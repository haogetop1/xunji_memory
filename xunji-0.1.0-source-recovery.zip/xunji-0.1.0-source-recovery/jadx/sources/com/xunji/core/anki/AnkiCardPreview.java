            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0013"}, d2 = {"Lcom/xunji/core/anki/AnkiCardPreview;", "", "question", "", "answer", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "getQuestion", "()Ljava/lang/String;", "getAnswer", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 26 */    public final /* data */ class AnkiCardPreview {
                private final String answer;
                private final String question;

                public static /* synthetic */ AnkiCardPreview copy$default(AnkiCardPreview ankiCardPreview, String str, String str2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = ankiCardPreview.question;
                    }
                    if ((i & 2) != 0) {
                        str2 = ankiCardPreview.answer;
                    }
                    return ankiCardPreview.copy(str, str2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getQuestion() {
                    return this.question;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getAnswer() {
                    return this.answer;
                }

                public final AnkiCardPreview copy(String question, String answer) {
                    Intrinsics.checkNotNullParameter(question, "question");
                    Intrinsics.checkNotNullParameter(answer, "answer");
                    return new AnkiCardPreview(question, answer);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiCardPreview)) {
                        return false;
                    }
                    AnkiCardPreview ankiCardPreview = (AnkiCardPreview) other;
                    return Intrinsics.areEqual(this.question, ankiCardPreview.question) && Intrinsics.areEqual(this.answer, ankiCardPreview.answer);
                }

                public int hashCode() {
                    return (this.question.hashCode() * 31) + this.answer.hashCode();
                }

                public String toString() {
                    return "AnkiCardPreview(question=" + this.question + ", answer=" + this.answer + ")";
                }

/* 27 */        public AnkiCardPreview(String question, String answer) {
                    Intrinsics.checkNotNullParameter(question, "question");
                    Intrinsics.checkNotNullParameter(answer, "answer");
                    this.question = question;
                    this.answer = answer;
                }

/* 27 */        public final String getAnswer() {
/* 28 */            return this.answer;
                }

/* 27 */        public final String getQuestion() {
/* 28 */            return this.question;
                }
            }

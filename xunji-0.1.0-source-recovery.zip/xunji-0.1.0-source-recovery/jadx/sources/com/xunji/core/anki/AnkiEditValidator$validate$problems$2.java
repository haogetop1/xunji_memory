            package com.xunji.core.anki;

            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEditValidator.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 13 */    final /* synthetic */ class AnkiEditValidator$validate$problems$2 extends FunctionReferenceImpl implements Function1<String, String> {
                AnkiEditValidator$validate$problems$2(Object obj) {
                    super(1, obj, Map.class, "get", "get(Ljava/lang/Object;)Ljava/lang/Object;", 0);
                }

                @Override // kotlin.jvm.functions.Function1
/* 14 */        public final String invoke(String p0) {
                    Intrinsics.checkNotNullParameter(p0, "p0");
/* 15 */            return (String) ((Map) this.receiver).get(p0);
                }
            }

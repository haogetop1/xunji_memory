            package com.xunji.core.anki;

            import java.io.UnsupportedEncodingException;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.LinkedHashMap;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import org.jsoup.Jsoup;
            
            /* JADX INFO: compiled from: AnkiEditValidator.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u001c\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bJ\u0010\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u000fH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/xunji/core/anki/AnkiEditValidator;", "", "renderer", "Lcom/xunji/core/anki/AnkiTemplateRenderer;", "<init>", "(Lcom/xunji/core/anki/AnkiTemplateRenderer;)V", "validate", "Lcom/xunji/core/anki/ValidatedFields;", "existing", "Lcom/xunji/core/anki/AnkiNoteContentModel;", "fields", "", "", "summary", "side", "Lcom/xunji/core/anki/RenderedSide;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final class AnkiEditValidator {
                private final AnkiTemplateRenderer renderer;

                /* JADX WARN: Multi-variable type inference failed */
                public AnkiEditValidator() {
                    this(null, 1);
                }

/* 4 */         public AnkiEditValidator(AnkiTemplateRenderer renderer) {
                    Intrinsics.checkNotNullParameter(renderer, "renderer");
                    this.renderer = renderer;
                }

/* 6 */         public final ValidatedFields validate(AnkiNoteContentModel existing, List<String> fields) throws UnsupportedEncodingException {
                    TemplateContext context;
                    Intrinsics.checkNotNullParameter(existing, "existing");
                    Intrinsics.checkNotNullParameter(fields, "fields");
/* 7 */             if (!(fields.size() == existing.getModel().getFieldNames().size())) {
                        throw new IllegalArgumentException("Note field mapping differs from model".toString());
                    }
/* 8 */             AnkiStorageValidator ankiStorageValidator = AnkiStorageValidator.INSTANCE;
                    AnkiSavedCardContext ankiSavedCardContext = (AnkiSavedCardContext) CollectionsKt.firstOrNull((List) existing.getSavedLinks());
                    List<String> tags = (ankiSavedCardContext == null || (context = ankiSavedCardContext.getContext()) == null) ? null : context.getTags();
                    if (tags == null) {
                        tags = CollectionsKt.emptyList();
                    }
                    AnkiStorageValidator.validateNote$default(ankiStorageValidator, fields, tags, CollectionsKt.emptyList(), 0, 0, 24, null);
/* 9 */             LinkedHashMap failures = new LinkedHashMap();
/* 10 */            LinkedHashMap previews = new LinkedHashMap();
                    for (AnkiSavedCardContext link : existing.getSavedLinks()) {
/* 12 */                TemplateContext context2 = TemplateContext.copy$default(link.getContext(), null, null, null, null, existing.getMediaMimes().keySet(), 15, null);
/* 13 */                RenderedSide question = this.renderer.render(existing.getModel(), fields, link.getOrdinal(), CardSide.QUESTION, context2);
/* 14 */                RenderedSide answer = this.renderer.render(existing.getModel(), fields, link.getOrdinal(), CardSide.ANSWER, context2);
/* 15 */                List problems = CollectionsKt.distinct(CollectionsKt.plus((Collection) CollectionsKt.plus((Collection) CollectionsKt.plus((Collection) question.getIssues(), (Iterable) answer.getIssues()), (Iterable) AnkiMediaValidator.INSTANCE.issues(question, new AnkiEditValidator$validate$problems$1(existing.getMediaMimes()))), (Iterable) AnkiMediaValidator.INSTANCE.issues(answer, new AnkiEditValidator$validate$problems$2(existing.getMediaMimes()))));
/* 16 */                if (problems.isEmpty()) {
                            previews.put(link.getCardId(), new AnkiCardPreview(summary(question), summary(answer)));
                        } else {
                            LinkedHashMap linkedHashMap = failures;
                            String cardId = link.getCardId();
                            Iterable $this$map$iv = CollectionsKt.take(problems, 4);
/* 31 */                    Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
                            for (Object item$iv$iv : $this$map$iv) {
/* 33 */                        List problems2 = problems;
                                RenderIssue it = (RenderIssue) item$iv$iv;
/* 33 */                        destination$iv$iv.add(it.copy(StringsKt.take(it.getCode(), 64), StringsKt.take(it.getDetail(), 160)));
                                problems = problems2;
/* 16 */                        $this$map$iv = $this$map$iv;
                                context2 = context2;
                                failures = failures;
                            }
/* 16 */                    linkedHashMap.put(cardId, (List) destination$iv$iv);
                        }
                    }
/* 19 */            LinkedHashMap failures2 = failures;
                    if (!failures2.isEmpty()) {
/* 19 */                throw new AnkiFieldValidationException(failures2);
                    }
/* 20 */            return new ValidatedFields(CollectionsKt.toList(fields), previews);
                }

/* 23 */        private final String summary(RenderedSide side) {
                    String strText = Jsoup.parseBodyFragment(new Regex("\\[sound:[^\\]]+]").replace(side.getHtml(), "[音频]")).text();
                    if (StringsKt.isBlank(strText)) {
                        strText = "[媒体]";
                    }
                    Intrinsics.checkNotNullExpressionValue(strText, "ifBlank(...)");
                    String text = strText;
/* 25 */            int[] points = text.codePoints().limit(160L).toArray();
/* 26 */            Intrinsics.checkNotNull(points);
                    return new String(points, 0, points.length);
                }
            }

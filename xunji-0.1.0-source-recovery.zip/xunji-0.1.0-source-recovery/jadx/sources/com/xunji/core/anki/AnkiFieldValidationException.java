            package com.xunji.core.anki;

            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00060\u0001j\u0002`\u0002B!\u0012\u0018\u0010\u0003\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00060\u0004¢\u0006\u0004\b\b\u0010\tR#\u0010\u0003\u001a\u0014\u0012\u0004\u0012\u00020\u0005\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00060\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lcom/xunji/core/anki/AnkiFieldValidationException;", "Ljava/lang/IllegalArgumentException;", "Lkotlin/IllegalArgumentException;", "issuesByCardId", "", "", "", "Lcom/xunji/core/anki/RenderIssue;", "<init>", "(Ljava/util/Map;)V", "getIssuesByCardId", "()Ljava/util/Map;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 28 */    public final class AnkiFieldValidationException extends IllegalArgumentException {
                private final Map<String, List<RenderIssue>> issuesByCardId;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
/* 29 */        public AnkiFieldValidationException(Map<String, ? extends List<RenderIssue>> issuesByCardId) {
/* 30 */            super("Saved Anki cards cannot render with these fields");
                    Intrinsics.checkNotNullParameter(issuesByCardId, "issuesByCardId");
                    this.issuesByCardId = issuesByCardId;
                }

/* 29 */        public final Map<String, List<RenderIssue>> getIssuesByCardId() {
/* 30 */            return this.issuesByCardId;
                }
            }

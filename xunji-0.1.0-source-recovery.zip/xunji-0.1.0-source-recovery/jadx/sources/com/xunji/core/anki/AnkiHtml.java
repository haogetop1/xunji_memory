            package com.xunji.core.anki;

            import com.fasterxml.jackson.core.JsonPointer;
            import java.io.UnsupportedEncodingException;
            import java.net.URLDecoder;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.Locale;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.collections.ArrayDeque;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.SetsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.sequences.Sequence;
            import kotlin.text.MatchResult;
            import kotlin.text.Regex;
            import kotlin.text.RegexOption;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.DebugKt;
            import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
            import org.jsoup.nodes.Attribute;
            import org.jsoup.nodes.Document;
            import org.jsoup.nodes.Element;
            import org.jsoup.nodes.Node;
            import org.jsoup.nodes.TextNode;
            import org.jsoup.parser.ParseError;
            import org.jsoup.parser.ParseErrorList;
            import org.jsoup.parser.Parser;
            
            /* JADX INFO: compiled from: AnkiHtml.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0010B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\t2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\t0\bR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\bX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/xunji/core/anki/AnkiHtml;", "", "<init>", "()V", "sound", "Lkotlin/text/Regex;", "cssUrl", "unsafeTags", "", "", "resourceTags", "inspect", "Lcom/xunji/core/anki/AnkiHtml$Inspection;", "html", "css", "mediaNames", "Inspection", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */     public final class AnkiHtml {
                public static final AnkiHtml INSTANCE = new AnkiHtml();
                private static final Regex sound = new Regex("\\[sound:([^\\]\\r\\n]+)]");
                private static final Regex cssUrl = new Regex("url\\(\\s*(['\"]?)(.*?)\\1\\s*\\)", RegexOption.IGNORE_CASE);
                private static final Set<String> unsafeTags = SetsKt.setOf((Object[]) new String[]{"script", "iframe", "object", "embed", "form", "base", "meta", "link", "svg", "math"});
                private static final Set<String> resourceTags = SetsKt.setOf((Object[]) new String[]{"img", "audio", "video", "source"});

                /* JADX INFO: compiled from: AnkiHtml.kt */
                @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B1\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00070\u0003¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u000f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00070\u0003HÆ\u0003J9\u0010\u0011\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00070\u0003HÆ\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0016HÖ\u0001J\t\u0010\u0017\u001a\u00020\u0004HÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00070\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000b¨\u0006\u0018"}, d2 = {"Lcom/xunji/core/anki/AnkiHtml$Inspection;", "", "audioNames", "", "", "resourceNames", "issues", "Lcom/xunji/core/anki/RenderIssue;", "<init>", "(Ljava/util/List;Ljava/util/List;Ljava/util/List;)V", "getAudioNames", "()Ljava/util/List;", "getResourceNames", "getIssues", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */         public static final /* data */ class Inspection {
                    private final List<String> audioNames;
                    private final List<RenderIssue> issues;
                    private final List<String> resourceNames;

                    /* JADX WARN: Multi-variable type inference failed */
                    public static /* synthetic */ Inspection copy$default(Inspection inspection, List list, List list2, List list3, int i, Object obj) {
                        if ((i & 1) != 0) {
                            list = inspection.audioNames;
                        }
                        if ((i & 2) != 0) {
                            list2 = inspection.resourceNames;
                        }
                        if ((i & 4) != 0) {
                            list3 = inspection.issues;
                        }
                        return inspection.copy(list, list2, list3);
                    }

                    public final List<String> component1() {
                        return this.audioNames;
                    }

                    public final List<String> component2() {
                        return this.resourceNames;
                    }

                    public final List<RenderIssue> component3() {
                        return this.issues;
                    }

                    public final Inspection copy(List<String> audioNames, List<String> resourceNames, List<RenderIssue> issues) {
                        Intrinsics.checkNotNullParameter(audioNames, "audioNames");
                        Intrinsics.checkNotNullParameter(resourceNames, "resourceNames");
                        Intrinsics.checkNotNullParameter(issues, "issues");
                        return new Inspection(audioNames, resourceNames, issues);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Inspection)) {
                            return false;
                        }
                        Inspection inspection = (Inspection) other;
                        return Intrinsics.areEqual(this.audioNames, inspection.audioNames) && Intrinsics.areEqual(this.resourceNames, inspection.resourceNames) && Intrinsics.areEqual(this.issues, inspection.issues);
                    }

                    public int hashCode() {
                        return (((this.audioNames.hashCode() * 31) + this.resourceNames.hashCode()) * 31) + this.issues.hashCode();
                    }

                    public String toString() {
                        return "Inspection(audioNames=" + this.audioNames + ", resourceNames=" + this.resourceNames + ", issues=" + this.issues + ")";
                    }

/* 10 */            public Inspection(List<String> audioNames, List<String> resourceNames, List<RenderIssue> issues) {
                        Intrinsics.checkNotNullParameter(audioNames, "audioNames");
                        Intrinsics.checkNotNullParameter(resourceNames, "resourceNames");
                        Intrinsics.checkNotNullParameter(issues, "issues");
                        this.audioNames = audioNames;
                        this.resourceNames = resourceNames;
                        this.issues = issues;
                    }

/* 10 */            public final List<String> getAudioNames() {
/* 11 */                return this.audioNames;
                    }

/* 10 */            public final List<RenderIssue> getIssues() {
/* 11 */                return this.issues;
                    }

/* 10 */            public final List<String> getResourceNames() {
/* 11 */                return this.resourceNames;
                    }
                }

/* 9 */         private AnkiHtml() {
                }

/* 17 */        public final Inspection inspect(String html, String css, Set<String> mediaNames) throws UnsupportedEncodingException {
                    boolean z;
                    String str;
                    String str2;
                    boolean z2;
                    String str3;
                    boolean z3;
                    Set<String> mediaNames2 = mediaNames;
                    Intrinsics.checkNotNullParameter(html, "html");
                    Intrinsics.checkNotNullParameter(css, "css");
                    Intrinsics.checkNotNullParameter(mediaNames2, "mediaNames");
/* 18 */            List issues = new ArrayList();
/* 19 */            List audio = new ArrayList();
/* 20 */            List resources = new ArrayList();
/* 39 */            inspect$css(issues, mediaNames2, audio, resources, css);
/* 40 */            Iterable $this$any$iv = CollectionsKt.listOf((Object[]) new String[]{"[latex]", "[$]", "[$$]", "\\(", "\\["});
                    int i = 0;
/* 73 */            if (!($this$any$iv instanceof Collection) || !((Collection) $this$any$iv).isEmpty()) {
/* 74 */                Iterator it = $this$any$iv.iterator();
                        while (true) {
                            if (it.hasNext()) {
                                Object element$iv = it.next();
                                String it2 = (String) element$iv;
/* 74 */                        if (StringsKt.contains((CharSequence) html, (CharSequence) it2, true)) {
                                    z = true;
                                    break;
                                }
                            } else {
/* 75 */                        z = false;
                                break;
                            }
                        }
                    } else {
                        z = false;
                    }
/* 40 */            if (z) {
/* 41 */                inspect$issue(issues, "unsupported_math", "LaTeX/MathJax content requires Anki rendering");
                    }
/* 42 */            if (StringsKt.contains((CharSequence) html, (CharSequence) "[anki:tts", true)) {
                        inspect$issue(issues, "unsupported_tts", "Anki TTS is unsupported");
                    }
/* 43 */            Parser trackErrors = Parser.htmlParser().setTrackErrors(8);
                    Intrinsics.checkNotNullExpressionValue(trackErrors, "setTrackErrors(...)");
                    Parser parser = trackErrors;
/* 44 */            Document document = parser.parseInput(html, "");
                    Intrinsics.checkNotNullExpressionValue(document, "parseInput(...)");
/* 45 */            ParseErrorList errors = parser.getErrors();
                    Intrinsics.checkNotNullExpressionValue(errors, "getErrors(...)");
                    if (!errors.isEmpty()) {
                        ParseErrorList errors2 = parser.getErrors();
                        Intrinsics.checkNotNullExpressionValue(errors2, "getErrors(...)");
                        String errorMessage = ((ParseError) CollectionsKt.first((List) errors2)).getErrorMessage();
                        Intrinsics.checkNotNullExpressionValue(errorMessage, "getErrorMessage(...)");
                        inspect$issue(issues, "invalid_html", errorMessage);
                    }
/* 46 */            ArrayDeque pending = new ArrayDeque();
/* 47 */            pending.addLast(document);
/* 48 */            while (!pending.isEmpty()) {
/* 49 */                Node node = (Node) pending.removeLast();
/* 50 */                List<Node> listChildNodes = node.childNodes();
                        Intrinsics.checkNotNullExpressionValue(listChildNodes, "childNodes(...)");
                        Iterable $this$forEach$iv = CollectionsKt.asReversedMutable(listChildNodes);
                        for (Object element$iv2 : $this$forEach$iv) {
                            Node p0 = (Node) element$iv2;
/* 50 */                    pending.addLast(p0);
                        }
/* 51 */                if (node instanceof TextNode) {
                            Regex regex = sound;
                            String wholeText = ((TextNode) node).getWholeText();
                            Intrinsics.checkNotNullExpressionValue(wholeText, "getWholeText(...)");
                            Sequence $this$forEach$iv2 = Regex.findAll$default(regex, wholeText, i, 2, null);
                            for (Object element$iv3 : $this$forEach$iv2) {
                                MatchResult it3 = (MatchResult) element$iv3;
/* 51 */                        inspect$reference(mediaNames2, audio, resources, issues, it3.getGroupValues().get(1), true);
                            }
                        }
/* 52 */                if (node instanceof Element) {
                            String str4 = "unsupported_html";
/* 53 */                    if (unsafeTags.contains(((Element) node).tagName())) {
                                inspect$issue(issues, "unsupported_html", "Unsupported HTML element: " + ((Element) node).tagName());
                            }
/* 55 */                    if (Intrinsics.areEqual(((Element) node).tagName(), "video")) {
                                inspect$issue(issues, "unsupported_video", "Video is unsupported");
                            }
/* 56 */                    Iterator<Attribute> it4 = ((Element) node).attributes().iterator();
                            Intrinsics.checkNotNullExpressionValue(it4, "iterator(...)");
                            while (it4.hasNext()) {
                                Attribute next = it4.next();
                                Intrinsics.checkNotNullExpressionValue(next, "next(...)");
                                Attribute attribute = next;
/* 57 */                        String key2 = attribute.getKey();
                                Intrinsics.checkNotNullExpressionValue(key2, "<get-key>(...)");
                                String key = key2.toLowerCase(Locale.ROOT);
                                Intrinsics.checkNotNullExpressionValue(key, "toLowerCase(...)");
                                parser = parser;
                                it4 = it4;
/* 58 */                        if (StringsKt.startsWith$default(key, DebugKt.DEBUG_PROPERTY_VALUE_ON, false, 2, (Object) null)) {
                                    inspect$issue(issues, str4, "Event handler: " + key);
                                }
/* 59 */                        if (Intrinsics.areEqual(key, "srcdoc")) {
                                    inspect$issue(issues, str4, "Embedded HTML is unsupported");
                                }
/* 60 */                        if (Intrinsics.areEqual(key, "style")) {
                                    String value2 = attribute.getValue();
                                    Intrinsics.checkNotNullExpressionValue(value2, "<get-value>(...)");
                                    inspect$css(issues, mediaNames2, audio, resources, value2);
                                }
/* 61 */                        if (!Intrinsics.areEqual(key, "srcset")) {
/* 61 */                            str = str4;
                                } else {
                                    String value3 = attribute.getValue();
                                    Intrinsics.checkNotNullExpressionValue(value3, "<get-value>(...)");
                                    Iterable $this$forEach$iv3 = StringsKt.split$default((CharSequence) value3, new char[]{AbstractJsonLexerKt.COMMA}, false, 0, 6, (Object) null);
                                    for (Object element$iv4 : $this$forEach$iv3) {
                                        String it5 = (String) element$iv4;
                                        audio = audio;
/* 61 */                                inspect$reference(mediaNames, audio, resources, issues, StringsKt.substringBefore$default(StringsKt.trim((CharSequence) it5).toString(), ' ', (String) null, 2, (Object) null), false);
/* 80 */                                str4 = str4;
                                    }
/* 81 */                            str = str4;
                                }
/* 62 */                        if (!SetsKt.setOf((Object[]) new String[]{"src", "href", "poster", "data"}).contains(key)) {
/* 62 */                            mediaNames2 = mediaNames;
                                    str4 = str;
                                } else {
/* 63 */                            if (Intrinsics.areEqual(key, "href")) {
                                        String value4 = attribute.getValue();
                                        Intrinsics.checkNotNullExpressionValue(value4, "<get-value>(...)");
                                        str2 = str;
                                        z2 = false;
                                        str3 = null;
                                        if (StringsKt.startsWith$default((CharSequence) value4, '#', false, 2, (Object) null)) {
                                            mediaNames2 = mediaNames;
                                            str4 = str2;
                                        }
                                    } else {
                                        str2 = str;
                                        z2 = false;
                                        str3 = null;
                                    }
/* 53 */                            if (resourceTags.contains(((Element) node).tagName()) || !Intrinsics.areEqual(key, "src")) {
                                        String value5 = attribute.getValue();
                                        Intrinsics.checkNotNullExpressionValue(value5, "<get-value>(...)");
                                        if (Intrinsics.areEqual(key, "src")) {
/* 53 */                                    if (!Intrinsics.areEqual(((Element) node).tagName(), "audio")) {
/* 53 */                                        if (Intrinsics.areEqual(((Element) node).tagName(), "source")) {
/* 53 */                                            Element elementParent = ((Element) node).parent();
                                                    if (Intrinsics.areEqual(elementParent != null ? elementParent.tagName() : str3, "audio")) {
                                                    }
                                                }
                                                z3 = z2;
                                            }
                                            z3 = true;
                                        } else {
                                            z3 = z2;
                                        }
                                        mediaNames2 = mediaNames;
                                        inspect$reference(mediaNames2, audio, resources, issues, value5, z3);
                                        str4 = str2;
                                    } else {
                                        mediaNames2 = mediaNames;
                                        str4 = str2;
                                    }
                                }
                            }
/* 67 */                    Parser parser2 = parser;
/* 53 */                    if (Intrinsics.areEqual(((Element) node).tagName(), "style")) {
/* 53 */                        String strData = ((Element) node).data();
                                Intrinsics.checkNotNullExpressionValue(strData, "data(...)");
                                inspect$css(issues, mediaNames2, audio, resources, strData);
                                i = 0;
                                parser = parser2;
                            } else {
                                i = 0;
                                parser = parser2;
                            }
                        }
                    }
/* 69 */            return new Inspection(audio, resources, issues);
                }

/* 20 */        private static final void inspect$issue(List<RenderIssue> list, String code, String detail) {
/* 21 */            if (list.size() < 64) {
                        list.add(new RenderIssue(code, detail));
                    }
                }

                /* JADX WARN: Unreachable blocks removed: 2, instructions: 2 */
/* 22 */        private static final void inspect$reference(Set<String> set, List<String> list, List<String> list2, List<RenderIssue> list3, String raw, boolean isAudio) throws UnsupportedEncodingException {
                    boolean z;
                    String decoded;
                    boolean z2;
                    String name = StringsKt.trim((CharSequence) raw).toString();
/* 24 */            if (name.length() == 0) {
                        return;
                    }
                    String actual = null;
/* 25 */            if (!StringsKt.startsWith$default(name, "//", false, 2, (Object) null)) {
                        Set of = SetsKt.setOf((Object[]) new String[]{"http", "https"});
                        String lowerCase = StringsKt.substringBefore$default(name, AbstractJsonLexerKt.COLON, (String) null, 2, (Object) null).toLowerCase(Locale.ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        if (!of.contains(lowerCase)) {
/* 26 */                    if (StringsKt.contains$default((CharSequence) StringsKt.substringBefore$default(name, JsonPointer.SEPARATOR, (String) null, 2, (Object) null), AbstractJsonLexerKt.COLON, false, 2, (Object) null)) {
                                inspect$issue(list3, "unsafe_url", "Unsupported URL: " + name);
                                return;
                            }
/* 26 */                    if (!StringsKt.startsWith$default((CharSequence) name, JsonPointer.SEPARATOR, false, 2, (Object) null) && !StringsKt.startsWith$default((CharSequence) name, AbstractJsonLexerKt.STRING_ESC, false, 2, (Object) null)) {
                                Iterable $this$any$iv = StringsKt.split$default((CharSequence) name, new char[]{JsonPointer.SEPARATOR, AbstractJsonLexerKt.STRING_ESC}, false, 0, 6, (Object) null);
/* 82 */                        if (!($this$any$iv instanceof Collection) || !((Collection) $this$any$iv).isEmpty()) {
/* 83 */                            Iterator it = $this$any$iv.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 84 */                                    z = false;
                                            break;
                                        }
                                        Object element$iv = it.next();
                                        String it2 = (String) element$iv;
/* 83 */                                if (Intrinsics.areEqual(it2, "..")) {
                                            z = true;
                                            break;
                                        }
                                    }
                                } else {
                                    z = false;
                                }
/* 27 */                        if (!z) {
                                    try {
/* 28 */                                decoded = URLDecoder.decode(StringsKt.replace$default(name, "+", "%2B", false, 4, (Object) null), "UTF-8");
                                    } catch (IllegalArgumentException e) {
                                        decoded = name;
                                    }
/* 29 */                            Intrinsics.checkNotNull(decoded);
/* 26 */                            if (!StringsKt.startsWith$default((CharSequence) decoded, JsonPointer.SEPARATOR, false, 2, (Object) null) && !StringsKt.startsWith$default((CharSequence) decoded, AbstractJsonLexerKt.STRING_ESC, false, 2, (Object) null)) {
                                        Iterable $this$any$iv2 = StringsKt.split$default((CharSequence) decoded, new char[]{JsonPointer.SEPARATOR, AbstractJsonLexerKt.STRING_ESC}, false, 0, 6, (Object) null);
/* 85 */                                if (!($this$any$iv2 instanceof Collection) || !((Collection) $this$any$iv2).isEmpty()) {
/* 86 */                                    Iterator it3 = $this$any$iv2.iterator();
                                            while (true) {
                                                if (!it3.hasNext()) {
/* 87 */                                            z2 = false;
                                                    break;
                                                }
                                                Object element$iv2 = it3.next();
                                                String it4 = (String) element$iv2;
/* 86 */                                        if (Intrinsics.areEqual(it4, "..")) {
                                                    z2 = true;
                                                    break;
                                                }
                                            }
                                        } else {
                                            z2 = false;
                                        }
/* 29 */                                if (!z2) {
/* 30 */                                    if (set.contains(name)) {
                                                actual = name;
                                            } else if (set.contains(decoded)) {
                                                actual = decoded;
                                            }
/* 31 */                                    if (actual == null) {
                                                inspect$issue(list3, "missing_media", "Missing local media: " + name);
/* 33 */                                        return;
                                            } else {
/* 32 */                                        (isAudio ? list : list2).add(actual);
/* 33 */                                        return;
                                            }
                                        }
                                    }
/* 29 */                            inspect$issue(list3, "unsafe_url", "Unsafe decoded path: " + name);
                                    return;
                                }
                            }
/* 27 */                    inspect$issue(list3, "unsafe_url", "Unsafe path: " + name);
                            return;
                        }
                    }
/* 25 */            inspect$issue(list3, "external_resource", "External URL: " + name);
                }

/* 34 */        private static final void inspect$css(List<RenderIssue> list, Set<String> set, List<String> list2, List<String> list3, String text) throws UnsupportedEncodingException {
/* 35 */            if (new Regex("</style\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
                        inspect$issue(list, "unsupported_css", "CSS must not terminate its style element");
                    }
/* 36 */            if (new Regex("@import\\b", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
                        inspect$issue(list, "external_resource", "CSS import is unsupported");
                    }
/* 37 */            Sequence $this$forEach$iv = Regex.findAll$default(cssUrl, text, 0, 2, null);
                    for (Object element$iv : $this$forEach$iv) {
                        MatchResult it = (MatchResult) element$iv;
/* 37 */                inspect$reference(set, list2, list3, list, it.getGroupValues().get(2), false);
                    }
                }
            }

            package com.xunji.core.anki;

            import androidx.compose.material.MenuKt;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: AnkiMediaValidator.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0018\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\u0005J*\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n2\u0006\u0010\f\u001a\u00020\r2\u0014\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\u0007\u0012\u0006\u0012\u0004\u0018\u00010\u00070\u000f¨\u0006\u0010"}, d2 = {"Lcom/xunji/core/anki/AnkiMediaValidator;", "", "<init>", "()V", "accepts", "", "mime", "", "audio", "issues", "", "Lcom/xunji/core/anki/RenderIssue;", "side", "Lcom/xunji/core/anki/RenderedSide;", "mimeFor", "Lkotlin/Function1;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 2 */     public final class AnkiMediaValidator {
                public static final AnkiMediaValidator INSTANCE = new AnkiMediaValidator();

/* 3 */         private AnkiMediaValidator() {
                }

/* 4 */         public final boolean accepts(String mime, boolean audio) {
                    if (audio) {
                        return mime != null && StringsKt.startsWith$default(mime, "audio/", false, 2, (Object) null);
                    }
/* 6 */             if (mime != null && StringsKt.startsWith$default(mime, "image/", false, 2, (Object) null)) {
                        return true;
                    }
                    return (mime != null && StringsKt.startsWith$default(mime, "font/", false, 2, (Object) null)) || Intrinsics.areEqual(mime, "application/font-woff") || Intrinsics.areEqual(mime, "application/vnd.ms-fontobject");
                }

/* 7 */         public final List<RenderIssue> issues(RenderedSide side, Function1<? super String, String> mimeFor) {
                    Intrinsics.checkNotNullParameter(side, "side");
                    Intrinsics.checkNotNullParameter(mimeFor, "mimeFor");
/* 8 */             List $this$issues_u24lambda_u240 = CollectionsKt.createListBuilder();
/* 15 */            issues$lambda$0$check($this$issues_u24lambda_u240, mimeFor, side.getAudioNames(), true);
                    issues$lambda$0$check($this$issues_u24lambda_u240, mimeFor, side.getResourceNames(), false);
/* 8 */             return CollectionsKt.build($this$issues_u24lambda_u240);
                }

/* 9 */         private static final void issues$lambda$0$check(List<RenderIssue> list, Function1<? super String, String> function1, List<String> list2, boolean audio) {
                    for (String name : list2) {
/* 11 */                if (list.size() == 8) {
                            return;
                        }
/* 12 */                if (!INSTANCE.accepts(function1.invoke(name), audio)) {
                            list.add(new RenderIssue("media_role", (audio ? "Audio" : "Resource") + " MIME mismatch: " + StringsKt.take(name, MenuKt.InTransitionDuration)));
                        }
                    }
                }
            }

            package com.xunji.core.anki;

            import androidx.autofill.HintConstants;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001BM\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\t\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u000b0\t\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\b\b\u0002\u0010\r\u001a\u00020\u0007¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0007HÆ\u0003J\u000f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00050\tHÆ\u0003J\u000f\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u000b0\tHÆ\u0003J\t\u0010 \u001a\u00020\u0005HÆ\u0003J\t\u0010!\u001a\u00020\u0007HÆ\u0003J[\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\t2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u000b0\t2\b\b\u0002\u0010\f\u001a\u00020\u00052\b\b\u0002\u0010\r\u001a\u00020\u0007HÆ\u0001J\u0013\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010&\u001a\u00020\u0007HÖ\u0001J\t\u0010'\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00050\t¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0017R\u0011\u0010\f\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0013R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0015¨\u0006("}, d2 = {"Lcom/xunji/core/anki/AnkiModel;", "", "sourceId", "", HintConstants.AUTOFILL_HINT_NAME, "", "kind", "", "fieldNames", "", "templates", "Lcom/xunji/core/anki/AnkiTemplate;", "css", "originalStockKind", "<init>", "(JLjava/lang/String;ILjava/util/List;Ljava/util/List;Ljava/lang/String;I)V", "getSourceId", "()J", "getName", "()Ljava/lang/String;", "getKind", "()I", "getFieldNames", "()Ljava/util/List;", "getTemplates", "getCss", "getOriginalStockKind", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */     public final /* data */ class AnkiModel {
                private final String css;
                private final List<String> fieldNames;
                private final int kind;
                private final String name;
                private final int originalStockKind;
                private final long sourceId;
                private final List<AnkiTemplate> templates;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ AnkiModel copy$default(AnkiModel ankiModel, long j, String str, int i, List list, List list2, String str2, int i2, int i3, Object obj) {
                    if ((i3 & 1) != 0) {
                        j = ankiModel.sourceId;
                    }
                    long j2 = j;
                    if ((i3 & 2) != 0) {
                        str = ankiModel.name;
                    }
                    String str3 = str;
                    if ((i3 & 4) != 0) {
                        i = ankiModel.kind;
                    }
                    int i4 = i;
                    if ((i3 & 8) != 0) {
                        list = ankiModel.fieldNames;
                    }
                    List list3 = list;
                    if ((i3 & 16) != 0) {
                        list2 = ankiModel.templates;
                    }
                    return ankiModel.copy(j2, str3, i4, list3, list2, (i3 & 32) != 0 ? ankiModel.css : str2, (i3 & 64) != 0 ? ankiModel.originalStockKind : i2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSourceId() {
                    return this.sourceId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getKind() {
                    return this.kind;
                }

                public final List<String> component4() {
                    return this.fieldNames;
                }

                public final List<AnkiTemplate> component5() {
                    return this.templates;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final String getCss() {
                    return this.css;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final int getOriginalStockKind() {
                    return this.originalStockKind;
                }

                public final AnkiModel copy(long sourceId, String name, int kind, List<String> fieldNames, List<AnkiTemplate> templates, String css, int originalStockKind) {
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(fieldNames, "fieldNames");
                    Intrinsics.checkNotNullParameter(templates, "templates");
                    Intrinsics.checkNotNullParameter(css, "css");
                    return new AnkiModel(sourceId, name, kind, fieldNames, templates, css, originalStockKind);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiModel)) {
                        return false;
                    }
                    AnkiModel ankiModel = (AnkiModel) other;
                    return this.sourceId == ankiModel.sourceId && Intrinsics.areEqual(this.name, ankiModel.name) && this.kind == ankiModel.kind && Intrinsics.areEqual(this.fieldNames, ankiModel.fieldNames) && Intrinsics.areEqual(this.templates, ankiModel.templates) && Intrinsics.areEqual(this.css, ankiModel.css) && this.originalStockKind == ankiModel.originalStockKind;
                }

                public int hashCode() {
                    return (((((((((((Long.hashCode(this.sourceId) * 31) + this.name.hashCode()) * 31) + Integer.hashCode(this.kind)) * 31) + this.fieldNames.hashCode()) * 31) + this.templates.hashCode()) * 31) + this.css.hashCode()) * 31) + Integer.hashCode(this.originalStockKind);
                }

                public String toString() {
                    return "AnkiModel(sourceId=" + this.sourceId + ", name=" + this.name + ", kind=" + this.kind + ", fieldNames=" + this.fieldNames + ", templates=" + this.templates + ", css=" + this.css + ", originalStockKind=" + this.originalStockKind + ")";
                }

/* 10 */        public AnkiModel(long sourceId, String name, int kind, List<String> fieldNames, List<AnkiTemplate> templates, String css, int originalStockKind) {
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(fieldNames, "fieldNames");
                    Intrinsics.checkNotNullParameter(templates, "templates");
                    Intrinsics.checkNotNullParameter(css, "css");
                    this.sourceId = sourceId;
                    this.name = name;
                    this.kind = kind;
                    this.fieldNames = fieldNames;
                    this.templates = templates;
                    this.css = css;
                    this.originalStockKind = originalStockKind;
                }

/* 10 */        public final String getCss() {
/* 11 */            return this.css;
                }

/* 10 */        public final List<String> getFieldNames() {
/* 11 */            return this.fieldNames;
                }

/* 10 */        public final int getKind() {
/* 11 */            return this.kind;
                }

/* 10 */        public final String getName() {
/* 11 */            return this.name;
                }

/* 10 */        public final int getOriginalStockKind() {
/* 11 */            return this.originalStockKind;
                }

/* 10 */        public final long getSourceId() {
/* 11 */            return this.sourceId;
                }

/* 10 */        public final List<AnkiTemplate> getTemplates() {
/* 11 */            return this.templates;
                }
            }

            package com.xunji.core.anki;

            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005\u0012\u0012\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\n¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0003J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\b0\u0005HÆ\u0003J\u0015\u0010\u0017\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\nHÆ\u0003JI\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u00052\u0014\b\u0002\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\nHÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u001dHÖ\u0001J\t\u0010\u001e\u001a\u00020\u0006HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u001d\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00060\n¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u001f"}, d2 = {"Lcom/xunji/core/anki/AnkiNoteContentModel;", "", "model", "Lcom/xunji/core/anki/AnkiModel;", "fields", "", "", "savedLinks", "Lcom/xunji/core/anki/AnkiSavedCardContext;", "mediaMimes", "", "<init>", "(Lcom/xunji/core/anki/AnkiModel;Ljava/util/List;Ljava/util/List;Ljava/util/Map;)V", "getModel", "()Lcom/xunji/core/anki/AnkiModel;", "getFields", "()Ljava/util/List;", "getSavedLinks", "getMediaMimes", "()Ljava/util/Map;", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 24 */    public final /* data */ class AnkiNoteContentModel {
                private final List<String> fields;
                private final Map<String, String> mediaMimes;
                private final AnkiModel model;
                private final List<AnkiSavedCardContext> savedLinks;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ AnkiNoteContentModel copy$default(AnkiNoteContentModel ankiNoteContentModel, AnkiModel ankiModel, List list, List list2, Map map, int i, Object obj) {
                    if ((i & 1) != 0) {
                        ankiModel = ankiNoteContentModel.model;
                    }
                    if ((i & 2) != 0) {
                        list = ankiNoteContentModel.fields;
                    }
                    if ((i & 4) != 0) {
                        list2 = ankiNoteContentModel.savedLinks;
                    }
                    if ((i & 8) != 0) {
                        map = ankiNoteContentModel.mediaMimes;
                    }
                    return ankiNoteContentModel.copy(ankiModel, list, list2, map);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final AnkiModel getModel() {
                    return this.model;
                }

                public final List<String> component2() {
                    return this.fields;
                }

                public final List<AnkiSavedCardContext> component3() {
                    return this.savedLinks;
                }

                public final Map<String, String> component4() {
                    return this.mediaMimes;
                }

                public final AnkiNoteContentModel copy(AnkiModel model, List<String> fields, List<AnkiSavedCardContext> savedLinks, Map<String, String> mediaMimes) {
                    Intrinsics.checkNotNullParameter(model, "model");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(savedLinks, "savedLinks");
                    Intrinsics.checkNotNullParameter(mediaMimes, "mediaMimes");
                    return new AnkiNoteContentModel(model, fields, savedLinks, mediaMimes);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiNoteContentModel)) {
                        return false;
                    }
                    AnkiNoteContentModel ankiNoteContentModel = (AnkiNoteContentModel) other;
                    return Intrinsics.areEqual(this.model, ankiNoteContentModel.model) && Intrinsics.areEqual(this.fields, ankiNoteContentModel.fields) && Intrinsics.areEqual(this.savedLinks, ankiNoteContentModel.savedLinks) && Intrinsics.areEqual(this.mediaMimes, ankiNoteContentModel.mediaMimes);
                }

                public int hashCode() {
                    return (((((this.model.hashCode() * 31) + this.fields.hashCode()) * 31) + this.savedLinks.hashCode()) * 31) + this.mediaMimes.hashCode();
                }

                public String toString() {
                    return "AnkiNoteContentModel(model=" + this.model + ", fields=" + this.fields + ", savedLinks=" + this.savedLinks + ", mediaMimes=" + this.mediaMimes + ")";
                }

/* 25 */        public AnkiNoteContentModel(AnkiModel model, List<String> fields, List<AnkiSavedCardContext> savedLinks, Map<String, String> mediaMimes) {
                    Intrinsics.checkNotNullParameter(model, "model");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(savedLinks, "savedLinks");
                    Intrinsics.checkNotNullParameter(mediaMimes, "mediaMimes");
                    this.model = model;
                    this.fields = fields;
                    this.savedLinks = savedLinks;
                    this.mediaMimes = mediaMimes;
                }

/* 25 */        public final List<String> getFields() {
/* 26 */            return this.fields;
                }

/* 25 */        public final Map<String, String> getMediaMimes() {
/* 26 */            return this.mediaMimes;
                }

/* 25 */        public final AnkiModel getModel() {
/* 26 */            return this.model;
                }

/* 25 */        public final List<AnkiSavedCardContext> getSavedLinks() {
/* 26 */            return this.savedLinks;
                }
            }

            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0019"}, d2 = {"Lcom/xunji/core/anki/AnkiSavedCardContext;", "", "cardId", "", "ordinal", "", "context", "Lcom/xunji/core/anki/TemplateContext;", "<init>", "(Ljava/lang/String;ILcom/xunji/core/anki/TemplateContext;)V", "getCardId", "()Ljava/lang/String;", "getOrdinal", "()I", "getContext", "()Lcom/xunji/core/anki/TemplateContext;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 23 */    public final /* data */ class AnkiSavedCardContext {
                private final String cardId;
                private final TemplateContext context;
                private final int ordinal;

                public static /* synthetic */ AnkiSavedCardContext copy$default(AnkiSavedCardContext ankiSavedCardContext, String str, int i, TemplateContext templateContext, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        str = ankiSavedCardContext.cardId;
                    }
                    if ((i2 & 2) != 0) {
                        i = ankiSavedCardContext.ordinal;
                    }
                    if ((i2 & 4) != 0) {
                        templateContext = ankiSavedCardContext.context;
                    }
                    return ankiSavedCardContext.copy(str, i, templateContext);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getOrdinal() {
                    return this.ordinal;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final TemplateContext getContext() {
                    return this.context;
                }

                public final AnkiSavedCardContext copy(String cardId, int ordinal, TemplateContext context) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(context, "context");
                    return new AnkiSavedCardContext(cardId, ordinal, context);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiSavedCardContext)) {
                        return false;
                    }
                    AnkiSavedCardContext ankiSavedCardContext = (AnkiSavedCardContext) other;
                    return Intrinsics.areEqual(this.cardId, ankiSavedCardContext.cardId) && this.ordinal == ankiSavedCardContext.ordinal && Intrinsics.areEqual(this.context, ankiSavedCardContext.context);
                }

                public int hashCode() {
                    return (((this.cardId.hashCode() * 31) + Integer.hashCode(this.ordinal)) * 31) + this.context.hashCode();
                }

                public String toString() {
                    return "AnkiSavedCardContext(cardId=" + this.cardId + ", ordinal=" + this.ordinal + ", context=" + this.context + ")";
                }

/* 24 */        public AnkiSavedCardContext(String cardId, int ordinal, TemplateContext context) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(context, "context");
                    this.cardId = cardId;
                    this.ordinal = ordinal;
                    this.context = context;
                }

/* 24 */        public final String getCardId() {
/* 25 */            return this.cardId;
                }

/* 24 */        public final TemplateContext getContext() {
/* 25 */            return this.context;
                }

/* 24 */        public final int getOrdinal() {
/* 25 */            return this.ordinal;
                }
            }

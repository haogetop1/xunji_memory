            package com.xunji.core.anki;

            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0003¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J;\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u0007HÖ\u0001J\t\u0010\u001e\u001a\u00020\u001fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\fR\u0011\u0010\u0012\u001a\u00020\u00038F¢\u0006\u0006\u001a\u0004\b\u0013\u0010\f¨\u0006 "}, d2 = {"Lcom/xunji/core/anki/AnkiSourceCard;", "", "sourceId", "", "noteId", "deckId", "ordinal", "", "originalDeckId", "<init>", "(JJJIJ)V", "getSourceId", "()J", "getNoteId", "getDeckId", "getOrdinal", "()I", "getOriginalDeckId", "effectiveDeckId", "getEffectiveDeckId", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */    public final /* data */ class AnkiSourceCard {
                private final long deckId;
                private final long noteId;
                private final int ordinal;
                private final long originalDeckId;
                private final long sourceId;

                public static /* synthetic */ AnkiSourceCard copy$default(AnkiSourceCard ankiSourceCard, long j, long j2, long j3, int i, long j4, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        j = ankiSourceCard.sourceId;
                    }
                    long j5 = j;
                    if ((i2 & 2) != 0) {
                        j2 = ankiSourceCard.noteId;
                    }
                    return ankiSourceCard.copy(j5, j2, (i2 & 4) != 0 ? ankiSourceCard.deckId : j3, (i2 & 8) != 0 ? ankiSourceCard.ordinal : i, (i2 & 16) != 0 ? ankiSourceCard.originalDeckId : j4);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSourceId() {
                    return this.sourceId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final long getNoteId() {
                    return this.noteId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getDeckId() {
                    return this.deckId;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getOrdinal() {
                    return this.ordinal;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final long getOriginalDeckId() {
                    return this.originalDeckId;
                }

                public final AnkiSourceCard copy(long sourceId, long noteId, long deckId, int ordinal, long originalDeckId) {
                    return new AnkiSourceCard(sourceId, noteId, deckId, ordinal, originalDeckId);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiSourceCard)) {
                        return false;
                    }
                    AnkiSourceCard ankiSourceCard = (AnkiSourceCard) other;
                    return this.sourceId == ankiSourceCard.sourceId && this.noteId == ankiSourceCard.noteId && this.deckId == ankiSourceCard.deckId && this.ordinal == ankiSourceCard.ordinal && this.originalDeckId == ankiSourceCard.originalDeckId;
                }

                public int hashCode() {
                    return (((((((Long.hashCode(this.sourceId) * 31) + Long.hashCode(this.noteId)) * 31) + Long.hashCode(this.deckId)) * 31) + Integer.hashCode(this.ordinal)) * 31) + Long.hashCode(this.originalDeckId);
                }

                public String toString() {
                    return "AnkiSourceCard(sourceId=" + this.sourceId + ", noteId=" + this.noteId + ", deckId=" + this.deckId + ", ordinal=" + this.ordinal + ", originalDeckId=" + this.originalDeckId + ")";
                }

/* 12 */        public AnkiSourceCard(long sourceId, long noteId, long deckId, int ordinal, long originalDeckId) {
                    this.sourceId = sourceId;
                    this.noteId = noteId;
                    this.deckId = deckId;
                    this.ordinal = ordinal;
                    this.originalDeckId = originalDeckId;
                }

/* 12 */        public final long getDeckId() {
/* 13 */            return this.deckId;
                }

/* 12 */        public final long getNoteId() {
/* 13 */            return this.noteId;
                }

/* 12 */        public final int getOrdinal() {
/* 13 */            return this.ordinal;
                }

/* 12 */        public final long getOriginalDeckId() {
/* 13 */            return this.originalDeckId;
                }

/* 12 */        public final long getSourceId() {
/* 13 */            return this.sourceId;
                }

/* 13 */        public final long getEffectiveDeckId() {
/* 14 */            Long lValueOf = Long.valueOf(this.originalDeckId);
                    long it = lValueOf.longValue();
                    if (!(it != 0)) {
                        lValueOf = null;
                    }
                    return lValueOf != null ? lValueOf.longValue() : this.deckId;
                }
            }

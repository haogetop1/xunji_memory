            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0005HÆ\u0003J\u001d\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"Lcom/xunji/core/anki/AnkiSourceDeck;", "", "sourceId", "", "fullName", "", "<init>", "(JLjava/lang/String;)V", "getSourceId", "()J", "getFullName", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 14 */    public final /* data */ class AnkiSourceDeck {
                private final String fullName;
                private final long sourceId;

                public static /* synthetic */ AnkiSourceDeck copy$default(AnkiSourceDeck ankiSourceDeck, long j, String str, int i, Object obj) {
                    if ((i & 1) != 0) {
                        j = ankiSourceDeck.sourceId;
                    }
                    if ((i & 2) != 0) {
                        str = ankiSourceDeck.fullName;
                    }
                    return ankiSourceDeck.copy(j, str);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSourceId() {
                    return this.sourceId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getFullName() {
                    return this.fullName;
                }

                public final AnkiSourceDeck copy(long sourceId, String fullName) {
                    Intrinsics.checkNotNullParameter(fullName, "fullName");
                    return new AnkiSourceDeck(sourceId, fullName);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiSourceDeck)) {
                        return false;
                    }
                    AnkiSourceDeck ankiSourceDeck = (AnkiSourceDeck) other;
                    return this.sourceId == ankiSourceDeck.sourceId && Intrinsics.areEqual(this.fullName, ankiSourceDeck.fullName);
                }

                public int hashCode() {
                    return (Long.hashCode(this.sourceId) * 31) + this.fullName.hashCode();
                }

                public String toString() {
                    return "AnkiSourceDeck(sourceId=" + this.sourceId + ", fullName=" + this.fullName + ")";
                }

/* 15 */        public AnkiSourceDeck(long sourceId, String fullName) {
                    Intrinsics.checkNotNullParameter(fullName, "fullName");
                    this.sourceId = sourceId;
                    this.fullName = fullName;
                }

/* 15 */        public final String getFullName() {
/* 16 */            return this.fullName;
                }

/* 15 */        public final long getSourceId() {
/* 16 */            return this.sourceId;
                }
            }

            package com.xunji.core.anki;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\b\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\b¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00050\bHÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00050\bHÆ\u0003JG\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\b2\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\bHÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\rR\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00050\b¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00050\b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012¨\u0006 "}, d2 = {"Lcom/xunji/core/anki/AnkiSourceNote;", "", "sourceId", "", "guid", "", "modelId", "fields", "", "tags", "<init>", "(JLjava/lang/String;JLjava/util/List;Ljava/util/List;)V", "getSourceId", "()J", "getGuid", "()Ljava/lang/String;", "getModelId", "getFields", "()Ljava/util/List;", "getTags", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 10 */    public final /* data */ class AnkiSourceNote {
                private final List<String> fields;
                private final String guid;
                private final long modelId;
                private final long sourceId;
                private final List<String> tags;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ AnkiSourceNote copy$default(AnkiSourceNote ankiSourceNote, long j, String str, long j2, List list, List list2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        j = ankiSourceNote.sourceId;
                    }
                    long j3 = j;
                    if ((i & 2) != 0) {
                        str = ankiSourceNote.guid;
                    }
                    String str2 = str;
                    if ((i & 4) != 0) {
                        j2 = ankiSourceNote.modelId;
                    }
                    long j4 = j2;
                    if ((i & 8) != 0) {
                        list = ankiSourceNote.fields;
                    }
                    List list3 = list;
                    if ((i & 16) != 0) {
                        list2 = ankiSourceNote.tags;
                    }
                    return ankiSourceNote.copy(j3, str2, j4, list3, list2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSourceId() {
                    return this.sourceId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getGuid() {
                    return this.guid;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getModelId() {
                    return this.modelId;
                }

                public final List<String> component4() {
                    return this.fields;
                }

                public final List<String> component5() {
                    return this.tags;
                }

                public final AnkiSourceNote copy(long sourceId, String guid, long modelId, List<String> fields, List<String> tags) {
                    Intrinsics.checkNotNullParameter(guid, "guid");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    return new AnkiSourceNote(sourceId, guid, modelId, fields, tags);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiSourceNote)) {
                        return false;
                    }
                    AnkiSourceNote ankiSourceNote = (AnkiSourceNote) other;
                    return this.sourceId == ankiSourceNote.sourceId && Intrinsics.areEqual(this.guid, ankiSourceNote.guid) && this.modelId == ankiSourceNote.modelId && Intrinsics.areEqual(this.fields, ankiSourceNote.fields) && Intrinsics.areEqual(this.tags, ankiSourceNote.tags);
                }

                public int hashCode() {
                    return (((((((Long.hashCode(this.sourceId) * 31) + this.guid.hashCode()) * 31) + Long.hashCode(this.modelId)) * 31) + this.fields.hashCode()) * 31) + this.tags.hashCode();
                }

                public String toString() {
                    return "AnkiSourceNote(sourceId=" + this.sourceId + ", guid=" + this.guid + ", modelId=" + this.modelId + ", fields=" + this.fields + ", tags=" + this.tags + ")";
                }

/* 11 */        public AnkiSourceNote(long sourceId, String guid, long modelId, List<String> fields, List<String> tags) {
                    Intrinsics.checkNotNullParameter(guid, "guid");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    this.sourceId = sourceId;
                    this.guid = guid;
                    this.modelId = modelId;
                    this.fields = fields;
                    this.tags = tags;
                }

/* 11 */        public final List<String> getFields() {
/* 12 */            return this.fields;
                }

/* 11 */        public final String getGuid() {
/* 12 */            return this.guid;
                }

/* 11 */        public final long getModelId() {
/* 12 */            return this.modelId;
                }

/* 11 */        public final long getSourceId() {
/* 12 */            return this.sourceId;
                }

/* 11 */        public final List<String> getTags() {
/* 12 */            return this.tags;
                }
            }

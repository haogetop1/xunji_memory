            package com.xunji.core.anki;

            import androidx.autofill.HintConstants;
            import java.nio.CharBuffer;
            import java.nio.charset.CodingErrorAction;
            import java.util.Collection;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.Charsets;
            import kotlin.text.StringsKt;
            import kotlinx.serialization.internal.ArrayListSerializer;
            import kotlinx.serialization.internal.StringSerializer;
            import kotlinx.serialization.json.Json;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\u0019B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003JD\u0010\u0007\u001a\u00020\u00052\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\n0\t2\b\b\u0002\u0010\r\u001a\u00020\u00052\b\b\u0002\u0010\u000e\u001a\u00020\u0005J:\u0010\u000f\u001a\u00020\u00052\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\n0\t2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00120\t2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\n0\t2\b\b\u0002\u0010\u000e\u001a\u00020\u0005J\u000e\u0010\u0014\u001a\u00020\u00052\u0006\u0010\u0015\u001a\u00020\nJ&\u0010\u0016\u001a\u00020\u00052\f\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\u0017\u001a\u00020\u00052\u0006\u0010\u0018\u001a\u00020\nH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/anki/AnkiStorageValidator;", "", "<init>", "()V", "MAX_FIELD_BYTES", "", "MAX_STORED_BYTES", "validateNote", "fields", "", "", "tags", "otherText", "fieldBytes", "storedBytes", "validateModel", "fieldNames", "templates", "Lcom/xunji/core/anki/AnkiTemplate;", "templateSyntaxBytes", "utf8Bytes", "text", "checkStorage", "maximum", "label", "ModelBudget", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 31 */    public final class AnkiStorageValidator {
                public static final AnkiStorageValidator INSTANCE = new AnkiStorageValidator();
                public static final int MAX_FIELD_BYTES = 262144;
                public static final int MAX_STORED_BYTES = 524288;
                private static final int templateSyntaxBytes;

/* 32 */        private AnkiStorageValidator() {
                }

/* 35 */        public static /* synthetic */ int validateNote$default(AnkiStorageValidator ankiStorageValidator, List list, List list2, List list3, int i, int i2, int i3, Object obj) {
/* 36 */            if ((i3 & 8) != 0) {
                        i = 262144;
                    }
                    int i4 = i;
                    if ((i3 & 16) != 0) {
                        i2 = 524288;
                    }
                    return ankiStorageValidator.validateNote(list, list2, list3, i4, i2);
                }

/* 36 */        public final int validateNote(List<String> fields, List<String> tags, List<String> otherText, int fieldBytes, int storedBytes) {
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    Intrinsics.checkNotNullParameter(otherText, "otherText");
/* 37 */            List<String> $this$all$iv = fields;
                    boolean z = true;
/* 90 */            if (!($this$all$iv instanceof Collection) || !$this$all$iv.isEmpty()) {
                        for (Object element$iv : $this$all$iv) {
                            String it = (String) element$iv;
/* 91 */                    if (!(INSTANCE.utf8Bytes(it) <= fieldBytes)) {
                                z = false;
                                break;
                            }
                        }
                    }
/* 37 */            if (!z) {
/* 37 */                throw new IllegalArgumentException(("note field exceeds " + fieldBytes + " UTF-8 bytes").toString());
                    }
/* 38 */            Json this_$iv = Json.INSTANCE;
/* 94 */            this_$iv.getSerializersModule();
                    String strEncodeToString = this_$iv.encodeToString(new ArrayListSerializer(StringSerializer.INSTANCE), fields);
/* 38 */            Json value$iv = Json.INSTANCE;
                    Json this_$iv2 = value$iv;
/* 94 */            this_$iv2.getSerializersModule();
/* 38 */            return checkStorage(CollectionsKt.plus((Collection) CollectionsKt.listOf((Object[]) new String[]{strEncodeToString, this_$iv2.encodeToString(new ArrayListSerializer(StringSerializer.INSTANCE), tags)}), (Iterable) otherText), storedBytes, "note");
                }

/* 39 */        public static /* synthetic */ int validateModel$default(AnkiStorageValidator ankiStorageValidator, List list, List list2, List list3, int i, int i2, Object obj) {
/* 40 */            if ((i2 & 8) != 0) {
                        i = 524288;
                    }
                    return ankiStorageValidator.validateModel(list, list2, list3, i);
                }

/* 40 */        public final int validateModel(List<String> fieldNames, List<AnkiTemplate> templates, List<String> otherText, int storedBytes) {
                    Intrinsics.checkNotNullParameter(fieldNames, "fieldNames");
                    Intrinsics.checkNotNullParameter(templates, "templates");
                    Intrinsics.checkNotNullParameter(otherText, "otherText");
/* 41 */            ModelBudget $this$validateModel_u24lambda_u240 = new ModelBudget(otherText, storedBytes);
/* 41 */            List<String> $this$forEach$iv = fieldNames;
                    for (Object element$iv : $this$forEach$iv) {
                        String p0 = (String) element$iv;
/* 41 */                $this$validateModel_u24lambda_u240.addField(p0);
                    }
/* 41 */            List<AnkiTemplate> $this$forEach$iv2 = templates;
                    for (Object element$iv2 : $this$forEach$iv2) {
                        AnkiTemplate p1 = (AnkiTemplate) element$iv2;
/* 41 */                $this$validateModel_u24lambda_u240.addTemplate(p1);
                    }
                    return $this$validateModel_u24lambda_u240.getBytes();
                }

                /* JADX INFO: compiled from: AnkiModels.kt */
                @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\u0018\u00002\u00020\u0001B\u001f\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\u000e\u0010\u0010\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0004J\u000e\u0010\u0013\u001a\u00020\u00112\u0006\u0010\u0014\u001a\u00020\u0015J\u0010\u0010\u0016\u001a\u00020\u00112\u0006\u0010\u0017\u001a\u00020\u0006H\u0002J\u0018\u0010\u0018\u001a\u00020\u00112\u0006\u0010\u0019\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u001bH\u0002R\u000e\u0010\u0005\u001a\u00020\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0006X\u0082\u000e¢\u0006\u0002\n\u0000R\u0011\u0010\r\u001a\u00020\u00068F¢\u0006\u0006\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001c"}, d2 = {"Lcom/xunji/core/anki/AnkiStorageValidator$ModelBudget;", "", "otherText", "", "", "maximum", "", "<init>", "(Ljava/util/List;I)V", "total", "", "fields", "templates", "bytes", "getBytes", "()I", "addField", "", HintConstants.AUTOFILL_HINT_NAME, "addTemplate", "template", "Lcom/xunji/core/anki/AnkiTemplate;", "add", "n", "text", "value", "jsonString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 42 */        public static final class ModelBudget {
                    private int fields;
                    private final int maximum;
                    private int templates;
                    private long total;

/* 43 */            public ModelBudget(List<String> otherText, int maximum) {
                        Intrinsics.checkNotNullParameter(otherText, "otherText");
                        this.maximum = maximum;
/* 49 */                add(4);
                        List<String> $this$forEach$iv = otherText;
                        for (Object element$iv : $this$forEach$iv) {
                            String it = (String) element$iv;
/* 49 */                    text(it, false);
                        }
                    }

/* 47 */            public final int getBytes() {
/* 48 */                return (int) this.total;
                    }

/* 49 */            public final void addField(String name) {
                        Intrinsics.checkNotNullParameter(name, "name");
/* 50 */                int i = this.fields;
                        this.fields = i + 1;
                        if (i > 0) {
                            add(1);
                        }
                        text(name, true);
                    }

/* 51 */            public final void addTemplate(AnkiTemplate template) {
                        Intrinsics.checkNotNullParameter(template, "template");
/* 52 */                int i = this.templates;
                        this.templates = i + 1;
                        if (i > 0) {
                            add(1);
                        }
/* 33 */                add(AnkiStorageValidator.templateSyntaxBytes + String.valueOf(template.getOrdinal()).length());
/* 54 */                text(template.getName(), true);
                        text(template.getQuestionFormat(), true);
                        text(template.getAnswerFormat(), true);
                    }

/* 56 */            private final void add(int n) {
/* 57 */                this.total += (long) n;
                        if (this.total <= ((long) this.maximum)) {
                        } else {
                            throw new IllegalArgumentException(("stored model exceeds " + this.maximum + " UTF-8 bytes after JSON escaping").toString());
                        }
                    }

/* 60 */            private final void text(String value, boolean jsonString) {
                        int size;
                        if (jsonString) {
/* 61 */                    add(2);
                        }
/* 62 */                int index = 0;
/* 63 */                while (index < value.length()) {
/* 64 */                    int index2 = index + 1;
                            char cCharAt = value.charAt(index);
/* 66 */                    boolean z = false;
/* 61 */                    if (jsonString && (cCharAt == '\"' || cCharAt == '\\' || StringsKt.contains$default((CharSequence) "\b\t\n\f\r", cCharAt, false, 2, (Object) null))) {
/* 61 */                        size = 2;
                            } else if (jsonString && cCharAt < ' ') {
                                size = 6;
                            } else if (Character.isHighSurrogate(cCharAt)) {
/* 69 */                        if (index2 < value.length() && Character.isLowSurrogate(value.charAt(index2))) {
                                    z = true;
                                }
                                if (!z) {
                                    throw new IllegalArgumentException("Invalid UTF-16 model text".toString());
                                }
/* 70 */                        index2++;
                                size = 4;
                            } else {
/* 72 */                        if (Character.isLowSurrogate(cCharAt)) {
/* 72 */                            throw new IllegalArgumentException("Invalid UTF-16 model text");
                                }
/* 73 */                        if (cCharAt < 128) {
                                    size = 1;
                                } else {
/* 75 */                            size = cCharAt < 2048 ? 2 : 3;
                                }
                            }
/* 77 */                    add(size);
                            index = index2;
                        }
                    }
                }

                static {
/* 81 */            AnkiStorageValidator ankiStorageValidator = INSTANCE;
                    Json this_$iv = Json.INSTANCE;
                    AnkiTemplate ankiTemplate = new AnkiTemplate(0, "", "", "");
/* 97 */            this_$iv.getSerializersModule();
/* 81 */            templateSyntaxBytes = ankiStorageValidator.utf8Bytes(this_$iv.encodeToString(AnkiTemplate.INSTANCE.serializer(), ankiTemplate)) - 7;
                }

/* 81 */        public final int utf8Bytes(String text) {
                    Intrinsics.checkNotNullParameter(text, "text");
/* 82 */            return Charsets.UTF_8.newEncoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).encode(CharBuffer.wrap(text)).remaining();
                }

/* 83 */        private final int checkStorage(List<String> text, int maximum, String label) {
                    long size = 0;
                    for (String it : text) {
/* 84 */                size += (long) INSTANCE.utf8Bytes(it);
                    }
                    if (!(size <= ((long) maximum))) {
/* 85 */                throw new IllegalArgumentException(("stored " + label + " exceeds " + maximum + " UTF-8 bytes after JSON escaping").toString());
                    }
/* 86 */            return (int) size;
                }
            }

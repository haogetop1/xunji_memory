            package com.xunji.core.anki;

            import androidx.autofill.HintConstants;
            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/anki/AnkiTemplate.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/anki/AnkiTemplate;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 7 */     public final /* synthetic */ class AnkiTemplate$$serializer implements GeneratedSerializer<AnkiTemplate> {
                public static final AnkiTemplate$$serializer INSTANCE = new AnkiTemplate$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 9 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.anki.AnkiTemplate", INSTANCE, 4);
                    pluginGeneratedSerialDescriptor.addElement("ordinal", false);
                    pluginGeneratedSerialDescriptor.addElement(HintConstants.AUTOFILL_HINT_NAME, false);
                    pluginGeneratedSerialDescriptor.addElement("questionFormat", false);
                    pluginGeneratedSerialDescriptor.addElement("answerFormat", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 8 */         private AnkiTemplate$$serializer() {
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 8 */         public final KSerializer<?>[] childSerializers() {
/* 9 */             return new KSerializer[]{IntSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 8 */         public final AnkiTemplate deserialize(Decoder decoder) {
                    int i;
                    String strDecodeStringElement;
                    String str;
                    String str2;
                    int i2;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 9 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        int iDecodeIntElement = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 0);
                        String strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                        String strDecodeStringElement3 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                        i = iDecodeIntElement;
                        i2 = 15;
                        strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                        str = strDecodeStringElement3;
                        str2 = strDecodeStringElement2;
                    } else {
                        String strDecodeStringElement4 = null;
                        String strDecodeStringElement5 = null;
                        String strDecodeStringElement6 = null;
                        boolean z = true;
                        int iDecodeIntElement2 = 0;
                        int i3 = 0;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    break;
                                case 0:
                                    iDecodeIntElement2 = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 0);
                                    i3 |= 1;
                                    break;
                                case 1:
                                    strDecodeStringElement6 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                                    i3 |= 2;
                                    break;
                                case 2:
                                    strDecodeStringElement5 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                                    i3 |= 4;
                                    break;
                                case 3:
                                    strDecodeStringElement4 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                                    i3 |= 8;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        i = iDecodeIntElement2;
                        strDecodeStringElement = strDecodeStringElement4;
                        str = strDecodeStringElement5;
                        str2 = strDecodeStringElement6;
                        i2 = i3;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new AnkiTemplate(i2, i, str2, str, strDecodeStringElement, null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 8 */         public final void serialize(Encoder encoder, AnkiTemplate value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 9 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    AnkiTemplate.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 8 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 9 */             return super.typeParametersSerializers();
                }
            }

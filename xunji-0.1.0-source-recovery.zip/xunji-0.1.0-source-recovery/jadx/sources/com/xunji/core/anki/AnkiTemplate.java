            package com.xunji.core.anki;

            import androidx.autofill.HintConstants;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 '2\u00020\u0001:\u0002&'B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tBA\b\u0010\u0012\u0006\u0010\n\u001a\u00020\u0003\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\b\u0010\rJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0005HÆ\u0003J1\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001d\u001a\u00020\u0005HÖ\u0001J%\u0010\u001e\u001a\u00020\u001f2\u0006\u0010 \u001a\u00020\u00002\u0006\u0010!\u001a\u00020\"2\u0006\u0010#\u001a\u00020$H\u0001¢\u0006\u0002\b%R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0011R\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0011¨\u0006("}, d2 = {"Lcom/xunji/core/anki/AnkiTemplate;", "", "ordinal", "", HintConstants.AUTOFILL_HINT_NAME, "", "questionFormat", "answerFormat", "<init>", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getOrdinal", "()I", "getName", "()Ljava/lang/String;", "getQuestionFormat", "getAnswerFormat", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 6 */     public final /* data */ class AnkiTemplate {

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private final String answerFormat;
                private final String name;
                private final int ordinal;
                private final String questionFormat;

                public static /* synthetic */ AnkiTemplate copy$default(AnkiTemplate ankiTemplate, int i, String str, String str2, String str3, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        i = ankiTemplate.ordinal;
                    }
                    if ((i2 & 2) != 0) {
                        str = ankiTemplate.name;
                    }
                    if ((i2 & 4) != 0) {
                        str2 = ankiTemplate.questionFormat;
                    }
                    if ((i2 & 8) != 0) {
                        str3 = ankiTemplate.answerFormat;
                    }
                    return ankiTemplate.copy(i, str, str2, str3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final int getOrdinal() {
                    return this.ordinal;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getQuestionFormat() {
                    return this.questionFormat;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getAnswerFormat() {
                    return this.answerFormat;
                }

                public final AnkiTemplate copy(int ordinal, String name, String questionFormat, String answerFormat) {
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(questionFormat, "questionFormat");
                    Intrinsics.checkNotNullParameter(answerFormat, "answerFormat");
                    return new AnkiTemplate(ordinal, name, questionFormat, answerFormat);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiTemplate)) {
                        return false;
                    }
                    AnkiTemplate ankiTemplate = (AnkiTemplate) other;
                    return this.ordinal == ankiTemplate.ordinal && Intrinsics.areEqual(this.name, ankiTemplate.name) && Intrinsics.areEqual(this.questionFormat, ankiTemplate.questionFormat) && Intrinsics.areEqual(this.answerFormat, ankiTemplate.answerFormat);
                }

                public int hashCode() {
                    return (((((Integer.hashCode(this.ordinal) * 31) + this.name.hashCode()) * 31) + this.questionFormat.hashCode()) * 31) + this.answerFormat.hashCode();
                }

                public String toString() {
                    return "AnkiTemplate(ordinal=" + this.ordinal + ", name=" + this.name + ", questionFormat=" + this.questionFormat + ", answerFormat=" + this.answerFormat + ")";
                }

                /* JADX INFO: compiled from: AnkiModels.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplate$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/anki/AnkiTemplate;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */         public static final class Companion {
/* 8 */             private Companion() {
                    }

/* 8 */             public final KSerializer<AnkiTemplate> serializer() {
/* 9 */                 return AnkiTemplate$$serializer.INSTANCE;
                    }
                }

/* 8 */         public /* synthetic */ AnkiTemplate(int seen0, int ordinal, String name, String questionFormat, String answerFormat, SerializationConstructorMarker serializationConstructorMarker) {
/* 9 */             if (15 != (seen0 & 15)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, 15, AnkiTemplate$$serializer.INSTANCE.getDescriptor());
                    }
                    this.ordinal = ordinal;
                    this.name = name;
                    this.questionFormat = questionFormat;
                    this.answerFormat = answerFormat;
                }

/* 8 */         public AnkiTemplate(int ordinal, String name, String questionFormat, String answerFormat) {
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(questionFormat, "questionFormat");
                    Intrinsics.checkNotNullParameter(answerFormat, "answerFormat");
/* 10 */            this.ordinal = ordinal;
                    this.name = name;
                    this.questionFormat = questionFormat;
                    this.answerFormat = answerFormat;
                }

                @JvmStatic
/* 8 */         public static final /* synthetic */ void write$Self$core(AnkiTemplate self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 9 */             output.encodeIntElement(serialDesc, 0, self.ordinal);
                    output.encodeStringElement(serialDesc, 1, self.name);
                    output.encodeStringElement(serialDesc, 2, self.questionFormat);
                    output.encodeStringElement(serialDesc, 3, self.answerFormat);
                }

/* 9 */         public final String getAnswerFormat() {
/* 10 */            return this.answerFormat;
                }

/* 9 */         public final String getName() {
/* 10 */            return this.name;
                }

/* 9 */         public final int getOrdinal() {
/* 10 */            return this.ordinal;
                }

/* 9 */         public final String getQuestionFormat() {
/* 10 */            return this.questionFormat;
                }
            }

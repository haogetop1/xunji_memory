            package com.xunji.core.anki;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 102 */   final /* synthetic */ class AnkiTemplateRenderer$renderFormat$renderParts$1 extends FunctionReferenceImpl implements Function2<String, String, Unit> {
                final /* synthetic */ List<RenderIssue> $issues;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnkiTemplateRenderer$renderFormat$renderParts$1(List<RenderIssue> list) {
                    super(2, Intrinsics.Kotlin.class, "issue", "renderFormat$issue(Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V", 0);
                    this.$issues = list;
                }

                @Override // kotlin.jvm.functions.Function2
/* 103 */       public /* bridge */ /* synthetic */ Unit invoke(String str, String str2) {
/* 104 */           invoke2(str, str2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 103 */       public final void invoke2(String p0, String p1) {
                    Intrinsics.checkNotNullParameter(p0, "p0");
                    Intrinsics.checkNotNullParameter(p1, "p1");
/* 5 */             AnkiTemplateRenderer.renderFormat$issue(this.$issues, p0, p1);
                }
            }

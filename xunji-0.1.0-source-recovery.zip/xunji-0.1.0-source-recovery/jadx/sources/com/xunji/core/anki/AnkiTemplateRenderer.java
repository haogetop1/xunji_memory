            package com.xunji.core.anki;

            import androidx.autofill.HintConstants;
            import java.io.UnsupportedEncodingException;
            import java.util.ArrayList;
            import java.util.Iterator;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Map;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Pair;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.ArrayDeque;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.collections.SetsKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.text.StringsKt;
            import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
            import org.jsoup.Jsoup;
            
            /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 \u001f2\u00020\u0001:\u0006\u001a\u001b\u001c\u001d\u001e\u001fB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J4\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010JZ\u0010\u0011\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\n2\u0012\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\n0\u00142\u0006\u0010\u0015\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0016\u001a\u00020\n2\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018H\u0002¨\u0006 "}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer;", "", "<init>", "()V", "render", "Lcom/xunji/core/anki/RenderedSide;", "model", "Lcom/xunji/core/anki/AnkiModel;", "fields", "", "", "ordinal", "", "side", "Lcom/xunji/core/anki/CardSide;", "context", "Lcom/xunji/core/anki/TemplateContext;", "renderFormat", "format", "values", "", "kind", "frontSide", "issues", "", "Lcom/xunji/core/anki/RenderIssue;", "Part", "RenderLimitException", "BoundedHtml", "ClozePart", "ClozeParser", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final class AnkiTemplateRenderer {

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();

                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\u00060\u0001j\u0002`\u0002B\u0007¢\u0006\u0004\b\u0003\u0010\u0004¨\u0006\u0005"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$RenderLimitException;", "Ljava/lang/RuntimeException;", "Lkotlin/RuntimeException;", "<init>", "()V", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
                private static final class RenderLimitException extends RuntimeException {
                }

                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\br\u0018\u00002\u00020\u0001:\u0003\u0002\u0003\u0004\u0082\u0001\u0003\u0005\u0006\u0007¨\u0006\bÀ\u0006\u0003"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$Part;", "", "Text", "Field", "Section", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Field;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Section;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Text;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */         private interface Part {

                    /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Text;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part;", "value", "", "<init>", "(Ljava/lang/String;)V", "getValue", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */             public static final /* data */ class Text implements Part {
                        private final String value;

                        public static /* synthetic */ Text copy$default(Text text, String str, int i, Object obj) {
                            if ((i & 1) != 0) {
                                str = text.value;
                            }
                            return text.copy(str);
                        }

                        /* JADX INFO: renamed from: component1, reason: from getter */
                        public final String getValue() {
                            return this.value;
                        }

                        public final Text copy(String value) {
                            Intrinsics.checkNotNullParameter(value, "value");
                            return new Text(value);
                        }

                        public boolean equals(Object other) {
                            if (this == other) {
                                return true;
                            }
                            return (other instanceof Text) && Intrinsics.areEqual(this.value, ((Text) other).value);
                        }

                        public int hashCode() {
                            return this.value.hashCode();
                        }

                        public String toString() {
                            return "Text(value=" + this.value + ")";
                        }

/* 6 */                 public Text(String value) {
                            Intrinsics.checkNotNullParameter(value, "value");
                            this.value = value;
                        }

/* 6 */                 public final String getValue() {
/* 7 */                     return this.value;
                        }
                    }

                    /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Field;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part;", HintConstants.AUTOFILL_HINT_NAME, "", "<init>", "(Ljava/lang/String;)V", "getName", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */             public static final /* data */ class Field implements Part {
                        private final String name;

                        public static /* synthetic */ Field copy$default(Field field, String str, int i, Object obj) {
                            if ((i & 1) != 0) {
                                str = field.name;
                            }
                            return field.copy(str);
                        }

                        /* JADX INFO: renamed from: component1, reason: from getter */
                        public final String getName() {
                            return this.name;
                        }

                        public final Field copy(String name) {
                            Intrinsics.checkNotNullParameter(name, "name");
                            return new Field(name);
                        }

                        public boolean equals(Object other) {
                            if (this == other) {
                                return true;
                            }
                            return (other instanceof Field) && Intrinsics.areEqual(this.name, ((Field) other).name);
                        }

                        public int hashCode() {
                            return this.name.hashCode();
                        }

                        public String toString() {
                            return "Field(name=" + this.name + ")";
                        }

/* 7 */                 public Field(String name) {
                            Intrinsics.checkNotNullParameter(name, "name");
                            this.name = name;
                        }

/* 7 */                 public final String getName() {
/* 8 */                     return this.name;
                        }
                    }

                    /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010!\n\u0002\b\u000e\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\u000f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007HÆ\u0003J-\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00052\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$Part$Section;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$Part;", HintConstants.AUTOFILL_HINT_NAME, "", "inverted", "", "children", "", "<init>", "(Ljava/lang/String;ZLjava/util/List;)V", "getName", "()Ljava/lang/String;", "getInverted", "()Z", "getChildren", "()Ljava/util/List;", "component1", "component2", "component3", "copy", "equals", "other", "", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */             public static final /* data */ class Section implements Part {
                        private final List<Part> children;
                        private final boolean inverted;
                        private final String name;

                        /* JADX WARN: Multi-variable type inference failed */
                        public static /* synthetic */ Section copy$default(Section section, String str, boolean z, List list, int i, Object obj) {
                            if ((i & 1) != 0) {
                                str = section.name;
                            }
                            if ((i & 2) != 0) {
                                z = section.inverted;
                            }
                            if ((i & 4) != 0) {
                                list = section.children;
                            }
                            return section.copy(str, z, list);
                        }

                        /* JADX INFO: renamed from: component1, reason: from getter */
                        public final String getName() {
                            return this.name;
                        }

                        /* JADX INFO: renamed from: component2, reason: from getter */
                        public final boolean getInverted() {
                            return this.inverted;
                        }

                        public final List<Part> component3() {
                            return this.children;
                        }

                        public final Section copy(String name, boolean inverted, List<Part> children) {
                            Intrinsics.checkNotNullParameter(name, "name");
                            Intrinsics.checkNotNullParameter(children, "children");
                            return new Section(name, inverted, children);
                        }

                        public boolean equals(Object other) {
                            if (this == other) {
                                return true;
                            }
                            if (!(other instanceof Section)) {
                                return false;
                            }
                            Section section = (Section) other;
                            return Intrinsics.areEqual(this.name, section.name) && this.inverted == section.inverted && Intrinsics.areEqual(this.children, section.children);
                        }

                        public int hashCode() {
                            return (((this.name.hashCode() * 31) + Boolean.hashCode(this.inverted)) * 31) + this.children.hashCode();
                        }

                        public String toString() {
                            return "Section(name=" + this.name + ", inverted=" + this.inverted + ", children=" + this.children + ")";
                        }

/* 8 */                 public Section(String name, boolean inverted, List<Part> children) {
                            Intrinsics.checkNotNullParameter(name, "name");
                            Intrinsics.checkNotNullParameter(children, "children");
                            this.name = name;
                            this.inverted = inverted;
                            this.children = children;
                        }

/* 8 */                 public final List<Part> getChildren() {
/* 9 */                     return this.children;
                        }

/* 8 */                 public final boolean getInverted() {
/* 9 */                     return this.inverted;
                        }

/* 8 */                 public final String getName() {
/* 9 */                     return this.name;
                        }
                    }
                }

                /* JADX WARN: Code duplicated, block: B:18:0x004b  */
/* 12 */        public final RenderedSide render(AnkiModel model, List<String> fields, int ordinal, CardSide side, TemplateContext context) throws UnsupportedEncodingException {
                    Object element$iv;
                    Intrinsics.checkNotNullParameter(model, "model");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(side, "side");
                    Intrinsics.checkNotNullParameter(context, "context");
/* 13 */            List issues = new ArrayList();
/* 15 */            int kind = model.getKind();
                    if (kind >= 0 && kind < 2) {
                        int originalStockKind = model.getOriginalStockKind();
                        if (!(originalStockKind >= 0 && originalStockKind < 6) || model.getOriginalStockKind() == 4) {
                            render$issue(issues, "unsupported_model", "Unsupported note type/stock kind: " + model.getKind() + "/" + model.getOriginalStockKind());
                        }
                    } else {
                        render$issue(issues, "unsupported_model", "Unsupported note type/stock kind: " + model.getKind() + "/" + model.getOriginalStockKind());
                    }
/* 16 */            if (fields.size() != model.getFieldNames().size()) {
                        render$issue(issues, "field_count", "Expected " + model.getFieldNames().size() + " fields, found " + fields.size());
                    }
/* 17 */            Iterable $this$firstOrNull$iv = model.getTemplates();
/* 201 */           Iterator it = $this$firstOrNull$iv.iterator();
/* 201 */           do {
                        if (!it.hasNext()) {
/* 202 */                   element$iv = null;
                            break;
                        }
                        element$iv = it.next();
/* 201 */           } while (!(((AnkiTemplate) element$iv).getOrdinal() == (model.getKind() == 1 ? 0 : ordinal)));
/* 17 */            AnkiTemplate template = (AnkiTemplate) element$iv;
                    if (template == null) {
/* 18 */                render$issue(issues, "missing_template", "No template for ordinal " + ordinal);
                    }
/* 19 */            if (ordinal < 0) {
/* 18 */                render$issue(issues, "missing_template", "Negative card ordinal");
                    }
/* 20 */            if (!issues.isEmpty()) {
                        return new RenderedSide("", CollectionsKt.emptyList(), CollectionsKt.emptyList(), issues);
                    }
/* 21 */            Map<String, String> map = MapsKt.toMap(CollectionsKt.zip(model.getFieldNames(), fields));
/* 22 */            if (template == null) {
/* 22 */                throw new IllegalArgumentException("Required value was null.".toString());
                    }
/* 23 */            String question = renderFormat(template.getQuestionFormat(), map, model.getKind(), ordinal, CardSide.QUESTION, context, "", issues);
/* 24 */            String html = side == CardSide.QUESTION ? question : renderFormat(template.getAnswerFormat(), map, model.getKind(), ordinal, CardSide.ANSWER, context, question, issues);
/* 25 */            if (StringsKt.isBlank(html)) {
                        render$issue(issues, side == CardSide.QUESTION ? "empty_question" : "empty_answer", "Rendered side is empty");
                    }
/* 26 */            AnkiHtml.Inspection inspection = AnkiHtml.INSTANCE.inspect(html, model.getCss(), context.getMediaNames());
/* 27 */            Iterable $this$forEach$iv = inspection.getIssues();
                    for (Object element$iv2 : $this$forEach$iv) {
                        RenderIssue it2 = (RenderIssue) element$iv2;
/* 27 */                render$issue(issues, it2.getCode(), it2.getDetail());
                        inspection = inspection;
                    }
/* 204 */           AnkiHtml.Inspection inspection2 = inspection;
/* 28 */            return new RenderedSide(html, inspection2.getAudioNames(), inspection2.getResourceNames(), issues);
                }

/* 13 */        private static final void render$issue(List<RenderIssue> list, String code, String detail) {
/* 14 */            if (list.size() < 64) {
                        list.add(new RenderIssue(code, detail));
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 31 */        public static final void renderFormat$issue(List<RenderIssue> list, String code, String detail) {
/* 32 */            if (list.size() < 64) {
                        list.add(new RenderIssue(code, detail));
                    }
                }

/* 32 */        private final String renderFormat(String format, Map<String, String> values, int kind, int ordinal, CardSide side, TemplateContext context, String frontSide, List<RenderIssue> issues) {
                    List root = new ArrayList();
/* 34 */            ArrayDeque stack = new ArrayDeque();
/* 36 */            int start = 0;
/* 37 */            while (start < format.length()) {
/* 38 */                int open = StringsKt.indexOf$default((CharSequence) format, "{{", start, false, 4, (Object) null);
/* 39 */                int start2 = start;
                        if (open < 0) {
                            List<Part> listRenderFormat$destination = renderFormat$destination(stack, root);
/* 33 */                    String strSubstring = format.substring(start2);
                            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                            listRenderFormat$destination.add(new Part.Text(strSubstring));
                            break;
                        }
/* 40 */                if (open > start2) {
                            List<Part> listRenderFormat$destination2 = renderFormat$destination(stack, root);
/* 33 */                    String strSubstring2 = format.substring(start2, open);
                            Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                            listRenderFormat$destination2.add(new Part.Text(strSubstring2));
                        }
/* 41 */                int close = StringsKt.indexOf$default((CharSequence) format, "}}", open + 2, false, 4, (Object) null);
/* 42 */                if (close < 0) {
                            renderFormat$issue(issues, "template_block", "Unclosed template token");
                            break;
                        }
/* 33 */                String strSubstring3 = format.substring(open + 2, close);
                        Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                        String token = StringsKt.trim((CharSequence) strSubstring3).toString();
/* 45 */                if (StringsKt.startsWith$default(token, "#", false, 2, (Object) null) || StringsKt.startsWith$default(token, "^", false, 2, (Object) null)) {
/* 46 */                    if (stack.size() >= 32) {
                                renderFormat$issue(issues, "template_depth", "Condition nesting exceeds 32");
                                return "";
                            }
/* 47 */                    String strSubstring4 = token.substring(1);
                            Intrinsics.checkNotNullExpressionValue(strSubstring4, "substring(...)");
                            String name = StringsKt.trim((CharSequence) strSubstring4).toString();
/* 48 */                    if (name.length() == 0) {
                                renderFormat$issue(issues, "template_block", "Empty section name");
                            }
/* 49 */                    Part.Section section = new Part.Section(name, token.charAt(0) == '^', null, 4);
/* 50 */                    renderFormat$destination(stack, root).add(section);
/* 51 */                    stack.addLast(section);
                        } else if (StringsKt.startsWith$default(token, "/", false, 2, (Object) null)) {
/* 54 */                    String strSubstring5 = token.substring(1);
                            Intrinsics.checkNotNullExpressionValue(strSubstring5, "substring(...)");
                            String name2 = StringsKt.trim((CharSequence) strSubstring5).toString();
/* 55 */                    Part.Section section2 = (Part.Section) stack.lastOrNull();
                            if (Intrinsics.areEqual(section2 != null ? section2.getName() : null, name2)) {
/* 56 */                        stack.removeLast();
                            } else {
                                renderFormat$issue(issues, "template_block", "Mismatched section close: " + name2);
                            }
                        } else {
/* 58 */                    if (token.length() == 0) {
                                renderFormat$issue(issues, "template_block", "Empty template token");
                            } else {
/* 60 */                        if (StringsKt.contains$default((CharSequence) token, AbstractJsonLexerKt.COLON, false, 2, (Object) null)) {
/* 61 */                            String filter = StringsKt.substringBefore$default(token, AbstractJsonLexerKt.COLON, (String) null, 2, (Object) null);
/* 62 */                            if (!SetsKt.setOf((Object[]) new String[]{"text", "hint", "cloze"}).contains(filter) || StringsKt.contains$default((CharSequence) StringsKt.substringAfter$default(token, AbstractJsonLexerKt.COLON, (String) null, 2, (Object) null), AbstractJsonLexerKt.COLON, false, 2, (Object) null) || (Intrinsics.areEqual(filter, "cloze") && kind != 1)) {
/* 63 */                                renderFormat$issue(issues, "unsupported_filter", "Unsupported template filter: " + token);
                                    }
                                }
/* 65 */                        renderFormat$destination(stack, root).add(new Part.Field(token));
                            }
                        }
/* 68 */                start = close + 2;
                    }
/* 70 */            if (!stack.isEmpty()) {
                        renderFormat$issue(issues, "template_block", "Unclosed section: " + ((Part.Section) stack.last()).getName());
                    }
/* 71 */            BoundedHtml output = new BoundedHtml();
/* 72 */            Ref.BooleanRef foundTargetCloze = new Ref.BooleanRef();
                    try {
/* 110 */               renderFormat$renderParts(output, kind, ordinal, side, foundTargetCloze, context, frontSide, values, issues, root);
                    } catch (RenderLimitException e) {
                        renderFormat$issue(issues, "render_limit", "Rendered side exceeds 4 MiB");
                    }
/* 112 */           if (kind == 1 && side == CardSide.QUESTION && !foundTargetCloze.element) {
                        renderFormat$issue(issues, "cloze_missing", "No cloze c" + (ordinal + 1) + " for saved card");
                    }
/* 113 */           return output.toString();
                }

/* 34 */        private static final List<Part> renderFormat$destination(ArrayDeque<Part.Section> arrayDeque, List<Part> list) {
                    List<Part> children;
/* 35 */            Part.Section sectionLastOrNull = arrayDeque.lastOrNull();
                    return (sectionLastOrNull == null || (children = sectionLastOrNull.getChildren()) == null) ? list : children;
                }

                /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
/* 72 */        private static final String renderFormat$value(TemplateContext $context, CardSide $side, String $frontSide, Map<String, String> map, String name) {
                    switch (name.hashCode()) {
                        case -203410743:
/* 73 */                    if (name.equals("Subdeck")) {
/* 75 */                        return StringsKt.substringAfterLast$default($context.getDeckFullName(), "::", (String) null, 2, (Object) null);
                            }
                            break;
                        case 2092848:
/* 73 */                    if (name.equals("Card")) {
/* 76 */                        return $context.getCardName();
                            }
                            break;
                        case 2126025:
/* 73 */                    if (name.equals("Deck")) {
/* 74 */                        return $context.getDeckFullName();
                            }
                            break;
                        case 2598969:
/* 73 */                    if (name.equals("Tags")) {
/* 77 */                        return CollectionsKt.joinToString$default($context.getTags(), " ", null, null, 0, null, null, 62, null);
                            }
                            break;
                        case 2622298:
/* 73 */                    if (name.equals("Type")) {
/* 78 */                        return $context.getTypeName();
                            }
                            break;
                        case 2131694336:
                            if (name.equals("FrontSide")) {
/* 79 */                        if ($side == CardSide.ANSWER) {
                                    return $frontSide;
                                }
                                return null;
                            }
                            break;
                    }
/* 80 */            return map.get(name);
                }

                /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
/* 82 */        private static final void renderFormat$renderParts(BoundedHtml output, int $kind, int $ordinal, CardSide $side, Ref.BooleanRef foundTargetCloze, TemplateContext $context, String $frontSide, Map<String, String> map, List<RenderIssue> list, List<? extends Part> list2) {
                    String strText;
                    Iterator<? extends Part> it = list2.iterator();
                    while (it.hasNext()) {
                        Part part = it.next();
/* 85 */                if (part instanceof Part.Text) {
/* 83 */                    output.append(((Part.Text) part).getValue());
                        } else {
                            boolean z = false;
/* 86 */                    if (part instanceof Part.Section) {
/* 87 */                        String condition = renderFormat$value($context, $side, $frontSide, map, ((Part.Section) part).getName());
/* 88 */                        if (condition == null) {
                                    renderFormat$issue(list, "missing_field", "Unknown section field: " + ((Part.Section) part).getName());
                                }
/* 89 */                        if (condition != null && (!StringsKt.isBlank(condition))) {
                                    z = true;
                                }
                                if (z != ((Part.Section) part).getInverted()) {
/* 83 */                            renderFormat$renderParts(output, $kind, $ordinal, $side, foundTargetCloze, $context, $frontSide, map, list, ((Part.Section) part).getChildren());
                                }
                            } else {
                                if (!(part instanceof Part.Field)) {
/* 84 */                            throw new NoWhenBranchMatchedException();
                                }
/* 92 */                        List split = StringsKt.split$default((CharSequence) ((Part.Field) part).getName(), new char[]{AbstractJsonLexerKt.COLON}, false, 2, 2, (Object) null);
/* 93 */                        String filter = split.size() == 2 ? (String) split.get(0) : "";
/* 94 */                        String name = split.size() == 2 ? (String) split.get(1) : (String) split.get(0);
                                Iterator<? extends Part> it2 = it;
/* 95 */                        if (!SetsKt.setOf((Object[]) new String[]{"", "text", "hint", "cloze"}).contains(filter)) {
                                    it = it2;
                                } else if (Intrinsics.areEqual(filter, "cloze") && $kind != 1) {
                                    it = it2;
                                } else if (StringsKt.contains$default((CharSequence) name, AbstractJsonLexerKt.COLON, false, 2, (Object) null)) {
                                    it = it2;
                                } else {
/* 96 */                            String field = renderFormat$value($context, $side, $frontSide, map, name);
/* 97 */                            if (field == null) {
                                        renderFormat$issue(list, "missing_field", "Unknown template field: " + name);
                                        it = it2;
                                    } else if ($kind != 1 || Intrinsics.areEqual(filter, "cloze") || !StringsKt.contains$default((CharSequence) field, (CharSequence) "{{c", false, 2, (Object) null)) {
/* 99 */                                boolean helper = SetsKt.setOf((Object[]) new String[]{"Deck", "Subdeck", "Card", "Tags", "Type"}).contains(name);
                                        switch (filter.hashCode()) {
                                            case 0:
                                                if (!filter.equals("")) {
                                                    it = it2;
                                                } else {
/* 83 */                                            output.append(helper ? INSTANCE.escape(field) : field);
                                                    it = it2;
                                                }
                                                break;
                                            case 3202695:
                                                if (!filter.equals("hint")) {
                                                    it = it2;
                                                } else {
/* 103 */                                           if (!StringsKt.isBlank(field)) {
/* 83 */                                                output.append("<details><summary>提示</summary>");
/* 83 */                                                output.append(helper ? INSTANCE.escape(field) : field);
/* 83 */                                                output.append("</details>");
                                                    }
                                                    it = it2;
                                                }
                                                break;
                                            case 3556653:
/* 95 */                                        if (!filter.equals("text")) {
                                                    it = it2;
                                                } else {
/* 102 */                                           Companion companion = INSTANCE;
                                                    if (helper) {
                                                        strText = field;
                                                    } else {
                                                        strText = Jsoup.parseBodyFragment(field).text();
                                                        Intrinsics.checkNotNullExpressionValue(strText, "text(...)");
                                                    }
/* 83 */                                            output.append(companion.escape(strText));
                                                    it = it2;
                                                }
                                                break;
                                            case 94756561:
                                                if (!filter.equals("cloze")) {
                                                    it = it2;
                                                } else if (!output.appendCloze(field, $ordinal + 1, $side, new AnkiTemplateRenderer$renderFormat$renderParts$1(list))) {
                                                    it = it2;
                                                } else {
                                                    foundTargetCloze.element = true;
/* 104 */                                           it = it2;
                                                }
                                                break;
                                            default:
/* 104 */                                       it = it2;
                                                break;
                                        }
                                    } else {
                                        renderFormat$issue(list, "unsupported_filter", "Raw cloze field would expose hidden answer");
                                        it = it2;
                                    }
                                }
                            }
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\fJ\b\u0010\r\u001a\u00020\fH\u0016J8\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\b2\u0006\u0010\u0012\u001a\u00020\u00132\u0018\u0010\u0014\u001a\u0014\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\n0\u0015R\u0012\u0010\u0004\u001a\u00060\u0005j\u0002`\u0006X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0016"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$BoundedHtml;", "", "<init>", "()V", "text", "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "bytes", "", "append", "", "value", "", "toString", "appendCloze", "", "source", "target", "side", "Lcom/xunji/core/anki/CardSide;", "issue", "Lkotlin/Function2;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 119 */       static final class BoundedHtml {
                    private int bytes;
                    private final StringBuilder text = new StringBuilder();

/* 120 */           public final void append(String value) {
                        Intrinsics.checkNotNullParameter(value, "value");
/* 121 */               int size = AnkiStorageValidator.INSTANCE.utf8Bytes(value);
                        if (((long) this.bytes) + ((long) size) > 4194304) {
/* 122 */                   throw new RenderLimitException();
                        }
/* 123 */               this.text.append(value);
                        this.bytes += size;
                    }

/* 124 */           public String toString() {
/* 125 */               String string = this.text.toString();
                        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                        return string;
                    }

/* 126 */           public final boolean appendCloze(String source, int target, CardSide side, final Function2<? super String, ? super String, Unit> issue) {
                        Intrinsics.checkNotNullParameter(source, "source");
                        Intrinsics.checkNotNullParameter(side, "side");
                        Intrinsics.checkNotNullParameter(issue, "issue");
/* 127 */               final Ref.BooleanRef invalid = new Ref.BooleanRef();
/* 128 */               ClozeParser parser = new ClozeParser(source, new Function2() { // from class: com.xunji.core.anki.AnkiTemplateRenderer$BoundedHtml$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return AnkiTemplateRenderer.BoundedHtml.appendCloze$lambda$0(invalid, issue, (String) obj, (String) obj2);
                            }
                        });
/* 129 */               List<ClozePart> list = parser.parse();
/* 130 */               if (invalid.element) {
                            return false;
                        }
/* 143 */               appendCloze$write(this, side, target, list);
/* 144 */               return parser.getNumbers().contains(Integer.valueOf(target));
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 127 */           public static final Unit appendCloze$lambda$0(Ref.BooleanRef $invalid, Function2 $issue, String code, String detail) {
                        Intrinsics.checkNotNullParameter(code, "code");
                        Intrinsics.checkNotNullParameter(detail, "detail");
/* 128 */               $invalid.element = true;
                        $issue.invoke(code, detail);
                        return Unit.INSTANCE;
                    }

/* 131 */           private static final void appendCloze$write(BoundedHtml this$0, CardSide $side, int $target, List<? extends ClozePart> list) {
/* 132 */               List<? extends ClozePart> $this$forEach$iv = list;
                        for (Object element$iv : $this$forEach$iv) {
                            ClozePart part = (ClozePart) element$iv;
/* 133 */                   if (part instanceof ClozePart.Text) {
                                this$0.append(((ClozePart.Text) part).getValue());
                            } else {
/* 134 */                       if (!(part instanceof ClozePart.Deletion)) {
/* 132 */                           throw new NoWhenBranchMatchedException();
                                }
/* 135 */                       if ($side == CardSide.QUESTION && ((ClozePart.Deletion) part).getNumber() == $target) {
/* 136 */                           this$0.append("<span class=\"cloze\">[");
                                    Companion companion = AnkiTemplateRenderer.INSTANCE;
                                    String hint = ((ClozePart.Deletion) part).getHint();
                                    if (hint == null) {
                                        hint = "...";
                                    }
/* 196 */                           this$0.append(companion.escape(hint));
                                    this$0.append("]</span>");
                                } else if ($side == CardSide.ANSWER && ((ClozePart.Deletion) part).getNumber() == $target) {
/* 138 */                           this$0.append("<span class=\"cloze\">");
                                    appendCloze$write(this$0, $side, $target, ((ClozePart.Deletion) part).getContent());
                                    this$0.append("</span>");
                                } else {
/* 139 */                           appendCloze$write(this$0, $side, $target, ((ClozePart.Deletion) part).getContent());
                                }
                            }
                        }
                    }
                }

                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\br\u0018\u00002\u00020\u0001:\u0002\u0002\u0003\u0082\u0001\u0002\u0004\u0005¨\u0006\u0006À\u0006\u0003"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart;", "", "Text", "Deletion", "Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart$Deletion;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart$Text;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 146 */       private interface ClozePart {

                    /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart$Text;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart;", "value", "", "<init>", "(Ljava/lang/String;)V", "getValue", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 147 */           public static final /* data */ class Text implements ClozePart {
                        private final String value;

                        public static /* synthetic */ Text copy$default(Text text, String str, int i, Object obj) {
                            if ((i & 1) != 0) {
                                str = text.value;
                            }
                            return text.copy(str);
                        }

                        /* JADX INFO: renamed from: component1, reason: from getter */
                        public final String getValue() {
                            return this.value;
                        }

                        public final Text copy(String value) {
                            Intrinsics.checkNotNullParameter(value, "value");
                            return new Text(value);
                        }

                        public boolean equals(Object other) {
                            if (this == other) {
                                return true;
                            }
                            return (other instanceof Text) && Intrinsics.areEqual(this.value, ((Text) other).value);
                        }

                        public int hashCode() {
                            return this.value.hashCode();
                        }

                        public String toString() {
                            return "Text(value=" + this.value + ")";
                        }

/* 148 */               public Text(String value) {
                            Intrinsics.checkNotNullParameter(value, "value");
                            this.value = value;
                        }

/* 148 */               public final String getValue() {
/* 149 */                   return this.value;
                        }
                    }

                    /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00010\u0005HÆ\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0007HÆ\u0003J/\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0007HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart$Deletion;", "Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart;", "number", "", "content", "", "hint", "", "<init>", "(ILjava/util/List;Ljava/lang/String;)V", "getNumber", "()I", "getContent", "()Ljava/util/List;", "getHint", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 148 */           public static final /* data */ class Deletion implements ClozePart {
                        private final List<ClozePart> content;
                        private final String hint;
                        private final int number;

                        /* JADX WARN: Multi-variable type inference failed */
                        public static /* synthetic */ Deletion copy$default(Deletion deletion, int i, List list, String str, int i2, Object obj) {
                            if ((i2 & 1) != 0) {
                                i = deletion.number;
                            }
                            if ((i2 & 2) != 0) {
                                list = deletion.content;
                            }
                            if ((i2 & 4) != 0) {
                                str = deletion.hint;
                            }
                            return deletion.copy(i, list, str);
                        }

                        /* JADX INFO: renamed from: component1, reason: from getter */
                        public final int getNumber() {
                            return this.number;
                        }

                        public final List<ClozePart> component2() {
                            return this.content;
                        }

                        /* JADX INFO: renamed from: component3, reason: from getter */
                        public final String getHint() {
                            return this.hint;
                        }

                        public final Deletion copy(int number, List<? extends ClozePart> content, String hint) {
                            Intrinsics.checkNotNullParameter(content, "content");
                            return new Deletion(number, content, hint);
                        }

                        public boolean equals(Object other) {
                            if (this == other) {
                                return true;
                            }
                            if (!(other instanceof Deletion)) {
                                return false;
                            }
                            Deletion deletion = (Deletion) other;
                            return this.number == deletion.number && Intrinsics.areEqual(this.content, deletion.content) && Intrinsics.areEqual(this.hint, deletion.hint);
                        }

                        public int hashCode() {
                            return (((Integer.hashCode(this.number) * 31) + this.content.hashCode()) * 31) + (this.hint == null ? 0 : this.hint.hashCode());
                        }

                        public String toString() {
                            return "Deletion(number=" + this.number + ", content=" + this.content + ", hint=" + this.hint + ")";
                        }

                        /* JADX WARN: Multi-variable type inference failed */
/* 149 */               public Deletion(int number, List<? extends ClozePart> content, String hint) {
                            Intrinsics.checkNotNullParameter(content, "content");
                            this.number = number;
                            this.content = content;
                            this.hint = hint;
                        }

/* 149 */               public final List<ClozePart> getContent() {
/* 150 */                   return this.content;
                        }

/* 149 */               public final String getHint() {
/* 150 */                   return this.hint;
                        }

/* 149 */               public final int getNumber() {
/* 150 */                   return this.number;
                        }
                    }
                }

                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010#\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\b\u0002\u0018\u00002\u00020\u0001B)\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0018\u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014J,\u0010\u0016\u001a\u0016\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00150\u0014\u0012\u0006\u0012\u0004\u0018\u00010\u00030\u00172\u0006\u0010\u0018\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\u001aH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R \u0010\u0004\u001a\u0014\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\t\u001a\u00020\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000eR\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\n0\u0010¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u001b"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozeParser;", "", "source", "", "issue", "Lkotlin/Function2;", "", "<init>", "(Ljava/lang/String;Lkotlin/jvm/functions/Function2;)V", "position", "", "getPosition", "()I", "setPosition", "(I)V", "numbers", "", "getNumbers", "()Ljava/util/Set;", "parse", "", "Lcom/xunji/core/anki/AnkiTemplateRenderer$ClozePart;", "read", "Lkotlin/Pair;", "depth", "nested", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 150 */       private static final class ClozeParser {
                    private final Function2<String, String, Unit> issue;
                    private final Set<Integer> numbers;
                    private int position;
                    private final String source;

                    /* JADX WARN: Multi-variable type inference failed */
/* 151 */           public ClozeParser(String source, Function2<? super String, ? super String, Unit> issue) {
                        Intrinsics.checkNotNullParameter(source, "source");
                        Intrinsics.checkNotNullParameter(issue, "issue");
                        this.source = source;
                        this.issue = issue;
/* 154 */               this.numbers = new LinkedHashSet();
                    }

/* 152 */           public final int getPosition() {
/* 153 */               return this.position;
                    }

/* 152 */           public final void setPosition(int i) {
/* 153 */               this.position = i;
                    }

/* 153 */           public final Set<Integer> getNumbers() {
/* 154 */               return this.numbers;
                    }

/* 154 */           public final List<ClozePart> parse() {
/* 155 */               return read(0, false).getFirst();
                    }

/* 156 */           private final Pair<List<ClozePart>, String> read(int depth, boolean nested) {
                        List parts = new ArrayList();
/* 158 */               int textStart = this.position;
                        while (true) {
                            String hint = null;
/* 157 */                   if (this.position >= this.source.length()) {
                                break;
                            }
/* 160 */                   if (!nested || (!StringsKt.startsWith$default(this.source, "}}", this.position, false, 4, (Object) null) && !StringsKt.startsWith$default(this.source, "::", this.position, false, 4, (Object) null))) {
/* 157 */                       if (!StringsKt.startsWith$default(this.source, "{{c", this.position, false, 4, (Object) null)) {
/* 157 */                           this.position++;
                                } else {
/* 171 */                           int numberStart = this.position + 3;
/* 172 */                           int numberEnd = numberStart;
/* 173 */                           while (numberEnd < this.source.length() && Character.isDigit(this.source.charAt(numberEnd))) {
                                        numberEnd++;
                                    }
/* 174 */                           if (numberEnd == numberStart || !StringsKt.startsWith$default(this.source, "::", numberEnd, false, 4, (Object) null)) {
/* 175 */                               invoke("cloze_syntax", "Unsupported cloze syntax");
/* 157 */                               this.position += 3;
                                    } else {
/* 179 */                               if (depth >= 3) {
/* 157 */                                   invoke("cloze_depth", "Cloze nesting exceeds 3");
/* 157 */                                   this.position = this.source.length();
                                            break;
                                        }
/* 180 */                               String strSubstring = this.source.substring(numberStart, numberEnd);
                                        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                                        Integer number = StringsKt.toIntOrNull(strSubstring);
/* 181 */                               if (number == null || number.intValue() <= 0) {
/* 181 */                                   invoke("cloze_syntax", "Invalid cloze number");
/* 157 */                                   this.position = numberEnd + 2;
                                        } else {
/* 182 */                                   if (this.position > textStart) {
/* 157 */                                       String strSubstring2 = this.source.substring(textStart, this.position);
                                                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                                                parts.add(new ClozePart.Text(strSubstring2));
                                            }
/* 183 */                                   this.numbers.add(number);
/* 157 */                                   this.position = numberEnd + 2;
/* 157 */                                   Pair<List<ClozePart>, String> pair = read(depth + 1, true);
/* 186 */                                   parts.add(new ClozePart.Deletion(number.intValue(), pair.component1(), pair.component2()));
/* 187 */                                   textStart = this.position;
                                        }
                                    }
                                }
                            } else {
/* 161 */                       if (this.position > textStart) {
/* 157 */                           String strSubstring3 = this.source.substring(textStart, this.position);
                                    Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                                    parts.add(new ClozePart.Text(strSubstring3));
                                }
/* 157 */                       if (StringsKt.startsWith$default(this.source, "::", this.position, false, 4, (Object) null)) {
/* 157 */                           this.position += 2;
/* 157 */                           int end = StringsKt.indexOf$default((CharSequence) this.source, "}}", this.position, false, 4, (Object) null);
/* 165 */                           if (end < 0) {
/* 157 */                               invoke("cloze_syntax", "Unclosed cloze hint");
/* 157 */                               this.position = this.source.length();
                                    } else {
/* 157 */                               hint = this.source.substring(this.position, end);
                                        Intrinsics.checkNotNullExpressionValue(hint, "substring(...)");
/* 157 */                               this.position = end + 2;
                                    }
                                } else {
/* 157 */                           this.position += 2;
                                }
/* 168 */                       return TuplesKt.to(parts, hint);
                            }
                        }
/* 190 */               if (this.position > textStart) {
/* 157 */                   String strSubstring4 = this.source.substring(textStart, this.position);
                            Intrinsics.checkNotNullExpressionValue(strSubstring4, "substring(...)");
                            parts.add(new ClozePart.Text(strSubstring4));
                        }
/* 191 */               if (nested) {
/* 157 */                   invoke("cloze_syntax", "Unclosed cloze deletion");
                        }
/* 192 */               return TuplesKt.to(parts, null);
                    }
                }

                /* JADX INFO: compiled from: AnkiTemplateRenderer.kt */
                @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H\u0002¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/anki/AnkiTemplateRenderer$Companion;", "", "<init>", "()V", "escape", "", "value", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 194 */       public static final class Companion {
/* 195 */           private Companion() {
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 196 */           public final String escape(String value) {
/* 197 */               return StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(value, "&", "&amp;", false, 4, (Object) null), "<", "&lt;", false, 4, (Object) null), ">", "&gt;", false, 4, (Object) null), "\"", "&quot;", false, 4, (Object) null);
                    }
                }
            }

            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010\u000f\u001a\u0004\u0018\u00010\u0003HÆ\u0003¢\u0006\u0002\u0010\nJ\t\u0010\u0010\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J.\u0010\u0012\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0005HÆ\u0001¢\u0006\u0002\u0010\u0013J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0005HÖ\u0001R\u0015\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\n\n\u0002\u0010\u000b\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\r¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/anki/ImportIssue;", "", "cardId", "", "code", "", "detail", "<init>", "(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;)V", "getCardId", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getCode", "()Ljava/lang/String;", "getDetail", "component1", "component2", "component3", "copy", "(Ljava/lang/Long;Ljava/lang/String;Ljava/lang/String;)Lcom/xunji/core/anki/ImportIssue;", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 15 */    public final /* data */ class ImportIssue {
                private final Long cardId;
                private final String code;
                private final String detail;

                public static /* synthetic */ ImportIssue copy$default(ImportIssue importIssue, Long l, String str, String str2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        l = importIssue.cardId;
                    }
                    if ((i & 2) != 0) {
                        str = importIssue.code;
                    }
                    if ((i & 4) != 0) {
                        str2 = importIssue.detail;
                    }
                    return importIssue.copy(l, str, str2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final Long getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getCode() {
                    return this.code;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getDetail() {
                    return this.detail;
                }

                public final ImportIssue copy(Long cardId, String code, String detail) {
                    Intrinsics.checkNotNullParameter(code, "code");
                    Intrinsics.checkNotNullParameter(detail, "detail");
                    return new ImportIssue(cardId, code, detail);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ImportIssue)) {
                        return false;
                    }
                    ImportIssue importIssue = (ImportIssue) other;
                    return Intrinsics.areEqual(this.cardId, importIssue.cardId) && Intrinsics.areEqual(this.code, importIssue.code) && Intrinsics.areEqual(this.detail, importIssue.detail);
                }

                public int hashCode() {
                    return ((((this.cardId == null ? 0 : this.cardId.hashCode()) * 31) + this.code.hashCode()) * 31) + this.detail.hashCode();
                }

                public String toString() {
                    return "ImportIssue(cardId=" + this.cardId + ", code=" + this.code + ", detail=" + this.detail + ")";
                }

/* 16 */        public ImportIssue(Long cardId, String code, String detail) {
                    Intrinsics.checkNotNullParameter(code, "code");
                    Intrinsics.checkNotNullParameter(detail, "detail");
                    this.cardId = cardId;
                    this.code = code;
                    this.detail = detail;
                }

/* 16 */        public final Long getCardId() {
/* 17 */            return this.cardId;
                }

/* 16 */        public final String getCode() {
/* 17 */            return this.code;
                }

/* 16 */        public final String getDetail() {
/* 17 */            return this.detail;
                }
            }

            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0005HÆ\u0003¢\u0006\u0002\u0010\u000eJ.\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005HÆ\u0001¢\u0006\u0002\u0010\u0014J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u0005¢\u0006\n\n\u0002\u0010\u000f\u001a\u0004\b\r\u0010\u000e¨\u0006\u001c"}, d2 = {"Lcom/xunji/core/anki/ImportProgress;", "", "stage", "Lcom/xunji/core/anki/ImportStage;", "completed", "", "total", "<init>", "(Lcom/xunji/core/anki/ImportStage;JLjava/lang/Long;)V", "getStage", "()Lcom/xunji/core/anki/ImportStage;", "getCompleted", "()J", "getTotal", "()Ljava/lang/Long;", "Ljava/lang/Long;", "component1", "component2", "component3", "copy", "(Lcom/xunji/core/anki/ImportStage;JLjava/lang/Long;)Lcom/xunji/core/anki/ImportProgress;", "equals", "", "other", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 17 */    public final /* data */ class ImportProgress {
                private final long completed;
                private final ImportStage stage;
                private final Long total;

                public static /* synthetic */ ImportProgress copy$default(ImportProgress importProgress, ImportStage importStage, long j, Long l, int i, Object obj) {
                    if ((i & 1) != 0) {
                        importStage = importProgress.stage;
                    }
                    if ((i & 2) != 0) {
                        j = importProgress.completed;
                    }
                    if ((i & 4) != 0) {
                        l = importProgress.total;
                    }
                    return importProgress.copy(importStage, j, l);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final ImportStage getStage() {
                    return this.stage;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final long getCompleted() {
                    return this.completed;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final Long getTotal() {
                    return this.total;
                }

                public final ImportProgress copy(ImportStage stage, long completed, Long total) {
                    Intrinsics.checkNotNullParameter(stage, "stage");
                    return new ImportProgress(stage, completed, total);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ImportProgress)) {
                        return false;
                    }
                    ImportProgress importProgress = (ImportProgress) other;
                    return this.stage == importProgress.stage && this.completed == importProgress.completed && Intrinsics.areEqual(this.total, importProgress.total);
                }

                public int hashCode() {
                    return (((this.stage.hashCode() * 31) + Long.hashCode(this.completed)) * 31) + (this.total == null ? 0 : this.total.hashCode());
                }

                public String toString() {
                    return "ImportProgress(stage=" + this.stage + ", completed=" + this.completed + ", total=" + this.total + ")";
                }

/* 18 */        public ImportProgress(ImportStage stage, long completed, Long total) {
                    Intrinsics.checkNotNullParameter(stage, "stage");
                    this.stage = stage;
                    this.completed = completed;
                    this.total = total;
                }

/* 18 */        public final long getCompleted() {
/* 19 */            return this.completed;
                }

/* 18 */        public final ImportStage getStage() {
/* 19 */            return this.stage;
                }

/* 18 */        public final Long getTotal() {
/* 19 */            return this.total;
                }
            }

            package com.xunji.core.anki;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0013"}, d2 = {"Lcom/xunji/core/anki/RenderIssue;", "", "code", "", "detail", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "getCode", "()Ljava/lang/String;", "getDetail", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 21 */    public final /* data */ class RenderIssue {
                private final String code;
                private final String detail;

                public static /* synthetic */ RenderIssue copy$default(RenderIssue renderIssue, String str, String str2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = renderIssue.code;
                    }
                    if ((i & 2) != 0) {
                        str2 = renderIssue.detail;
                    }
                    return renderIssue.copy(str, str2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCode() {
                    return this.code;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getDetail() {
                    return this.detail;
                }

                public final RenderIssue copy(String code, String detail) {
                    Intrinsics.checkNotNullParameter(code, "code");
                    Intrinsics.checkNotNullParameter(detail, "detail");
                    return new RenderIssue(code, detail);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof RenderIssue)) {
                        return false;
                    }
                    RenderIssue renderIssue = (RenderIssue) other;
                    return Intrinsics.areEqual(this.code, renderIssue.code) && Intrinsics.areEqual(this.detail, renderIssue.detail);
                }

                public int hashCode() {
                    return (this.code.hashCode() * 31) + this.detail.hashCode();
                }

                public String toString() {
                    return "RenderIssue(code=" + this.code + ", detail=" + this.detail + ")";
                }

/* 22 */        public RenderIssue(String code, String detail) {
                    Intrinsics.checkNotNullParameter(code, "code");
                    Intrinsics.checkNotNullParameter(detail, "detail");
                    this.code = code;
                    this.detail = detail;
                }

/* 22 */        public final String getCode() {
/* 23 */            return this.code;
                }

/* 22 */        public final String getDetail() {
/* 23 */            return this.detail;
                }
            }

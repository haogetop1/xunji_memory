            package com.xunji.core.anki;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B9\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0003J\u000f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0003J\u000f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\b0\u0005HÆ\u0003JC\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00030\u00052\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001J\t\u0010\u001b\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000e¨\u0006\u001c"}, d2 = {"Lcom/xunji/core/anki/RenderedSide;", "", "html", "", "audioNames", "", "resourceNames", "issues", "Lcom/xunji/core/anki/RenderIssue;", "<init>", "(Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;)V", "getHtml", "()Ljava/lang/String;", "getAudioNames", "()Ljava/util/List;", "getResourceNames", "getIssues", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 22 */    public final /* data */ class RenderedSide {
                private final List<String> audioNames;
                private final String html;
                private final List<RenderIssue> issues;
                private final List<String> resourceNames;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ RenderedSide copy$default(RenderedSide renderedSide, String str, List list, List list2, List list3, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = renderedSide.html;
                    }
                    if ((i & 2) != 0) {
                        list = renderedSide.audioNames;
                    }
                    if ((i & 4) != 0) {
                        list2 = renderedSide.resourceNames;
                    }
                    if ((i & 8) != 0) {
                        list3 = renderedSide.issues;
                    }
                    return renderedSide.copy(str, list, list2, list3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getHtml() {
                    return this.html;
                }

                public final List<String> component2() {
                    return this.audioNames;
                }

                public final List<String> component3() {
                    return this.resourceNames;
                }

                public final List<RenderIssue> component4() {
                    return this.issues;
                }

                public final RenderedSide copy(String html, List<String> audioNames, List<String> resourceNames, List<RenderIssue> issues) {
                    Intrinsics.checkNotNullParameter(html, "html");
                    Intrinsics.checkNotNullParameter(audioNames, "audioNames");
                    Intrinsics.checkNotNullParameter(resourceNames, "resourceNames");
                    Intrinsics.checkNotNullParameter(issues, "issues");
                    return new RenderedSide(html, audioNames, resourceNames, issues);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof RenderedSide)) {
                        return false;
                    }
                    RenderedSide renderedSide = (RenderedSide) other;
                    return Intrinsics.areEqual(this.html, renderedSide.html) && Intrinsics.areEqual(this.audioNames, renderedSide.audioNames) && Intrinsics.areEqual(this.resourceNames, renderedSide.resourceNames) && Intrinsics.areEqual(this.issues, renderedSide.issues);
                }

                public int hashCode() {
                    return (((((this.html.hashCode() * 31) + this.audioNames.hashCode()) * 31) + this.resourceNames.hashCode()) * 31) + this.issues.hashCode();
                }

                public String toString() {
                    return "RenderedSide(html=" + this.html + ", audioNames=" + this.audioNames + ", resourceNames=" + this.resourceNames + ", issues=" + this.issues + ")";
                }

/* 23 */        public RenderedSide(String html, List<String> audioNames, List<String> resourceNames, List<RenderIssue> issues) {
                    Intrinsics.checkNotNullParameter(html, "html");
                    Intrinsics.checkNotNullParameter(audioNames, "audioNames");
                    Intrinsics.checkNotNullParameter(resourceNames, "resourceNames");
                    Intrinsics.checkNotNullParameter(issues, "issues");
                    this.html = html;
                    this.audioNames = audioNames;
                    this.resourceNames = resourceNames;
                    this.issues = issues;
                }

/* 23 */        public final List<String> getAudioNames() {
/* 24 */            return this.audioNames;
                }

/* 23 */        public final String getHtml() {
/* 24 */            return this.html;
                }

/* 23 */        public final List<RenderIssue> getIssues() {
/* 24 */            return this.issues;
                }

/* 23 */        public final List<String> getResourceNames() {
/* 24 */            return this.resourceNames;
                }
            }

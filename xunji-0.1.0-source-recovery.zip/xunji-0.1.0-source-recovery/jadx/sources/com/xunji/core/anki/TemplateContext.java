            package com.xunji.core.anki;

            import java.util.List;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\"\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\t¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00030\u0006HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00030\tHÆ\u0003JG\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\u000e\b\u0002\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00032\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\tHÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0017\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\rR\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00030\t¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013¨\u0006 "}, d2 = {"Lcom/xunji/core/anki/TemplateContext;", "", "deckFullName", "", "cardName", "tags", "", "typeName", "mediaNames", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;Ljava/lang/String;Ljava/util/Set;)V", "getDeckFullName", "()Ljava/lang/String;", "getCardName", "getTags", "()Ljava/util/List;", "getTypeName", "getMediaNames", "()Ljava/util/Set;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 20 */    public final /* data */ class TemplateContext {
                private final String cardName;
                private final String deckFullName;
                private final Set<String> mediaNames;
                private final List<String> tags;
                private final String typeName;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ TemplateContext copy$default(TemplateContext templateContext, String str, String str2, List list, String str3, Set set, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = templateContext.deckFullName;
                    }
                    if ((i & 2) != 0) {
                        str2 = templateContext.cardName;
                    }
                    if ((i & 4) != 0) {
                        list = templateContext.tags;
                    }
                    if ((i & 8) != 0) {
                        str3 = templateContext.typeName;
                    }
                    if ((i & 16) != 0) {
                        set = templateContext.mediaNames;
                    }
                    Set set2 = set;
                    List list2 = list;
                    return templateContext.copy(str, str2, list2, str3, set2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getDeckFullName() {
                    return this.deckFullName;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getCardName() {
                    return this.cardName;
                }

                public final List<String> component3() {
                    return this.tags;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getTypeName() {
                    return this.typeName;
                }

                public final Set<String> component5() {
                    return this.mediaNames;
                }

                public final TemplateContext copy(String deckFullName, String cardName, List<String> tags, String typeName, Set<String> mediaNames) {
                    Intrinsics.checkNotNullParameter(deckFullName, "deckFullName");
                    Intrinsics.checkNotNullParameter(cardName, "cardName");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    Intrinsics.checkNotNullParameter(typeName, "typeName");
                    Intrinsics.checkNotNullParameter(mediaNames, "mediaNames");
                    return new TemplateContext(deckFullName, cardName, tags, typeName, mediaNames);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof TemplateContext)) {
                        return false;
                    }
                    TemplateContext templateContext = (TemplateContext) other;
                    return Intrinsics.areEqual(this.deckFullName, templateContext.deckFullName) && Intrinsics.areEqual(this.cardName, templateContext.cardName) && Intrinsics.areEqual(this.tags, templateContext.tags) && Intrinsics.areEqual(this.typeName, templateContext.typeName) && Intrinsics.areEqual(this.mediaNames, templateContext.mediaNames);
                }

                public int hashCode() {
                    return (((((((this.deckFullName.hashCode() * 31) + this.cardName.hashCode()) * 31) + this.tags.hashCode()) * 31) + this.typeName.hashCode()) * 31) + this.mediaNames.hashCode();
                }

                public String toString() {
                    return "TemplateContext(deckFullName=" + this.deckFullName + ", cardName=" + this.cardName + ", tags=" + this.tags + ", typeName=" + this.typeName + ", mediaNames=" + this.mediaNames + ")";
                }

/* 21 */        public TemplateContext(String deckFullName, String cardName, List<String> tags, String typeName, Set<String> mediaNames) {
                    Intrinsics.checkNotNullParameter(deckFullName, "deckFullName");
                    Intrinsics.checkNotNullParameter(cardName, "cardName");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    Intrinsics.checkNotNullParameter(typeName, "typeName");
                    Intrinsics.checkNotNullParameter(mediaNames, "mediaNames");
                    this.deckFullName = deckFullName;
                    this.cardName = cardName;
                    this.tags = tags;
                    this.typeName = typeName;
                    this.mediaNames = mediaNames;
                }

/* 21 */        public final String getCardName() {
/* 22 */            return this.cardName;
                }

/* 21 */        public final String getDeckFullName() {
/* 22 */            return this.deckFullName;
                }

/* 21 */        public final Set<String> getMediaNames() {
/* 22 */            return this.mediaNames;
                }

/* 21 */        public final List<String> getTags() {
/* 22 */            return this.tags;
                }

/* 21 */        public final String getTypeName() {
/* 22 */            return this.typeName;
                }
            }

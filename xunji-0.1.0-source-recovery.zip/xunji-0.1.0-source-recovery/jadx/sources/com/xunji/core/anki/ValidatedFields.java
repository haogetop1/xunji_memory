            package com.xunji.core.anki;

            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiModels.kt */
            /* JADX INFO: loaded from: classes6.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B)\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0012\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003HÆ\u0003J\u0015\u0010\u000f\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0003J/\u0010\u0010\u001a\u00020\u00002\u000e\b\u0002\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0014\b\u0002\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006HÆ\u0001J\u0013\u0010\u0011\u001a\u00020\u00122\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0004HÖ\u0001R\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u001d\u0010\u0005\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00070\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u0017"}, d2 = {"Lcom/xunji/core/anki/ValidatedFields;", "", "fields", "", "", "previewsByCardId", "", "Lcom/xunji/core/anki/AnkiCardPreview;", "<init>", "(Ljava/util/List;Ljava/util/Map;)V", "getFields", "()Ljava/util/List;", "getPreviewsByCardId", "()Ljava/util/Map;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 27 */    public final /* data */ class ValidatedFields {
                private final List<String> fields;
                private final Map<String, AnkiCardPreview> previewsByCardId;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ ValidatedFields copy$default(ValidatedFields validatedFields, List list, Map map, int i, Object obj) {
                    if ((i & 1) != 0) {
                        list = validatedFields.fields;
                    }
                    if ((i & 2) != 0) {
                        map = validatedFields.previewsByCardId;
                    }
                    return validatedFields.copy(list, map);
                }

                public final List<String> component1() {
                    return this.fields;
                }

                public final Map<String, AnkiCardPreview> component2() {
                    return this.previewsByCardId;
                }

                public final ValidatedFields copy(List<String> fields, Map<String, AnkiCardPreview> previewsByCardId) {
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(previewsByCardId, "previewsByCardId");
                    return new ValidatedFields(fields, previewsByCardId);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ValidatedFields)) {
                        return false;
                    }
                    ValidatedFields validatedFields = (ValidatedFields) other;
                    return Intrinsics.areEqual(this.fields, validatedFields.fields) && Intrinsics.areEqual(this.previewsByCardId, validatedFields.previewsByCardId);
                }

                public int hashCode() {
                    return (this.fields.hashCode() * 31) + this.previewsByCardId.hashCode();
                }

                public String toString() {
                    return "ValidatedFields(fields=" + this.fields + ", previewsByCardId=" + this.previewsByCardId + ")";
                }

/* 28 */        public ValidatedFields(List<String> fields, Map<String, AnkiCardPreview> previewsByCardId) {
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(previewsByCardId, "previewsByCardId");
                    this.fields = fields;
                    this.previewsByCardId = previewsByCardId;
                }

/* 28 */        public final List<String> getFields() {
/* 29 */            return this.fields;
                }

/* 28 */        public final Map<String, AnkiCardPreview> getPreviewsByCardId() {
/* 29 */            return this.previewsByCardId;
                }
            }

            package com.xunji.core.backup;
            
            /* JADX INFO: compiled from: D8$$SyntheticClass */
            /* JADX INFO: loaded from: classes4.dex */
            public final /* synthetic */ class BackupCodec$$ExternalSyntheticBackport0 {
            }

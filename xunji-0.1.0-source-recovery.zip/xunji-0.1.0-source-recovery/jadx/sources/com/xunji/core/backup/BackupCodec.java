            package com.xunji.core.backup;

            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.Regex;
            import kotlinx.serialization.json.Json;
            import kotlinx.serialization.json.JsonBuilder;
            import kotlinx.serialization.json.JsonKt;
            
            /* JADX INFO: compiled from: BackupCodec.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0011\u001a\u00020\u0012J\u000e\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u000bJ\u000e\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u0017J\u000e\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0014\u001a\u00020\u000bJ\u000e\u0010\u0019\u001a\u00020\b2\u0006\u0010\u0016\u001a\u00020\u0017R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u000b0\n¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/backup/BackupCodec;", "", "<init>", "()V", "MAX_RECORD_BYTES", "", "MAX_MANIFEST_BYTES", "SAFETY_BYTES", "", "recordTypes", "", "", "getRecordTypes", "()Ljava/util/List;", "json", "Lkotlinx/serialization/json/Json;", "encode", "document", "Lcom/xunji/core/backup/BackupDocument;", "decode", "text", "encodeManifest", "manifest", "Lcom/xunji/core/backup/BackupManifest;", "decodeManifest", "requiredSpace", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final class BackupCodec {
                public static final int MAX_MANIFEST_BYTES = 1048576;
                public static final int MAX_RECORD_BYTES = 16777216;
                public static final long SAFETY_BYTES = 268435456;
                public static final BackupCodec INSTANCE = new BackupCodec();
                private static final List<String> recordTypes = CollectionsKt.listOf((Object[]) new String[]{"decks", "anki_models", "anki_notes", "cards", "schedules", "review_logs", "anki_deck_sources", "anki_media", "anki_cards", "settings"});
                private static final Json json = JsonKt.Json$default(null, new Function1() { // from class: com.xunji.core.backup.BackupCodec$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Object obj) {
                        return BackupCodec.json$lambda$0((JsonBuilder) obj);
                    }
                }, 1, null);

/* 5 */         private BackupCodec() {
                }

/* 9 */         public final List<String> getRecordTypes() {
/* 10 */            return recordTypes;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 10 */        public static final Unit json$lambda$0(JsonBuilder Json) {
                    Intrinsics.checkNotNullParameter(Json, "$this$Json");
/* 11 */            Json.setEncodeDefaults(true);
/* 11 */            Json.setPrettyPrint(true);
                    Json.setIgnoreUnknownKeys(false);
                    Json.setLenient(false);
                    Json.setAllowSpecialFloatingPointValues(false);
                    return Unit.INSTANCE;
                }

/* 11 */        public final String encode(BackupDocument document) {
                    Intrinsics.checkNotNullParameter(document, "document");
/* 12 */            BackupValidator.INSTANCE.validate(document);
                    Json this_$iv = json;
/* 27 */            this_$iv.getSerializersModule();
                    return this_$iv.encodeToString(BackupDocument.INSTANCE.serializer(), document);
                }

/* 12 */        public final BackupDocument decode(String text) {
                    Intrinsics.checkNotNullParameter(text, "text");
/* 13 */            Json this_$iv = json;
/* 28 */            this_$iv.getSerializersModule();
                    Object objDecodeFromString = this_$iv.decodeFromString(BackupDocument.INSTANCE.serializer(), text);
                    BackupDocument p0 = (BackupDocument) objDecodeFromString;
/* 13 */            BackupValidator.INSTANCE.validate(p0);
                    return (BackupDocument) objDecodeFromString;
                }

/* 13 */        public final String encodeManifest(BackupManifest manifest) {
                    Intrinsics.checkNotNullParameter(manifest, "manifest");
/* 14 */            Json this_$iv = json;
/* 30 */            this_$iv.getSerializersModule();
                    return this_$iv.encodeToString(BackupManifest.INSTANCE.serializer(), manifest);
                }

                /* JADX WARN: Code duplicated, block: B:33:0x00b3  */
/* 14 */        public final BackupManifest decodeManifest(String text) {
                    boolean z;
                    boolean z2;
                    Long l;
                    Intrinsics.checkNotNullParameter(text, "text");
/* 15 */            Json this_$iv = json;
/* 31 */            this_$iv.getSerializersModule();
                    Object objDecodeFromString = this_$iv.decodeFromString(BackupManifest.INSTANCE.serializer(), text);
/* 15 */            BackupManifest m = (BackupManifest) objDecodeFromString;
                    boolean z3 = false;
/* 16 */            if (!(Intrinsics.areEqual(m.getFormat(), "xunji-backup") && m.getSchemaVersion() == 2)) {
                        throw new IllegalArgumentException("不支持的备份格式或版本".toString());
                    }
/* 17 */            BackupValidator.INSTANCE.time(m.getExportedAt());
/* 18 */            if (Intrinsics.areEqual(m.getCounts().keySet(), CollectionsKt.toSet(recordTypes))) {
                        Iterable $this$all$iv = m.getCounts().values();
/* 32 */                if (!($this$all$iv instanceof Collection) || !((Collection) $this$all$iv).isEmpty()) {
/* 33 */                    Iterator it = $this$all$iv.iterator();
                            while (true) {
                                if (!it.hasNext()) {
/* 34 */                            z2 = true;
                                    break;
                                }
                                Object element$iv = it.next();
                                long it2 = ((Number) element$iv).longValue();
/* 33 */                        if (!(it2 >= 0)) {
                                    z2 = false;
                                    break;
                                }
                            }
                        } else {
                            z2 = true;
                        }
/* 18 */                if (z2 && (l = m.getCounts().get("settings")) != null && l.longValue() == 1) {
                            z = true;
                        } else {
                            z = false;
                        }
                    } else {
                        z = false;
                    }
                    if (!z) {
                        throw new IllegalArgumentException("Invalid backup record counts".toString());
                    }
                    if (m.getRecordsBytes() > 0 && m.getMediaCount() >= 0 && m.getMediaBytes() >= 0) {
                        if (new Regex("[0-9a-f]{64}").matches(m.getRecordsSha256())) {
                            z3 = true;
                        }
                    }
                    if (z3) {
/* 15 */                return (BackupManifest) objDecodeFromString;
                    }
                    throw new IllegalArgumentException("Invalid backup byte budget or digest".toString());
                }

/* 21 */        public final long requiredSpace(BackupManifest manifest) {
                    Intrinsics.checkNotNullParameter(manifest, "manifest");
/* 22 */            return Math.addExact(SAFETY_BYTES, Math.addExact(Math.addExact(Math.multiplyExact(manifest.getRecordsBytes(), 9L), Math.multiplyExact(manifest.getMediaBytes(), 2L)), Math.addExact(1048576L, Math.multiplyExact(Math.addExact(manifest.getMediaCount(), 2L), 256L))));
                }
            }

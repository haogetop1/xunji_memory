            package com.xunji.core.backup;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.AppSettings$$serializer;
            import java.util.List;
            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Lazy;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.DeserializationStrategy;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: BackupDocument.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/backup/BackupDocument.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/backup/BackupDocument;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 4 */     public final /* synthetic */ class BackupDocument$$serializer implements GeneratedSerializer<BackupDocument> {
                public static final BackupDocument$$serializer INSTANCE = new BackupDocument$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 6 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.backup.BackupDocument", INSTANCE, 8);
                    pluginGeneratedSerialDescriptor.addElement("format", true);
                    pluginGeneratedSerialDescriptor.addElement("schemaVersion", true);
                    pluginGeneratedSerialDescriptor.addElement("exportedAt", false);
                    pluginGeneratedSerialDescriptor.addElement("decks", false);
                    pluginGeneratedSerialDescriptor.addElement("cards", false);
                    pluginGeneratedSerialDescriptor.addElement("schedules", false);
                    pluginGeneratedSerialDescriptor.addElement("reviewLogs", false);
                    pluginGeneratedSerialDescriptor.addElement("settings", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 5 */         private BackupDocument$$serializer() {
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 5 */         public final KSerializer<?>[] childSerializers() {
/* 6 */             Lazy[] lazyArr = BackupDocument.$childSerializers;
                    return new KSerializer[]{StringSerializer.INSTANCE, IntSerializer.INSTANCE, LongSerializer.INSTANCE, lazyArr[3].getValue(), lazyArr[4].getValue(), lazyArr[5].getValue(), lazyArr[6].getValue(), AppSettings$$serializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 5 */         public final BackupDocument deserialize(Decoder decoder) {
                    int i;
                    String str;
                    List list;
                    List list2;
                    List list3;
                    long j;
                    int i2;
                    List list4;
                    AppSettings appSettings;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 6 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
/* 6 */             Lazy[] lazyArr = BackupDocument.$childSerializers;
                    int i3 = 7;
                    int i4 = 4;
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        String strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        int iDecodeIntElement = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 1);
                        long jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                        List list5 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 3, (DeserializationStrategy) lazyArr[3].getValue(), null);
                        List list6 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 4, (DeserializationStrategy) lazyArr[4].getValue(), null);
                        List list7 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 5, (DeserializationStrategy) lazyArr[5].getValue(), null);
                        list4 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 6, (DeserializationStrategy) lazyArr[6].getValue(), null);
                        str = strDecodeStringElement;
                        appSettings = (AppSettings) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 7, AppSettings$$serializer.INSTANCE, null);
                        list3 = list5;
                        i2 = 255;
                        list = list7;
                        list2 = list6;
                        j = jDecodeLongElement;
                        i = iDecodeIntElement;
                    } else {
                        boolean z = true;
                        int i5 = 0;
                        List list8 = null;
                        AppSettings appSettings2 = null;
                        List list9 = null;
                        long jDecodeLongElement2 = 0;
                        int iDecodeIntElement2 = 0;
                        List list10 = null;
                        String strDecodeStringElement2 = null;
                        List list11 = null;
                        while (z) {
                            int i6 = i4;
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    i3 = 7;
                                    i4 = 4;
                                    break;
                                case 0:
                                    i5 |= 1;
                                    strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i3 = 7;
                                    i4 = 4;
                                    break;
                                case 1:
                                    i5 |= 2;
                                    iDecodeIntElement2 = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 1);
                                    i3 = 7;
                                    i4 = 4;
                                    break;
                                case 2:
                                    jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                                    i5 |= 4;
                                    i3 = 7;
                                    i4 = 4;
                                    break;
                                case 3:
                                    list11 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 3, (DeserializationStrategy) lazyArr[3].getValue(), list11);
                                    i5 |= 8;
                                    i3 = 7;
                                    i4 = 4;
                                    break;
                                case 4:
                                    list10 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, i6, (DeserializationStrategy) lazyArr[i6].getValue(), list10);
                                    i5 |= 16;
                                    i4 = i6;
                                    i3 = 7;
                                    break;
                                case 5:
                                    list9 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 5, (DeserializationStrategy) lazyArr[5].getValue(), list9);
                                    i5 |= 32;
                                    i4 = i6;
                                    break;
                                case 6:
                                    list8 = (List) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 6, (DeserializationStrategy) lazyArr[6].getValue(), list8);
                                    i5 |= 64;
                                    i4 = i6;
                                    break;
                                case 7:
                                    appSettings2 = (AppSettings) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, i3, AppSettings$$serializer.INSTANCE, appSettings2);
                                    i5 |= 128;
                                    i4 = i6;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        String str2 = strDecodeStringElement2;
                        i = iDecodeIntElement2;
                        str = str2;
                        list = list9;
                        list2 = list10;
                        list3 = list11;
                        j = jDecodeLongElement2;
                        i2 = i5;
                        list4 = list8;
                        appSettings = appSettings2;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new BackupDocument(i2, str, i, j, list3, list2, list, list4, appSettings, (SerializationConstructorMarker) null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 5 */         public final void serialize(Encoder encoder, BackupDocument value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 6 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    BackupDocument.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 5 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 6 */             return super.typeParametersSerializers();
                }
            }

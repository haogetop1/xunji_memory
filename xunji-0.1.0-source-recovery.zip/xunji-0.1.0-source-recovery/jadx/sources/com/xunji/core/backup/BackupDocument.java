            package com.xunji.core.backup;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.AppSettings$$serializer;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.CardSchedule$$serializer;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.Deck$$serializer;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.Flashcard$$serializer;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.model.ReviewLog$$serializer;
            import java.util.List;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.ArrayListSerializer;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: BackupDocument.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u0000f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 =2\u00020\u0001:\u0002<=Bc\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t\u0012\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\t\u0012\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000e0\t\u0012\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\t\u0012\u0006\u0010\u0011\u001a\u00020\u0012¢\u0006\u0004\b\u0013\u0010\u0014B\u007f\b\u0010\u0012\u0006\u0010\u0015\u001a\u00020\u0005\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u000e\u0010\b\u001a\n\u0012\u0004\u0012\u00020\n\u0018\u00010\t\u0012\u000e\u0010\u000b\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\t\u0012\u000e\u0010\r\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\t\u0012\u000e\u0010\u000f\u001a\n\u0012\u0004\u0012\u00020\u0010\u0018\u00010\t\u0012\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012\u0012\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017¢\u0006\u0004\b\u0013\u0010\u0018J\t\u0010&\u001a\u00020\u0003HÆ\u0003J\t\u0010'\u001a\u00020\u0005HÆ\u0003J\t\u0010(\u001a\u00020\u0007HÆ\u0003J\u000f\u0010)\u001a\b\u0012\u0004\u0012\u00020\n0\tHÆ\u0003J\u000f\u0010*\u001a\b\u0012\u0004\u0012\u00020\f0\tHÆ\u0003J\u000f\u0010+\u001a\b\u0012\u0004\u0012\u00020\u000e0\tHÆ\u0003J\u000f\u0010,\u001a\b\u0012\u0004\u0012\u00020\u00100\tHÆ\u0003J\t\u0010-\u001a\u00020\u0012HÆ\u0003Jq\u0010.\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\t2\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000e0\t2\u000e\b\u0002\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\t2\b\b\u0002\u0010\u0011\u001a\u00020\u0012HÆ\u0001J\u0013\u0010/\u001a\u0002002\b\u00101\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00102\u001a\u00020\u0005HÖ\u0001J\t\u00103\u001a\u00020\u0003HÖ\u0001J%\u00104\u001a\u0002052\u0006\u00106\u001a\u00020\u00002\u0006\u00107\u001a\u0002082\u0006\u00109\u001a\u00020:H\u0001¢\u0006\u0002\b;R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0017\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010 R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\t¢\u0006\b\n\u0000\u001a\u0004\b!\u0010 R\u0017\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000e0\t¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010 R\u0017\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\t¢\u0006\b\n\u0000\u001a\u0004\b#\u0010 R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%¨\u0006>"}, d2 = {"Lcom/xunji/core/backup/BackupDocument;", "", "format", "", "schemaVersion", "", "exportedAt", "", "decks", "", "Lcom/xunji/core/model/Deck;", "cards", "Lcom/xunji/core/model/Flashcard;", "schedules", "Lcom/xunji/core/model/CardSchedule;", "reviewLogs", "Lcom/xunji/core/model/ReviewLog;", "settings", "Lcom/xunji/core/model/AppSettings;", "<init>", "(Ljava/lang/String;IJLjava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lcom/xunji/core/model/AppSettings;)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;IJLjava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Lcom/xunji/core/model/AppSettings;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getFormat", "()Ljava/lang/String;", "getSchemaVersion", "()I", "getExportedAt", "()J", "getDecks", "()Ljava/util/List;", "getCards", "getSchedules", "getReviewLogs", "getSettings", "()Lcom/xunji/core/model/AppSettings;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 3 */     public final /* data */ class BackupDocument {
                private final List<Flashcard> cards;
                private final List<Deck> decks;
                private final long exportedAt;
                private final String format;
                private final List<ReviewLog> reviewLogs;
                private final List<CardSchedule> schedules;
                private final int schemaVersion;
                private final AppSettings settings;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, null, null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.backup.BackupDocument$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BackupDocument._childSerializers$_anonymous_();
                    }
                }), LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.backup.BackupDocument$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BackupDocument._childSerializers$_anonymous_$0();
                    }
                }), LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.backup.BackupDocument$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BackupDocument._childSerializers$_anonymous_$1();
                    }
                }), LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.backup.BackupDocument$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BackupDocument._childSerializers$_anonymous_$2();
                    }
                }), null};

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ BackupDocument copy$default(BackupDocument backupDocument, String str, int i, long j, List list, List list2, List list3, List list4, AppSettings appSettings, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        str = backupDocument.format;
                    }
                    if ((i2 & 2) != 0) {
                        i = backupDocument.schemaVersion;
                    }
                    if ((i2 & 4) != 0) {
                        j = backupDocument.exportedAt;
                    }
                    if ((i2 & 8) != 0) {
                        list = backupDocument.decks;
                    }
                    if ((i2 & 16) != 0) {
                        list2 = backupDocument.cards;
                    }
                    if ((i2 & 32) != 0) {
                        list3 = backupDocument.schedules;
                    }
                    if ((i2 & 64) != 0) {
                        list4 = backupDocument.reviewLogs;
                    }
                    if ((i2 & 128) != 0) {
                        appSettings = backupDocument.settings;
                    }
                    AppSettings appSettings2 = appSettings;
                    List list5 = list3;
                    List list6 = list;
                    long j2 = j;
                    return backupDocument.copy(str, i, j2, list6, list2, list5, list4, appSettings2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getFormat() {
                    return this.format;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getSchemaVersion() {
                    return this.schemaVersion;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getExportedAt() {
                    return this.exportedAt;
                }

                public final List<Deck> component4() {
                    return this.decks;
                }

                public final List<Flashcard> component5() {
                    return this.cards;
                }

                public final List<CardSchedule> component6() {
                    return this.schedules;
                }

                public final List<ReviewLog> component7() {
                    return this.reviewLogs;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final AppSettings getSettings() {
                    return this.settings;
                }

                public final BackupDocument copy(String format, int schemaVersion, long exportedAt, List<Deck> decks, List<Flashcard> cards, List<CardSchedule> schedules, List<ReviewLog> reviewLogs, AppSettings settings) {
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(decks, "decks");
                    Intrinsics.checkNotNullParameter(cards, "cards");
                    Intrinsics.checkNotNullParameter(schedules, "schedules");
                    Intrinsics.checkNotNullParameter(reviewLogs, "reviewLogs");
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    return new BackupDocument(format, schemaVersion, exportedAt, decks, cards, schedules, reviewLogs, settings);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof BackupDocument)) {
                        return false;
                    }
                    BackupDocument backupDocument = (BackupDocument) other;
                    return Intrinsics.areEqual(this.format, backupDocument.format) && this.schemaVersion == backupDocument.schemaVersion && this.exportedAt == backupDocument.exportedAt && Intrinsics.areEqual(this.decks, backupDocument.decks) && Intrinsics.areEqual(this.cards, backupDocument.cards) && Intrinsics.areEqual(this.schedules, backupDocument.schedules) && Intrinsics.areEqual(this.reviewLogs, backupDocument.reviewLogs) && Intrinsics.areEqual(this.settings, backupDocument.settings);
                }

                public int hashCode() {
                    return (((((((((((((this.format.hashCode() * 31) + Integer.hashCode(this.schemaVersion)) * 31) + Long.hashCode(this.exportedAt)) * 31) + this.decks.hashCode()) * 31) + this.cards.hashCode()) * 31) + this.schedules.hashCode()) * 31) + this.reviewLogs.hashCode()) * 31) + this.settings.hashCode();
                }

                public String toString() {
                    return "BackupDocument(format=" + this.format + ", schemaVersion=" + this.schemaVersion + ", exportedAt=" + this.exportedAt + ", decks=" + this.decks + ", cards=" + this.cards + ", schedules=" + this.schedules + ", reviewLogs=" + this.reviewLogs + ", settings=" + this.settings + ")";
                }

                /* JADX INFO: compiled from: BackupDocument.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/backup/BackupDocument$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/backup/BackupDocument;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */         public static final class Companion {
/* 5 */             private Companion() {
                    }

/* 5 */             public final KSerializer<BackupDocument> serializer() {
/* 6 */                 return BackupDocument$$serializer.INSTANCE;
                    }
                }

/* 5 */         public /* synthetic */ BackupDocument(int seen0, String format, int schemaVersion, long exportedAt, List decks, List cards, List schedules, List reviewLogs, AppSettings settings, SerializationConstructorMarker serializationConstructorMarker) {
/* 6 */             if (252 != (seen0 & 252)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, 252, BackupDocument$$serializer.INSTANCE.getDescriptor());
                    }
                    if ((seen0 & 1) == 0) {
                        this.format = "xunji-backup";
                    } else {
                        this.format = format;
                    }
                    if ((seen0 & 2) == 0) {
                        this.schemaVersion = 1;
                    } else {
                        this.schemaVersion = schemaVersion;
                    }
                    this.exportedAt = exportedAt;
                    this.decks = decks;
                    this.cards = cards;
                    this.schedules = schedules;
                    this.reviewLogs = reviewLogs;
                    this.settings = settings;
                }

/* 5 */         public BackupDocument(String format, int schemaVersion, long exportedAt, List<Deck> decks, List<Flashcard> cards, List<CardSchedule> schedules, List<ReviewLog> reviewLogs, AppSettings settings) {
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(decks, "decks");
                    Intrinsics.checkNotNullParameter(cards, "cards");
                    Intrinsics.checkNotNullParameter(schedules, "schedules");
                    Intrinsics.checkNotNullParameter(reviewLogs, "reviewLogs");
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    this.format = format;
                    this.schemaVersion = schemaVersion;
                    this.exportedAt = exportedAt;
                    this.decks = decks;
                    this.cards = cards;
                    this.schedules = schedules;
                    this.reviewLogs = reviewLogs;
                    this.settings = settings;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 5 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
                    return new ArrayListSerializer(Deck$$serializer.INSTANCE);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 5 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_$0() {
                    return new ArrayListSerializer(Flashcard$$serializer.INSTANCE);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 5 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_$1() {
                    return new ArrayListSerializer(CardSchedule$$serializer.INSTANCE);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 5 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_$2() {
                    return new ArrayListSerializer(ReviewLog$$serializer.INSTANCE);
                }

                @JvmStatic
/* 5 */         public static final /* synthetic */ void write$Self$core(BackupDocument self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 6 */             Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
                    if (output.shouldEncodeElementDefault(serialDesc, 0) || !Intrinsics.areEqual(self.format, "xunji-backup")) {
                        output.encodeStringElement(serialDesc, 0, self.format);
                    }
                    if (output.shouldEncodeElementDefault(serialDesc, 1) || self.schemaVersion != 1) {
                        output.encodeIntElement(serialDesc, 1, self.schemaVersion);
                    }
                    output.encodeLongElement(serialDesc, 2, self.exportedAt);
                    output.encodeSerializableElement(serialDesc, 3, lazyArr[3].getValue(), self.decks);
                    output.encodeSerializableElement(serialDesc, 4, lazyArr[4].getValue(), self.cards);
                    output.encodeSerializableElement(serialDesc, 5, lazyArr[5].getValue(), self.schedules);
                    output.encodeSerializableElement(serialDesc, 6, lazyArr[6].getValue(), self.reviewLogs);
                    output.encodeSerializableElement(serialDesc, 7, AppSettings$$serializer.INSTANCE, self.settings);
                }

/* 5 */         public final List<Flashcard> getCards() {
/* 6 */             return this.cards;
                }

/* 5 */         public final List<Deck> getDecks() {
/* 6 */             return this.decks;
                }

/* 5 */         public final long getExportedAt() {
/* 6 */             return this.exportedAt;
                }

/* 5 */         public final String getFormat() {
/* 6 */             return this.format;
                }

/* 5 */         public final List<ReviewLog> getReviewLogs() {
/* 6 */             return this.reviewLogs;
                }

/* 5 */         public final List<CardSchedule> getSchedules() {
/* 6 */             return this.schedules;
                }

/* 5 */         public final int getSchemaVersion() {
/* 6 */             return this.schemaVersion;
                }

/* 5 */         public final AppSettings getSettings() {
/* 6 */             return this.settings;
                }
            }

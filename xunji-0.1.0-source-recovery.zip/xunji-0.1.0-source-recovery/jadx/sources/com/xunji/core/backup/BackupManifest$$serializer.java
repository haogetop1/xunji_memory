            package com.xunji.core.backup;

            import java.util.Map;
            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Lazy;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.DeserializationStrategy;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: BackupDocument.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/backup/BackupManifest.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/backup/BackupManifest;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 6 */     public final /* synthetic */ class BackupManifest$$serializer implements GeneratedSerializer<BackupManifest> {
                public static final BackupManifest$$serializer INSTANCE = new BackupManifest$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 8 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.backup.BackupManifest", INSTANCE, 8);
                    pluginGeneratedSerialDescriptor.addElement("format", true);
                    pluginGeneratedSerialDescriptor.addElement("schemaVersion", true);
                    pluginGeneratedSerialDescriptor.addElement("exportedAt", false);
                    pluginGeneratedSerialDescriptor.addElement("counts", false);
                    pluginGeneratedSerialDescriptor.addElement("recordsBytes", false);
                    pluginGeneratedSerialDescriptor.addElement("recordsSha256", false);
                    pluginGeneratedSerialDescriptor.addElement("mediaCount", false);
                    pluginGeneratedSerialDescriptor.addElement("mediaBytes", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 7 */         private BackupManifest$$serializer() {
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 7 */         public final KSerializer<?>[] childSerializers() {
                    return new KSerializer[]{StringSerializer.INSTANCE, IntSerializer.INSTANCE, LongSerializer.INSTANCE, BackupManifest.$childSerializers[3].getValue(), LongSerializer.INSTANCE, StringSerializer.INSTANCE, LongSerializer.INSTANCE, LongSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 7 */         public final BackupManifest deserialize(Decoder decoder) {
                    String str;
                    int i;
                    Map map;
                    int i2;
                    String str2;
                    long j;
                    long j2;
                    long jDecodeLongElement;
                    long j3;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 8 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
/* 8 */             Lazy[] lazyArr = BackupManifest.$childSerializers;
                    int i3 = 7;
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        String strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        int iDecodeIntElement = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 1);
                        long jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                        Map map2 = (Map) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 3, (DeserializationStrategy) lazyArr[3].getValue(), null);
                        long jDecodeLongElement3 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 4);
                        String strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 5);
                        long jDecodeLongElement4 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                        map = map2;
                        jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 7);
                        str = strDecodeStringElement2;
                        j = jDecodeLongElement3;
                        j3 = jDecodeLongElement4;
                        j2 = jDecodeLongElement2;
                        str2 = strDecodeStringElement;
                        i = 255;
                        i2 = iDecodeIntElement;
                    } else {
                        long jDecodeLongElement5 = 0;
                        boolean z = true;
                        int i4 = 0;
                        String strDecodeStringElement3 = null;
                        String strDecodeStringElement4 = null;
                        long jDecodeLongElement6 = 0;
                        long jDecodeLongElement7 = 0;
                        long jDecodeLongElement8 = 0;
                        int iDecodeIntElement2 = 0;
                        Map map3 = null;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    i3 = 7;
                                    break;
                                case 0:
                                    strDecodeStringElement3 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i4 |= 1;
                                    i3 = 7;
                                    break;
                                case 1:
                                    iDecodeIntElement2 = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 1);
                                    i4 |= 2;
                                    break;
                                case 2:
                                    jDecodeLongElement8 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                                    i4 |= 4;
                                    break;
                                case 3:
                                    map3 = (Map) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 3, (DeserializationStrategy) lazyArr[3].getValue(), map3);
                                    i4 |= 8;
                                    break;
                                case 4:
                                    jDecodeLongElement6 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 4);
                                    i4 |= 16;
                                    break;
                                case 5:
                                    strDecodeStringElement4 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 5);
                                    i4 |= 32;
                                    break;
                                case 6:
                                    jDecodeLongElement7 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                                    i4 |= 64;
                                    break;
                                case 7:
                                    jDecodeLongElement5 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, i3);
                                    i4 |= 128;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        str = strDecodeStringElement4;
                        int i5 = iDecodeIntElement2;
                        i = i4;
                        long j4 = jDecodeLongElement7;
                        map = map3;
                        long j5 = jDecodeLongElement5;
                        i2 = i5;
                        str2 = strDecodeStringElement3;
                        j = jDecodeLongElement6;
                        j2 = jDecodeLongElement8;
                        jDecodeLongElement = j5;
                        j3 = j4;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new BackupManifest(i, str2, i2, j2, map, j, str, j3, jDecodeLongElement, (SerializationConstructorMarker) null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 7 */         public final void serialize(Encoder encoder, BackupManifest value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 8 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    BackupManifest.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 7 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 8 */             return super.typeParametersSerializers();
                }
            }

            package com.xunji.core.backup;

            import java.util.Map;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.LinkedHashMapSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: BackupDocument.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010$\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 72\u00020\u0001:\u000267BW\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\t\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007¢\u0006\u0004\b\u000e\u0010\u000fBm\b\u0010\u0012\u0006\u0010\u0010\u001a\u00020\u0005\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0014\u0010\b\u001a\u0010\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u0007\u0018\u00010\t\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\b\u0010\u0011\u001a\u0004\u0018\u00010\u0012¢\u0006\u0004\b\u000e\u0010\u0013J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0005HÆ\u0003J\t\u0010\"\u001a\u00020\u0007HÆ\u0003J\u0015\u0010#\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\tHÆ\u0003J\t\u0010$\u001a\u00020\u0007HÆ\u0003J\t\u0010%\u001a\u00020\u0003HÆ\u0003J\t\u0010&\u001a\u00020\u0007HÆ\u0003J\t\u0010'\u001a\u00020\u0007HÆ\u0003Je\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\u0014\b\u0002\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\t2\b\b\u0002\u0010\n\u001a\u00020\u00072\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u00072\b\b\u0002\u0010\r\u001a\u00020\u0007HÆ\u0001J\u0013\u0010)\u001a\u00020*2\b\u0010+\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010,\u001a\u00020\u0005HÖ\u0001J\t\u0010-\u001a\u00020\u0003HÖ\u0001J%\u0010.\u001a\u00020/2\u0006\u00100\u001a\u00020\u00002\u0006\u00101\u001a\u0002022\u0006\u00103\u001a\u000204H\u0001¢\u0006\u0002\b5R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u001d\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00070\t¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0015R\u0011\u0010\f\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u0019R\u0011\u0010\r\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u0019¨\u00068"}, d2 = {"Lcom/xunji/core/backup/BackupManifest;", "", "format", "", "schemaVersion", "", "exportedAt", "", "counts", "", "recordsBytes", "recordsSha256", "mediaCount", "mediaBytes", "<init>", "(Ljava/lang/String;IJLjava/util/Map;JLjava/lang/String;JJ)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;IJLjava/util/Map;JLjava/lang/String;JJLkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getFormat", "()Ljava/lang/String;", "getSchemaVersion", "()I", "getExportedAt", "()J", "getCounts", "()Ljava/util/Map;", "getRecordsBytes", "getRecordsSha256", "getMediaCount", "getMediaBytes", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 5 */     public final /* data */ class BackupManifest {
                private final Map<String, Long> counts;
                private final long exportedAt;
                private final String format;
                private final long mediaBytes;
                private final long mediaCount;
                private final long recordsBytes;
                private final String recordsSha256;
                private final int schemaVersion;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, null, null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.backup.BackupManifest$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return BackupManifest._childSerializers$_anonymous_();
                    }
                }), null, null, null, null};

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ BackupManifest copy$default(BackupManifest backupManifest, String str, int i, long j, Map map, long j2, String str2, long j3, long j4, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        str = backupManifest.format;
                    }
                    if ((i2 & 2) != 0) {
                        i = backupManifest.schemaVersion;
                    }
                    if ((i2 & 4) != 0) {
                        j = backupManifest.exportedAt;
                    }
                    if ((i2 & 8) != 0) {
                        map = backupManifest.counts;
                    }
                    if ((i2 & 16) != 0) {
                        j2 = backupManifest.recordsBytes;
                    }
                    if ((i2 & 32) != 0) {
                        str2 = backupManifest.recordsSha256;
                    }
                    if ((i2 & 64) != 0) {
                        j3 = backupManifest.mediaCount;
                    }
                    if ((i2 & 128) != 0) {
                        j4 = backupManifest.mediaBytes;
                    }
                    String str3 = str2;
                    Map map2 = map;
                    long j5 = j;
                    return backupManifest.copy(str, i, j5, map2, j2, str3, j3, j4);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getFormat() {
                    return this.format;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getSchemaVersion() {
                    return this.schemaVersion;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getExportedAt() {
                    return this.exportedAt;
                }

                public final Map<String, Long> component4() {
                    return this.counts;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final long getRecordsBytes() {
                    return this.recordsBytes;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final String getRecordsSha256() {
                    return this.recordsSha256;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getMediaCount() {
                    return this.mediaCount;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final long getMediaBytes() {
                    return this.mediaBytes;
                }

                public final BackupManifest copy(String format, int schemaVersion, long exportedAt, Map<String, Long> counts, long recordsBytes, String recordsSha256, long mediaCount, long mediaBytes) {
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(counts, "counts");
                    Intrinsics.checkNotNullParameter(recordsSha256, "recordsSha256");
                    return new BackupManifest(format, schemaVersion, exportedAt, counts, recordsBytes, recordsSha256, mediaCount, mediaBytes);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof BackupManifest)) {
                        return false;
                    }
                    BackupManifest backupManifest = (BackupManifest) other;
                    return Intrinsics.areEqual(this.format, backupManifest.format) && this.schemaVersion == backupManifest.schemaVersion && this.exportedAt == backupManifest.exportedAt && Intrinsics.areEqual(this.counts, backupManifest.counts) && this.recordsBytes == backupManifest.recordsBytes && Intrinsics.areEqual(this.recordsSha256, backupManifest.recordsSha256) && this.mediaCount == backupManifest.mediaCount && this.mediaBytes == backupManifest.mediaBytes;
                }

                public int hashCode() {
                    return (((((((((((((this.format.hashCode() * 31) + Integer.hashCode(this.schemaVersion)) * 31) + Long.hashCode(this.exportedAt)) * 31) + this.counts.hashCode()) * 31) + Long.hashCode(this.recordsBytes)) * 31) + this.recordsSha256.hashCode()) * 31) + Long.hashCode(this.mediaCount)) * 31) + Long.hashCode(this.mediaBytes);
                }

                public String toString() {
                    return "BackupManifest(format=" + this.format + ", schemaVersion=" + this.schemaVersion + ", exportedAt=" + this.exportedAt + ", counts=" + this.counts + ", recordsBytes=" + this.recordsBytes + ", recordsSha256=" + this.recordsSha256 + ", mediaCount=" + this.mediaCount + ", mediaBytes=" + this.mediaBytes + ")";
                }

                /* JADX INFO: compiled from: BackupDocument.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/backup/BackupManifest$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/backup/BackupManifest;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */         public static final class Companion {
/* 7 */             private Companion() {
                    }

/* 7 */             public final KSerializer<BackupManifest> serializer() {
/* 8 */                 return BackupManifest$$serializer.INSTANCE;
                    }
                }

/* 7 */         public /* synthetic */ BackupManifest(int seen0, String format, int schemaVersion, long exportedAt, Map counts, long recordsBytes, String recordsSha256, long mediaCount, long mediaBytes, SerializationConstructorMarker serializationConstructorMarker) {
/* 8 */             if (252 != (seen0 & 252)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, 252, BackupManifest$$serializer.INSTANCE.getDescriptor());
                    }
                    if ((seen0 & 1) == 0) {
/* 8 */                 this.format = "xunji-backup";
                    } else {
                        this.format = format;
                    }
                    if ((seen0 & 2) == 0) {
/* 8 */                 this.schemaVersion = 2;
                    } else {
                        this.schemaVersion = schemaVersion;
                    }
                    this.exportedAt = exportedAt;
                    this.counts = counts;
                    this.recordsBytes = recordsBytes;
                    this.recordsSha256 = recordsSha256;
                    this.mediaCount = mediaCount;
                    this.mediaBytes = mediaBytes;
                }

/* 7 */         public BackupManifest(String format, int schemaVersion, long exportedAt, Map<String, Long> counts, long recordsBytes, String recordsSha256, long mediaCount, long mediaBytes) {
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(counts, "counts");
                    Intrinsics.checkNotNullParameter(recordsSha256, "recordsSha256");
/* 9 */             this.format = format;
                    this.schemaVersion = schemaVersion;
                    this.exportedAt = exportedAt;
/* 10 */            this.counts = counts;
                    this.recordsBytes = recordsBytes;
                    this.recordsSha256 = recordsSha256;
/* 11 */            this.mediaCount = mediaCount;
                    this.mediaBytes = mediaBytes;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 7 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
                    return new LinkedHashMapSerializer(StringSerializer.INSTANCE, LongSerializer.INSTANCE);
                }

                @JvmStatic
/* 7 */         public static final /* synthetic */ void write$Self$core(BackupManifest self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 8 */             Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
/* 8 */             if (output.shouldEncodeElementDefault(serialDesc, 0) || !Intrinsics.areEqual(self.format, "xunji-backup")) {
                        output.encodeStringElement(serialDesc, 0, self.format);
                    }
/* 8 */             if (output.shouldEncodeElementDefault(serialDesc, 1) || self.schemaVersion != 2) {
                        output.encodeIntElement(serialDesc, 1, self.schemaVersion);
                    }
                    output.encodeLongElement(serialDesc, 2, self.exportedAt);
                    output.encodeSerializableElement(serialDesc, 3, lazyArr[3].getValue(), self.counts);
                    output.encodeLongElement(serialDesc, 4, self.recordsBytes);
                    output.encodeStringElement(serialDesc, 5, self.recordsSha256);
                    output.encodeLongElement(serialDesc, 6, self.mediaCount);
                    output.encodeLongElement(serialDesc, 7, self.mediaBytes);
                }

/* 8 */         public final long getExportedAt() {
/* 9 */             return this.exportedAt;
                }

/* 8 */         public final String getFormat() {
/* 9 */             return this.format;
                }

/* 8 */         public final int getSchemaVersion() {
/* 9 */             return this.schemaVersion;
                }

/* 9 */         public final Map<String, Long> getCounts() {
/* 10 */            return this.counts;
                }

/* 9 */         public final long getRecordsBytes() {
/* 10 */            return this.recordsBytes;
                }

/* 9 */         public final String getRecordsSha256() {
/* 10 */            return this.recordsSha256;
                }

/* 10 */        public final long getMediaBytes() {
/* 11 */            return this.mediaBytes;
                }

/* 10 */        public final long getMediaCount() {
/* 11 */            return this.mediaCount;
                }
            }

            package com.xunji.core.backup;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.validation.InputValidator;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.IntRange;
            import kotlin.ranges.RangesKt;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: BackupValidator.kt */
            /* JADX INFO: loaded from: classes4.dex */
            @Metadata(d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010 \n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bJ\u000e\u0010\f\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005J0\u0010\r\u001a\u00020\t\"\u0004\b\u0000\u0010\u000e2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u0002H\u000e0\u00102\u0012\u0010\u0011\u001a\u000e\u0012\u0004\u0012\u0002H\u000e\u0012\u0004\u0012\u00020\u000b0\u0012H\u0002J\u000e\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0014\u001a\u00020\u0015J\u000e\u0010\u0016\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0017J\u0018\u0010\u0018\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u00192\b\b\u0002\u0010\u001a\u001a\u00020\u001bJ\u000e\u0010\u001c\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u001dJ\u000e\u0010\u001e\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001fJ\u000e\u0010 \u001a\u00020\t2\u0006\u0010!\u001a\u00020\"R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006#"}, d2 = {"Lcom/xunji/core/backup/BackupValidator;", "", "<init>", "()V", "MAX_TIME", "", "uuid", "Lkotlin/text/Regex;", "id", "", "value", "", "time", "unique", "T", "values", "", "key", "Lkotlin/Function1;", "schedule", "s", "Lcom/xunji/core/model/CardSchedule;", "settings", "Lcom/xunji/core/model/AppSettings;", "deck", "Lcom/xunji/core/model/Deck;", "imported", "", "card", "Lcom/xunji/core/model/Flashcard;", "log", "Lcom/xunji/core/model/ReviewLog;", "validate", "d", "Lcom/xunji/core/backup/BackupDocument;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final class BackupValidator {
                private static final long MAX_TIME = 253402300799999L;
                public static final BackupValidator INSTANCE = new BackupValidator();
                private static final Regex uuid = new Regex("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");

                /* JADX INFO: compiled from: BackupValidator.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[Phase.values().length];
                        try {
                            iArr[Phase.LEARNING.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[Phase.RELEARNING.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[Phase.REVIEW.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

/* 5 */         private BackupValidator() {
                }

/* 8 */         public final void id(String value) {
                    Intrinsics.checkNotNullParameter(value, "value");
/* 9 */             if (!uuid.matches(value)) {
                        throw new IllegalArgumentException("无效的 ID".toString());
                    }
                }

/* 9 */         public final void time(long value) {
                    boolean z = false;
                    if (0 <= value && value < 253402300800000L) {
                        z = true;
                    }
                    if (!z) {
                        throw new IllegalArgumentException("时间超出范围".toString());
                    }
                }

/* 10 */        private final <T> void unique(List<? extends T> values, Function1<? super T, String> key) {
/* 11 */            List<? extends T> $this$map$iv = values;
/* 62 */            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
                    for (Object item$iv$iv : $this$map$iv) {
/* 64 */                destination$iv$iv.add(key.invoke(item$iv$iv));
                    }
/* 11 */            if (!(CollectionsKt.toSet((List) destination$iv$iv).size() == values.size())) {
                        throw new IllegalArgumentException("存在重复 ID".toString());
                    }
                }

                /* JADX WARN: Code duplicated, block: B:43:0x00ba  */
                /* JADX WARN: Code duplicated, block: B:60:0x00f3  */
/* 12 */        public final void schedule(CardSchedule s) {
                    boolean z;
                    boolean z2;
                    Intrinsics.checkNotNullParameter(s, "s");
/* 13 */            id(s.getCardId());
                    time(s.getDueAt());
                    Long lastReviewAt = s.getLastReviewAt();
                    if (lastReviewAt != null) {
/* 13 */                time(lastReviewAt.longValue());
                    }
                    Long firstReviewedAt = s.getFirstReviewedAt();
                    if (firstReviewedAt != null) {
/* 13 */                time(firstReviewedAt.longValue());
                    }
/* 14 */            long p0 = s.getRevision();
                    boolean z3 = true;
                    if (!(0 <= p0 && p0 < Long.MAX_VALUE)) {
                        throw new IllegalArgumentException("无效的版本号".toString());
                    }
/* 15 */            if (s.getPhase() == Phase.NEW) {
/* 16 */                if (!(s.getStep() == null && s.getStability() == null && s.getDifficulty() == null && s.getLastReviewAt() == null && s.getFirstReviewedAt() == null)) {
                            throw new IllegalArgumentException("新卡状态不一致".toString());
                        }
/* 24 */                return;
                    }
/* 18 */            if (s.getStability() == null) {
                        z = false;
                    } else if (!(Math.abs(s.getStability().doubleValue()) <= Double.MAX_VALUE) || s.getStability().doubleValue() < 0.001d) {
                        z = false;
                    } else {
                        z = true;
                    }
                    if (!z) {
                        throw new IllegalArgumentException("无效的记忆稳定性".toString());
                    }
/* 19 */            if (s.getDifficulty() == null) {
                        z2 = false;
                    } else if (Math.abs(s.getDifficulty().doubleValue()) <= Double.MAX_VALUE) {
                        double dDoubleValue = s.getDifficulty().doubleValue();
                        if (1.0d <= dDoubleValue && dDoubleValue <= 10.0d) {
                            z2 = true;
                        } else {
                            z2 = false;
                        }
                    } else {
                        z2 = false;
                    }
                    if (!z2) {
                        throw new IllegalArgumentException("无效的记忆难度".toString());
                    }
/* 20 */            if (!((s.getLastReviewAt() == null || s.getFirstReviewedAt() == null || s.getFirstReviewedAt().longValue() > s.getLastReviewAt().longValue()) ? false : true)) {
                        throw new IllegalArgumentException("缺少学习时间".toString());
                    }
                    if (!(s.getRevision() > 0)) {
                        throw new IllegalArgumentException("已学卡版本号无效".toString());
                    }
                    switch (WhenMappings.$EnumSwitchMapping$0[s.getPhase().ordinal()]) {
                        case 1:
                            IntRange intRange = new IntRange(0, 1);
                            Integer step = s.getStep();
                            if (step == null || !intRange.contains(step.intValue())) {
                                z3 = false;
                            }
                            break;
                        case 2:
                            Integer step2 = s.getStep();
                            if (step2 == null || step2.intValue() != 0) {
                                z3 = false;
                            }
                            break;
                        case 3:
                            if (s.getStep() != null) {
                                z3 = false;
                            }
                            break;
                        default:
                            z3 = false;
                            break;
                    }
                    if (!z3) {
                        throw new IllegalArgumentException("学习步骤无效".toString());
                    }
                }

/* 25 */        public final void settings(AppSettings value) {
                    Intrinsics.checkNotNullParameter(value, "value");
                    boolean z = false;
/* 26 */            if (value.getSchemaVersion() == 1) {
                        int newCardsPerDay = value.getNewCardsPerDay();
                        if (newCardsPerDay >= 0 && newCardsPerDay < 101) {
                            z = true;
                        }
                    }
                    if (!z) {
                        throw new IllegalArgumentException("无效的设置".toString());
                    }
                }

/* 27 */        public static /* synthetic */ void deck$default(BackupValidator backupValidator, Deck deck, boolean z, int i, Object obj) {
/* 28 */            if ((i & 2) != 0) {
                        z = false;
                    }
                    backupValidator.deck(deck, z);
                }

/* 28 */        public final void deck(Deck value, boolean imported) {
                    Intrinsics.checkNotNullParameter(value, "value");
/* 29 */            id(value.getId());
                    time(value.getCreatedAt());
                    time(value.getUpdatedAt());
                    if (!(value.getUpdatedAt() >= value.getCreatedAt())) {
/* 29 */                throw new IllegalArgumentException("Failed requirement.".toString());
                    }
/* 30 */            if (!imported) {
/* 31 */                InputValidator.INSTANCE.deckName(value.getName());
                    } else {
                        if (!((StringsKt.isBlank(value.getName()) || StringsKt.contains$default((CharSequence) value.getName(), (char) 0, false, 2, (Object) null) || value.getName().codePointCount(0, value.getName().length()) > 1042) ? false : true)) {
                            throw new IllegalArgumentException("导入牌组名称超限".toString());
                        }
                    }
                }

/* 33 */        public final void card(Flashcard value) {
                    Intrinsics.checkNotNullParameter(value, "value");
/* 34 */            id(value.getId());
                    id(value.getDeckId());
                    InputValidator.INSTANCE.cardContent(value.getFront(), value.getBack(), value.getExample());
/* 35 */            time(value.getCreatedAt());
                    time(value.getUpdatedAt());
                    if (!(value.getUpdatedAt() >= value.getCreatedAt())) {
/* 35 */                throw new IllegalArgumentException("Failed requirement.".toString());
                    }
                }

                /* JADX WARN: Code duplicated, block: B:29:0x00c2  */
/* 37 */        public final void log(ReviewLog log) {
                    boolean z;
                    Intrinsics.checkNotNullParameter(log, "log");
/* 38 */            id(log.getId());
                    id(log.getCardId());
                    id(log.getDeckId());
                    id(log.getSessionId());
                    time(log.getReviewedAt());
                    Long undoneAt = log.getUndoneAt();
                    if (undoneAt != null) {
/* 38 */                time(undoneAt.longValue());
                    }
/* 39 */            long p0 = log.getDurationMs();
                    if (!(0 <= p0 && p0 < 300001)) {
/* 39 */                throw new IllegalArgumentException("Failed requirement.".toString());
                    }
/* 40 */            schedule(log.getBeforeSchedule());
                    schedule(log.getAfterSchedule());
/* 41 */            if (!(Intrinsics.areEqual(log.getBeforeSchedule().getCardId(), log.getCardId()) && Intrinsics.areEqual(log.getAfterSchedule().getCardId(), log.getCardId()))) {
                        throw new IllegalArgumentException("记录快照与卡片不对应".toString());
                    }
                    if (log.getAfterSchedule().getRevision() == log.getBeforeSchedule().getRevision() + 1 && log.getAfterSchedule().getPhase() != Phase.NEW) {
                        Long lastReviewAt = log.getAfterSchedule().getLastReviewAt();
                        z = lastReviewAt != null && lastReviewAt.longValue() == log.getReviewedAt();
                    }
                    if (!z) {
                        throw new IllegalArgumentException("评分快照不一致".toString());
                    }
/* 43 */            Long firstReviewedAt = log.getAfterSchedule().getFirstReviewedAt();
                    Long firstReviewedAt2 = log.getBeforeSchedule().getFirstReviewedAt();
                    if (firstReviewedAt2 == null) {
                        firstReviewedAt2 = Long.valueOf(log.getReviewedAt());
                    }
                    if (!Intrinsics.areEqual(firstReviewedAt, firstReviewedAt2)) {
                        throw new IllegalArgumentException("首次学习时间不一致".toString());
                    }
                }

/* 45 */        public final void validate(BackupDocument d) {
                    Intrinsics.checkNotNullParameter(d, "d");
/* 46 */            if (!(Intrinsics.areEqual(d.getFormat(), "xunji-backup") && d.getSchemaVersion() == 1 && d.getSettings().getSchemaVersion() == 1)) {
                        throw new IllegalArgumentException("不支持的备份格式或版本".toString());
                    }
/* 47 */            time(d.getExportedAt());
                    int newCardsPerDay = d.getSettings().getNewCardsPerDay();
                    if (!(newCardsPerDay >= 0 && newCardsPerDay < 101)) {
/* 47 */                throw new IllegalArgumentException("Failed requirement.".toString());
                    }
/* 48 */            unique(d.getDecks(), new Function1() { // from class: com.xunji.core.backup.BackupValidator$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupValidator.validate$lambda$1((Deck) obj);
                        }
                    });
                    unique(d.getCards(), new Function1() { // from class: com.xunji.core.backup.BackupValidator$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupValidator.validate$lambda$2((Flashcard) obj);
                        }
                    });
                    unique(d.getSchedules(), new Function1() { // from class: com.xunji.core.backup.BackupValidator$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupValidator.validate$lambda$3((CardSchedule) obj);
                        }
                    });
                    unique(d.getReviewLogs(), new Function1() { // from class: com.xunji.core.backup.BackupValidator$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupValidator.validate$lambda$4((ReviewLog) obj);
                        }
                    });
/* 49 */            Iterable $this$associateBy$iv = d.getDecks();
/* 66 */            int capacity$iv = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$associateBy$iv, 10)), 16);
/* 67 */            Map decks = new LinkedHashMap(capacity$iv);
                    for (Object element$iv$iv : $this$associateBy$iv) {
/* 69 */                decks.put(((Deck) element$iv$iv).getId(), element$iv$iv);
                    }
                    Iterable $this$associateBy$iv2 = d.getCards();
/* 66 */            int capacity$iv2 = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$associateBy$iv2, 10)), 16);
/* 67 */            Map cards = new LinkedHashMap(capacity$iv2);
                    for (Object element$iv$iv2 : $this$associateBy$iv2) {
/* 69 */                cards.put(((Flashcard) element$iv$iv2).getId(), element$iv$iv2);
                    }
/* 50 */            Iterable $this$forEach$iv = d.getDecks();
                    for (Object element$iv : $this$forEach$iv) {
/* 50 */                deck$default(INSTANCE, (Deck) element$iv, false, 2, null);
                    }
/* 51 */            Iterable $this$forEach$iv2 = d.getCards();
                    for (Object element$iv2 : $this$forEach$iv2) {
                        Flashcard it = (Flashcard) element$iv2;
/* 51 */                INSTANCE.card(it);
                        if (!decks.containsKey(it.getDeckId())) {
/* 51 */                    throw new IllegalArgumentException("Failed requirement.".toString());
                        }
                    }
/* 52 */            Iterable $this$map$iv = d.getSchedules();
/* 76 */            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
                    for (Object item$iv$iv : $this$map$iv) {
/* 78 */                destination$iv$iv.add(((CardSchedule) item$iv$iv).getCardId());
                    }
/* 52 */            if (!Intrinsics.areEqual(CollectionsKt.toSet((List) destination$iv$iv), cards.keySet())) {
                        throw new IllegalArgumentException("卡片与调度状态不对应".toString());
                    }
/* 53 */            Iterable $this$forEach$iv3 = d.getSchedules();
                    for (Object element$iv3 : $this$forEach$iv3) {
                        CardSchedule p0 = (CardSchedule) element$iv3;
/* 53 */                schedule(p0);
                    }
/* 54 */            Iterable $this$forEach$iv4 = d.getReviewLogs();
                    for (Object element$iv4 : $this$forEach$iv4) {
                        ReviewLog log = (ReviewLog) element$iv4;
/* 55 */                INSTANCE.log(log);
/* 56 */                Flashcard flashcard = (Flashcard) cards.get(log.getCardId());
                        if (!Intrinsics.areEqual(flashcard != null ? flashcard.getDeckId() : null, log.getDeckId())) {
                            throw new IllegalArgumentException("记录与牌组不对应".toString());
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 47 */        public static final String validate$lambda$1(Deck it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 48 */            return it.getId();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 47 */        public static final String validate$lambda$2(Flashcard it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 48 */            return it.getId();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 47 */        public static final String validate$lambda$3(CardSchedule it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 48 */            return it.getCardId();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 47 */        public static final String validate$lambda$4(ReviewLog it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 48 */            return it.getId();
                }
            }

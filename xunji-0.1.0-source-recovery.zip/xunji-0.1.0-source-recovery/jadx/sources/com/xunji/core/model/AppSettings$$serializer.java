            package com.xunji.core.model;

            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Lazy;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.DeserializationStrategy;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/model/AppSettings.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/model/AppSettings;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 9 */     public final /* synthetic */ class AppSettings$$serializer implements GeneratedSerializer<AppSettings> {
                public static final AppSettings$$serializer INSTANCE = new AppSettings$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 11 */            PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.model.AppSettings", INSTANCE, 3);
                    pluginGeneratedSerialDescriptor.addElement("newCardsPerDay", true);
                    pluginGeneratedSerialDescriptor.addElement("themeMode", true);
                    pluginGeneratedSerialDescriptor.addElement("schemaVersion", true);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 10 */        private AppSettings$$serializer() {
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 10 */        public final KSerializer<?>[] childSerializers() {
                    return new KSerializer[]{IntSerializer.INSTANCE, AppSettings.$childSerializers[1].getValue(), IntSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 10 */        public final AppSettings deserialize(Decoder decoder) {
                    int iDecodeIntElement;
                    int iDecodeIntElement2;
                    int i;
                    ThemeMode themeMode;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 11 */            SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
/* 11 */            Lazy[] lazyArr = AppSettings.$childSerializers;
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        iDecodeIntElement = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 0);
                        themeMode = (ThemeMode) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, (DeserializationStrategy) lazyArr[1].getValue(), null);
                        i = 7;
                        iDecodeIntElement2 = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 2);
                    } else {
                        boolean z = true;
                        iDecodeIntElement = 0;
                        int i2 = 0;
                        ThemeMode themeMode2 = null;
                        int iDecodeIntElement3 = 0;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    break;
                                case 0:
                                    iDecodeIntElement = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 0);
                                    i2 |= 1;
                                    break;
                                case 1:
                                    themeMode2 = (ThemeMode) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, (DeserializationStrategy) lazyArr[1].getValue(), themeMode2);
                                    i2 |= 2;
                                    break;
                                case 2:
                                    iDecodeIntElement3 = compositeDecoderBeginStructure.decodeIntElement(serialDescriptor, 2);
                                    i2 |= 4;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        iDecodeIntElement2 = iDecodeIntElement3;
                        i = i2;
                        themeMode = themeMode2;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new AppSettings(i, iDecodeIntElement, themeMode, iDecodeIntElement2, (SerializationConstructorMarker) null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 10 */        public final void serialize(Encoder encoder, AppSettings value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 11 */            SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    AppSettings.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 10 */        public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 11 */            return super.typeParametersSerializers();
                }
            }

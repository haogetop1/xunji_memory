            package com.xunji.core.model;

            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 %2\u00020\u0001:\u0002$%B%\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bB5\b\u0010\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b¢\u0006\u0004\b\u0007\u0010\fJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J'\u0010\u0015\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0016\u001a\u00020\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÖ\u0001J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001J%\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u001e\u001a\u00020\u00002\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"H\u0001¢\u0006\u0002\b#R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000e¨\u0006&"}, d2 = {"Lcom/xunji/core/model/AppSettings;", "", "newCardsPerDay", "", "themeMode", "Lcom/xunji/core/model/ThemeMode;", "schemaVersion", "<init>", "(ILcom/xunji/core/model/ThemeMode;I)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(IILcom/xunji/core/model/ThemeMode;ILkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getNewCardsPerDay", "()I", "getThemeMode", "()Lcom/xunji/core/model/ThemeMode;", "getSchemaVersion", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 8 */     public final /* data */ class AppSettings {
                private final int newCardsPerDay;
                private final int schemaVersion;
                private final ThemeMode themeMode;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.model.AppSettings$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return AppSettings._childSerializers$_anonymous_();
                    }
                }), null};

                public AppSettings() {
                    this(0, (ThemeMode) null, 0, 7);
                }

                public static /* synthetic */ AppSettings copy$default(AppSettings appSettings, int i, ThemeMode themeMode, int i2, int i3, Object obj) {
                    if ((i3 & 1) != 0) {
                        i = appSettings.newCardsPerDay;
                    }
                    if ((i3 & 2) != 0) {
                        themeMode = appSettings.themeMode;
                    }
                    if ((i3 & 4) != 0) {
                        i2 = appSettings.schemaVersion;
                    }
                    return appSettings.copy(i, themeMode, i2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final int getNewCardsPerDay() {
                    return this.newCardsPerDay;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final ThemeMode getThemeMode() {
                    return this.themeMode;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getSchemaVersion() {
                    return this.schemaVersion;
                }

                public final AppSettings copy(int newCardsPerDay, ThemeMode themeMode, int schemaVersion) {
                    Intrinsics.checkNotNullParameter(themeMode, "themeMode");
                    return new AppSettings(newCardsPerDay, themeMode, schemaVersion);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AppSettings)) {
                        return false;
                    }
                    AppSettings appSettings = (AppSettings) other;
                    return this.newCardsPerDay == appSettings.newCardsPerDay && this.themeMode == appSettings.themeMode && this.schemaVersion == appSettings.schemaVersion;
                }

                public int hashCode() {
                    return (((Integer.hashCode(this.newCardsPerDay) * 31) + this.themeMode.hashCode()) * 31) + Integer.hashCode(this.schemaVersion);
                }

                public String toString() {
                    return "AppSettings(newCardsPerDay=" + this.newCardsPerDay + ", themeMode=" + this.themeMode + ", schemaVersion=" + this.schemaVersion + ")";
                }

                /* JADX INFO: compiled from: Models.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/AppSettings$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/AppSettings;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */         public static final class Companion {
/* 10 */            private Companion() {
                    }

/* 10 */            public final KSerializer<AppSettings> serializer() {
/* 11 */                return AppSettings$$serializer.INSTANCE;
                    }
                }

/* 10 */        public /* synthetic */ AppSettings(int seen0, int newCardsPerDay, ThemeMode themeMode, int schemaVersion, SerializationConstructorMarker serializationConstructorMarker) {
                    if ((seen0 & 1) == 0) {
                        this.newCardsPerDay = 20;
                    } else {
                        this.newCardsPerDay = newCardsPerDay;
                    }
                    if ((seen0 & 2) == 0) {
                        this.themeMode = ThemeMode.SYSTEM;
                    } else {
                        this.themeMode = themeMode;
                    }
                    if ((seen0 & 4) == 0) {
                        this.schemaVersion = 1;
                    } else {
                        this.schemaVersion = schemaVersion;
                    }
                }

/* 10 */        public AppSettings(int newCardsPerDay, ThemeMode themeMode, int schemaVersion) {
                    Intrinsics.checkNotNullParameter(themeMode, "themeMode");
                    this.newCardsPerDay = newCardsPerDay;
                    this.themeMode = themeMode;
                    this.schemaVersion = schemaVersion;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 10 */        public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
                    return ThemeMode.INSTANCE.serializer();
                }

                @JvmStatic
/* 10 */        public static final /* synthetic */ void write$Self$core(AppSettings self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 11 */            Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
                    if (output.shouldEncodeElementDefault(serialDesc, 0) || self.newCardsPerDay != 20) {
                        output.encodeIntElement(serialDesc, 0, self.newCardsPerDay);
                    }
                    if (output.shouldEncodeElementDefault(serialDesc, 1) || self.themeMode != ThemeMode.SYSTEM) {
                        output.encodeSerializableElement(serialDesc, 1, lazyArr[1].getValue(), self.themeMode);
                    }
                    if (output.shouldEncodeElementDefault(serialDesc, 2) || self.schemaVersion != 1) {
                        output.encodeIntElement(serialDesc, 2, self.schemaVersion);
                    }
                }

/* 10 */        public final int getNewCardsPerDay() {
/* 11 */            return this.newCardsPerDay;
                }

/* 10 */        public final int getSchemaVersion() {
/* 11 */            return this.schemaVersion;
                }

/* 10 */        public final ThemeMode getThemeMode() {
/* 11 */            return this.themeMode;
                }
            }

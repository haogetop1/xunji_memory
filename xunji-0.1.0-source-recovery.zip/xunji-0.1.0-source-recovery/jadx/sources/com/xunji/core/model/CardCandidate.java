            package com.xunji.core.model;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0086\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0007HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001a"}, d2 = {"Lcom/xunji/core/model/CardCandidate;", "", "card", "Lcom/xunji/core/model/Flashcard;", "schedule", "Lcom/xunji/core/model/CardSchedule;", "deckName", "", "<init>", "(Lcom/xunji/core/model/Flashcard;Lcom/xunji/core/model/CardSchedule;Ljava/lang/String;)V", "getCard", "()Lcom/xunji/core/model/Flashcard;", "getSchedule", "()Lcom/xunji/core/model/CardSchedule;", "getDeckName", "()Ljava/lang/String;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 10 */    public final /* data */ class CardCandidate {
                private final Flashcard card;
                private final String deckName;
                private final CardSchedule schedule;

                public static /* synthetic */ CardCandidate copy$default(CardCandidate cardCandidate, Flashcard flashcard, CardSchedule cardSchedule, String str, int i, Object obj) {
                    if ((i & 1) != 0) {
                        flashcard = cardCandidate.card;
                    }
                    if ((i & 2) != 0) {
                        cardSchedule = cardCandidate.schedule;
                    }
                    if ((i & 4) != 0) {
                        str = cardCandidate.deckName;
                    }
                    return cardCandidate.copy(flashcard, cardSchedule, str);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final Flashcard getCard() {
                    return this.card;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final CardSchedule getSchedule() {
                    return this.schedule;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getDeckName() {
                    return this.deckName;
                }

                public final CardCandidate copy(Flashcard card, CardSchedule schedule, String deckName) {
                    Intrinsics.checkNotNullParameter(card, "card");
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(deckName, "deckName");
                    return new CardCandidate(card, schedule, deckName);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof CardCandidate)) {
                        return false;
                    }
                    CardCandidate cardCandidate = (CardCandidate) other;
                    return Intrinsics.areEqual(this.card, cardCandidate.card) && Intrinsics.areEqual(this.schedule, cardCandidate.schedule) && Intrinsics.areEqual(this.deckName, cardCandidate.deckName);
                }

                public int hashCode() {
                    return (((this.card.hashCode() * 31) + this.schedule.hashCode()) * 31) + this.deckName.hashCode();
                }

                public String toString() {
                    return "CardCandidate(card=" + this.card + ", schedule=" + this.schedule + ", deckName=" + this.deckName + ")";
                }

/* 11 */        public CardCandidate(Flashcard card, CardSchedule schedule, String deckName) {
                    Intrinsics.checkNotNullParameter(card, "card");
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(deckName, "deckName");
                    this.card = card;
                    this.schedule = schedule;
                    this.deckName = deckName;
                }

/* 11 */        public final Flashcard getCard() {
/* 12 */            return this.card;
                }

/* 11 */        public final String getDeckName() {
/* 12 */            return this.deckName;
                }

/* 11 */        public final CardSchedule getSchedule() {
/* 12 */            return this.schedule;
                }
            }

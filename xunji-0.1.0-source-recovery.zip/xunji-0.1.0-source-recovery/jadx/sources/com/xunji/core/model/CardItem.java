            package com.xunji.core.model;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0010HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/xunji/core/model/CardItem;", "", "candidate", "Lcom/xunji/core/model/CardCandidate;", "<init>", "(Lcom/xunji/core/model/CardCandidate;)V", "getCandidate", "()Lcom/xunji/core/model/CardCandidate;", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */    public final /* data */ class CardItem {
                private final CardCandidate candidate;

                public static /* synthetic */ CardItem copy$default(CardItem cardItem, CardCandidate cardCandidate, int i, Object obj) {
                    if ((i & 1) != 0) {
                        cardCandidate = cardItem.candidate;
                    }
                    return cardItem.copy(cardCandidate);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final CardCandidate getCandidate() {
                    return this.candidate;
                }

                public final CardItem copy(CardCandidate candidate) {
                    Intrinsics.checkNotNullParameter(candidate, "candidate");
                    return new CardItem(candidate);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    return (other instanceof CardItem) && Intrinsics.areEqual(this.candidate, ((CardItem) other).candidate);
                }

                public int hashCode() {
                    return this.candidate.hashCode();
                }

                public String toString() {
                    return "CardItem(candidate=" + this.candidate + ")";
                }

/* 12 */        public CardItem(CardCandidate candidate) {
                    Intrinsics.checkNotNullParameter(candidate, "candidate");
                    this.candidate = candidate;
                }

/* 12 */        public final CardCandidate getCandidate() {
/* 13 */            return this.candidate;
                }
            }

            package com.xunji.core.model;

            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Lazy;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.DeserializationStrategy;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.builtins.BuiltinSerializersKt;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.DoubleSerializer;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/model/CardSchedule.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/model/CardSchedule;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 8 */     public final /* synthetic */ class CardSchedule$$serializer implements GeneratedSerializer<CardSchedule> {
                public static final CardSchedule$$serializer INSTANCE = new CardSchedule$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 10 */            PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.model.CardSchedule", INSTANCE, 9);
                    pluginGeneratedSerialDescriptor.addElement("cardId", false);
                    pluginGeneratedSerialDescriptor.addElement("phase", false);
                    pluginGeneratedSerialDescriptor.addElement("step", false);
                    pluginGeneratedSerialDescriptor.addElement("stability", false);
                    pluginGeneratedSerialDescriptor.addElement("difficulty", false);
                    pluginGeneratedSerialDescriptor.addElement("dueAt", false);
                    pluginGeneratedSerialDescriptor.addElement("lastReviewAt", false);
                    pluginGeneratedSerialDescriptor.addElement("firstReviewedAt", false);
                    pluginGeneratedSerialDescriptor.addElement("revision", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 9 */         private CardSchedule$$serializer() {
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 9 */         public final KSerializer<?>[] childSerializers() {
                    return new KSerializer[]{StringSerializer.INSTANCE, CardSchedule.$childSerializers[1].getValue(), BuiltinSerializersKt.getNullable(IntSerializer.INSTANCE), BuiltinSerializersKt.getNullable(DoubleSerializer.INSTANCE), BuiltinSerializersKt.getNullable(DoubleSerializer.INSTANCE), LongSerializer.INSTANCE, BuiltinSerializersKt.getNullable(LongSerializer.INSTANCE), BuiltinSerializersKt.getNullable(LongSerializer.INSTANCE), LongSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 9 */         public final CardSchedule deserialize(Decoder decoder) {
                    Double d;
                    Integer num;
                    Long l;
                    String str;
                    long j;
                    long jDecodeLongElement;
                    Long l2;
                    Phase phase;
                    Double d2;
                    int i;
                    char c;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 10 */            SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
/* 10 */            Lazy[] lazyArr = CardSchedule.$childSerializers;
                    int i2 = 7;
                    int i3 = 8;
                    String strDecodeStringElement = null;
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        String strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        Phase phase2 = (Phase) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, (DeserializationStrategy) lazyArr[1].getValue(), null);
                        num = (Integer) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, IntSerializer.INSTANCE, null);
                        Double d3 = (Double) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, DoubleSerializer.INSTANCE, null);
                        Double d4 = (Double) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 4, DoubleSerializer.INSTANCE, null);
                        long jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                        Long l3 = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 6, LongSerializer.INSTANCE, null);
                        str = strDecodeStringElement2;
                        l = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 7, LongSerializer.INSTANCE, null);
                        l2 = l3;
                        jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 8);
                        j = jDecodeLongElement2;
                        d = d3;
                        d2 = d4;
                        phase = phase2;
                        i = 511;
                    } else {
                        long jDecodeLongElement3 = 0;
                        boolean z = true;
                        int i4 = 0;
                        Long l4 = null;
                        Double d5 = null;
                        Long l5 = null;
                        Double d6 = null;
                        Integer num2 = null;
                        Phase phase3 = null;
                        long jDecodeLongElement4 = 0;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 0:
                                    strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i4 |= 1;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 1:
                                    phase3 = (Phase) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 1, (DeserializationStrategy) lazyArr[1].getValue(), phase3);
                                    i4 |= 2;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 2:
                                    num2 = (Integer) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 2, IntSerializer.INSTANCE, num2);
                                    i4 |= 4;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 3:
                                    d6 = (Double) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 3, DoubleSerializer.INSTANCE, d6);
                                    i4 |= 8;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 4:
                                    d5 = (Double) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 4, DoubleSerializer.INSTANCE, d5);
                                    i4 |= 16;
                                    i2 = 7;
                                    i3 = 8;
                                    break;
                                case 5:
                                    c = 6;
                                    jDecodeLongElement3 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                                    i4 |= 32;
                                    i2 = 7;
                                    break;
                                case 6:
                                    c = 6;
                                    l5 = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 6, LongSerializer.INSTANCE, l5);
                                    i4 |= 64;
                                    i2 = 7;
                                    break;
                                case 7:
                                    l4 = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, i2, LongSerializer.INSTANCE, l4);
                                    i4 |= 128;
                                    break;
                                case 8:
                                    jDecodeLongElement4 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, i3);
                                    i4 |= 256;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        Integer num3 = num2;
                        d = d6;
                        num = num3;
                        l = l4;
                        str = strDecodeStringElement;
                        j = jDecodeLongElement3;
                        jDecodeLongElement = jDecodeLongElement4;
                        l2 = l5;
                        phase = phase3;
                        d2 = d5;
                        i = i4;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new CardSchedule(i, str, phase, num, d, d2, j, l2, l, jDecodeLongElement, null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 9 */         public final void serialize(Encoder encoder, CardSchedule value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 10 */            SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    CardSchedule.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 9 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 10 */            return super.typeParametersSerializers();
                }
            }

            package com.xunji.core.model;

            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.DoubleSerializer;
            import kotlinx.serialization.internal.IntSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u001f\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 A2\u00020\u0001:\u0002@ABY\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\b\u0010\r\u001a\u0004\u0018\u00010\f\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\f\u0012\u0006\u0010\u000f\u001a\u00020\f¢\u0006\u0004\b\u0010\u0010\u0011Bq\b\u0010\u0012\u0006\u0010\u0012\u001a\u00020\u0007\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007\u0012\b\u0010\b\u001a\u0004\u0018\u00010\t\u0012\b\u0010\n\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\u000b\u001a\u00020\f\u0012\b\u0010\r\u001a\u0004\u0018\u00010\f\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\f\u0012\u0006\u0010\u000f\u001a\u00020\f\u0012\b\u0010\u0013\u001a\u0004\u0018\u00010\u0014¢\u0006\u0004\b\u0010\u0010\u0015J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\t\u0010)\u001a\u00020\u0005HÆ\u0003J\u0010\u0010*\u001a\u0004\u0018\u00010\u0007HÆ\u0003¢\u0006\u0002\u0010\u001bJ\u0010\u0010+\u001a\u0004\u0018\u00010\tHÆ\u0003¢\u0006\u0002\u0010\u001eJ\u0010\u0010,\u001a\u0004\u0018\u00010\tHÆ\u0003¢\u0006\u0002\u0010\u001eJ\t\u0010-\u001a\u00020\fHÆ\u0003J\u0010\u0010.\u001a\u0004\u0018\u00010\fHÆ\u0003¢\u0006\u0002\u0010$J\u0010\u0010/\u001a\u0004\u0018\u00010\fHÆ\u0003¢\u0006\u0002\u0010$J\t\u00100\u001a\u00020\fHÆ\u0003Jr\u00101\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\t2\b\b\u0002\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\f2\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\f2\b\b\u0002\u0010\u000f\u001a\u00020\fHÆ\u0001¢\u0006\u0002\u00102J\u0013\u00103\u001a\u0002042\b\u00105\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00106\u001a\u00020\u0007HÖ\u0001J\t\u00107\u001a\u00020\u0003HÖ\u0001J%\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u00002\u0006\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020>H\u0001¢\u0006\u0002\b?R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0015\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\n\n\u0002\u0010\u001c\u001a\u0004\b\u001a\u0010\u001bR\u0015\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001eR\u0015\u0010\n\u001a\u0004\u0018\u00010\t¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b \u0010\u001eR\u0011\u0010\u000b\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0015\u0010\r\u001a\u0004\u0018\u00010\f¢\u0006\n\n\u0002\u0010%\u001a\u0004\b#\u0010$R\u0015\u0010\u000e\u001a\u0004\u0018\u00010\f¢\u0006\n\n\u0002\u0010%\u001a\u0004\b&\u0010$R\u0011\u0010\u000f\u001a\u00020\f¢\u0006\b\n\u0000\u001a\u0004\b'\u0010\"¨\u0006B"}, d2 = {"Lcom/xunji/core/model/CardSchedule;", "", "cardId", "", "phase", "Lcom/xunji/core/model/Phase;", "step", "", "stability", "", "difficulty", "dueAt", "", "lastReviewAt", "firstReviewedAt", "revision", "<init>", "(Ljava/lang/String;Lcom/xunji/core/model/Phase;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;JLjava/lang/Long;Ljava/lang/Long;J)V", "seen0", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Lcom/xunji/core/model/Phase;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;JLjava/lang/Long;Ljava/lang/Long;JLkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getCardId", "()Ljava/lang/String;", "getPhase", "()Lcom/xunji/core/model/Phase;", "getStep", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getStability", "()Ljava/lang/Double;", "Ljava/lang/Double;", "getDifficulty", "getDueAt", "()J", "getLastReviewAt", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getFirstReviewedAt", "getRevision", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(Ljava/lang/String;Lcom/xunji/core/model/Phase;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;JLjava/lang/Long;Ljava/lang/Long;J)Lcom/xunji/core/model/CardSchedule;", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 7 */     public final /* data */ class CardSchedule {
                private final String cardId;
                private final Double difficulty;
                private final long dueAt;
                private final Long firstReviewedAt;
                private final Long lastReviewAt;
                private final Phase phase;
                private final long revision;
                private final Double stability;
                private final Integer step;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.model.CardSchedule$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return CardSchedule._childSerializers$_anonymous_();
                    }
                }), null, null, null, null, null, null, null};

                public static /* synthetic */ CardSchedule copy$default(CardSchedule cardSchedule, String str, Phase phase, Integer num, Double d, Double d2, long j, Long l, Long l2, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = cardSchedule.cardId;
                    }
                    if ((i & 2) != 0) {
                        phase = cardSchedule.phase;
                    }
                    if ((i & 4) != 0) {
                        num = cardSchedule.step;
                    }
                    if ((i & 8) != 0) {
                        d = cardSchedule.stability;
                    }
                    if ((i & 16) != 0) {
                        d2 = cardSchedule.difficulty;
                    }
                    if ((i & 32) != 0) {
                        j = cardSchedule.dueAt;
                    }
                    if ((i & 64) != 0) {
                        l = cardSchedule.lastReviewAt;
                    }
                    if ((i & 128) != 0) {
                        l2 = cardSchedule.firstReviewedAt;
                    }
                    if ((i & 256) != 0) {
                        j2 = cardSchedule.revision;
                    }
                    long j3 = j;
                    Double d3 = d;
                    Double d4 = d2;
                    Integer num2 = num;
                    return cardSchedule.copy(str, phase, num2, d3, d4, j3, l, l2, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final Phase getPhase() {
                    return this.phase;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final Integer getStep() {
                    return this.step;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final Double getStability() {
                    return this.stability;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final Double getDifficulty() {
                    return this.difficulty;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getDueAt() {
                    return this.dueAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final Long getLastReviewAt() {
                    return this.lastReviewAt;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final Long getFirstReviewedAt() {
                    return this.firstReviewedAt;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final long getRevision() {
                    return this.revision;
                }

                public final CardSchedule copy(String cardId, Phase phase, Integer step, Double stability, Double difficulty, long dueAt, Long lastReviewAt, Long firstReviewedAt, long revision) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(phase, "phase");
                    return new CardSchedule(cardId, phase, step, stability, difficulty, dueAt, lastReviewAt, firstReviewedAt, revision);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof CardSchedule)) {
                        return false;
                    }
                    CardSchedule cardSchedule = (CardSchedule) other;
                    return Intrinsics.areEqual(this.cardId, cardSchedule.cardId) && this.phase == cardSchedule.phase && Intrinsics.areEqual(this.step, cardSchedule.step) && Intrinsics.areEqual((Object) this.stability, (Object) cardSchedule.stability) && Intrinsics.areEqual((Object) this.difficulty, (Object) cardSchedule.difficulty) && this.dueAt == cardSchedule.dueAt && Intrinsics.areEqual(this.lastReviewAt, cardSchedule.lastReviewAt) && Intrinsics.areEqual(this.firstReviewedAt, cardSchedule.firstReviewedAt) && this.revision == cardSchedule.revision;
                }

                public int hashCode() {
                    return (((((((((((((((this.cardId.hashCode() * 31) + this.phase.hashCode()) * 31) + (this.step == null ? 0 : this.step.hashCode())) * 31) + (this.stability == null ? 0 : this.stability.hashCode())) * 31) + (this.difficulty == null ? 0 : this.difficulty.hashCode())) * 31) + Long.hashCode(this.dueAt)) * 31) + (this.lastReviewAt == null ? 0 : this.lastReviewAt.hashCode())) * 31) + (this.firstReviewedAt != null ? this.firstReviewedAt.hashCode() : 0)) * 31) + Long.hashCode(this.revision);
                }

                public String toString() {
                    return "CardSchedule(cardId=" + this.cardId + ", phase=" + this.phase + ", step=" + this.step + ", stability=" + this.stability + ", difficulty=" + this.difficulty + ", dueAt=" + this.dueAt + ", lastReviewAt=" + this.lastReviewAt + ", firstReviewedAt=" + this.firstReviewedAt + ", revision=" + this.revision + ")";
                }

                /* JADX INFO: compiled from: Models.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/CardSchedule$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/CardSchedule;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */         public static final class Companion {
/* 9 */             private Companion() {
                    }

/* 9 */             public final KSerializer<CardSchedule> serializer() {
/* 10 */                return CardSchedule$$serializer.INSTANCE;
                    }
                }

/* 9 */         public /* synthetic */ CardSchedule(int seen0, String cardId, Phase phase, Integer step, Double stability, Double difficulty, long dueAt, Long lastReviewAt, Long firstReviewedAt, long revision, SerializationConstructorMarker serializationConstructorMarker) {
/* 10 */            if (511 != (seen0 & 511)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, 511, CardSchedule$$serializer.INSTANCE.getDescriptor());
                    }
                    this.cardId = cardId;
                    this.phase = phase;
                    this.step = step;
                    this.stability = stability;
                    this.difficulty = difficulty;
                    this.dueAt = dueAt;
                    this.lastReviewAt = lastReviewAt;
                    this.firstReviewedAt = firstReviewedAt;
                    this.revision = revision;
                }

/* 9 */         public CardSchedule(String cardId, Phase phase, Integer step, Double stability, Double difficulty, long dueAt, Long lastReviewAt, Long firstReviewedAt, long revision) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(phase, "phase");
                    this.cardId = cardId;
                    this.phase = phase;
                    this.step = step;
                    this.stability = stability;
                    this.difficulty = difficulty;
                    this.dueAt = dueAt;
                    this.lastReviewAt = lastReviewAt;
                    this.firstReviewedAt = firstReviewedAt;
                    this.revision = revision;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 9 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
                    return Phase.INSTANCE.serializer();
                }

                @JvmStatic
/* 9 */         public static final /* synthetic */ void write$Self$core(CardSchedule self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 10 */            Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
                    output.encodeStringElement(serialDesc, 0, self.cardId);
                    output.encodeSerializableElement(serialDesc, 1, lazyArr[1].getValue(), self.phase);
                    output.encodeNullableSerializableElement(serialDesc, 2, IntSerializer.INSTANCE, self.step);
                    output.encodeNullableSerializableElement(serialDesc, 3, DoubleSerializer.INSTANCE, self.stability);
                    output.encodeNullableSerializableElement(serialDesc, 4, DoubleSerializer.INSTANCE, self.difficulty);
                    output.encodeLongElement(serialDesc, 5, self.dueAt);
                    output.encodeNullableSerializableElement(serialDesc, 6, LongSerializer.INSTANCE, self.lastReviewAt);
                    output.encodeNullableSerializableElement(serialDesc, 7, LongSerializer.INSTANCE, self.firstReviewedAt);
                    output.encodeLongElement(serialDesc, 8, self.revision);
                }

/* 9 */         public final String getCardId() {
/* 10 */            return this.cardId;
                }

/* 9 */         public final Double getDifficulty() {
/* 10 */            return this.difficulty;
                }

/* 9 */         public final long getDueAt() {
/* 10 */            return this.dueAt;
                }

/* 9 */         public final Long getFirstReviewedAt() {
/* 10 */            return this.firstReviewedAt;
                }

/* 9 */         public final Long getLastReviewAt() {
/* 10 */            return this.lastReviewAt;
                }

/* 9 */         public final Phase getPhase() {
/* 10 */            return this.phase;
                }

/* 9 */         public final long getRevision() {
/* 10 */            return this.revision;
                }

/* 9 */         public final Double getStability() {
/* 10 */            return this.stability;
                }

/* 9 */         public final Integer getStep() {
/* 10 */            return this.step;
                }
            }

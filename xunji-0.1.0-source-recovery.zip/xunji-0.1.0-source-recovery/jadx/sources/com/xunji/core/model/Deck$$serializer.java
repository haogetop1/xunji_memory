            package com.xunji.core.model;

            import androidx.autofill.HintConstants;
            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/model/Deck.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/model/Deck;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 6 */     public final /* synthetic */ class Deck$$serializer implements GeneratedSerializer<Deck> {
                public static final Deck$$serializer INSTANCE = new Deck$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 8 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.model.Deck", INSTANCE, 4);
                    pluginGeneratedSerialDescriptor.addElement("id", false);
                    pluginGeneratedSerialDescriptor.addElement(HintConstants.AUTOFILL_HINT_NAME, false);
                    pluginGeneratedSerialDescriptor.addElement("createdAt", false);
                    pluginGeneratedSerialDescriptor.addElement("updatedAt", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 7 */         private Deck$$serializer() {
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 7 */         public final KSerializer<?>[] childSerializers() {
/* 8 */             return new KSerializer[]{StringSerializer.INSTANCE, StringSerializer.INSTANCE, LongSerializer.INSTANCE, LongSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 7 */         public final Deck deserialize(Decoder decoder) {
                    long jDecodeLongElement;
                    String str;
                    String strDecodeStringElement;
                    long jDecodeLongElement2;
                    int i;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 8 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        String strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        str = strDecodeStringElement2;
                        strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                        jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                        i = 15;
                        jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 3);
                    } else {
                        String strDecodeStringElement3 = null;
                        jDecodeLongElement = 0;
                        String strDecodeStringElement4 = null;
                        boolean z = true;
                        int i2 = 0;
                        long jDecodeLongElement3 = 0;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    break;
                                case 0:
                                    strDecodeStringElement3 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i2 |= 1;
                                    break;
                                case 1:
                                    strDecodeStringElement4 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                                    i2 |= 2;
                                    break;
                                case 2:
                                    jDecodeLongElement3 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 2);
                                    i2 |= 4;
                                    break;
                                case 3:
                                    jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 3);
                                    i2 |= 8;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        str = strDecodeStringElement3;
                        strDecodeStringElement = strDecodeStringElement4;
                        jDecodeLongElement2 = jDecodeLongElement3;
                        i = i2;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new Deck(i, str, strDecodeStringElement, jDecodeLongElement2, jDecodeLongElement, null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 7 */         public final void serialize(Encoder encoder, Deck value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 8 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    Deck.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 7 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 8 */             return super.typeParametersSerializers();
                }
            }

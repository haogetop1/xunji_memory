            package com.xunji.core.model;

            import androidx.autofill.HintConstants;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 (2\u00020\u0001:\u0002'(B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tB?\b\u0010\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\b\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\u0004\b\b\u0010\u000eJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0006HÆ\u0003J1\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u0006HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u000bHÖ\u0001J\t\u0010\u001e\u001a\u00020\u0003HÖ\u0001J%\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\u00002\u0006\u0010\"\u001a\u00020#2\u0006\u0010$\u001a\u00020%H\u0001¢\u0006\u0002\b&R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013¨\u0006)"}, d2 = {"Lcom/xunji/core/model/Deck;", "", "id", "", HintConstants.AUTOFILL_HINT_NAME, "createdAt", "", "updatedAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;JJ)V", "seen0", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/lang/String;JJLkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getId", "()Ljava/lang/String;", "getName", "getCreatedAt", "()J", "getUpdatedAt", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 5 */     public final /* data */ class Deck {

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private final long createdAt;
                private final String id;
                private final String name;
                private final long updatedAt;

                public static /* synthetic */ Deck copy$default(Deck deck, String str, String str2, long j, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = deck.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = deck.name;
                    }
                    if ((i & 4) != 0) {
                        j = deck.createdAt;
                    }
                    if ((i & 8) != 0) {
                        j2 = deck.updatedAt;
                    }
                    long j3 = j2;
                    return deck.copy(str, str2, j, j3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getCreatedAt() {
                    return this.createdAt;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final long getUpdatedAt() {
                    return this.updatedAt;
                }

                public final Deck copy(String id, String name, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(name, "name");
                    return new Deck(id, name, createdAt, updatedAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof Deck)) {
                        return false;
                    }
                    Deck deck = (Deck) other;
                    return Intrinsics.areEqual(this.id, deck.id) && Intrinsics.areEqual(this.name, deck.name) && this.createdAt == deck.createdAt && this.updatedAt == deck.updatedAt;
                }

                public int hashCode() {
                    return (((((this.id.hashCode() * 31) + this.name.hashCode()) * 31) + Long.hashCode(this.createdAt)) * 31) + Long.hashCode(this.updatedAt);
                }

                public String toString() {
                    return "Deck(id=" + this.id + ", name=" + this.name + ", createdAt=" + this.createdAt + ", updatedAt=" + this.updatedAt + ")";
                }

                /* JADX INFO: compiled from: Models.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/Deck$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/Deck;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */         public static final class Companion {
/* 7 */             private Companion() {
                    }

/* 7 */             public final KSerializer<Deck> serializer() {
/* 8 */                 return Deck$$serializer.INSTANCE;
                    }
                }

/* 7 */         public /* synthetic */ Deck(int seen0, String id, String name, long createdAt, long updatedAt, SerializationConstructorMarker serializationConstructorMarker) {
/* 8 */             if (15 != (seen0 & 15)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, 15, Deck$$serializer.INSTANCE.getDescriptor());
                    }
                    this.id = id;
                    this.name = name;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

/* 7 */         public Deck(String id, String name, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(name, "name");
                    this.id = id;
                    this.name = name;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

                @JvmStatic
/* 7 */         public static final /* synthetic */ void write$Self$core(Deck self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 8 */             output.encodeStringElement(serialDesc, 0, self.id);
                    output.encodeStringElement(serialDesc, 1, self.name);
                    output.encodeLongElement(serialDesc, 2, self.createdAt);
                    output.encodeLongElement(serialDesc, 3, self.updatedAt);
                }

/* 7 */         public final long getCreatedAt() {
/* 8 */             return this.createdAt;
                }

/* 7 */         public final String getId() {
/* 8 */             return this.id;
                }

/* 7 */         public final String getName() {
/* 8 */             return this.name;
                }

/* 7 */         public final long getUpdatedAt() {
/* 8 */             return this.updatedAt;
                }
            }

            package com.xunji.core.model;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0010\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0005HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\rR\u0011\u0010\u0007\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\r¨\u0006\u001b"}, d2 = {"Lcom/xunji/core/model/DeckSummary;", "", "deck", "Lcom/xunji/core/model/Deck;", "total", "", "due", "newCards", "<init>", "(Lcom/xunji/core/model/Deck;III)V", "getDeck", "()Lcom/xunji/core/model/Deck;", "getTotal", "()I", "getDue", "getNewCards", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public final /* data */ class DeckSummary {
                private final Deck deck;
                private final int due;
                private final int newCards;
                private final int total;

                public static /* synthetic */ DeckSummary copy$default(DeckSummary deckSummary, Deck deck, int i, int i2, int i3, int i4, Object obj) {
                    if ((i4 & 1) != 0) {
                        deck = deckSummary.deck;
                    }
                    if ((i4 & 2) != 0) {
                        i = deckSummary.total;
                    }
                    if ((i4 & 4) != 0) {
                        i2 = deckSummary.due;
                    }
                    if ((i4 & 8) != 0) {
                        i3 = deckSummary.newCards;
                    }
                    return deckSummary.copy(deck, i, i2, i3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final Deck getDeck() {
                    return this.deck;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getTotal() {
                    return this.total;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getDue() {
                    return this.due;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getNewCards() {
                    return this.newCards;
                }

                public final DeckSummary copy(Deck deck, int total, int due, int newCards) {
                    Intrinsics.checkNotNullParameter(deck, "deck");
                    return new DeckSummary(deck, total, due, newCards);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof DeckSummary)) {
                        return false;
                    }
                    DeckSummary deckSummary = (DeckSummary) other;
                    return Intrinsics.areEqual(this.deck, deckSummary.deck) && this.total == deckSummary.total && this.due == deckSummary.due && this.newCards == deckSummary.newCards;
                }

                public int hashCode() {
                    return (((((this.deck.hashCode() * 31) + Integer.hashCode(this.total)) * 31) + Integer.hashCode(this.due)) * 31) + Integer.hashCode(this.newCards);
                }

                public String toString() {
                    return "DeckSummary(deck=" + this.deck + ", total=" + this.total + ", due=" + this.due + ", newCards=" + this.newCards + ")";
                }

/* 13 */        public DeckSummary(Deck deck, int total, int due, int newCards) {
                    Intrinsics.checkNotNullParameter(deck, "deck");
                    this.deck = deck;
                    this.total = total;
                    this.due = due;
                    this.newCards = newCards;
                }

/* 13 */        public final Deck getDeck() {
/* 14 */            return this.deck;
                }

/* 13 */        public final int getDue() {
/* 14 */            return this.due;
                }

/* 13 */        public final int getNewCards() {
/* 14 */            return this.newCards;
                }

/* 13 */        public final int getTotal() {
/* 14 */            return this.total;
                }
            }

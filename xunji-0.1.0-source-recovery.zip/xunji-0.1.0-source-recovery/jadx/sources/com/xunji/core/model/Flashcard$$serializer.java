            package com.xunji.core.model;

            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/model/Flashcard.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/model/Flashcard;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 7 */     public final /* synthetic */ class Flashcard$$serializer implements GeneratedSerializer<Flashcard> {
                public static final Flashcard$$serializer INSTANCE = new Flashcard$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 9 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.model.Flashcard", INSTANCE, 7);
                    pluginGeneratedSerialDescriptor.addElement("id", false);
                    pluginGeneratedSerialDescriptor.addElement("deckId", false);
                    pluginGeneratedSerialDescriptor.addElement("front", false);
                    pluginGeneratedSerialDescriptor.addElement("back", false);
                    pluginGeneratedSerialDescriptor.addElement("example", false);
                    pluginGeneratedSerialDescriptor.addElement("createdAt", false);
                    pluginGeneratedSerialDescriptor.addElement("updatedAt", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 8 */         private Flashcard$$serializer() {
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 8 */         public final KSerializer<?>[] childSerializers() {
/* 9 */             return new KSerializer[]{StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, LongSerializer.INSTANCE, LongSerializer.INSTANCE};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 8 */         public final Flashcard deserialize(Decoder decoder) {
                    String strDecodeStringElement;
                    String strDecodeStringElement2;
                    long j;
                    int i;
                    long j2;
                    String str;
                    String str2;
                    String str3;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 9 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        String strDecodeStringElement3 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                        String strDecodeStringElement4 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                        String strDecodeStringElement5 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                        String strDecodeStringElement6 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 4);
                        long jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                        long jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                        i = WorkQueueKt.MASK;
                        j = jDecodeLongElement2;
                        str3 = strDecodeStringElement5;
                        str = strDecodeStringElement6;
                        strDecodeStringElement2 = strDecodeStringElement4;
                        str2 = strDecodeStringElement3;
                        j2 = jDecodeLongElement;
                    } else {
                        strDecodeStringElement = null;
                        long jDecodeLongElement3 = 0;
                        String strDecodeStringElement7 = null;
                        String strDecodeStringElement8 = null;
                        strDecodeStringElement2 = null;
                        String strDecodeStringElement9 = null;
                        boolean z = true;
                        int i2 = 0;
                        long jDecodeLongElement4 = 0;
                        while (z) {
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    continue;
                                case 0:
                                    strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i2 |= 1;
                                    continue;
                                case 1:
                                    strDecodeStringElement9 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                                    i2 |= 2;
                                    break;
                                case 2:
                                    strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                                    i2 |= 4;
                                    break;
                                case 3:
                                    strDecodeStringElement7 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                                    i2 |= 8;
                                    break;
                                case 4:
                                    strDecodeStringElement8 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 4);
                                    i2 |= 16;
                                    break;
                                case 5:
                                    jDecodeLongElement4 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                                    i2 |= 32;
                                    break;
                                case 6:
                                    jDecodeLongElement3 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                                    i2 |= 64;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        j = jDecodeLongElement3;
                        i = i2;
                        j2 = jDecodeLongElement4;
                        str = strDecodeStringElement8;
                        str2 = strDecodeStringElement9;
                        str3 = strDecodeStringElement7;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new Flashcard(i, strDecodeStringElement, str2, strDecodeStringElement2, str3, str, j2, j, null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 8 */         public final void serialize(Encoder encoder, Flashcard value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 9 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    Flashcard.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 8 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 9 */             return super.typeParametersSerializers();
                }
            }

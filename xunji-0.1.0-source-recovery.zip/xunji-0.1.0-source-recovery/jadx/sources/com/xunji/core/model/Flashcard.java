            package com.xunji.core.model;

            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 12\u00020\u0001:\u000201B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fB]\b\u0010\u0012\u0006\u0010\r\u001a\u00020\u000e\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\u0010¢\u0006\u0004\b\u000b\u0010\u0011J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\tHÆ\u0003J\t\u0010!\u001a\u00020\tHÆ\u0003JO\u0010\"\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\tHÆ\u0001J\u0013\u0010#\u001a\u00020$2\b\u0010%\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010&\u001a\u00020\u000eHÖ\u0001J\t\u0010'\u001a\u00020\u0003HÖ\u0001J%\u0010(\u001a\u00020)2\u0006\u0010*\u001a\u00020\u00002\u0006\u0010+\u001a\u00020,2\u0006\u0010-\u001a\u00020.H\u0001¢\u0006\u0002\b/R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0013R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\n\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019¨\u00062"}, d2 = {"Lcom/xunji/core/model/Flashcard;", "", "id", "", "deckId", "front", "back", "example", "createdAt", "", "updatedAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V", "seen0", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJLkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getId", "()Ljava/lang/String;", "getDeckId", "getFront", "getBack", "getExample", "getCreatedAt", "()J", "getUpdatedAt", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 6 */     public final /* data */ class Flashcard {

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private final String back;
                private final long createdAt;
                private final String deckId;
                private final String example;
                private final String front;
                private final String id;
                private final long updatedAt;

                public static /* synthetic */ Flashcard copy$default(Flashcard flashcard, String str, String str2, String str3, String str4, String str5, long j, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = flashcard.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = flashcard.deckId;
                    }
                    if ((i & 4) != 0) {
                        str3 = flashcard.front;
                    }
                    if ((i & 8) != 0) {
                        str4 = flashcard.back;
                    }
                    if ((i & 16) != 0) {
                        str5 = flashcard.example;
                    }
                    if ((i & 32) != 0) {
                        j = flashcard.createdAt;
                    }
                    if ((i & 64) != 0) {
                        j2 = flashcard.updatedAt;
                    }
                    long j3 = j2;
                    long j4 = j;
                    String str6 = str5;
                    String str7 = str3;
                    return flashcard.copy(str, str2, str7, str4, str6, j4, j3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getDeckId() {
                    return this.deckId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getFront() {
                    return this.front;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getBack() {
                    return this.back;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getExample() {
                    return this.example;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getCreatedAt() {
                    return this.createdAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getUpdatedAt() {
                    return this.updatedAt;
                }

                public final Flashcard copy(String id, String deckId, String front, String back, String example, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
                    return new Flashcard(id, deckId, front, back, example, createdAt, updatedAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof Flashcard)) {
                        return false;
                    }
                    Flashcard flashcard = (Flashcard) other;
                    return Intrinsics.areEqual(this.id, flashcard.id) && Intrinsics.areEqual(this.deckId, flashcard.deckId) && Intrinsics.areEqual(this.front, flashcard.front) && Intrinsics.areEqual(this.back, flashcard.back) && Intrinsics.areEqual(this.example, flashcard.example) && this.createdAt == flashcard.createdAt && this.updatedAt == flashcard.updatedAt;
                }

                public int hashCode() {
                    return (((((((((((this.id.hashCode() * 31) + this.deckId.hashCode()) * 31) + this.front.hashCode()) * 31) + this.back.hashCode()) * 31) + this.example.hashCode()) * 31) + Long.hashCode(this.createdAt)) * 31) + Long.hashCode(this.updatedAt);
                }

                public String toString() {
                    return "Flashcard(id=" + this.id + ", deckId=" + this.deckId + ", front=" + this.front + ", back=" + this.back + ", example=" + this.example + ", createdAt=" + this.createdAt + ", updatedAt=" + this.updatedAt + ")";
                }

                /* JADX INFO: compiled from: Models.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/Flashcard$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/Flashcard;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */         public static final class Companion {
/* 8 */             private Companion() {
                    }

/* 8 */             public final KSerializer<Flashcard> serializer() {
/* 9 */                 return Flashcard$$serializer.INSTANCE;
                    }
                }

/* 8 */         public /* synthetic */ Flashcard(int seen0, String id, String deckId, String front, String back, String example, long createdAt, long updatedAt, SerializationConstructorMarker serializationConstructorMarker) {
/* 9 */             if (127 != (seen0 & WorkQueueKt.MASK)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, WorkQueueKt.MASK, Flashcard$$serializer.INSTANCE.getDescriptor());
                    }
                    this.id = id;
                    this.deckId = deckId;
                    this.front = front;
                    this.back = back;
                    this.example = example;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

/* 8 */         public Flashcard(String id, String deckId, String front, String back, String example, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
                    this.id = id;
                    this.deckId = deckId;
                    this.front = front;
                    this.back = back;
                    this.example = example;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

                @JvmStatic
/* 8 */         public static final /* synthetic */ void write$Self$core(Flashcard self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 9 */             output.encodeStringElement(serialDesc, 0, self.id);
                    output.encodeStringElement(serialDesc, 1, self.deckId);
                    output.encodeStringElement(serialDesc, 2, self.front);
                    output.encodeStringElement(serialDesc, 3, self.back);
                    output.encodeStringElement(serialDesc, 4, self.example);
                    output.encodeLongElement(serialDesc, 5, self.createdAt);
                    output.encodeLongElement(serialDesc, 6, self.updatedAt);
                }

/* 8 */         public final String getBack() {
/* 9 */             return this.back;
                }

/* 8 */         public final long getCreatedAt() {
/* 9 */             return this.createdAt;
                }

/* 8 */         public final String getDeckId() {
/* 9 */             return this.deckId;
                }

/* 8 */         public final String getExample() {
/* 9 */             return this.example;
                }

/* 8 */         public final String getFront() {
/* 9 */             return this.front;
                }

/* 8 */         public final String getId() {
/* 9 */             return this.id;
                }

/* 8 */         public final long getUpdatedAt() {
/* 9 */             return this.updatedAt;
                }
            }

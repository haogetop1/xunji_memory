            package com.xunji.core.model;

            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.enums.EnumEntries;
            import kotlin.enums.EnumEntriesKt;
            import kotlin.jvm.functions.Function0;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.internal.EnumsKt;
            
            /* JADX INFO: compiled from: Models.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\b\b\u0087\u0081\u0002\u0018\u0000 \b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\bB\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\t"}, d2 = {"Lcom/xunji/core/model/Rating;", "", "<init>", "(Ljava/lang/String;I)V", "AGAIN", "HARD", "GOOD", "EASY", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 3 */     public enum Rating {
                AGAIN,
                HARD,
                GOOD,
                EASY;

                private static final /* synthetic */ EnumEntries $ENTRIES = EnumEntriesKt.enumEntries($VALUES);

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>> $cachedSerializer$delegate = LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.model.Rating$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return Rating._init_$_anonymous_();
                    }
                });

                public static EnumEntries<Rating> getEntries() {
                    return $ENTRIES;
                }

                /* JADX INFO: compiled from: Models.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/Rating$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/Rating;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */         public static final class Companion {
/* 5 */             private Companion() {
                    }

/* 5 */             private final /* synthetic */ KSerializer get$cachedSerializer() {
/* 6 */                 return (KSerializer) Rating.$cachedSerializer$delegate.getValue();
                    }

/* 5 */             public final KSerializer<Rating> serializer() {
/* 6 */                 return get$cachedSerializer();
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 5 */         public static final /* synthetic */ KSerializer _init_$_anonymous_() {
/* 6 */             return EnumsKt.createSimpleEnumSerializer("com.xunji.core.model.Rating", values());
                }
            }

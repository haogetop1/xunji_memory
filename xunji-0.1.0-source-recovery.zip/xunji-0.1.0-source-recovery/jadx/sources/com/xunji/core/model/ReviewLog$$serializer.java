            package com.xunji.core.model;

            import kotlin.Deprecated;
            import kotlin.DeprecationLevel;
            import kotlin.Lazy;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.DeserializationStrategy;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.UnknownFieldException;
            import kotlinx.serialization.builtins.BuiltinSerializersKt;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeDecoder;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.encoding.Decoder;
            import kotlinx.serialization.encoding.Encoder;
            import kotlinx.serialization.internal.GeneratedSerializer;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginGeneratedSerialDescriptor;
            import kotlinx.serialization.internal.StringSerializer;
            
            /* JADX INFO: compiled from: ReviewLog.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00070\u0006¢\u0006\u0002\u0010\bJ\u000e\u0010\t\u001a\u00020\u00022\u0006\u0010\n\u001a\u00020\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u0002R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"com/xunji/core/model/ReviewLog.$serializer", "Lkotlinx/serialization/internal/GeneratedSerializer;", "Lcom/xunji/core/model/ReviewLog;", "<init>", "()V", "childSerializers", "", "Lkotlinx/serialization/KSerializer;", "()[Lkotlinx/serialization/KSerializer;", "deserialize", "decoder", "Lkotlinx/serialization/encoding/Decoder;", "serialize", "", "encoder", "Lkotlinx/serialization/encoding/Encoder;", "value", "descriptor", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "getDescriptor", "()Lkotlinx/serialization/descriptors/SerialDescriptor;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Deprecated(level = DeprecationLevel.HIDDEN, message = "This synthesized declaration should not be used directly")
/* 3 */     public final /* synthetic */ class ReviewLog$$serializer implements GeneratedSerializer<ReviewLog> {
                public static final ReviewLog$$serializer INSTANCE = new ReviewLog$$serializer();
                private static final SerialDescriptor descriptor;

                @Override // kotlinx.serialization.KSerializer, kotlinx.serialization.SerializationStrategy, kotlinx.serialization.DeserializationStrategy
                public final SerialDescriptor getDescriptor() {
                    return descriptor;
                }

                static {
/* 5 */             PluginGeneratedSerialDescriptor pluginGeneratedSerialDescriptor = new PluginGeneratedSerialDescriptor("com.xunji.core.model.ReviewLog", INSTANCE, 10);
                    pluginGeneratedSerialDescriptor.addElement("id", false);
                    pluginGeneratedSerialDescriptor.addElement("cardId", false);
                    pluginGeneratedSerialDescriptor.addElement("deckId", false);
                    pluginGeneratedSerialDescriptor.addElement("sessionId", false);
                    pluginGeneratedSerialDescriptor.addElement("rating", false);
                    pluginGeneratedSerialDescriptor.addElement("reviewedAt", false);
                    pluginGeneratedSerialDescriptor.addElement("durationMs", false);
                    pluginGeneratedSerialDescriptor.addElement("beforeSchedule", false);
                    pluginGeneratedSerialDescriptor.addElement("afterSchedule", false);
                    pluginGeneratedSerialDescriptor.addElement("undoneAt", false);
                    descriptor = pluginGeneratedSerialDescriptor;
                }

/* 4 */         private ReviewLog$$serializer() {
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 4 */         public final KSerializer<?>[] childSerializers() {
                    return new KSerializer[]{StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, StringSerializer.INSTANCE, ReviewLog.$childSerializers[4].getValue(), LongSerializer.INSTANCE, LongSerializer.INSTANCE, CardSchedule$$serializer.INSTANCE, CardSchedule$$serializer.INSTANCE, BuiltinSerializersKt.getNullable(LongSerializer.INSTANCE)};
                }

                @Override // kotlinx.serialization.DeserializationStrategy
/* 4 */         public final ReviewLog deserialize(Decoder decoder) {
                    CardSchedule cardSchedule;
                    long j;
                    String str;
                    String str2;
                    String str3;
                    long j2;
                    Long l;
                    CardSchedule cardSchedule2;
                    Rating rating;
                    int i;
                    int i2;
                    Intrinsics.checkNotNullParameter(decoder, "decoder");
/* 5 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeDecoder compositeDecoderBeginStructure = decoder.beginStructure(serialDescriptor);
/* 5 */             Lazy[] lazyArr = ReviewLog.$childSerializers;
                    int i3 = 9;
                    int i4 = 4;
                    String strDecodeStringElement = null;
                    if (compositeDecoderBeginStructure.decodeSequentially()) {
                        String strDecodeStringElement2 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                        String strDecodeStringElement3 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                        String strDecodeStringElement4 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                        String strDecodeStringElement5 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                        Rating rating2 = (Rating) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 4, (DeserializationStrategy) lazyArr[4].getValue(), null);
                        long jDecodeLongElement = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                        long jDecodeLongElement2 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                        CardSchedule cardSchedule3 = (CardSchedule) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 7, CardSchedule$$serializer.INSTANCE, null);
                        CardSchedule cardSchedule4 = (CardSchedule) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 8, CardSchedule$$serializer.INSTANCE, null);
                        rating = rating2;
                        strDecodeStringElement = strDecodeStringElement2;
                        l = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, 9, LongSerializer.INSTANCE, null);
                        cardSchedule = cardSchedule3;
                        j = jDecodeLongElement2;
                        str3 = strDecodeStringElement5;
                        cardSchedule2 = cardSchedule4;
                        i = 1023;
                        j2 = jDecodeLongElement;
                        str2 = strDecodeStringElement4;
                        str = strDecodeStringElement3;
                    } else {
                        long jDecodeLongElement3 = 0;
                        boolean z = true;
                        int i5 = 0;
                        Long l2 = null;
                        CardSchedule cardSchedule5 = null;
                        CardSchedule cardSchedule6 = null;
                        Rating rating3 = null;
                        String strDecodeStringElement6 = null;
                        String strDecodeStringElement7 = null;
                        String strDecodeStringElement8 = null;
                        long jDecodeLongElement4 = 0;
                        while (z) {
                            int i6 = i4;
                            int iDecodeElementIndex = compositeDecoderBeginStructure.decodeElementIndex(serialDescriptor);
                            switch (iDecodeElementIndex) {
                                case -1:
                                    z = false;
                                    i3 = 9;
                                    i4 = 4;
                                    break;
                                case 0:
                                    i5 |= 1;
                                    strDecodeStringElement = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 0);
                                    i3 = 9;
                                    i4 = 4;
                                    break;
                                case 1:
                                    strDecodeStringElement6 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 1);
                                    i5 |= 2;
                                    i3 = 9;
                                    i4 = 4;
                                    break;
                                case 2:
                                    strDecodeStringElement7 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 2);
                                    i5 |= 4;
                                    i3 = 9;
                                    i4 = 4;
                                    break;
                                case 3:
                                    i2 = i6;
                                    strDecodeStringElement8 = compositeDecoderBeginStructure.decodeStringElement(serialDescriptor, 3);
                                    i5 |= 8;
                                    i4 = i2;
                                    i3 = 9;
                                    break;
                                case 4:
                                    i2 = i6;
                                    rating3 = (Rating) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, i2, (DeserializationStrategy) lazyArr[i6].getValue(), rating3);
                                    i5 |= 16;
                                    i4 = i2;
                                    i3 = 9;
                                    break;
                                case 5:
                                    jDecodeLongElement4 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 5);
                                    i5 |= 32;
                                    i4 = i6;
                                    break;
                                case 6:
                                    jDecodeLongElement3 = compositeDecoderBeginStructure.decodeLongElement(serialDescriptor, 6);
                                    i5 |= 64;
                                    i4 = i6;
                                    break;
                                case 7:
                                    cardSchedule6 = (CardSchedule) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 7, CardSchedule$$serializer.INSTANCE, cardSchedule6);
                                    i5 |= 128;
                                    i4 = i6;
                                    break;
                                case 8:
                                    cardSchedule5 = (CardSchedule) compositeDecoderBeginStructure.decodeSerializableElement(serialDescriptor, 8, CardSchedule$$serializer.INSTANCE, cardSchedule5);
                                    i5 |= 256;
                                    i4 = i6;
                                    break;
                                case 9:
                                    l2 = (Long) compositeDecoderBeginStructure.decodeNullableSerializableElement(serialDescriptor, i3, LongSerializer.INSTANCE, l2);
                                    i5 |= 512;
                                    i4 = i6;
                                    break;
                                default:
                                    throw new UnknownFieldException(iDecodeElementIndex);
                            }
                        }
                        cardSchedule = cardSchedule6;
                        j = jDecodeLongElement3;
                        str = strDecodeStringElement6;
                        str2 = strDecodeStringElement7;
                        str3 = strDecodeStringElement8;
                        j2 = jDecodeLongElement4;
                        l = l2;
                        cardSchedule2 = cardSchedule5;
                        rating = rating3;
                        i = i5;
                    }
                    compositeDecoderBeginStructure.endStructure(serialDescriptor);
                    return new ReviewLog(i, strDecodeStringElement, str, str2, str3, rating, j2, j, cardSchedule, cardSchedule2, l, null);
                }

                @Override // kotlinx.serialization.SerializationStrategy
/* 4 */         public final void serialize(Encoder encoder, ReviewLog value) {
                    Intrinsics.checkNotNullParameter(encoder, "encoder");
                    Intrinsics.checkNotNullParameter(value, "value");
/* 5 */             SerialDescriptor serialDescriptor = descriptor;
                    CompositeEncoder compositeEncoderBeginStructure = encoder.beginStructure(serialDescriptor);
                    ReviewLog.write$Self$core(value, compositeEncoderBeginStructure, serialDescriptor);
                    compositeEncoderBeginStructure.endStructure(serialDescriptor);
                }

                @Override // kotlinx.serialization.internal.GeneratedSerializer
/* 4 */         public /* bridge */ KSerializer<?>[] typeParametersSerializers() {
/* 5 */             return super.typeParametersSerializers();
                }
            }

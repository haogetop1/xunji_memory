            package com.xunji.core.model;

            import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.FastDoubleMath;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.LazyThreadSafetyMode;
            import kotlin.Metadata;
            import kotlin.jvm.JvmStatic;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.KSerializer;
            import kotlinx.serialization.Serializable;
            import kotlinx.serialization.descriptors.SerialDescriptor;
            import kotlinx.serialization.encoding.CompositeEncoder;
            import kotlinx.serialization.internal.LongSerializer;
            import kotlinx.serialization.internal.PluginExceptionsKt;
            import kotlinx.serialization.internal.SerializationConstructorMarker;
            
            /* JADX INFO: compiled from: ReviewLog.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0087\b\u0018\u0000 A2\u00020\u0001:\u0002@ABY\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0006\u0010\u000e\u001a\u00020\r\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u0010\u0010\u0011B{\b\u0010\u0012\u0006\u0010\u0012\u001a\u00020\u0013\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0003\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\b\u0010\f\u001a\u0004\u0018\u00010\r\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\r\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\n\u0012\b\u0010\u0014\u001a\u0004\u0018\u00010\u0015¢\u0006\u0004\b\u0010\u0010\u0016J\t\u0010'\u001a\u00020\u0003HÆ\u0003J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\t\u0010)\u001a\u00020\u0003HÆ\u0003J\t\u0010*\u001a\u00020\u0003HÆ\u0003J\t\u0010+\u001a\u00020\bHÆ\u0003J\t\u0010,\u001a\u00020\nHÆ\u0003J\t\u0010-\u001a\u00020\nHÆ\u0003J\t\u0010.\u001a\u00020\rHÆ\u0003J\t\u0010/\u001a\u00020\rHÆ\u0003J\u0010\u00100\u001a\u0004\u0018\u00010\nHÆ\u0003¢\u0006\u0002\u0010%Jt\u00101\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\r2\b\b\u0002\u0010\u000e\u001a\u00020\r2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\nHÆ\u0001¢\u0006\u0002\u00102J\u0013\u00103\u001a\u0002042\b\u00105\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00106\u001a\u00020\u0013HÖ\u0001J\t\u00107\u001a\u00020\u0003HÖ\u0001J%\u00108\u001a\u0002092\u0006\u0010:\u001a\u00020\u00002\u0006\u0010;\u001a\u00020<2\u0006\u0010=\u001a\u00020>H\u0001¢\u0006\u0002\b?R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0018R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0018R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0018R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001fR\u0011\u0010\f\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0011\u0010\u000e\u001a\u00020\r¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\"R\u0015\u0010\u000f\u001a\u0004\u0018\u00010\n¢\u0006\n\n\u0002\u0010&\u001a\u0004\b$\u0010%¨\u0006B"}, d2 = {"Lcom/xunji/core/model/ReviewLog;", "", "id", "", "cardId", "deckId", "sessionId", "rating", "Lcom/xunji/core/model/Rating;", "reviewedAt", "", "durationMs", "beforeSchedule", "Lcom/xunji/core/model/CardSchedule;", "afterSchedule", "undoneAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/xunji/core/model/Rating;JJLcom/xunji/core/model/CardSchedule;Lcom/xunji/core/model/CardSchedule;Ljava/lang/Long;)V", "seen0", "", "serializationConstructorMarker", "Lkotlinx/serialization/internal/SerializationConstructorMarker;", "(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/xunji/core/model/Rating;JJLcom/xunji/core/model/CardSchedule;Lcom/xunji/core/model/CardSchedule;Ljava/lang/Long;Lkotlinx/serialization/internal/SerializationConstructorMarker;)V", "getId", "()Ljava/lang/String;", "getCardId", "getDeckId", "getSessionId", "getRating", "()Lcom/xunji/core/model/Rating;", "getReviewedAt", "()J", "getDurationMs", "getBeforeSchedule", "()Lcom/xunji/core/model/CardSchedule;", "getAfterSchedule", "getUndoneAt", "()Ljava/lang/Long;", "Ljava/lang/Long;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/xunji/core/model/Rating;JJLcom/xunji/core/model/CardSchedule;Lcom/xunji/core/model/CardSchedule;Ljava/lang/Long;)Lcom/xunji/core/model/ReviewLog;", "equals", "", "other", "hashCode", "toString", "write$Self", "", "self", "output", "Lkotlinx/serialization/encoding/CompositeEncoder;", "serialDesc", "Lkotlinx/serialization/descriptors/SerialDescriptor;", "write$Self$core", "$serializer", "Companion", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            @Serializable
/* 2 */     public final /* data */ class ReviewLog {
                private final CardSchedule afterSchedule;
                private final CardSchedule beforeSchedule;
                private final String cardId;
                private final String deckId;
                private final long durationMs;
                private final String id;
                private final Rating rating;
                private final long reviewedAt;
                private final String sessionId;
                private final Long undoneAt;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                private static final Lazy<KSerializer<Object>>[] $childSerializers = {null, null, null, null, LazyKt.lazy(LazyThreadSafetyMode.PUBLICATION, new Function0() { // from class: com.xunji.core.model.ReviewLog$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return ReviewLog._childSerializers$_anonymous_();
                    }
                }), null, null, null, null, null};

                public static /* synthetic */ ReviewLog copy$default(ReviewLog reviewLog, String str, String str2, String str3, String str4, Rating rating, long j, long j2, CardSchedule cardSchedule, CardSchedule cardSchedule2, Long l, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = reviewLog.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = reviewLog.cardId;
                    }
                    if ((i & 4) != 0) {
                        str3 = reviewLog.deckId;
                    }
                    if ((i & 8) != 0) {
                        str4 = reviewLog.sessionId;
                    }
                    if ((i & 16) != 0) {
                        rating = reviewLog.rating;
                    }
                    if ((i & 32) != 0) {
                        j = reviewLog.reviewedAt;
                    }
                    if ((i & 64) != 0) {
                        j2 = reviewLog.durationMs;
                    }
                    if ((i & 128) != 0) {
                        cardSchedule = reviewLog.beforeSchedule;
                    }
                    if ((i & 256) != 0) {
                        cardSchedule2 = reviewLog.afterSchedule;
                    }
                    if ((i & 512) != 0) {
                        l = reviewLog.undoneAt;
                    }
                    Long l2 = l;
                    CardSchedule cardSchedule3 = cardSchedule;
                    long j3 = j2;
                    long j4 = j;
                    String str5 = str4;
                    Rating rating2 = rating;
                    String str6 = str3;
                    return reviewLog.copy(str, str2, str6, str5, rating2, j4, j3, cardSchedule3, cardSchedule2, l2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component10, reason: from getter */
                public final Long getUndoneAt() {
                    return this.undoneAt;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getDeckId() {
                    return this.deckId;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getSessionId() {
                    return this.sessionId;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final Rating getRating() {
                    return this.rating;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getReviewedAt() {
                    return this.reviewedAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getDurationMs() {
                    return this.durationMs;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final CardSchedule getBeforeSchedule() {
                    return this.beforeSchedule;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final CardSchedule getAfterSchedule() {
                    return this.afterSchedule;
                }

                public final ReviewLog copy(String id, String cardId, String deckId, String sessionId, Rating rating, long reviewedAt, long durationMs, CardSchedule beforeSchedule, CardSchedule afterSchedule, Long undoneAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(rating, "rating");
                    Intrinsics.checkNotNullParameter(beforeSchedule, "beforeSchedule");
                    Intrinsics.checkNotNullParameter(afterSchedule, "afterSchedule");
                    return new ReviewLog(id, cardId, deckId, sessionId, rating, reviewedAt, durationMs, beforeSchedule, afterSchedule, undoneAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ReviewLog)) {
                        return false;
                    }
                    ReviewLog reviewLog = (ReviewLog) other;
                    return Intrinsics.areEqual(this.id, reviewLog.id) && Intrinsics.areEqual(this.cardId, reviewLog.cardId) && Intrinsics.areEqual(this.deckId, reviewLog.deckId) && Intrinsics.areEqual(this.sessionId, reviewLog.sessionId) && this.rating == reviewLog.rating && this.reviewedAt == reviewLog.reviewedAt && this.durationMs == reviewLog.durationMs && Intrinsics.areEqual(this.beforeSchedule, reviewLog.beforeSchedule) && Intrinsics.areEqual(this.afterSchedule, reviewLog.afterSchedule) && Intrinsics.areEqual(this.undoneAt, reviewLog.undoneAt);
                }

                public int hashCode() {
                    return (((((((((((((((((this.id.hashCode() * 31) + this.cardId.hashCode()) * 31) + this.deckId.hashCode()) * 31) + this.sessionId.hashCode()) * 31) + this.rating.hashCode()) * 31) + Long.hashCode(this.reviewedAt)) * 31) + Long.hashCode(this.durationMs)) * 31) + this.beforeSchedule.hashCode()) * 31) + this.afterSchedule.hashCode()) * 31) + (this.undoneAt == null ? 0 : this.undoneAt.hashCode());
                }

                public String toString() {
                    return "ReviewLog(id=" + this.id + ", cardId=" + this.cardId + ", deckId=" + this.deckId + ", sessionId=" + this.sessionId + ", rating=" + this.rating + ", reviewedAt=" + this.reviewedAt + ", durationMs=" + this.durationMs + ", beforeSchedule=" + this.beforeSchedule + ", afterSchedule=" + this.afterSchedule + ", undoneAt=" + this.undoneAt + ")";
                }

                /* JADX INFO: compiled from: ReviewLog.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/core/model/ReviewLog$Companion;", "", "<init>", "()V", "serializer", "Lkotlinx/serialization/KSerializer;", "Lcom/xunji/core/model/ReviewLog;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */         public static final class Companion {
/* 4 */             private Companion() {
                    }

/* 4 */             public final KSerializer<ReviewLog> serializer() {
/* 5 */                 return ReviewLog$$serializer.INSTANCE;
                    }
                }

/* 4 */         public /* synthetic */ ReviewLog(int seen0, String id, String cardId, String deckId, String sessionId, Rating rating, long reviewedAt, long durationMs, CardSchedule beforeSchedule, CardSchedule afterSchedule, Long undoneAt, SerializationConstructorMarker serializationConstructorMarker) {
/* 5 */             if (1023 != (seen0 & FastDoubleMath.DOUBLE_EXPONENT_BIAS)) {
                        PluginExceptionsKt.throwMissingFieldException(seen0, FastDoubleMath.DOUBLE_EXPONENT_BIAS, ReviewLog$$serializer.INSTANCE.getDescriptor());
                    }
                    this.id = id;
                    this.cardId = cardId;
                    this.deckId = deckId;
                    this.sessionId = sessionId;
                    this.rating = rating;
                    this.reviewedAt = reviewedAt;
                    this.durationMs = durationMs;
                    this.beforeSchedule = beforeSchedule;
                    this.afterSchedule = afterSchedule;
                    this.undoneAt = undoneAt;
                }

/* 4 */         public ReviewLog(String id, String cardId, String deckId, String sessionId, Rating rating, long reviewedAt, long durationMs, CardSchedule beforeSchedule, CardSchedule afterSchedule, Long undoneAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(rating, "rating");
                    Intrinsics.checkNotNullParameter(beforeSchedule, "beforeSchedule");
                    Intrinsics.checkNotNullParameter(afterSchedule, "afterSchedule");
                    this.id = id;
                    this.cardId = cardId;
                    this.deckId = deckId;
                    this.sessionId = sessionId;
                    this.rating = rating;
                    this.reviewedAt = reviewedAt;
                    this.durationMs = durationMs;
                    this.beforeSchedule = beforeSchedule;
                    this.afterSchedule = afterSchedule;
                    this.undoneAt = undoneAt;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 4 */         public static final /* synthetic */ KSerializer _childSerializers$_anonymous_() {
                    return Rating.INSTANCE.serializer();
                }

                @JvmStatic
/* 4 */         public static final /* synthetic */ void write$Self$core(ReviewLog self, CompositeEncoder output, SerialDescriptor serialDesc) {
/* 5 */             Lazy<KSerializer<Object>>[] lazyArr = $childSerializers;
                    output.encodeStringElement(serialDesc, 0, self.id);
                    output.encodeStringElement(serialDesc, 1, self.cardId);
                    output.encodeStringElement(serialDesc, 2, self.deckId);
                    output.encodeStringElement(serialDesc, 3, self.sessionId);
                    output.encodeSerializableElement(serialDesc, 4, lazyArr[4].getValue(), self.rating);
                    output.encodeLongElement(serialDesc, 5, self.reviewedAt);
                    output.encodeLongElement(serialDesc, 6, self.durationMs);
                    output.encodeSerializableElement(serialDesc, 7, CardSchedule$$serializer.INSTANCE, self.beforeSchedule);
                    output.encodeSerializableElement(serialDesc, 8, CardSchedule$$serializer.INSTANCE, self.afterSchedule);
                    output.encodeNullableSerializableElement(serialDesc, 9, LongSerializer.INSTANCE, self.undoneAt);
                }

/* 4 */         public final CardSchedule getAfterSchedule() {
/* 5 */             return this.afterSchedule;
                }

/* 4 */         public final CardSchedule getBeforeSchedule() {
/* 5 */             return this.beforeSchedule;
                }

/* 4 */         public final String getCardId() {
/* 5 */             return this.cardId;
                }

/* 4 */         public final String getDeckId() {
/* 5 */             return this.deckId;
                }

/* 4 */         public final long getDurationMs() {
/* 5 */             return this.durationMs;
                }

/* 4 */         public final String getId() {
/* 5 */             return this.id;
                }

/* 4 */         public final Rating getRating() {
/* 5 */             return this.rating;
                }

/* 4 */         public final long getReviewedAt() {
/* 5 */             return this.reviewedAt;
                }

/* 4 */         public final String getSessionId() {
/* 5 */             return this.sessionId;
                }

/* 4 */         public final Long getUndoneAt() {
/* 5 */             return this.undoneAt;
                }
            }

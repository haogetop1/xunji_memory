            package com.xunji.core.scheduling;

            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.Rating;
            import io.github.openspacedrepetition.Card;
            import io.github.openspacedrepetition.State;
            import java.time.Duration;
            import java.time.Instant;
            import java.util.LinkedHashMap;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: FsrsScheduler.kt */
            /* JADX INFO: loaded from: classes2.dex */
            @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J \u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u000b2\u0006\u0010\f\u001a\u00020\rH\u0016J$\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u000b\u0012\u0004\u0012\u00020\b0\u000f2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\rH\u0016R\u0016\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/xunji/core/scheduling/FsrsScheduler;", "Lcom/xunji/core/scheduling/Scheduler;", "<init>", "()V", "delegate", "Lio/github/openspacedrepetition/Scheduler;", "kotlin.jvm.PlatformType", "review", "Lcom/xunji/core/model/CardSchedule;", "schedule", "rating", "Lcom/xunji/core/model/Rating;", "at", "Ljava/time/Instant;", "preview", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final class FsrsScheduler implements Scheduler {
                private final io.github.openspacedrepetition.Scheduler delegate = io.github.openspacedrepetition.Scheduler.builder().desiredRetention(0.9d).learningSteps(new Duration[]{Duration.ofMinutes(1), Duration.ofMinutes(10)}).relearningSteps(new Duration[]{Duration.ofMinutes(10)}).enableFuzzing(false).build();

                /* JADX INFO: compiled from: FsrsScheduler.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[Phase.values().length];
                        try {
                            iArr[Phase.NEW.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[Phase.LEARNING.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[Phase.REVIEW.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        try {
                            iArr[Phase.RELEARNING.ordinal()] = 4;
                        } catch (NoSuchFieldError e4) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                @Override // com.xunji.core.scheduling.Scheduler
/* 17 */        public CardSchedule review(CardSchedule schedule, Rating rating, Instant at) {
                    State state;
                    Instant instantOfEpochMilli;
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(rating, "rating");
                    Intrinsics.checkNotNullParameter(at, "at");
/* 18 */            if (!(schedule.getLastReviewAt() == null || at.toEpochMilli() >= schedule.getLastReviewAt().longValue())) {
                        throw new IllegalArgumentException("设备时间早于上次复习，请校准时间后重试".toString());
                    }
/* 19 */            Card.Builder builderCardId = Card.builder().cardId(0);
                    switch (WhenMappings.$EnumSwitchMapping$0[schedule.getPhase().ordinal()]) {
                        case 1:
                        case 2:
/* 21 */                    state = State.LEARNING;
                            break;
                        case 3:
/* 22 */                    state = State.REVIEW;
                            break;
                        case 4:
/* 23 */                    state = State.RELEARNING;
                            break;
                        default:
                            throw new NoWhenBranchMatchedException();
                    }
/* 27 */            Card.Builder builderDue = builderCardId.state(state).step(schedule.getPhase() != Phase.NEW ? schedule.getStep() : 0).stability(schedule.getStability()).difficulty(schedule.getDifficulty()).due(Instant.ofEpochMilli(schedule.getDueAt()));
/* 28 */            Long lastReviewAt = schedule.getLastReviewAt();
                    if (lastReviewAt != null) {
                        long p0 = lastReviewAt.longValue();
/* 28 */                instantOfEpochMilli = Instant.ofEpochMilli(p0);
                    } else {
                        instantOfEpochMilli = null;
                    }
                    Card card = builderDue.lastReview(instantOfEpochMilli).build();
/* 29 */            Card result = reviewCard(card, io.github.openspacedrepetition.Rating.valueOf(rating.name()), at, null).card();
                    Intrinsics.checkNotNullExpressionValue(result, "card(...)");
/* 31 */            Phase phaseValueOf = Phase.valueOf(result.getState().name());
                    Integer step = result.getStep();
/* 32 */            Double stability = result.getStability();
                    Double difficulty = result.getDifficulty();
                    long epochMilli = result.getDue().toEpochMilli();
/* 33 */            Long lValueOf = Long.valueOf(at.toEpochMilli());
                    Long firstReviewedAt = schedule.getFirstReviewedAt();
/* 30 */            return CardSchedule.copy$default(schedule, null, phaseValueOf, step, stability, difficulty, epochMilli, lValueOf, Long.valueOf(firstReviewedAt != null ? firstReviewedAt.longValue() : at.toEpochMilli()), schedule.getRevision() + 1, 1, null);
                }

                @Override // com.xunji.core.scheduling.Scheduler
/* 36 */        public Map<Rating, CardSchedule> preview(CardSchedule schedule, Instant at) {
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(at, "at");
/* 37 */            Iterable $this$associateWith$iv = Rating.getEntries();
/* 41 */            Map result$iv = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault($this$associateWith$iv, 10)), 16));
/* 42 */            Map destination$iv$iv = result$iv;
                    for (Rating rating : $this$associateWith$iv) {
/* 44 */                Rating it = rating;
/* 44 */                destination$iv$iv.put(rating, review(schedule, it, at));
                    }
/* 37 */            return destination$iv$iv;
                }
            }

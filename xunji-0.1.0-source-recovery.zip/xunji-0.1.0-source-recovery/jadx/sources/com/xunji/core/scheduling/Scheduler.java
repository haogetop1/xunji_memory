            package com.xunji.core.scheduling;

            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Rating;
            import java.time.Instant;
            import java.util.Map;
            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: Scheduler.kt */
            /* JADX INFO: loaded from: classes2.dex */
            @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0000\bf\u0018\u00002\u00020\u0001J \u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u00062\u0006\u0010\u0007\u001a\u00020\bH&J$\u0010\t\u001a\u000e\u0012\u0004\u0012\u00020\u0006\u0012\u0004\u0012\u00020\u00030\n2\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\bH&¨\u0006\u000bÀ\u0006\u0003"}, d2 = {"Lcom/xunji/core/scheduling/Scheduler;", "", "review", "Lcom/xunji/core/model/CardSchedule;", "schedule", "rating", "Lcom/xunji/core/model/Rating;", "at", "Ljava/time/Instant;", "preview", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface Scheduler {
                Map<Rating, CardSchedule> preview(CardSchedule schedule, Instant at);

                CardSchedule review(CardSchedule schedule, Rating rating, Instant at);
            }

            package com.xunji.core.serialization;

            import com.xunji.core.model.CardSchedule;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.json.Json;
            
            /* JADX INFO: compiled from: ScheduleCodec.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\u000e\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0005¨\u0006\n"}, d2 = {"Lcom/xunji/core/serialization/ScheduleCodec;", "", "<init>", "()V", "encode", "", "schedule", "Lcom/xunji/core/model/CardSchedule;", "decode", "json", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final class ScheduleCodec {
                public static final ScheduleCodec INSTANCE = new ScheduleCodec();

/* 4 */         private ScheduleCodec() {
                }

/* 5 */         public final String encode(CardSchedule schedule) {
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
/* 6 */             Json this_$iv = Json.INSTANCE;
/* 10 */            this_$iv.getSerializersModule();
                    return this_$iv.encodeToString(CardSchedule.INSTANCE.serializer(), schedule);
                }

/* 6 */         public final CardSchedule decode(String json) {
                    Intrinsics.checkNotNullParameter(json, "json");
/* 7 */             Json this_$iv = Json.INSTANCE;
/* 11 */            this_$iv.getSerializersModule();
                    return (CardSchedule) this_$iv.decodeFromString(CardSchedule.INSTANCE.serializer(), json);
                }
            }

            package com.xunji.core.stats;

            import java.time.LocalDate;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: StudyStatistics.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0006\n\u0000\n\u0002\u0010\t\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0005HÆ\u0003J\u0010\u0010\u001a\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u0013J\t\u0010\u001b\u001a\u00020\nHÆ\u0003JB\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\b\b\u0002\u0010\t\u001a\u00020\nHÆ\u0001¢\u0006\u0002\u0010\u001dJ\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\u0005HÖ\u0001J\t\u0010\"\u001a\u00020#HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0015\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u0014\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016¨\u0006$"}, d2 = {"Lcom/xunji/core/stats/DaySummary;", "", "date", "Ljava/time/LocalDate;", "scoreCount", "", "distinctCards", "againRatio", "", "durationMs", "", "<init>", "(Ljava/time/LocalDate;IILjava/lang/Double;J)V", "getDate", "()Ljava/time/LocalDate;", "getScoreCount", "()I", "getDistinctCards", "getAgainRatio", "()Ljava/lang/Double;", "Ljava/lang/Double;", "getDurationMs", "()J", "component1", "component2", "component3", "component4", "component5", "copy", "(Ljava/time/LocalDate;IILjava/lang/Double;J)Lcom/xunji/core/stats/DaySummary;", "equals", "", "other", "hashCode", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final /* data */ class DaySummary {
                private final Double againRatio;
                private final LocalDate date;
                private final int distinctCards;
                private final long durationMs;
                private final int scoreCount;

                public static /* synthetic */ DaySummary copy$default(DaySummary daySummary, LocalDate localDate, int i, int i2, Double d, long j, int i3, Object obj) {
                    if ((i3 & 1) != 0) {
                        localDate = daySummary.date;
                    }
                    if ((i3 & 2) != 0) {
                        i = daySummary.scoreCount;
                    }
                    if ((i3 & 4) != 0) {
                        i2 = daySummary.distinctCards;
                    }
                    if ((i3 & 8) != 0) {
                        d = daySummary.againRatio;
                    }
                    if ((i3 & 16) != 0) {
                        j = daySummary.durationMs;
                    }
                    long j2 = j;
                    return daySummary.copy(localDate, i, i2, d, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final LocalDate getDate() {
                    return this.date;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getScoreCount() {
                    return this.scoreCount;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getDistinctCards() {
                    return this.distinctCards;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final Double getAgainRatio() {
                    return this.againRatio;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final long getDurationMs() {
                    return this.durationMs;
                }

                public final DaySummary copy(LocalDate date, int scoreCount, int distinctCards, Double againRatio, long durationMs) {
                    Intrinsics.checkNotNullParameter(date, "date");
                    return new DaySummary(date, scoreCount, distinctCards, againRatio, durationMs);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof DaySummary)) {
                        return false;
                    }
                    DaySummary daySummary = (DaySummary) other;
                    return Intrinsics.areEqual(this.date, daySummary.date) && this.scoreCount == daySummary.scoreCount && this.distinctCards == daySummary.distinctCards && Intrinsics.areEqual((Object) this.againRatio, (Object) daySummary.againRatio) && this.durationMs == daySummary.durationMs;
                }

                public int hashCode() {
                    return (((((((this.date.hashCode() * 31) + Integer.hashCode(this.scoreCount)) * 31) + Integer.hashCode(this.distinctCards)) * 31) + (this.againRatio == null ? 0 : this.againRatio.hashCode())) * 31) + Long.hashCode(this.durationMs);
                }

                public String toString() {
                    return "DaySummary(date=" + this.date + ", scoreCount=" + this.scoreCount + ", distinctCards=" + this.distinctCards + ", againRatio=" + this.againRatio + ", durationMs=" + this.durationMs + ")";
                }

/* 5 */         public DaySummary(LocalDate date, int scoreCount, int distinctCards, Double againRatio, long durationMs) {
                    Intrinsics.checkNotNullParameter(date, "date");
                    this.date = date;
                    this.scoreCount = scoreCount;
                    this.distinctCards = distinctCards;
                    this.againRatio = againRatio;
                    this.durationMs = durationMs;
                }

/* 5 */         public final Double getAgainRatio() {
/* 6 */             return this.againRatio;
                }

/* 5 */         public final LocalDate getDate() {
/* 6 */             return this.date;
                }

/* 5 */         public final int getDistinctCards() {
/* 6 */             return this.distinctCards;
                }

/* 5 */         public final long getDurationMs() {
/* 6 */             return this.durationMs;
                }

/* 5 */         public final int getScoreCount() {
/* 6 */             return this.scoreCount;
                }
            }

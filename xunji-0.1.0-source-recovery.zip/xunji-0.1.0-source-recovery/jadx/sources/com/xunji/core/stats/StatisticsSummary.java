            package com.xunji.core.stats;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: StudyStatistics.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u001d\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u000f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0003J#\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0015HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0016"}, d2 = {"Lcom/xunji/core/stats/StatisticsSummary;", "", "today", "Lcom/xunji/core/stats/DaySummary;", "lastSevenDays", "", "<init>", "(Lcom/xunji/core/stats/DaySummary;Ljava/util/List;)V", "getToday", "()Lcom/xunji/core/stats/DaySummary;", "getLastSevenDays", "()Ljava/util/List;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */     public final /* data */ class StatisticsSummary {
                private final List<DaySummary> lastSevenDays;
                private final DaySummary today;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ StatisticsSummary copy$default(StatisticsSummary statisticsSummary, DaySummary daySummary, List list, int i, Object obj) {
                    if ((i & 1) != 0) {
                        daySummary = statisticsSummary.today;
                    }
                    if ((i & 2) != 0) {
                        list = statisticsSummary.lastSevenDays;
                    }
                    return statisticsSummary.copy(daySummary, list);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final DaySummary getToday() {
                    return this.today;
                }

                public final List<DaySummary> component2() {
                    return this.lastSevenDays;
                }

                public final StatisticsSummary copy(DaySummary today, List<DaySummary> lastSevenDays) {
                    Intrinsics.checkNotNullParameter(today, "today");
                    Intrinsics.checkNotNullParameter(lastSevenDays, "lastSevenDays");
                    return new StatisticsSummary(today, lastSevenDays);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof StatisticsSummary)) {
                        return false;
                    }
                    StatisticsSummary statisticsSummary = (StatisticsSummary) other;
                    return Intrinsics.areEqual(this.today, statisticsSummary.today) && Intrinsics.areEqual(this.lastSevenDays, statisticsSummary.lastSevenDays);
                }

                public int hashCode() {
                    return (this.today.hashCode() * 31) + this.lastSevenDays.hashCode();
                }

                public String toString() {
                    return "StatisticsSummary(today=" + this.today + ", lastSevenDays=" + this.lastSevenDays + ")";
                }

/* 6 */         public StatisticsSummary(DaySummary today, List<DaySummary> lastSevenDays) {
                    Intrinsics.checkNotNullParameter(today, "today");
                    Intrinsics.checkNotNullParameter(lastSevenDays, "lastSevenDays");
                    this.today = today;
                    this.lastSevenDays = lastSevenDays;
                }

/* 6 */         public final List<DaySummary> getLastSevenDays() {
/* 7 */             return this.lastSevenDays;
                }

/* 6 */         public final DaySummary getToday() {
/* 7 */             return this.today;
                }
            }

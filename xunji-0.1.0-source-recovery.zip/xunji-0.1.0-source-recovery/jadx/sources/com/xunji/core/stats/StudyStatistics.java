            package com.xunji.core.stats;

            import com.xunji.core.model.Rating;
            import com.xunji.core.model.ReviewLog;
            import java.time.Instant;
            import java.time.LocalDate;
            import java.time.ZoneId;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.IntIterator;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: StudyStatistics.kt */
            /* JADX INFO: loaded from: classes7.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f¨\u0006\r"}, d2 = {"Lcom/xunji/core/stats/StudyStatistics;", "", "<init>", "()V", "summarize", "Lcom/xunji/core/stats/StatisticsSummary;", "logs", "", "Lcom/xunji/core/model/ReviewLog;", "at", "Ljava/time/Instant;", "zone", "Ljava/time/ZoneId;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */     public final class StudyStatistics {
                public static final StudyStatistics INSTANCE = new StudyStatistics();

/* 7 */         private StudyStatistics() {
                }

/* 9 */         public final StatisticsSummary summarize(List<ReviewLog> logs, Instant at, ZoneId zone) {
                    int count$iv;
                    Double dValueOf;
                    Iterable logs2 = logs;
                    ZoneId zone2 = zone;
                    Intrinsics.checkNotNullParameter(logs2, "logs");
                    Intrinsics.checkNotNullParameter(at, "at");
                    Intrinsics.checkNotNullParameter(zone2, "zone");
/* 10 */            LocalDate today = at.atZone(zone).toLocalDate();
/* 11 */            Iterable $this$map$iv = RangesKt.downTo(6, 0);
                    int $i$f$map = 0;
/* 20 */            Collection destination$iv$iv = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv, 10));
                    Iterable $this$mapTo$iv$iv = $this$map$iv;
/* 21 */            Iterator<Integer> it = $this$mapTo$iv$iv.iterator();
                    while (it.hasNext()) {
                        int item$iv$iv = ((IntIterator) it).nextInt();
/* 12 */                int $i$f$map2 = $i$f$map;
/* 22 */                LocalDate date = today.minusDays(item$iv$iv);
                        long start = date.atStartOfDay(zone2).toInstant().toEpochMilli();
                        Iterable $this$mapTo$iv$iv2 = $this$mapTo$iv$iv;
                        long end = date.plusDays(1L).atStartOfDay(zone2).toInstant().toEpochMilli();
/* 13 */                Iterable $this$filter$iv = logs2;
/* 23 */                Collection destination$iv$iv2 = new ArrayList();
/* 24 */                Iterator it2 = $this$filter$iv.iterator();
                        while (true) {
                            if (!it2.hasNext()) {
                                break;
                            }
                            Object element$iv$iv = it2.next();
                            ReviewLog it3 = (ReviewLog) element$iv$iv;
/* 24 */                    if (it3.getUndoneAt() == null && it3.getReviewedAt() >= start && it3.getReviewedAt() < end) {
                                destination$iv$iv2.add(element$iv$iv);
                            }
                        }
                        List<ReviewLog> valid = (List) destination$iv$iv2;
/* 14 */                Intrinsics.checkNotNull(date);
                        int size = valid.size();
                        List $this$map$iv2 = valid;
                        LocalDate today2 = today;
/* 26 */                Collection destination$iv$iv3 = new ArrayList(CollectionsKt.collectionSizeOrDefault($this$map$iv2, 10));
                        for (Object item$iv$iv2 : $this$map$iv2) {
/* 28 */                    ReviewLog it4 = (ReviewLog) item$iv$iv2;
/* 28 */                    destination$iv$iv3.add(it4.getCardId());
                        }
/* 14 */                int size2 = CollectionsKt.toSet((List) destination$iv$iv3).size();
                        if (valid.isEmpty()) {
                            dValueOf = null;
                        } else {
                            List $this$count$iv = valid;
                            int $i$f$count = 0;
/* 30 */                    if (($this$count$iv instanceof Collection) && $this$count$iv.isEmpty()) {
                                count$iv = 0;
                            } else {
/* 31 */                        count$iv = 0;
                                for (Object element$iv : $this$count$iv) {
                                    ReviewLog it5 = (ReviewLog) element$iv;
/* 14 */                            $this$count$iv = $this$count$iv;
                                    $i$f$count = $i$f$count;
/* 32 */                            if (it5.getRating() == Rating.AGAIN) {
                                        count$iv++;
                                        if (count$iv < 0) {
                                            CollectionsKt.throwCountOverflow();
                                        }
                                    }
                                }
                            }
/* 14 */                    dValueOf = Double.valueOf(((double) count$iv) / ((double) valid.size()));
                        }
                        Double d = dValueOf;
                        long jCoerceIn = 0;
                        for (ReviewLog it6 : valid) {
/* 14 */                    jCoerceIn += RangesKt.coerceIn(it6.getDurationMs(), 0L, 300000L);
                        }
/* 22 */                destination$iv$iv.add(new DaySummary(date, size, size2, d, jCoerceIn));
                        logs2 = logs;
                        zone2 = zone;
                        $i$f$map = $i$f$map2;
                        $this$mapTo$iv$iv = $this$mapTo$iv$iv2;
                        today = today2;
                    }
                    List days = (List) destination$iv$iv;
/* 16 */            return new StatisticsSummary((DaySummary) CollectionsKt.last(days), days);
                }
            }

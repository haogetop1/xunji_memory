            package com.xunji.core.study;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.time.DayBounds;
            import com.xunji.core.time.LocalDay;
            import java.time.Instant;
            import java.time.ZoneId;
            import java.util.Collection;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: NewCardQuota.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J,\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e¨\u0006\u000f"}, d2 = {"Lcom/xunji/core/study/NewCardQuota;", "", "<init>", "()V", "remaining", "", "allSchedules", "", "Lcom/xunji/core/model/CardSchedule;", "settings", "Lcom/xunji/core/model/AppSettings;", "at", "Ljava/time/Instant;", "zone", "Ljava/time/ZoneId;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final class NewCardQuota {
                public static final NewCardQuota INSTANCE = new NewCardQuota();

/* 5 */         private NewCardQuota() {
                }

                /* JADX WARN: Code duplicated, block: B:20:0x006c  */
/* 7 */         public final int remaining(List<CardSchedule> allSchedules, AppSettings settings, Instant at, ZoneId zone) {
                    int count$iv;
                    boolean z;
                    Intrinsics.checkNotNullParameter(allSchedules, "allSchedules");
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    Intrinsics.checkNotNullParameter(at, "at");
                    Intrinsics.checkNotNullParameter(zone, "zone");
/* 8 */             DayBounds day = LocalDay.INSTANCE.bounds(at, zone);
/* 9 */             List<CardSchedule> $this$count$iv = allSchedules;
/* 14 */            if (($this$count$iv instanceof Collection) && $this$count$iv.isEmpty()) {
                        count$iv = 0;
                    } else {
/* 15 */                count$iv = 0;
                        for (Object element$iv : $this$count$iv) {
                            CardSchedule it = (CardSchedule) element$iv;
/* 9 */                     Long firstReviewedAt = it.getFirstReviewedAt();
                            if (firstReviewedAt != null) {
                                long first = firstReviewedAt.longValue();
                                z = (first > day.getStart() ? 1 : (first == day.getStart() ? 0 : -1)) >= 0 && (first > day.getEndExclusive() ? 1 : (first == day.getEndExclusive() ? 0 : -1)) < 0;
                            }
/* 16 */                    if (z && (count$iv = count$iv + 1) < 0) {
                                CollectionsKt.throwCountOverflow();
                            }
                        }
                    }
/* 10 */            return RangesKt.coerceAtLeast(settings.getNewCardsPerDay() - count$iv, 0);
                }
            }

            package com.xunji.core.study;

            import com.xunji.core.model.CardCandidate;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: QueuePlanner.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0003\u0002\u0003\u0004\u0082\u0001\u0003\u0005\u0006\u0007¨\u0006\bÀ\u0006\u0003"}, d2 = {"Lcom/xunji/core/study/QueueDecision;", "", "Ready", "Waiting", "Done", "Lcom/xunji/core/study/QueueDecision$Done;", "Lcom/xunji/core/study/QueueDecision$Ready;", "Lcom/xunji/core/study/QueueDecision$Waiting;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 2 */     public interface QueueDecision {

                /* JADX INFO: compiled from: QueuePlanner.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/core/study/QueueDecision$Ready;", "Lcom/xunji/core/study/QueueDecision;", "candidate", "Lcom/xunji/core/model/CardCandidate;", "<init>", "(Lcom/xunji/core/model/CardCandidate;)V", "getCandidate", "()Lcom/xunji/core/model/CardCandidate;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */         public static final /* data */ class Ready implements QueueDecision {
                    private final CardCandidate candidate;

                    public static /* synthetic */ Ready copy$default(Ready ready, CardCandidate cardCandidate, int i, Object obj) {
                        if ((i & 1) != 0) {
                            cardCandidate = ready.candidate;
                        }
                        return ready.copy(cardCandidate);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final CardCandidate getCandidate() {
                        return this.candidate;
                    }

                    public final Ready copy(CardCandidate candidate) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        return new Ready(candidate);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Ready) && Intrinsics.areEqual(this.candidate, ((Ready) other).candidate);
                    }

                    public int hashCode() {
                        return this.candidate.hashCode();
                    }

                    public String toString() {
                        return "Ready(candidate=" + this.candidate + ")";
                    }

/* 4 */             public Ready(CardCandidate candidate) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        this.candidate = candidate;
                    }

/* 4 */             public final CardCandidate getCandidate() {
/* 5 */                 return this.candidate;
                    }
                }

                /* JADX INFO: compiled from: QueuePlanner.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/core/study/QueueDecision$Waiting;", "Lcom/xunji/core/study/QueueDecision;", "nextDueAt", "", "<init>", "(J)V", "getNextDueAt", "()J", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */         public static final /* data */ class Waiting implements QueueDecision {
                    private final long nextDueAt;

                    public static /* synthetic */ Waiting copy$default(Waiting waiting, long j, int i, Object obj) {
                        if ((i & 1) != 0) {
                            j = waiting.nextDueAt;
                        }
                        return waiting.copy(j);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final long getNextDueAt() {
                        return this.nextDueAt;
                    }

                    public final Waiting copy(long nextDueAt) {
                        return new Waiting(nextDueAt);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Waiting) && this.nextDueAt == ((Waiting) other).nextDueAt;
                    }

                    public int hashCode() {
                        return Long.hashCode(this.nextDueAt);
                    }

                    public String toString() {
                        return "Waiting(nextDueAt=" + this.nextDueAt + ")";
                    }

/* 5 */             public Waiting(long nextDueAt) {
                        this.nextDueAt = nextDueAt;
                    }

/* 5 */             public final long getNextDueAt() {
/* 6 */                 return this.nextDueAt;
                    }
                }

                /* JADX INFO: compiled from: QueuePlanner.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÆ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/core/study/QueueDecision$Done;", "Lcom/xunji/core/study/QueueDecision;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */         public static final /* data */ class Done implements QueueDecision {
                    public static final Done INSTANCE = new Done();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Done)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return -647902356;
                    }

                    public String toString() {
                        return "Done";
                    }

/* 6 */             private Done() {
                    }
                }
            }

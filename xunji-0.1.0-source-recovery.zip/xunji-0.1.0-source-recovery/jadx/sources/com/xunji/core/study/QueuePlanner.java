            package com.xunji.core.study;

            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.Phase;
            import java.time.Instant;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Comparator;
            import java.util.Iterator;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.comparisons.ComparisonsKt;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: QueuePlanner.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J$\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\f¨\u0006\r"}, d2 = {"Lcom/xunji/core/study/QueuePlanner;", "", "<init>", "()V", "next", "Lcom/xunji/core/study/QueueDecision;", "candidates", "", "Lcom/xunji/core/model/CardCandidate;", "remainingNew", "", "at", "Ljava/time/Instant;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */     public final class QueuePlanner {
                public static final QueuePlanner INSTANCE = new QueuePlanner();

/* 8 */         private QueuePlanner() {
                }

/* 10 */        public final QueueDecision next(List<CardCandidate> candidates, int remainingNew, Instant at) {
                    Long l;
                    Intrinsics.checkNotNullParameter(candidates, "candidates");
                    Intrinsics.checkNotNullParameter(at, "at");
/* 11 */            List<CardCandidate> $this$filter$iv = candidates;
/* 23 */            Collection destination$iv$iv = new ArrayList();
                    for (Object element$iv$iv : $this$filter$iv) {
                        CardCandidate it = (CardCandidate) element$iv$iv;
/* 24 */                if (it.getSchedule().getPhase() != Phase.NEW && it.getSchedule().getDueAt() <= at.toEpochMilli()) {
                            destination$iv$iv.add(element$iv$iv);
                        }
                    }
                    List due = (List) destination$iv$iv;
                    final Comparator comparator = new Comparator() { // from class: com.xunji.core.study.QueuePlanner$next$$inlined$compareBy$1
                        /* JADX WARN: Multi-variable type inference failed */
                        @Override // java.util.Comparator
/* 101 */               public final int compare(T t, T t2) {
/* 102 */                   CardCandidate it2 = (CardCandidate) t;
/* 329 */                   Integer num = it2.getSchedule().getPhase() == Phase.REVIEW ? (Comparable) 1 : (Comparable) 0;
/* 102 */                   CardCandidate it3 = (CardCandidate) t2;
/* 102 */                   return ComparisonsKt.compareValues(num, it3.getSchedule().getPhase() == Phase.REVIEW ? (Comparable) 1 : (Comparable) 0);
                        }
                    };
/* 13 */            final Comparator comparator2 = new Comparator() { // from class: com.xunji.core.study.QueuePlanner$next$$inlined$thenBy$1
                        /* JADX WARN: Multi-variable type inference failed */
                        @Override // java.util.Comparator
/* 143 */               public final int compare(T t, T t2) {
/* 144 */                   int previousCompare = comparator.compare(t, t2);
/* 145 */                   if (previousCompare != 0) {
                                return previousCompare;
                            }
                            CardCandidate it2 = (CardCandidate) t;
/* 329 */                   Long lValueOf = Long.valueOf(it2.getSchedule().getDueAt());
/* 145 */                   CardCandidate it3 = (CardCandidate) t2;
/* 145 */                   return ComparisonsKt.compareValues(lValueOf, Long.valueOf(it3.getSchedule().getDueAt()));
                        }
                    };
/* 12 */            List ordered = CollectionsKt.sortedWith(due, new Comparator() { // from class: com.xunji.core.study.QueuePlanner$next$$inlined$thenBy$2
                        /* JADX WARN: Multi-variable type inference failed */
                        @Override // java.util.Comparator
/* 143 */               public final int compare(T t, T t2) {
/* 144 */                   int previousCompare = comparator2.compare(t, t2);
/* 145 */                   if (previousCompare != 0) {
                                return previousCompare;
                            }
                            CardCandidate it2 = (CardCandidate) t;
/* 329 */                   String id = it2.getCard().getId();
/* 145 */                   CardCandidate it3 = (CardCandidate) t2;
/* 145 */                   return ComparisonsKt.compareValues(id, it3.getCard().getId());
                        }
                    });
/* 14 */            CardCandidate it2 = (CardCandidate) CollectionsKt.firstOrNull(ordered);
                    if (it2 != null) {
/* 14 */                return new QueueDecision.Ready(it2);
                    }
/* 15 */            if (remainingNew > 0) {
/* 15 */                List<CardCandidate> $this$filter$iv2 = candidates;
/* 27 */                Collection destination$iv$iv2 = new ArrayList();
                        for (Object element$iv$iv2 : $this$filter$iv2) {
/* 28 */                    if (((CardCandidate) element$iv$iv2).getSchedule().getPhase() == Phase.NEW) {
                                destination$iv$iv2.add(element$iv$iv2);
                            }
                        }
/* 16 */                final Comparator comparator3 = new Comparator() { // from class: com.xunji.core.study.QueuePlanner$next$$inlined$compareBy$2
                            /* JADX WARN: Multi-variable type inference failed */
                            @Override // java.util.Comparator
/* 101 */                   public final int compare(T t, T t2) {
/* 102 */                       CardCandidate it3 = (CardCandidate) t;
/* 329 */                       Long lValueOf = Long.valueOf(it3.getCard().getCreatedAt());
/* 102 */                       CardCandidate it4 = (CardCandidate) t2;
/* 102 */                       return ComparisonsKt.compareValues(lValueOf, Long.valueOf(it4.getCard().getCreatedAt()));
                            }
                        };
/* 15 */                CardCandidate it3 = (CardCandidate) CollectionsKt.minWithOrNull((List) destination$iv$iv2, new Comparator() { // from class: com.xunji.core.study.QueuePlanner$next$$inlined$thenBy$3
                            /* JADX WARN: Multi-variable type inference failed */
                            @Override // java.util.Comparator
/* 143 */                   public final int compare(T t, T t2) {
/* 144 */                       int previousCompare = comparator3.compare(t, t2);
/* 145 */                       if (previousCompare != 0) {
                                    return previousCompare;
                                }
                                CardCandidate it4 = (CardCandidate) t;
/* 329 */                       String id = it4.getCard().getId();
/* 145 */                       CardCandidate it5 = (CardCandidate) t2;
/* 145 */                       return ComparisonsKt.compareValues(id, it5.getCard().getId());
                            }
                        });
/* 17 */                if (it3 != null) {
/* 17 */                    return new QueueDecision.Ready(it3);
                        }
                    }
/* 18 */            List<CardCandidate> $this$filter$iv3 = candidates;
/* 30 */            Collection destination$iv$iv3 = new ArrayList();
                    for (Object element$iv$iv3 : $this$filter$iv3) {
/* 31 */                if (((CardCandidate) element$iv$iv3).getSchedule().getPhase() != Phase.NEW) {
                            destination$iv$iv3.add(element$iv$iv3);
                        }
                    }
/* 18 */            Iterator it4 = ((List) destination$iv$iv3).iterator();
                    if (it4.hasNext()) {
/* 18 */                Long lValueOf = Long.valueOf(((CardCandidate) it4.next()).getSchedule().getDueAt());
                        while (it4.hasNext()) {
/* 18 */                    Long lValueOf2 = Long.valueOf(((CardCandidate) it4.next()).getSchedule().getDueAt());
                            if (lValueOf.compareTo(lValueOf2) > 0) {
                                lValueOf = lValueOf2;
                            }
                        }
                        l = lValueOf;
                    } else {
                        l = null;
                    }
                    Long next = l;
/* 19 */            return next != null ? new QueueDecision.Waiting(next.longValue()) : QueueDecision.Done.INSTANCE;
                }
            }

            package com.xunji.core.study;

            import kotlin.Metadata;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: SessionTimer.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005J\u000e\u0010\u000b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u0005J\u0006\u0010\f\u001a\u00020\tJ\u000e\u0010\r\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0005R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000R\u0012\u0010\u0006\u001a\u0004\u0018\u00010\u0005X\u0082\u000e¢\u0006\u0004\n\u0002\u0010\u0007¨\u0006\u000e"}, d2 = {"Lcom/xunji/core/study/SessionTimer;", "", "<init>", "()V", "accumulated", "", "started", "Ljava/lang/Long;", "resume", "", "monotonicMs", "pause", "reset", "elapsedMs", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final class SessionTimer {
                private long accumulated;
                private Long started;

/* 5 */         public final void resume(long monotonicMs) {
/* 6 */             if (this.started == null) {
                        this.started = Long.valueOf(monotonicMs);
                    }
                }

/* 6 */         public final void pause(long monotonicMs) {
/* 7 */             this.accumulated = elapsedMs(monotonicMs);
                    this.started = null;
                }

/* 7 */         public final void reset() {
/* 8 */             this.accumulated = 0L;
                    this.started = null;
                }

/* 8 */         public final long elapsedMs(long monotonicMs) {
/* 9 */             long j = this.accumulated;
                    Long l = this.started;
                    long jCoerceAtLeast = 0;
                    if (l != null) {
                        long it = l.longValue();
/* 9 */                 jCoerceAtLeast = RangesKt.coerceAtLeast(monotonicMs - it, 0L);
                    }
                    long it2 = j + jCoerceAtLeast;
                    return RangesKt.coerceIn(it2, 0L, 300000L);
                }
            }

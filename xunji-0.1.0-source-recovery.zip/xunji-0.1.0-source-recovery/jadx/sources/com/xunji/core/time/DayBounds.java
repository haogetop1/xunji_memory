            package com.xunji.core.time;

            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: LocalDay.kt */
            /* JADX INFO: loaded from: classes5.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0086\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0014"}, d2 = {"Lcom/xunji/core/time/DayBounds;", "", "start", "", "endExclusive", "<init>", "(JJ)V", "getStart", "()J", "getEndExclusive", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 2 */     public final /* data */ class DayBounds {
                private final long endExclusive;
                private final long start;

                public static /* synthetic */ DayBounds copy$default(DayBounds dayBounds, long j, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        j = dayBounds.start;
                    }
                    if ((i & 2) != 0) {
                        j2 = dayBounds.endExclusive;
                    }
                    return dayBounds.copy(j, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getStart() {
                    return this.start;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final long getEndExclusive() {
                    return this.endExclusive;
                }

                public final DayBounds copy(long start, long endExclusive) {
                    return new DayBounds(start, endExclusive);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof DayBounds)) {
                        return false;
                    }
                    DayBounds dayBounds = (DayBounds) other;
                    return this.start == dayBounds.start && this.endExclusive == dayBounds.endExclusive;
                }

                public int hashCode() {
                    return (Long.hashCode(this.start) * 31) + Long.hashCode(this.endExclusive);
                }

                public String toString() {
                    return "DayBounds(start=" + this.start + ", endExclusive=" + this.endExclusive + ")";
                }

/* 3 */         public DayBounds(long start, long endExclusive) {
                    this.start = start;
                    this.endExclusive = endExclusive;
                }

/* 3 */         public final long getEndExclusive() {
/* 4 */             return this.endExclusive;
                }

/* 3 */         public final long getStart() {
/* 4 */             return this.start;
                }
            }

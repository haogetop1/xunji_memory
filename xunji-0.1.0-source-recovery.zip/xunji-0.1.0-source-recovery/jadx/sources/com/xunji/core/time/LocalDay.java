            package com.xunji.core.time;

            import java.time.Instant;
            import java.time.LocalDate;
            import java.time.ZoneId;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: LocalDay.kt */
            /* JADX INFO: loaded from: classes5.dex */
            @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0016\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t¨\u0006\n"}, d2 = {"Lcom/xunji/core/time/LocalDay;", "", "<init>", "()V", "bounds", "Lcom/xunji/core/time/DayBounds;", "at", "Ljava/time/Instant;", "zone", "Ljava/time/ZoneId;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final class LocalDay {
                public static final LocalDay INSTANCE = new LocalDay();

/* 4 */         private LocalDay() {
                }

/* 6 */         public final DayBounds bounds(Instant at, ZoneId zone) {
                    Intrinsics.checkNotNullParameter(at, "at");
                    Intrinsics.checkNotNullParameter(zone, "zone");
/* 7 */             LocalDate date = at.atZone(zone).toLocalDate();
/* 8 */             return new DayBounds(date.atStartOfDay(zone).toInstant().toEpochMilli(), date.plusDays(1L).atStartOfDay(zone).toInstant().toEpochMilli());
                }
            }

            package com.xunji.core.validation;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: InputValidator.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\u0018\u00002\u00060\u0001j\u0002`\u0002B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007R\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lcom/xunji/core/validation/FieldValidationException;", "Ljava/lang/IllegalArgumentException;", "Lkotlin/IllegalArgumentException;", "field", "", "message", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "getField", "()Ljava/lang/String;", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public final class FieldValidationException extends IllegalArgumentException {
                private final String field;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
/* 1 */         public FieldValidationException(String field, String message) {
/* 2 */             super(message);
                    Intrinsics.checkNotNullParameter(field, "field");
                    Intrinsics.checkNotNullParameter(message, "message");
                    this.field = field;
                }

/* 1 */         public final String getField() {
/* 2 */             return this.field;
                }
            }

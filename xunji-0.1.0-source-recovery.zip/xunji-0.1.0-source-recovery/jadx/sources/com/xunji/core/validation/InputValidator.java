            package com.xunji.core.validation;

            import androidx.autofill.HintConstants;
            import com.fasterxml.jackson.databind.deser.DeserializerCache;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: InputValidator.kt */
            /* JADX INFO: loaded from: classes3.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005J\u001e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\u0005J(\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\u00052\u0006\u0010\u000e\u001a\u00020\u00052\u0006\u0010\u000f\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0012H\u0002¨\u0006\u0013"}, d2 = {"Lcom/xunji/core/validation/InputValidator;", "", "<init>", "()V", "deckName", "", "raw", "cardContent", "", "front", "back", "example", "check", "field", "text", "maximum", "", "required", "", "core"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 1 */     public final class InputValidator {
                public static final InputValidator INSTANCE = new InputValidator();

/* 2 */         private InputValidator() {
                }

/* 4 */         public final String deckName(String raw) {
                    Intrinsics.checkNotNullParameter(raw, "raw");
/* 5 */             String name = StringsKt.trim((CharSequence) raw).toString();
/* 6 */             check(HintConstants.AUTOFILL_HINT_NAME, name, 80, true);
/* 7 */             return name;
                }

/* 9 */         public final void cardContent(String front, String back, String example) {
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
/* 10 */            check("front", front, DeserializerCache.DEFAULT_MAX_CACHE_SIZE, true);
/* 11 */            check("back", back, 10000, true);
/* 12 */            check("example", example, 4000, false);
                }

/* 14 */        private final void check(String field, String text, int maximum, boolean required) {
/* 15 */            if (required && StringsKt.isBlank(text)) {
                        throw new FieldValidationException(field, "请填写此项");
                    }
/* 16 */            if (text.codePointCount(0, text.length()) > maximum) {
/* 16 */                throw new FieldValidationException(field, "最多填写 " + maximum + " 个字符");
                    }
                }
            }

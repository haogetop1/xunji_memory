            package com.xunji.flashcards;

            import android.content.ContentResolver;
            import android.content.Context;
            import com.xunji.core.scheduling.FsrsScheduler;
            import com.xunji.flashcards.anki.AnkiCardPresenter;
            import com.xunji.flashcards.anki.AnkiImportService;
            import com.xunji.flashcards.anki.FileOperationCoordinator;
            import com.xunji.flashcards.anki.MediaStore;
            import com.xunji.flashcards.backup.BackupFileGateway;
            import com.xunji.flashcards.backup.BackupService;
            import com.xunji.flashcards.backup.FileGateway;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.RoomStudyRepository;
            import com.xunji.flashcards.data.XunjiDatabase;
            import com.xunji.flashcards.study.ReviewService;
            import java.io.File;
            import java.time.Clock;
            import kotlin.Metadata;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AppContainer.kt */
            /* JADX INFO: loaded from: classes14.dex */
            @Metadata(d1 = {"\u0000j\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\u00020\u000fX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0014\u0010\u0012\u001a\u00020\u0013X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\u0016\u001a\u00020\u0017¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u001a\u001a\u00020\u001b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\u001e\u001a\u00020\u001f¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0014\u0010\"\u001a\u00020#X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0014\u0010&\u001a\u00020'X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b(\u0010)R\u0011\u0010*\u001a\u00020+¢\u0006\b\n\u0000\u001a\u0004\b,\u0010-R\u0014\u0010.\u001a\u00020/X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b0\u00101¨\u00062"}, d2 = {"Lcom/xunji/flashcards/AppContainer;", "", "context", "Landroid/content/Context;", "<init>", "(Landroid/content/Context;)V", "database", "Lcom/xunji/flashcards/data/XunjiDatabase;", "getDatabase", "()Lcom/xunji/flashcards/data/XunjiDatabase;", "repository", "Lcom/xunji/flashcards/data/RoomStudyRepository;", "getRepository", "()Lcom/xunji/flashcards/data/RoomStudyRepository;", "ankiRepository", "Lcom/xunji/flashcards/data/AnkiRepository;", "getAnkiRepository$app_debug", "()Lcom/xunji/flashcards/data/AnkiRepository;", "ankiPresenter", "Lcom/xunji/flashcards/anki/AnkiCardPresenter;", "getAnkiPresenter$app_debug", "()Lcom/xunji/flashcards/anki/AnkiCardPresenter;", "scheduler", "Lcom/xunji/core/scheduling/FsrsScheduler;", "getScheduler", "()Lcom/xunji/core/scheduling/FsrsScheduler;", "review", "Lcom/xunji/flashcards/study/ReviewService;", "getReview", "()Lcom/xunji/flashcards/study/ReviewService;", "files", "Lcom/xunji/flashcards/backup/FileGateway;", "getFiles", "()Lcom/xunji/flashcards/backup/FileGateway;", "fileOperations", "Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "getFileOperations$app_debug", "()Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "mediaStore", "Lcom/xunji/flashcards/anki/MediaStore;", "getMediaStore$app_debug", "()Lcom/xunji/flashcards/anki/MediaStore;", "backup", "Lcom/xunji/flashcards/backup/BackupService;", "getBackup", "()Lcom/xunji/flashcards/backup/BackupService;", "ankiImport", "Lcom/xunji/flashcards/anki/AnkiImportService;", "getAnkiImport$app_debug", "()Lcom/xunji/flashcards/anki/AnkiImportService;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 17 */    public final class AppContainer {
                public static final int $stable = 8;
                private final AnkiImportService ankiImport;
                private final AnkiCardPresenter ankiPresenter;
                private final AnkiRepository ankiRepository;
                private final BackupService backup;
                private final XunjiDatabase database;
                private final FileOperationCoordinator fileOperations;
                private final FileGateway files;
                private final MediaStore mediaStore;
                private final RoomStudyRepository repository;
                private final ReviewService review;
                private final FsrsScheduler scheduler;

                /* JADX WARN: Multi-variable type inference failed */
/* 18 */        public AppContainer(Context context) {
                    Intrinsics.checkNotNullParameter(context, "context");
/* 20 */            XunjiDatabase.Companion companion = XunjiDatabase.INSTANCE;
                    Context applicationContext = context.getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                    this.database = companion.open(applicationContext);
/* 21 */            this.repository = new RoomStudyRepository(this.database, null, null, 6, null);
/* 22 */            this.ankiRepository = new AnkiRepository(this.database);
/* 23 */            this.ankiPresenter = new AnkiCardPresenter(this.ankiRepository);
/* 24 */            this.scheduler = new FsrsScheduler();
                    Object[] objArr = 0 == true ? 1 : 0;
/* 25 */            this.review = new ReviewService(this.database, this.scheduler, objArr, null, 12, null);
                    ContentResolver contentResolver = context.getContentResolver();
                    Intrinsics.checkNotNullExpressionValue(contentResolver, "getContentResolver(...)");
/* 26 */            this.files = new BackupFileGateway(contentResolver);
/* 27 */            this.fileOperations = new FileOperationCoordinator();
/* 28 */            this.mediaStore = new MediaStore(new File(context.getFilesDir(), "anki-media"), this.database, this.fileOperations);
                    DefaultConstructorMarker defaultConstructorMarker = null;
                    Clock clock = null;
/* 29 */            this.backup = new BackupService(this.database, context, this.mediaStore, this.fileOperations, new File(context.getCacheDir(), "backups"), clock, null, 96, defaultConstructorMarker);
/* 30 */            this.ankiImport = new AnkiImportService(this.database, this.mediaStore, this.fileOperations, new File(context.getCacheDir(), "anki-import"), clock, 0 == true ? 1 : 0, 48, defaultConstructorMarker);
                }

/* 19 */        public final XunjiDatabase getDatabase() {
/* 20 */            return this.database;
                }

/* 20 */        public final RoomStudyRepository getRepository() {
/* 21 */            return this.repository;
                }

                /* JADX INFO: renamed from: getAnkiRepository$app_debug, reason: from getter */
/* 21 */        public final AnkiRepository getAnkiRepository() {
/* 22 */            return this.ankiRepository;
                }

                /* JADX INFO: renamed from: getAnkiPresenter$app_debug, reason: from getter */
/* 22 */        public final AnkiCardPresenter getAnkiPresenter() {
/* 23 */            return this.ankiPresenter;
                }

/* 23 */        public final FsrsScheduler getScheduler() {
/* 24 */            return this.scheduler;
                }

/* 24 */        public final ReviewService getReview() {
/* 25 */            return this.review;
                }

/* 25 */        public final FileGateway getFiles() {
/* 26 */            return this.files;
                }

                /* JADX INFO: renamed from: getFileOperations$app_debug, reason: from getter */
/* 26 */        public final FileOperationCoordinator getFileOperations() {
/* 27 */            return this.fileOperations;
                }

                /* JADX INFO: renamed from: getMediaStore$app_debug, reason: from getter */
/* 27 */        public final MediaStore getMediaStore() {
/* 28 */            return this.mediaStore;
                }

/* 28 */        public final BackupService getBackup() {
/* 29 */            return this.backup;
                }

                /* JADX INFO: renamed from: getAnkiImport$app_debug, reason: from getter */
/* 29 */        public final AnkiImportService getAnkiImport() {
/* 30 */            return this.ankiImport;
                }
            }

            package com.xunji.flashcards;

            import android.app.Application;
            import android.os.Bundle;
            import androidx.activity.ComponentActivity;
            import androidx.activity.EdgeToEdge;
            import androidx.activity.compose.ComponentActivityKt;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.WindowInsetsPadding_androidKt;
            import androidx.compose.material3.SurfaceKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.MutableIntState;
            import androidx.compose.runtime.SnapshotIntStateKt;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.flashcards.ui.XunjiAppKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import com.xunji.flashcards.ui.theme.ThemeKt;
            import kotlin.Metadata;
            import kotlin.Result;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: MainActivity.kt */
            /* JADX INFO: loaded from: classes14.dex */
            @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0012\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007H\u0014¨\u0006\b²\u0006\n\u0010\t\u001a\u00020\nX\u008a\u008e\u0002"}, d2 = {"Lcom/xunji/flashcards/MainActivity;", "Landroidx/activity/ComponentActivity;", "<init>", "()V", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "app_debug", "retry", ""}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final class MainActivity extends ComponentActivity {
                public static final int $stable = 8;

                @Override // androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
/* 17 */        protected void onCreate(Bundle savedInstanceState) {
/* 18 */            super.onCreate(savedInstanceState);
                    EdgeToEdge.enable$default(this, null, null, 3, null);
/* 19 */            ComponentActivityKt.setContent$default(this, null, ComposableLambdaKt.composableLambdaInstance(1377880644, true, new Function2() { // from class: com.xunji.flashcards.MainActivity$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(Object obj, Object obj2) {
                            return MainActivity.onCreate$lambda$0(this.f$0, (Composer) obj, ((Integer) obj2).intValue());
                        }
                    }), 1, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final Unit onCreate$lambda$0(MainActivity this$0, Composer $composer, int $changed) {
                    Object objM9077constructorimpl;
                    Unit unit;
                    ComposerKt.sourceInformation($composer, "C19@707L33,20@767L77:MainActivity.kt#ddtsym");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1377880644, $changed, -1, "com.xunji.flashcards.MainActivity.onCreate.<anonymous> (MainActivity.kt:19)");
                        }
/* 20 */                ComposerKt.sourceInformationMarkerStart($composer, 1293372613, "CC(remember):MainActivity.kt#9igjgp");
/* 27 */                Object objRememberedValue = $composer.rememberedValue();
/* 28 */                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 20 */                    Object objMutableIntStateOf = SnapshotIntStateKt.mutableIntStateOf(0);
/* 30 */                    $composer.updateRememberedValue(objMutableIntStateOf);
/* 31 */                    objRememberedValue = objMutableIntStateOf;
                        }
/* 20 */                final MutableIntState retry$delegate = (MutableIntState) objRememberedValue;
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 21 */                int iOnCreate$lambda$0$1 = onCreate$lambda$0$1(retry$delegate);
                        ComposerKt.sourceInformationMarkerStart($composer, 1293374577, "CC(remember):MainActivity.kt#9igjgp");
                        boolean zChanged = $composer.changed(iOnCreate$lambda$0$1);
/* 33 */                Object objRememberedValue2 = $composer.rememberedValue();
/* 34 */                if (zChanged || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                            try {
/* 21 */                        Result.Companion companion = Result.INSTANCE;
/* 21 */                        Application application = this$0.getApplication();
                                Intrinsics.checkNotNull(application, "null cannot be cast to non-null type com.xunji.flashcards.XunjiApplication");
                                objM9077constructorimpl = Result.m9077constructorimpl(((XunjiApplication) application).getContainer());
                            } catch (Throwable th) {
                                Result.Companion companion2 = Result.INSTANCE;
                                objM9077constructorimpl = Result.m9077constructorimpl(ResultKt.createFailure(th));
                            }
                            Object objM9076boximpl = Result.m9076boximpl(objM9077constructorimpl);
/* 37 */                    $composer.updateRememberedValue(objM9076boximpl);
/* 38 */                    objRememberedValue2 = objM9076boximpl;
                        }
/* 21 */                Object container = ((Result) objRememberedValue2).getValue();
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 22 */                AppContainer appContainer = (AppContainer) (Result.m9083isFailureimpl(container) ? null : container);
                        if (appContainer == null) {
                            $composer.startReplaceGroup(1440016491);
                            $composer.endReplaceGroup();
                            unit = null;
                        } else {
                            $composer.startReplaceGroup(1440016492);
                            ComposerKt.sourceInformation($composer, "*21@885L12");
/* 22 */                    XunjiAppKt.XunjiApp(appContainer, $composer, 0);
                            $composer.endReplaceGroup();
                            unit = Unit.INSTANCE;
                        }
                        if (unit == null) {
                            $composer.startReplaceGroup(1293378986);
                            ComposerKt.sourceInformation($composer, "21@913L155,21@902L166");
                            ThemeKt.XunjiTheme(null, ComposableLambdaKt.rememberComposableLambda(-1913822685, true, new Function2() { // from class: com.xunji.flashcards.MainActivity$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj, Object obj2) {
                                    return MainActivity.onCreate$lambda$0$5(retry$delegate, (Composer) obj, ((Integer) obj2).intValue());
                                }
                            }, $composer, 54), $composer, 48, 1);
                        } else {
                            $composer.startReplaceGroup(1293377591);
                        }
                        $composer.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 19 */                $composer.skipToGroupEnd();
                    }
/* 23 */            return Unit.INSTANCE;
                }

/* 19 */        private static final int onCreate$lambda$0$1(MutableIntState $retry$delegate) {
/* 40 */            return $retry$delegate.getIntValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 21 */        public static final Unit onCreate$lambda$0$5(final MutableIntState $retry$delegate, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C21@947L119,21@915L151:MainActivity.kt#ddtsym");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1913822685, $changed, -1, "com.xunji.flashcards.MainActivity.onCreate.<anonymous>.<anonymous> (MainActivity.kt:21)");
                        }
/* 22 */                SurfaceKt.m3412SurfaceT9BRK9s(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), null, 0L, 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-738352706, true, new Function2() { // from class: com.xunji.flashcards.MainActivity$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return MainActivity.onCreate$lambda$0$5$0($retry$delegate, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, $composer, 54), $composer, 12582918, 126);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:28:0x0154  */
                /* JADX WARN: Code duplicated, block: B:29:0x0166  */
                /* JADX WARN: Code duplicated, block: B:32:0x019b  */
/* 21 */        public static final Unit onCreate$lambda$0$5$0(final MutableIntState $retry$delegate, Composer $composer, int $changed) {
                    int i;
                    Object objRememberedValue;
                    ComposerKt.sourceInformation($composer, "C21@949L115:MainActivity.kt#ddtsym");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-738352706, $changed, -1, "com.xunji.flashcards.MainActivity.onCreate.<anonymous>.<anonymous>.<anonymous> (MainActivity.kt:21)");
                        }
/* 22 */                Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(WindowInsetsPadding_androidKt.statusBarsPadding(Modifier.INSTANCE), Dp.m8404constructorimpl(22));
/* 44 */                ComposerKt.sourceInformationMarkerStart($composer, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 49 */                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
/* 54 */                ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 55 */                int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 56 */                CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 57 */                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 59 */                Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 53 */                int i2 = ((((0 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 61 */                if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 62 */                $composer.startReusableNode();
/* 63 */                if ($composer.getInserting()) {
/* 64 */                    $composer.createNode(constructor);
                        } else {
/* 66 */                    $composer.useNode();
                        }
/* 68 */                Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 69 */                Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 70 */                Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 71 */                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 73 */                if (composerM4979constructorimpl.getInserting()) {
                            i = 0;
                        } else {
                            i = 0;
/* 72 */                    if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 78 */                    Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 80 */                    int i3 = (i2 >> 6) & 14;
/* 51 */                    ComposerKt.sourceInformationMarkerStart($composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i4 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, 781352397, "C21@1052L9,21@1000L62:MainActivity.kt#ddtsym");
                            ComposerKt.sourceInformationMarkerStart($composer, -2053003455, "CC(remember):MainActivity.kt#9igjgp");
                            objRememberedValue = $composer.rememberedValue();
/* 82 */                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                objRememberedValue = new Function0() { // from class: com.xunji.flashcards.MainActivity$$ExternalSyntheticLambda3
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return MainActivity.onCreate$lambda$0$5$0$0$0$0($retry$delegate);
                                    }
                                };
/* 84 */                        $composer.updateRememberedValue(objRememberedValue);
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 22 */                    XunjiComponentsKt.EmptyState("暂时无法打开循记", "你的数据会保留。请重试，或稍后重新打开应用。", "重试", (Function0) objRememberedValue, $composer, 3510, 0);
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 51 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 87 */                    $composer.endNode();
/* 60 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 54 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 44 */                    ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 72 */                composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 75 */                composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 78 */                Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 80 */                int i5 = (i2 >> 6) & 14;
/* 51 */                ComposerKt.sourceInformationMarkerStart($composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i6 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, 781352397, "C21@1052L9,21@1000L62:MainActivity.kt#ddtsym");
                        ComposerKt.sourceInformationMarkerStart($composer, -2053003455, "CC(remember):MainActivity.kt#9igjgp");
                        objRememberedValue = $composer.rememberedValue();
/* 82 */                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            objRememberedValue = new Function0() { // from class: com.xunji.flashcards.MainActivity$$ExternalSyntheticLambda3
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return MainActivity.onCreate$lambda$0$5$0$0$0$0($retry$delegate);
                                }
                            };
/* 84 */                    $composer.updateRememberedValue(objRememberedValue);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 22 */                XunjiComponentsKt.EmptyState("暂时无法打开循记", "你的数据会保留。请重试，或稍后重新打开应用。", "重试", (Function0) objRememberedValue, $composer, 3510, 0);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 51 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 87 */                $composer.endNode();
/* 60 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 54 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 44 */                ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 21 */        public static final Unit onCreate$lambda$0$5$0$0$0$0(MutableIntState $retry$delegate) {
/* 41 */            $retry$delegate.setIntValue(onCreate$lambda$0$1($retry$delegate) + 1);
                    return Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards;
            
            /* JADX INFO: loaded from: classes8.dex */
            public final class R {

                public static final class drawable {
                    public static int ic_xunji = 0x7f040006;

                    private drawable() {
                    }
                }

                public static final class string {
                    public static int app_name = 0x7f080001;

                    private string() {
                    }
                }

                public static final class xml {
                    public static int data_extraction_rules = 0x7f0b0000;

                    private xml() {
                    }
                }

                private R() {
                }
            }

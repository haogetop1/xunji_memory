            package com.xunji.flashcards;

            import android.app.Application;
            import androidx.core.view.MotionEventCompat;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.CoroutineScopeKt;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.SupervisorKt;
            
            /* JADX INFO: compiled from: AppContainer.kt */
            /* JADX INFO: loaded from: classes14.dex */
            @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\n\u001a\u00020\u000bH\u0016R\u001b\u0010\u0004\u001a\u00020\u00058FX\u0086\u0084\u0002¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\u0006\u0010\u0007¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/XunjiApplication;", "Landroid/app/Application;", "<init>", "()V", "container", "Lcom/xunji/flashcards/AppContainer;", "getContainer", "()Lcom/xunji/flashcards/AppContainer;", "container$delegate", "Lkotlin/Lazy;", "onCreate", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 31 */    public final class XunjiApplication extends Application {
                public static final int $stable = 8;

                /* JADX INFO: renamed from: container$delegate, reason: from kotlin metadata */
                private final Lazy container = LazyKt.lazy(new Function0() { // from class: com.xunji.flashcards.XunjiApplication$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return XunjiApplication.container_delegate$lambda$0(this.f$0);
                    }
                });

                /* JADX INFO: Access modifiers changed from: private */
/* 32 */        public static final AppContainer container_delegate$lambda$0(XunjiApplication this$0) {
/* 33 */            return new AppContainer(this$0);
                }

/* 32 */        public final AppContainer getContainer() {
/* 33 */            return (AppContainer) getValue();
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.XunjiApplication$onCreate$1, reason: invalid class name */
                /* JADX INFO: compiled from: AppContainer.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.XunjiApplication$onCreate$1", f = "AppContainer.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_6}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 34 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    int label;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return XunjiApplication.this.new AnonymousClass1(continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 35 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 36 */                            ResultKt.throwOnFailure($result);
                                    this.label = 1;
/* 37 */                            if (XunjiApplication.this.getContainer().getAnkiImport().initialize(this) == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (Exception e) {
                        }
/* 38 */                return Unit.INSTANCE;
                    }
                }

                @Override // android.app.Application
/* 34 */        public void onCreate() {
/* 35 */            super.onCreate();
/* 1 */             BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(SupervisorKt.SupervisorJob$default((Job) null, 1, (Object) null).plus(Dispatchers.getIO())), null, null, new AnonymousClass1(null), 3, null);
                }
            }

            package com.xunji.flashcards.anki;

            import androidx.autofill.HintConstants;
            import com.xunji.core.anki.AnkiMediaValidator;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiTemplateRenderer;
            import com.xunji.core.anki.CardSide;
            import com.xunji.core.anki.RenderIssue;
            import com.xunji.core.anki.RenderedSide;
            import com.xunji.core.anki.TemplateContext;
            import com.xunji.flashcards.data.AnkiCardEntity;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.AnkiNoteContent;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.UnsupportedEncodingException;
            import java.net.URLDecoder;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.NoSuchElementException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.collections.SetsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            import kotlin.text.MatchResult;
            import kotlin.text.Regex;
            import kotlin.text.RegexOption;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.DebugKt;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
            import org.jsoup.Jsoup;
            import org.jsoup.nodes.Attribute;
            import org.jsoup.nodes.Document;
            import org.jsoup.nodes.Element;
            import org.jsoup.nodes.TextNode;
            
            /* JADX INFO: compiled from: AnkiCardPresenter.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0003\b\u0001\u0018\u0000 \u00132\u00020\u0001:\u0001\u0013B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J \u0010\u0006\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\fJ4\u0010\r\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\t0\u0011H\u0086@¢\u0006\u0002\u0010\u0012R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiCardPresenter;", "", "repository", "Lcom/xunji/flashcards/data/AnkiRepository;", "<init>", "(Lcom/xunji/flashcards/data/AnkiRepository;)V", "present", "Lcom/xunji/flashcards/anki/RenderedCard;", "cardId", "", "side", "Lcom/xunji/core/anki/CardSide;", "(Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "preview", "content", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "fields", "", "(Lcom/xunji/flashcards/data/AnkiNoteContent;Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */    public final class AnkiCardPresenter {
                public static final String ORIGIN = "https://anki.xunji.invalid/";
                private final AnkiRepository repository;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = XunjiDatabase.$stable;
                private static final Regex cssUrl = new Regex("url\\(\\s*(['\"]?)(.*?)\\1\\s*\\)", RegexOption.IGNORE_CASE);
                private static final Regex sound = new Regex("\\[sound:[^\\]\\r\\n]+]");

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiCardPresenter$present$2, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiCardPresenter.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/RenderedCard;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiCardPresenter$present$2", f = "AnkiCardPresenter.kt", i = {1}, l = {17, 18}, m = "invokeSuspend", n = {"content"}, s = {"L$0"}, v = 1)
/* 14 */        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super RenderedCard>, Object> {
                    final /* synthetic */ String $cardId;
                    final /* synthetic */ CardSide $side;
                    Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(String str, CardSide cardSide, Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                        this.$cardId = str;
                        this.$side = cardSide;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiCardPresenter.this.new AnonymousClass2(this.$cardId, this.$side, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super RenderedCard> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 15 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objNoteForCard;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 15 */                        objNoteForCard = AnkiCardPresenter.this.repository.noteForCard(this.$cardId, this);
                                if (objNoteForCard == coroutine_suspended) {
/* 16 */                            return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                objNoteForCard = $result;
                                break;
                            case 2:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 17 */                AnkiNoteContent content = (AnkiNoteContent) objNoteForCard;
                        if (content == null) {
                            return null;
                        }
                        this.L$0 = SpillingKt.nullOutSpilledVariable(content);
                        this.label = 2;
/* 18 */                Object objPreview = AnkiCardPresenter.this.preview(content, this.$cardId, this.$side, AnkiRepository.INSTANCE.strings(content.getNote().getFields()), this);
                        return objPreview == coroutine_suspended ? coroutine_suspended : objPreview;
                    }
                }

/* 14 */        public AnkiCardPresenter(AnkiRepository repository) {
                    Intrinsics.checkNotNullParameter(repository, "repository");
                    this.repository = repository;
                }

/* 15 */        public final Object present(String cardId, CardSide side, Continuation<? super RenderedCard> continuation) {
/* 16 */            return BuildersKt.withContext(Dispatchers.getDefault(), new AnonymousClass2(cardId, side, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiCardPresenter$preview$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiCardPresenter.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/RenderedCard;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiCardPresenter$preview$2", f = "AnkiCardPresenter.kt", i = {0, 0}, l = {24}, m = "invokeSuspend", n = {"model", "link"}, s = {"L$0", "L$1"}, v = 1)
/* 19 */        static final class C04082 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super RenderedCard>, Object> {
                    final /* synthetic */ String $cardId;
                    final /* synthetic */ AnkiNoteContent $content;
                    final /* synthetic */ List<String> $fields;
                    final /* synthetic */ CardSide $side;
                    Object L$0;
                    Object L$1;
                    int label;
                    final /* synthetic */ AnkiCardPresenter this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04082(AnkiNoteContent ankiNoteContent, AnkiCardPresenter ankiCardPresenter, List<String> list, CardSide cardSide, String str, Continuation<? super C04082> continuation) {
                        super(2, continuation);
                        this.$content = ankiNoteContent;
                        this.this$0 = ankiCardPresenter;
                        this.$fields = list;
                        this.$side = cardSide;
                        this.$cardId = str;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04082(this.$content, this.this$0, this.$fields, this.$side, this.$cardId, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super RenderedCard> continuation) {
                        return ((C04082) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 20 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objContext;
                        AnkiCardEntity link;
                        AnkiModel model;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 22 */                        AnkiModel model2 = AnkiRepository.INSTANCE.asModel(this.$content.getModel());
/* 23 */                        Iterable links = this.$content.getLinks();
                                String str = this.$cardId;
/* 74 */                        Object obj = null;
/* 75 */                        boolean z = false;
                                for (Object obj2 : links) {
/* 77 */                            if (Intrinsics.areEqual(((AnkiCardEntity) obj2).getCardId(), str)) {
/* 78 */                                if (z) {
/* 78 */                                    throw new IllegalArgumentException("Collection contains more than one matching element.");
                                        }
/* 79 */                                obj = obj2;
/* 80 */                                z = true;
                                    }
                                }
/* 83 */                        if (z) {
/* 23 */                            AnkiCardEntity link2 = (AnkiCardEntity) obj;
                                    this.L$0 = model2;
                                    this.L$1 = link2;
                                    this.label = 1;
/* 15 */                            objContext = this.this$0.repository.context(this.$content, link2, model2, this);
                                    if (objContext == coroutine_suspended) {
/* 21 */                                return coroutine_suspended;
                                    }
/* 24 */                            link = link2;
                                    model = model2;
                                } else {
/* 83 */                            throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                }
                                break;
                            case 1:
                                link = (AnkiCardEntity) this.L$1;
                                AnkiModel model3 = (AnkiModel) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objContext = $result;
                                model = model3;
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 21 */                TemplateContext context = (TemplateContext) objContext;
/* 25 */                RenderedSide rendered = new AnkiTemplateRenderer().render(model, this.$fields, link.getOrdinal(), this.$side, context);
/* 26 */                if (!rendered.getIssues().isEmpty()) {
/* 26 */                    throw new IllegalArgumentException(CollectionsKt.joinToString$default(CollectionsKt.take(rendered.getIssues(), 4), "; ", null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.anki.AnkiCardPresenter$preview$2$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj3) {
                                    return AnkiCardPresenter.C04082.invokeSuspend$lambda$1$0((RenderIssue) obj3);
                                }
                            }, 30, null).toString());
                        }
/* 27 */                return AnkiCardPresenter.INSTANCE.bind$app_debug(this.$cardId, this.$side, rendered, model.getCss(), this.$content);
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 25 */            public static final CharSequence invokeSuspend$lambda$1$0(RenderIssue it) {
                        return StringsKt.take(it.getCode(), 64) + ": " + StringsKt.take(it.getDetail(), 160);
                    }
                }

/* 20 */        public final Object preview(AnkiNoteContent content, String cardId, CardSide side, List<String> list, Continuation<? super RenderedCard> continuation) {
/* 21 */            return BuildersKt.withContext(Dispatchers.getDefault(), new C04082(content, this, list, side, cardId, null), continuation);
                }

                /* JADX INFO: compiled from: AnkiCardPresenter.kt */
                @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J5\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\u00052\u0006\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u000f2\u0006\u0010\u0010\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u0012H\u0000¢\u0006\u0002\b\u0013R\u000e\u0010\u0004\u001a\u00020\u0005X\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0014"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiCardPresenter$Companion;", "", "<init>", "()V", "ORIGIN", "", "cssUrl", "Lkotlin/text/Regex;", "sound", "bind", "Lcom/xunji/flashcards/anki/RenderedCard;", "cardId", "side", "Lcom/xunji/core/anki/CardSide;", "rendered", "Lcom/xunji/core/anki/RenderedSide;", "css", "content", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "bind$app_debug", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 28 */        public static final class Companion {
/* 29 */            private Companion() {
                    }

/* 34 */            public final RenderedCard bind$app_debug(String cardId, CardSide side, RenderedSide rendered, String css, AnkiNoteContent content) {
                        Intrinsics.checkNotNullParameter(cardId, "cardId");
                        Intrinsics.checkNotNullParameter(side, "side");
                        Intrinsics.checkNotNullParameter(rendered, "rendered");
                        Intrinsics.checkNotNullParameter(css, "css");
                        Intrinsics.checkNotNullParameter(content, "content");
/* 35 */                if (!rendered.getIssues().isEmpty()) {
                            throw new IllegalArgumentException("Incompatible card must not display partial HTML".toString());
                        }
/* 36 */                Iterable media = content.getMedia();
/* 76 */                final Map rows = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(media, 10)), 16));
                        for (Object obj : media) {
/* 78 */                    rows.put(((AnkiMediaEntity) obj).getOriginalName(), obj);
                        }
/* 37 */                if (!AnkiMediaValidator.INSTANCE.issues(rendered, new Function1() { // from class: com.xunji.flashcards.anki.AnkiCardPresenter$Companion$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return AnkiCardPresenter.Companion.bind$lambda$2(rows, (String) obj2);
                            }
                        }).isEmpty()) {
                            throw new IllegalArgumentException("Unsupported media role/MIME".toString());
                        }
/* 38 */                Iterable<String> iterableDistinct = CollectionsKt.distinct(rendered.getResourceNames());
/* 81 */                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterableDistinct, 10));
                        for (String str : iterableDistinct) {
/* 39 */                    Object obj2 = rows.get(str);
                            if (obj2 == null) {
/* 39 */                        throw new IllegalArgumentException("Required value was null.".toString());
                            }
                            AnkiMediaEntity ankiMediaEntity = (AnkiMediaEntity) obj2;
/* 83 */                    arrayList.add(new CardMedia(ankiMediaEntity.getNamespace(), str, ankiMediaEntity.getMime()));
                            iterableDistinct = iterableDistinct;
                        }
                        List resources = (List) arrayList;
/* 42 */                List list = resources;
                        int i = 0;
/* 85 */                Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
/* 86 */                int i2 = 0;
                        for (Object obj3 : list) {
/* 88 */                    int i3 = i2 + 1;
                            if (i2 < 0) {
                                CollectionsKt.throwIndexOverflow();
                            }
/* 88 */                    arrayList2.add(TuplesKt.to(((CardMedia) obj3).getName(), "https://anki.xunji.invalid/media/" + i2));
                            i2 = i3;
/* 42 */                    resources = resources;
                            list = list;
                            i = i;
                        }
/* 89 */                List resources2 = resources;
/* 42 */                final Map urls = MapsKt.toMap((List) arrayList2);
/* 49 */                Document doc = Jsoup.parse(rendered.getHtml());
                        Intrinsics.checkNotNullExpressionValue(doc, "parse(...)");
/* 50 */                doc.select("script,iframe,object,embed,form,base,meta,link,svg,math,video,audio").remove();
/* 51 */                Iterable allElements = doc.getAllElements();
                        Intrinsics.checkNotNullExpressionValue(allElements, "getAllElements(...)");
                        Iterable<Element> iterable = allElements;
                        int i4 = 0;
                        for (Element element : iterable) {
/* 52 */                    Iterable iterableAsList = element.attributes().asList();
                            Iterable iterable2 = iterable;
                            Intrinsics.checkNotNullExpressionValue(iterableAsList, "asList(...)");
                            Iterable<Attribute> iterable3 = iterableAsList;
                            for (Attribute attribute : iterable3) {
/* 54 */                        Iterable iterable4 = iterable3;
                                String key = attribute.getKey();
                                int i5 = i4;
                                Intrinsics.checkNotNullExpressionValue(key, "<get-key>(...)");
                                if (StringsKt.startsWith(key, DebugKt.DEBUG_PROPERTY_VALUE_ON, true) || SetsKt.setOf((Object[]) new String[]{"srcdoc", "href", "action", "formaction", "target", "download"}).contains(attribute.getKey())) {
/* 54 */                            element.removeAttr(attribute.getKey());
                                } else if (Intrinsics.areEqual(attribute.getKey(), "style")) {
                                    String value = attribute.getValue();
                                    Intrinsics.checkNotNullExpressionValue(value, "<get-value>(...)");
                                    element.attr("style", bind$rewriteCss(urls, value));
                                } else if (Intrinsics.areEqual(attribute.getKey(), "src")) {
                                    String value2 = attribute.getValue();
                                    Intrinsics.checkNotNullExpressionValue(value2, "<get-value>(...)");
                                    element.attr("src", bind$url(urls, value2));
                                } else if (Intrinsics.areEqual(attribute.getKey(), "srcset")) {
                                    String value3 = attribute.getValue();
                                    Intrinsics.checkNotNullExpressionValue(value3, "<get-value>(...)");
                                    element.attr("srcset", CollectionsKt.joinToString$default(StringsKt.split$default((CharSequence) value3, new char[]{AbstractJsonLexerKt.COMMA}, false, 0, 6, (Object) null), ",", null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.anki.AnkiCardPresenter$Companion$$ExternalSyntheticLambda2
                                        @Override // kotlin.jvm.functions.Function1
                                        public final Object invoke(Object obj4) {
                                            return AnkiCardPresenter.Companion.bind$lambda$8$0$0(urls, (String) obj4);
                                        }
                                    }, 30, null));
                                }
                                iterable3 = iterable4;
                                i4 = i5;
                            }
                            int i6 = i4;
/* 60 */                    if (Intrinsics.areEqual(element.tagName(), "style")) {
                                String strData = element.data();
                                Intrinsics.checkNotNullExpressionValue(strData, "data(...)");
                                element.text(bind$rewriteCss(urls, strData));
                            }
/* 61 */                    Iterable iterableChildNodes = element.childNodes();
                            Intrinsics.checkNotNullExpressionValue(iterableChildNodes, "childNodes(...)");
                            Iterable iterable5 = iterableChildNodes;
                            int i7 = 0;
/* 93 */                    Collection arrayList3 = new ArrayList();
                            for (Object obj4 : iterable5) {
                                Iterable iterable6 = iterable5;
                                int i8 = i7;
                                if (obj4 instanceof TextNode) {
                                    arrayList3.add(obj4);
                                }
                                iterable5 = iterable6;
                                i7 = i8;
                            }
                            Iterable iterable7 = (List) arrayList3;
                            int i9 = 0;
                            for (Iterator it = iterable7.iterator(); it.hasNext(); it = it) {
                                TextNode textNode = (TextNode) it.next();
/* 61 */                        Iterable iterable8 = iterable7;
/* 15 */                        Regex regex = AnkiCardPresenter.sound;
                                int i10 = i9;
                                String wholeText = textNode.getWholeText();
                                Intrinsics.checkNotNullExpressionValue(wholeText, "getWholeText(...)");
                                textNode.text(regex.replace(wholeText, ""));
/* 104 */                       iterable7 = iterable8;
                                i9 = i10;
                            }
                            iterable = iterable2;
                            i4 = i6;
                        }
/* 63 */                doc.head().prependElement("meta").attr("http-equiv", "Content-Security-Policy").attr("content", "default-src 'none'; img-src https://anki.xunji.invalid/; font-src https://anki.xunji.invalid/; style-src 'unsafe-inline'; connect-src 'none'; frame-src 'none'; form-action 'none'; base-uri 'none'");
/* 64 */                doc.head().appendElement("meta").attr(HintConstants.AUTOFILL_HINT_NAME, "viewport").attr("content", "width=device-width, initial-scale=1");
/* 65 */                doc.head().appendElement("style").text(bind$rewriteCss(urls, css));
/* 66 */                doc.head().appendElement("style").text("html{color-scheme:light dark}body{margin:16px;overflow-wrap:anywhere;font-size:20px;line-height:1.6}img{max-width:100%;height:auto} .card{max-width:100%}");
/* 67 */                doc.body().addClass("card");
/* 68 */                Iterable<String> audioNames = rendered.getAudioNames();
                        int i11 = 0;
/* 107 */               Collection arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(audioNames, 10));
                        for (String str2 : audioNames) {
/* 68 */                    Object obj5 = rows.get(str2);
                            if (obj5 == null) {
                                throw new IllegalArgumentException("Required value was null.".toString());
                            }
                            AnkiMediaEntity ankiMediaEntity2 = (AnkiMediaEntity) obj5;
/* 109 */                   arrayList4.add(new CardMedia(ankiMediaEntity2.getNamespace(), str2, ankiMediaEntity2.getMime()));
                            audioNames = audioNames;
                            i11 = i11;
                        }
                        List audio = (List) arrayList4;
/* 69 */                String strOuterHtml = doc.outerHtml();
                        Intrinsics.checkNotNullExpressionValue(strOuterHtml, "outerHtml(...)");
                        List list2 = resources2;
/* 112 */               Map linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(list2, 10)), 16));
                        for (Object obj6 : list2) {
/* 114 */                   linkedHashMap.put((String) MapsKt.getValue(urls, ((CardMedia) obj6).getName()), obj6);
/* 69 */                    list2 = list2;
                        }
/* 69 */                return new RenderedCard(cardId, side, strOuterHtml, linkedHashMap, audio);
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 36 */            public static final String bind$lambda$2(Map $rows, String it) {
                        Intrinsics.checkNotNullParameter(it, "it");
/* 37 */                AnkiMediaEntity ankiMediaEntity = (AnkiMediaEntity) $rows.get(it);
                        if (ankiMediaEntity != null) {
                            return ankiMediaEntity.getMime();
                        }
                        return null;
                    }

/* 43 */            private static final String bind$url(Map<String, String> map, String raw) throws UnsupportedEncodingException {
                        String decoded;
/* 44 */                String name = StringsKt.trim((CharSequence) raw).toString();
                        try {
/* 45 */                    decoded = URLDecoder.decode(StringsKt.replace$default(name, "+", "%2B", false, 4, (Object) null), "UTF-8");
                        } catch (IllegalArgumentException e) {
                            decoded = name;
                        }
/* 46 */                String str = map.get(name);
                        if (str == null) {
                            str = map.get(decoded);
                        }
                        if (str != null) {
                            return str;
                        }
                        throw new IllegalArgumentException("Unbound resource".toString());
                    }

/* 47 */            private static final String bind$rewriteCss(final Map<String, String> map, String text) {
/* 15 */                return AnkiCardPresenter.cssUrl.replace(text, new Function1() { // from class: com.xunji.flashcards.anki.AnkiCardPresenter$Companion$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return AnkiCardPresenter.Companion.bind$rewriteCss$lambda$7(map, (MatchResult) obj);
                            }
                        });
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 47 */            public static final CharSequence bind$rewriteCss$lambda$7(Map $urls, MatchResult it) throws UnsupportedEncodingException {
                        Intrinsics.checkNotNullParameter(it, "it");
                        return "url(\"" + bind$url($urls, it.getGroupValues().get(2)) + "\")";
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 56 */            public static final CharSequence bind$lambda$8$0$0(Map $urls, String part) throws UnsupportedEncodingException {
                        String str;
                        Intrinsics.checkNotNullParameter(part, "part");
/* 57 */                List<String> listSplit = new Regex("\\s+").split(StringsKt.trim((CharSequence) part).toString(), 2);
                        String strBind$url = bind$url($urls, listSplit.get(0));
                        if (listSplit.size() == 2) {
                            str = " " + ((Object) listSplit.get(1));
                        } else {
                            str = "";
                        }
                        return strBind$url + str;
                    }
                }
            }

            package com.xunji.flashcards.anki;

            import com.xunji.core.anki.ImportIssue;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.Grouping;
            import kotlin.collections.GroupingKt;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u000b\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0000\b\u0001\u0018\u00002\u00020\u0001B\u0017\b\u0000\u0012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\u0004\b\u0005\u0010\u0006J&\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\u0006\u0010\u001b\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\n2\b\b\u0002\u0010\u001d\u001a\u00020\u001eR\u0017\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\r\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u000f\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\fR\u0011\u0010\u0011\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\fR\u0017\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00040\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\bR\u001d\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\n0\u0016¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019¨\u0006\u001f"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiImportReport;", "", "cards", "", "Lcom/xunji/flashcards/anki/ImportPreviewCard;", "<init>", "(Ljava/util/List;)V", "getCards", "()Ljava/util/List;", "totalCards", "", "getTotalCards", "()I", "compatibleCards", "getCompatibleCards", "duplicateCards", "getDuplicateCards", "skippedCards", "getSkippedCards", "affectedCards", "getAffectedCards", "reasons", "", "", "getReasons", "()Ljava/util/Map;", "page", "index", "size", "issuesOnly", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 27 */    public final class AnkiImportReport {
                public static final int $stable = 8;
                private final List<ImportPreviewCard> affectedCards;
                private final List<ImportPreviewCard> cards;
                private final int compatibleCards;
                private final int duplicateCards;
                private final Map<String, Integer> reasons;
                private final int skippedCards;
                private final int totalCards;

/* 28 */        public AnkiImportReport(List<ImportPreviewCard> cards) {
                    int i;
                    int i2;
                    Intrinsics.checkNotNullParameter(cards, "cards");
                    this.cards = cards;
/* 30 */            this.totalCards = this.cards.size();
/* 31 */            Iterable iterable = this.cards;
                    int i3 = 0;
/* 347 */           if ((iterable instanceof Collection) && ((Collection) iterable).isEmpty()) {
                        i = 0;
                    } else {
/* 348 */               i = 0;
/* 349 */               Iterator it = iterable.iterator();
                        while (it.hasNext()) {
/* 349 */                   if ((((ImportPreviewCard) it.next()).getStatus() == PreviewStatus.COMPATIBLE) && (i = i + 1) < 0) {
                                CollectionsKt.throwCountOverflow();
                            }
                        }
                    }
/* 31 */            this.compatibleCards = i;
/* 32 */            Iterable iterable2 = this.cards;
/* 351 */           if ((iterable2 instanceof Collection) && ((Collection) iterable2).isEmpty()) {
                        i2 = 0;
                    } else {
/* 352 */               i2 = 0;
/* 353 */               Iterator it2 = iterable2.iterator();
                        while (it2.hasNext()) {
/* 353 */                   if ((((ImportPreviewCard) it2.next()).getStatus() == PreviewStatus.DUPLICATE) && (i2 = i2 + 1) < 0) {
                                CollectionsKt.throwCountOverflow();
                            }
                        }
                    }
/* 32 */            this.duplicateCards = i2;
/* 33 */            Iterable iterable3 = this.cards;
/* 355 */           if (!(iterable3 instanceof Collection) || !((Collection) iterable3).isEmpty()) {
/* 356 */               int i4 = 0;
/* 357 */               Iterator it3 = iterable3.iterator();
                        while (it3.hasNext()) {
/* 357 */                   if ((((ImportPreviewCard) it3.next()).getStatus() == PreviewStatus.SKIPPED) && (i4 = i4 + 1) < 0) {
                                CollectionsKt.throwCountOverflow();
                            }
                        }
/* 358 */               i3 = i4;
                    }
/* 33 */            this.skippedCards = i3;
/* 34 */            Iterable iterable4 = this.cards;
/* 359 */           Collection arrayList = new ArrayList();
                    for (Object obj : iterable4) {
/* 360 */               if (!((ImportPreviewCard) obj).getIssues().isEmpty()) {
                            arrayList.add(obj);
                        }
                    }
/* 34 */            this.affectedCards = (List) arrayList;
/* 35 */            Iterable iterable5 = this.affectedCards;
/* 362 */           Collection arrayList2 = new ArrayList();
/* 363 */           Iterator it4 = iterable5.iterator();
                    while (it4.hasNext()) {
/* 365 */               CollectionsKt.addAll(arrayList2, ((ImportPreviewCard) it4.next()).getIssues());
                    }
                    final Iterable iterable6 = (List) arrayList2;
/* 35 */            this.reasons = GroupingKt.eachCount(new Grouping<ImportIssue, String>() { // from class: com.xunji.flashcards.anki.AnkiImportReport$special$$inlined$groupingBy$1
                        @Override // kotlin.collections.Grouping
/* 1550 */              public Iterator<ImportIssue> sourceIterator() {
/* 1551 */                  return iterable6.iterator();
                        }

                        @Override // kotlin.collections.Grouping
/* 1551 */              public String keyOf(ImportIssue element) {
/* 3795 */                  return element.getCode();
                        }
                    });
                }

/* 28 */        public final List<ImportPreviewCard> getCards() {
/* 29 */            return this.cards;
                }

/* 29 */        public final int getTotalCards() {
/* 30 */            return this.totalCards;
                }

/* 30 */        public final int getCompatibleCards() {
/* 31 */            return this.compatibleCards;
                }

/* 31 */        public final int getDuplicateCards() {
/* 32 */            return this.duplicateCards;
                }

/* 32 */        public final int getSkippedCards() {
/* 33 */            return this.skippedCards;
                }

/* 33 */        public final List<ImportPreviewCard> getAffectedCards() {
/* 34 */            return this.affectedCards;
                }

/* 34 */        public final Map<String, Integer> getReasons() {
/* 35 */            return this.reasons;
                }

/* 35 */        public static /* synthetic */ List page$default(AnkiImportReport ankiImportReport, int i, int i2, boolean z, int i3, Object obj) {
/* 36 */            if ((i3 & 4) != 0) {
                        z = false;
                    }
                    return ankiImportReport.page(i, i2, z);
                }

/* 36 */        public final List<ImportPreviewCard> page(int index, int size, boolean issuesOnly) {
/* 37 */            boolean z = false;
                    if (index >= 0) {
/* 37 */                if (1 <= size && size < 101) {
                            z = true;
                        }
                    }
                    if (z) {
                        return CollectionsKt.take(CollectionsKt.drop(issuesOnly ? this.affectedCards : this.cards, index * size), size);
                    }
                    throw new IllegalArgumentException("Invalid preview page".toString());
                }
            }

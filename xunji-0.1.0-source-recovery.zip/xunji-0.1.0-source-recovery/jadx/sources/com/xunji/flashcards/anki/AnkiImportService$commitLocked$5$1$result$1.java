            package com.xunji.flashcards.anki;

            import androidx.compose.material3.ProgressIndicatorKt;
            import androidx.core.view.InputDeviceCompat;
            import androidx.room.RoomDatabaseKt;
            import com.xunji.core.anki.AnkiMediaValidator;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiSourceCard;
            import com.xunji.core.anki.AnkiSourceDeck;
            import com.xunji.core.anki.AnkiSourceNote;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.anki.CardSide;
            import com.xunji.core.anki.RenderedSide;
            import com.xunji.core.anki.TemplateContext;
            import com.xunji.flashcards.data.AnkiCardEntity;
            import com.xunji.flashcards.data.AnkiDao;
            import com.xunji.flashcards.data.AnkiDeckSourceEntity;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.AnkiModelEntity;
            import com.xunji.flashcards.data.AnkiNoteEntity;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.CardEntity;
            import com.xunji.flashcards.data.DeckEntity;
            import com.xunji.flashcards.data.ScheduleEntity;
            import com.xunji.flashcards.data.XunjiDao;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.NoSuchElementException;
            import java.util.Set;
            import java.util.UUID;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.ranges.RangesKt;
            import kotlin.sequences.SequencesKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.JobKt;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/ImportResult;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1", f = "AnkiImportService.kt", i = {0}, l = {223}, m = "invokeSuspend", n = {"$this$withContext"}, s = {"L$0"}, v = 1)
/* 220 */   final class AnkiImportService$commitLocked$5$1$result$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super ImportResult>, Object> {
                final /* synthetic */ Job $caller;
                final /* synthetic */ Ref.ObjectRef<ImportResult> $completed;
                final /* synthetic */ int $duplicateCount;
                final /* synthetic */ PreparedAnkiImport $prepared;
                final /* synthetic */ Map<String, Integer> $reasons;
                final /* synthetic */ List<ImportPreviewCard> $selectedCards;
                final /* synthetic */ Set<String> $selectedGuids;
                final /* synthetic */ int $skipped;
                final /* synthetic */ StagedMedia $staged;
                private /* synthetic */ Object L$0;
                int label;
                final /* synthetic */ AnkiImportService this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnkiImportService$commitLocked$5$1$result$1(AnkiImportService ankiImportService, PreparedAnkiImport preparedAnkiImport, List<ImportPreviewCard> list, int i, Job job, int i2, Map<String, Integer> map, Set<String> set, StagedMedia stagedMedia, Ref.ObjectRef<ImportResult> objectRef, Continuation<? super AnkiImportService$commitLocked$5$1$result$1> continuation) {
                    super(2, continuation);
                    this.this$0 = ankiImportService;
                    this.$prepared = preparedAnkiImport;
                    this.$selectedCards = list;
                    this.$duplicateCount = i;
                    this.$caller = job;
                    this.$skipped = i2;
                    this.$reasons = map;
                    this.$selectedGuids = set;
                    this.$staged = stagedMedia;
                    this.$completed = objectRef;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    AnkiImportService$commitLocked$5$1$result$1 ankiImportService$commitLocked$5$1$result$1 = new AnkiImportService$commitLocked$5$1$result$1(this.this$0, this.$prepared, this.$selectedCards, this.$duplicateCount, this.$caller, this.$skipped, this.$reasons, this.$selectedGuids, this.$staged, this.$completed, continuation);
                    ankiImportService$commitLocked$5$1$result$1.L$0 = obj;
                    return ankiImportService$commitLocked$5$1$result$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super ImportResult> continuation) {
                    return ((AnkiImportService$commitLocked$5$1$result$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/ImportResult;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1", f = "AnkiImportService.kt", i = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, l = {226, 239}, m = "invokeSuspend", n = {"$this$forEach\\3", "element\\3", "guid\\4", "revision\\4", "$i$f$forEach\\3\\224", "$i$a$-forEach-AnkiImportService$commitLocked$5$1$result$1$1$2\\4\\354\\0", "sourceById", "localNotes", "localDecks", "added", "duplicates", "notes", "decks", "mediaStored", "cachedMediaNamespace", "cachedMediaMimes", "now"}, s = {"L$0", "L$4", "L$5", "L$6", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "J$0"}, v = 1)
/* 221 */       static final class AnonymousClass1 extends SuspendLambda implements Function1<Continuation<? super ImportResult>, Object> {
                    final /* synthetic */ CoroutineScope $$this$withContext;
                    final /* synthetic */ Job $caller;
                    final /* synthetic */ int $duplicateCount;
                    final /* synthetic */ PreparedAnkiImport $prepared;
                    final /* synthetic */ Map<String, Integer> $reasons;
                    final /* synthetic */ List<ImportPreviewCard> $selectedCards;
                    final /* synthetic */ Set<String> $selectedGuids;
                    final /* synthetic */ int $skipped;
                    final /* synthetic */ StagedMedia $staged;
                    int I$0;
                    int I$1;
                    long J$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    Object L$9;
                    int label;
                    final /* synthetic */ AnkiImportService this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(PreparedAnkiImport preparedAnkiImport, List<ImportPreviewCard> list, int i, AnkiImportService ankiImportService, Job job, int i2, Map<String, Integer> map, Set<String> set, StagedMedia stagedMedia, CoroutineScope coroutineScope, Continuation<? super AnonymousClass1> continuation) {
                        super(1, continuation);
                        this.$prepared = preparedAnkiImport;
                        this.$selectedCards = list;
                        this.$duplicateCount = i;
                        this.this$0 = ankiImportService;
                        this.$caller = job;
                        this.$skipped = i2;
                        this.$reasons = map;
                        this.$selectedGuids = set;
                        this.$staged = stagedMedia;
                        this.$$this$withContext = coroutineScope;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return new AnonymousClass1(this.$prepared, this.$selectedCards, this.$duplicateCount, this.this$0, this.$caller, this.$skipped, this.$reasons, this.$selectedGuids, this.$staged, this.$$this$withContext, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super ImportResult> continuation) {
                        return ((AnonymousClass1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:17:0x00d7  */
                    /* JADX WARN: Code duplicated, block: B:19:0x00ed  */
                    /* JADX WARN: Code duplicated, block: B:22:0x011a A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:23:0x011b  */
                    /* JADX WARN: Code duplicated, block: B:26:0x0126  */
                    /* JADX WARN: Code duplicated, block: B:27:0x012f  */
                    /* JADX WARN: Code duplicated, block: B:30:0x0136 A[ADDED_TO_REGION] */
                    /* JADX WARN: Code duplicated, block: B:33:0x013c  */
                    /* JADX WARN: Code duplicated, block: B:35:0x0140  */
                    /* JADX WARN: Type inference failed for: r6v7, types: [T, java.util.Map] */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:23:0x011b -> B:24:0x0122). Please report as a decompilation issue!!! */
                    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                        */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 222 */           public final java.lang.Object invokeSuspend(java.lang.Object r34) {
                        /*
                            Method dump skipped, instruction units count: 634
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiImportService.kt */
                    @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "sourceCard", "Lcom/xunji/core/anki/AnkiSourceCard;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3", f = "AnkiImportService.kt", i = {0, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 8, 9, 9, 9, 9, 9, 9, 9, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11, 11, 11, 11, 11, 11, 12, 12, 12, 12, 12, 12, 12, 12, 12, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 13, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18, 18}, l = {242, 243, 244, ProgressIndicatorKt.FirstLineTailDelay, 251, 251, 256, InputDeviceCompat.SOURCE_KEYBOARD, 258, 264, 265, 272, 273, 279, 280, 287, 297, 298, 299}, m = "invokeSuspend", n = {"sourceCard", "sourceCard", "note", "sourceCard", "note", "current", "sourceCard", "note", "current", "sourceCard", "note", "current", "model", "sourceCard", "note", "current", "model", "sourceCard", "note", "current", "sourceCard", "note", "current", "model", "sourceCard", "note", "current", "model", "persistedModel", "sourceCard", "note", "current", "model", "savedNote", "persistedModel", "mappings", "sourceCard", "note", "current", "model", "savedNote", "persistedModel", "mappings", "existing", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "$this$invokeSuspend_u24lambda_u244\\9", "$i$a$-run-AnkiImportService$commitLocked$5$1$result$1$1$3$deckId$1\\9\\272\\0", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "$this$invokeSuspend_u24lambda_u244\\9", "base\\9", "name\\9", "id\\9", "existingNames\\9", "$i$a$-run-AnkiImportService$commitLocked$5$1$result$1$1$3$deckId$1\\9\\272\\0", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "$this$invokeSuspend_u24lambda_u244\\9", "base\\9", "name\\9", "id\\9", "existingNames\\9", "$i$a$-run-AnkiImportService$commitLocked$5$1$result$1$1$3$deckId$1\\9\\272\\0", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "deckId", "fields", "tags", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "deckId", "fields", "tags", "template", "context", "question", "answer", "id", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "deckId", "fields", "tags", "template", "context", "question", "answer", "id", "sourceCard", "note", "current", "model", "savedNote", "sourceDeck", "deckKey", "deckId", "fields", "tags", "template", "context", "question", "answer", "id"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$9", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$9", "L$10", "L$11", "L$12", "L$13", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "L$9", "L$10", "L$11", "L$12", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12", "L$13", "L$14", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12", "L$13", "L$14", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12", "L$13", "L$14"}, v = 1)
/* 237 */           static final class AnonymousClass3 extends SuspendLambda implements Function2<AnkiSourceCard, Continuation<? super Unit>, Object> {
                        final /* synthetic */ CoroutineScope $$this$withContext;
                        final /* synthetic */ Ref.IntRef $added;
                        final /* synthetic */ Ref.ObjectRef<Map<String, String>> $cachedMediaMimes;
                        final /* synthetic */ Ref.ObjectRef<String> $cachedMediaNamespace;
                        final /* synthetic */ Job $caller;
                        final /* synthetic */ Ref.IntRef $decks;
                        final /* synthetic */ Ref.IntRef $duplicates;
                        final /* synthetic */ Map<Pair<String, String>, String> $localDecks;
                        final /* synthetic */ Map<String, AnkiNoteEntity> $localNotes;
                        final /* synthetic */ Ref.BooleanRef $mediaStored;
                        final /* synthetic */ Ref.IntRef $notes;
                        final /* synthetic */ long $now;
                        final /* synthetic */ PreparedAnkiImport $prepared;
                        final /* synthetic */ Map<Long, ImportPreviewCard> $sourceById;
                        final /* synthetic */ StagedMedia $staged;
                        int I$0;
                        long J$0;
                        /* synthetic */ Object L$0;
                        Object L$1;
                        Object L$10;
                        Object L$11;
                        Object L$12;
                        Object L$13;
                        Object L$14;
                        Object L$2;
                        Object L$3;
                        Object L$4;
                        Object L$5;
                        Object L$6;
                        Object L$7;
                        Object L$8;
                        Object L$9;
                        int label;
                        final /* synthetic */ AnkiImportService this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass3(Map<Long, ImportPreviewCard> map, Job job, PreparedAnkiImport preparedAnkiImport, Map<String, AnkiNoteEntity> map2, AnkiImportService ankiImportService, Ref.IntRef intRef, Ref.IntRef intRef2, Ref.BooleanRef booleanRef, StagedMedia stagedMedia, Map<Pair<String, String>, String> map3, CoroutineScope coroutineScope, Ref.ObjectRef<String> objectRef, Ref.ObjectRef<Map<String, String>> objectRef2, long j, Ref.IntRef intRef3, Ref.IntRef intRef4, Continuation<? super AnonymousClass3> continuation) {
                            super(2, continuation);
                            this.$sourceById = map;
                            this.$caller = job;
                            this.$prepared = preparedAnkiImport;
                            this.$localNotes = map2;
                            this.this$0 = ankiImportService;
                            this.$duplicates = intRef;
                            this.$notes = intRef2;
                            this.$mediaStored = booleanRef;
                            this.$staged = stagedMedia;
                            this.$localDecks = map3;
                            this.$$this$withContext = coroutineScope;
                            this.$cachedMediaNamespace = objectRef;
                            this.$cachedMediaMimes = objectRef2;
                            this.$now = j;
                            this.$added = intRef3;
                            this.$decks = intRef4;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            AnonymousClass3 anonymousClass3 = new AnonymousClass3(this.$sourceById, this.$caller, this.$prepared, this.$localNotes, this.this$0, this.$duplicates, this.$notes, this.$mediaStored, this.$staged, this.$localDecks, this.$$this$withContext, this.$cachedMediaNamespace, this.$cachedMediaMimes, this.$now, this.$added, this.$decks, continuation);
                            anonymousClass3.L$0 = obj;
                            return anonymousClass3;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(AnkiSourceCard ankiSourceCard, Continuation<? super Unit> continuation) {
                            return ((AnonymousClass3) create(ankiSourceCard, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:102:0x054b A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:103:0x054c  */
                        /* JADX WARN: Code duplicated, block: B:106:0x056d  */
                        /* JADX WARN: Code duplicated, block: B:108:0x0571  */
                        /* JADX WARN: Code duplicated, block: B:109:0x0576  */
                        /* JADX WARN: Code duplicated, block: B:111:0x0579  */
                        /* JADX WARN: Code duplicated, block: B:114:0x058f  */
                        /* JADX WARN: Code duplicated, block: B:116:0x05c2 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:117:0x05c3  */
                        /* JADX WARN: Code duplicated, block: B:120:0x05d7  */
                        /* JADX WARN: Code duplicated, block: B:129:0x063a  */
                        /* JADX WARN: Code duplicated, block: B:133:0x0643  */
                        /* JADX WARN: Code duplicated, block: B:135:0x0646  */
                        /* JADX WARN: Code duplicated, block: B:137:0x0653  */
                        /* JADX WARN: Code duplicated, block: B:139:0x0661  */
                        /* JADX WARN: Code duplicated, block: B:141:0x066f  */
                        /* JADX WARN: Code duplicated, block: B:144:0x068b  */
                        /* JADX WARN: Code duplicated, block: B:146:0x06a7  */
                        /* JADX WARN: Code duplicated, block: B:148:0x06df A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:149:0x06e0  */
                        /* JADX WARN: Code duplicated, block: B:152:0x06ea  */
                        /* JADX WARN: Code duplicated, block: B:153:0x06ef  */
                        /* JADX WARN: Code duplicated, block: B:155:0x06f2  */
                        /* JADX WARN: Code duplicated, block: B:157:0x0735 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:158:0x0736  */
                        /* JADX WARN: Code duplicated, block: B:162:0x0764 A[LOOP:2: B:160:0x075e->B:162:0x0764, LOOP_END] */
                        /* JADX WARN: Code duplicated, block: B:165:0x078f  */
                        /* JADX WARN: Code duplicated, block: B:166:0x0793  */
                        /* JADX WARN: Code duplicated, block: B:169:0x07b7  */
                        /* JADX WARN: Code duplicated, block: B:174:0x083f A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:175:0x0840  */
                        /* JADX WARN: Code duplicated, block: B:178:0x08ab A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:179:0x08ac  */
                        /* JADX WARN: Code duplicated, block: B:181:0x08cd A[LOOP:3: B:167:0x07b1->B:181:0x08cd, LOOP_END] */
                        /* JADX WARN: Code duplicated, block: B:184:0x08f8  */
                        /* JADX WARN: Code duplicated, block: B:185:0x0906  */
                        /* JADX WARN: Code duplicated, block: B:188:0x0930  */
                        /* JADX WARN: Code duplicated, block: B:190:0x0972 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:191:0x0973  */
                        /* JADX WARN: Code duplicated, block: B:195:0x099f A[LOOP:0: B:193:0x0999->B:195:0x099f, LOOP_END] */
                        /* JADX WARN: Code duplicated, block: B:197:0x09e5  */
                        /* JADX WARN: Code duplicated, block: B:201:0x0a04  */
                        /* JADX WARN: Code duplicated, block: B:203:0x0a1d  */
                        /* JADX WARN: Code duplicated, block: B:204:0x0a1f  */
                        /* JADX WARN: Code duplicated, block: B:206:0x0a25  */
                        /* JADX WARN: Code duplicated, block: B:207:0x0a27  */
                        /* JADX WARN: Code duplicated, block: B:210:0x0a2b A[LOOP:1: B:199:0x09fe->B:210:0x0a2b, LOOP_END] */
                        /* JADX WARN: Code duplicated, block: B:214:0x0a44  */
                        /* JADX WARN: Code duplicated, block: B:215:0x0a4b  */
                        /* JADX WARN: Code duplicated, block: B:217:0x0a4f  */
                        /* JADX WARN: Code duplicated, block: B:220:0x0a94  */
                        /* JADX WARN: Code duplicated, block: B:223:0x0aa0  */
                        /* JADX WARN: Code duplicated, block: B:225:0x0aa3  */
                        /* JADX WARN: Code duplicated, block: B:227:0x0aba  */
                        /* JADX WARN: Code duplicated, block: B:230:0x0ad4  */
                        /* JADX WARN: Code duplicated, block: B:232:0x0ad8  */
                        /* JADX WARN: Code duplicated, block: B:234:0x0b6f A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:235:0x0b70  */
                        /* JADX WARN: Code duplicated, block: B:238:0x0c0e A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:239:0x0c0f  */
                        /* JADX WARN: Code duplicated, block: B:242:0x0c9a A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:243:0x0c9b  */
                        /* JADX WARN: Code duplicated, block: B:246:0x0cb5  */
                        /* JADX WARN: Code duplicated, block: B:248:0x0cc5  */
                        /* JADX WARN: Code duplicated, block: B:250:0x0cd5  */
                        /* JADX WARN: Code duplicated, block: B:253:0x0a39 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:254:0x0a32 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:256:0x08ea A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:257:0x07c9 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:258:0x03cb A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:259:0x03c9 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:262:? A[LOOP:4: B:53:0x03ac->B:262:?, LOOP_END, SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:37:0x0355  */
                        /* JADX WARN: Code duplicated, block: B:39:0x036e A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:42:0x0372 A[DONT_INVERT, PHI: r3 r5
                          0x0372: PHI (r3v11 'note' com.xunji.core.anki.AnkiSourceNote) = (r3v9 'note' com.xunji.core.anki.AnkiSourceNote), (r3v13 'note' com.xunji.core.anki.AnkiSourceNote) binds: [B:36:0x0353, B:40:0x036f] A[DONT_GENERATE, DONT_INLINE]
                          0x0372: PHI (r5v9 'current' com.xunji.flashcards.data.AnkiNoteEntity) = (r5v5 'current' com.xunji.flashcards.data.AnkiNoteEntity), (r5v12 'current' com.xunji.flashcards.data.AnkiNoteEntity) binds: [B:36:0x0353, B:40:0x036f] A[DONT_GENERATE, DONT_INLINE]] */
                        /* JADX WARN: Code duplicated, block: B:43:0x0374  */
                        /* JADX WARN: Code duplicated, block: B:45:0x0390 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:46:0x0391  */
                        /* JADX WARN: Code duplicated, block: B:49:0x039d  */
                        /* JADX WARN: Code duplicated, block: B:52:0x03a8  */
                        /* JADX WARN: Code duplicated, block: B:55:0x03b2  */
                        /* JADX WARN: Code duplicated, block: B:57:0x03c4  */
                        /* JADX WARN: Code duplicated, block: B:58:0x03c6  */
                        /* JADX WARN: Code duplicated, block: B:63:0x03ce  */
                        /* JADX WARN: Code duplicated, block: B:65:0x03dd  */
                        /* JADX WARN: Code duplicated, block: B:66:0x03e0  */
                        /* JADX WARN: Code duplicated, block: B:69:0x03e6  */
                        /* JADX WARN: Code duplicated, block: B:71:0x040a A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:72:0x040b  */
                        /* JADX WARN: Code duplicated, block: B:74:0x0413  */
                        /* JADX WARN: Code duplicated, block: B:76:0x043f A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:77:0x0440  */
                        /* JADX WARN: Code duplicated, block: B:79:0x044d  */
                        /* JADX WARN: Code duplicated, block: B:81:0x0475 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:82:0x0476  */
                        /* JADX WARN: Code duplicated, block: B:85:0x0483  */
                        /* JADX WARN: Code duplicated, block: B:86:0x0486  */
                        /* JADX WARN: Code duplicated, block: B:88:0x0494  */
                        /* JADX WARN: Code duplicated, block: B:90:0x049e  */
                        /* JADX WARN: Code duplicated, block: B:92:0x04a8  */
                        /* JADX WARN: Code duplicated, block: B:94:0x04c8 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:95:0x04c9  */
                        /* JADX WARN: Code duplicated, block: B:98:0x04fc A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:99:0x04fd  */
                        /* JADX WARN: Type inference failed for: r10v92, types: [T, java.util.Map] */
                        /* JADX WARN: Type inference failed for: r4v39, types: [T, java.lang.String] */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 238 */               public final Object invokeSuspend(Object $result) throws Throwable {
                            Object note;
                            AnkiSourceNote note2;
                            AnkiNoteEntity current;
                            Object objNoteByGuid;
                            AnkiSourceNote note3;
                            AnkiNoteEntity current2;
                            Object objLinks;
                            AnkiSourceNote note4;
                            AnkiNoteEntity current3;
                            AnkiNoteEntity savedNote;
                            Object model;
                            AnkiNoteEntity current4;
                            AnkiSourceNote note5;
                            AnkiImportService ankiImportService;
                            Object objModel;
                            AnkiModel model2;
                            AnkiImportService ankiImportService2;
                            Iterable iterable;
                            Iterator it;
                            boolean z;
                            boolean z2;
                            AnkiModel model3;
                            AnkiImportService ankiImportService3;
                            Object objModel2;
                            AnkiModel model4;
                            AnkiSourceNote note6;
                            AnkiNoteEntity current5;
                            AnkiImportService ankiImportService4;
                            AnkiModelEntity ankiModelEntity;
                            Object model5;
                            AnkiSourceNote note7;
                            AnkiModelEntity ankiModelEntity2;
                            AnkiNoteEntity savedNote2;
                            AnkiModel model6;
                            Object objInsertModel;
                            AnkiNoteEntity savedNote3;
                            AnkiModel model7;
                            AnkiNoteEntity current6;
                            AnkiSourceNote note8;
                            AnkiModelEntity persistedModel;
                            Object objInsertNote;
                            AnkiModel model8;
                            AnkiModelEntity persistedModel2;
                            AnkiNoteEntity current7;
                            AnkiNoteEntity savedNote4;
                            StagedMedia stagedMedia;
                            List<AnkiMediaEntity> listEmptyList;
                            Object objMedia;
                            AnkiModelEntity persistedModel3;
                            AnkiSourceNote note9;
                            AnkiModel model9;
                            AnkiNoteEntity savedNote5;
                            List<AnkiMediaEntity> list;
                            AnkiNoteEntity current8;
                            List existing;
                            boolean z3;
                            AnkiSourceNote note10;
                            List existing2;
                            AnkiSourceDeck ankiSourceDeck;
                            AnkiSourceDeck sourceDeck;
                            Pair<String, String> pair;
                            String str;
                            String str2;
                            AnkiNoteEntity savedNote6;
                            AnkiSourceDeck sourceDeck2;
                            Pair<String, String> pair2;
                            AnkiModel model10;
                            AnkiSourceNote note11;
                            Object objDeckSource;
                            AnkiNoteEntity savedNote7;
                            AnkiModel model11;
                            AnkiNoteEntity current9;
                            AnkiSourceNote note12;
                            Pair<String, String> pair3;
                            AnkiSourceDeck sourceDeck3;
                            AnkiDeckSourceEntity ankiDeckSourceEntity;
                            String localDeckId;
                            AnkiImportService ankiImportService5;
                            long j;
                            Ref.IntRef intRef;
                            CoroutineScope coroutineScope;
                            AnkiNoteEntity current10;
                            Object objDecks;
                            AnkiSourceNote note13;
                            AnkiImportService ankiImportService6;
                            int i;
                            AnkiSourceDeck sourceDeck4;
                            Ref.IntRef intRef2;
                            long j2;
                            AnkiNoteEntity savedNote8;
                            AnkiModel model12;
                            Pair<String, String> pair4;
                            AnkiNoteEntity savedNote9;
                            AnkiModel model13;
                            Collection arrayList;
                            Iterable iterable2;
                            Iterator it2;
                            Set set;
                            final String fullName;
                            Iterator it3;
                            Object next;
                            String str3;
                            String str4;
                            String string;
                            XunjiDao xunjiDaoDao;
                            Set set2;
                            DeckEntity deckEntity;
                            AnkiModel model14;
                            AnkiNoteEntity savedNote10;
                            Object obj;
                            AnkiImportService ankiImportService7;
                            AnkiNoteEntity current11;
                            Set set3;
                            String str5;
                            int i2;
                            AnkiSourceNote note14;
                            AnkiDao ankiDao;
                            AnkiSourceNote note15;
                            AnkiDeckSourceEntity ankiDeckSourceEntity2;
                            String deckId;
                            List<String> listStrings;
                            List<String> listStrings2;
                            AnkiSourceNote note16;
                            List<String> list2;
                            AnkiNoteEntity current12;
                            String deckId2;
                            AnkiModel model15;
                            List<String> list3;
                            AnkiSourceDeck sourceDeck5;
                            AnkiNoteEntity savedNote11;
                            Pair<String, String> pair5;
                            Ref.ObjectRef<Map<String, String>> objectRef;
                            AnkiSourceNote note17;
                            Object objMedia2;
                            AnkiSourceNote note18;
                            Iterable templates;
                            int i3;
                            Iterator it4;
                            AnkiSourceNote note19;
                            Object next2;
                            AnkiTemplate template;
                            TemplateContext context;
                            String name;
                            AnkiModel model16;
                            AnkiNoteEntity savedNote12;
                            RenderedSide question;
                            RenderedSide answer;
                            boolean z4;
                            boolean z5;
                            String id;
                            String id2;
                            List<String> list4;
                            TemplateContext context2;
                            Pair<String, String> pair6;
                            AnkiSourceDeck sourceDeck6;
                            RenderedSide question2;
                            AnkiNoteEntity current13;
                            AnkiTemplate template2;
                            AnkiNoteEntity savedNote13;
                            AnkiModel model17;
                            List<String> list5;
                            AnkiSourceNote note20;
                            RenderedSide answer2;
                            String deckId3;
                            int ordinal;
                            Iterable iterable3;
                            int i4;
                            int ordinal2;
                            boolean z6;
                            int iCoerceAtLeast;
                            LinkedHashMap linkedHashMap;
                            AnkiSourceNote note21;
                            RenderedSide answer3;
                            RenderedSide question3;
                            TemplateContext context3;
                            String id3;
                            AnkiTemplate template3;
                            List<String> list6;
                            List<String> list7;
                            String deckId4;
                            Pair<String, String> pair7;
                            AnkiSourceNote note22;
                            RenderedSide answer4;
                            RenderedSide answer5;
                            AnkiSourceCard sourceCard = (AnkiSourceCard) this.L$0;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            String str6 = "toString(...)";
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 240 */                           if (!this.$sourceById.containsKey(Boxing.boxLong(sourceCard.getSourceId()))) {
                                        return Unit.INSTANCE;
                                    }
/* 241 */                           Job job = this.$caller;
                                    if (job != null) {
                                        JobKt.ensureActive(job);
                                        Unit unit = Unit.INSTANCE;
                                    }
                                    this.L$0 = sourceCard;
                                    this.label = 1;
/* 242 */                           note = this.$prepared.getSource().readNote(sourceCard.getSourceId(), this);
                                    if (note == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    note2 = (AnkiSourceNote) note;
/* 243 */                           current = this.$localNotes.get(note2.getGuid());
                                    if (current == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = note2;
                                        this.label = 2;
/* 70 */                                objNoteByGuid = this.this$0.dao.noteByGuid(note2.getGuid(), this);
                                        if (objNoteByGuid == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        current = (AnkiNoteEntity) objNoteByGuid;
/* 244 */                               if (current != null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = note2;
                                            this.L$2 = current;
                                            this.label = 3;
/* 70 */                                    objLinks = this.this$0.dao.links(current.getId(), this);
                                            if (objLinks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 244 */                                   AnkiNoteEntity ankiNoteEntity = current;
                                            note4 = note2;
                                            current3 = ankiNoteEntity;
/* 239 */                                   iterable = (Iterable) objLinks;
/* 347 */                                   if ((iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
/* 348 */                                       it = iterable.iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
/* 244 */                                               if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                            z2 = true;
                                                        } else {
                                                            z2 = false;
                                                        }
/* 348 */                                               if (z2) {
                                                            z = true;
                                                        }
                                                    } else {
/* 349 */                                               z = false;
                                                    }
                                                }
                                            } else {
                                                z = false;
                                            }
/* 244 */                                   if (z) {
/* 245 */                                       this.$duplicates.element++;
                                                return Unit.INSTANCE;
                                            }
/* 244 */                                   current2 = current3;
                                            note3 = note4;
                                        } else {
                                            note3 = note2;
                                            current2 = current;
                                        }
                                    } else if (current != null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = note2;
                                        this.L$2 = current;
                                        this.label = 3;
/* 70 */                                objLinks = this.this$0.dao.links(current.getId(), this);
                                        if (objLinks == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 244 */                               AnkiNoteEntity ankiNoteEntity2 = current;
                                        note4 = note2;
                                        current3 = ankiNoteEntity2;
/* 239 */                               iterable = (Iterable) objLinks;
/* 347 */                               if (iterable instanceof Collection) {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        } else {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        }
/* 244 */                               if (z) {
/* 245 */                                   this.$duplicates.element++;
                                            return Unit.INSTANCE;
                                        }
/* 244 */                               current2 = current3;
                                        note3 = note4;
                                    } else {
                                        note3 = note2;
                                        current2 = current;
                                    }
/* 248 */                           savedNote = null;
/* 249 */                           if (current2 != null) {
/* 250 */                               ankiImportService = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = ankiImportService;
                                        this.label = 4;
/* 70 */                                objModel = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 248 */                               model2 = null;
                                        ankiImportService2 = ankiImportService;
                                        if (objModel == null) {
/* 250 */                                   throw new IllegalArgumentException("Required value was null.".toString());
                                        }
/* 70 */                                model3 = ankiImportService2.asModel((AnkiModelEntity) objModel);
/* 251 */                               ankiImportService3 = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = model3;
                                        this.L$4 = ankiImportService3;
                                        this.label = 5;
/* 70 */                                objModel2 = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 251 */                               AnkiNoteEntity ankiNoteEntity3 = current2;
                                        model4 = model3;
                                        note6 = note3;
                                        current5 = ankiNoteEntity3;
                                        ankiImportService4 = ankiImportService3;
                                        if (objModel2 != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        ankiModelEntity = (AnkiModelEntity) objModel2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                        this.L$2 = current5;
                                        this.L$3 = model4;
                                        this.L$4 = ankiImportService4;
                                        this.L$5 = ankiModelEntity;
                                        this.label = 6;
                                        model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                        if (model5 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        note7 = note6;
/* 251 */                               ankiModelEntity2 = ankiModelEntity;
/* 70 */                                if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                                   throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                        }
/* 254 */                               savedNote2 = current5;
/* 270 */                               ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                        if (ankiSourceDeck != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        sourceDeck = ankiSourceDeck;
/* 271 */                               pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                               str = this.$localDecks.get(pair);
                                        if (str == null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model4;
                                            this.L$4 = savedNote2;
                                            this.L$5 = sourceDeck;
                                            this.L$6 = pair;
                                            this.L$7 = null;
                                            this.label = 12;
/* 70 */                                    objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                            if (objDeckSource == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 272 */                                   savedNote7 = savedNote2;
                                            model11 = model4;
                                            current9 = current5;
                                            note12 = note7;
                                            pair3 = pair;
                                            sourceDeck3 = sourceDeck;
                                            ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                            if (ankiDeckSourceEntity != null) {
                                                localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                            } else {
                                                localDeckId = null;
                                            }
                                            if (localDeckId == null) {
                                                CoroutineScope coroutineScope2 = this.$$this$withContext;
                                                ankiImportService5 = this.this$0;
                                                j = this.$now;
                                                intRef = this.$decks;
                                                coroutineScope = coroutineScope2;
/* 70 */                                        XunjiDao xunjiDaoDao2 = ankiImportService5.db.dao();
                                                this.L$0 = sourceCard;
                                                current10 = current9;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model11;
                                                this.L$4 = savedNote7;
                                                this.L$5 = sourceDeck3;
                                                this.L$6 = pair3;
                                                this.L$7 = ankiImportService5;
                                                this.L$8 = intRef;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.J$0 = j;
                                                this.I$0 = 0;
                                                this.label = 13;
                                                objDecks = xunjiDaoDao2.decks(this);
                                                if (objDecks == coroutine_suspended) {
/* 239 */                                           return coroutine_suspended;
                                                }
/* 273 */                                       note13 = note12;
                                                ankiImportService6 = ankiImportService5;
                                                i = 0;
                                                sourceDeck4 = sourceDeck3;
                                                AnkiNoteEntity ankiNoteEntity4 = savedNote7;
                                                intRef2 = intRef;
                                                j2 = j;
                                                savedNote8 = ankiNoteEntity4;
                                                model12 = model11;
                                                pair4 = pair3;
/* 239 */                                       Iterable iterable4 = (Iterable) objDecks;
                                                savedNote9 = savedNote8;
                                                model13 = model12;
/* 351 */                                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable4, 10));
                                                iterable2 = iterable4;
/* 352 */                                       it2 = iterable2.iterator();
                                                while (it2.hasNext()) {
/* 353 */                                           arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                           iterable2 = iterable2;
                                                }
/* 273 */                                       set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                       fullName = sourceDeck4.getFullName();
/* 275 */                                       if (set.contains(fullName)) {
/* 355 */                                           it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj2) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj2).intValue());
                                                        }
                                                    }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj2) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj2).intValue());
                                                        }
                                                    }).iterator();
                                                    while (true) {
                                                        if (it3.hasNext()) {
                                                            throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                        }
                                                        next = it3.next();
                                                        str3 = fullName;
/* 355 */                                               if (set.contains((String) next)) {
/* 355 */                                                   long j3 = j2;
                                                            Object obj2 = coroutine_suspended;
                                                            AnkiModel model18 = model13;
                                                            model13 = model18;
                                                            coroutine_suspended = obj2;
                                                            j2 = j3;
                                                            set = set;
                                                            savedNote9 = savedNote9;
                                                            str6 = str6;
                                                            fullName = str3;
                                                        } else {
/* 356 */                                                   str4 = (String) next;
                                                        }
                                                    }
                                                } else {
                                                    str4 = fullName;
                                                    str3 = str4;
                                                }
/* 278 */                                       string = UUID.randomUUID().toString();
                                                Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                        xunjiDaoDao = ankiImportService6.db.dao();
                                                set2 = set;
                                                Object obj3 = coroutine_suspended;
                                                model14 = model13;
                                                str2 = str6;
                                                savedNote10 = savedNote9;
                                                deckEntity = new DeckEntity(string, str4, j2, j2);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model14;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = ankiImportService6;
                                                this.L$8 = intRef2;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                                this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$12 = string;
                                                this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                                this.I$0 = i;
                                                this.label = 14;
                                                obj = obj3;
                                                if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 279 */                                       ankiImportService7 = ankiImportService6;
                                                current11 = current10;
                                                set3 = set2;
                                                str5 = str3;
                                                model10 = model14;
                                                i2 = i;
                                                note14 = note13;
/* 70 */                                        ankiDao = ankiImportService7.dao;
                                                note15 = note14;
                                                ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                                this.L$3 = model10;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = intRef2;
                                                this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$11 = string;
                                                this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                                this.L$13 = null;
                                                this.I$0 = i2;
                                                this.label = 15;
                                                if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 281 */                                       intRef2.element++;
/* 283 */                                       this.$localDecks.put(pair4, string);
                                                str = string;
                                                coroutine_suspended = obj;
                                                current5 = current11;
                                                pair2 = pair4;
                                                sourceDeck2 = sourceDeck4;
                                                note11 = note15;
                                                savedNote6 = savedNote10;
                                            } else {
                                                str2 = "toString(...)";
                                                AnkiNoteEntity current14 = current9;
                                                str = localDeckId;
                                                savedNote6 = savedNote7;
                                                note11 = note12;
                                                current5 = current14;
                                                pair2 = pair3;
                                                model10 = model11;
                                                sourceDeck2 = sourceDeck3;
                                            }
                                        } else {
                                            str2 = "toString(...)";
                                            savedNote6 = savedNote2;
                                            sourceDeck2 = sourceDeck;
                                            pair2 = pair;
                                            model10 = model4;
                                            note11 = note7;
                                        }
                                        deckId = str;
/* 284 */                               listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                               listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                               if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 286 */                                   note16 = note11;
                                            list2 = listStrings;
                                            current12 = current5;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            list3 = listStrings2;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        } else {
/* 287 */                                   objectRef = this.$cachedMediaMimes;
                                            this.L$0 = sourceCard;
                                            note17 = note11;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote6;
                                            this.L$5 = sourceDeck2;
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                            this.L$7 = deckId;
                                            this.L$8 = listStrings;
                                            this.L$9 = listStrings2;
                                            this.L$10 = objectRef;
                                            this.L$11 = null;
                                            this.L$12 = null;
                                            this.label = 16;
/* 70 */                                    objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                            if (objMedia2 == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 287 */                                   note18 = note17;
/* 239 */                                   Iterable<AnkiMediaEntity> iterable5 = (Iterable) objMedia2;
/* 357 */                                   iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable5, 10)), 16);
/* 358 */                                   linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                            for (AnkiMediaEntity ankiMediaEntity : iterable5) {
/* 287 */                                       int i5 = iCoerceAtLeast;
                                                Pair pair8 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                       linkedHashMap.put(pair8.getFirst(), pair8.getSecond());
                                                iCoerceAtLeast = i5;
                                                note18 = note18;
                                            }
/* 287 */                                   objectRef.element = linkedHashMap;
/* 288 */                                   this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                            note16 = note18;
                                            list2 = listStrings;
                                            current12 = current5;
                                            list3 = listStrings2;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        }
/* 290 */                               templates = model15.getTemplates();
                                        i3 = 0;
/* 363 */                               it4 = templates.iterator();
                                        while (true) {
                                            if (it4.hasNext()) {
                                                next2 = it4.next();
/* 290 */                                       note19 = note16;
                                                ordinal = ((AnkiTemplate) next2).getOrdinal();
                                                iterable3 = templates;
                                                i4 = i3;
                                                if (model15.getKind() == 1) {
                                                    ordinal2 = 0;
                                                } else {
                                                    ordinal2 = sourceCard.getOrdinal();
                                                }
                                                if (ordinal == ordinal2) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
/* 363 */                                       if (!z6) {
                                                    note16 = note19;
                                                    templates = iterable3;
                                                    i3 = i4;
                                                }
                                            } else {
/* 364 */                                       note19 = note16;
                                                next2 = null;
                                            }
                                        }
/* 290 */                               template = (AnkiTemplate) next2;
                                        String fullName2 = sourceDeck5.getFullName();
                                        if (template != null) {
                                            name = template.getName();
                                        } else {
                                            name = null;
                                        }
                                        if (name == null) {
                                            name = "";
                                        }
/* 291 */                               context = new TemplateContext(fullName2, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                        model16 = model15;
                                        savedNote12 = savedNote11;
/* 70 */                                question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                                answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                               if (question.getIssues().isEmpty() || !answer.getIssues().isEmpty()) {
                                            z4 = false;
                                        } else {
                                            z4 = true;
                                        }
                                        if (!z4) {
                                            throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                        }
/* 295 */                               if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty() || !AnkiMediaValidator.INSTANCE.issues(answer, new AnonymousClass8(this.$cachedMediaMimes.element)).isEmpty()) {
                                            z5 = false;
                                        } else {
                                            z5 = true;
                                        }
                                        if (!z5) {
                                            throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                        }
/* 296 */                               id = UUID.randomUUID().toString();
                                        Intrinsics.checkNotNullExpressionValue(id, str2);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                        this.L$4 = savedNote12;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                        this.L$14 = id;
                                        this.label = 17;
/* 70 */                                if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 297 */                               id2 = id;
                                        list4 = list3;
                                        context2 = context;
                                        pair6 = pair5;
                                        sourceDeck6 = sourceDeck5;
                                        question2 = question;
                                        current13 = current12;
                                        template2 = template;
                                        savedNote13 = savedNote12;
                                        model17 = model16;
                                        list5 = list2;
                                        note20 = note19;
                                        answer2 = answer;
                                        deckId3 = deckId2;
/* 298 */                               note21 = note20;
                                        answer3 = answer2;
                                        question3 = question2;
                                        context3 = context2;
                                        id3 = id2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = savedNote13;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                        this.L$14 = id3;
                                        this.label = 18;
/* 70 */                                if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 298 */                               template3 = template2;
                                        list6 = list4;
                                        list7 = list5;
                                        deckId4 = deckId3;
                                        pair7 = pair6;
                                        note22 = note21;
                                        answer4 = answer3;
                                        answer5 = question3;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                        this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                        this.label = 19;
/* 70 */                                if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 300 */                               this.$added.element++;
/* 301 */                               return Unit.INSTANCE;
                                    }
                                    this.L$0 = sourceCard;
                                    this.L$1 = note3;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                    this.label = 7;
/* 256 */                           model = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 256 */                           AnkiSourceNote ankiSourceNote = note3;
                                    current4 = current2;
                                    note5 = ankiSourceNote;
/* 239 */                           model6 = (AnkiModel) model;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note5;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current4);
                                    this.L$3 = model6;
                                    this.label = 8;
/* 257 */                           objInsertModel = new AnkiRepository(this.this$0.db).insertModel(AnkiRepository.Companion.modelSnapshot$default(AnkiRepository.INSTANCE, model6, null, 2, null), this);
                                    if (objInsertModel == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    savedNote3 = savedNote;
/* 257 */                           model7 = model6;
                                    current6 = current4;
                                    note8 = note5;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    } else {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel;
                                        AnkiNoteEntity ankiNoteEntity5 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity5;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty() || list.isEmpty()) {
/* 266 */                                   if (!Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list)) || list.isEmpty()) {
                                                z3 = true;
                                            } else {
                                                z3 = false;
                                            }
                                            if (z3) {
                                                throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                            }
                                            AnkiNoteEntity ankiNoteEntity6 = current8;
                                            note7 = note9;
                                            savedNote2 = savedNote5;
                                            model4 = model9;
                                            current5 = ankiNoteEntity6;
                                        } else {
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note9);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current8);
                                            this.L$3 = model9;
                                            this.L$4 = savedNote5;
                                            this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel3);
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(list);
                                            this.L$7 = SpillingKt.nullOutSpilledVariable(existing);
                                            this.label = 11;
/* 70 */                                    if (this.this$0.dao.insertMedia(list, this) == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
                                            note10 = note9;
/* 265 */                                   existing2 = existing;
                                            savedNote2 = savedNote5;
                                            model4 = model9;
                                            current5 = current8;
                                            note7 = note10;
                                        }
/* 267 */                               this.$mediaStored.element = true;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope3 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope3;
/* 70 */                                    XunjiDao xunjiDaoDao3 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao3.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity7 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity7;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable6 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable6, 10));
                                            iterable2 = iterable6;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj4) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj4).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj4) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj4).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j4 = j2;
                                                        Object obj4 = coroutine_suspended;
                                                        AnkiModel model19 = model13;
                                                        model13 = model19;
                                                        coroutine_suspended = obj4;
                                                        j2 = j4;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj5 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj5;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current15 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current15;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable7 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable7, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i6 = iCoerceAtLeast;
                                            Pair pair9 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair9.getFirst(), pair9.getSecond());
                                            iCoerceAtLeast = i6;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName3 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName3, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    note = $result;
                                    note2 = (AnkiSourceNote) note;
/* 243 */                           current = this.$localNotes.get(note2.getGuid());
                                    if (current == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = note2;
                                        this.label = 2;
/* 70 */                                objNoteByGuid = this.this$0.dao.noteByGuid(note2.getGuid(), this);
                                        if (objNoteByGuid == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        current = (AnkiNoteEntity) objNoteByGuid;
/* 244 */                               if (current != null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = note2;
                                            this.L$2 = current;
                                            this.label = 3;
/* 70 */                                    objLinks = this.this$0.dao.links(current.getId(), this);
                                            if (objLinks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 244 */                                   AnkiNoteEntity ankiNoteEntity8 = current;
                                            note4 = note2;
                                            current3 = ankiNoteEntity8;
/* 239 */                                   iterable = (Iterable) objLinks;
/* 347 */                                   if (iterable instanceof Collection) {
/* 348 */                                       it = iterable.iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
/* 244 */                                               if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                            z2 = true;
                                                        } else {
                                                            z2 = false;
                                                        }
/* 348 */                                               if (z2) {
                                                            z = true;
                                                        }
                                                    } else {
/* 349 */                                               z = false;
                                                    }
                                                }
                                            } else {
/* 348 */                                       it = iterable.iterator();
                                                while (true) {
                                                    if (it.hasNext()) {
/* 244 */                                               if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                            z2 = true;
                                                        } else {
                                                            z2 = false;
                                                        }
/* 348 */                                               if (z2) {
                                                            z = true;
                                                        }
                                                    } else {
/* 349 */                                               z = false;
                                                    }
                                                }
                                            }
/* 244 */                                   if (z) {
/* 245 */                                       this.$duplicates.element++;
                                                return Unit.INSTANCE;
                                            }
/* 244 */                                   current2 = current3;
                                            note3 = note4;
                                        } else {
                                            note3 = note2;
                                            current2 = current;
                                        }
                                    } else if (current != null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = note2;
                                        this.L$2 = current;
                                        this.label = 3;
/* 70 */                                objLinks = this.this$0.dao.links(current.getId(), this);
                                        if (objLinks == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 244 */                               AnkiNoteEntity ankiNoteEntity9 = current;
                                        note4 = note2;
                                        current3 = ankiNoteEntity9;
/* 239 */                               iterable = (Iterable) objLinks;
/* 347 */                               if (iterable instanceof Collection) {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        } else {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        }
/* 244 */                               if (z) {
/* 245 */                                   this.$duplicates.element++;
                                            return Unit.INSTANCE;
                                        }
/* 244 */                               current2 = current3;
                                        note3 = note4;
                                    } else {
                                        note3 = note2;
                                        current2 = current;
                                    }
/* 248 */                           savedNote = null;
/* 249 */                           if (current2 != null) {
/* 250 */                               ankiImportService = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = ankiImportService;
                                        this.label = 4;
/* 70 */                                objModel = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 248 */                               model2 = null;
                                        ankiImportService2 = ankiImportService;
                                        if (objModel == null) {
/* 250 */                                   throw new IllegalArgumentException("Required value was null.".toString());
                                        }
/* 70 */                                model3 = ankiImportService2.asModel((AnkiModelEntity) objModel);
/* 251 */                               ankiImportService3 = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = model3;
                                        this.L$4 = ankiImportService3;
                                        this.label = 5;
/* 70 */                                objModel2 = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 251 */                               AnkiNoteEntity ankiNoteEntity10 = current2;
                                        model4 = model3;
                                        note6 = note3;
                                        current5 = ankiNoteEntity10;
                                        ankiImportService4 = ankiImportService3;
                                        if (objModel2 != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        ankiModelEntity = (AnkiModelEntity) objModel2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                        this.L$2 = current5;
                                        this.L$3 = model4;
                                        this.L$4 = ankiImportService4;
                                        this.L$5 = ankiModelEntity;
                                        this.label = 6;
                                        model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                        if (model5 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        note7 = note6;
/* 251 */                               ankiModelEntity2 = ankiModelEntity;
/* 70 */                                if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                                   throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                        }
/* 254 */                               savedNote2 = current5;
/* 270 */                               ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                        if (ankiSourceDeck != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        sourceDeck = ankiSourceDeck;
/* 271 */                               pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                               str = this.$localDecks.get(pair);
                                        if (str == null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model4;
                                            this.L$4 = savedNote2;
                                            this.L$5 = sourceDeck;
                                            this.L$6 = pair;
                                            this.L$7 = null;
                                            this.label = 12;
/* 70 */                                    objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                            if (objDeckSource == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 272 */                                   savedNote7 = savedNote2;
                                            model11 = model4;
                                            current9 = current5;
                                            note12 = note7;
                                            pair3 = pair;
                                            sourceDeck3 = sourceDeck;
                                            ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                            if (ankiDeckSourceEntity != null) {
                                                localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                            } else {
                                                localDeckId = null;
                                            }
                                            if (localDeckId == null) {
                                                CoroutineScope coroutineScope4 = this.$$this$withContext;
                                                ankiImportService5 = this.this$0;
                                                j = this.$now;
                                                intRef = this.$decks;
                                                coroutineScope = coroutineScope4;
/* 70 */                                        XunjiDao xunjiDaoDao4 = ankiImportService5.db.dao();
                                                this.L$0 = sourceCard;
                                                current10 = current9;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model11;
                                                this.L$4 = savedNote7;
                                                this.L$5 = sourceDeck3;
                                                this.L$6 = pair3;
                                                this.L$7 = ankiImportService5;
                                                this.L$8 = intRef;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.J$0 = j;
                                                this.I$0 = 0;
                                                this.label = 13;
                                                objDecks = xunjiDaoDao4.decks(this);
                                                if (objDecks == coroutine_suspended) {
/* 239 */                                           return coroutine_suspended;
                                                }
/* 273 */                                       note13 = note12;
                                                ankiImportService6 = ankiImportService5;
                                                i = 0;
                                                sourceDeck4 = sourceDeck3;
                                                AnkiNoteEntity ankiNoteEntity11 = savedNote7;
                                                intRef2 = intRef;
                                                j2 = j;
                                                savedNote8 = ankiNoteEntity11;
                                                model12 = model11;
                                                pair4 = pair3;
/* 239 */                                       Iterable iterable8 = (Iterable) objDecks;
                                                savedNote9 = savedNote8;
                                                model13 = model12;
/* 351 */                                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable8, 10));
                                                iterable2 = iterable8;
/* 352 */                                       it2 = iterable2.iterator();
                                                while (it2.hasNext()) {
/* 353 */                                           arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                           iterable2 = iterable2;
                                                }
/* 273 */                                       set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                       fullName = sourceDeck4.getFullName();
/* 275 */                                       if (set.contains(fullName)) {
                                                    str4 = fullName;
                                                    str3 = str4;
                                                } else {
/* 355 */                                           it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj6) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj6).intValue());
                                                        }
                                                    }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj6) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj6).intValue());
                                                        }
                                                    }).iterator();
                                                    while (true) {
                                                        if (it3.hasNext()) {
                                                            throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                        }
                                                        next = it3.next();
                                                        str3 = fullName;
/* 355 */                                               if (set.contains((String) next)) {
/* 356 */                                                   str4 = (String) next;
                                                        } else {
/* 355 */                                                   long j5 = j2;
                                                            Object obj6 = coroutine_suspended;
                                                            AnkiModel model110 = model13;
                                                            model13 = model110;
                                                            coroutine_suspended = obj6;
                                                            j2 = j5;
                                                            set = set;
                                                            savedNote9 = savedNote9;
                                                            str6 = str6;
                                                            fullName = str3;
                                                        }
                                                    }
                                                }
/* 278 */                                       string = UUID.randomUUID().toString();
                                                Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                        xunjiDaoDao = ankiImportService6.db.dao();
                                                set2 = set;
                                                Object obj7 = coroutine_suspended;
                                                model14 = model13;
                                                str2 = str6;
                                                savedNote10 = savedNote9;
                                                deckEntity = new DeckEntity(string, str4, j2, j2);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model14;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = ankiImportService6;
                                                this.L$8 = intRef2;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                                this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$12 = string;
                                                this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                                this.I$0 = i;
                                                this.label = 14;
                                                obj = obj7;
                                                if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 279 */                                       ankiImportService7 = ankiImportService6;
                                                current11 = current10;
                                                set3 = set2;
                                                str5 = str3;
                                                model10 = model14;
                                                i2 = i;
                                                note14 = note13;
/* 70 */                                        ankiDao = ankiImportService7.dao;
                                                note15 = note14;
                                                ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                                this.L$3 = model10;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = intRef2;
                                                this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$11 = string;
                                                this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                                this.L$13 = null;
                                                this.I$0 = i2;
                                                this.label = 15;
                                                if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 281 */                                       intRef2.element++;
/* 283 */                                       this.$localDecks.put(pair4, string);
                                                str = string;
                                                coroutine_suspended = obj;
                                                current5 = current11;
                                                pair2 = pair4;
                                                sourceDeck2 = sourceDeck4;
                                                note11 = note15;
                                                savedNote6 = savedNote10;
                                            } else {
                                                str2 = "toString(...)";
                                                AnkiNoteEntity current16 = current9;
                                                str = localDeckId;
                                                savedNote6 = savedNote7;
                                                note11 = note12;
                                                current5 = current16;
                                                pair2 = pair3;
                                                model10 = model11;
                                                sourceDeck2 = sourceDeck3;
                                            }
                                        } else {
                                            str2 = "toString(...)";
                                            savedNote6 = savedNote2;
                                            sourceDeck2 = sourceDeck;
                                            pair2 = pair;
                                            model10 = model4;
                                            note11 = note7;
                                        }
                                        deckId = str;
/* 284 */                               listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                               listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                               if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                                   objectRef = this.$cachedMediaMimes;
                                            this.L$0 = sourceCard;
                                            note17 = note11;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote6;
                                            this.L$5 = sourceDeck2;
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                            this.L$7 = deckId;
                                            this.L$8 = listStrings;
                                            this.L$9 = listStrings2;
                                            this.L$10 = objectRef;
                                            this.L$11 = null;
                                            this.L$12 = null;
                                            this.label = 16;
/* 70 */                                    objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                            if (objMedia2 == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 287 */                                   note18 = note17;
/* 239 */                                   Iterable<AnkiMediaEntity> iterable9 = (Iterable) objMedia2;
/* 357 */                                   iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable9, 10)), 16);
/* 358 */                                   linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                            while (r22.hasNext()) {
/* 287 */                                       int i7 = iCoerceAtLeast;
                                                Pair pair10 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                       linkedHashMap.put(pair10.getFirst(), pair10.getSecond());
                                                iCoerceAtLeast = i7;
                                                note18 = note18;
                                            }
/* 287 */                                   objectRef.element = linkedHashMap;
/* 288 */                                   this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                            note16 = note18;
                                            list2 = listStrings;
                                            current12 = current5;
                                            list3 = listStrings2;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        } else {
/* 286 */                                   note16 = note11;
                                            list2 = listStrings;
                                            current12 = current5;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            list3 = listStrings2;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        }
/* 290 */                               templates = model15.getTemplates();
                                        i3 = 0;
/* 363 */                               it4 = templates.iterator();
                                        while (true) {
                                            if (it4.hasNext()) {
                                                next2 = it4.next();
/* 290 */                                       note19 = note16;
                                                ordinal = ((AnkiTemplate) next2).getOrdinal();
                                                iterable3 = templates;
                                                i4 = i3;
                                                if (model15.getKind() == 1) {
                                                    ordinal2 = 0;
                                                } else {
                                                    ordinal2 = sourceCard.getOrdinal();
                                                }
                                                if (ordinal == ordinal2) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
/* 363 */                                       if (!z6) {
                                                    note16 = note19;
                                                    templates = iterable3;
                                                    i3 = i4;
                                                }
                                            } else {
/* 364 */                                       note19 = note16;
                                                next2 = null;
                                            }
                                        }
/* 290 */                               template = (AnkiTemplate) next2;
                                        String fullName4 = sourceDeck5.getFullName();
                                        if (template != null) {
                                            name = template.getName();
                                        } else {
                                            name = null;
                                        }
                                        if (name == null) {
                                            name = "";
                                        }
/* 291 */                               context = new TemplateContext(fullName4, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                        model16 = model15;
                                        savedNote12 = savedNote11;
/* 70 */                                question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                                answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                               if (question.getIssues().isEmpty()) {
                                            z4 = false;
                                        } else {
                                            z4 = false;
                                        }
                                        if (!z4) {
                                            throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                        }
/* 295 */                               if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                            z5 = false;
                                        } else {
                                            z5 = false;
                                        }
                                        if (!z5) {
                                            throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                        }
/* 296 */                               id = UUID.randomUUID().toString();
                                        Intrinsics.checkNotNullExpressionValue(id, str2);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                        this.L$4 = savedNote12;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                        this.L$14 = id;
                                        this.label = 17;
/* 70 */                                if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 297 */                               id2 = id;
                                        list4 = list3;
                                        context2 = context;
                                        pair6 = pair5;
                                        sourceDeck6 = sourceDeck5;
                                        question2 = question;
                                        current13 = current12;
                                        template2 = template;
                                        savedNote13 = savedNote12;
                                        model17 = model16;
                                        list5 = list2;
                                        note20 = note19;
                                        answer2 = answer;
                                        deckId3 = deckId2;
/* 298 */                               note21 = note20;
                                        answer3 = answer2;
                                        question3 = question2;
                                        context3 = context2;
                                        id3 = id2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = savedNote13;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                        this.L$14 = id3;
                                        this.label = 18;
/* 70 */                                if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 298 */                               template3 = template2;
                                        list6 = list4;
                                        list7 = list5;
                                        deckId4 = deckId3;
                                        pair7 = pair6;
                                        note22 = note21;
                                        answer4 = answer3;
                                        answer5 = question3;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                        this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                        this.label = 19;
/* 70 */                                if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 300 */                               this.$added.element++;
/* 301 */                               return Unit.INSTANCE;
                                    }
                                    this.L$0 = sourceCard;
                                    this.L$1 = note3;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                    this.label = 7;
/* 256 */                           model = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 256 */                           AnkiSourceNote ankiSourceNote2 = note3;
                                    current4 = current2;
                                    note5 = ankiSourceNote2;
/* 239 */                           model6 = (AnkiModel) model;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note5;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current4);
                                    this.L$3 = model6;
                                    this.label = 8;
/* 257 */                           objInsertModel = new AnkiRepository(this.this$0.db).insertModel(AnkiRepository.Companion.modelSnapshot$default(AnkiRepository.INSTANCE, model6, null, 2, null), this);
                                    if (objInsertModel == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    savedNote3 = savedNote;
/* 257 */                           model7 = model6;
                                    current6 = current4;
                                    note8 = note5;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel2 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel2;
                                        AnkiNoteEntity ankiNoteEntity12 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity12;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity13 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity13;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope5 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope5;
/* 70 */                                    XunjiDao xunjiDaoDao5 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao5.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity14 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity14;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable10 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable10, 10));
                                            iterable2 = iterable10;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj8) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj8).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj8) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj8).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j6 = j2;
                                                        Object obj8 = coroutine_suspended;
                                                        AnkiModel model111 = model13;
                                                        model13 = model111;
                                                        coroutine_suspended = obj8;
                                                        j2 = j6;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj9 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj9;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current17 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current17;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable11 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable11, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i8 = iCoerceAtLeast;
                                            Pair pair11 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair11.getFirst(), pair11.getSecond());
                                            iCoerceAtLeast = i8;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName5 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName5, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 2:
                                    note2 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    objNoteByGuid = $result;
                                    current = (AnkiNoteEntity) objNoteByGuid;
/* 244 */                           if (current != null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = note2;
                                        this.L$2 = current;
                                        this.label = 3;
/* 70 */                                objLinks = this.this$0.dao.links(current.getId(), this);
                                        if (objLinks == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 244 */                               AnkiNoteEntity ankiNoteEntity15 = current;
                                        note4 = note2;
                                        current3 = ankiNoteEntity15;
/* 239 */                               iterable = (Iterable) objLinks;
/* 347 */                               if (iterable instanceof Collection) {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        } else {
/* 348 */                                   it = iterable.iterator();
                                            while (true) {
                                                if (it.hasNext()) {
/* 244 */                                           if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                        z2 = true;
                                                    } else {
                                                        z2 = false;
                                                    }
/* 348 */                                           if (z2) {
                                                        z = true;
                                                    }
                                                } else {
/* 349 */                                           z = false;
                                                }
                                            }
                                        }
/* 244 */                               if (z) {
/* 245 */                                   this.$duplicates.element++;
                                            return Unit.INSTANCE;
                                        }
/* 244 */                               current2 = current3;
                                        note3 = note4;
                                    } else {
                                        note3 = note2;
                                        current2 = current;
                                    }
/* 248 */                           savedNote = null;
/* 249 */                           if (current2 != null) {
/* 250 */                               ankiImportService = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = ankiImportService;
                                        this.label = 4;
/* 70 */                                objModel = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 248 */                               model2 = null;
                                        ankiImportService2 = ankiImportService;
                                        if (objModel == null) {
/* 250 */                                   throw new IllegalArgumentException("Required value was null.".toString());
                                        }
/* 70 */                                model3 = ankiImportService2.asModel((AnkiModelEntity) objModel);
/* 251 */                               ankiImportService3 = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = model3;
                                        this.L$4 = ankiImportService3;
                                        this.label = 5;
/* 70 */                                objModel2 = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 251 */                               AnkiNoteEntity ankiNoteEntity16 = current2;
                                        model4 = model3;
                                        note6 = note3;
                                        current5 = ankiNoteEntity16;
                                        ankiImportService4 = ankiImportService3;
                                        if (objModel2 != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        ankiModelEntity = (AnkiModelEntity) objModel2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                        this.L$2 = current5;
                                        this.L$3 = model4;
                                        this.L$4 = ankiImportService4;
                                        this.L$5 = ankiModelEntity;
                                        this.label = 6;
                                        model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                        if (model5 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        note7 = note6;
/* 251 */                               ankiModelEntity2 = ankiModelEntity;
/* 70 */                                if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                                   throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                        }
/* 254 */                               savedNote2 = current5;
/* 270 */                               ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                        if (ankiSourceDeck != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        sourceDeck = ankiSourceDeck;
/* 271 */                               pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                               str = this.$localDecks.get(pair);
                                        if (str == null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model4;
                                            this.L$4 = savedNote2;
                                            this.L$5 = sourceDeck;
                                            this.L$6 = pair;
                                            this.L$7 = null;
                                            this.label = 12;
/* 70 */                                    objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                            if (objDeckSource == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 272 */                                   savedNote7 = savedNote2;
                                            model11 = model4;
                                            current9 = current5;
                                            note12 = note7;
                                            pair3 = pair;
                                            sourceDeck3 = sourceDeck;
                                            ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                            if (ankiDeckSourceEntity != null) {
                                                localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                            } else {
                                                localDeckId = null;
                                            }
                                            if (localDeckId == null) {
                                                CoroutineScope coroutineScope6 = this.$$this$withContext;
                                                ankiImportService5 = this.this$0;
                                                j = this.$now;
                                                intRef = this.$decks;
                                                coroutineScope = coroutineScope6;
/* 70 */                                        XunjiDao xunjiDaoDao6 = ankiImportService5.db.dao();
                                                this.L$0 = sourceCard;
                                                current10 = current9;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model11;
                                                this.L$4 = savedNote7;
                                                this.L$5 = sourceDeck3;
                                                this.L$6 = pair3;
                                                this.L$7 = ankiImportService5;
                                                this.L$8 = intRef;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.J$0 = j;
                                                this.I$0 = 0;
                                                this.label = 13;
                                                objDecks = xunjiDaoDao6.decks(this);
                                                if (objDecks == coroutine_suspended) {
/* 239 */                                           return coroutine_suspended;
                                                }
/* 273 */                                       note13 = note12;
                                                ankiImportService6 = ankiImportService5;
                                                i = 0;
                                                sourceDeck4 = sourceDeck3;
                                                AnkiNoteEntity ankiNoteEntity17 = savedNote7;
                                                intRef2 = intRef;
                                                j2 = j;
                                                savedNote8 = ankiNoteEntity17;
                                                model12 = model11;
                                                pair4 = pair3;
/* 239 */                                       Iterable iterable12 = (Iterable) objDecks;
                                                savedNote9 = savedNote8;
                                                model13 = model12;
/* 351 */                                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable12, 10));
                                                iterable2 = iterable12;
/* 352 */                                       it2 = iterable2.iterator();
                                                while (it2.hasNext()) {
/* 353 */                                           arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                           iterable2 = iterable2;
                                                }
/* 273 */                                       set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                       fullName = sourceDeck4.getFullName();
/* 275 */                                       if (set.contains(fullName)) {
                                                    str4 = fullName;
                                                    str3 = str4;
                                                } else {
/* 355 */                                           it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj10) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj10).intValue());
                                                        }
                                                    }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj10) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj10).intValue());
                                                        }
                                                    }).iterator();
                                                    while (true) {
                                                        if (it3.hasNext()) {
                                                            throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                        }
                                                        next = it3.next();
                                                        str3 = fullName;
/* 355 */                                               if (set.contains((String) next)) {
/* 356 */                                                   str4 = (String) next;
                                                        } else {
/* 355 */                                                   long j7 = j2;
                                                            Object obj10 = coroutine_suspended;
                                                            AnkiModel model112 = model13;
                                                            model13 = model112;
                                                            coroutine_suspended = obj10;
                                                            j2 = j7;
                                                            set = set;
                                                            savedNote9 = savedNote9;
                                                            str6 = str6;
                                                            fullName = str3;
                                                        }
                                                    }
                                                }
/* 278 */                                       string = UUID.randomUUID().toString();
                                                Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                        xunjiDaoDao = ankiImportService6.db.dao();
                                                set2 = set;
                                                Object obj11 = coroutine_suspended;
                                                model14 = model13;
                                                str2 = str6;
                                                savedNote10 = savedNote9;
                                                deckEntity = new DeckEntity(string, str4, j2, j2);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model14;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = ankiImportService6;
                                                this.L$8 = intRef2;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                                this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$12 = string;
                                                this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                                this.I$0 = i;
                                                this.label = 14;
                                                obj = obj11;
                                                if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 279 */                                       ankiImportService7 = ankiImportService6;
                                                current11 = current10;
                                                set3 = set2;
                                                str5 = str3;
                                                model10 = model14;
                                                i2 = i;
                                                note14 = note13;
/* 70 */                                        ankiDao = ankiImportService7.dao;
                                                note15 = note14;
                                                ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                                this.L$3 = model10;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = intRef2;
                                                this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$11 = string;
                                                this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                                this.L$13 = null;
                                                this.I$0 = i2;
                                                this.label = 15;
                                                if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 281 */                                       intRef2.element++;
/* 283 */                                       this.$localDecks.put(pair4, string);
                                                str = string;
                                                coroutine_suspended = obj;
                                                current5 = current11;
                                                pair2 = pair4;
                                                sourceDeck2 = sourceDeck4;
                                                note11 = note15;
                                                savedNote6 = savedNote10;
                                            } else {
                                                str2 = "toString(...)";
                                                AnkiNoteEntity current18 = current9;
                                                str = localDeckId;
                                                savedNote6 = savedNote7;
                                                note11 = note12;
                                                current5 = current18;
                                                pair2 = pair3;
                                                model10 = model11;
                                                sourceDeck2 = sourceDeck3;
                                            }
                                        } else {
                                            str2 = "toString(...)";
                                            savedNote6 = savedNote2;
                                            sourceDeck2 = sourceDeck;
                                            pair2 = pair;
                                            model10 = model4;
                                            note11 = note7;
                                        }
                                        deckId = str;
/* 284 */                               listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                               listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                               if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                                   objectRef = this.$cachedMediaMimes;
                                            this.L$0 = sourceCard;
                                            note17 = note11;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote6;
                                            this.L$5 = sourceDeck2;
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                            this.L$7 = deckId;
                                            this.L$8 = listStrings;
                                            this.L$9 = listStrings2;
                                            this.L$10 = objectRef;
                                            this.L$11 = null;
                                            this.L$12 = null;
                                            this.label = 16;
/* 70 */                                    objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                            if (objMedia2 == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 287 */                                   note18 = note17;
/* 239 */                                   Iterable<AnkiMediaEntity> iterable13 = (Iterable) objMedia2;
/* 357 */                                   iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable13, 10)), 16);
/* 358 */                                   linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                            while (r22.hasNext()) {
/* 287 */                                       int i9 = iCoerceAtLeast;
                                                Pair pair12 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                       linkedHashMap.put(pair12.getFirst(), pair12.getSecond());
                                                iCoerceAtLeast = i9;
                                                note18 = note18;
                                            }
/* 287 */                                   objectRef.element = linkedHashMap;
/* 288 */                                   this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                            note16 = note18;
                                            list2 = listStrings;
                                            current12 = current5;
                                            list3 = listStrings2;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        } else {
/* 286 */                                   note16 = note11;
                                            list2 = listStrings;
                                            current12 = current5;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            list3 = listStrings2;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        }
/* 290 */                               templates = model15.getTemplates();
                                        i3 = 0;
/* 363 */                               it4 = templates.iterator();
                                        while (true) {
                                            if (it4.hasNext()) {
                                                next2 = it4.next();
/* 290 */                                       note19 = note16;
                                                ordinal = ((AnkiTemplate) next2).getOrdinal();
                                                iterable3 = templates;
                                                i4 = i3;
                                                if (model15.getKind() == 1) {
                                                    ordinal2 = 0;
                                                } else {
                                                    ordinal2 = sourceCard.getOrdinal();
                                                }
                                                if (ordinal == ordinal2) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
/* 363 */                                       if (!z6) {
                                                    note16 = note19;
                                                    templates = iterable3;
                                                    i3 = i4;
                                                }
                                            } else {
/* 364 */                                       note19 = note16;
                                                next2 = null;
                                            }
                                        }
/* 290 */                               template = (AnkiTemplate) next2;
                                        String fullName6 = sourceDeck5.getFullName();
                                        if (template != null) {
                                            name = template.getName();
                                        } else {
                                            name = null;
                                        }
                                        if (name == null) {
                                            name = "";
                                        }
/* 291 */                               context = new TemplateContext(fullName6, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                        model16 = model15;
                                        savedNote12 = savedNote11;
/* 70 */                                question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                                answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                               if (question.getIssues().isEmpty()) {
                                            z4 = false;
                                        } else {
                                            z4 = false;
                                        }
                                        if (!z4) {
                                            throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                        }
/* 295 */                               if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                            z5 = false;
                                        } else {
                                            z5 = false;
                                        }
                                        if (!z5) {
                                            throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                        }
/* 296 */                               id = UUID.randomUUID().toString();
                                        Intrinsics.checkNotNullExpressionValue(id, str2);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                        this.L$4 = savedNote12;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                        this.L$14 = id;
                                        this.label = 17;
/* 70 */                                if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 297 */                               id2 = id;
                                        list4 = list3;
                                        context2 = context;
                                        pair6 = pair5;
                                        sourceDeck6 = sourceDeck5;
                                        question2 = question;
                                        current13 = current12;
                                        template2 = template;
                                        savedNote13 = savedNote12;
                                        model17 = model16;
                                        list5 = list2;
                                        note20 = note19;
                                        answer2 = answer;
                                        deckId3 = deckId2;
/* 298 */                               note21 = note20;
                                        answer3 = answer2;
                                        question3 = question2;
                                        context3 = context2;
                                        id3 = id2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = savedNote13;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                        this.L$14 = id3;
                                        this.label = 18;
/* 70 */                                if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 298 */                               template3 = template2;
                                        list6 = list4;
                                        list7 = list5;
                                        deckId4 = deckId3;
                                        pair7 = pair6;
                                        note22 = note21;
                                        answer4 = answer3;
                                        answer5 = question3;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                        this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                        this.label = 19;
/* 70 */                                if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 300 */                               this.$added.element++;
/* 301 */                               return Unit.INSTANCE;
                                    }
                                    this.L$0 = sourceCard;
                                    this.L$1 = note3;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                    this.label = 7;
/* 256 */                           model = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 256 */                           AnkiSourceNote ankiSourceNote3 = note3;
                                    current4 = current2;
                                    note5 = ankiSourceNote3;
/* 239 */                           model6 = (AnkiModel) model;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note5;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current4);
                                    this.L$3 = model6;
                                    this.label = 8;
/* 257 */                           objInsertModel = new AnkiRepository(this.this$0.db).insertModel(AnkiRepository.Companion.modelSnapshot$default(AnkiRepository.INSTANCE, model6, null, 2, null), this);
                                    if (objInsertModel == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    savedNote3 = savedNote;
/* 257 */                           model7 = model6;
                                    current6 = current4;
                                    note8 = note5;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel3 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel3;
                                        AnkiNoteEntity ankiNoteEntity18 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity18;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity19 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity19;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope7 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope7;
/* 70 */                                    XunjiDao xunjiDaoDao7 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao7.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity110 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity110;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable14 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable14, 10));
                                            iterable2 = iterable14;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj12) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj12).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj12) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj12).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j8 = j2;
                                                        Object obj12 = coroutine_suspended;
                                                        AnkiModel model113 = model13;
                                                        model13 = model113;
                                                        coroutine_suspended = obj12;
                                                        j2 = j8;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj13 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj13;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current19 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current19;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable15 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable15, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i10 = iCoerceAtLeast;
                                            Pair pair13 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair13.getFirst(), pair13.getSecond());
                                            iCoerceAtLeast = i10;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName7 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName7, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 3:
                                    current3 = (AnkiNoteEntity) this.L$2;
                                    note4 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    objLinks = $result;
/* 239 */                           iterable = (Iterable) objLinks;
/* 347 */                           if (iterable instanceof Collection) {
/* 348 */                               it = iterable.iterator();
                                        while (true) {
                                            if (it.hasNext()) {
/* 244 */                                       if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
/* 348 */                                       if (z2) {
                                                    z = true;
                                                }
                                            } else {
/* 349 */                                       z = false;
                                            }
                                        }
                                    } else {
/* 348 */                               it = iterable.iterator();
                                        while (true) {
                                            if (it.hasNext()) {
/* 244 */                                       if (((AnkiCardEntity) it.next()).getOrdinal() == sourceCard.getOrdinal()) {
                                                    z2 = true;
                                                } else {
                                                    z2 = false;
                                                }
/* 348 */                                       if (z2) {
                                                    z = true;
                                                }
                                            } else {
/* 349 */                                       z = false;
                                            }
                                        }
                                    }
/* 244 */                           if (z) {
/* 245 */                               this.$duplicates.element++;
                                        return Unit.INSTANCE;
                                    }
/* 244 */                           current2 = current3;
                                    note3 = note4;
/* 248 */                           savedNote = null;
/* 249 */                           if (current2 != null) {
/* 250 */                               ankiImportService = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = ankiImportService;
                                        this.label = 4;
/* 70 */                                objModel = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 248 */                               model2 = null;
                                        ankiImportService2 = ankiImportService;
                                        if (objModel == null) {
/* 250 */                                   throw new IllegalArgumentException("Required value was null.".toString());
                                        }
/* 70 */                                model3 = ankiImportService2.asModel((AnkiModelEntity) objModel);
/* 251 */                               ankiImportService3 = this.this$0;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                        this.L$2 = current2;
                                        this.L$3 = model3;
                                        this.L$4 = ankiImportService3;
                                        this.label = 5;
/* 70 */                                objModel2 = this.this$0.dao.model(current2.getModelId(), this);
                                        if (objModel2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 251 */                               AnkiNoteEntity ankiNoteEntity111 = current2;
                                        model4 = model3;
                                        note6 = note3;
                                        current5 = ankiNoteEntity111;
                                        ankiImportService4 = ankiImportService3;
                                        if (objModel2 != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        ankiModelEntity = (AnkiModelEntity) objModel2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                        this.L$2 = current5;
                                        this.L$3 = model4;
                                        this.L$4 = ankiImportService4;
                                        this.L$5 = ankiModelEntity;
                                        this.label = 6;
                                        model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                        if (model5 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
                                        note7 = note6;
/* 251 */                               ankiModelEntity2 = ankiModelEntity;
/* 70 */                                if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                                   throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                        }
/* 254 */                               savedNote2 = current5;
/* 270 */                               ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                        if (ankiSourceDeck != null) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        sourceDeck = ankiSourceDeck;
/* 271 */                               pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                               str = this.$localDecks.get(pair);
                                        if (str == null) {
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model4;
                                            this.L$4 = savedNote2;
                                            this.L$5 = sourceDeck;
                                            this.L$6 = pair;
                                            this.L$7 = null;
                                            this.label = 12;
/* 70 */                                    objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                            if (objDeckSource == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 272 */                                   savedNote7 = savedNote2;
                                            model11 = model4;
                                            current9 = current5;
                                            note12 = note7;
                                            pair3 = pair;
                                            sourceDeck3 = sourceDeck;
                                            ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                            if (ankiDeckSourceEntity != null) {
                                                localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                            } else {
                                                localDeckId = null;
                                            }
                                            if (localDeckId == null) {
                                                CoroutineScope coroutineScope8 = this.$$this$withContext;
                                                ankiImportService5 = this.this$0;
                                                j = this.$now;
                                                intRef = this.$decks;
                                                coroutineScope = coroutineScope8;
/* 70 */                                        XunjiDao xunjiDaoDao8 = ankiImportService5.db.dao();
                                                this.L$0 = sourceCard;
                                                current10 = current9;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model11;
                                                this.L$4 = savedNote7;
                                                this.L$5 = sourceDeck3;
                                                this.L$6 = pair3;
                                                this.L$7 = ankiImportService5;
                                                this.L$8 = intRef;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.J$0 = j;
                                                this.I$0 = 0;
                                                this.label = 13;
                                                objDecks = xunjiDaoDao8.decks(this);
                                                if (objDecks == coroutine_suspended) {
/* 239 */                                           return coroutine_suspended;
                                                }
/* 273 */                                       note13 = note12;
                                                ankiImportService6 = ankiImportService5;
                                                i = 0;
                                                sourceDeck4 = sourceDeck3;
                                                AnkiNoteEntity ankiNoteEntity112 = savedNote7;
                                                intRef2 = intRef;
                                                j2 = j;
                                                savedNote8 = ankiNoteEntity112;
                                                model12 = model11;
                                                pair4 = pair3;
/* 239 */                                       Iterable iterable16 = (Iterable) objDecks;
                                                savedNote9 = savedNote8;
                                                model13 = model12;
/* 351 */                                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable16, 10));
                                                iterable2 = iterable16;
/* 352 */                                       it2 = iterable2.iterator();
                                                while (it2.hasNext()) {
/* 353 */                                           arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                           iterable2 = iterable2;
                                                }
/* 273 */                                       set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                       fullName = sourceDeck4.getFullName();
/* 275 */                                       if (set.contains(fullName)) {
                                                    str4 = fullName;
                                                    str3 = str4;
                                                } else {
/* 355 */                                           it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj14) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj14).intValue());
                                                        }
                                                    }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                        @Override // kotlin.jvm.functions.Function1
                                                        public final Object invoke(Object obj14) {
                                                            return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj14).intValue());
                                                        }
                                                    }).iterator();
                                                    while (true) {
                                                        if (it3.hasNext()) {
                                                            throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                        }
                                                        next = it3.next();
                                                        str3 = fullName;
/* 355 */                                               if (set.contains((String) next)) {
/* 356 */                                                   str4 = (String) next;
                                                        } else {
/* 355 */                                                   long j9 = j2;
                                                            Object obj14 = coroutine_suspended;
                                                            AnkiModel model114 = model13;
                                                            model13 = model114;
                                                            coroutine_suspended = obj14;
                                                            j2 = j9;
                                                            set = set;
                                                            savedNote9 = savedNote9;
                                                            str6 = str6;
                                                            fullName = str3;
                                                        }
                                                    }
                                                }
/* 278 */                                       string = UUID.randomUUID().toString();
                                                Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                        xunjiDaoDao = ankiImportService6.db.dao();
                                                set2 = set;
                                                Object obj15 = coroutine_suspended;
                                                model14 = model13;
                                                str2 = str6;
                                                savedNote10 = savedNote9;
                                                deckEntity = new DeckEntity(string, str4, j2, j2);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                                this.L$3 = model14;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = ankiImportService6;
                                                this.L$8 = intRef2;
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                                this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$12 = string;
                                                this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                                this.I$0 = i;
                                                this.label = 14;
                                                obj = obj15;
                                                if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 279 */                                       ankiImportService7 = ankiImportService6;
                                                current11 = current10;
                                                set3 = set2;
                                                str5 = str3;
                                                model10 = model14;
                                                i2 = i;
                                                note14 = note13;
/* 70 */                                        ankiDao = ankiImportService7.dao;
                                                note15 = note14;
                                                ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                                this.L$0 = sourceCard;
                                                this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                                this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                                this.L$3 = model10;
                                                this.L$4 = savedNote10;
                                                this.L$5 = sourceDeck4;
                                                this.L$6 = pair4;
                                                this.L$7 = intRef2;
                                                this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                                this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                                this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                                this.L$11 = string;
                                                this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                                this.L$13 = null;
                                                this.I$0 = i2;
                                                this.label = 15;
                                                if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                           return obj;
                                                }
/* 281 */                                       intRef2.element++;
/* 283 */                                       this.$localDecks.put(pair4, string);
                                                str = string;
                                                coroutine_suspended = obj;
                                                current5 = current11;
                                                pair2 = pair4;
                                                sourceDeck2 = sourceDeck4;
                                                note11 = note15;
                                                savedNote6 = savedNote10;
                                            } else {
                                                str2 = "toString(...)";
                                                AnkiNoteEntity current110 = current9;
                                                str = localDeckId;
                                                savedNote6 = savedNote7;
                                                note11 = note12;
                                                current5 = current110;
                                                pair2 = pair3;
                                                model10 = model11;
                                                sourceDeck2 = sourceDeck3;
                                            }
                                        } else {
                                            str2 = "toString(...)";
                                            savedNote6 = savedNote2;
                                            sourceDeck2 = sourceDeck;
                                            pair2 = pair;
                                            model10 = model4;
                                            note11 = note7;
                                        }
                                        deckId = str;
/* 284 */                               listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                               listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                               if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                                   objectRef = this.$cachedMediaMimes;
                                            this.L$0 = sourceCard;
                                            note17 = note11;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote6;
                                            this.L$5 = sourceDeck2;
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                            this.L$7 = deckId;
                                            this.L$8 = listStrings;
                                            this.L$9 = listStrings2;
                                            this.L$10 = objectRef;
                                            this.L$11 = null;
                                            this.L$12 = null;
                                            this.label = 16;
/* 70 */                                    objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                            if (objMedia2 == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 287 */                                   note18 = note17;
/* 239 */                                   Iterable<AnkiMediaEntity> iterable17 = (Iterable) objMedia2;
/* 357 */                                   iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable17, 10)), 16);
/* 358 */                                   linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                            while (r22.hasNext()) {
/* 287 */                                       int i11 = iCoerceAtLeast;
                                                Pair pair14 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                       linkedHashMap.put(pair14.getFirst(), pair14.getSecond());
                                                iCoerceAtLeast = i11;
                                                note18 = note18;
                                            }
/* 287 */                                   objectRef.element = linkedHashMap;
/* 288 */                                   this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                            note16 = note18;
                                            list2 = listStrings;
                                            current12 = current5;
                                            list3 = listStrings2;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        } else {
/* 286 */                                   note16 = note11;
                                            list2 = listStrings;
                                            current12 = current5;
                                            deckId2 = deckId;
                                            model15 = model10;
                                            list3 = listStrings2;
                                            sourceDeck5 = sourceDeck2;
                                            savedNote11 = savedNote6;
                                            pair5 = pair2;
                                        }
/* 290 */                               templates = model15.getTemplates();
                                        i3 = 0;
/* 363 */                               it4 = templates.iterator();
                                        while (true) {
                                            if (it4.hasNext()) {
                                                next2 = it4.next();
/* 290 */                                       note19 = note16;
                                                ordinal = ((AnkiTemplate) next2).getOrdinal();
                                                iterable3 = templates;
                                                i4 = i3;
                                                if (model15.getKind() == 1) {
                                                    ordinal2 = 0;
                                                } else {
                                                    ordinal2 = sourceCard.getOrdinal();
                                                }
                                                if (ordinal == ordinal2) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
/* 363 */                                       if (!z6) {
                                                    note16 = note19;
                                                    templates = iterable3;
                                                    i3 = i4;
                                                }
                                            } else {
/* 364 */                                       note19 = note16;
                                                next2 = null;
                                            }
                                        }
/* 290 */                               template = (AnkiTemplate) next2;
                                        String fullName8 = sourceDeck5.getFullName();
                                        if (template != null) {
                                            name = template.getName();
                                        } else {
                                            name = null;
                                        }
                                        if (name == null) {
                                            name = "";
                                        }
/* 291 */                               context = new TemplateContext(fullName8, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                        model16 = model15;
                                        savedNote12 = savedNote11;
/* 70 */                                question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                                answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                               if (question.getIssues().isEmpty()) {
                                            z4 = false;
                                        } else {
                                            z4 = false;
                                        }
                                        if (!z4) {
                                            throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                        }
/* 295 */                               if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                            z5 = false;
                                        } else {
                                            z5 = false;
                                        }
                                        if (!z5) {
                                            throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                        }
/* 296 */                               id = UUID.randomUUID().toString();
                                        Intrinsics.checkNotNullExpressionValue(id, str2);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                        this.L$4 = savedNote12;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                        this.L$14 = id;
                                        this.label = 17;
/* 70 */                                if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 297 */                               id2 = id;
                                        list4 = list3;
                                        context2 = context;
                                        pair6 = pair5;
                                        sourceDeck6 = sourceDeck5;
                                        question2 = question;
                                        current13 = current12;
                                        template2 = template;
                                        savedNote13 = savedNote12;
                                        model17 = model16;
                                        list5 = list2;
                                        note20 = note19;
                                        answer2 = answer;
                                        deckId3 = deckId2;
/* 298 */                               note21 = note20;
                                        answer3 = answer2;
                                        question3 = question2;
                                        context3 = context2;
                                        id3 = id2;
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = savedNote13;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                        this.L$14 = id3;
                                        this.label = 18;
/* 70 */                                if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 298 */                               template3 = template2;
                                        list6 = list4;
                                        list7 = list5;
                                        deckId4 = deckId3;
                                        pair7 = pair6;
                                        note22 = note21;
                                        answer4 = answer3;
                                        answer5 = question3;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                        this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                        this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                        this.label = 19;
/* 70 */                                if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 300 */                               this.$added.element++;
/* 301 */                               return Unit.INSTANCE;
                                    }
                                    this.L$0 = sourceCard;
                                    this.L$1 = note3;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                    this.label = 7;
/* 256 */                           model = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 256 */                           AnkiSourceNote ankiSourceNote4 = note3;
                                    current4 = current2;
                                    note5 = ankiSourceNote4;
/* 239 */                           model6 = (AnkiModel) model;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note5;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current4);
                                    this.L$3 = model6;
                                    this.label = 8;
/* 257 */                           objInsertModel = new AnkiRepository(this.this$0.db).insertModel(AnkiRepository.Companion.modelSnapshot$default(AnkiRepository.INSTANCE, model6, null, 2, null), this);
                                    if (objInsertModel == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    savedNote3 = savedNote;
/* 257 */                           model7 = model6;
                                    current6 = current4;
                                    note8 = note5;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel4 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel4;
                                        AnkiNoteEntity ankiNoteEntity113 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity113;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity114 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity114;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope9 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope9;
/* 70 */                                    XunjiDao xunjiDaoDao9 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao9.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity115 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity115;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable18 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable18, 10));
                                            iterable2 = iterable18;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj16) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj16).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj16) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj16).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j10 = j2;
                                                        Object obj16 = coroutine_suspended;
                                                        AnkiModel model115 = model13;
                                                        model13 = model115;
                                                        coroutine_suspended = obj16;
                                                        j2 = j10;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj17 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj17;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current111 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current111;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable19 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable19, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i12 = iCoerceAtLeast;
                                            Pair pair15 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair15.getFirst(), pair15.getSecond());
                                            iCoerceAtLeast = i12;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName9 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName9, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 4:
                                    ankiImportService2 = (AnkiImportService) this.L$3;
                                    model2 = null;
                                    current2 = (AnkiNoteEntity) this.L$2;
                                    note3 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    objModel = $result;
                                    if (objModel == null) {
/* 250 */                               throw new IllegalArgumentException("Required value was null.".toString());
                                    }
/* 70 */                            model3 = ankiImportService2.asModel((AnkiModelEntity) objModel);
/* 251 */                           ankiImportService3 = this.this$0;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = current2;
                                    this.L$3 = model3;
                                    this.L$4 = ankiImportService3;
                                    this.label = 5;
/* 70 */                            objModel2 = this.this$0.dao.model(current2.getModelId(), this);
                                    if (objModel2 == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 251 */                           AnkiNoteEntity ankiNoteEntity116 = current2;
                                    model4 = model3;
                                    note6 = note3;
                                    current5 = ankiNoteEntity116;
                                    ankiImportService4 = ankiImportService3;
                                    if (objModel2 != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    ankiModelEntity = (AnkiModelEntity) objModel2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                    this.L$2 = current5;
                                    this.L$3 = model4;
                                    this.L$4 = ankiImportService4;
                                    this.L$5 = ankiModelEntity;
                                    this.label = 6;
                                    model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model5 == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    note7 = note6;
/* 251 */                           ankiModelEntity2 = ankiModelEntity;
/* 70 */                            if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                               throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                    }
/* 254 */                           savedNote2 = current5;
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope10 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope10;
/* 70 */                                    XunjiDao xunjiDaoDao10 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao10.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity117 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity117;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable110 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable110, 10));
                                            iterable2 = iterable110;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj18) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj18).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj18) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj18).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j11 = j2;
                                                        Object obj18 = coroutine_suspended;
                                                        AnkiModel model116 = model13;
                                                        model13 = model116;
                                                        coroutine_suspended = obj18;
                                                        j2 = j11;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj19 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj19;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current112 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current112;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable111 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable111, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i13 = iCoerceAtLeast;
                                            Pair pair16 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair16.getFirst(), pair16.getSecond());
                                            iCoerceAtLeast = i13;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName10 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName10, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 5:
                                    AnkiImportService ankiImportService8 = (AnkiImportService) this.L$4;
                                    AnkiModel model20 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current20 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note23 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    ankiImportService4 = ankiImportService8;
                                    note6 = note23;
                                    current5 = current20;
                                    model4 = model20;
                                    objModel2 = $result;
                                    if (objModel2 != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    ankiModelEntity = (AnkiModelEntity) objModel2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note6);
                                    this.L$2 = current5;
                                    this.L$3 = model4;
                                    this.L$4 = ankiImportService4;
                                    this.L$5 = ankiModelEntity;
                                    this.label = 6;
                                    model5 = this.$prepared.getSource().readModel(sourceCard.getSourceId(), this);
                                    if (model5 == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    note7 = note6;
/* 251 */                           ankiModelEntity2 = ankiModelEntity;
/* 70 */                            if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                               throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                    }
/* 254 */                           savedNote2 = current5;
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope11 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope11;
/* 70 */                                    XunjiDao xunjiDaoDao11 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao11.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity118 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity118;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable112 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable112, 10));
                                            iterable2 = iterable112;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj110) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj110).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj110) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj110).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j12 = j2;
                                                        Object obj110 = coroutine_suspended;
                                                        AnkiModel model117 = model13;
                                                        model13 = model117;
                                                        coroutine_suspended = obj110;
                                                        j2 = j12;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj111 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj111;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current113 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current113;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable113 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable113, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i14 = iCoerceAtLeast;
                                            Pair pair17 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair17.getFirst(), pair17.getSecond());
                                            iCoerceAtLeast = i14;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName11 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName11, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 6:
                                    ankiModelEntity2 = (AnkiModelEntity) this.L$5;
                                    ankiImportService4 = (AnkiImportService) this.L$4;
                                    model4 = (AnkiModel) this.L$3;
                                    current5 = (AnkiNoteEntity) this.L$2;
                                    note7 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    model5 = $result;
/* 70 */                            if (!ankiImportService4.compatible(ankiModelEntity2, (AnkiModel) model5)) {
/* 251 */                               throw new IllegalArgumentException("Source model changed; repeat import preflight".toString());
                                    }
/* 254 */                           savedNote2 = current5;
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope12 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope12;
/* 70 */                                    XunjiDao xunjiDaoDao12 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao12.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity119 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity119;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable114 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable114, 10));
                                            iterable2 = iterable114;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj112) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj112).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj112) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj112).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j13 = j2;
                                                        Object obj112 = coroutine_suspended;
                                                        AnkiModel model118 = model13;
                                                        model13 = model118;
                                                        coroutine_suspended = obj112;
                                                        j2 = j13;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj113 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj113;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current114 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current114;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable115 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable115, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i15 = iCoerceAtLeast;
                                            Pair pair18 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair18.getFirst(), pair18.getSecond());
                                            iCoerceAtLeast = i15;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName12 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName12, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 7:
                                    savedNote = null;
                                    AnkiNoteEntity current21 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note24 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    current4 = current21;
                                    note5 = note24;
                                    model = $result;
/* 239 */                           model6 = (AnkiModel) model;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note5;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current4);
                                    this.L$3 = model6;
                                    this.label = 8;
/* 257 */                           objInsertModel = new AnkiRepository(this.this$0.db).insertModel(AnkiRepository.Companion.modelSnapshot$default(AnkiRepository.INSTANCE, model6, null, 2, null), this);
                                    if (objInsertModel == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    savedNote3 = savedNote;
/* 257 */                           model7 = model6;
                                    current6 = current4;
                                    note8 = note5;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel5 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel5;
                                        AnkiNoteEntity ankiNoteEntity1110 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity1110;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity1111 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity1111;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope13 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope13;
/* 70 */                                    XunjiDao xunjiDaoDao13 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao13.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity1112 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity1112;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable116 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable116, 10));
                                            iterable2 = iterable116;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj114) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj114).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj114) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj114).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j14 = j2;
                                                        Object obj114 = coroutine_suspended;
                                                        AnkiModel model119 = model13;
                                                        model13 = model119;
                                                        coroutine_suspended = obj114;
                                                        j2 = j14;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj115 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj115;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current115 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current115;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable117 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable117, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i16 = iCoerceAtLeast;
                                            Pair pair19 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair19.getFirst(), pair19.getSecond());
                                            iCoerceAtLeast = i16;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName13 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName13, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 8:
                                    AnkiModel model21 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current22 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note25 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    savedNote3 = null;
                                    model7 = model21;
                                    current6 = current22;
                                    objInsertModel = $result;
                                    note8 = note25;
/* 239 */                           persistedModel = (AnkiModelEntity) objInsertModel;
                                    this.L$0 = sourceCard;
                                    this.L$1 = note8;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current6);
                                    this.L$3 = model7;
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(persistedModel);
                                    this.label = 9;
/* 258 */                           objInsertNote = new AnkiRepository(this.this$0.db).insertNote(AnkiRepository.Companion.noteSnapshot$default(AnkiRepository.INSTANCE, note8, persistedModel.getId(), this.$prepared.getNamespace(), null, 8, null), this);
                                    if (objInsertNote == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
                                    model8 = model7;
/* 258 */                           persistedModel2 = persistedModel;
                                    current7 = current6;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel6 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel6;
                                        AnkiNoteEntity ankiNoteEntity1113 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity1113;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity1114 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity1114;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope14 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope14;
/* 70 */                                    XunjiDao xunjiDaoDao14 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao14.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity1115 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity1115;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable118 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable118, 10));
                                            iterable2 = iterable118;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj116) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj116).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj116) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj116).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j15 = j2;
                                                        Object obj116 = coroutine_suspended;
                                                        AnkiModel model1110 = model13;
                                                        model13 = model1110;
                                                        coroutine_suspended = obj116;
                                                        j2 = j15;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj117 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj117;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current116 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current116;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable119 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable119, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i17 = iCoerceAtLeast;
                                            Pair pair110 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair110.getFirst(), pair110.getSecond());
                                            iCoerceAtLeast = i17;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName14 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName14, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 9:
                                    persistedModel2 = (AnkiModelEntity) this.L$4;
                                    model8 = (AnkiModel) this.L$3;
                                    current7 = (AnkiNoteEntity) this.L$2;
                                    note8 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    objInsertNote = $result;
/* 239 */                           savedNote4 = (AnkiNoteEntity) objInsertNote;
/* 259 */                           this.$localNotes.put(note8.getGuid(), savedNote4);
/* 260 */                           this.$notes.element++;
/* 261 */                           if (this.$mediaStored.element) {
/* 262 */                               stagedMedia = this.$staged;
                                        if (stagedMedia != null) {
                                            listEmptyList = stagedMedia.getMappings();
                                        } else {
                                            listEmptyList = null;
                                        }
                                        if (listEmptyList == null) {
                                            listEmptyList = CollectionsKt.emptyList();
                                        }
/* 263 */                               if (!Intrinsics.areEqual(MediaStore.INSTANCE.namespaceFor(listEmptyList), this.$prepared.getNamespace())) {
                                            throw new IllegalArgumentException("Staged media namespace differs".toString());
                                        }
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note8);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current7);
                                        this.L$3 = model8;
                                        this.L$4 = savedNote4;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(persistedModel2);
                                        this.L$6 = listEmptyList;
                                        this.label = 10;
/* 70 */                                objMedia = this.this$0.dao.media(this.$prepared.getNamespace(), this);
                                        if (objMedia == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 264 */                               AnkiModel ankiModel7 = model8;
                                        persistedModel3 = persistedModel2;
                                        note9 = note8;
                                        model9 = ankiModel7;
                                        AnkiNoteEntity ankiNoteEntity1116 = current7;
                                        savedNote5 = savedNote4;
                                        list = listEmptyList;
                                        current8 = ankiNoteEntity1116;
/* 239 */                               existing = (List) objMedia;
/* 265 */                               if (existing.isEmpty()) {
                                        }
/* 266 */                               if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                            z3 = true;
                                        } else {
                                            z3 = true;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                        }
                                        AnkiNoteEntity ankiNoteEntity1117 = current8;
                                        note7 = note9;
                                        savedNote2 = savedNote5;
                                        model4 = model9;
                                        current5 = ankiNoteEntity1117;
/* 267 */                               this.$mediaStored.element = true;
                                        break;
                                    } else {
/* 261 */                               savedNote2 = savedNote4;
                                        note7 = note8;
                                        current5 = current7;
                                        model4 = model8;
                                    }
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope15 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope15;
/* 70 */                                    XunjiDao xunjiDaoDao15 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao15.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity1118 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity1118;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable1110 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable1110, 10));
                                            iterable2 = iterable1110;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj118) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj118).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj118) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj118).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j16 = j2;
                                                        Object obj118 = coroutine_suspended;
                                                        AnkiModel model1111 = model13;
                                                        model13 = model1111;
                                                        coroutine_suspended = obj118;
                                                        j2 = j16;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj119 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj119;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current117 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current117;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable1111 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable1111, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i18 = iCoerceAtLeast;
                                            Pair pair111 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair111.getFirst(), pair111.getSecond());
                                            iCoerceAtLeast = i18;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName15 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName15, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 10:
                                    List<AnkiMediaEntity> list8 = (List) this.L$6;
                                    AnkiModelEntity persistedModel4 = (AnkiModelEntity) this.L$5;
                                    AnkiNoteEntity savedNote14 = (AnkiNoteEntity) this.L$4;
                                    AnkiModel model22 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current23 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note26 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    list = list8;
                                    note9 = note26;
                                    current8 = current23;
                                    model9 = model22;
                                    savedNote5 = savedNote14;
                                    persistedModel3 = persistedModel4;
                                    objMedia = $result;
/* 239 */                           existing = (List) objMedia;
/* 265 */                           if (existing.isEmpty()) {
                                        break;
                                    }
/* 266 */                           if (Intrinsics.areEqual(CollectionsKt.toSet(existing), CollectionsKt.toSet(list))) {
                                        z3 = true;
                                    } else {
                                        z3 = true;
                                    }
                                    if (z3) {
                                        throw new IllegalArgumentException("Media namespace mapping changed".toString());
                                    }
                                    AnkiNoteEntity ankiNoteEntity1119 = current8;
                                    note7 = note9;
                                    savedNote2 = savedNote5;
                                    model4 = model9;
                                    current5 = ankiNoteEntity1119;
/* 267 */                           this.$mediaStored.element = true;
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope16 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope16;
/* 70 */                                    XunjiDao xunjiDaoDao16 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao16.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity11110 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity11110;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable1112 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable1112, 10));
                                            iterable2 = iterable1112;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj1110) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj1110).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj1110) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj1110).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j17 = j2;
                                                        Object obj1110 = coroutine_suspended;
                                                        AnkiModel model1112 = model13;
                                                        model13 = model1112;
                                                        coroutine_suspended = obj1110;
                                                        j2 = j17;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj1111 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj1111;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current118 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current118;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable1113 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable1113, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i19 = iCoerceAtLeast;
                                            Pair pair112 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair112.getFirst(), pair112.getSecond());
                                            iCoerceAtLeast = i19;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName16 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName16, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 11:
                                    existing2 = (List) this.L$7;
                                    savedNote5 = (AnkiNoteEntity) this.L$4;
                                    model9 = (AnkiModel) this.L$3;
                                    current8 = (AnkiNoteEntity) this.L$2;
                                    note10 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    savedNote2 = savedNote5;
                                    model4 = model9;
                                    current5 = current8;
                                    note7 = note10;
/* 267 */                           this.$mediaStored.element = true;
/* 270 */                           ankiSourceDeck = this.$prepared.getSource().getDecks().get(Boxing.boxLong(sourceCard.getEffectiveDeckId()));
                                    if (ankiSourceDeck != null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    sourceDeck = ankiSourceDeck;
/* 271 */                           pair = TuplesKt.to(String.valueOf(sourceDeck.getSourceId()), sourceDeck.getFullName());
/* 272 */                           str = this.$localDecks.get(pair);
                                    if (str == null) {
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note7);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model4;
                                        this.L$4 = savedNote2;
                                        this.L$5 = sourceDeck;
                                        this.L$6 = pair;
                                        this.L$7 = null;
                                        this.label = 12;
/* 70 */                                objDeckSource = this.this$0.dao.deckSource(pair.getFirst(), pair.getSecond(), this);
                                        if (objDeckSource == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 272 */                               savedNote7 = savedNote2;
                                        model11 = model4;
                                        current9 = current5;
                                        note12 = note7;
                                        pair3 = pair;
                                        sourceDeck3 = sourceDeck;
                                        ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                        if (ankiDeckSourceEntity != null) {
                                            localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                        } else {
                                            localDeckId = null;
                                        }
                                        if (localDeckId == null) {
                                            CoroutineScope coroutineScope17 = this.$$this$withContext;
                                            ankiImportService5 = this.this$0;
                                            j = this.$now;
                                            intRef = this.$decks;
                                            coroutineScope = coroutineScope17;
/* 70 */                                    XunjiDao xunjiDaoDao17 = ankiImportService5.db.dao();
                                            this.L$0 = sourceCard;
                                            current10 = current9;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model11;
                                            this.L$4 = savedNote7;
                                            this.L$5 = sourceDeck3;
                                            this.L$6 = pair3;
                                            this.L$7 = ankiImportService5;
                                            this.L$8 = intRef;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.J$0 = j;
                                            this.I$0 = 0;
                                            this.label = 13;
                                            objDecks = xunjiDaoDao17.decks(this);
                                            if (objDecks == coroutine_suspended) {
/* 239 */                                       return coroutine_suspended;
                                            }
/* 273 */                                   note13 = note12;
                                            ankiImportService6 = ankiImportService5;
                                            i = 0;
                                            sourceDeck4 = sourceDeck3;
                                            AnkiNoteEntity ankiNoteEntity11111 = savedNote7;
                                            intRef2 = intRef;
                                            j2 = j;
                                            savedNote8 = ankiNoteEntity11111;
                                            model12 = model11;
                                            pair4 = pair3;
/* 239 */                                   Iterable iterable1114 = (Iterable) objDecks;
                                            savedNote9 = savedNote8;
                                            model13 = model12;
/* 351 */                                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable1114, 10));
                                            iterable2 = iterable1114;
/* 352 */                                   it2 = iterable2.iterator();
                                            while (it2.hasNext()) {
/* 353 */                                       arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                       iterable2 = iterable2;
                                            }
/* 273 */                                   set = CollectionsKt.toSet((List) arrayList);
/* 274 */                                   fullName = sourceDeck4.getFullName();
/* 275 */                                   if (set.contains(fullName)) {
                                                str4 = fullName;
                                                str3 = str4;
                                            } else {
/* 355 */                                       it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj1112) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj1112).intValue());
                                                    }
                                                }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj1112) {
                                                        return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj1112).intValue());
                                                    }
                                                }).iterator();
                                                while (true) {
                                                    if (it3.hasNext()) {
                                                        throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                    }
                                                    next = it3.next();
                                                    str3 = fullName;
/* 355 */                                           if (set.contains((String) next)) {
/* 356 */                                               str4 = (String) next;
                                                    } else {
/* 355 */                                               long j18 = j2;
                                                        Object obj1112 = coroutine_suspended;
                                                        AnkiModel model1113 = model13;
                                                        model13 = model1113;
                                                        coroutine_suspended = obj1112;
                                                        j2 = j18;
                                                        set = set;
                                                        savedNote9 = savedNote9;
                                                        str6 = str6;
                                                        fullName = str3;
                                                    }
                                                }
                                            }
/* 278 */                                   string = UUID.randomUUID().toString();
                                            Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                    xunjiDaoDao = ankiImportService6.db.dao();
                                            set2 = set;
                                            Object obj1113 = coroutine_suspended;
                                            model14 = model13;
                                            str2 = str6;
                                            savedNote10 = savedNote9;
                                            deckEntity = new DeckEntity(string, str4, j2, j2);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                            this.L$3 = model14;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = ankiImportService6;
                                            this.L$8 = intRef2;
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                            this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$12 = string;
                                            this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                            this.I$0 = i;
                                            this.label = 14;
                                            obj = obj1113;
                                            if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 279 */                                   ankiImportService7 = ankiImportService6;
                                            current11 = current10;
                                            set3 = set2;
                                            str5 = str3;
                                            model10 = model14;
                                            i2 = i;
                                            note14 = note13;
/* 70 */                                    ankiDao = ankiImportService7.dao;
                                            note15 = note14;
                                            ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                            this.L$0 = sourceCard;
                                            this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                            this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                            this.L$3 = model10;
                                            this.L$4 = savedNote10;
                                            this.L$5 = sourceDeck4;
                                            this.L$6 = pair4;
                                            this.L$7 = intRef2;
                                            this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                            this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                            this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                            this.L$11 = string;
                                            this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                            this.L$13 = null;
                                            this.I$0 = i2;
                                            this.label = 15;
                                            if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                       return obj;
                                            }
/* 281 */                                   intRef2.element++;
/* 283 */                                   this.$localDecks.put(pair4, string);
                                            str = string;
                                            coroutine_suspended = obj;
                                            current5 = current11;
                                            pair2 = pair4;
                                            sourceDeck2 = sourceDeck4;
                                            note11 = note15;
                                            savedNote6 = savedNote10;
                                        } else {
                                            str2 = "toString(...)";
                                            AnkiNoteEntity current119 = current9;
                                            str = localDeckId;
                                            savedNote6 = savedNote7;
                                            note11 = note12;
                                            current5 = current119;
                                            pair2 = pair3;
                                            model10 = model11;
                                            sourceDeck2 = sourceDeck3;
                                        }
                                    } else {
                                        str2 = "toString(...)";
                                        savedNote6 = savedNote2;
                                        sourceDeck2 = sourceDeck;
                                        pair2 = pair;
                                        model10 = model4;
                                        note11 = note7;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable1115 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable1115, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i110 = iCoerceAtLeast;
                                            Pair pair113 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair113.getFirst(), pair113.getSecond());
                                            iCoerceAtLeast = i110;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName17 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName17, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 12:
                                    Pair<String, String> pair20 = (Pair) this.L$6;
                                    AnkiSourceDeck sourceDeck7 = (AnkiSourceDeck) this.L$5;
                                    AnkiNoteEntity savedNote15 = (AnkiNoteEntity) this.L$4;
                                    AnkiModel model23 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current24 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note27 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    pair3 = pair20;
                                    savedNote7 = savedNote15;
                                    model11 = model23;
                                    current9 = current24;
                                    note12 = note27;
                                    objDeckSource = $result;
                                    sourceDeck3 = sourceDeck7;
                                    ankiDeckSourceEntity = (AnkiDeckSourceEntity) objDeckSource;
                                    if (ankiDeckSourceEntity != null) {
                                        localDeckId = ankiDeckSourceEntity.getLocalDeckId();
                                    } else {
                                        localDeckId = null;
                                    }
                                    if (localDeckId == null) {
                                        CoroutineScope coroutineScope18 = this.$$this$withContext;
                                        ankiImportService5 = this.this$0;
                                        j = this.$now;
                                        intRef = this.$decks;
                                        coroutineScope = coroutineScope18;
/* 70 */                                XunjiDao xunjiDaoDao18 = ankiImportService5.db.dao();
                                        this.L$0 = sourceCard;
                                        current10 = current9;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note12);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                        this.L$3 = model11;
                                        this.L$4 = savedNote7;
                                        this.L$5 = sourceDeck3;
                                        this.L$6 = pair3;
                                        this.L$7 = ankiImportService5;
                                        this.L$8 = intRef;
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                        this.J$0 = j;
                                        this.I$0 = 0;
                                        this.label = 13;
                                        objDecks = xunjiDaoDao18.decks(this);
                                        if (objDecks == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 273 */                               note13 = note12;
                                        ankiImportService6 = ankiImportService5;
                                        i = 0;
                                        sourceDeck4 = sourceDeck3;
                                        AnkiNoteEntity ankiNoteEntity11112 = savedNote7;
                                        intRef2 = intRef;
                                        j2 = j;
                                        savedNote8 = ankiNoteEntity11112;
                                        model12 = model11;
                                        pair4 = pair3;
/* 239 */                               Iterable iterable1116 = (Iterable) objDecks;
                                        savedNote9 = savedNote8;
                                        model13 = model12;
/* 351 */                               arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable1116, 10));
                                        iterable2 = iterable1116;
/* 352 */                               it2 = iterable2.iterator();
                                        while (it2.hasNext()) {
/* 353 */                                   arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                                   iterable2 = iterable2;
                                        }
/* 273 */                               set = CollectionsKt.toSet((List) arrayList);
/* 274 */                               fullName = sourceDeck4.getFullName();
/* 275 */                               if (set.contains(fullName)) {
                                            str4 = fullName;
                                            str3 = str4;
                                        } else {
/* 355 */                                   it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj1114) {
                                                    return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj1114).intValue());
                                                }
                                            }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj1114) {
                                                    return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj1114).intValue());
                                                }
                                            }).iterator();
                                            while (true) {
                                                if (it3.hasNext()) {
                                                    throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                                }
                                                next = it3.next();
                                                str3 = fullName;
/* 355 */                                       if (set.contains((String) next)) {
/* 356 */                                           str4 = (String) next;
                                                } else {
/* 355 */                                           long j19 = j2;
                                                    Object obj1114 = coroutine_suspended;
                                                    AnkiModel model1114 = model13;
                                                    model13 = model1114;
                                                    coroutine_suspended = obj1114;
                                                    j2 = j19;
                                                    set = set;
                                                    savedNote9 = savedNote9;
                                                    str6 = str6;
                                                    fullName = str3;
                                                }
                                            }
                                        }
/* 278 */                               string = UUID.randomUUID().toString();
                                        Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                                xunjiDaoDao = ankiImportService6.db.dao();
                                        set2 = set;
                                        Object obj1115 = coroutine_suspended;
                                        model14 = model13;
                                        str2 = str6;
                                        savedNote10 = savedNote9;
                                        deckEntity = new DeckEntity(string, str4, j2, j2);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                        this.L$3 = model14;
                                        this.L$4 = savedNote10;
                                        this.L$5 = sourceDeck4;
                                        this.L$6 = pair4;
                                        this.L$7 = ankiImportService6;
                                        this.L$8 = intRef2;
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                        this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                        this.L$12 = string;
                                        this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                        this.I$0 = i;
                                        this.label = 14;
                                        obj = obj1115;
                                        if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                                   return obj;
                                        }
/* 279 */                               ankiImportService7 = ankiImportService6;
                                        current11 = current10;
                                        set3 = set2;
                                        str5 = str3;
                                        model10 = model14;
                                        i2 = i;
                                        note14 = note13;
/* 70 */                                ankiDao = ankiImportService7.dao;
                                        note15 = note14;
                                        ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                        this.L$0 = sourceCard;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote10;
                                        this.L$5 = sourceDeck4;
                                        this.L$6 = pair4;
                                        this.L$7 = intRef2;
                                        this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                        this.L$11 = string;
                                        this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                        this.L$13 = null;
                                        this.I$0 = i2;
                                        this.label = 15;
                                        if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                                   return obj;
                                        }
/* 281 */                               intRef2.element++;
/* 283 */                               this.$localDecks.put(pair4, string);
                                        str = string;
                                        coroutine_suspended = obj;
                                        current5 = current11;
                                        pair2 = pair4;
                                        sourceDeck2 = sourceDeck4;
                                        note11 = note15;
                                        savedNote6 = savedNote10;
                                    } else {
                                        str2 = "toString(...)";
                                        AnkiNoteEntity current1110 = current9;
                                        str = localDeckId;
                                        savedNote6 = savedNote7;
                                        note11 = note12;
                                        current5 = current1110;
                                        pair2 = pair3;
                                        model10 = model11;
                                        sourceDeck2 = sourceDeck3;
                                    }
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable1117 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable1117, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i111 = iCoerceAtLeast;
                                            Pair pair114 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair114.getFirst(), pair114.getSecond());
                                            iCoerceAtLeast = i111;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName18 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName18, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 13:
                                    i = this.I$0;
                                    long j20 = this.J$0;
                                    CoroutineScope coroutineScope19 = (CoroutineScope) this.L$9;
                                    Ref.IntRef intRef3 = (Ref.IntRef) this.L$8;
                                    AnkiImportService ankiImportService9 = (AnkiImportService) this.L$7;
                                    Pair<String, String> pair21 = (Pair) this.L$6;
                                    AnkiSourceDeck sourceDeck8 = (AnkiSourceDeck) this.L$5;
                                    AnkiNoteEntity savedNote16 = (AnkiNoteEntity) this.L$4;
                                    AnkiModel model24 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current25 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note28 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    coroutineScope = coroutineScope19;
                                    current10 = current25;
                                    note13 = note28;
                                    objDecks = $result;
                                    ankiImportService6 = ankiImportService9;
                                    sourceDeck4 = sourceDeck8;
                                    intRef2 = intRef3;
                                    j2 = j20;
                                    savedNote8 = savedNote16;
                                    model12 = model24;
                                    pair4 = pair21;
/* 239 */                           Iterable iterable1118 = (Iterable) objDecks;
                                    savedNote9 = savedNote8;
                                    model13 = model12;
/* 351 */                           arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable1118, 10));
                                    iterable2 = iterable1118;
/* 352 */                           it2 = iterable2.iterator();
                                    while (it2.hasNext()) {
/* 353 */                               arrayList.add(((DeckEntity) it2.next()).getName());
/* 273 */                               iterable2 = iterable2;
                                    }
/* 273 */                           set = CollectionsKt.toSet((List) arrayList);
/* 274 */                           fullName = sourceDeck4.getFullName();
/* 275 */                           if (set.contains(fullName)) {
                                        str4 = fullName;
                                        str3 = str4;
                                    } else {
/* 355 */                               it3 = SequencesKt.map(SequencesKt.generateSequence(Boxing.boxInt(1), (Function1<? super Integer, ? extends Integer>) new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda0
                                            @Override // kotlin.jvm.functions.Function1
                                            public final Object invoke(Object obj1116) {
                                                return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$1(((Integer) obj1116).intValue());
                                            }
                                        }), new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$$ExternalSyntheticLambda1
                                            @Override // kotlin.jvm.functions.Function1
                                            public final Object invoke(Object obj1116) {
                                                return AnkiImportService$commitLocked$5$1$result$1.AnonymousClass1.AnonymousClass3.invokeSuspend$lambda$4$2(fullName, ((Integer) obj1116).intValue());
                                            }
                                        }).iterator();
                                        while (true) {
                                            if (it3.hasNext()) {
                                                throw new NoSuchElementException("Sequence contains no element matching the predicate.");
                                            }
                                            next = it3.next();
                                            str3 = fullName;
/* 355 */                                   if (set.contains((String) next)) {
/* 356 */                                       str4 = (String) next;
                                            } else {
/* 355 */                                       long j110 = j2;
                                                Object obj1116 = coroutine_suspended;
                                                AnkiModel model1115 = model13;
                                                model13 = model1115;
                                                coroutine_suspended = obj1116;
                                                j2 = j110;
                                                set = set;
                                                savedNote9 = savedNote9;
                                                str6 = str6;
                                                fullName = str3;
                                            }
                                        }
                                    }
/* 278 */                           string = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(string, str6);
/* 70 */                            xunjiDaoDao = ankiImportService6.db.dao();
                                    set2 = set;
                                    Object obj1117 = coroutine_suspended;
                                    model14 = model13;
                                    str2 = str6;
                                    savedNote10 = savedNote9;
                                    deckEntity = new DeckEntity(string, str4, j2, j2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note13);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current10);
                                    this.L$3 = model14;
                                    this.L$4 = savedNote10;
                                    this.L$5 = sourceDeck4;
                                    this.L$6 = pair4;
                                    this.L$7 = ankiImportService6;
                                    this.L$8 = intRef2;
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(str3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(str4);
                                    this.L$12 = string;
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(set2);
                                    this.I$0 = i;
                                    this.label = 14;
                                    obj = obj1117;
                                    if (xunjiDaoDao.insertDeck(deckEntity, this) == obj) {
/* 239 */                               return obj;
                                    }
/* 279 */                           ankiImportService7 = ankiImportService6;
                                    current11 = current10;
                                    set3 = set2;
                                    str5 = str3;
                                    model10 = model14;
                                    i2 = i;
                                    note14 = note13;
/* 70 */                            ankiDao = ankiImportService7.dao;
                                    note15 = note14;
                                    ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                    this.L$3 = model10;
                                    this.L$4 = savedNote10;
                                    this.L$5 = sourceDeck4;
                                    this.L$6 = pair4;
                                    this.L$7 = intRef2;
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                    this.L$11 = string;
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                    this.L$13 = null;
                                    this.I$0 = i2;
                                    this.label = 15;
                                    if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                               return obj;
                                    }
/* 281 */                           intRef2.element++;
/* 283 */                           this.$localDecks.put(pair4, string);
                                    str = string;
                                    coroutine_suspended = obj;
                                    current5 = current11;
                                    pair2 = pair4;
                                    sourceDeck2 = sourceDeck4;
                                    note11 = note15;
                                    savedNote6 = savedNote10;
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable1119 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable1119, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i112 = iCoerceAtLeast;
                                            Pair pair115 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair115.getFirst(), pair115.getSecond());
                                            iCoerceAtLeast = i112;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName19 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName19, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 14:
                                    int i20 = this.I$0;
                                    set3 = (Set) this.L$13;
                                    string = (String) this.L$12;
                                    str4 = (String) this.L$11;
                                    String str7 = (String) this.L$10;
                                    CoroutineScope coroutineScope20 = (CoroutineScope) this.L$9;
                                    Ref.IntRef intRef4 = (Ref.IntRef) this.L$8;
                                    ankiImportService7 = (AnkiImportService) this.L$7;
                                    Pair<String, String> pair22 = (Pair) this.L$6;
                                    AnkiSourceDeck sourceDeck9 = (AnkiSourceDeck) this.L$5;
                                    AnkiNoteEntity savedNote17 = (AnkiNoteEntity) this.L$4;
                                    model10 = (AnkiModel) this.L$3;
                                    AnkiNoteEntity current26 = (AnkiNoteEntity) this.L$2;
                                    note14 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    str2 = "toString(...)";
                                    savedNote10 = savedNote17;
                                    sourceDeck4 = sourceDeck9;
                                    pair4 = pair22;
                                    intRef2 = intRef4;
                                    current11 = current26;
                                    coroutineScope = coroutineScope20;
                                    str5 = str7;
                                    obj = coroutine_suspended;
                                    i2 = i20;
/* 70 */                            ankiDao = ankiImportService7.dao;
                                    note15 = note14;
                                    ankiDeckSourceEntity2 = new AnkiDeckSourceEntity(pair4.getFirst(), pair4.getSecond(), string);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note15);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current11);
                                    this.L$3 = model10;
                                    this.L$4 = savedNote10;
                                    this.L$5 = sourceDeck4;
                                    this.L$6 = pair4;
                                    this.L$7 = intRef2;
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(coroutineScope);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(str5);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(str4);
                                    this.L$11 = string;
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(set3);
                                    this.L$13 = null;
                                    this.I$0 = i2;
                                    this.label = 15;
                                    if (ankiDao.insertDeckSource(ankiDeckSourceEntity2, this) == obj) {
/* 239 */                               return obj;
                                    }
/* 281 */                           intRef2.element++;
/* 283 */                           this.$localDecks.put(pair4, string);
                                    str = string;
                                    coroutine_suspended = obj;
                                    current5 = current11;
                                    pair2 = pair4;
                                    sourceDeck2 = sourceDeck4;
                                    note11 = note15;
                                    savedNote6 = savedNote10;
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable11110 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable11110, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i113 = iCoerceAtLeast;
                                            Pair pair116 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair116.getFirst(), pair116.getSecond());
                                            iCoerceAtLeast = i113;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName110 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName110, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 15:
                                    int i21 = this.I$0;
                                    string = (String) this.L$11;
                                    intRef2 = (Ref.IntRef) this.L$7;
                                    pair4 = (Pair) this.L$6;
                                    sourceDeck4 = (AnkiSourceDeck) this.L$5;
                                    AnkiNoteEntity savedNote18 = (AnkiNoteEntity) this.L$4;
                                    AnkiModel model25 = (AnkiModel) this.L$3;
                                    current11 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note29 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    note15 = note29;
                                    str2 = "toString(...)";
                                    savedNote10 = savedNote18;
                                    model10 = model25;
                                    obj = coroutine_suspended;
/* 281 */                           intRef2.element++;
/* 283 */                           this.$localDecks.put(pair4, string);
                                    str = string;
                                    coroutine_suspended = obj;
                                    current5 = current11;
                                    pair2 = pair4;
                                    sourceDeck2 = sourceDeck4;
                                    note11 = note15;
                                    savedNote6 = savedNote10;
                                    deckId = str;
/* 284 */                           listStrings = AnkiRepository.INSTANCE.strings(savedNote6.getFields());
/* 285 */                           listStrings2 = AnkiRepository.INSTANCE.strings(savedNote6.getTags());
/* 286 */                           if (Intrinsics.areEqual(this.$cachedMediaNamespace.element, savedNote6.getMediaNamespace())) {
/* 287 */                               objectRef = this.$cachedMediaMimes;
                                        this.L$0 = sourceCard;
                                        note17 = note11;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(note17);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(current5);
                                        this.L$3 = model10;
                                        this.L$4 = savedNote6;
                                        this.L$5 = sourceDeck2;
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(pair2);
                                        this.L$7 = deckId;
                                        this.L$8 = listStrings;
                                        this.L$9 = listStrings2;
                                        this.L$10 = objectRef;
                                        this.L$11 = null;
                                        this.L$12 = null;
                                        this.label = 16;
/* 70 */                                objMedia2 = this.this$0.dao.media(savedNote6.getMediaNamespace(), this);
                                        if (objMedia2 == coroutine_suspended) {
/* 239 */                                   return coroutine_suspended;
                                        }
/* 287 */                               note18 = note17;
/* 239 */                               Iterable<AnkiMediaEntity> iterable11111 = (Iterable) objMedia2;
/* 357 */                               iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable11111, 10)), 16);
/* 358 */                               linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                        while (r22.hasNext()) {
/* 287 */                                   int i114 = iCoerceAtLeast;
                                            Pair pair117 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                                   linkedHashMap.put(pair117.getFirst(), pair117.getSecond());
                                            iCoerceAtLeast = i114;
                                            note18 = note18;
                                        }
/* 287 */                               objectRef.element = linkedHashMap;
/* 288 */                               this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                        note16 = note18;
                                        list2 = listStrings;
                                        current12 = current5;
                                        list3 = listStrings2;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    } else {
/* 286 */                               note16 = note11;
                                        list2 = listStrings;
                                        current12 = current5;
                                        deckId2 = deckId;
                                        model15 = model10;
                                        list3 = listStrings2;
                                        sourceDeck5 = sourceDeck2;
                                        savedNote11 = savedNote6;
                                        pair5 = pair2;
                                    }
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName111 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName111, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 16:
                                    objectRef = (Ref.ObjectRef) this.L$10;
                                    listStrings2 = (List) this.L$9;
                                    listStrings = (List) this.L$8;
                                    deckId = (String) this.L$7;
                                    pair2 = (Pair) this.L$6;
                                    sourceDeck2 = (AnkiSourceDeck) this.L$5;
                                    savedNote6 = (AnkiNoteEntity) this.L$4;
                                    model10 = (AnkiModel) this.L$3;
                                    current5 = (AnkiNoteEntity) this.L$2;
                                    note18 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    str2 = "toString(...)";
                                    objMedia2 = $result;
/* 239 */                           Iterable<AnkiMediaEntity> iterable11112 = (Iterable) objMedia2;
/* 357 */                           iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable11112, 10)), 16);
/* 358 */                           linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                    while (r22.hasNext()) {
/* 287 */                               int i115 = iCoerceAtLeast;
                                        Pair pair118 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 360 */                               linkedHashMap.put(pair118.getFirst(), pair118.getSecond());
                                        iCoerceAtLeast = i115;
                                        note18 = note18;
                                    }
/* 287 */                           objectRef.element = linkedHashMap;
/* 288 */                           this.$cachedMediaNamespace.element = savedNote6.getMediaNamespace();
                                    note16 = note18;
                                    list2 = listStrings;
                                    current12 = current5;
                                    list3 = listStrings2;
                                    deckId2 = deckId;
                                    model15 = model10;
                                    sourceDeck5 = sourceDeck2;
                                    savedNote11 = savedNote6;
                                    pair5 = pair2;
/* 290 */                           templates = model15.getTemplates();
                                    i3 = 0;
/* 363 */                           it4 = templates.iterator();
                                    while (true) {
                                        if (it4.hasNext()) {
                                            next2 = it4.next();
/* 290 */                                   note19 = note16;
                                            ordinal = ((AnkiTemplate) next2).getOrdinal();
                                            iterable3 = templates;
                                            i4 = i3;
                                            if (model15.getKind() == 1) {
                                                ordinal2 = 0;
                                            } else {
                                                ordinal2 = sourceCard.getOrdinal();
                                            }
                                            if (ordinal == ordinal2) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
/* 363 */                                   if (!z6) {
                                                note16 = note19;
                                                templates = iterable3;
                                                i3 = i4;
                                            }
                                        } else {
/* 364 */                                   note19 = note16;
                                            next2 = null;
                                        }
                                    }
/* 290 */                           template = (AnkiTemplate) next2;
                                    String fullName112 = sourceDeck5.getFullName();
                                    if (template != null) {
                                        name = template.getName();
                                    } else {
                                        name = null;
                                    }
                                    if (name == null) {
                                        name = "";
                                    }
/* 291 */                           context = new TemplateContext(fullName112, name, list3, model15.getName(), this.$cachedMediaMimes.element.keySet());
                                    model16 = model15;
                                    savedNote12 = savedNote11;
/* 70 */                            question = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.QUESTION, context);
/* 70 */                            answer = this.this$0.renderer.render(model16, list2, sourceCard.getOrdinal(), CardSide.ANSWER, context);
/* 294 */                           if (question.getIssues().isEmpty()) {
                                        z4 = false;
                                    } else {
                                        z4 = false;
                                    }
                                    if (!z4) {
                                        throw new IllegalArgumentException("Card compatibility changed; repeat import preflight".toString());
                                    }
/* 295 */                           if (AnkiMediaValidator.INSTANCE.issues(question, new AnonymousClass7(this.$cachedMediaMimes.element)).isEmpty()) {
                                        z5 = false;
                                    } else {
                                        z5 = false;
                                    }
                                    if (!z5) {
                                        throw new IllegalArgumentException("Card media compatibility changed; repeat import preflight".toString());
                                    }
/* 296 */                           id = UUID.randomUUID().toString();
                                    Intrinsics.checkNotNullExpressionValue(id, str2);
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note19);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current12);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model16);
                                    this.L$4 = savedNote12;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck5);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair5);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId2);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list2);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list3);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer);
                                    this.L$14 = id;
                                    this.label = 17;
/* 70 */                            if (this.this$0.db.dao().insertCard(new CardEntity(id, deckId2, this.this$0.summary(question), this.this$0.summary(answer), "", this.$now, this.$now), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 297 */                           id2 = id;
                                    list4 = list3;
                                    context2 = context;
                                    pair6 = pair5;
                                    sourceDeck6 = sourceDeck5;
                                    question2 = question;
                                    current13 = current12;
                                    template2 = template;
                                    savedNote13 = savedNote12;
                                    model17 = model16;
                                    list5 = list2;
                                    note20 = note19;
                                    answer2 = answer;
                                    deckId3 = deckId2;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 17:
                                    String id4 = (String) this.L$14;
                                    answer2 = (RenderedSide) this.L$13;
                                    question2 = (RenderedSide) this.L$12;
                                    context2 = (TemplateContext) this.L$11;
                                    template2 = (AnkiTemplate) this.L$10;
                                    list4 = (List) this.L$9;
                                    list5 = (List) this.L$8;
                                    deckId3 = (String) this.L$7;
                                    pair6 = (Pair) this.L$6;
                                    sourceDeck6 = (AnkiSourceDeck) this.L$5;
                                    savedNote13 = (AnkiNoteEntity) this.L$4;
                                    model17 = (AnkiModel) this.L$3;
                                    current13 = (AnkiNoteEntity) this.L$2;
                                    note20 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    id2 = id4;
/* 298 */                           note21 = note20;
                                    answer3 = answer2;
                                    question3 = question2;
                                    context3 = context2;
                                    id3 = id2;
                                    this.L$0 = sourceCard;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note21);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = savedNote13;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair6);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId3);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list5);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list4);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template2);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(question3);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer3);
                                    this.L$14 = id3;
                                    this.label = 18;
/* 70 */                            if (this.this$0.db.dao().putSchedule(new ScheduleEntity(id2, "NEW", null, null, null, this.$now, null, null, 0L), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 298 */                           template3 = template2;
                                    list6 = list4;
                                    list7 = list5;
                                    deckId4 = deckId3;
                                    pair7 = pair6;
                                    note22 = note21;
                                    answer4 = answer3;
                                    answer5 = question3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 18:
                                    String id5 = (String) this.L$14;
                                    RenderedSide answer6 = (RenderedSide) this.L$13;
                                    RenderedSide question4 = (RenderedSide) this.L$12;
                                    TemplateContext context4 = (TemplateContext) this.L$11;
                                    AnkiTemplate template4 = (AnkiTemplate) this.L$10;
                                    List<String> list9 = (List) this.L$9;
                                    List<String> list10 = (List) this.L$8;
                                    String deckId5 = (String) this.L$7;
                                    Pair<String, String> pair23 = (Pair) this.L$6;
                                    sourceDeck6 = (AnkiSourceDeck) this.L$5;
                                    savedNote13 = (AnkiNoteEntity) this.L$4;
                                    model17 = (AnkiModel) this.L$3;
                                    current13 = (AnkiNoteEntity) this.L$2;
                                    AnkiSourceNote note30 = (AnkiSourceNote) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    context3 = context4;
                                    template3 = template4;
                                    list6 = list9;
                                    list7 = list10;
                                    deckId4 = deckId5;
                                    pair7 = pair23;
                                    note22 = note30;
                                    answer4 = answer6;
                                    answer5 = question4;
                                    id3 = id5;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(sourceCard);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note22);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(current13);
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(model17);
                                    this.L$4 = SpillingKt.nullOutSpilledVariable(savedNote13);
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(sourceDeck6);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(pair7);
                                    this.L$7 = SpillingKt.nullOutSpilledVariable(deckId4);
                                    this.L$8 = SpillingKt.nullOutSpilledVariable(list7);
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(list6);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(template3);
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(context3);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(answer5);
                                    this.L$13 = SpillingKt.nullOutSpilledVariable(answer4);
                                    this.L$14 = SpillingKt.nullOutSpilledVariable(id3);
                                    this.label = 19;
/* 70 */                            if (this.this$0.dao.insertLink(new AnkiCardEntity(id3, savedNote13.getId(), sourceCard.getOrdinal()), this) == coroutine_suspended) {
/* 239 */                               return coroutine_suspended;
                                    }
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                case 19:
                                    ResultKt.throwOnFailure($result);
/* 300 */                           this.$added.element++;
/* 301 */                           return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }

                        /* JADX INFO: Access modifiers changed from: private */
/* 274 */               public static final Integer invokeSuspend$lambda$4$1(int it) {
/* 275 */                   return Integer.valueOf(it + 1);
                        }

                        /* JADX INFO: Access modifiers changed from: private */
/* 275 */               public static final String invokeSuspend$lambda$4$2(String $base, int it) {
                            return $base + " (Anki" + (it != 1 ? " " + it + ")" : ")");
                        }

                        /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$7, reason: invalid class name */
                        /* JADX INFO: compiled from: AnkiImportService.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 293 */               static final /* synthetic */ class AnonymousClass7 extends FunctionReferenceImpl implements Function1<String, String> {
                            AnonymousClass7(Object obj) {
                                super(1, obj, Map.class, "get", "get(Ljava/lang/Object;)Ljava/lang/Object;", 0);
                            }

                            @Override // kotlin.jvm.functions.Function1
/* 294 */                   public final String invoke(String p0) {
                                Intrinsics.checkNotNullParameter(p0, "p0");
/* 295 */                       return (String) ((Map) this.receiver).get(p0);
                            }
                        }

                        /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1$result$1$1$3$8, reason: invalid class name */
                        /* JADX INFO: compiled from: AnkiImportService.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 293 */               static final /* synthetic */ class AnonymousClass8 extends FunctionReferenceImpl implements Function1<String, String> {
                            AnonymousClass8(Object obj) {
                                super(1, obj, Map.class, "get", "get(Ljava/lang/Object;)Ljava/lang/Object;", 0);
                            }

                            @Override // kotlin.jvm.functions.Function1
/* 294 */                   public final String invoke(String p0) {
                                Intrinsics.checkNotNullParameter(p0, "p0");
/* 295 */                       return (String) ((Map) this.receiver).get(p0);
                            }
                        }
                    }
                }

                /* JADX WARN: Type inference failed for: r2v4, types: [T, com.xunji.flashcards.anki.ImportResult] */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 221 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    Object objWithTransaction;
                    CoroutineScope $this$withContext = (CoroutineScope) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                            this.label = 1;
/* 70 */                    objWithTransaction = RoomDatabaseKt.withTransaction(this.this$0.db, new AnonymousClass1(this.$prepared, this.$selectedCards, this.$duplicateCount, this.this$0, this.$caller, this.$skipped, this.$reasons, this.$selectedGuids, this.$staged, $this$withContext, null), this);
                            if (objWithTransaction == coroutine_suspended) {
/* 222 */                       return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            objWithTransaction = $result;
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 304 */           this.$completed.element = (ImportResult) objWithTransaction;
                    return objWithTransaction;
                }
            }

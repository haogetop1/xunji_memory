            package com.xunji.flashcards.anki;

            import java.io.File;
            import java.io.IOException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.FilesKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$initialize$2$1", f = "AnkiImportService.kt", i = {}, l = {85}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 81 */    final class AnkiImportService$initialize$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                int label;
                final /* synthetic */ AnkiImportService this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnkiImportService$initialize$2$1(AnkiImportService ankiImportService, Continuation<? super AnkiImportService$initialize$2$1> continuation) {
                    super(2, continuation);
                    this.this$0 = ankiImportService;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new AnkiImportService$initialize$2$1(this.this$0, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((AnkiImportService$initialize$2$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Code duplicated, block: B:21:0x0060  */
                /* JADX WARN: Code duplicated, block: B:23:0x0065  */
                /* JADX WARN: Code duplicated, block: B:25:0x0072 A[LOOP:0: B:22:0x0063->B:25:0x0072, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:33:0x0075 A[SYNTHETIC] */
                /* JADX WARN: Instruction removed from duplicated block: B:21:0x0060, please report this as an issue */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 82 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    File[] fileArrListFiles;
                    int i;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 70 */                    if (!this.this$0.initialized) {
                                this.label = 1;
/* 70 */                        if (this.this$0.media.initialize(this) == coroutine_suspended) {
/* 83 */                            return coroutine_suspended;
                                }
/* 70 */                        if (this.this$0.stagingRoot.isDirectory() && !this.this$0.stagingRoot.mkdirs()) {
                                    throw new IOException("Cannot create import staging directory");
                                }
/* 70 */                        fileArrListFiles = this.this$0.stagingRoot.listFiles();
                                if (fileArrListFiles != null) {
                                    for (File file : fileArrListFiles) {
/* 87 */                                Intrinsics.checkNotNull(file);
                                        if (FilesKt.deleteRecursively(file)) {
/* 87 */                                    throw new IOException("Cannot clean abandoned import preview");
                                        }
                                    }
                                }
/* 70 */                        this.this$0.initialized = true;
                            }
/* 90 */                    return Unit.INSTANCE;
                        case 1:
                            ResultKt.throwOnFailure($result);
/* 70 */                    if (this.this$0.stagingRoot.isDirectory()) {
                                break;
                            }
/* 70 */                    fileArrListFiles = this.this$0.stagingRoot.listFiles();
                            if (fileArrListFiles != null) {
                                while (i < r3) {
/* 87 */                            Intrinsics.checkNotNull(file);
                                    if (FilesKt.deleteRecursively(file)) {
/* 87 */                                throw new IOException("Cannot clean abandoned import preview");
                                    }
                                }
                            }
/* 70 */                    this.this$0.initialized = true;
/* 90 */                    return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

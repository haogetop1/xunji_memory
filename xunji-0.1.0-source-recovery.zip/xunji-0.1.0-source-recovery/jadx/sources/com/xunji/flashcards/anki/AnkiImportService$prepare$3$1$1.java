            package com.xunji.flashcards.anki;

            import androidx.compose.material.TextFieldImplKt;
            import androidx.core.app.NotificationCompat;
            import com.xunji.core.anki.AnkiMediaValidator;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiSourceCard;
            import com.xunji.core.anki.AnkiSourceDeck;
            import com.xunji.core.anki.AnkiSourceNote;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.anki.CardSide;
            import com.xunji.core.anki.ImportIssue;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.core.anki.ImportStage;
            import com.xunji.core.anki.RenderIssue;
            import com.xunji.core.anki.RenderedSide;
            import com.xunji.core.anki.TemplateContext;
            import com.xunji.flashcards.data.AnkiCardEntity;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.AnkiModelEntity;
            import com.xunji.flashcards.data.AnkiNoteEntity;
            import com.xunji.flashcards.data.AnkiRepository;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.HashMap;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.ranges.RangesKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.JobKt;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "card", "Lcom/xunji/core/anki/AnkiSourceCard;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$prepare$3$1$1", f = "AnkiImportService.kt", i = {0, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5}, l = {129, 131, 133, 143, TextFieldImplKt.AnimationDuration, 152}, m = "invokeSuspend", n = {"card", "card", "note", "guid", "card", "note", "guid", "model", "deck", "card", "note", "guid", "model", "deck", "local", "issues", NotificationCompat.CATEGORY_STATUS, "actualModel", "fields", "tags", "mediaMimes", "card", "note", "guid", "model", "deck", "local", "issues", NotificationCompat.CATEGORY_STATUS, "actualModel", "fields", "tags", "mediaMimes", "savedModel", "card", "note", "guid", "model", "deck", "local", "issues", NotificationCompat.CATEGORY_STATUS, "actualModel", "fields", "tags", "mediaMimes", "savedModel"}, s = {"L$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "L$12"}, v = 1)
/* 125 */   final class AnkiImportService$prepare$3$1$1 extends SuspendLambda implements Function2<AnkiSourceCard, Continuation<? super Unit>, Object> {
                final /* synthetic */ CoroutineScope $$this$withContext;
                final /* synthetic */ ArrayList<ImportPreviewCard> $cards;
                final /* synthetic */ HashMap<String, String> $guids;
                final /* synthetic */ HashMap<Pair<String, String>, Pair<String, String>> $issueText;
                final /* synthetic */ Function1<ImportProgress, Unit> $onProgress;
                final /* synthetic */ Map<String, String> $retainedMimes;
                final /* synthetic */ LinkedHashMap<String, Long> $revisions;
                final /* synthetic */ PreparedPackage $source;
                final /* synthetic */ Map<Long, List<ImportIssue>> $sourceIssues;
                /* synthetic */ Object L$0;
                Object L$1;
                Object L$10;
                Object L$11;
                Object L$12;
                Object L$2;
                Object L$3;
                Object L$4;
                Object L$5;
                Object L$6;
                Object L$7;
                Object L$8;
                Object L$9;
                int label;
                final /* synthetic */ AnkiImportService this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                AnkiImportService$prepare$3$1$1(CoroutineScope coroutineScope, PreparedPackage preparedPackage, HashMap<String, String> map, AnkiImportService ankiImportService, LinkedHashMap<String, Long> linkedHashMap, Map<Long, ? extends List<ImportIssue>> map2, Map<String, String> map3, ArrayList<ImportPreviewCard> arrayList, Function1<? super ImportProgress, Unit> function1, HashMap<Pair<String, String>, Pair<String, String>> map4, Continuation<? super AnkiImportService$prepare$3$1$1> continuation) {
                    super(2, continuation);
                    this.$$this$withContext = coroutineScope;
                    this.$source = preparedPackage;
                    this.$guids = map;
                    this.this$0 = ankiImportService;
                    this.$revisions = linkedHashMap;
                    this.$sourceIssues = map2;
                    this.$retainedMimes = map3;
                    this.$cards = arrayList;
                    this.$onProgress = function1;
                    this.$issueText = map4;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    AnkiImportService$prepare$3$1$1 ankiImportService$prepare$3$1$1 = new AnkiImportService$prepare$3$1$1(this.$$this$withContext, this.$source, this.$guids, this.this$0, this.$revisions, this.$sourceIssues, this.$retainedMimes, this.$cards, this.$onProgress, this.$issueText, continuation);
                    ankiImportService$prepare$3$1$1.L$0 = obj;
                    return ankiImportService$prepare$3$1$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(AnkiSourceCard ankiSourceCard, Continuation<? super Unit> continuation) {
                    return ((AnkiImportService$prepare$3$1$1) create(ankiSourceCard, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Code duplicated, block: B:130:0x058a  */
                /* JADX WARN: Code duplicated, block: B:133:0x0596  */
                /* JADX WARN: Code duplicated, block: B:136:0x05a3  */
                /* JADX WARN: Code duplicated, block: B:139:0x05b4  */
                /* JADX WARN: Code duplicated, block: B:140:0x05bb  */
                /* JADX WARN: Code duplicated, block: B:142:0x05bf  */
                /* JADX WARN: Code duplicated, block: B:143:0x05c2  */
                /* JADX WARN: Code duplicated, block: B:150:0x0412 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:151:0x040b A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:153:0x0200 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:154:0x01fb A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:17:0x0135  */
                /* JADX WARN: Code duplicated, block: B:18:0x0140  */
                /* JADX WARN: Code duplicated, block: B:21:0x015d A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:22:0x015e  */
                /* JADX WARN: Code duplicated, block: B:25:0x0193 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:26:0x0194  */
                /* JADX WARN: Code duplicated, block: B:29:0x019f  */
                /* JADX WARN: Code duplicated, block: B:30:0x01a8  */
                /* JADX WARN: Code duplicated, block: B:33:0x01be  */
                /* JADX WARN: Code duplicated, block: B:36:0x01ca  */
                /* JADX WARN: Code duplicated, block: B:38:0x01d4  */
                /* JADX WARN: Code duplicated, block: B:41:0x01de  */
                /* JADX WARN: Code duplicated, block: B:44:0x01e8  */
                /* JADX WARN: Code duplicated, block: B:47:0x01fe A[LOOP:5: B:42:0x01e2->B:47:0x01fe, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:50:0x0203  */
                /* JADX WARN: Code duplicated, block: B:53:0x022d  */
                /* JADX WARN: Code duplicated, block: B:55:0x0263 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:56:0x0264  */
                /* JADX WARN: Code duplicated, block: B:58:0x0271  */
                /* JADX WARN: Code duplicated, block: B:60:0x027b  */
                /* JADX WARN: Code duplicated, block: B:61:0x02aa  */
                /* JADX WARN: Code duplicated, block: B:63:0x0310 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:64:0x0311  */
                /* JADX WARN: Code duplicated, block: B:68:0x0346 A[LOOP:4: B:66:0x0340->B:68:0x0346, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:72:0x03c8 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:73:0x03c9  */
                /* JADX WARN: Code duplicated, block: B:76:0x03d5  */
                /* JADX WARN: Code duplicated, block: B:79:0x03e3  */
                /* JADX WARN: Code duplicated, block: B:82:0x03ed  */
                /* JADX WARN: Code duplicated, block: B:84:0x0405  */
                /* JADX WARN: Code duplicated, block: B:85:0x0407  */
                /* JADX WARN: Code duplicated, block: B:88:0x040d A[LOOP:3: B:80:0x03e7->B:88:0x040d, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:91:0x041a  */
                /* JADX WARN: Code duplicated, block: B:92:0x042c  */
                /* JADX WARN: Code duplicated, block: B:93:0x043d  */
                /* JADX WARN: Code duplicated, block: B:95:0x044b  */
                /* JADX WARN: Code duplicated, block: B:98:0x045e  */
                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Type inference failed for: r14v12 */
                /* JADX WARN: Type inference failed for: r14v22 */
                /* JADX WARN: Type inference failed for: r14v7 */
                /* JADX WARN: Type inference failed for: r15v15 */
                /* JADX WARN: Type inference failed for: r15v18 */
                /* JADX WARN: Type inference failed for: r15v19 */
                /* JADX WARN: Type inference failed for: r15v5 */
                /* JADX WARN: Type inference failed for: r15v7, types: [java.lang.Object] */
                /* JADX WARN: Type inference failed for: r15v9 */
                /* JADX WARN: Type inference failed for: r23v0, types: [java.lang.Object] */
                /* JADX WARN: Type inference failed for: r23v1 */
                /* JADX WARN: Type inference failed for: r32v0 */
                /* JADX WARN: Type inference failed for: r32v1 */
                /* JADX WARN: Type inference failed for: r32v2 */
                /* JADX WARN: Type inference failed for: r4v15, types: [T, com.xunji.core.anki.AnkiModel] */
                /* JADX WARN: Type inference failed for: r4v34 */
                /* JADX WARN: Type inference failed for: r4v37 */
                /* JADX WARN: Type inference failed for: r4v55 */
                /* JADX WARN: Type inference failed for: r4v58 */
                /* JADX WARN: Type inference failed for: r4v59 */
                /* JADX WARN: Type inference failed for: r4v60 */
                /* JADX WARN: Type inference failed for: r4v61 */
                /* JADX WARN: Type inference failed for: r4v62 */
                /* JADX WARN: Type inference failed for: r4v63 */
                /* JADX WARN: Type inference failed for: r4v9, types: [T, java.lang.Object] */
                /* JADX WARN: Type inference failed for: r6v11 */
                /* JADX WARN: Type inference failed for: r6v14, types: [com.xunji.core.anki.AnkiModel] */
                /* JADX WARN: Type inference failed for: r6v20 */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 126 */       public final Object invokeSuspend(Object obj) throws Throwable {
                    int i;
                    Object note;
                    AnkiSourceNote ankiSourceNote;
                    HashMap<String, String> map;
                    String guid;
                    String str;
                    String guid2;
                    String str2;
                    Object model;
                    AnkiSourceNote ankiSourceNote2;
                    String str3;
                    AnkiModel ankiModel;
                    AnkiSourceDeck ankiSourceDeck;
                    Object objNoteByGuid;
                    String str4;
                    AnkiSourceDeck ankiSourceDeck2;
                    ?? r4;
                    AnkiNoteEntity ankiNoteEntity;
                    Long lBoxLong;
                    List<ImportIssue> listEmptyList;
                    List mutableList;
                    PreviewStatus previewStatus;
                    Ref.ObjectRef objectRef;
                    List<String> fields;
                    List<String> tags;
                    Map<String, String> map2;
                    AnkiSourceCard ankiSourceCard;
                    List list;
                    Ref.ObjectRef objectRef2;
                    List<String> list2;
                    List<String> list3;
                    Map map3;
                    String str5;
                    AnkiSourceNote ankiSourceNote3;
                    Object objModel;
                    ?? r6;
                    String str6;
                    List<String> list4;
                    Map<String, String> map4;
                    AnkiSourceNote ankiSourceNote4;
                    AnkiSourceDeck ankiSourceDeck3;
                    AnkiNoteEntity ankiNoteEntity2;
                    List list5;
                    Ref.ObjectRef objectRef3;
                    PreviewStatus previewStatus2;
                    List list6;
                    Iterator it;
                    AnkiModelEntity ankiModelEntity;
                    ?? r23;
                    List<String> listStrings;
                    List<String> listStrings2;
                    AnkiSourceCard ankiSourceCard2;
                    Object objMedia;
                    List list7;
                    AnkiSourceNote ankiSourceNote5;
                    AnkiModelEntity ankiModelEntity2;
                    ?? r14;
                    PreviewStatus previewStatus3;
                    AnkiSourceNote ankiSourceNote6;
                    String str7;
                    List<String> list8;
                    ?? r15;
                    Ref.ObjectRef objectRef4;
                    List<String> list9;
                    AnkiSourceDeck ankiSourceDeck4;
                    AnkiNoteEntity ankiNoteEntity3;
                    List list10;
                    LinkedHashMap linkedHashMap;
                    AnkiModelEntity ankiModelEntity3;
                    AnkiSourceNote ankiSourceNote7;
                    AnkiSourceCard ankiSourceCard3;
                    Object objLinks;
                    PreviewStatus previewStatus4;
                    AnkiModelEntity ankiModelEntity4;
                    AnkiSourceNote ankiSourceNote8;
                    int iCoerceAtLeast;
                    ?? r5;
                    AnkiSourceDeck ankiSourceDeck5;
                    String str8;
                    PreviewStatus previewStatus5;
                    String fullName;
                    String str9;
                    Object next;
                    ?? r16;
                    Iterable iterable;
                    Iterator it2;
                    int i2;
                    Iterable iterable2;
                    AnkiModelEntity ankiModelEntity5;
                    int i3;
                    AnkiSourceCard ankiSourceCard4 = (AnkiSourceCard) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i4 = 1;
                    switch (this.label) {
                        case 0:
                            i = 0;
                            ResultKt.throwOnFailure(obj);
/* 128 */                   JobKt.ensureActive(getCoroutineContext());
                            this.L$0 = ankiSourceCard4;
                            this.label = 1;
/* 129 */                   note = this.$source.readNote(ankiSourceCard4.getSourceId(), this);
                            if (note == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
                            ankiSourceNote = (AnkiSourceNote) note;
/* 130 */                   map = this.$guids;
                            guid = ankiSourceNote.getGuid();
/* 347 */                   str = map.get(guid);
/* 348 */                   if (str == null) {
/* 130 */                       guid2 = ankiSourceNote.getGuid();
/* 350 */                       map.put(guid, guid2);
                            } else {
/* 353 */                       guid2 = str;
                            }
/* 130 */                   str2 = guid2;
                            this.L$0 = ankiSourceCard4;
                            this.L$1 = ankiSourceNote;
                            this.L$2 = str2;
                            this.label = 2;
/* 131 */                   model = this.$source.readModel(ankiSourceCard4.getSourceId(), this);
                            if (model == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
/* 131 */                   ankiSourceNote2 = ankiSourceNote;
                            str3 = str2;
/* 127 */                   ankiModel = (AnkiModel) model;
/* 132 */                   ankiSourceDeck = this.$source.getDecks().get(Boxing.boxLong(ankiSourceCard4.getEffectiveDeckId()));
                            this.L$0 = ankiSourceCard4;
                            this.L$1 = ankiSourceNote2;
                            this.L$2 = str3;
                            this.L$3 = ankiModel;
                            this.L$4 = ankiSourceDeck;
                            this.label = 3;
/* 70 */                    objNoteByGuid = this.this$0.dao.noteByGuid(str3, this);
                            if (objNoteByGuid == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
                            str4 = str3;
/* 133 */                   ankiSourceDeck2 = ankiSourceDeck;
                            r4 = ankiModel;
/* 127 */                   ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
/* 134 */                   LinkedHashMap<String, Long> linkedHashMap2 = this.$revisions;
                            if (ankiNoteEntity != null) {
                                lBoxLong = Boxing.boxLong(ankiNoteEntity.getRevision());
                            } else {
                                lBoxLong = null;
                            }
                            linkedHashMap2.putIfAbsent(str4, lBoxLong);
/* 135 */                   listEmptyList = this.$sourceIssues.get(Boxing.boxLong(ankiSourceCard4.getSourceId()));
                            if (listEmptyList == null) {
                                listEmptyList = CollectionsKt.emptyList();
                            }
                            mutableList = CollectionsKt.toMutableList((Collection) listEmptyList);
/* 136 */                   if (ankiSourceDeck2 == null) {
                                list6 = mutableList;
/* 354 */                       if ((list6 instanceof Collection) || !list6.isEmpty()) {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                }
/* 136 */                       if (i4 != 0) {
                                    mutableList.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "missing_deck", "Original source deck is missing"));
                                }
                            }
/* 137 */                   previewStatus = PreviewStatus.COMPATIBLE;
/* 138 */                   objectRef = new Ref.ObjectRef();
                            objectRef.element = r4;
/* 139 */                   fields = ankiSourceNote2.getFields();
/* 140 */                   tags = ankiSourceNote2.getTags();
/* 141 */                   map2 = this.$retainedMimes;
/* 142 */                   if (ankiNoteEntity != null) {
                                ankiSourceNote3 = ankiSourceNote2;
                                this.L$0 = ankiSourceCard4;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote3);
                                this.L$2 = str4;
                                this.L$3 = r4;
                                this.L$4 = ankiSourceDeck2;
                                this.L$5 = ankiNoteEntity;
                                this.L$6 = mutableList;
                                this.L$7 = previewStatus;
                                this.L$8 = objectRef;
                                this.L$9 = fields;
                                this.L$10 = tags;
                                this.L$11 = map2;
                                this.label = 4;
/* 70 */                        objModel = this.this$0.dao.model(ankiNoteEntity.getModelId(), this);
                                if (objModel == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 143 */                       r6 = r4;
                                str6 = str4;
                                list4 = tags;
                                map4 = map2;
                                ankiSourceNote4 = ankiSourceNote3;
                                ankiSourceDeck3 = ankiSourceDeck2;
                                ankiNoteEntity2 = ankiNoteEntity;
                                list5 = mutableList;
                                objectRef3 = objectRef;
                                previewStatus2 = previewStatus;
                                if (objModel == null) {
                                    throw new IllegalArgumentException("Stored Anki model is missing".toString());
                                }
                                ankiModelEntity = (AnkiModelEntity) objModel;
/* 70 */                        if (this.this$0.compatible(ankiModelEntity, r6)) {
                                    r23 = r6;
/* 70 */                            objectRef3.element = this.this$0.asModel(ankiModelEntity);
/* 148 */                           listStrings = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getFields());
/* 149 */                           listStrings2 = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getTags());
                                    ankiSourceCard2 = ankiSourceCard4;
                                    this.L$0 = ankiSourceCard2;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote4);
                                    this.L$2 = str6;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(r23);
                                    this.L$4 = ankiSourceDeck3;
                                    this.L$5 = ankiNoteEntity2;
                                    this.L$6 = list5;
                                    this.L$7 = previewStatus2;
                                    this.L$8 = objectRef3;
                                    this.L$9 = listStrings;
                                    this.L$10 = listStrings2;
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(map4);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity);
                                    this.label = 5;
/* 70 */                            objMedia = this.this$0.dao.media(ankiNoteEntity2.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 127 */                               return coroutine_suspended;
                                    }
/* 150 */                           list7 = list5;
                                    ankiSourceNote5 = ankiSourceNote4;
                                    ankiModelEntity2 = ankiModelEntity;
                                    r14 = r23;
/* 127 */                           Iterable<AnkiMediaEntity> iterable3 = (Iterable) objMedia;
/* 358 */                           AnkiModelEntity ankiModelEntity6 = ankiModelEntity2;
                                    iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable3, 10)), 16);
/* 359 */                           linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                    for (AnkiMediaEntity ankiMediaEntity : iterable3) {
/* 150 */                               int i5 = iCoerceAtLeast;
                                        Pair pair = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                               linkedHashMap.put(pair.getFirst(), pair.getSecond());
                                        iCoerceAtLeast = i5;
                                        ankiSourceNote5 = ankiSourceNote5;
                                    }
                                    AnkiSourceNote ankiSourceNote9 = ankiSourceNote5;
/* 150 */                           previewStatus3 = previewStatus2;
                                    str7 = str6;
                                    ankiModelEntity = ankiModelEntity6;
                                    objectRef4 = objectRef3;
                                    r15 = r14;
                                    list9 = listStrings;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    list8 = listStrings2;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    ankiSourceNote6 = ankiSourceNote9;
                                    list10 = list7;
                                } else {
                                    List<String> list11 = list4;
                                    Map<String, String> map5 = map4;
                                    ?? r24 = r6;
/* 145 */                           list5.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "model_conflict", "Existing GUID has a different field or template structure"));
                                    previewStatus3 = previewStatus2;
                                    ankiSourceNote6 = ankiSourceNote4;
                                    str7 = str6;
                                    list8 = list11;
                                    r15 = r24;
                                    objectRef4 = objectRef3;
                                    list9 = fields;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    ankiSourceCard2 = ankiSourceCard4;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    list10 = list5;
                                    linkedHashMap = map5;
                                }
                                ankiModelEntity3 = ankiModelEntity;
                                ankiSourceNote7 = ankiSourceNote6;
                                this.L$0 = ankiSourceCard2;
                                ankiSourceCard3 = ankiSourceCard2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                                this.L$2 = str7;
                                this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                                this.L$4 = ankiSourceDeck4;
                                this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                                this.L$6 = list10;
                                this.L$7 = previewStatus3;
                                this.L$8 = objectRef4;
                                this.L$9 = list9;
                                this.L$10 = list8;
                                this.L$11 = linkedHashMap;
                                this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                                this.label = 6;
/* 70 */                        objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                                if (objLinks == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 152 */                       previewStatus4 = previewStatus3;
                                ankiModelEntity4 = ankiModelEntity3;
                                ankiSourceNote8 = ankiSourceNote7;
                                r16 = r15;
/* 127 */                       iterable = (Iterable) objLinks;
/* 364 */                       if ((iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                } else {
                                    i2 = i;
                                }
/* 152 */                       if (i2 != 0) {
                                    previewStatus = PreviewStatus.DUPLICATE;
                                    AnkiSourceDeck ankiSourceDeck6 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck6;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                } else {
                                    AnkiSourceDeck ankiSourceDeck7 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck7;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    previewStatus = previewStatus4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                }
                            } else {
/* 142 */                       ankiSourceCard = ankiSourceCard4;
                                list = mutableList;
                                objectRef2 = objectRef;
                                list2 = fields;
                                list3 = tags;
                                map3 = map2;
                                str5 = str4;
                                r5 = r4;
                            }
                            String str10 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE && list.isEmpty()) {
/* 155 */                       List<AnkiTemplate> templates = ((AnkiModel) objectRef2.element).getTemplates();
/* 367 */                       Iterator it3 = templates.iterator();
                                ?? r7 = r5;
                                while (true) {
                                    if (it3.hasNext()) {
                                        next = it3.next();
/* 155 */                               ankiSourceDeck5 = ankiSourceDeck2;
                                        ?? r32 = r7;
                                        List<AnkiTemplate> list12 = templates;
/* 367 */                               if ((((AnkiTemplate) next).getOrdinal() == (((AnkiModel) objectRef2.element).getKind() == 1 ? i : ankiSourceCard.getOrdinal()) ? 1 : i) == 0) {
                                            templates = list12;
                                            ankiSourceDeck2 = ankiSourceDeck5;
                                            r7 = r32;
                                        }
                                    } else {
/* 368 */                               ankiSourceDeck5 = ankiSourceDeck2;
                                        next = null;
                                    }
                                }
/* 155 */                       AnkiTemplate ankiTemplate = (AnkiTemplate) next;
                                Intrinsics.checkNotNull(ankiSourceDeck5);
                                String fullName2 = ankiSourceDeck5.getFullName();
                                String name = ankiTemplate != null ? ankiTemplate.getName() : null;
/* 156 */                       TemplateContext templateContext = new TemplateContext(fullName2, name == null ? "" : name, list3, ((AnkiModel) objectRef2.element).getName(), map3.keySet());
/* 157 */                       CardSide[] cardSideArr = new CardSide[2];
                                cardSideArr[i] = CardSide.QUESTION;
                                cardSideArr[1] = CardSide.ANSWER;
                                Iterator it4 = CollectionsKt.listOf((Object[]) cardSideArr).iterator();
                                while (it4.hasNext()) {
/* 70 */                            RenderedSide renderedSideRender = this.this$0.renderer.render((AnkiModel) objectRef2.element, list2, ankiSourceCard.getOrdinal(), (CardSide) it4.next(), templateContext);
                                    for (RenderIssue renderIssue : CollectionsKt.plus((Collection) renderedSideRender.getIssues(), (Iterable) AnkiMediaValidator.INSTANCE.issues(renderedSideRender, new AnonymousClass4(map3)))) {
                                        list.add(new ImportIssue(Boxing.boxLong(ankiSourceCard.getSourceId()), renderIssue.getCode(), renderIssue.getDetail()));
/* 369 */                               objectRef2 = objectRef2;
                                        ankiTemplate = ankiTemplate;
                                        renderedSideRender = renderedSideRender;
                                        str10 = str10;
                                        it4 = it4;
                                    }
                                }
                                str8 = str10;
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE || list.isEmpty()) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
                                previewStatus5 = PreviewStatus.SKIPPED;
                            }
                            ArrayList<ImportPreviewCard> arrayList = this.$cards;
                            long sourceId = ankiSourceCard.getSourceId();
                            int ordinal = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList.add(new ImportPreviewCard(sourceId, str5, ordinal, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 1:
                            i = 0;
                            ResultKt.throwOnFailure(obj);
                            note = obj;
                            ankiSourceNote = (AnkiSourceNote) note;
/* 130 */                   map = this.$guids;
                            guid = ankiSourceNote.getGuid();
/* 347 */                   str = map.get(guid);
/* 348 */                   if (str == null) {
/* 130 */                       guid2 = ankiSourceNote.getGuid();
/* 350 */                       map.put(guid, guid2);
                            } else {
/* 353 */                       guid2 = str;
                            }
/* 130 */                   str2 = guid2;
                            this.L$0 = ankiSourceCard4;
                            this.L$1 = ankiSourceNote;
                            this.L$2 = str2;
                            this.label = 2;
/* 131 */                   model = this.$source.readModel(ankiSourceCard4.getSourceId(), this);
                            if (model == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
/* 131 */                   ankiSourceNote2 = ankiSourceNote;
                            str3 = str2;
/* 127 */                   ankiModel = (AnkiModel) model;
/* 132 */                   ankiSourceDeck = this.$source.getDecks().get(Boxing.boxLong(ankiSourceCard4.getEffectiveDeckId()));
                            this.L$0 = ankiSourceCard4;
                            this.L$1 = ankiSourceNote2;
                            this.L$2 = str3;
                            this.L$3 = ankiModel;
                            this.L$4 = ankiSourceDeck;
                            this.label = 3;
/* 70 */                    objNoteByGuid = this.this$0.dao.noteByGuid(str3, this);
                            if (objNoteByGuid == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
                            str4 = str3;
/* 133 */                   ankiSourceDeck2 = ankiSourceDeck;
                            r4 = ankiModel;
/* 127 */                   ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
/* 134 */                   LinkedHashMap<String, Long> linkedHashMap3 = this.$revisions;
                            if (ankiNoteEntity != null) {
                                lBoxLong = Boxing.boxLong(ankiNoteEntity.getRevision());
                            } else {
                                lBoxLong = null;
                            }
                            linkedHashMap3.putIfAbsent(str4, lBoxLong);
/* 135 */                   listEmptyList = this.$sourceIssues.get(Boxing.boxLong(ankiSourceCard4.getSourceId()));
                            if (listEmptyList == null) {
                                listEmptyList = CollectionsKt.emptyList();
                            }
                            mutableList = CollectionsKt.toMutableList((Collection) listEmptyList);
/* 136 */                   if (ankiSourceDeck2 == null) {
                                list6 = mutableList;
/* 354 */                       if (list6 instanceof Collection) {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                } else {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                }
/* 136 */                       if (i4 != 0) {
                                    mutableList.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "missing_deck", "Original source deck is missing"));
                                }
                            }
/* 137 */                   previewStatus = PreviewStatus.COMPATIBLE;
/* 138 */                   objectRef = new Ref.ObjectRef();
                            objectRef.element = r4;
/* 139 */                   fields = ankiSourceNote2.getFields();
/* 140 */                   tags = ankiSourceNote2.getTags();
/* 141 */                   map2 = this.$retainedMimes;
/* 142 */                   if (ankiNoteEntity != null) {
                                ankiSourceNote3 = ankiSourceNote2;
                                this.L$0 = ankiSourceCard4;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote3);
                                this.L$2 = str4;
                                this.L$3 = r4;
                                this.L$4 = ankiSourceDeck2;
                                this.L$5 = ankiNoteEntity;
                                this.L$6 = mutableList;
                                this.L$7 = previewStatus;
                                this.L$8 = objectRef;
                                this.L$9 = fields;
                                this.L$10 = tags;
                                this.L$11 = map2;
                                this.label = 4;
/* 70 */                        objModel = this.this$0.dao.model(ankiNoteEntity.getModelId(), this);
                                if (objModel == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 143 */                       r6 = r4;
                                str6 = str4;
                                list4 = tags;
                                map4 = map2;
                                ankiSourceNote4 = ankiSourceNote3;
                                ankiSourceDeck3 = ankiSourceDeck2;
                                ankiNoteEntity2 = ankiNoteEntity;
                                list5 = mutableList;
                                objectRef3 = objectRef;
                                previewStatus2 = previewStatus;
                                if (objModel == null) {
                                    throw new IllegalArgumentException("Stored Anki model is missing".toString());
                                }
                                ankiModelEntity = (AnkiModelEntity) objModel;
/* 70 */                        if (this.this$0.compatible(ankiModelEntity, r6)) {
                                    List<String> list13 = list4;
                                    Map<String, String> map6 = map4;
                                    ?? r25 = r6;
/* 145 */                           list5.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "model_conflict", "Existing GUID has a different field or template structure"));
                                    previewStatus3 = previewStatus2;
                                    ankiSourceNote6 = ankiSourceNote4;
                                    str7 = str6;
                                    list8 = list13;
                                    r15 = r25;
                                    objectRef4 = objectRef3;
                                    list9 = fields;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    ankiSourceCard2 = ankiSourceCard4;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    list10 = list5;
                                    linkedHashMap = map6;
                                } else {
                                    r23 = r6;
/* 70 */                            objectRef3.element = this.this$0.asModel(ankiModelEntity);
/* 148 */                           listStrings = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getFields());
/* 149 */                           listStrings2 = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getTags());
                                    ankiSourceCard2 = ankiSourceCard4;
                                    this.L$0 = ankiSourceCard2;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote4);
                                    this.L$2 = str6;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(r23);
                                    this.L$4 = ankiSourceDeck3;
                                    this.L$5 = ankiNoteEntity2;
                                    this.L$6 = list5;
                                    this.L$7 = previewStatus2;
                                    this.L$8 = objectRef3;
                                    this.L$9 = listStrings;
                                    this.L$10 = listStrings2;
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(map4);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity);
                                    this.label = 5;
/* 70 */                            objMedia = this.this$0.dao.media(ankiNoteEntity2.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 127 */                               return coroutine_suspended;
                                    }
/* 150 */                           list7 = list5;
                                    ankiSourceNote5 = ankiSourceNote4;
                                    ankiModelEntity2 = ankiModelEntity;
                                    r14 = r23;
/* 127 */                           Iterable<AnkiMediaEntity> iterable4 = (Iterable) objMedia;
/* 358 */                           AnkiModelEntity ankiModelEntity7 = ankiModelEntity2;
                                    iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable4, 10)), 16);
/* 359 */                           linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                    while (r25.hasNext()) {
/* 150 */                               int i6 = iCoerceAtLeast;
                                        Pair pair2 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                               linkedHashMap.put(pair2.getFirst(), pair2.getSecond());
                                        iCoerceAtLeast = i6;
                                        ankiSourceNote5 = ankiSourceNote5;
                                    }
                                    AnkiSourceNote ankiSourceNote10 = ankiSourceNote5;
/* 150 */                           previewStatus3 = previewStatus2;
                                    str7 = str6;
                                    ankiModelEntity = ankiModelEntity7;
                                    objectRef4 = objectRef3;
                                    r15 = r14;
                                    list9 = listStrings;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    list8 = listStrings2;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    ankiSourceNote6 = ankiSourceNote10;
                                    list10 = list7;
                                }
                                ankiModelEntity3 = ankiModelEntity;
                                ankiSourceNote7 = ankiSourceNote6;
                                this.L$0 = ankiSourceCard2;
                                ankiSourceCard3 = ankiSourceCard2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                                this.L$2 = str7;
                                this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                                this.L$4 = ankiSourceDeck4;
                                this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                                this.L$6 = list10;
                                this.L$7 = previewStatus3;
                                this.L$8 = objectRef4;
                                this.L$9 = list9;
                                this.L$10 = list8;
                                this.L$11 = linkedHashMap;
                                this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                                this.label = 6;
/* 70 */                        objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                                if (objLinks == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 152 */                       previewStatus4 = previewStatus3;
                                ankiModelEntity4 = ankiModelEntity3;
                                ankiSourceNote8 = ankiSourceNote7;
                                r16 = r15;
/* 127 */                       iterable = (Iterable) objLinks;
/* 364 */                       if (iterable instanceof Collection) {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                } else {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                }
/* 152 */                       if (i2 != 0) {
                                    previewStatus = PreviewStatus.DUPLICATE;
                                    AnkiSourceDeck ankiSourceDeck8 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck8;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                } else {
                                    AnkiSourceDeck ankiSourceDeck9 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck9;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    previewStatus = previewStatus4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                }
                            } else {
/* 142 */                       ankiSourceCard = ankiSourceCard4;
                                list = mutableList;
                                objectRef2 = objectRef;
                                list2 = fields;
                                list3 = tags;
                                map3 = map2;
                                str5 = str4;
                                r5 = r4;
                            }
                            String str11 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList2 = this.$cards;
                            long sourceId2 = ankiSourceCard.getSourceId();
                            int ordinal2 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList2.add(new ImportPreviewCard(sourceId2, str5, ordinal2, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 2:
                            i = 0;
                            str3 = (String) this.L$2;
                            AnkiSourceNote ankiSourceNote11 = (AnkiSourceNote) this.L$1;
                            ResultKt.throwOnFailure(obj);
                            model = obj;
                            ankiSourceNote2 = ankiSourceNote11;
/* 127 */                   ankiModel = (AnkiModel) model;
/* 132 */                   ankiSourceDeck = this.$source.getDecks().get(Boxing.boxLong(ankiSourceCard4.getEffectiveDeckId()));
                            this.L$0 = ankiSourceCard4;
                            this.L$1 = ankiSourceNote2;
                            this.L$2 = str3;
                            this.L$3 = ankiModel;
                            this.L$4 = ankiSourceDeck;
                            this.label = 3;
/* 70 */                    objNoteByGuid = this.this$0.dao.noteByGuid(str3, this);
                            if (objNoteByGuid == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
                            str4 = str3;
/* 133 */                   ankiSourceDeck2 = ankiSourceDeck;
                            r4 = ankiModel;
/* 127 */                   ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
/* 134 */                   LinkedHashMap<String, Long> linkedHashMap4 = this.$revisions;
                            if (ankiNoteEntity != null) {
                                lBoxLong = Boxing.boxLong(ankiNoteEntity.getRevision());
                            } else {
                                lBoxLong = null;
                            }
                            linkedHashMap4.putIfAbsent(str4, lBoxLong);
/* 135 */                   listEmptyList = this.$sourceIssues.get(Boxing.boxLong(ankiSourceCard4.getSourceId()));
                            if (listEmptyList == null) {
                                listEmptyList = CollectionsKt.emptyList();
                            }
                            mutableList = CollectionsKt.toMutableList((Collection) listEmptyList);
/* 136 */                   if (ankiSourceDeck2 == null) {
                                list6 = mutableList;
/* 354 */                       if (list6 instanceof Collection) {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                } else {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                }
/* 136 */                       if (i4 != 0) {
                                    mutableList.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "missing_deck", "Original source deck is missing"));
                                }
                            }
/* 137 */                   previewStatus = PreviewStatus.COMPATIBLE;
/* 138 */                   objectRef = new Ref.ObjectRef();
                            objectRef.element = r4;
/* 139 */                   fields = ankiSourceNote2.getFields();
/* 140 */                   tags = ankiSourceNote2.getTags();
/* 141 */                   map2 = this.$retainedMimes;
/* 142 */                   if (ankiNoteEntity != null) {
                                ankiSourceNote3 = ankiSourceNote2;
                                this.L$0 = ankiSourceCard4;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote3);
                                this.L$2 = str4;
                                this.L$3 = r4;
                                this.L$4 = ankiSourceDeck2;
                                this.L$5 = ankiNoteEntity;
                                this.L$6 = mutableList;
                                this.L$7 = previewStatus;
                                this.L$8 = objectRef;
                                this.L$9 = fields;
                                this.L$10 = tags;
                                this.L$11 = map2;
                                this.label = 4;
/* 70 */                        objModel = this.this$0.dao.model(ankiNoteEntity.getModelId(), this);
                                if (objModel == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 143 */                       r6 = r4;
                                str6 = str4;
                                list4 = tags;
                                map4 = map2;
                                ankiSourceNote4 = ankiSourceNote3;
                                ankiSourceDeck3 = ankiSourceDeck2;
                                ankiNoteEntity2 = ankiNoteEntity;
                                list5 = mutableList;
                                objectRef3 = objectRef;
                                previewStatus2 = previewStatus;
                                if (objModel == null) {
                                    throw new IllegalArgumentException("Stored Anki model is missing".toString());
                                }
                                ankiModelEntity = (AnkiModelEntity) objModel;
/* 70 */                        if (this.this$0.compatible(ankiModelEntity, r6)) {
                                    List<String> list14 = list4;
                                    Map<String, String> map7 = map4;
                                    ?? r26 = r6;
/* 145 */                           list5.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "model_conflict", "Existing GUID has a different field or template structure"));
                                    previewStatus3 = previewStatus2;
                                    ankiSourceNote6 = ankiSourceNote4;
                                    str7 = str6;
                                    list8 = list14;
                                    r15 = r26;
                                    objectRef4 = objectRef3;
                                    list9 = fields;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    ankiSourceCard2 = ankiSourceCard4;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    list10 = list5;
                                    linkedHashMap = map7;
                                } else {
                                    r23 = r6;
/* 70 */                            objectRef3.element = this.this$0.asModel(ankiModelEntity);
/* 148 */                           listStrings = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getFields());
/* 149 */                           listStrings2 = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getTags());
                                    ankiSourceCard2 = ankiSourceCard4;
                                    this.L$0 = ankiSourceCard2;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote4);
                                    this.L$2 = str6;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(r23);
                                    this.L$4 = ankiSourceDeck3;
                                    this.L$5 = ankiNoteEntity2;
                                    this.L$6 = list5;
                                    this.L$7 = previewStatus2;
                                    this.L$8 = objectRef3;
                                    this.L$9 = listStrings;
                                    this.L$10 = listStrings2;
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(map4);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity);
                                    this.label = 5;
/* 70 */                            objMedia = this.this$0.dao.media(ankiNoteEntity2.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 127 */                               return coroutine_suspended;
                                    }
/* 150 */                           list7 = list5;
                                    ankiSourceNote5 = ankiSourceNote4;
                                    ankiModelEntity2 = ankiModelEntity;
                                    r14 = r23;
/* 127 */                           Iterable<AnkiMediaEntity> iterable5 = (Iterable) objMedia;
/* 358 */                           AnkiModelEntity ankiModelEntity8 = ankiModelEntity2;
                                    iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable5, 10)), 16);
/* 359 */                           linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                    while (r25.hasNext()) {
/* 150 */                               int i7 = iCoerceAtLeast;
                                        Pair pair3 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                               linkedHashMap.put(pair3.getFirst(), pair3.getSecond());
                                        iCoerceAtLeast = i7;
                                        ankiSourceNote5 = ankiSourceNote5;
                                    }
                                    AnkiSourceNote ankiSourceNote12 = ankiSourceNote5;
/* 150 */                           previewStatus3 = previewStatus2;
                                    str7 = str6;
                                    ankiModelEntity = ankiModelEntity8;
                                    objectRef4 = objectRef3;
                                    r15 = r14;
                                    list9 = listStrings;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    list8 = listStrings2;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    ankiSourceNote6 = ankiSourceNote12;
                                    list10 = list7;
                                }
                                ankiModelEntity3 = ankiModelEntity;
                                ankiSourceNote7 = ankiSourceNote6;
                                this.L$0 = ankiSourceCard2;
                                ankiSourceCard3 = ankiSourceCard2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                                this.L$2 = str7;
                                this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                                this.L$4 = ankiSourceDeck4;
                                this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                                this.L$6 = list10;
                                this.L$7 = previewStatus3;
                                this.L$8 = objectRef4;
                                this.L$9 = list9;
                                this.L$10 = list8;
                                this.L$11 = linkedHashMap;
                                this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                                this.label = 6;
/* 70 */                        objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                                if (objLinks == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 152 */                       previewStatus4 = previewStatus3;
                                ankiModelEntity4 = ankiModelEntity3;
                                ankiSourceNote8 = ankiSourceNote7;
                                r16 = r15;
/* 127 */                       iterable = (Iterable) objLinks;
/* 364 */                       if (iterable instanceof Collection) {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                } else {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                }
/* 152 */                       if (i2 != 0) {
                                    previewStatus = PreviewStatus.DUPLICATE;
                                    AnkiSourceDeck ankiSourceDeck10 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck10;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                } else {
                                    AnkiSourceDeck ankiSourceDeck11 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck11;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    previewStatus = previewStatus4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                }
                            } else {
/* 142 */                       ankiSourceCard = ankiSourceCard4;
                                list = mutableList;
                                objectRef2 = objectRef;
                                list2 = fields;
                                list3 = tags;
                                map3 = map2;
                                str5 = str4;
                                r5 = r4;
                            }
                            String str12 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList3 = this.$cards;
                            long sourceId3 = ankiSourceCard.getSourceId();
                            int ordinal3 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList3.add(new ImportPreviewCard(sourceId3, str5, ordinal3, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 3:
                            i = 0;
                            ankiSourceDeck2 = (AnkiSourceDeck) this.L$4;
                            AnkiModel ankiModel2 = (AnkiModel) this.L$3;
                            str4 = (String) this.L$2;
                            ankiSourceNote2 = (AnkiSourceNote) this.L$1;
                            ResultKt.throwOnFailure(obj);
                            objNoteByGuid = obj;
                            r4 = ankiModel2;
/* 127 */                   ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
/* 134 */                   LinkedHashMap<String, Long> linkedHashMap5 = this.$revisions;
                            if (ankiNoteEntity != null) {
                                lBoxLong = Boxing.boxLong(ankiNoteEntity.getRevision());
                            } else {
                                lBoxLong = null;
                            }
                            linkedHashMap5.putIfAbsent(str4, lBoxLong);
/* 135 */                   listEmptyList = this.$sourceIssues.get(Boxing.boxLong(ankiSourceCard4.getSourceId()));
                            if (listEmptyList == null) {
                                listEmptyList = CollectionsKt.emptyList();
                            }
                            mutableList = CollectionsKt.toMutableList((Collection) listEmptyList);
/* 136 */                   if (ankiSourceDeck2 == null) {
                                list6 = mutableList;
/* 354 */                       if (list6 instanceof Collection) {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                } else {
/* 355 */                           it = list6.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 356 */                                   i4 = 1;
                                        } else if (Intrinsics.areEqual(((ImportIssue) it.next()).getCode(), "missing_deck")) {
                                            i4 = i;
                                        }
                                    }
                                }
/* 136 */                       if (i4 != 0) {
                                    mutableList.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "missing_deck", "Original source deck is missing"));
                                }
                            }
/* 137 */                   previewStatus = PreviewStatus.COMPATIBLE;
/* 138 */                   objectRef = new Ref.ObjectRef();
                            objectRef.element = r4;
/* 139 */                   fields = ankiSourceNote2.getFields();
/* 140 */                   tags = ankiSourceNote2.getTags();
/* 141 */                   map2 = this.$retainedMimes;
/* 142 */                   if (ankiNoteEntity != null) {
                                ankiSourceNote3 = ankiSourceNote2;
                                this.L$0 = ankiSourceCard4;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote3);
                                this.L$2 = str4;
                                this.L$3 = r4;
                                this.L$4 = ankiSourceDeck2;
                                this.L$5 = ankiNoteEntity;
                                this.L$6 = mutableList;
                                this.L$7 = previewStatus;
                                this.L$8 = objectRef;
                                this.L$9 = fields;
                                this.L$10 = tags;
                                this.L$11 = map2;
                                this.label = 4;
/* 70 */                        objModel = this.this$0.dao.model(ankiNoteEntity.getModelId(), this);
                                if (objModel == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 143 */                       r6 = r4;
                                str6 = str4;
                                list4 = tags;
                                map4 = map2;
                                ankiSourceNote4 = ankiSourceNote3;
                                ankiSourceDeck3 = ankiSourceDeck2;
                                ankiNoteEntity2 = ankiNoteEntity;
                                list5 = mutableList;
                                objectRef3 = objectRef;
                                previewStatus2 = previewStatus;
                                if (objModel == null) {
                                    throw new IllegalArgumentException("Stored Anki model is missing".toString());
                                }
                                ankiModelEntity = (AnkiModelEntity) objModel;
/* 70 */                        if (this.this$0.compatible(ankiModelEntity, r6)) {
                                    List<String> list15 = list4;
                                    Map<String, String> map8 = map4;
                                    ?? r27 = r6;
/* 145 */                           list5.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "model_conflict", "Existing GUID has a different field or template structure"));
                                    previewStatus3 = previewStatus2;
                                    ankiSourceNote6 = ankiSourceNote4;
                                    str7 = str6;
                                    list8 = list15;
                                    r15 = r27;
                                    objectRef4 = objectRef3;
                                    list9 = fields;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    ankiSourceCard2 = ankiSourceCard4;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    list10 = list5;
                                    linkedHashMap = map8;
                                } else {
                                    r23 = r6;
/* 70 */                            objectRef3.element = this.this$0.asModel(ankiModelEntity);
/* 148 */                           listStrings = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getFields());
/* 149 */                           listStrings2 = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getTags());
                                    ankiSourceCard2 = ankiSourceCard4;
                                    this.L$0 = ankiSourceCard2;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote4);
                                    this.L$2 = str6;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(r23);
                                    this.L$4 = ankiSourceDeck3;
                                    this.L$5 = ankiNoteEntity2;
                                    this.L$6 = list5;
                                    this.L$7 = previewStatus2;
                                    this.L$8 = objectRef3;
                                    this.L$9 = listStrings;
                                    this.L$10 = listStrings2;
                                    this.L$11 = SpillingKt.nullOutSpilledVariable(map4);
                                    this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity);
                                    this.label = 5;
/* 70 */                            objMedia = this.this$0.dao.media(ankiNoteEntity2.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 127 */                               return coroutine_suspended;
                                    }
/* 150 */                           list7 = list5;
                                    ankiSourceNote5 = ankiSourceNote4;
                                    ankiModelEntity2 = ankiModelEntity;
                                    r14 = r23;
/* 127 */                           Iterable<AnkiMediaEntity> iterable6 = (Iterable) objMedia;
/* 358 */                           AnkiModelEntity ankiModelEntity9 = ankiModelEntity2;
                                    iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable6, 10)), 16);
/* 359 */                           linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                    while (r25.hasNext()) {
/* 150 */                               int i8 = iCoerceAtLeast;
                                        Pair pair4 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                               linkedHashMap.put(pair4.getFirst(), pair4.getSecond());
                                        iCoerceAtLeast = i8;
                                        ankiSourceNote5 = ankiSourceNote5;
                                    }
                                    AnkiSourceNote ankiSourceNote13 = ankiSourceNote5;
/* 150 */                           previewStatus3 = previewStatus2;
                                    str7 = str6;
                                    ankiModelEntity = ankiModelEntity9;
                                    objectRef4 = objectRef3;
                                    r15 = r14;
                                    list9 = listStrings;
                                    ankiSourceDeck4 = ankiSourceDeck3;
                                    list8 = listStrings2;
                                    ankiNoteEntity3 = ankiNoteEntity2;
                                    ankiSourceNote6 = ankiSourceNote13;
                                    list10 = list7;
                                }
                                ankiModelEntity3 = ankiModelEntity;
                                ankiSourceNote7 = ankiSourceNote6;
                                this.L$0 = ankiSourceCard2;
                                ankiSourceCard3 = ankiSourceCard2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                                this.L$2 = str7;
                                this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                                this.L$4 = ankiSourceDeck4;
                                this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                                this.L$6 = list10;
                                this.L$7 = previewStatus3;
                                this.L$8 = objectRef4;
                                this.L$9 = list9;
                                this.L$10 = list8;
                                this.L$11 = linkedHashMap;
                                this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                                this.label = 6;
/* 70 */                        objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                                if (objLinks == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 152 */                       previewStatus4 = previewStatus3;
                                ankiModelEntity4 = ankiModelEntity3;
                                ankiSourceNote8 = ankiSourceNote7;
                                r16 = r15;
/* 127 */                       iterable = (Iterable) objLinks;
/* 364 */                       if (iterable instanceof Collection) {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                } else {
/* 365 */                           it2 = iterable.iterator();
                                    while (true) {
                                        if (it2.hasNext()) {
/* 152 */                                   iterable2 = iterable;
                                            ankiModelEntity5 = ankiModelEntity4;
                                            if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                                i3 = 1;
                                            } else {
                                                i3 = i;
                                            }
/* 365 */                                   if (i3 != 0) {
                                                i2 = 1;
                                            } else {
                                                iterable = iterable2;
                                                ankiModelEntity4 = ankiModelEntity5;
                                            }
                                        } else {
                                            i2 = i;
                                        }
                                    }
                                }
/* 152 */                       if (i2 != 0) {
                                    previewStatus = PreviewStatus.DUPLICATE;
                                    AnkiSourceDeck ankiSourceDeck12 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck12;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                } else {
                                    AnkiSourceDeck ankiSourceDeck13 = ankiSourceDeck4;
                                    map3 = linkedHashMap;
                                    ankiSourceDeck2 = ankiSourceDeck13;
                                    list3 = list8;
                                    objectRef2 = objectRef4;
                                    previewStatus = previewStatus4;
                                    list = list10;
                                    r5 = r16;
                                    ankiSourceCard = ankiSourceCard3;
                                    str5 = str7;
                                    list2 = list9;
                                }
                            } else {
/* 142 */                       ankiSourceCard = ankiSourceCard4;
                                list = mutableList;
                                objectRef2 = objectRef;
                                list2 = fields;
                                list3 = tags;
                                map3 = map2;
                                str5 = str4;
                                r5 = r4;
                            }
                            String str13 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList4 = this.$cards;
                            long sourceId4 = ankiSourceCard.getSourceId();
                            int ordinal4 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList4.add(new ImportPreviewCard(sourceId4, str5, ordinal4, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 4:
                            i = 0;
                            Map<String, String> map9 = (Map) this.L$11;
                            list4 = (List) this.L$10;
                            List<String> list16 = (List) this.L$9;
                            Ref.ObjectRef objectRef5 = (Ref.ObjectRef) this.L$8;
                            PreviewStatus previewStatus6 = (PreviewStatus) this.L$7;
                            List list17 = (List) this.L$6;
                            AnkiNoteEntity ankiNoteEntity4 = (AnkiNoteEntity) this.L$5;
                            AnkiSourceDeck ankiSourceDeck14 = (AnkiSourceDeck) this.L$4;
                            AnkiModel ankiModel3 = (AnkiModel) this.L$3;
                            String str14 = (String) this.L$2;
                            ankiSourceNote4 = (AnkiSourceNote) this.L$1;
                            ResultKt.throwOnFailure(obj);
                            str6 = str14;
                            objModel = obj;
                            ankiSourceDeck3 = ankiSourceDeck14;
                            fields = list16;
                            map4 = map9;
                            list5 = list17;
                            objectRef3 = objectRef5;
                            r6 = ankiModel3;
                            ankiNoteEntity2 = ankiNoteEntity4;
                            previewStatus2 = previewStatus6;
                            if (objModel == null) {
                                throw new IllegalArgumentException("Stored Anki model is missing".toString());
                            }
                            ankiModelEntity = (AnkiModelEntity) objModel;
/* 70 */                    if (this.this$0.compatible(ankiModelEntity, r6)) {
                                List<String> list18 = list4;
                                Map<String, String> map10 = map4;
                                ?? r28 = r6;
/* 145 */                       list5.add(new ImportIssue(Boxing.boxLong(ankiSourceCard4.getSourceId()), "model_conflict", "Existing GUID has a different field or template structure"));
                                previewStatus3 = previewStatus2;
                                ankiSourceNote6 = ankiSourceNote4;
                                str7 = str6;
                                list8 = list18;
                                r15 = r28;
                                objectRef4 = objectRef3;
                                list9 = fields;
                                ankiSourceDeck4 = ankiSourceDeck3;
                                ankiSourceCard2 = ankiSourceCard4;
                                ankiNoteEntity3 = ankiNoteEntity2;
                                list10 = list5;
                                linkedHashMap = map10;
                            } else {
                                r23 = r6;
/* 70 */                        objectRef3.element = this.this$0.asModel(ankiModelEntity);
/* 148 */                       listStrings = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getFields());
/* 149 */                       listStrings2 = AnkiRepository.INSTANCE.strings(ankiNoteEntity2.getTags());
                                ankiSourceCard2 = ankiSourceCard4;
                                this.L$0 = ankiSourceCard2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote4);
                                this.L$2 = str6;
                                this.L$3 = SpillingKt.nullOutSpilledVariable(r23);
                                this.L$4 = ankiSourceDeck3;
                                this.L$5 = ankiNoteEntity2;
                                this.L$6 = list5;
                                this.L$7 = previewStatus2;
                                this.L$8 = objectRef3;
                                this.L$9 = listStrings;
                                this.L$10 = listStrings2;
                                this.L$11 = SpillingKt.nullOutSpilledVariable(map4);
                                this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity);
                                this.label = 5;
/* 70 */                        objMedia = this.this$0.dao.media(ankiNoteEntity2.getMediaNamespace(), this);
                                if (objMedia == coroutine_suspended) {
/* 127 */                           return coroutine_suspended;
                                }
/* 150 */                       list7 = list5;
                                ankiSourceNote5 = ankiSourceNote4;
                                ankiModelEntity2 = ankiModelEntity;
                                r14 = r23;
/* 127 */                       Iterable<AnkiMediaEntity> iterable7 = (Iterable) objMedia;
/* 358 */                       AnkiModelEntity ankiModelEntity10 = ankiModelEntity2;
                                iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable7, 10)), 16);
/* 359 */                       linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                                while (r25.hasNext()) {
/* 150 */                           int i9 = iCoerceAtLeast;
                                    Pair pair5 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                           linkedHashMap.put(pair5.getFirst(), pair5.getSecond());
                                    iCoerceAtLeast = i9;
                                    ankiSourceNote5 = ankiSourceNote5;
                                }
                                AnkiSourceNote ankiSourceNote14 = ankiSourceNote5;
/* 150 */                       previewStatus3 = previewStatus2;
                                str7 = str6;
                                ankiModelEntity = ankiModelEntity10;
                                objectRef4 = objectRef3;
                                r15 = r14;
                                list9 = listStrings;
                                ankiSourceDeck4 = ankiSourceDeck3;
                                list8 = listStrings2;
                                ankiNoteEntity3 = ankiNoteEntity2;
                                ankiSourceNote6 = ankiSourceNote14;
                                list10 = list7;
                            }
                            ankiModelEntity3 = ankiModelEntity;
                            ankiSourceNote7 = ankiSourceNote6;
                            this.L$0 = ankiSourceCard2;
                            ankiSourceCard3 = ankiSourceCard2;
                            this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                            this.L$2 = str7;
                            this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                            this.L$4 = ankiSourceDeck4;
                            this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                            this.L$6 = list10;
                            this.L$7 = previewStatus3;
                            this.L$8 = objectRef4;
                            this.L$9 = list9;
                            this.L$10 = list8;
                            this.L$11 = linkedHashMap;
                            this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                            this.label = 6;
/* 70 */                    objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                            if (objLinks == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
/* 152 */                   previewStatus4 = previewStatus3;
                            ankiModelEntity4 = ankiModelEntity3;
                            ankiSourceNote8 = ankiSourceNote7;
                            r16 = r15;
/* 127 */                   iterable = (Iterable) objLinks;
/* 364 */                   if (iterable instanceof Collection) {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            } else {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            }
/* 152 */                   if (i2 != 0) {
                                previewStatus = PreviewStatus.DUPLICATE;
                                AnkiSourceDeck ankiSourceDeck15 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck15;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            } else {
                                AnkiSourceDeck ankiSourceDeck16 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck16;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                previewStatus = previewStatus4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            }
                            String str15 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList5 = this.$cards;
                            long sourceId5 = ankiSourceCard.getSourceId();
                            int ordinal5 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList5.add(new ImportPreviewCard(sourceId5, str5, ordinal5, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 5:
                            i = 0;
                            ankiModelEntity2 = (AnkiModelEntity) this.L$12;
                            listStrings2 = (List) this.L$10;
                            listStrings = (List) this.L$9;
                            objectRef3 = (Ref.ObjectRef) this.L$8;
                            previewStatus2 = (PreviewStatus) this.L$7;
                            List list19 = (List) this.L$6;
                            ankiNoteEntity2 = (AnkiNoteEntity) this.L$5;
                            ankiSourceDeck3 = (AnkiSourceDeck) this.L$4;
                            AnkiModel ankiModel4 = (AnkiModel) this.L$3;
                            str6 = (String) this.L$2;
                            ankiSourceNote5 = (AnkiSourceNote) this.L$1;
                            ResultKt.throwOnFailure(obj);
                            list7 = list19;
                            ankiSourceCard2 = ankiSourceCard4;
                            objMedia = obj;
                            r14 = ankiModel4;
/* 127 */                   Iterable<AnkiMediaEntity> iterable8 = (Iterable) objMedia;
/* 358 */                   AnkiModelEntity ankiModelEntity11 = ankiModelEntity2;
                            iCoerceAtLeast = RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(iterable8, 10)), 16);
/* 359 */                   linkedHashMap = new LinkedHashMap(iCoerceAtLeast);
                            while (r25.hasNext()) {
/* 150 */                       int i10 = iCoerceAtLeast;
                                Pair pair6 = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 361 */                       linkedHashMap.put(pair6.getFirst(), pair6.getSecond());
                                iCoerceAtLeast = i10;
                                ankiSourceNote5 = ankiSourceNote5;
                            }
                            AnkiSourceNote ankiSourceNote15 = ankiSourceNote5;
/* 150 */                   previewStatus3 = previewStatus2;
                            str7 = str6;
                            ankiModelEntity = ankiModelEntity11;
                            objectRef4 = objectRef3;
                            r15 = r14;
                            list9 = listStrings;
                            ankiSourceDeck4 = ankiSourceDeck3;
                            list8 = listStrings2;
                            ankiNoteEntity3 = ankiNoteEntity2;
                            ankiSourceNote6 = ankiSourceNote15;
                            list10 = list7;
                            ankiModelEntity3 = ankiModelEntity;
                            ankiSourceNote7 = ankiSourceNote6;
                            this.L$0 = ankiSourceCard2;
                            ankiSourceCard3 = ankiSourceCard2;
                            this.L$1 = SpillingKt.nullOutSpilledVariable(ankiSourceNote7);
                            this.L$2 = str7;
                            this.L$3 = SpillingKt.nullOutSpilledVariable(r15);
                            this.L$4 = ankiSourceDeck4;
                            this.L$5 = SpillingKt.nullOutSpilledVariable(ankiNoteEntity3);
                            this.L$6 = list10;
                            this.L$7 = previewStatus3;
                            this.L$8 = objectRef4;
                            this.L$9 = list9;
                            this.L$10 = list8;
                            this.L$11 = linkedHashMap;
                            this.L$12 = SpillingKt.nullOutSpilledVariable(ankiModelEntity3);
                            this.label = 6;
/* 70 */                    objLinks = this.this$0.dao.links(ankiNoteEntity3.getId(), this);
                            if (objLinks == coroutine_suspended) {
/* 127 */                       return coroutine_suspended;
                            }
/* 152 */                   previewStatus4 = previewStatus3;
                            ankiModelEntity4 = ankiModelEntity3;
                            ankiSourceNote8 = ankiSourceNote7;
                            r16 = r15;
/* 127 */                   iterable = (Iterable) objLinks;
/* 364 */                   if (iterable instanceof Collection) {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            } else {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            }
/* 152 */                   if (i2 != 0) {
                                previewStatus = PreviewStatus.DUPLICATE;
                                AnkiSourceDeck ankiSourceDeck17 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck17;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            } else {
                                AnkiSourceDeck ankiSourceDeck18 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck18;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                previewStatus = previewStatus4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            }
                            String str16 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList6 = this.$cards;
                            long sourceId6 = ankiSourceCard.getSourceId();
                            int ordinal6 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList6.add(new ImportPreviewCard(sourceId6, str5, ordinal6, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        case 6:
                            ankiModelEntity4 = (AnkiModelEntity) this.L$12;
                            linkedHashMap = (Map) this.L$11;
                            list8 = (List) this.L$10;
                            list9 = (List) this.L$9;
                            objectRef4 = (Ref.ObjectRef) this.L$8;
                            previewStatus4 = (PreviewStatus) this.L$7;
                            list10 = (List) this.L$6;
                            ankiSourceDeck4 = (AnkiSourceDeck) this.L$4;
                            AnkiModel ankiModel5 = (AnkiModel) this.L$3;
                            str7 = (String) this.L$2;
                            i = 0;
                            ankiSourceNote8 = (AnkiSourceNote) this.L$1;
                            ResultKt.throwOnFailure(obj);
                            ankiSourceCard3 = ankiSourceCard4;
                            objLinks = obj;
                            r16 = ankiModel5;
/* 127 */                   iterable = (Iterable) objLinks;
/* 364 */                   if (iterable instanceof Collection) {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            } else {
/* 365 */                       it2 = iterable.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
/* 152 */                               iterable2 = iterable;
                                        ankiModelEntity5 = ankiModelEntity4;
                                        if (((AnkiCardEntity) it2.next()).getOrdinal() == ankiSourceCard3.getOrdinal()) {
                                            i3 = 1;
                                        } else {
                                            i3 = i;
                                        }
/* 365 */                               if (i3 != 0) {
                                            i2 = 1;
                                        } else {
                                            iterable = iterable2;
                                            ankiModelEntity4 = ankiModelEntity5;
                                        }
                                    } else {
                                        i2 = i;
                                    }
                                }
                            }
/* 152 */                   if (i2 != 0) {
                                previewStatus = PreviewStatus.DUPLICATE;
                                AnkiSourceDeck ankiSourceDeck19 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck19;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            } else {
                                AnkiSourceDeck ankiSourceDeck110 = ankiSourceDeck4;
                                map3 = linkedHashMap;
                                ankiSourceDeck2 = ankiSourceDeck110;
                                list3 = list8;
                                objectRef2 = objectRef4;
                                previewStatus = previewStatus4;
                                list = list10;
                                r5 = r16;
                                ankiSourceCard = ankiSourceCard3;
                                str5 = str7;
                                list2 = list9;
                            }
                            String str17 = "";
/* 154 */                   if (previewStatus == PreviewStatus.DUPLICATE) {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            } else {
                                ankiSourceDeck5 = ankiSourceDeck2;
                                str8 = "";
                            }
/* 164 */                   if (previewStatus != PreviewStatus.DUPLICATE) {
/* 165 */                       previewStatus5 = previewStatus;
                            } else {
/* 165 */                       previewStatus5 = previewStatus;
                            }
                            ArrayList<ImportPreviewCard> arrayList7 = this.$cards;
                            long sourceId7 = ankiSourceCard.getSourceId();
                            int ordinal7 = ankiSourceCard.getOrdinal();
                            if (ankiSourceDeck5 != null) {
                                fullName = ankiSourceDeck5.getFullName();
                            } else {
                                fullName = null;
                            }
                            if (fullName == null) {
                                str9 = str8;
                            } else {
                                str9 = fullName;
                            }
                            arrayList7.add(new ImportPreviewCard(sourceId7, str5, ordinal7, str9, previewStatus5, AnkiImportService.C04123.invokeSuspend$lambda$0$compact(this.$issueText, ankiSourceCard.getSourceId(), list)));
/* 166 */                   invoke(new ImportProgress(ImportStage.READY, this.$cards.size(), Boxing.boxLong(this.$source.getCardCount())));
/* 167 */                   return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$prepare$3$1$1$4, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 157 */       static final /* synthetic */ class AnonymousClass4 extends FunctionReferenceImpl implements Function1<String, String> {
                    AnonymousClass4(Object obj) {
                        super(1, obj, Map.class, "get", "get(Ljava/lang/Object;)Ljava/lang/Object;", 0);
                    }

                    @Override // kotlin.jvm.functions.Function1
/* 158 */           public final String invoke(String p0) {
                        Intrinsics.checkNotNullParameter(p0, "p0");
/* 159 */               return (String) ((Map) this.receiver).get(p0);
                    }
                }
            }

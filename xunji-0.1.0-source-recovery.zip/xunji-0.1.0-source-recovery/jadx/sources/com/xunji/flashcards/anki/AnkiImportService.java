            package com.xunji.flashcards.anki;

            import android.text.Html;
            import androidx.compose.runtime.ComposerKt;
            import com.github.luben.zstd.BuildConfig;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.anki.AnkiTemplateRenderer;
            import com.xunji.core.anki.ImportIssue;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.core.anki.RenderedSide;
            import com.xunji.flashcards.data.AnkiDao;
            import com.xunji.flashcards.data.AnkiModelEntity;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.File;
            import java.io.InputStream;
            import java.time.Clock;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.HashMap;
            import java.util.HashSet;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.Set;
            import java.util.concurrent.CancellationException;
            import kotlin.ExceptionsKt;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.MagicApiIntrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.jvm.internal.Reflection;
            import kotlin.reflect.KType;
            import kotlin.reflect.KTypeProjection;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineDispatcher;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.JobKt;
            import kotlinx.coroutines.NonCancellable;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            import kotlinx.coroutines.sync.Mutex;
            import kotlinx.coroutines.sync.MutexKt;
            import kotlinx.serialization.SerializersKt;
            import kotlinx.serialization.json.Json;
            import kotlinx.serialization.modules.SerializersModule;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\u008c\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0001\u0018\u00002\u00020\u0001B;\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\r¢\u0006\u0004\b\u000e\u0010\u000fJ\u000e\u0010\u001b\u001a\u00020\u001cH\u0086@¢\u0006\u0002\u0010\u001dJ8\u0010\u001e\u001a\u00020\u001a2\u0006\u0010\u001f\u001a\u00020 2\n\b\u0002\u0010!\u001a\u0004\u0018\u00010\"2\u0014\b\u0002\u0010#\u001a\u000e\u0012\u0004\u0012\u00020%\u0012\u0004\u0012\u00020\u001c0$H\u0086@¢\u0006\u0002\u0010&J\u0016\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u001aH\u0086@¢\u0006\u0002\u0010*J\u0016\u0010+\u001a\u00020(2\u0006\u0010)\u001a\u00020\u001aH\u0082@¢\u0006\u0002\u0010*J\u0015\u0010,\u001a\u00020\u001c2\u0006\u0010)\u001a\u00020\u001aH\u0000¢\u0006\u0002\b-J\u0018\u0010.\u001a\u00020\u00182\u0006\u0010/\u001a\u0002002\u0006\u00101\u001a\u000202H\u0002J\u0010\u00103\u001a\u0002022\u0006\u0010/\u001a\u000200H\u0002J\u0010\u00104\u001a\u00020\"2\u0006\u00105\u001a\u000206H\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0010\u001a\u00020\u0011X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0012\u001a\u00020\u0013X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0014\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0015X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0017\u001a\u00020\u0018X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0019\u001a\u0004\u0018\u00010\u001aX\u0082\u000e¢\u0006\u0002\n\u0000¨\u00067"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiImportService;", "", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "media", "Lcom/xunji/flashcards/anki/MediaStore;", "coordinator", "Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "stagingRoot", "Ljava/io/File;", "clock", "Ljava/time/Clock;", "reader", "Lcom/xunji/flashcards/anki/ApkgReader;", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;Lcom/xunji/flashcards/anki/MediaStore;Lcom/xunji/flashcards/anki/FileOperationCoordinator;Ljava/io/File;Ljava/time/Clock;Lcom/xunji/flashcards/anki/ApkgReader;)V", "dao", "Lcom/xunji/flashcards/data/AnkiDao;", "renderer", "Lcom/xunji/core/anki/AnkiTemplateRenderer;", "initialization", "Lkotlinx/coroutines/sync/Mutex;", "sourceOperations", "initialized", "", "active", "Lcom/xunji/flashcards/anki/PreparedAnkiImport;", "initialize", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "prepare", "input", "Ljava/io/InputStream;", "displayName", "", "onProgress", "Lkotlin/Function1;", "Lcom/xunji/core/anki/ImportProgress;", "(Ljava/io/InputStream;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "commit", "Lcom/xunji/flashcards/anki/ImportResult;", "prepared", "(Lcom/xunji/flashcards/anki/PreparedAnkiImport;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "commitLocked", BuildConfig.BUILD_TYPE, "release$app_debug", "compatible", "local", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "source", "Lcom/xunji/core/anki/AnkiModel;", "asModel", "summary", "side", "Lcom/xunji/core/anki/RenderedSide;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 68 */    public final class AnkiImportService {
                public static final int $stable = 8;
                private PreparedAnkiImport active;
                private final Clock clock;
                private final FileOperationCoordinator coordinator;
                private final AnkiDao dao;
                private final XunjiDatabase db;
                private final Mutex initialization;
                private boolean initialized;
                private final MediaStore media;
                private final ApkgReader reader;
                private final AnkiTemplateRenderer renderer;
                private final Mutex sourceOperations;
                private final File stagingRoot;

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commit$1, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService", f = "AnkiImportService.kt", i = {0, 0, 0, 1, 1, 1, 1}, l = {352, 186}, m = "commit", n = {"prepared", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\186", "prepared", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\186", "$i$a$-withLock$default-AnkiImportService$commit$2\\2\\354\\0"}, s = {"L$0", "L$1", "I$0", "L$0", "L$1", "I$0", "I$1"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnkiImportService.this.commit(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService", f = "AnkiImportService.kt", i = {0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, l = {200, ComposerKt.providerMapsKey, 200, 210, 319, 319, 319}, m = "commitLocked", n = {"prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "completed", "failure", "caller", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "completed", "failure", "caller", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "completed", "failure", "caller", "duplicateCount", "skipped", "prepared", "chosen", "selectedCards", "selectedGuids", "reasons", "completed", "failure", "caller", "duplicateCount", "skipped"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "I$0", "I$1"}, v = 1)
                static final class C04091 extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    Object L$9;
                    int label;
                    /* synthetic */ Object result;

                    C04091(Continuation<? super C04091> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 70 */                return AnkiImportService.this.commitLocked(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$initialize$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService", f = "AnkiImportService.kt", i = {0, 0, 1, 1, 1}, l = {352, 83}, m = "initialize", n = {"$this$withLock_u24default\\1", "$i$f$withLock\\1\\82", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\82", "$i$a$-withLock$default-AnkiImportService$initialize$2\\2\\354\\0"}, s = {"L$0", "I$0", "L$0", "I$0", "I$1"}, v = 1)
                static final class C04101 extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    Object L$0;
                    int label;
                    /* synthetic */ Object result;

                    C04101(Continuation<? super C04101> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnkiImportService.this.initialize(this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$prepare$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService", f = "AnkiImportService.kt", i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1}, l = {97, 176}, m = "prepare", n = {"input", "displayName", "onProgress", "packageSource", "passedToReader", "input", "displayName", "onProgress", "packageSource", "passedToReader", "error"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5"}, v = 1)
                static final class C04111 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    int label;
                    /* synthetic */ Object result;

                    C04111(Continuation<? super C04111> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnkiImportService.this.prepare(null, null, null, this);
                    }
                }

/* 69 */        public AnkiImportService(XunjiDatabase db, MediaStore media, FileOperationCoordinator coordinator, File stagingRoot, Clock clock, ApkgReader reader) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(media, "media");
                    Intrinsics.checkNotNullParameter(coordinator, "coordinator");
                    Intrinsics.checkNotNullParameter(stagingRoot, "stagingRoot");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    Intrinsics.checkNotNullParameter(reader, "reader");
/* 71 */            this.db = db;
                    this.media = media;
/* 72 */            this.coordinator = coordinator;
                    this.stagingRoot = stagingRoot;
/* 73 */            this.clock = clock;
                    this.reader = reader;
/* 75 */            this.dao = this.db.ankiDao();
/* 76 */            this.renderer = new AnkiTemplateRenderer();
/* 77 */            this.initialization = MutexKt.Mutex$default(false, 1, null);
/* 78 */            this.sourceOperations = MutexKt.Mutex$default(false, 1, null);
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 69 */        public /* synthetic */ AnkiImportService(XunjiDatabase xunjiDatabase, MediaStore mediaStore, FileOperationCoordinator fileOperationCoordinator, File file, Clock clock, ApkgReader apkgReader, int i, DefaultConstructorMarker defaultConstructorMarker) {
                    Clock clock2;
                    ApkgReader apkgReader2;
/* 70 */            if ((i & 16) == 0) {
/* 70 */                clock2 = clock;
                    } else {
/* 73 */                Clock clockSystemUTC = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clockSystemUTC, "systemUTC(...)");
                        clock2 = clockSystemUTC;
                    }
                    if ((i & 32) == 0) {
/* 70 */                apkgReader2 = apkgReader;
                    } else {
/* 73 */                apkgReader2 = new ApkgReader(null, 1);
                    }
                    this(xunjiDatabase, mediaStore, fileOperationCoordinator, file, clock2, apkgReader2);
                }

                /* JADX WARN: Code duplicated, block: B:25:0x007e A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:26:0x007f  */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 81 */        public final Object initialize(Continuation<? super Unit> continuation) throws Throwable {
                    C04101 c04101;
                    Object obj;
                    Mutex mutex;
                    int i;
                    CoroutineDispatcher io2;
                    AnkiImportService$initialize$2$1 ankiImportService$initialize$2$1;
                    if (continuation instanceof C04101) {
                        c04101 = (C04101) continuation;
                        if ((c04101.label & Integer.MIN_VALUE) != 0) {
                            c04101.label -= Integer.MIN_VALUE;
                        } else {
                            c04101 = new C04101(continuation);
                        }
                    } else {
                        c04101 = new C04101(continuation);
                    }
                    Object $result = c04101.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    try {
                        switch (c04101.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                Mutex mutex2 = this.initialization;
/* 348 */                       obj = null;
/* 352 */                       c04101.L$0 = mutex2;
/* 347 */                       c04101.I$0 = 0;
                                c04101.label = 1;
/* 348 */                       if (mutex2.lock(null, c04101) == coroutine_suspended) {
/* 82 */                            return coroutine_suspended;
                                }
                                mutex = mutex2;
/* 352 */                       i = 0;
/* 83 */                        io2 = Dispatchers.getIO();
                                ankiImportService$initialize$2$1 = new AnkiImportService$initialize$2$1(this, null);
                                c04101.L$0 = mutex;
                                c04101.I$0 = i;
/* 354 */                       c04101.I$1 = 0;
                                c04101.label = 2;
                                if (BuildersKt.withContext(io2, ankiImportService$initialize$2$1, c04101) == coroutine_suspended) {
/* 82 */                            return coroutine_suspended;
                                }
/* 91 */                        Unit unit = Unit.INSTANCE;
/* 356 */                       mutex.unlock(obj);
/* 91 */                        return unit;
                            case 1:
/* 82 */                        i = c04101.I$0;
                                obj = null;
                                mutex = (Mutex) c04101.L$0;
                                ResultKt.throwOnFailure($result);
/* 83 */                        io2 = Dispatchers.getIO();
                                ankiImportService$initialize$2$1 = new AnkiImportService$initialize$2$1(this, null);
                                c04101.L$0 = mutex;
                                c04101.I$0 = i;
/* 354 */                       c04101.I$1 = 0;
                                c04101.label = 2;
                                if (BuildersKt.withContext(io2, ankiImportService$initialize$2$1, c04101) == coroutine_suspended) {
/* 82 */                            return coroutine_suspended;
                                }
/* 91 */                        Unit unit2 = Unit.INSTANCE;
/* 356 */                       mutex.unlock(obj);
/* 91 */                        return unit2;
                            case 2:
                                int i2 = c04101.I$1;
                                int i3 = c04101.I$0;
                                obj = null;
                                mutex = (Mutex) c04101.L$0;
                                ResultKt.throwOnFailure($result);
/* 91 */                        Unit unit3 = Unit.INSTANCE;
/* 356 */                       mutex.unlock(obj);
/* 91 */                        return unit3;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    } catch (Throwable th) {
/* 356 */               mutex.unlock(obj);
                        throw th;
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 92 */        public static /* synthetic */ Object prepare$default(AnkiImportService ankiImportService, InputStream inputStream, String str, Function1 function1, Continuation continuation, int i, Object obj) {
/* 93 */            if ((i & 2) != 0) {
                        str = null;
                    }
                    if ((i & 4) != 0) {
                        function1 = new Function1() { // from class: com.xunji.flashcards.anki.AnkiImportService$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return AnkiImportService.prepare$lambda$0((ImportProgress) obj2);
                            }
                        };
                    }
                    return ankiImportService.prepare(inputStream, str, function1, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 92 */        public static final Unit prepare$lambda$0(ImportProgress it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 93 */            return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:36:0x0111 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:37:0x0112  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
/* 92 */        public final Object prepare(InputStream input, String displayName, Function1<? super ImportProgress, Unit> function1, Continuation<? super PreparedAnkiImport> continuation) throws Exception {
                    C04111 c04111;
                    AnkiImportService ankiImportService;
                    InputStream input2;
                    String displayName2;
                    Exception error;
                    Ref.BooleanRef passedToReader;
                    InputStream input3;
                    Ref.ObjectRef packageSource;
                    Function1<? super ImportProgress, Unit> function2;
                    CoroutineContext coroutineContextPlus;
                    Exception error2;
                    C04134 c04134;
                    if (continuation instanceof C04111) {
                        c04111 = (C04111) continuation;
                        if ((c04111.label & Integer.MIN_VALUE) != 0) {
                            c04111.label -= Integer.MIN_VALUE;
                            ankiImportService = this;
                        } else {
                            ankiImportService = this;
                            c04111 = ankiImportService.new C04111(continuation);
                        }
                    } else {
                        ankiImportService = this;
                        c04111 = ankiImportService.new C04111(continuation);
                    }
                    C04111 c04112 = c04111;
                    Object $result = c04112.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04112.label) {
                        case 0:
/* 93 */                    ResultKt.throwOnFailure($result);
/* 94 */                    Ref.ObjectRef packageSource2 = new Ref.ObjectRef();
/* 95 */                    Ref.BooleanRef passedToReader2 = new Ref.BooleanRef();
                            try {
/* 97 */                        CoroutineDispatcher io2 = Dispatchers.getIO();
                                input2 = input;
                                try {
                                    C04123 c04123 = ankiImportService.new C04123(passedToReader2, input2, function1, displayName, packageSource2, null);
                                    input2 = input;
                                    c04112.L$0 = input2;
                                    c04112.L$1 = SpillingKt.nullOutSpilledVariable(displayName);
                                    c04112.L$2 = SpillingKt.nullOutSpilledVariable(function1);
                                    c04112.L$3 = packageSource2;
                                    c04112.L$4 = passedToReader2;
                                    c04112.label = 1;
                                    Object objWithContext = BuildersKt.withContext(io2, c04123, c04112);
                                    return objWithContext == coroutine_suspended ? coroutine_suspended : objWithContext;
                                } catch (Exception e) {
                                    e = e;
                                    displayName2 = displayName;
                                    error = e;
                                    passedToReader = passedToReader2;
                                    input3 = input2;
                                    packageSource = packageSource2;
                                    function2 = function1;
/* 176 */                           coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                    error2 = error;
                                    c04134 = new C04134(passedToReader, input3, packageSource, error, null);
                                    c04112.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                                    c04112.L$1 = SpillingKt.nullOutSpilledVariable(displayName2);
                                    c04112.L$2 = SpillingKt.nullOutSpilledVariable(function2);
                                    c04112.L$3 = SpillingKt.nullOutSpilledVariable(packageSource);
                                    c04112.L$4 = SpillingKt.nullOutSpilledVariable(passedToReader);
                                    c04112.L$5 = error2;
                                    c04112.label = 2;
                                    if (BuildersKt.withContext(coroutineContextPlus, c04134, c04112) == coroutine_suspended) {
/* 93 */                                return coroutine_suspended;
                                    }
/* 182 */                           throw error2;
                                }
                            } catch (Exception e2) {
                                e = e2;
                                input2 = input;
                            }
                            break;
                        case 1:
                            Ref.BooleanRef passedToReader3 = (Ref.BooleanRef) c04112.L$4;
                            Ref.ObjectRef packageSource3 = (Ref.ObjectRef) c04112.L$3;
                            function2 = (Function1) c04112.L$2;
                            displayName2 = (String) c04112.L$1;
                            InputStream input4 = (InputStream) c04112.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
                                return $result;
                            } catch (Exception e3) {
                                error = e3;
                                passedToReader = passedToReader3;
                                packageSource = packageSource3;
                                input3 = input4;
                            }
                            break;
                        case 2:
                            Exception error3 = (Exception) c04112.L$5;
                            ResultKt.throwOnFailure($result);
/* 182 */                   throw error3;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 176 */           coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                    error2 = error;
                    c04134 = new C04134(passedToReader, input3, packageSource, error, null);
                    c04112.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                    c04112.L$1 = SpillingKt.nullOutSpilledVariable(displayName2);
                    c04112.L$2 = SpillingKt.nullOutSpilledVariable(function2);
                    c04112.L$3 = SpillingKt.nullOutSpilledVariable(packageSource);
                    c04112.L$4 = SpillingKt.nullOutSpilledVariable(passedToReader);
                    c04112.L$5 = error2;
                    c04112.label = 2;
                    if (BuildersKt.withContext(coroutineContextPlus, c04134, c04112) == coroutine_suspended) {
/* 93 */                return coroutine_suspended;
                    }
/* 182 */           throw error2;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$prepare$3, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/PreparedAnkiImport;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$prepare$3", f = "AnkiImportService.kt", i = {0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3}, l = {352, 100, 103, WorkQueueKt.MASK}, m = "invokeSuspend", n = {"$this$withContext", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\98", "$this$withContext", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\98", "$i$a$-withLock$default-AnkiImportService$prepare$3$1\\2\\354\\0", "$this$withContext", "$this$withLock_u24default\\1", "$i$f$withLock\\1\\98", "$i$a$-withLock$default-AnkiImportService$prepare$3$1\\2\\354\\0", "epoch\\2", "$this$withContext", "$this$withLock_u24default\\1", "namespace\\2", "retainedMimes\\2", "sourceIssues\\2", "source\\2", "revisions\\2", "guids\\2", "issueText\\2", "cards\\2", "$i$f$withLock\\1\\98", "$i$a$-withLock$default-AnkiImportService$prepare$3$1\\2\\354\\0", "epoch\\2"}, s = {"L$0", "L$1", "I$0", "L$0", "L$1", "I$0", "I$1", "L$0", "L$1", "I$0", "I$1", "J$0", "L$0", "L$1", "L$4", "L$5", "L$6", "L$7", "L$8", "L$9", "L$10", "L$11", "I$0", "I$1", "J$0"}, v = 1)
/* 95 */        static final class C04123 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super PreparedAnkiImport>, Object> {
                    final /* synthetic */ String $displayName;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Function1<ImportProgress, Unit> $onProgress;
                    final /* synthetic */ Ref.ObjectRef<PreparedPackage> $packageSource;
                    final /* synthetic */ Ref.BooleanRef $passedToReader;
                    int I$0;
                    int I$1;
                    long J$0;
                    private /* synthetic */ Object L$0;
                    Object L$1;
                    Object L$10;
                    Object L$11;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    Object L$9;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    C04123(Ref.BooleanRef booleanRef, InputStream inputStream, Function1<? super ImportProgress, Unit> function1, String str, Ref.ObjectRef<PreparedPackage> objectRef, Continuation<? super C04123> continuation) {
                        super(2, continuation);
                        this.$passedToReader = booleanRef;
                        this.$input = inputStream;
                        this.$onProgress = function1;
                        this.$displayName = str;
                        this.$packageSource = objectRef;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04123 c04123 = AnkiImportService.this.new C04123(this.$passedToReader, this.$input, this.$onProgress, this.$displayName, this.$packageSource, continuation);
                        c04123.L$0 = obj;
                        return c04123;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super PreparedAnkiImport> continuation) {
                        return ((C04123) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:116:0x01da A[EXC_TOP_SPLITTER, SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:125:0x021d A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:29:0x0144 A[Catch: all -> 0x0064, TRY_ENTER, TRY_LEAVE, TryCatch #3 {all -> 0x0064, blocks: (B:7:0x004f, B:29:0x0144), top: B:107:0x000d }] */
                    /* JADX WARN: Code duplicated, block: B:32:0x0164 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:33:0x0165  */
                    /* JADX WARN: Code duplicated, block: B:36:0x01a0 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:37:0x01a1  */
                    /* JADX WARN: Code duplicated, block: B:45:0x0204 A[Catch: all -> 0x0222, TryCatch #2 {all -> 0x0222, blocks: (B:43:0x01fe, B:45:0x0204, B:48:0x0217, B:58:0x025f, B:60:0x0286, B:62:0x029f), top: B:105:0x01fe }] */
                    /* JADX WARN: Code duplicated, block: B:46:0x020f  */
                    /* JADX WARN: Code duplicated, block: B:48:0x0217 A[Catch: all -> 0x0222, TRY_LEAVE, TryCatch #2 {all -> 0x0222, blocks: (B:43:0x01fe, B:45:0x0204, B:48:0x0217, B:58:0x025f, B:60:0x0286, B:62:0x029f), top: B:105:0x01fe }] */
                    /* JADX WARN: Code duplicated, block: B:58:0x025f A[Catch: all -> 0x0222, TRY_ENTER, TryCatch #2 {all -> 0x0222, blocks: (B:43:0x01fe, B:45:0x0204, B:48:0x0217, B:58:0x025f, B:60:0x0286, B:62:0x029f), top: B:105:0x01fe }] */
                    /* JADX WARN: Code duplicated, block: B:60:0x0286 A[Catch: all -> 0x0222, TryCatch #2 {all -> 0x0222, blocks: (B:43:0x01fe, B:45:0x0204, B:48:0x0217, B:58:0x025f, B:60:0x0286, B:62:0x029f), top: B:105:0x01fe }] */
                    /* JADX WARN: Code duplicated, block: B:61:0x029b  */
                    /* JADX WARN: Code duplicated, block: B:72:0x033c A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:73:0x033d  */
                    /* JADX WARN: Code duplicated, block: B:76:0x035f  */
                    /* JADX WARN: Code duplicated, block: B:77:0x0362  */
                    /* JADX WARN: Code duplicated, block: B:79:0x0365 A[Catch: all -> 0x039e, TRY_LEAVE, TryCatch #11 {all -> 0x039e, blocks: (B:74:0x0353, B:79:0x0365, B:83:0x0392, B:84:0x039d), top: B:122:0x0353 }] */
                    /* JADX WARN: Code duplicated, block: B:82:0x0391  */
                    /* JADX WARN: Not initialized variable reg: 17, insn: 0x0067: MOVE (r5 I:??[OBJECT, ARRAY]) = (r17 I:??[OBJECT, ARRAY] A[D('owner\1' java.lang.Object)]), block:B:10:0x0065 */
                    /* JADX WARN: Type inference failed for: r7v11, types: [T, com.xunji.flashcards.anki.PreparedPackage] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 96 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object obj;
                        Object obj2;
                        Mutex mutex;
                        AnkiImportService ankiImportService;
                        Ref.ObjectRef<PreparedPackage> objectRef;
                        Object obj3;
                        Ref.BooleanRef booleanRef;
                        InputStream inputStream;
                        String str;
                        Function1<ImportProgress, Unit> function1;
                        int i;
                        int i2;
                        PreparedAnkiImport preparedAnkiImport;
                        AnkiImportService ankiImportService2;
                        Ref.ObjectRef<PreparedPackage> objectRef2;
                        Mutex mutex2;
                        InputStream inputStream2;
                        Ref.BooleanRef booleanRef2;
                        int i3;
                        Function1<ImportProgress, Unit> function2;
                        String str2;
                        long restoreEpoch;
                        Object objOpen;
                        Ref.ObjectRef<PreparedPackage> objectRef3;
                        int i4;
                        AnkiImportService ankiImportService3;
                        Function1<ImportProgress, Unit> function3;
                        int i5;
                        PreparedPackage preparedPackage;
                        String strNamespaceFor;
                        Collection arrayList;
                        PreparedPackage preparedPackage2;
                        Mutex mutex3;
                        Iterable issues;
                        int i6;
                        Map linkedHashMap;
                        LinkedHashMap linkedHashMap2;
                        ArrayList arrayList2;
                        Ref.ObjectRef<PreparedPackage> objectRef4;
                        boolean z;
                        long j;
                        AnkiImportService$prepare$3$1$1 ankiImportService$prepare$3$1$1;
                        AnkiImportService ankiImportService4;
                        PreparedPackage preparedPackage3;
                        long j2;
                        ArrayList arrayList3;
                        String str3;
                        Ref.ObjectRef<PreparedPackage> objectRef5;
                        AnkiImportService ankiImportService5;
                        LinkedHashMap linkedHashMap3;
                        Long cardId;
                        Object obj4;
                        Object obj5;
                        String key;
                        String strMimeFor;
                        Pair pair;
                        boolean z2;
                        CoroutineScope $this$withContext = (CoroutineScope) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 70 */                            Mutex mutex4 = AnkiImportService.this.sourceOperations;
                                    ankiImportService = AnkiImportService.this;
                                    Ref.BooleanRef booleanRef3 = this.$passedToReader;
                                    InputStream inputStream3 = this.$input;
                                    Function1<ImportProgress, Unit> function4 = this.$onProgress;
                                    String str4 = this.$displayName;
                                    objectRef = this.$packageSource;
                                    this.L$0 = $this$withContext;
                                    this.L$1 = mutex4;
                                    this.L$2 = ankiImportService;
                                    this.L$3 = booleanRef3;
                                    this.L$4 = inputStream3;
                                    this.L$5 = function4;
                                    this.L$6 = str4;
                                    this.L$7 = objectRef;
/* 347 */                           this.I$0 = 0;
                                    this.label = 1;
/* 348 */                           if (mutex4.lock(null, this) == coroutine_suspended) {
/* 97 */                                return coroutine_suspended;
                                    }
/* 352 */                           obj3 = null;
                                    booleanRef = booleanRef3;
                                    mutex = mutex4;
                                    inputStream = inputStream3;
                                    str = str4;
                                    function1 = function4;
/* 347 */                           i = 0;
/* 354 */                           i2 = 0;
                                    try {
/* 70 */                                preparedAnkiImport = ankiImportService.active;
                                        if (preparedAnkiImport != null) {
                                            preparedAnkiImport.close();
                                        }
/* 100 */                               this.L$0 = $this$withContext;
                                        this.L$1 = mutex;
                                        this.L$2 = ankiImportService;
                                        this.L$3 = booleanRef;
                                        this.L$4 = inputStream;
                                        this.L$5 = function1;
                                        this.L$6 = str;
                                        this.L$7 = objectRef;
                                        this.I$0 = i;
/* 354 */                               this.I$1 = 0;
                                        this.label = 2;
                                        if (ankiImportService.initialize(this) == coroutine_suspended) {
/* 97 */                                    return coroutine_suspended;
                                        }
/* 100 */                               ankiImportService2 = ankiImportService;
                                        objectRef2 = objectRef;
                                        mutex2 = mutex;
                                        inputStream2 = inputStream;
                                        booleanRef2 = booleanRef;
                                        i3 = i;
                                        function2 = function1;
                                        str2 = str;
                                        try {
/* 70 */                                    restoreEpoch = ankiImportService2.coordinator.getRestoreEpoch();
/* 102 */                                   booleanRef2.element = true;
/* 70 */                                    ApkgReader apkgReader = ankiImportService2.reader;
/* 70 */                                    File file = ankiImportService2.stagingRoot;
                                            this.L$0 = $this$withContext;
                                            this.L$1 = mutex2;
                                            this.L$2 = ankiImportService2;
                                            this.L$3 = function2;
                                            this.L$4 = objectRef2;
                                            this.L$5 = null;
                                            this.L$6 = null;
                                            this.L$7 = null;
                                            this.I$0 = i3;
                                            this.I$1 = i2;
                                            this.J$0 = restoreEpoch;
                                            this.label = 3;
                                            objOpen = apkgReader.open(inputStream2, file, function2, str2, this);
                                            if (objOpen == coroutine_suspended) {
/* 97 */                                        return coroutine_suspended;
                                            }
/* 103 */                                   mutex = mutex2;
                                            objectRef3 = objectRef2;
                                            i4 = i2;
                                            ankiImportService3 = ankiImportService2;
                                            function3 = function2;
                                            i5 = i3;
                                            try {
/* 103 */                                       objectRef3.element = (PreparedPackage) objOpen;
                                                preparedPackage = (PreparedPackage) objOpen;
/* 104 */                                       strNamespaceFor = MediaStore.INSTANCE.namespaceFor(preparedPackage.getMedia());
/* 105 */                                       Map<String, AnkiMediaFile> media = preparedPackage.getMedia();
/* 356 */                                       arrayList = new ArrayList();
                                                for (Map.Entry<String, AnkiMediaFile> entry : media.entrySet()) {
                                                    try {
                                                        key = entry.getKey();
/* 105 */                                               PreparedPackage preparedPackage4 = preparedPackage;
                                                        mutex3 = mutex;
                                                        try {
                                                            strMimeFor = MediaStore.INSTANCE.mimeFor(entry.getValue());
                                                            if (strMimeFor != null) {
                                                                pair = TuplesKt.to(key, strMimeFor);
                                                            } else {
                                                                pair = null;
                                                            }
/* 364 */                                                   if (pair != null) {
/* 364 */                                                       arrayList.add(pair);
                                                            }
/* 365 */                                                   preparedPackage = preparedPackage4;
                                                            mutex = mutex3;
                                                        } catch (Throwable th) {
/* 383 */                                                   th = th;
                                                            obj2 = obj3;
                                                            mutex = mutex3;
                                                            mutex.unlock(obj2);
                                                            throw th;
                                                        }
                                                    } catch (Throwable th2) {
                                                        th = th2;
                                                        obj2 = obj3;
                                                        mutex.unlock(obj2);
                                                        throw th;
                                                    }
                                                    break;
                                                }
/* 367 */                                       preparedPackage2 = preparedPackage;
                                                mutex3 = mutex;
                                                try {
/* 105 */                                           Map map = MapsKt.toMap((List) arrayList);
/* 106 */                                           issues = preparedPackage2.getIssues();
                                                    i6 = 0;
/* 369 */                                           linkedHashMap = new LinkedHashMap();
                                                    for (Object obj6 : issues) {
/* 106 */                                               cardId = ((ImportIssue) obj6).getCardId();
/* 373 */                                               Iterable iterable = issues;
                                                        int i7 = i6;
/* 372 */                                               obj4 = linkedHashMap.get(cardId);
/* 374 */                                               if (obj4 == null) {
/* 372 */                                                   ArrayList arrayList4 = new ArrayList();
/* 372 */                                                   linkedHashMap.put(cardId, arrayList4);
/* 377 */                                                   obj5 = arrayList4;
                                                        } else {
                                                            obj5 = obj4;
                                                        }
/* 380 */                                               ((List) obj5).add(obj6);
                                                        i6 = i7;
                                                        issues = iterable;
                                                        i4 = i4;
                                                    }
                                                    int i8 = i4;
/* 107 */                                           linkedHashMap2 = new LinkedHashMap();
/* 108 */                                           HashMap map2 = new HashMap();
/* 109 */                                           HashMap map3 = new HashMap();
/* 126 */                                           arrayList2 = new ArrayList(preparedPackage2.getCardCount());
/* 127 */                                           objectRef4 = objectRef3;
                                                    z = true;
                                                    int i9 = i5;
                                                    j = restoreEpoch;
                                                    try {
                                                        ankiImportService$prepare$3$1$1 = new AnkiImportService$prepare$3$1$1($this$withContext, preparedPackage2, map2, ankiImportService3, linkedHashMap2, linkedHashMap, map, arrayList2, function3, map3, null);
                                                        this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                                                        this.L$1 = mutex3;
                                                        this.L$2 = ankiImportService3;
                                                        this.L$3 = objectRef4;
                                                        this.L$4 = strNamespaceFor;
                                                        this.L$5 = SpillingKt.nullOutSpilledVariable(map);
                                                        this.L$6 = SpillingKt.nullOutSpilledVariable(linkedHashMap);
                                                        this.L$7 = preparedPackage2;
                                                        this.L$8 = linkedHashMap2;
                                                        this.L$9 = SpillingKt.nullOutSpilledVariable(map2);
                                                        this.L$10 = SpillingKt.nullOutSpilledVariable(map3);
                                                        this.L$11 = arrayList2;
                                                        try {
                                                            this.I$0 = i9;
                                                            this.I$1 = i8;
                                                            ankiImportService4 = ankiImportService3;
                                                            this.J$0 = j;
                                                            this.label = 4;
                                                            if (preparedPackage2.forEachCard(ankiImportService$prepare$3$1$1, this) == coroutine_suspended) {
                                                                return coroutine_suspended;
                                                            }
                                                            preparedPackage3 = preparedPackage2;
                                                            j2 = j;
                                                            arrayList3 = arrayList2;
                                                            str3 = strNamespaceFor;
                                                            mutex = mutex3;
                                                            objectRef5 = objectRef4;
                                                            ankiImportService5 = ankiImportService4;
                                                            linkedHashMap3 = linkedHashMap2;
                                                            obj2 = obj3;
                                                            try {
                                                                if (j2 == ankiImportService5.coordinator.getRestoreEpoch()) {
                                                                    z2 = z;
                                                                } else {
                                                                    z2 = false;
                                                                }
                                                                if (!z2) {
/* 168 */                                                           throw new IllegalArgumentException("Data was restored during preflight; repeat import preflight".toString());
                                                                }
/* 169 */                                                       PreparedAnkiImport preparedAnkiImport2 = new PreparedAnkiImport(ankiImportService5, preparedPackage3, preparedPackage3.getFormat(), j2, new AnkiImportReport(arrayList3), str3, linkedHashMap3);
/* 70 */                                                        ankiImportService5.active = preparedAnkiImport2;
/* 171 */                                                       objectRef5.element = null;
/* 383 */                                                       mutex.unlock(obj2);
/* 173 */                                                       return preparedAnkiImport2;
                                                            } catch (Throwable th3) {
/* 383 */                                                       th = th3;
                                                                mutex.unlock(obj2);
                                                                throw th;
                                                            }
                                                        } catch (Throwable th4) {
                                                            th = th4;
                                                            mutex = mutex3;
                                                            obj2 = obj3;
                                                            mutex.unlock(obj2);
                                                            throw th;
                                                        }
                                                    } catch (Throwable th5) {
                                                        th = th5;
                                                        mutex = mutex3;
                                                        obj2 = obj3;
                                                    }
                                                } catch (Throwable th6) {
                                                    th = th6;
                                                    mutex = mutex3;
                                                    obj2 = obj3;
                                                }
                                            } catch (Throwable th7) {
                                                th = th7;
                                                obj2 = obj3;
                                            }
                                        } catch (Throwable th8) {
                                            th = th8;
                                            mutex = mutex2;
                                            obj2 = obj3;
                                            mutex.unlock(obj2);
                                            throw th;
                                        }
                                    } catch (Throwable th9) {
                                        th = th9;
                                        obj2 = obj3;
                                        mutex.unlock(obj2);
                                        throw th;
                                    }
                                    break;
                                case 1:
/* 97 */                            int i10 = this.I$0;
                                    Ref.ObjectRef<PreparedPackage> objectRef6 = (Ref.ObjectRef) this.L$7;
                                    str = (String) this.L$6;
                                    Function1<ImportProgress, Unit> function5 = (Function1) this.L$5;
                                    InputStream inputStream4 = (InputStream) this.L$4;
                                    Ref.BooleanRef booleanRef4 = (Ref.BooleanRef) this.L$3;
                                    ankiImportService = (AnkiImportService) this.L$2;
                                    Mutex mutex5 = (Mutex) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    i = i10;
                                    inputStream = inputStream4;
                                    function1 = function5;
                                    obj3 = null;
                                    booleanRef = booleanRef4;
                                    objectRef = objectRef6;
                                    mutex = mutex5;
/* 354 */                           i2 = 0;
/* 70 */                            preparedAnkiImport = ankiImportService.active;
                                    if (preparedAnkiImport != null) {
                                        preparedAnkiImport.close();
                                    }
/* 100 */                           this.L$0 = $this$withContext;
                                    this.L$1 = mutex;
                                    this.L$2 = ankiImportService;
                                    this.L$3 = booleanRef;
                                    this.L$4 = inputStream;
                                    this.L$5 = function1;
                                    this.L$6 = str;
                                    this.L$7 = objectRef;
                                    this.I$0 = i;
/* 354 */                           this.I$1 = 0;
                                    this.label = 2;
                                    if (ankiImportService.initialize(this) == coroutine_suspended) {
/* 97 */                                return coroutine_suspended;
                                    }
/* 100 */                           ankiImportService2 = ankiImportService;
                                    objectRef2 = objectRef;
                                    mutex2 = mutex;
                                    inputStream2 = inputStream;
                                    booleanRef2 = booleanRef;
                                    i3 = i;
                                    function2 = function1;
                                    str2 = str;
/* 70 */                            restoreEpoch = ankiImportService2.coordinator.getRestoreEpoch();
/* 102 */                           booleanRef2.element = true;
/* 70 */                            ApkgReader apkgReader2 = ankiImportService2.reader;
/* 70 */                            File file2 = ankiImportService2.stagingRoot;
                                    this.L$0 = $this$withContext;
                                    this.L$1 = mutex2;
                                    this.L$2 = ankiImportService2;
                                    this.L$3 = function2;
                                    this.L$4 = objectRef2;
                                    this.L$5 = null;
                                    this.L$6 = null;
                                    this.L$7 = null;
                                    this.I$0 = i3;
                                    this.I$1 = i2;
                                    this.J$0 = restoreEpoch;
                                    this.label = 3;
                                    objOpen = apkgReader2.open(inputStream2, file2, function2, str2, this);
                                    if (objOpen == coroutine_suspended) {
/* 97 */                                return coroutine_suspended;
                                    }
/* 103 */                           mutex = mutex2;
                                    objectRef3 = objectRef2;
                                    i4 = i2;
                                    ankiImportService3 = ankiImportService2;
                                    function3 = function2;
                                    i5 = i3;
/* 103 */                           objectRef3.element = (PreparedPackage) objOpen;
                                    preparedPackage = (PreparedPackage) objOpen;
/* 104 */                           strNamespaceFor = MediaStore.INSTANCE.namespaceFor(preparedPackage.getMedia());
/* 105 */                           Map<String, AnkiMediaFile> media2 = preparedPackage.getMedia();
/* 356 */                           arrayList = new ArrayList();
                                    while (r21.hasNext()) {
                                        key = entry.getKey();
/* 105 */                               PreparedPackage preparedPackage5 = preparedPackage;
                                        mutex3 = mutex;
                                        strMimeFor = MediaStore.INSTANCE.mimeFor(entry.getValue());
                                        if (strMimeFor != null) {
                                            pair = TuplesKt.to(key, strMimeFor);
                                        } else {
                                            pair = null;
                                        }
/* 364 */                               if (pair != null) {
/* 364 */                                   arrayList.add(pair);
                                        }
/* 365 */                               preparedPackage = preparedPackage5;
                                        mutex = mutex3;
                                        break;
                                    }
/* 367 */                           preparedPackage2 = preparedPackage;
                                    mutex3 = mutex;
/* 105 */                           Map map4 = MapsKt.toMap((List) arrayList);
/* 106 */                           issues = preparedPackage2.getIssues();
                                    i6 = 0;
/* 369 */                           linkedHashMap = new LinkedHashMap();
                                    while (r18.hasNext()) {
/* 106 */                               cardId = ((ImportIssue) obj6).getCardId();
/* 373 */                               Iterable iterable2 = issues;
                                        int i11 = i6;
/* 372 */                               obj4 = linkedHashMap.get(cardId);
/* 374 */                               if (obj4 == null) {
/* 372 */                                   ArrayList arrayList5 = new ArrayList();
/* 372 */                                   linkedHashMap.put(cardId, arrayList5);
/* 377 */                                   obj5 = arrayList5;
                                        } else {
                                            obj5 = obj4;
                                        }
/* 380 */                               ((List) obj5).add(obj6);
                                        i6 = i11;
                                        issues = iterable2;
                                        i4 = i4;
                                    }
                                    int i12 = i4;
/* 107 */                           linkedHashMap2 = new LinkedHashMap();
/* 108 */                           HashMap map5 = new HashMap();
/* 109 */                           HashMap map6 = new HashMap();
/* 126 */                           arrayList2 = new ArrayList(preparedPackage2.getCardCount());
/* 127 */                           objectRef4 = objectRef3;
                                    z = true;
                                    int i13 = i5;
                                    j = restoreEpoch;
                                    ankiImportService$prepare$3$1$1 = new AnkiImportService$prepare$3$1$1($this$withContext, preparedPackage2, map5, ankiImportService3, linkedHashMap2, linkedHashMap, map4, arrayList2, function3, map6, null);
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                                    this.L$1 = mutex3;
                                    this.L$2 = ankiImportService3;
                                    this.L$3 = objectRef4;
                                    this.L$4 = strNamespaceFor;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(map4);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(linkedHashMap);
                                    this.L$7 = preparedPackage2;
                                    this.L$8 = linkedHashMap2;
                                    this.L$9 = SpillingKt.nullOutSpilledVariable(map5);
                                    this.L$10 = SpillingKt.nullOutSpilledVariable(map6);
                                    this.L$11 = arrayList2;
                                    this.I$0 = i13;
                                    this.I$1 = i12;
                                    ankiImportService4 = ankiImportService3;
                                    this.J$0 = j;
                                    this.label = 4;
                                    if (preparedPackage2.forEachCard(ankiImportService$prepare$3$1$1, this) == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    preparedPackage3 = preparedPackage2;
                                    j2 = j;
                                    arrayList3 = arrayList2;
                                    str3 = strNamespaceFor;
                                    mutex = mutex3;
                                    objectRef5 = objectRef4;
                                    ankiImportService5 = ankiImportService4;
                                    linkedHashMap3 = linkedHashMap2;
                                    obj2 = obj3;
                                    if (j2 == ankiImportService5.coordinator.getRestoreEpoch()) {
                                        z2 = z;
                                    } else {
                                        z2 = false;
                                    }
                                    if (!z2) {
/* 168 */                               throw new IllegalArgumentException("Data was restored during preflight; repeat import preflight".toString());
                                    }
/* 169 */                           PreparedAnkiImport preparedAnkiImport3 = new PreparedAnkiImport(ankiImportService5, preparedPackage3, preparedPackage3.getFormat(), j2, new AnkiImportReport(arrayList3), str3, linkedHashMap3);
/* 70 */                            ankiImportService5.active = preparedAnkiImport3;
/* 171 */                           objectRef5.element = null;
/* 383 */                           mutex.unlock(obj2);
/* 173 */                           return preparedAnkiImport3;
                                case 2:
/* 97 */                            int i14 = this.I$1;
                                    int i15 = this.I$0;
                                    Ref.ObjectRef<PreparedPackage> objectRef7 = (Ref.ObjectRef) this.L$7;
                                    String str5 = (String) this.L$6;
                                    Function1<ImportProgress, Unit> function6 = (Function1) this.L$5;
                                    InputStream inputStream5 = (InputStream) this.L$4;
                                    Ref.BooleanRef booleanRef5 = (Ref.BooleanRef) this.L$3;
                                    AnkiImportService ankiImportService6 = (AnkiImportService) this.L$2;
                                    obj3 = null;
                                    Mutex mutex6 = (Mutex) this.L$1;
                                    try {
                                        ResultKt.throwOnFailure($result);
                                        i2 = i14;
                                        booleanRef2 = booleanRef5;
                                        objectRef2 = objectRef7;
                                        inputStream2 = inputStream5;
                                        mutex2 = mutex6;
                                        ankiImportService2 = ankiImportService6;
                                        i3 = i15;
                                        function2 = function6;
                                        str2 = str5;
/* 70 */                                restoreEpoch = ankiImportService2.coordinator.getRestoreEpoch();
/* 102 */                               booleanRef2.element = true;
/* 70 */                                ApkgReader apkgReader3 = ankiImportService2.reader;
/* 70 */                                File file3 = ankiImportService2.stagingRoot;
                                        this.L$0 = $this$withContext;
                                        this.L$1 = mutex2;
                                        this.L$2 = ankiImportService2;
                                        this.L$3 = function2;
                                        this.L$4 = objectRef2;
                                        this.L$5 = null;
                                        this.L$6 = null;
                                        this.L$7 = null;
                                        this.I$0 = i3;
                                        this.I$1 = i2;
                                        this.J$0 = restoreEpoch;
                                        this.label = 3;
                                        objOpen = apkgReader3.open(inputStream2, file3, function2, str2, this);
                                        if (objOpen == coroutine_suspended) {
/* 97 */                                    return coroutine_suspended;
                                        }
/* 103 */                               mutex = mutex2;
                                        objectRef3 = objectRef2;
                                        i4 = i2;
                                        ankiImportService3 = ankiImportService2;
                                        function3 = function2;
                                        i5 = i3;
/* 103 */                               objectRef3.element = (PreparedPackage) objOpen;
                                        preparedPackage = (PreparedPackage) objOpen;
/* 104 */                               strNamespaceFor = MediaStore.INSTANCE.namespaceFor(preparedPackage.getMedia());
/* 105 */                               Map<String, AnkiMediaFile> media3 = preparedPackage.getMedia();
/* 356 */                               arrayList = new ArrayList();
                                        while (r21.hasNext()) {
                                            key = entry.getKey();
/* 105 */                                   PreparedPackage preparedPackage6 = preparedPackage;
                                            mutex3 = mutex;
                                            strMimeFor = MediaStore.INSTANCE.mimeFor(entry.getValue());
                                            if (strMimeFor != null) {
                                                pair = TuplesKt.to(key, strMimeFor);
                                            } else {
                                                pair = null;
                                            }
/* 364 */                                   if (pair != null) {
/* 364 */                                       arrayList.add(pair);
                                            }
/* 365 */                                   preparedPackage = preparedPackage6;
                                            mutex = mutex3;
                                            break;
                                        }
/* 367 */                               preparedPackage2 = preparedPackage;
                                        mutex3 = mutex;
/* 105 */                               Map map7 = MapsKt.toMap((List) arrayList);
/* 106 */                               issues = preparedPackage2.getIssues();
                                        i6 = 0;
/* 369 */                               linkedHashMap = new LinkedHashMap();
                                        while (r18.hasNext()) {
/* 106 */                                   cardId = ((ImportIssue) obj6).getCardId();
/* 373 */                                   Iterable iterable3 = issues;
                                            int i16 = i6;
/* 372 */                                   obj4 = linkedHashMap.get(cardId);
/* 374 */                                   if (obj4 == null) {
/* 372 */                                       ArrayList arrayList6 = new ArrayList();
/* 372 */                                       linkedHashMap.put(cardId, arrayList6);
/* 377 */                                       obj5 = arrayList6;
                                            } else {
                                                obj5 = obj4;
                                            }
/* 380 */                                   ((List) obj5).add(obj6);
                                            i6 = i16;
                                            issues = iterable3;
                                            i4 = i4;
                                        }
                                        int i17 = i4;
/* 107 */                               linkedHashMap2 = new LinkedHashMap();
/* 108 */                               HashMap map8 = new HashMap();
/* 109 */                               HashMap map9 = new HashMap();
/* 126 */                               arrayList2 = new ArrayList(preparedPackage2.getCardCount());
/* 127 */                               objectRef4 = objectRef3;
                                        z = true;
                                        int i18 = i5;
                                        j = restoreEpoch;
                                        ankiImportService$prepare$3$1$1 = new AnkiImportService$prepare$3$1$1($this$withContext, preparedPackage2, map8, ankiImportService3, linkedHashMap2, linkedHashMap, map7, arrayList2, function3, map9, null);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                                        this.L$1 = mutex3;
                                        this.L$2 = ankiImportService3;
                                        this.L$3 = objectRef4;
                                        this.L$4 = strNamespaceFor;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(map7);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(linkedHashMap);
                                        this.L$7 = preparedPackage2;
                                        this.L$8 = linkedHashMap2;
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(map8);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(map9);
                                        this.L$11 = arrayList2;
                                        this.I$0 = i18;
                                        this.I$1 = i17;
                                        ankiImportService4 = ankiImportService3;
                                        this.J$0 = j;
                                        this.label = 4;
                                        if (preparedPackage2.forEachCard(ankiImportService$prepare$3$1$1, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        preparedPackage3 = preparedPackage2;
                                        j2 = j;
                                        arrayList3 = arrayList2;
                                        str3 = strNamespaceFor;
                                        mutex = mutex3;
                                        objectRef5 = objectRef4;
                                        ankiImportService5 = ankiImportService4;
                                        linkedHashMap3 = linkedHashMap2;
                                        obj2 = obj3;
                                        if (j2 == ankiImportService5.coordinator.getRestoreEpoch()) {
                                            z2 = z;
                                        } else {
                                            z2 = false;
                                        }
                                        if (!z2) {
/* 168 */                                   throw new IllegalArgumentException("Data was restored during preflight; repeat import preflight".toString());
                                        }
/* 169 */                               PreparedAnkiImport preparedAnkiImport4 = new PreparedAnkiImport(ankiImportService5, preparedPackage3, preparedPackage3.getFormat(), j2, new AnkiImportReport(arrayList3), str3, linkedHashMap3);
/* 70 */                                ankiImportService5.active = preparedAnkiImport4;
/* 171 */                               objectRef5.element = null;
/* 383 */                               mutex.unlock(obj2);
/* 173 */                               return preparedAnkiImport4;
                                    } catch (Throwable th10) {
/* 383 */                               th = th10;
                                        mutex = mutex6;
                                        obj2 = null;
                                        mutex.unlock(obj2);
                                        throw th;
                                    }
                                case 3:
/* 97 */                            long j3 = this.J$0;
                                    i4 = this.I$1;
                                    i5 = this.I$0;
                                    objectRef3 = (Ref.ObjectRef) this.L$4;
                                    Function1<ImportProgress, Unit> function7 = (Function1) this.L$3;
                                    AnkiImportService ankiImportService7 = (AnkiImportService) this.L$2;
                                    obj3 = null;
                                    Mutex mutex7 = (Mutex) this.L$1;
                                    try {
                                        ResultKt.throwOnFailure($result);
                                        restoreEpoch = j3;
                                        function3 = function7;
                                        ankiImportService3 = ankiImportService7;
                                        mutex = mutex7;
                                        objOpen = $result;
/* 103 */                               objectRef3.element = (PreparedPackage) objOpen;
                                        preparedPackage = (PreparedPackage) objOpen;
/* 104 */                               strNamespaceFor = MediaStore.INSTANCE.namespaceFor(preparedPackage.getMedia());
/* 105 */                               Map<String, AnkiMediaFile> media4 = preparedPackage.getMedia();
/* 356 */                               arrayList = new ArrayList();
                                        while (r21.hasNext()) {
                                            key = entry.getKey();
/* 105 */                                   PreparedPackage preparedPackage7 = preparedPackage;
                                            mutex3 = mutex;
                                            strMimeFor = MediaStore.INSTANCE.mimeFor(entry.getValue());
                                            if (strMimeFor != null) {
                                                pair = TuplesKt.to(key, strMimeFor);
                                            } else {
                                                pair = null;
                                            }
/* 364 */                                   if (pair != null) {
/* 364 */                                       arrayList.add(pair);
                                            }
/* 365 */                                   preparedPackage = preparedPackage7;
                                            mutex = mutex3;
                                            break;
                                        }
/* 367 */                               preparedPackage2 = preparedPackage;
                                        mutex3 = mutex;
/* 105 */                               Map map10 = MapsKt.toMap((List) arrayList);
/* 106 */                               issues = preparedPackage2.getIssues();
                                        i6 = 0;
/* 369 */                               linkedHashMap = new LinkedHashMap();
                                        while (r18.hasNext()) {
/* 106 */                                   cardId = ((ImportIssue) obj6).getCardId();
/* 373 */                                   Iterable iterable4 = issues;
                                            int i19 = i6;
/* 372 */                                   obj4 = linkedHashMap.get(cardId);
/* 374 */                                   if (obj4 == null) {
/* 372 */                                       ArrayList arrayList7 = new ArrayList();
/* 372 */                                       linkedHashMap.put(cardId, arrayList7);
/* 377 */                                       obj5 = arrayList7;
                                            } else {
                                                obj5 = obj4;
                                            }
/* 380 */                                   ((List) obj5).add(obj6);
                                            i6 = i19;
                                            issues = iterable4;
                                            i4 = i4;
                                        }
                                        int i110 = i4;
/* 107 */                               linkedHashMap2 = new LinkedHashMap();
/* 108 */                               HashMap map11 = new HashMap();
/* 109 */                               HashMap map12 = new HashMap();
/* 126 */                               arrayList2 = new ArrayList(preparedPackage2.getCardCount());
/* 127 */                               objectRef4 = objectRef3;
                                        z = true;
                                        int i111 = i5;
                                        j = restoreEpoch;
                                        ankiImportService$prepare$3$1$1 = new AnkiImportService$prepare$3$1$1($this$withContext, preparedPackage2, map11, ankiImportService3, linkedHashMap2, linkedHashMap, map10, arrayList2, function3, map12, null);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                                        this.L$1 = mutex3;
                                        this.L$2 = ankiImportService3;
                                        this.L$3 = objectRef4;
                                        this.L$4 = strNamespaceFor;
                                        this.L$5 = SpillingKt.nullOutSpilledVariable(map10);
                                        this.L$6 = SpillingKt.nullOutSpilledVariable(linkedHashMap);
                                        this.L$7 = preparedPackage2;
                                        this.L$8 = linkedHashMap2;
                                        this.L$9 = SpillingKt.nullOutSpilledVariable(map11);
                                        this.L$10 = SpillingKt.nullOutSpilledVariable(map12);
                                        this.L$11 = arrayList2;
                                        this.I$0 = i111;
                                        this.I$1 = i110;
                                        ankiImportService4 = ankiImportService3;
                                        this.J$0 = j;
                                        this.label = 4;
                                        if (preparedPackage2.forEachCard(ankiImportService$prepare$3$1$1, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        preparedPackage3 = preparedPackage2;
                                        j2 = j;
                                        arrayList3 = arrayList2;
                                        str3 = strNamespaceFor;
                                        mutex = mutex3;
                                        objectRef5 = objectRef4;
                                        ankiImportService5 = ankiImportService4;
                                        linkedHashMap3 = linkedHashMap2;
                                        obj2 = obj3;
                                        if (j2 == ankiImportService5.coordinator.getRestoreEpoch()) {
                                            z2 = z;
                                        } else {
                                            z2 = false;
                                        }
                                        if (!z2) {
/* 168 */                                   throw new IllegalArgumentException("Data was restored during preflight; repeat import preflight".toString());
                                        }
/* 169 */                               PreparedAnkiImport preparedAnkiImport5 = new PreparedAnkiImport(ankiImportService5, preparedPackage3, preparedPackage3.getFormat(), j2, new AnkiImportReport(arrayList3), str3, linkedHashMap3);
/* 70 */                                ankiImportService5.active = preparedAnkiImport5;
/* 171 */                               objectRef5.element = null;
/* 383 */                               mutex.unlock(obj2);
/* 173 */                               return preparedAnkiImport5;
                                    } catch (Throwable th11) {
/* 383 */                               th = th11;
                                        mutex = mutex7;
                                        obj2 = null;
                                        mutex.unlock(obj2);
                                        throw th;
                                    }
                                case 4:
                                    long j4 = this.J$0;
                                    int i20 = this.I$1;
                                    int i21 = this.I$0;
                                    arrayList3 = (ArrayList) this.L$11;
                                    linkedHashMap3 = (LinkedHashMap) this.L$8;
                                    PreparedPackage preparedPackage8 = (PreparedPackage) this.L$7;
                                    String str6 = (String) this.L$4;
                                    objectRef5 = (Ref.ObjectRef) this.L$3;
                                    AnkiImportService ankiImportService8 = (AnkiImportService) this.L$2;
                                    mutex = (Mutex) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    preparedPackage3 = preparedPackage8;
                                    str3 = str6;
                                    ankiImportService5 = ankiImportService8;
                                    j2 = j4;
                                    z = true;
                                    obj2 = null;
                                    if (j2 == ankiImportService5.coordinator.getRestoreEpoch()) {
                                        z2 = z;
                                    } else {
                                        z2 = false;
                                    }
                                    if (!z2) {
/* 168 */                               throw new IllegalArgumentException("Data was restored during preflight; repeat import preflight".toString());
                                    }
/* 169 */                           PreparedAnkiImport preparedAnkiImport6 = new PreparedAnkiImport(ankiImportService5, preparedPackage3, preparedPackage3.getFormat(), j2, new AnkiImportReport(arrayList3), str3, linkedHashMap3);
/* 70 */                            ankiImportService5.active = preparedAnkiImport6;
/* 171 */                           objectRef5.element = null;
/* 383 */                           mutex.unlock(obj2);
/* 173 */                           return preparedAnkiImport6;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (Throwable th12) {
/* 383 */                   th = th12;
                            obj2 = obj;
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 110 */           public static final List<ImportIssue> invokeSuspend$lambda$0$compact(HashMap<Pair<String, String>, Pair<String, String>> map, long cardId, List<ImportIssue> list) {
                        Pair<String, String> pair;
/* 111 */               HashSet seen = new HashSet();
/* 112 */               ArrayList kept = new ArrayList(9);
/* 113 */               int omitted = 0;
                        for (ImportIssue importIssue : list) {
/* 115 */                   Pair<String, String> pair2 = TuplesKt.to(StringsKt.take(importIssue.getCode(), 64), StringsKt.take(importIssue.getDetail(), 160));
/* 116 */                   if (seen.add(pair2)) {
/* 117 */                       if (kept.size() < 8) {
/* 118 */                           HashMap<Pair<String, String>, Pair<String, String>> map2 = map;
/* 386 */                           Pair<String, String> pair3 = map2.get(pair2);
/* 387 */                           if (pair3 == null) {
/* 388 */                               pair = pair2;
/* 389 */                               map2.put(pair2, pair);
                                    } else {
/* 392 */                               pair = pair3;
                                    }
/* 118 */                           Pair<String, String> pair4 = pair;
/* 119 */                           kept.add(new ImportIssue(Long.valueOf(cardId), pair4.getFirst(), pair4.getSecond()));
                                } else {
/* 120 */                           omitted++;
                                }
                            }
                        }
/* 123 */               if (omitted > 0) {
                            kept.add(new ImportIssue(Long.valueOf(cardId), "more_issues", omitted + " additional diagnostics"));
                        }
/* 124 */               return kept;
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$prepare$4, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$prepare$4", f = "AnkiImportService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 174 */       static final class C04134 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Exception $error;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Ref.ObjectRef<PreparedPackage> $packageSource;
                    final /* synthetic */ Ref.BooleanRef $passedToReader;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04134(Ref.BooleanRef booleanRef, InputStream inputStream, Ref.ObjectRef<PreparedPackage> objectRef, Exception exc, Continuation<? super C04134> continuation) {
                        super(2, continuation);
                        this.$passedToReader = booleanRef;
                        this.$input = inputStream;
                        this.$packageSource = objectRef;
                        this.$error = exc;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04134(this.$passedToReader, this.$input, this.$packageSource, this.$error, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04134) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 175 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 178 */                           if (!this.$passedToReader.element) {
                                        this.$input.close();
                                    }
/* 179 */                           PreparedPackage preparedPackage = this.$packageSource.element;
                                    if (preparedPackage == null) {
                                        return null;
                                    }
                                    preparedPackage.close();
                                    return Unit.INSTANCE;
                                } catch (Exception cleanup) {
                                    ExceptionsKt.addSuppressed(this.$error, cleanup);
                                    return Unit.INSTANCE;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX WARN: Code duplicated, block: B:25:0x0083 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:26:0x0084  */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 185 */       public final Object commit(PreparedAnkiImport prepared, Continuation<? super ImportResult> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    Object obj;
                    Mutex mutex;
                    int i;
                    Object objCommitLocked;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    try {
                        switch (anonymousClass1.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                Mutex mutex2 = this.sourceOperations;
/* 359 */                       obj = null;
/* 363 */                       anonymousClass1.L$0 = prepared;
                                anonymousClass1.L$1 = mutex2;
/* 358 */                       anonymousClass1.I$0 = 0;
                                anonymousClass1.label = 1;
/* 359 */                       if (mutex2.lock(null, anonymousClass1) == coroutine_suspended) {
/* 186 */                           return coroutine_suspended;
                                }
                                mutex = mutex2;
/* 363 */                       i = 0;
/* 186 */                       anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                anonymousClass1.L$1 = mutex;
                                anonymousClass1.I$0 = i;
/* 365 */                       anonymousClass1.I$1 = 0;
                                anonymousClass1.label = 2;
                                objCommitLocked = commitLocked(prepared, anonymousClass1);
                                if (objCommitLocked == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ImportResult importResult = (ImportResult) objCommitLocked;
/* 367 */                       mutex.unlock(obj);
/* 186 */                       return importResult;
                            case 1:
/* 186 */                       i = anonymousClass1.I$0;
                                obj = null;
                                mutex = (Mutex) anonymousClass1.L$1;
                                prepared = (PreparedAnkiImport) anonymousClass1.L$0;
                                ResultKt.throwOnFailure($result);
/* 186 */                       anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                anonymousClass1.L$1 = mutex;
                                anonymousClass1.I$0 = i;
/* 365 */                       anonymousClass1.I$1 = 0;
                                anonymousClass1.label = 2;
                                objCommitLocked = commitLocked(prepared, anonymousClass1);
                                if (objCommitLocked == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                ImportResult importResult2 = (ImportResult) objCommitLocked;
/* 367 */                       mutex.unlock(obj);
/* 186 */                       return importResult2;
                            case 2:
                                int i2 = anonymousClass1.I$1;
                                int i3 = anonymousClass1.I$0;
                                obj = null;
                                mutex = (Mutex) anonymousClass1.L$1;
                                ResultKt.throwOnFailure($result);
                                objCommitLocked = $result;
                                ImportResult importResult3 = (ImportResult) objCommitLocked;
/* 367 */                       mutex.unlock(obj);
/* 186 */                       return importResult3;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    } catch (Throwable th) {
/* 367 */               mutex.unlock(obj);
                        throw th;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:145:? A[RETURN, SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:146:? A[RETURN, SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:60:0x02cb A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:70:0x031d A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:7:0x001a  */
                /* JADX WARN: Code duplicated, block: B:83:0x03e8 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:84:0x03e9  */
                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Type inference failed for: r0v62, types: [T, java.lang.Object, java.lang.Throwable] */
                /* JADX WARN: Type inference failed for: r0v89 */
                /* JADX WARN: Type inference failed for: r0v90 */
                /* JADX WARN: Type inference failed for: r0v91 */
                /* JADX WARN: Type inference failed for: r0v92 */
                /* JADX WARN: Type inference failed for: r5v46 */
/* 187 */       public final Object commitLocked(PreparedAnkiImport preparedAnkiImport, Continuation<? super ImportResult> continuation) throws Throwable {
                    C04091 c04091;
                    List list;
                    int totalCards;
                    Throwable th;
                    int i;
                    Set<Long> set;
                    Set set2;
                    int i2;
                    Map map;
                    List list2;
                    Object obj;
                    int i3;
                    int i4;
                    Ref.ObjectRef objectRef;
                    Set<Long> set3;
                    Set set4;
                    int i5;
                    Map map2;
                    Job job;
                    Ref.ObjectRef objectRef2;
                    int i6;
                    Set<Long> set5;
                    Object obj2;
                    int i7;
                    Ref.ObjectRef objectRef3;
                    CoroutineContext coroutineContextPlus;
                    AnonymousClass4 anonymousClass4;
                    CoroutineContext coroutineContextPlus2;
                    AnonymousClass4 anonymousClass5;
                    ?? r0;
                    Throwable th2;
                    ImportResult importResult;
                    CoroutineContext coroutineContextPlus3;
                    AnonymousClass7 anonymousClass7;
                    PreparedAnkiImport preparedAnkiImport2 = preparedAnkiImport;
                    if (continuation instanceof C04091) {
                        c04091 = (C04091) continuation;
                        if ((c04091.label & Integer.MIN_VALUE) != 0) {
                            c04091.label -= Integer.MIN_VALUE;
                        } else {
                            c04091 = new C04091(continuation);
                        }
                    } else {
                        c04091 = new C04091(continuation);
                    }
                    C04091 c04092 = c04091;
                    Object obj3 = c04092.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04092.label) {
                        case 0:
/* 188 */                   ResultKt.throwOnFailure(obj3);
/* 189 */                   preparedAnkiImport2.ensureOpen$app_debug();
/* 190 */                   if (!(this.active == preparedAnkiImport2)) {
                                throw new IllegalStateException("Import preview expired; select the package again".toString());
                            }
/* 191 */                   Set<Long> selected$app_debug = preparedAnkiImport2.getSelected$app_debug();
                            if (selected$app_debug == null) {
                                throw new IllegalStateException("Confirm compatible cards before import".toString());
                            }
/* 192 */                   List<ImportPreviewCard> cards = preparedAnkiImport2.getReport().getCards();
/* 370 */                   ArrayList arrayList = new ArrayList();
                            for (Object obj4 : cards) {
/* 371 */                       if (selected$app_debug.contains(Boxing.boxLong(((ImportPreviewCard) obj4).getSourceCardId()))) {
                                    arrayList.add(obj4);
                                }
                            }
/* 192 */                   list = arrayList;
/* 193 */                   List list3 = list;
/* 373 */                   ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list3, 10));
/* 374 */                   Iterator it = list3.iterator();
                            while (it.hasNext()) {
/* 375 */                       arrayList2.add(((ImportPreviewCard) it.next()).getGuid());
                            }
/* 193 */                   Set set6 = CollectionsKt.toSet(arrayList2);
/* 194 */                   int duplicateCards = preparedAnkiImport2.getReport().getDuplicateCards();
/* 195 */                   totalCards = (preparedAnkiImport2.getReport().getTotalCards() - duplicateCards) - list.size();
/* 196 */                   Map mutableMap = MapsKt.toMutableMap(preparedAnkiImport2.getReport().getReasons());
/* 197 */                   if (list.size() < preparedAnkiImport2.getReport().getCompatibleCards()) {
                                mutableMap.put("not_selected", Boxing.boxInt(preparedAnkiImport2.getReport().getCompatibleCards() - list.size()));
                            }
/* 198 */                   if (selected$app_debug.isEmpty()) {
                                try {
/* 200 */                           FileOperationCoordinator fileOperationCoordinator = this.coordinator;
                                    try {
                                        try {
                                            preparedAnkiImport2 = preparedAnkiImport;
                                            AnonymousClass3 anonymousClass3 = new AnonymousClass3(preparedAnkiImport, duplicateCards, totalCards, mutableMap, null);
                                            c04092.L$0 = preparedAnkiImport2;
                                            c04092.L$1 = SpillingKt.nullOutSpilledVariable(selected$app_debug);
                                            c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                            c04092.L$3 = SpillingKt.nullOutSpilledVariable(set6);
                                            c04092.L$4 = SpillingKt.nullOutSpilledVariable(mutableMap);
                                            c04092.I$0 = duplicateCards;
                                            c04092.I$1 = totalCards;
                                            c04092.label = 1;
                                            Object objWithLock = fileOperationCoordinator.withLock(anonymousClass3, c04092);
                                            if (objWithLock == coroutine_suspended) {
/* 188 */                                       return coroutine_suspended;
                                            }
/* 200 */                                   obj = objWithLock;
                                            i3 = totalCards;
                                            set = selected$app_debug;
                                            set2 = set6;
                                            i4 = duplicateCards;
                                            map = mutableMap;
                                            list2 = list;
/* 204 */                                   coroutineContextPlus2 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                            anonymousClass5 = new AnonymousClass4(preparedAnkiImport2, null);
                                            c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                            c04092.L$1 = SpillingKt.nullOutSpilledVariable(set);
                                            c04092.L$2 = SpillingKt.nullOutSpilledVariable(list2);
                                            c04092.L$3 = SpillingKt.nullOutSpilledVariable(set2);
                                            c04092.L$4 = SpillingKt.nullOutSpilledVariable(map);
                                            c04092.L$5 = obj;
                                            c04092.I$0 = i4;
                                            c04092.I$1 = i3;
                                            c04092.label = 2;
                                            if (BuildersKt.withContext(coroutineContextPlus2, anonymousClass5, c04092) == coroutine_suspended) {
/* 188 */                                       return coroutine_suspended;
                                            }
/* 200 */                                   return obj;
                                        } catch (Throwable th3) {
                                            th = th3;
                                            preparedAnkiImport2 = preparedAnkiImport;
                                            th = th;
                                            i = totalCards;
                                            set = selected$app_debug;
                                            set2 = set6;
                                            i2 = duplicateCards;
                                            map = mutableMap;
                                            list2 = list;
                                            coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                            anonymousClass4 = new AnonymousClass4(preparedAnkiImport2, null);
                                            c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                            c04092.L$1 = SpillingKt.nullOutSpilledVariable(set);
                                            c04092.L$2 = SpillingKt.nullOutSpilledVariable(list2);
                                            c04092.L$3 = SpillingKt.nullOutSpilledVariable(set2);
                                            c04092.L$4 = SpillingKt.nullOutSpilledVariable(map);
                                            c04092.L$5 = th;
                                            c04092.I$0 = i2;
                                            c04092.I$1 = i;
                                            c04092.label = 3;
                                            if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, c04092) == coroutine_suspended) {
/* 188 */                                       return coroutine_suspended;
                                            }
/* 206 */                                   throw th;
                                        }
                                    } catch (Throwable th4) {
                                        th = th4;
                                        preparedAnkiImport2 = preparedAnkiImport;
                                    }
                                } catch (Throwable th5) {
                                    th = th5;
                                }
                            } else {
                                Ref.ObjectRef objectRef4 = new Ref.ObjectRef();
/* 207 */                       objectRef = new Ref.ObjectRef();
/* 208 */                       Job job2 = (Job) c04092.getContext().get(Job.INSTANCE);
                                try {
/* 210 */                           CoroutineDispatcher io2 = Dispatchers.getIO();
                                    set3 = selected$app_debug;
                                    set4 = set6;
                                    map2 = mutableMap;
                                    try {
                                        AnonymousClass5 anonymousClass6 = new AnonymousClass5(list, this, preparedAnkiImport2, objectRef4, job2, duplicateCards, totalCards, map2, set4, null);
                                        totalCards = totalCards;
                                        try {
                                            c04092.L$0 = preparedAnkiImport2;
                                            c04092.L$1 = SpillingKt.nullOutSpilledVariable(set3);
                                            c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                            c04092.L$3 = SpillingKt.nullOutSpilledVariable(set4);
                                            c04092.L$4 = SpillingKt.nullOutSpilledVariable(map2);
                                            c04092.L$5 = objectRef4;
                                            c04092.L$6 = objectRef;
                                            c04092.L$7 = SpillingKt.nullOutSpilledVariable(job2);
                                            c04092.I$0 = duplicateCards;
                                            c04092.I$1 = totalCards;
                                            c04092.label = 4;
                                            Object objWithContext = BuildersKt.withContext(io2, anonymousClass6, c04092);
                                            if (objWithContext == coroutine_suspended) {
/* 188 */                                       return coroutine_suspended;
                                            }
/* 210 */                                   list = list;
                                            i6 = duplicateCards;
                                            map2 = map2;
                                            set5 = set3;
                                            job = job2;
                                            objectRef2 = objectRef4;
                                            obj2 = objWithContext;
                                            i7 = totalCards;
                                            objectRef3 = objectRef;
/* 319 */                                   coroutineContextPlus3 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                            anonymousClass7 = new AnonymousClass7(preparedAnkiImport2, objectRef2, objectRef3, null);
                                            c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                            c04092.L$1 = SpillingKt.nullOutSpilledVariable(set5);
                                            c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                            c04092.L$3 = SpillingKt.nullOutSpilledVariable(set4);
                                            c04092.L$4 = SpillingKt.nullOutSpilledVariable(map2);
                                            c04092.L$5 = SpillingKt.nullOutSpilledVariable(objectRef2);
                                            c04092.L$6 = SpillingKt.nullOutSpilledVariable(objectRef3);
                                            c04092.L$7 = SpillingKt.nullOutSpilledVariable(job);
                                            c04092.L$8 = obj2;
                                            c04092.I$0 = i6;
                                            c04092.I$1 = i7;
                                            c04092.label = 5;
                                            if (BuildersKt.withContext(coroutineContextPlus3, anonymousClass7, c04092) == coroutine_suspended) {
/* 188 */                                       return coroutine_suspended;
                                            }
/* 210 */                                   return obj2;
                                        } catch (Throwable th6) {
                                            list = list;
                                            i5 = duplicateCards;
                                            map2 = map2;
                                            job = job2;
                                            objectRef2 = objectRef4;
                                            r0 = th6;
                                            try {
/* 315 */                                       if (r0 instanceof CancellationException) {
                                                }
                                                try {
/* 316 */                                           objectRef.element = r0;
                                                    throw r0;
                                                } catch (Throwable th7) {
                                                    th2 = th7;
                                                    CoroutineContext coroutineContextPlus4 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                                    AnonymousClass7 anonymousClass8 = new AnonymousClass7(preparedAnkiImport2, objectRef2, objectRef, null);
                                                    c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                                    c04092.L$1 = SpillingKt.nullOutSpilledVariable(set3);
                                                    c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                                    c04092.L$3 = SpillingKt.nullOutSpilledVariable(set4);
                                                    c04092.L$4 = SpillingKt.nullOutSpilledVariable(map2);
                                                    c04092.L$5 = SpillingKt.nullOutSpilledVariable(objectRef2);
                                                    c04092.L$6 = SpillingKt.nullOutSpilledVariable(objectRef);
                                                    c04092.L$7 = SpillingKt.nullOutSpilledVariable(job);
                                                    c04092.L$8 = th2;
                                                    c04092.I$0 = i5;
                                                    c04092.I$1 = totalCards;
                                                    c04092.label = 7;
                                                    if (BuildersKt.withContext(coroutineContextPlus4, anonymousClass8, c04092) == coroutine_suspended) {
/* 188 */                                               return coroutine_suspended;
                                                    }
                                                    throw th2;
                                                }
                                            } catch (Throwable th8) {
                                                job = job;
                                                th2 = th8;
                                            }
                                        }
                                    } catch (Throwable th9) {
                                        totalCards = totalCards;
                                        list = list;
                                        i5 = duplicateCards;
                                        job = job2;
                                        objectRef2 = objectRef4;
                                        r0 = th9;
                                    }
                                } catch (Throwable th10) {
                                    set3 = selected$app_debug;
                                    set4 = set6;
                                    i5 = duplicateCards;
                                    map2 = mutableMap;
                                    job = job2;
                                    objectRef2 = objectRef4;
                                    r0 = th10;
                                }
                            }
                            break;
                        case 1:
                            int i8 = c04092.I$1;
                            int i9 = c04092.I$0;
                            map = (Map) c04092.L$4;
                            set2 = (Set) c04092.L$3;
                            list2 = (List) c04092.L$2;
                            set = (Set) c04092.L$1;
                            preparedAnkiImport2 = (PreparedAnkiImport) c04092.L$0;
                            try {
                                ResultKt.throwOnFailure(obj3);
                                i3 = i8;
                                i4 = i9;
                                obj = obj3;
/* 204 */                       coroutineContextPlus2 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass5 = new AnonymousClass4(preparedAnkiImport2, null);
                                c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                c04092.L$1 = SpillingKt.nullOutSpilledVariable(set);
                                c04092.L$2 = SpillingKt.nullOutSpilledVariable(list2);
                                c04092.L$3 = SpillingKt.nullOutSpilledVariable(set2);
                                c04092.L$4 = SpillingKt.nullOutSpilledVariable(map);
                                c04092.L$5 = obj;
                                c04092.I$0 = i4;
                                c04092.I$1 = i3;
                                c04092.label = 2;
                                if (BuildersKt.withContext(coroutineContextPlus2, anonymousClass5, c04092) == coroutine_suspended) {
/* 188 */                           return coroutine_suspended;
                                }
/* 200 */                       return obj;
                            } catch (Throwable th11) {
                                th = th11;
                                i = i8;
                                i2 = i9;
                                coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass4 = new AnonymousClass4(preparedAnkiImport2, null);
                                c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                c04092.L$1 = SpillingKt.nullOutSpilledVariable(set);
                                c04092.L$2 = SpillingKt.nullOutSpilledVariable(list2);
                                c04092.L$3 = SpillingKt.nullOutSpilledVariable(set2);
                                c04092.L$4 = SpillingKt.nullOutSpilledVariable(map);
                                c04092.L$5 = th;
                                c04092.I$0 = i2;
                                c04092.I$1 = i;
                                c04092.label = 3;
                                if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, c04092) == coroutine_suspended) {
/* 188 */                           return coroutine_suspended;
                                }
/* 206 */                       throw th;
                            }
                        case 2:
                            int i10 = c04092.I$1;
                            int i11 = c04092.I$0;
                            Object obj5 = c04092.L$5;
                            ResultKt.throwOnFailure(obj3);
/* 200 */                   return obj5;
                        case 3:
/* 188 */                   int i12 = c04092.I$1;
                            int i13 = c04092.I$0;
                            Throwable th12 = (Throwable) c04092.L$5;
                            ResultKt.throwOnFailure(obj3);
/* 206 */                   throw th12;
                        case 4:
                            int i14 = c04092.I$1;
                            int i15 = c04092.I$0;
                            job = (Job) c04092.L$7;
                            objectRef3 = (Ref.ObjectRef) c04092.L$6;
                            objectRef2 = (Ref.ObjectRef) c04092.L$5;
                            map2 = (Map) c04092.L$4;
                            set4 = (Set) c04092.L$3;
                            list = (List) c04092.L$2;
                            set5 = (Set) c04092.L$1;
                            preparedAnkiImport2 = (PreparedAnkiImport) c04092.L$0;
                            try {
                                ResultKt.throwOnFailure(obj3);
                                i7 = i14;
                                i6 = i15;
                                obj2 = obj3;
/* 319 */                       coroutineContextPlus3 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass7 = new AnonymousClass7(preparedAnkiImport2, objectRef2, objectRef3, null);
                                c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                c04092.L$1 = SpillingKt.nullOutSpilledVariable(set5);
                                c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                c04092.L$3 = SpillingKt.nullOutSpilledVariable(set4);
                                c04092.L$4 = SpillingKt.nullOutSpilledVariable(map2);
                                c04092.L$5 = SpillingKt.nullOutSpilledVariable(objectRef2);
                                c04092.L$6 = SpillingKt.nullOutSpilledVariable(objectRef3);
                                c04092.L$7 = SpillingKt.nullOutSpilledVariable(job);
                                c04092.L$8 = obj2;
                                c04092.I$0 = i6;
                                c04092.I$1 = i7;
                                c04092.label = 5;
                                if (BuildersKt.withContext(coroutineContextPlus3, anonymousClass7, c04092) == coroutine_suspended) {
/* 188 */                           return coroutine_suspended;
                                }
/* 210 */                       return obj2;
                            } catch (Throwable th13) {
                                objectRef = objectRef3;
                                set3 = set5;
                                totalCards = i14;
                                i5 = i15;
                                r0 = th13;
/* 315 */                       if ((r0 instanceof CancellationException) || (importResult = (ImportResult) objectRef2.element) == null) {
/* 316 */                           objectRef.element = r0;
                                    throw r0;
                                }
/* 319 */                       CoroutineContext coroutineContextPlus5 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                AnonymousClass7 anonymousClass9 = new AnonymousClass7(preparedAnkiImport2, objectRef2, objectRef, null);
                                c04092.L$0 = SpillingKt.nullOutSpilledVariable(preparedAnkiImport2);
                                c04092.L$1 = SpillingKt.nullOutSpilledVariable(set3);
                                c04092.L$2 = SpillingKt.nullOutSpilledVariable(list);
                                c04092.L$3 = SpillingKt.nullOutSpilledVariable(set4);
                                c04092.L$4 = SpillingKt.nullOutSpilledVariable(map2);
                                c04092.L$5 = SpillingKt.nullOutSpilledVariable(objectRef2);
                                c04092.L$6 = SpillingKt.nullOutSpilledVariable(objectRef);
                                c04092.L$7 = SpillingKt.nullOutSpilledVariable(job);
                                c04092.L$8 = SpillingKt.nullOutSpilledVariable(r0);
                                c04092.L$9 = importResult;
                                c04092.I$0 = i5;
                                c04092.I$1 = totalCards;
                                c04092.label = 6;
                                return BuildersKt.withContext(coroutineContextPlus5, anonymousClass9, c04092) == coroutine_suspended ? coroutine_suspended : importResult;
                            }
                        case 5:
                            int i16 = c04092.I$1;
                            int i17 = c04092.I$0;
                            Object obj6 = c04092.L$8;
                            ResultKt.throwOnFailure(obj3);
/* 210 */                   return obj6;
                        case 6:
                            int i18 = c04092.I$1;
                            int i19 = c04092.I$0;
                            ImportResult importResult2 = (ImportResult) c04092.L$9;
                            ResultKt.throwOnFailure(obj3);
                            return importResult2;
                        case 7:
                            int i20 = c04092.I$1;
                            int i21 = c04092.I$0;
                            Throwable th14 = (Throwable) c04092.L$8;
                            ResultKt.throwOnFailure(obj3);
                            throw th14;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$3, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/ImportResult;", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$3", f = "AnkiImportService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 198 */       static final class AnonymousClass3 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super ImportResult>, Object> {
                    final /* synthetic */ int $duplicateCount;
                    final /* synthetic */ PreparedAnkiImport $prepared;
                    final /* synthetic */ Map<String, Integer> $reasons;
                    final /* synthetic */ int $skipped;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass3(PreparedAnkiImport preparedAnkiImport, int i, int i2, Map<String, Integer> map, Continuation<? super AnonymousClass3> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedAnkiImport;
                        this.$duplicateCount = i;
                        this.$skipped = i2;
                        this.$reasons = map;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass3 anonymousClass3 = new AnonymousClass3(this.$prepared, this.$duplicateCount, this.$skipped, this.$reasons, continuation);
                        anonymousClass3.L$0 = obj;
                        return anonymousClass3;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super ImportResult> continuation) {
                        return ((AnonymousClass3) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 199 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 201 */                       $this$withLock.requireEpoch(this.$prepared.getRestoreEpoch());
/* 202 */                       return new ImportResult(0, this.$duplicateCount, this.$skipped, 0, 0, this.$reasons);
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$4, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$4", f = "AnkiImportService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 202 */       static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ PreparedAnkiImport $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass4(PreparedAnkiImport preparedAnkiImport, Continuation<? super AnonymousClass4> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedAnkiImport;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass4(this.$prepared, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 203 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.$prepared.close();
                                return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/ImportResult;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$5", f = "AnkiImportService.kt", i = {0, 1, 1}, l = {212, 214}, m = "invokeSuspend", n = {"needsSourceMedia", "staged", "needsSourceMedia"}, s = {"I$0", "L$0", "I$0"}, v = 1)
/* 208 */       static final class AnonymousClass5 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super ImportResult>, Object> {
                    final /* synthetic */ Job $caller;
                    final /* synthetic */ Ref.ObjectRef<ImportResult> $completed;
                    final /* synthetic */ int $duplicateCount;
                    final /* synthetic */ PreparedAnkiImport $prepared;
                    final /* synthetic */ Map<String, Integer> $reasons;
                    final /* synthetic */ List<ImportPreviewCard> $selectedCards;
                    final /* synthetic */ Set<String> $selectedGuids;
                    final /* synthetic */ int $skipped;
                    int I$0;
                    Object L$0;
                    int label;
                    final /* synthetic */ AnkiImportService this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass5(List<ImportPreviewCard> list, AnkiImportService ankiImportService, PreparedAnkiImport preparedAnkiImport, Ref.ObjectRef<ImportResult> objectRef, Job job, int i, int i2, Map<String, Integer> map, Set<String> set, Continuation<? super AnonymousClass5> continuation) {
                        super(2, continuation);
                        this.$selectedCards = list;
                        this.this$0 = ankiImportService;
                        this.$prepared = preparedAnkiImport;
                        this.$completed = objectRef;
                        this.$caller = job;
                        this.$duplicateCount = i;
                        this.$skipped = i2;
                        this.$reasons = map;
                        this.$selectedGuids = set;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass5(this.$selectedCards, this.this$0, this.$prepared, this.$completed, this.$caller, this.$duplicateCount, this.$skipped, this.$reasons, this.$selectedGuids, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super ImportResult> continuation) {
                        return ((AnonymousClass5) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:37:0x00cb A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:57:0x00ef  */
                    /* JADX WARN: Code duplicated, block: B:60:0x00e3 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:62:0x00d0 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 209 */           public final Object invokeSuspend(Object $result) throws Exception {
                        int i;
                        StagedMedia stagedMedia;
                        Object objStage;
                        StagedMedia staged;
                        Object objWithLock;
                        Throwable th;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 211 */                       Iterable iterable = this.$selectedCards;
                                PreparedAnkiImport preparedAnkiImport = this.$prepared;
                                int i2 = 0;
/* 347 */                       if (!(iterable instanceof Collection) || !((Collection) iterable).isEmpty()) {
/* 348 */                           Iterator it = iterable.iterator();
                                    while (it.hasNext()) {
/* 348 */                               if (preparedAnkiImport.getRevisions$app_debug().get(((ImportPreviewCard) it.next()).getGuid()) == null) {
                                            i2 = 1;
                                        }
                                    }
                                }
/* 211 */                       i = i2;
/* 212 */                       if (i != 0) {
                                    this.I$0 = i;
                                    this.label = 1;
/* 70 */                            objStage = this.this$0.media.stage(this.$prepared.getNamespace(), this.$prepared.getSource(), this);
                                    if (objStage == coroutine_suspended) {
/* 210 */                               return coroutine_suspended;
                                    }
/* 212 */                           stagedMedia = (StagedMedia) objStage;
                                } else {
                                    stagedMedia = null;
                                }
                                staged = stagedMedia;
                                try {
                                    this.L$0 = staged;
                                    this.I$0 = i;
                                    this.label = 2;
/* 70 */                            objWithLock = this.this$0.coordinator.withLock(new AnonymousClass1(this.$prepared, this.this$0, this.$caller, staged, this.$selectedCards, this.$duplicateCount, this.$skipped, this.$reasons, this.$selectedGuids, this.$completed, null), this);
                                    if (objWithLock == coroutine_suspended) {
/* 210 */                               return coroutine_suspended;
                                    }
                                    ImportResult importResult = (ImportResult) objWithLock;
/* 309 */                           if (staged != null) {
                                        try {
                                            staged.close();
                                        } catch (Exception cleanup) {
/* 310 */                                   if (this.$completed.element == null) {
                                                throw cleanup;
                                            }
                                        }
                                        break;
                                    }
/* 312 */                           return importResult;
                                } catch (Throwable th2) {
                                    th = th2;
                                    if (staged != null) {
                                        throw th;
                                    }
                                    try {
                                        staged.close();
                                        throw th;
                                    } catch (Exception cleanup2) {
/* 310 */                               if (this.$completed.element == null) {
                                            throw cleanup2;
                                        }
                                        throw th;
                                    }
                                }
                            case 1:
/* 210 */                       i = this.I$0;
                                ResultKt.throwOnFailure($result);
                                objStage = $result;
/* 212 */                       stagedMedia = (StagedMedia) objStage;
                                staged = stagedMedia;
                                this.L$0 = staged;
                                this.I$0 = i;
                                this.label = 2;
/* 70 */                        objWithLock = this.this$0.coordinator.withLock(new AnonymousClass1(this.$prepared, this.this$0, this.$caller, staged, this.$selectedCards, this.$duplicateCount, this.$skipped, this.$reasons, this.$selectedGuids, this.$completed, null), this);
                                if (objWithLock == coroutine_suspended) {
/* 210 */                           return coroutine_suspended;
                                }
                                ImportResult importResult2 = (ImportResult) objWithLock;
/* 309 */                       if (staged != null) {
                                    staged.close();
                                    break;
                                }
/* 312 */                       return importResult2;
                            case 2:
                                i = this.I$0;
                                StagedMedia staged2 = (StagedMedia) this.L$0;
                                try {
                                    ResultKt.throwOnFailure($result);
                                    staged = staged2;
                                    objWithLock = $result;
                                    ImportResult importResult3 = (ImportResult) objWithLock;
/* 309 */                           if (staged != null) {
                                        staged.close();
                                        break;
                                    }
/* 312 */                           return importResult3;
                                } catch (Throwable th3) {
                                    staged = staged2;
                                    th = th3;
                                    if (staged != null) {
                                        throw th;
                                    }
                                    staged.close();
                                    throw th;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiImportService.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/ImportResult;", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$5$1", f = "AnkiImportService.kt", i = {0, 0, 0, 1}, l = {218, 222}, m = "invokeSuspend", n = {"$this$withLock", "it\\2", "$i$a$-let-AnkiImportService$commitLocked$5$1$2\\2\\218\\0", "$this$withLock"}, s = {"L$0", "L$1", "I$0", "L$0"}, v = 1)
/* 212 */           static final class AnonymousClass1 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super ImportResult>, Object> {
                        final /* synthetic */ Job $caller;
                        final /* synthetic */ Ref.ObjectRef<ImportResult> $completed;
                        final /* synthetic */ int $duplicateCount;
                        final /* synthetic */ PreparedAnkiImport $prepared;
                        final /* synthetic */ Map<String, Integer> $reasons;
                        final /* synthetic */ List<ImportPreviewCard> $selectedCards;
                        final /* synthetic */ Set<String> $selectedGuids;
                        final /* synthetic */ int $skipped;
                        final /* synthetic */ StagedMedia $staged;
                        int I$0;
                        private /* synthetic */ Object L$0;
                        Object L$1;
                        int label;
                        final /* synthetic */ AnkiImportService this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(PreparedAnkiImport preparedAnkiImport, AnkiImportService ankiImportService, Job job, StagedMedia stagedMedia, List<ImportPreviewCard> list, int i, int i2, Map<String, Integer> map, Set<String> set, Ref.ObjectRef<ImportResult> objectRef, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.$prepared = preparedAnkiImport;
                            this.this$0 = ankiImportService;
                            this.$caller = job;
                            this.$staged = stagedMedia;
                            this.$selectedCards = list;
                            this.$duplicateCount = i;
                            this.$skipped = i2;
                            this.$reasons = map;
                            this.$selectedGuids = set;
                            this.$completed = objectRef;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.$prepared, this.this$0, this.$caller, this.$staged, this.$selectedCards, this.$duplicateCount, this.$skipped, this.$reasons, this.$selectedGuids, this.$completed, continuation);
                            anonymousClass1.L$0 = obj;
                            return anonymousClass1;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super ImportResult> continuation) {
                            return ((AnonymousClass1) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:25:0x0074  */
                        /* JADX WARN: Code duplicated, block: B:28:0x00ac A[RETURN] */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 213 */               public final Object invokeSuspend(Object $result) throws Throwable {
                            Job job;
                            Object objWithContext;
                            FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 215 */                           $this$withLock.requireEpoch(this.$prepared.getRestoreEpoch());
/* 70 */                            if (!(this.this$0.active == this.$prepared)) {
                                        throw new IllegalStateException("Import preview expired".toString());
                                    }
/* 217 */                           Job job2 = this.$caller;
                                    if (job2 != null) {
                                        JobKt.ensureActive(job2);
                                    }
/* 218 */                           StagedMedia stagedMedia = this.$staged;
                                    if (stagedMedia != null) {
/* 70 */                                MediaStore mediaStore = this.this$0.media;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(stagedMedia);
/* 347 */                               this.I$0 = 0;
                                        this.label = 1;
                                        if (mediaStore.promoteLocked($this$withLock, stagedMedia, this) == coroutine_suspended) {
/* 214 */                                   return coroutine_suspended;
                                        }
                                    }
/* 219 */                           job = this.$caller;
                                    if (job != null) {
                                        JobKt.ensureActive(job);
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                    this.L$1 = null;
                                    this.label = 2;
/* 222 */                           objWithContext = BuildersKt.withContext(NonCancellable.INSTANCE, new AnkiImportService$commitLocked$5$1$result$1(this.this$0, this.$prepared, this.$selectedCards, this.$duplicateCount, this.$caller, this.$skipped, this.$reasons, this.$selectedGuids, this.$staged, this.$completed, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 214 */                               return coroutine_suspended;
                                    }
                                    ImportResult result = (ImportResult) objWithContext;
/* 306 */                           return result;
                                case 1:
                                    int i = this.I$0;
                                    ResultKt.throwOnFailure($result);
/* 219 */                           job = this.$caller;
                                    if (job != null) {
                                        JobKt.ensureActive(job);
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                    this.L$1 = null;
                                    this.label = 2;
/* 222 */                           objWithContext = BuildersKt.withContext(NonCancellable.INSTANCE, new AnkiImportService$commitLocked$5$1$result$1(this.this$0, this.$prepared, this.$selectedCards, this.$duplicateCount, this.$caller, this.$skipped, this.$reasons, this.$selectedGuids, this.$staged, this.$completed, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 214 */                               return coroutine_suspended;
                                    }
                                    ImportResult result2 = (ImportResult) objWithContext;
/* 306 */                           return result2;
                                case 2:
                                    ResultKt.throwOnFailure($result);
                                    objWithContext = $result;
                                    ImportResult result3 = (ImportResult) objWithContext;
/* 306 */                           return result3;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.AnkiImportService$commitLocked$7, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.AnkiImportService$commitLocked$7", f = "AnkiImportService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 317 */       static final class AnonymousClass7 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Ref.ObjectRef<ImportResult> $completed;
                    final /* synthetic */ Ref.ObjectRef<Throwable> $failure;
                    final /* synthetic */ PreparedAnkiImport $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass7(PreparedAnkiImport preparedAnkiImport, Ref.ObjectRef<ImportResult> objectRef, Ref.ObjectRef<Throwable> objectRef2, Continuation<? super AnonymousClass7> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedAnkiImport;
                        this.$completed = objectRef;
                        this.$failure = objectRef2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass7(this.$prepared, this.$completed, this.$failure, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass7) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 318 */           public final Object invokeSuspend(Object $result) throws Exception {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 320 */                           this.$prepared.close();
                                    break;
                                } catch (Exception cleanup) {
/* 321 */                           if (this.$completed.element == null) {
/* 322 */                               if (this.$failure.element == null) {
                                            throw cleanup;
                                        }
                                        Throwable th = this.$failure.element;
                                        Intrinsics.checkNotNull(th);
                                        ExceptionsKt.addSuppressed(th, cleanup);
                                    }
                                }
/* 325 */                       return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 328 */       public final void release$app_debug(PreparedAnkiImport prepared) {
                    Intrinsics.checkNotNullParameter(prepared, "prepared");
/* 329 */           if (this.active == prepared) {
                        this.active = null;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 330 */       public final boolean compatible(AnkiModelEntity local, AnkiModel source) {
/* 331 */           Json json = Json.INSTANCE;
                    String templates = local.getTemplates();
/* 377 */           SerializersModule serializersModule = json.getSerializersModule();
                    KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                    MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
                    Iterable iterable = (Iterable) json.decodeFromString(SerializersKt.serializer(serializersModule, kTypeTypeOf), templates);
/* 378 */           Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 379 */           Iterator it = iterable.iterator();
                    while (it.hasNext()) {
/* 380 */               arrayList.add(Integer.valueOf(((AnkiTemplate) it.next()).getOrdinal()));
                    }
                    List templateOrdinals = (List) arrayList;
/* 332 */           if (local.getKind() == source.getKind() && local.getOriginalStockKind() == source.getOriginalStockKind() && Intrinsics.areEqual(AnkiRepository.INSTANCE.strings(local.getFieldNames()), source.getFieldNames())) {
/* 334 */               Iterable templates2 = source.getTemplates();
/* 382 */               Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(templates2, 10));
/* 383 */               Iterator it2 = templates2.iterator();
                        while (it2.hasNext()) {
/* 384 */                   arrayList2.add(Integer.valueOf(((AnkiTemplate) it2.next()).getOrdinal()));
                        }
/* 334 */               if (Intrinsics.areEqual(templateOrdinals, (List) arrayList2)) {
                            return true;
                        }
                    }
                    return false;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 335 */       public final AnkiModel asModel(AnkiModelEntity local) {
/* 337 */           long j = Long.parseLong(local.getSourceModelId());
                    String name = local.getName();
                    int kind = local.getKind();
                    List<String> listStrings = AnkiRepository.INSTANCE.strings(local.getFieldNames());
/* 338 */           Json json = Json.INSTANCE;
                    String templates = local.getTemplates();
/* 386 */           SerializersModule serializersModule = json.getSerializersModule();
                    KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                    MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 336 */           return new AnkiModel(j, name, kind, listStrings, (List) json.decodeFromString(SerializersKt.serializer(serializersModule, kTypeTypeOf), templates), local.getCss(), local.getOriginalStockKind());
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 340 */       public final String summary(RenderedSide side) {
                    String string = StringsKt.trim((CharSequence) Html.fromHtml(new Regex("\\[sound:[^\\]]+]").replace(side.getHtml(), "[音频]"), 0).toString()).toString();
                    if (StringsKt.isBlank(string)) {
                        string = "[媒体]";
                    }
                    String text = string;
/* 342 */           int[] points = text.codePoints().limit(160L).toArray();
/* 343 */           Intrinsics.checkNotNull(points);
                    return new String(points, 0, points.length);
                }
            }

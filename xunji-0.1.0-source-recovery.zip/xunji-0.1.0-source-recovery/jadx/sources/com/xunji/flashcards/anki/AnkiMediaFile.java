            package com.xunji.flashcards.anki;

            import java.io.File;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ApkgReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0081\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003¢\u0006\u0004\b\n\u0010\u000bJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J;\u0010\u0019\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u001a\u001a\u00020\u001b2\b\u0010\u001c\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001J\t\u0010\u001f\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\rR\u0011\u0010\t\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\r¨\u0006 "}, d2 = {"Lcom/xunji/flashcards/anki/AnkiMediaFile;", "", "originalName", "", "file", "Ljava/io/File;", "size", "", "sha1", "sha256", "<init>", "(Ljava/lang/String;Ljava/io/File;JLjava/lang/String;Ljava/lang/String;)V", "getOriginalName", "()Ljava/lang/String;", "getFile", "()Ljava/io/File;", "getSize", "()J", "getSha1", "getSha256", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 29 */    public final /* data */ class AnkiMediaFile {
                public static final int $stable = 8;
                private final File file;
                private final String originalName;
                private final String sha1;
                private final String sha256;
                private final long size;

                public static /* synthetic */ AnkiMediaFile copy$default(AnkiMediaFile ankiMediaFile, String str, File file, long j, String str2, String str3, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = ankiMediaFile.originalName;
                    }
                    if ((i & 2) != 0) {
                        file = ankiMediaFile.file;
                    }
                    if ((i & 4) != 0) {
                        j = ankiMediaFile.size;
                    }
                    if ((i & 8) != 0) {
                        str2 = ankiMediaFile.sha1;
                    }
                    if ((i & 16) != 0) {
                        str3 = ankiMediaFile.sha256;
                    }
                    long j2 = j;
                    return ankiMediaFile.copy(str, file, j2, str2, str3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getOriginalName() {
                    return this.originalName;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final File getFile() {
                    return this.file;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getSize() {
                    return this.size;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getSha1() {
                    return this.sha1;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getSha256() {
                    return this.sha256;
                }

                public final AnkiMediaFile copy(String originalName, File file, long size, String sha1, String sha256) {
                    Intrinsics.checkNotNullParameter(originalName, "originalName");
                    Intrinsics.checkNotNullParameter(file, "file");
                    Intrinsics.checkNotNullParameter(sha1, "sha1");
                    Intrinsics.checkNotNullParameter(sha256, "sha256");
                    return new AnkiMediaFile(originalName, file, size, sha1, sha256);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiMediaFile)) {
                        return false;
                    }
                    AnkiMediaFile ankiMediaFile = (AnkiMediaFile) other;
                    return Intrinsics.areEqual(this.originalName, ankiMediaFile.originalName) && Intrinsics.areEqual(this.file, ankiMediaFile.file) && this.size == ankiMediaFile.size && Intrinsics.areEqual(this.sha1, ankiMediaFile.sha1) && Intrinsics.areEqual(this.sha256, ankiMediaFile.sha256);
                }

                public int hashCode() {
                    return (((((((this.originalName.hashCode() * 31) + this.file.hashCode()) * 31) + Long.hashCode(this.size)) * 31) + this.sha1.hashCode()) * 31) + this.sha256.hashCode();
                }

                public String toString() {
                    return "AnkiMediaFile(originalName=" + this.originalName + ", file=" + this.file + ", size=" + this.size + ", sha1=" + this.sha1 + ", sha256=" + this.sha256 + ")";
                }

/* 30 */        public AnkiMediaFile(String originalName, File file, long size, String sha1, String sha256) {
                    Intrinsics.checkNotNullParameter(originalName, "originalName");
                    Intrinsics.checkNotNullParameter(file, "file");
                    Intrinsics.checkNotNullParameter(sha1, "sha1");
                    Intrinsics.checkNotNullParameter(sha256, "sha256");
                    this.originalName = originalName;
                    this.file = file;
                    this.size = size;
                    this.sha1 = sha1;
                    this.sha256 = sha256;
                }

/* 30 */        public final File getFile() {
/* 31 */            return this.file;
                }

/* 30 */        public final String getOriginalName() {
/* 31 */            return this.originalName;
                }

/* 30 */        public final String getSha1() {
/* 31 */            return this.sha1;
                }

/* 30 */        public final String getSha256() {
/* 31 */            return this.sha256;
                }

/* 30 */        public final long getSize() {
/* 31 */            return this.size;
                }
            }

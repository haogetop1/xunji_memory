            package com.xunji.flashcards.anki;

            import android.database.Cursor;
            import android.database.sqlite.SQLiteDatabase;
            import android.database.sqlite.SQLiteException;
            import androidx.autofill.HintConstants;
            import androidx.core.app.NotificationCompat;
            import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiSourceCard;
            import com.xunji.core.anki.AnkiSourceDeck;
            import com.xunji.core.anki.AnkiSourceNote;
            import com.xunji.core.anki.AnkiStorageValidator;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.anki.ImportIssue;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.core.anki.ImportStage;
            import java.io.ByteArrayOutputStream;
            import java.io.Closeable;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Comparator;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Locale;
            import java.util.Map;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.IntIterator;
            import kotlin.collections.MapsKt;
            import kotlin.comparisons.ComparisonsKt;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.IntRange;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.JobKt;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonPrimitive;
            
            /* JADX INFO: compiled from: AnkiPackageDatabase.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0010\"\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0001\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J*\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\"2\u0012\u0010#\u001a\u000e\u0012\u0004\u0012\u00020%\u0012\u0004\u0012\u00020\u001e0$J$\u0010&\u001a\u00020\u001e2\u0006\u0010'\u001a\u00020(2\u0012\u0010)\u001a\u000e\u0012\u0004\u0012\u00020(\u0012\u0004\u0012\u00020(0\u0013H\u0002J \u0010*\u001a\u00020(2\u0006\u0010+\u001a\u00020(2\u0006\u0010,\u001a\u00020\u000f2\u0006\u0010!\u001a\u00020\"H\u0002J\u0010\u0010-\u001a\u00020\u001e2\u0006\u0010!\u001a\u00020\"H\u0002J\u0010\u0010.\u001a\u00020\u001e2\u0006\u0010/\u001a\u00020\u000bH\u0002J\u001c\u00100\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00140\u00132\u0006\u0010!\u001a\u00020\"H\u0002J\u0016\u00101\u001a\b\u0012\u0004\u0012\u00020\n022\u0006\u0010!\u001a\u00020\"H\u0002J\u0010\u00103\u001a\u0002042\u0006\u00105\u001a\u000206H\u0002J\u0006\u00107\u001a\u000206J\u000e\u00108\u001a\u0002092\u0006\u00105\u001a\u000206J\u000e\u0010:\u001a\u0002042\u0006\u0010;\u001a\u00020\nJ\u000e\u0010<\u001a\u00020\u000b2\u0006\u0010;\u001a\u00020\nJ\u0010\u0010=\u001a\u00020\n2\u0006\u0010>\u001a\u00020(H\u0002J\b\u0010?\u001a\u00020\u001eH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R*\u0010\b\u001a\u001e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\tj\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b`\fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000R\u001e\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u000e\u001a\u00020\u000f@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R6\u0010\u0015\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00140\u00132\u0012\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00140\u0013@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R*\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u00190\u00182\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00190\u0018@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001c¨\u0006@"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiPackageDatabase;", "Ljava/io/Closeable;", "db", "Landroid/database/sqlite/SQLiteDatabase;", "limits", "Lcom/xunji/flashcards/anki/ApkgLimits;", "<init>", "(Landroid/database/sqlite/SQLiteDatabase;Lcom/xunji/flashcards/anki/ApkgLimits;)V", "models", "Ljava/util/LinkedHashMap;", "", "Lcom/xunji/core/anki/AnkiModel;", "Lkotlin/collections/LinkedHashMap;", "modelsBytes", "value", "", "cardCount", "getCardCount", "()I", "", "Lcom/xunji/core/anki/AnkiSourceDeck;", "decks", "getDecks", "()Ljava/util/Map;", "", "Lcom/xunji/core/anki/ImportIssue;", "issues", "getIssues", "()Ljava/util/List;", "validate", "", "format", "Lcom/xunji/flashcards/anki/PackageFormat;", "context", "Lkotlin/coroutines/CoroutineContext;", NotificationCompat.CATEGORY_PROGRESS, "Lkotlin/Function1;", "Lcom/xunji/core/anki/ImportProgress;", "schema", "table", "", "expected", "collectionJson", "column", "maximum", "readModernModels", "cache", "model", "readModernDecks", "validateNotes", "", "note", "Lcom/xunji/core/anki/AnkiSourceNote;", "cursor", "Landroid/database/Cursor;", "cards", "card", "Lcom/xunji/core/anki/AnkiSourceCard;", "noteForCard", "cardId", "modelForCard", "scalar", "query", "close", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public final class AnkiPackageDatabase implements Closeable {
                public static final int $stable = 8;
                private int cardCount;
                private final SQLiteDatabase db;
                private Map<Long, AnkiSourceDeck> decks;
                private List<ImportIssue> issues;
                private final ApkgLimits limits;
                private final LinkedHashMap<Long, AnkiModel> models;
                private long modelsBytes;

/* 13 */        public AnkiPackageDatabase(SQLiteDatabase db, ApkgLimits limits) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(limits, "limits");
                    this.db = db;
                    this.limits = limits;
/* 15 */            this.models = new LinkedHashMap<>();
/* 18 */            this.decks = MapsKt.emptyMap();
/* 19 */            this.issues = CollectionsKt.emptyList();
                }

/* 16 */        public final int getCardCount() {
/* 17 */            return this.cardCount;
                }

/* 17 */        public final Map<Long, AnkiSourceDeck> getDecks() {
/* 18 */            return this.decks;
                }

/* 18 */        public final List<ImportIssue> getIssues() {
/* 19 */            return this.issues;
                }

                /* JADX WARN: Code duplicated, block: B:22:0x010b  */
/* 21 */        public final void validate(PackageFormat format, CoroutineContext context, Function1<? super ImportProgress, Unit> progress) {
                    Throwable th;
                    char c;
                    String str;
                    boolean z;
                    char c2;
                    char c3;
                    long j;
                    JsonPrimitive jsonPrimitive;
                    Throwable th2;
                    Throwable th3;
                    char c4;
                    CoroutineContext context2 = context;
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(context2, "context");
                    Intrinsics.checkNotNullParameter(progress, "progress");
/* 22 */            int version = format == PackageFormat.LATEST ? 18 : 11;
                    schema("col", MapsKt.plus(MapsKt.mapOf(TuplesKt.to("id", "integer"), TuplesKt.to("ver", "integer")), version == 11 ? MapsKt.mapOf(TuplesKt.to("models", "text"), TuplesKt.to("decks", "text")) : MapsKt.emptyMap()));
                    String str2 = "flds";
                    schema("notes", MapsKt.mapOf(TuplesKt.to("id", "integer"), TuplesKt.to("guid", "text"), TuplesKt.to("mid", "integer"), TuplesKt.to("tags", "text"), TuplesKt.to("flds", "text")));
                    schema("cards", MapsKt.mapOf(TuplesKt.to("id", "integer"), TuplesKt.to("nid", "integer"), TuplesKt.to("did", "integer"), TuplesKt.to("ord", "integer"), TuplesKt.to("odid", "integer")));
/* 26 */            Cursor cursorRawQuery = this.db.rawQuery("SELECT ver,typeof(ver) FROM col", null);
                    try {
                        Cursor cursor = cursorRawQuery;
/* 26 */                if (cursor.moveToFirst()) {
                            try {
                                if (Intrinsics.areEqual(cursor.getString(1), "integer")) {
                                    c = 1;
                                    str = "decks";
                                    if (cursor.getLong(0) == version && !cursor.moveToNext()) {
                                        z = true;
                                    }
                                } else {
                                    c = 1;
                                    str = "decks";
                                }
                                z = false;
                            } catch (Throwable th4) {
                                th = th4;
                            }
                        } else {
                            c = 1;
                            str = "decks";
                            z = false;
                        }
                        if (z) {
                            Unit unit = Unit.INSTANCE;
                            CloseableKt.closeFinally(cursorRawQuery, null);
/* 27 */                    String str3 = HintConstants.AUTOFILL_HINT_NAME;
                            if (version == 18) {
/* 28 */                        Pair[] pairArr = new Pair[3];
                                pairArr[0] = TuplesKt.to("id", "integer");
/* 27 */                        pairArr[c] = TuplesKt.to(HintConstants.AUTOFILL_HINT_NAME, "text");
/* 23 */                        pairArr[2] = TuplesKt.to("config", "blob");
                                c2 = c;
                                schema("notetypes", MapsKt.mapOf(pairArr));
/* 29 */                        Pair[] pairArr2 = new Pair[3];
                                pairArr2[0] = TuplesKt.to("ntid", "integer");
                                pairArr2[c2] = TuplesKt.to("ord", "integer");
/* 23 */                        pairArr2[2] = TuplesKt.to(HintConstants.AUTOFILL_HINT_NAME, "text");
                                j = 0;
                                schema("fields", MapsKt.mapOf(pairArr2));
/* 30 */                        Pair[] pairArr3 = new Pair[4];
                                pairArr3[0] = TuplesKt.to("ntid", "integer");
                                pairArr3[c2] = TuplesKt.to("ord", "integer");
/* 23 */                        pairArr3[2] = TuplesKt.to(HintConstants.AUTOFILL_HINT_NAME, "text");
                                pairArr3[3] = TuplesKt.to("config", "blob");
                                schema("templates", MapsKt.mapOf(pairArr3));
/* 31 */                        Pair[] pairArr4 = new Pair[2];
                                c3 = 0;
                                pairArr4[0] = TuplesKt.to("id", "integer");
/* 27 */                        pairArr4[c2] = TuplesKt.to(HintConstants.AUTOFILL_HINT_NAME, "text");
                                schema(str, MapsKt.mapOf(pairArr4));
/* 32 */                        readModernModels(context2);
                                this.decks = readModernDecks(context2);
                            } else {
/* 34 */                        c2 = c;
                                String str4 = str;
                                c3 = 0;
                                j = 0;
                                Map jsonObject = JsonElementKt.getJsonObject(BoundedJson.INSTANCE.parse(collectionJson("models", this.limits.getMaxModelsBytes(), context2)));
                                int i = 0;
/* 171 */                       Iterator<Map.Entry<String, JsonElement>> it = jsonObject.entrySet().iterator();
                                while (it.hasNext()) {
                                    Map.Entry<String, JsonElement> next = it.next();
                                    String key = next.getKey();
                                    JsonElement value = next.getValue();
/* 35 */                            JobKt.ensureActive(context2);
                                    JsonObject jsonObject2 = JsonElementKt.getJsonObject(value);
/* 1 */                             long jIdentifier = AnkiPackageDatabaseKt.identifier(jsonObject2);
/* 36 */                            if (((!Intrinsics.areEqual(key, String.valueOf(jIdentifier)) || jIdentifier <= 0) ? (char) 0 : c2) == 0) {
                                        throw new IllegalArgumentException("Invalid legacy model ID".toString());
                                    }
/* 37 */                            Iterable jsonArray = JsonElementKt.getJsonArray((JsonElement) MapsKt.getValue(jsonObject2, str2));
/* 172 */                           String str5 = str2;
                                    int version2 = version;
                                    Map map = jsonObject;
                                    Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(jsonArray, 10));
/* 173 */                           Iterator<JsonElement> it2 = jsonArray.iterator();
                                    while (it2.hasNext()) {
/* 174 */                               arrayList.add(JsonElementKt.getJsonObject((JsonElement) it2.next()));
                                    }
/* 176 */                           Iterable iterableSortedWith = CollectionsKt.sortedWith((List) arrayList, new Comparator() { // from class: com.xunji.flashcards.anki.AnkiPackageDatabase$validate$lambda$1$$inlined$sortedBy$1
                                        /* JADX WARN: Multi-variable type inference failed */
                                        @Override // java.util.Comparator
/* 101 */                               public final int compare(T t, T t2) {
/* 102 */                                   return ComparisonsKt.compareValues(Integer.valueOf(AnkiPackageDatabaseKt.ordinal((JsonObject) t)), Integer.valueOf(AnkiPackageDatabaseKt.ordinal((JsonObject) t2)));
                                        }
                                    });
                                    Iterable iterable = iterableSortedWith;
/* 172 */                           Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 177 */                           Iterator it3 = iterable.iterator();
                                    while (it3.hasNext()) {
/* 178 */                               arrayList2.add(Integer.valueOf(AnkiPackageDatabaseKt.ordinal((JsonObject) it3.next())));
                                        iterable = iterable;
                                    }
/* 1 */                             AnkiPackageDatabaseKt.ordinals((List) arrayList2);
/* 38 */                            Iterable jsonArray2 = JsonElementKt.getJsonArray((JsonElement) MapsKt.getValue(jsonObject2, "tmpls"));
/* 180 */                           Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(jsonArray2, 10));
/* 181 */                           Iterator<JsonElement> it4 = jsonArray2.iterator();
                                    while (it4.hasNext()) {
/* 182 */                               arrayList3.add(JsonElementKt.getJsonObject((JsonElement) it4.next()));
/* 38 */                                jsonArray2 = jsonArray2;
                                    }
                                    Iterable iterable2 = (List) arrayList3;
/* 184 */                           Collection arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable2, 10));
                                    Iterable<JsonObject> iterable3 = iterable2;
                                    int i2 = 0;
                                    for (JsonObject jsonObject3 : iterable3) {
/* 186 */                               Iterable iterable4 = iterable2;
/* 186 */                               arrayList4.add(new AnkiTemplate(AnkiPackageDatabaseKt.ordinal(jsonObject3), AnkiPackageDatabaseKt.string(jsonObject3, HintConstants.AUTOFILL_HINT_NAME), AnkiPackageDatabaseKt.string(jsonObject3, "qfmt"), AnkiPackageDatabaseKt.string(jsonObject3, "afmt")));
                                        iterable2 = iterable4;
/* 38 */                                iterable3 = iterable3;
                                        i2 = i2;
                                        i = i;
                                        it = it;
                                        next = next;
                                    }
                                    int i3 = i;
                                    Iterator<Map.Entry<String, JsonElement>> it5 = it;
/* 188 */                           List listSortedWith = CollectionsKt.sortedWith((List) arrayList4, new Comparator() { // from class: com.xunji.flashcards.anki.AnkiPackageDatabase$validate$lambda$1$$inlined$sortedBy$2
                                        /* JADX WARN: Multi-variable type inference failed */
                                        @Override // java.util.Comparator
/* 101 */                               public final int compare(T t, T t2) {
/* 102 */                                   return ComparisonsKt.compareValues(Integer.valueOf(((AnkiTemplate) t).getOrdinal()), Integer.valueOf(((AnkiTemplate) t2).getOrdinal()));
                                        }
                                    });
/* 1 */                             long jNumber = AnkiPackageDatabaseKt.number(jsonObject2, ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY);
                                    if (((0 > jNumber || jNumber >= 2147483648L) ? (char) 0 : c2) == 0) {
                                        throw new IllegalArgumentException("Invalid legacy model kind".toString());
                                    }
/* 1 */                             String strString = AnkiPackageDatabaseKt.string(jsonObject2, HintConstants.AUTOFILL_HINT_NAME);
                                    int i4 = (int) jNumber;
                                    Iterable iterable5 = iterableSortedWith;
/* 189 */                           Collection arrayList5 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable5, 10));
/* 190 */                           Iterator it6 = iterable5.iterator();
                                    while (it6.hasNext()) {
/* 191 */                               arrayList5.add(AnkiPackageDatabaseKt.string((JsonObject) it6.next(), HintConstants.AUTOFILL_HINT_NAME));
/* 191 */                               i4 = i4;
                                    }
/* 192 */                           int i5 = i4;
                                    ArrayList arrayList6 = (List) arrayList5;
/* 1 */                             String strString2 = AnkiPackageDatabaseKt.string(jsonObject2, "css");
                                    JsonElement jsonElement = (JsonElement) jsonObject2.get((Object) "originalStockKind");
                                    cache(new AnkiModel(jIdentifier, strString, i5, arrayList6, listSortedWith, strString2, (jsonElement == null || (jsonPrimitive = JsonElementKt.getJsonPrimitive(jsonElement)) == null) ? 0 : JsonElementKt.getInt(jsonPrimitive)));
                                    str2 = str5;
                                    version = version2;
                                    jsonObject = map;
                                    i = i3;
                                    it = it5;
                                }
/* 42 */                        Map jsonObject4 = JsonElementKt.getJsonObject(BoundedJson.INSTANCE.parse(collectionJson(str4, this.limits.getMaxDecksBytes(), context2)));
                                int i6 = 0;
/* 194 */                       Collection arrayList7 = new ArrayList(jsonObject4.size());
                                Map map2 = jsonObject4;
                                int i7 = 0;
                                for (Map.Entry<String, JsonElement> entry : map2.entrySet()) {
                                    String key2 = entry.getKey();
                                    JsonElement value2 = entry.getValue();
/* 43 */                            JobKt.ensureActive(context2);
                                    JsonObject jsonObject5 = JsonElementKt.getJsonObject(value2);
                                    Map map3 = map2;
                                    int i8 = i7;
/* 1 */                             long jIdentifier2 = AnkiPackageDatabaseKt.identifier(jsonObject5);
/* 44 */                            Map map4 = jsonObject4;
                                    if (((!Intrinsics.areEqual(key2, String.valueOf(jIdentifier2)) || jIdentifier2 <= 0) ? (char) 0 : c2) == 0) {
                                        throw new IllegalArgumentException("Invalid legacy deck ID".toString());
                                    }
/* 196 */                           arrayList7.add(TuplesKt.to(Long.valueOf(jIdentifier2), new AnkiSourceDeck(jIdentifier2, AnkiPackageDatabaseKt.deckName(AnkiPackageDatabaseKt.string(jsonObject5, str3)))));
                                    map2 = map3;
                                    i7 = i8;
                                    jsonObject4 = map4;
                                    i6 = i6;
                                    str3 = str3;
                                }
/* 42 */                        this.decks = MapsKt.toMap((List) arrayList7);
                            }
/* 48 */                    long count = scalar("SELECT count(*) FROM cards");
                            if (((j > count || count > ((long) this.limits.getMaxCards())) ? c3 : c2) == 0) {
                                throw new IllegalArgumentException(("Source card count exceeds " + this.limits.getMaxCards()).toString());
                            }
                            this.cardCount = (int) count;
/* 49 */                    Set<Long> setValidateNotes = validateNotes(context2);
/* 50 */                    Cursor cursorRawQuery2 = this.db.rawQuery("SELECT c.id FROM cards c LEFT JOIN notes n ON c.nid=n.id WHERE n.id IS NULL LIMIT 1", null);
                            try {
/* 50 */                        if (cursorRawQuery2.moveToFirst()) {
                                    try {
/* 50 */                                throw new IllegalArgumentException("Card references a missing note".toString());
                                    } catch (Throwable th5) {
                                        th2 = th5;
                                    }
                                } else {
                                    Unit unit2 = Unit.INSTANCE;
                                    CloseableKt.closeFinally(cursorRawQuery2, null);
/* 51 */                            List problems = new ArrayList();
/* 52 */                            Cursor cursorCards = cards();
                                    try {
/* 52 */                                for (Cursor cursor2 = cursorCards; cursor2.moveToNext(); cursor2 = cursor2) {
/* 53 */                                    JobKt.ensureActive(context2);
                                            AnkiSourceCard ankiSourceCardCard = card(cursor2);
/* 54 */                                    if (!this.decks.containsKey(Long.valueOf(ankiSourceCardCard.getEffectiveDeckId()))) {
                                                try {
                                                    problems.add(new ImportIssue(Long.valueOf(ankiSourceCardCard.getSourceId()), "missing_deck", "Missing source deck " + ankiSourceCardCard.getEffectiveDeckId()));
                                                } catch (Throwable th6) {
                                                    th3 = th6;
                                                    try {
                                                        throw th3;
                                                    } catch (Throwable th7) {
                                                        CloseableKt.closeFinally(cursorCards, th3);
                                                        throw th7;
                                                    }
                                                }
                                            }
/* 55 */                                    if (setValidateNotes.contains(Long.valueOf(ankiSourceCardCard.getNoteId()))) {
                                                problems.add(new ImportIssue(Long.valueOf(ankiSourceCardCard.getSourceId()), "field_count", "Source note field count differs from its model"));
                                            }
/* 56 */                                    AnkiModel ankiModelModelForCard = modelForCard(ankiSourceCardCard.getSourceId());
/* 57 */                                    if (ankiModelModelForCard.getKind() == 0) {
                                                Iterable templates = ankiModelModelForCard.getTemplates();
/* 198 */                                       if ((templates instanceof Collection) && ((Collection) templates).isEmpty()) {
                                                    c4 = c3;
                                                } else {
/* 199 */                                           Iterator it7 = templates.iterator();
                                                    while (true) {
                                                        if (!it7.hasNext()) {
                                                            c4 = c3;
                                                            break;
                                                        }
                                                        AnkiModel ankiModel = ankiModelModelForCard;
/* 199 */                                               if ((((AnkiTemplate) it7.next()).getOrdinal() == ankiSourceCardCard.getOrdinal() ? c2 : c3) != 0) {
                                                            c4 = c2;
                                                            break;
                                                        }
                                                        ankiModelModelForCard = ankiModel;
                                                    }
                                                }
/* 57 */                                        if (c4 == 0) {
/* 57 */                                            throw new IllegalArgumentException("Card references a missing template ordinal".toString());
                                                }
                                            }
                                            context2 = context;
                                            count = count;
                                        }
                                        Unit unit3 = Unit.INSTANCE;
/* 52 */                                CloseableKt.closeFinally(cursorCards, null);
/* 59 */                                this.issues = CollectionsKt.toList(problems);
                                        progress.invoke(new ImportProgress(ImportStage.DATABASE, this.cardCount, Long.valueOf(this.cardCount)));
/* 60 */                                return;
                                    } catch (Throwable th8) {
                                        th3 = th8;
                                    }
                                }
                            } catch (Throwable th9) {
                                th2 = th9;
                            }
                            try {
                                throw th2;
                            } catch (Throwable th10) {
                                CloseableKt.closeFinally(cursorRawQuery2, th2);
                                throw th10;
                            }
                        }
                        try {
/* 26 */                    throw new IllegalArgumentException("Unsupported or invalid SQLite schema".toString());
                        } catch (Throwable th11) {
                            th = th11;
                        }
                    } catch (Throwable th12) {
                        th = th12;
                    }
                    try {
                        throw th;
                    } catch (Throwable th13) {
                        CloseableKt.closeFinally(cursorRawQuery, th);
                        throw th13;
                    }
                }

                /* JADX WARN: Code duplicated, block: B:11:0x003d  */
                /* JADX WARN: Code duplicated, block: B:49:0x010b  */
                /* JADX WARN: Code duplicated, block: B:53:0x0117  */
/* 61 */        private final void schema(String table, Map<String, String> expected) {
                    boolean z;
                    Map.Entry<String, String> next;
                    String keys;
/* 62 */            Cursor cursorRawQuery = this.db.rawQuery("SELECT type,sql FROM sqlite_master WHERE name=?", new String[]{table});
                    try {
                        Cursor cursor = cursorRawQuery;
                        boolean z2 = false;
/* 62 */                if (cursor.moveToFirst() && Intrinsics.areEqual(cursor.getString(0), "table")) {
                            String string = cursor.getString(1);
                            Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                            if (StringsKt.contains((CharSequence) string, (CharSequence) "VIRTUAL", true)) {
                                z = false;
                            } else {
                                z = true;
                            }
                        } else {
                            z = false;
                        }
                        if (!z) {
/* 62 */                    throw new IllegalArgumentException(("Missing/unsupported source table " + table).toString());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(cursorRawQuery, null);
/* 63 */                Map columns = new LinkedHashMap();
/* 64 */                Cursor cursorRawQuery2 = this.db.rawQuery("PRAGMA table_info(" + table + ")", null);
                        try {
                            Cursor cursor2 = cursorRawQuery2;
/* 64 */                    while (cursor2.moveToNext()) {
                                String string2 = cursor2.getString(1);
                                String string3 = cursor2.getString(2);
                                Intrinsics.checkNotNullExpressionValue(string3, "getString(...)");
                                Locale ROOT = Locale.ROOT;
                                Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                                String lowerCase = string3.toLowerCase(ROOT);
                                Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                                columns.put(string2, lowerCase);
                            }
                            Unit unit2 = Unit.INSTANCE;
                            CloseableKt.closeFinally(cursorRawQuery2, null);
/* 201 */                   if (!expected.isEmpty()) {
/* 202 */                       Iterator<Map.Entry<String, String>> it = expected.entrySet().iterator();
/* 202 */                       do {
                                    if (!it.hasNext()) {
/* 203 */                               z2 = true;
                                        break;
                                    } else {
                                        next = it.next();
                                    }
/* 202 */                       } while (Intrinsics.areEqual(columns.get(next.getKey()), next.getValue()));
                            } else {
                                z2 = true;
                            }
/* 65 */                    if (!z2) {
/* 65 */                        throw new IllegalArgumentException(("Unsupported columns in source table " + table).toString());
                            }
                            switch (table) {
                                case "fields":
/* 68 */                            keys = "ntid,ord";
                                    break;
                                case "cards":
                                case "decks":
                                case "notes":
                                case "notetypes":
/* 67 */                            keys = "id";
                                    break;
                                case "templates":
/* 68 */                            keys = "ntid,ord";
                                    break;
                                default:
/* 69 */                            keys = null;
                                    break;
                            }
/* 71 */                    if (keys != null) {
                                Cursor cursorRawQuery3 = this.db.rawQuery("SELECT 1 FROM " + table + " GROUP BY " + keys + " HAVING count(*)>1 LIMIT 1", null);
                                try {
/* 72 */                            if (cursorRawQuery3.moveToFirst()) {
/* 72 */                                throw new IllegalArgumentException(("Duplicate source key in " + table + " (" + keys + ")").toString());
                                    }
                                    Unit unit3 = Unit.INSTANCE;
/* 71 */                            CloseableKt.closeFinally(cursorRawQuery3, null);
                                } catch (Throwable th) {
                                    try {
                                        throw th;
                                    } catch (Throwable th2) {
                                        CloseableKt.closeFinally(cursorRawQuery3, th);
                                        throw th2;
                                    }
                                }
                            }
                        } catch (Throwable th3) {
                            try {
                                throw th3;
                            } catch (Throwable th4) {
                                CloseableKt.closeFinally(cursorRawQuery2, th3);
                                throw th4;
                            }
                        }
                    } catch (Throwable th5) {
                        try {
                            throw th5;
                        } catch (Throwable th6) {
                            CloseableKt.closeFinally(cursorRawQuery, th5);
                            throw th6;
                        }
                    }
                }

/* 75 */        private final String collectionJson(String column, int maximum, CoroutineContext context) {
                    long length = scalar("SELECT length(CAST(" + column + " AS BLOB)) FROM col");
                    if (!(0 <= length && length <= ((long) maximum))) {
/* 76 */                throw new IllegalArgumentException(("Legacy " + column + " JSON exceeds " + maximum + " bytes").toString());
                    }
/* 77 */            ByteArrayOutputStream output = new ByteArrayOutputStream((int) length);
                    long offset = 0;
                    while (offset < length) {
/* 79 */                JobKt.ensureActive(context);
/* 80 */                Cursor cursorRawQuery = this.db.rawQuery("SELECT substr(CAST(" + column + " AS BLOB),?,?) FROM col", new String[]{String.valueOf(1 + offset), String.valueOf(Math.min(65536L, length - offset))});
                        try {
                            Cursor cursor = cursorRawQuery;
/* 81 */                    if (!cursor.moveToFirst()) {
/* 81 */                        throw new IllegalArgumentException("Missing collection JSON".toString());
                            }
                            byte[] blob = cursor.getBlob(0);
/* 82 */                    Intrinsics.checkNotNull(blob);
                            if (!(blob.length == 0) && blob.length <= 65536) {
                                output.write(blob);
                                offset += (long) blob.length;
                                Unit unit = Unit.INSTANCE;
/* 80 */                        CloseableKt.closeFinally(cursorRawQuery, null);
                            } else {
/* 82 */                        throw new IllegalArgumentException("Truncated collection JSON chunk".toString());
                            }
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorRawQuery, th);
                                throw th2;
                            }
                        }
                    }
/* 85 */            byte[] byteArray = output.toByteArray();
                    Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                    return BoundedApkgKt.utf8(byteArray);
                }

                /* JADX WARN: Code duplicated, block: B:109:0x02c7  */
                /* JADX WARN: Code duplicated, block: B:111:0x02ca  */
                /* JADX WARN: Code duplicated, block: B:117:0x02f9 A[Catch: all -> 0x0351, TRY_LEAVE, TryCatch #12 {all -> 0x0351, blocks: (B:115:0x02ef, B:117:0x02f9), top: B:212:0x02ef }] */
                /* JADX WARN: Code duplicated, block: B:241:0x01d7 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:242:0x01bb A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:243:0x035b A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:244:0x0341 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:51:0x015c  */
                /* JADX WARN: Code duplicated, block: B:54:0x0161  */
                /* JADX WARN: Code duplicated, block: B:60:0x0190 A[Catch: all -> 0x01c7, TRY_LEAVE, TryCatch #6 {all -> 0x01c7, blocks: (B:58:0x0186, B:60:0x0190, B:65:0x01bd, B:66:0x01c6), top: B:201:0x0186, outer: #3 }] */
/* 87 */        private final void readModernModels(CoroutineContext context) {
                    Throwable th;
                    Throwable th2;
                    Throwable th3;
                    boolean z;
                    int iCheckedOrdinal;
                    String str;
                    List list;
                    Cursor cursorRawQuery;
                    Throwable th4;
                    Cursor cursor;
                    AnkiProtoReader.ModelConfig modelConfig;
                    boolean z2;
                    int iCheckedOrdinal2;
                    int i;
                    Cursor cursorRawQuery2;
                    Cursor cursor2;
                    String str2 = "x";
                    String str3 = "integer";
/* 88 */            Cursor cursorRawQuery3 = this.db.rawQuery("SELECT id,length(CAST(name AS BLOB)),length(config),typeof(id),typeof(name),typeof(config) FROM notetypes ORDER BY id", null);
                    try {
                        Cursor cursor3 = cursorRawQuery3;
/* 170 */               int i2 = 0;
/* 88 */                while (cursor3.moveToNext()) {
/* 89 */                    JobKt.ensureActive(context);
                            if (!(Intrinsics.areEqual(cursor3.getString(3), str3) && Intrinsics.areEqual(cursor3.getString(4), "text") && Intrinsics.areEqual(cursor3.getString(5), "blob"))) {
/* 89 */                        throw new IllegalArgumentException("Invalid note type scalar types".toString());
                            }
/* 90 */                    long j = cursor3.getLong(0);
                            if (!(j > 0)) {
/* 90 */                        throw new IllegalArgumentException("Invalid model ID".toString());
                            }
                            if (!(cursor3.getLong(1) + cursor3.getLong(2) <= ((long) this.limits.getMaxModelStoredBytes()))) {
                                throw new IllegalArgumentException(("Source model scalar exceeds " + this.limits.getMaxModelStoredBytes() + " bytes").toString());
                            }
/* 92 */                    Cursor cursorRawQuery4 = this.db.rawQuery("SELECT CAST(name AS BLOB),config FROM notetypes WHERE id=?", new String[]{String.valueOf(j)});
                            try {
                                Cursor cursor4 = cursorRawQuery4;
/* 92 */                        if (cursor4.moveToFirst()) {
                                    byte[] blob = cursor4.getBlob(0);
                                    Intrinsics.checkNotNullExpressionValue(blob, "getBlob(...)");
                                    String strUtf8 = BoundedApkgKt.utf8(blob);
                                    AnkiProtoReader ankiProtoReader = AnkiProtoReader.INSTANCE;
                                    byte[] blob2 = cursor4.getBlob(1);
                                    Intrinsics.checkNotNullExpressionValue(blob2, "getBlob(...)");
                                    Pair pair = TuplesKt.to(strUtf8, ankiProtoReader.modelConfig(blob2));
                                    CloseableKt.closeFinally(cursorRawQuery4, null);
                                    String str4 = (String) pair.component1();
                                    AnkiProtoReader.ModelConfig modelConfig2 = (AnkiProtoReader.ModelConfig) pair.component2();
                                    String str5 = str2;
/* 93 */                            AnkiStorageValidator.ModelBudget modelBudget = new AnkiStorageValidator.ModelBudget(CollectionsKt.listOf((Object[]) new String[]{str4, modelConfig2.getCss(), String.valueOf(j), StringsKt.repeat(str2, 36), StringsKt.repeat(str2, 64)}), this.limits.getMaxModelStoredBytes());
/* 94 */                            Iterable iterable = (List) new ArrayList();
/* 95 */                            Cursor cursorRawQuery5 = this.db.rawQuery("SELECT ord,length(CAST(name AS BLOB)),typeof(ntid),typeof(ord),typeof(name) FROM fields WHERE ntid=? ORDER BY ord", new String[]{String.valueOf(j)});
                                    try {
                                        Cursor cursor5 = cursorRawQuery5;
/* 95 */                                while (cursor5.moveToNext()) {
                                            try {
/* 96 */                                        JobKt.ensureActive(context);
                                                Cursor cursor6 = cursor3;
                                                try {
                                                    if (Intrinsics.areEqual(cursor5.getString(2), str3)) {
                                                        try {
                                                            if (Intrinsics.areEqual(cursor5.getString(3), str3) && Intrinsics.areEqual(cursor5.getString(4), "text")) {
                                                                modelConfig = modelConfig2;
/* 88 */                                                        z2 = cursor5.getLong(1) <= ((long) this.limits.getMaxModelStoredBytes());
                                                                if (!z2) {
/* 96 */                                                            throw new IllegalArgumentException("Invalid model field scalar".toString());
                                                                }
                                                                try {
/* 1 */                                                             iCheckedOrdinal2 = AnkiPackageDatabaseKt.checkedOrdinal(cursor5.getLong(0));
                                                                    i = i2;
                                                                    try {
/* 88 */                                                                cursorRawQuery2 = this.db.rawQuery("SELECT CAST(name AS BLOB) FROM fields WHERE ntid=? AND ord=?", new String[]{String.valueOf(j), String.valueOf(iCheckedOrdinal2)});
                                                                        try {
                                                                            cursor2 = cursorRawQuery2;
/* 97 */                                                                    if (!cursor2.moveToFirst()) {
                                                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                                                            }
                                                                            byte[] blob3 = cursor2.getBlob(0);
                                                                            Intrinsics.checkNotNullExpressionValue(blob3, "getBlob(...)");
                                                                            String strUtf9 = BoundedApkgKt.utf8(blob3);
                                                                            CloseableKt.closeFinally(cursorRawQuery2, null);
/* 98 */                                                                    modelBudget.addField(strUtf9);
                                                                            ((Collection) iterable).add(TuplesKt.to(Integer.valueOf(iCheckedOrdinal2), strUtf9));
                                                                            cursor3 = cursor6;
                                                                            modelConfig2 = modelConfig;
                                                                            i2 = i;
                                                                        } catch (Throwable th5) {
                                                                            try {
                                                                                throw th5;
                                                                            } catch (Throwable th6) {
                                                                                CloseableKt.closeFinally(cursorRawQuery2, th5);
                                                                                throw th6;
                                                                            }
                                                                        }
                                                                    } catch (Throwable th7) {
                                                                        th2 = th7;
                                                                    }
                                                                } catch (Throwable th8) {
                                                                    th2 = th8;
                                                                }
                                                            } else {
/* 96 */                                                        modelConfig = modelConfig2;
                                                            }
                                                            if (!z2) {
/* 96 */                                                        throw new IllegalArgumentException("Invalid model field scalar".toString());
                                                            }
/* 1 */                                                     iCheckedOrdinal2 = AnkiPackageDatabaseKt.checkedOrdinal(cursor5.getLong(0));
                                                            i = i2;
/* 88 */                                                    cursorRawQuery2 = this.db.rawQuery("SELECT CAST(name AS BLOB) FROM fields WHERE ntid=? AND ord=?", new String[]{String.valueOf(j), String.valueOf(iCheckedOrdinal2)});
                                                            cursor2 = cursorRawQuery2;
/* 97 */                                                    if (!cursor2.moveToFirst()) {
                                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                                            }
                                                            byte[] blob4 = cursor2.getBlob(0);
                                                            Intrinsics.checkNotNullExpressionValue(blob4, "getBlob(...)");
                                                            String strUtf10 = BoundedApkgKt.utf8(blob4);
                                                            CloseableKt.closeFinally(cursorRawQuery2, null);
/* 98 */                                                    modelBudget.addField(strUtf10);
                                                            ((Collection) iterable).add(TuplesKt.to(Integer.valueOf(iCheckedOrdinal2), strUtf10));
                                                            cursor3 = cursor6;
                                                            modelConfig2 = modelConfig;
                                                            i2 = i;
                                                            th2 = th7;
                                                        } catch (Throwable th9) {
                                                            th2 = th9;
                                                        }
                                                    } else {
/* 96 */                                                modelConfig = modelConfig2;
                                                        if (!z2) {
/* 96 */                                                    throw new IllegalArgumentException("Invalid model field scalar".toString());
                                                        }
/* 1 */                                                 iCheckedOrdinal2 = AnkiPackageDatabaseKt.checkedOrdinal(cursor5.getLong(0));
                                                        i = i2;
/* 88 */                                                cursorRawQuery2 = this.db.rawQuery("SELECT CAST(name AS BLOB) FROM fields WHERE ntid=? AND ord=?", new String[]{String.valueOf(j), String.valueOf(iCheckedOrdinal2)});
                                                        cursor2 = cursorRawQuery2;
/* 97 */                                                if (!cursor2.moveToFirst()) {
                                                            throw new IllegalArgumentException("Failed requirement.".toString());
                                                        }
                                                        byte[] blob5 = cursor2.getBlob(0);
                                                        Intrinsics.checkNotNullExpressionValue(blob5, "getBlob(...)");
                                                        String strUtf11 = BoundedApkgKt.utf8(blob5);
                                                        CloseableKt.closeFinally(cursorRawQuery2, null);
/* 98 */                                                modelBudget.addField(strUtf11);
                                                        ((Collection) iterable).add(TuplesKt.to(Integer.valueOf(iCheckedOrdinal2), strUtf11));
                                                        cursor3 = cursor6;
                                                        modelConfig2 = modelConfig;
                                                        i2 = i;
                                                        th2 = th7;
                                                    }
                                                } catch (Throwable th10) {
                                                    th2 = th10;
                                                }
                                            } catch (Throwable th11) {
                                                th2 = th11;
                                            }
                                            try {
                                                throw th2;
                                            } catch (Throwable th12) {
                                                CloseableKt.closeFinally(cursorRawQuery5, th2);
                                                throw th12;
                                            }
                                        }
/* 99 */                                Cursor cursor7 = cursor3;
                                        AnkiProtoReader.ModelConfig modelConfig3 = modelConfig2;
                                        int i3 = i2;
                                        try {
                                            Unit unit = Unit.INSTANCE;
/* 95 */                                    CloseableKt.closeFinally(cursorRawQuery5, null);
/* 100 */                                   Iterable iterable2 = iterable;
/* 204 */                                   Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable2, 10));
/* 205 */                                   Iterator it = iterable2.iterator();
                                            while (it.hasNext()) {
/* 206 */                                       arrayList.add(Integer.valueOf(((Number) ((Pair) it.next()).getFirst()).intValue()));
                                            }
/* 1 */                                     AnkiPackageDatabaseKt.ordinals((List) arrayList);
                                            List arrayList2 = new ArrayList();
/* 101 */                                   Cursor cursorRawQuery6 = this.db.rawQuery("SELECT ord,length(CAST(name AS BLOB)),length(config),typeof(ntid),typeof(ord),typeof(name),typeof(config) FROM templates WHERE ntid=? ORDER BY ord", new String[]{String.valueOf(j)});
                                            try {
                                                Cursor cursor8 = cursorRawQuery6;
/* 101 */                                       while (cursor8.moveToNext()) {
                                                    try {
/* 102 */                                               JobKt.ensureActive(context);
                                                        if (!Intrinsics.areEqual(cursor8.getString(3), str3)) {
/* 102 */                                                   z = false;
                                                            if (z) {
/* 102 */                                                       throw new IllegalArgumentException("Invalid template scalar".toString());
                                                            }
/* 1 */                                                     iCheckedOrdinal = AnkiPackageDatabaseKt.checkedOrdinal(cursor8.getLong(0));
                                                            str = str3;
                                                            list = arrayList2;
/* 104 */                                                   cursorRawQuery = this.db.rawQuery("SELECT CAST(name AS BLOB),config FROM templates WHERE ntid=? AND ord=?", new String[]{String.valueOf(j), String.valueOf(iCheckedOrdinal)});
                                                            cursor = cursorRawQuery;
/* 104 */                                                   if (cursor.moveToFirst()) {
                                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                                            }
                                                            AnkiProtoReader ankiProtoReader2 = AnkiProtoReader.INSTANCE;
                                                            Cursor cursor9 = cursor8;
                                                            byte[] blob6 = cursor.getBlob(1);
                                                            Intrinsics.checkNotNullExpressionValue(blob6, "getBlob(...)");
                                                            AnkiProtoReader.TemplateConfig templateConfig = ankiProtoReader2.templateConfig(blob6);
                                                            byte[] blob7 = cursor.getBlob(0);
                                                            Intrinsics.checkNotNullExpressionValue(blob7, "getBlob(...)");
                                                            AnkiTemplate ankiTemplate = new AnkiTemplate(iCheckedOrdinal, BoundedApkgKt.utf8(blob7), templateConfig.getQuestion(), templateConfig.getAnswer());
                                                            CloseableKt.closeFinally(cursorRawQuery, null);
/* 105 */                                                   modelBudget.addTemplate(ankiTemplate);
                                                            list.add(ankiTemplate);
                                                            cursor8 = cursor9;
                                                            arrayList2 = list;
                                                            str3 = str;
                                                            th4 = th;
                                                            throw th4;
                                                        }
                                                        try {
                                                            if (Intrinsics.areEqual(cursor8.getString(4), str3) && Intrinsics.areEqual(cursor8.getString(5), "text") && Intrinsics.areEqual(cursor8.getString(6), "blob") && cursor8.getLong(1) + cursor8.getLong(2) <= this.limits.getMaxModelStoredBytes()) {
                                                                z = true;
                                                            } else {
/* 102 */                                                       z = false;
                                                            }
                                                            if (z) {
/* 102 */                                                       throw new IllegalArgumentException("Invalid template scalar".toString());
                                                            }
/* 1 */                                                     iCheckedOrdinal = AnkiPackageDatabaseKt.checkedOrdinal(cursor8.getLong(0));
                                                            str = str3;
                                                            list = arrayList2;
                                                            try {
/* 104 */                                                       cursorRawQuery = this.db.rawQuery("SELECT CAST(name AS BLOB),config FROM templates WHERE ntid=? AND ord=?", new String[]{String.valueOf(j), String.valueOf(iCheckedOrdinal)});
                                                                try {
                                                                    cursor = cursorRawQuery;
/* 104 */                                                           if (cursor.moveToFirst()) {
                                                                        throw new IllegalArgumentException("Failed requirement.".toString());
                                                                    }
                                                                    AnkiProtoReader ankiProtoReader3 = AnkiProtoReader.INSTANCE;
                                                                    Cursor cursor10 = cursor8;
                                                                    try {
                                                                        byte[] blob8 = cursor.getBlob(1);
                                                                        Intrinsics.checkNotNullExpressionValue(blob8, "getBlob(...)");
                                                                        AnkiProtoReader.TemplateConfig templateConfig2 = ankiProtoReader3.templateConfig(blob8);
                                                                        byte[] blob9 = cursor.getBlob(0);
                                                                        Intrinsics.checkNotNullExpressionValue(blob9, "getBlob(...)");
                                                                        AnkiTemplate ankiTemplate2 = new AnkiTemplate(iCheckedOrdinal, BoundedApkgKt.utf8(blob9), templateConfig2.getQuestion(), templateConfig2.getAnswer());
                                                                        CloseableKt.closeFinally(cursorRawQuery, null);
/* 105 */                                                               modelBudget.addTemplate(ankiTemplate2);
                                                                        list.add(ankiTemplate2);
                                                                        cursor8 = cursor10;
                                                                        arrayList2 = list;
                                                                        str3 = str;
                                                                    } catch (Throwable th13) {
                                                                        th4 = th13;
                                                                    }
                                                                    th4 = th13;
                                                                } catch (Throwable th14) {
                                                                    th4 = th14;
                                                                }
                                                                try {
                                                                    throw th4;
                                                                } catch (Throwable th15) {
                                                                    CloseableKt.closeFinally(cursorRawQuery, th4);
                                                                    throw th15;
                                                                }
                                                            } catch (Throwable th16) {
                                                                th3 = th16;
                                                            }
                                                        } catch (Throwable th17) {
                                                            th3 = th17;
                                                        }
                                                    } catch (Throwable th18) {
                                                        th3 = th18;
                                                    }
                                                    try {
                                                        throw th3;
                                                    } catch (Throwable th19) {
                                                        CloseableKt.closeFinally(cursorRawQuery6, th3);
                                                        throw th19;
                                                    }
                                                }
/* 106 */                                       String str6 = str3;
                                                List list2 = arrayList2;
                                                try {
                                                    Unit unit2 = Unit.INSTANCE;
/* 101 */                                           CloseableKt.closeFinally(cursorRawQuery6, null);
/* 107 */                                           int kind = modelConfig3.getKind();
                                                    Iterable iterable3 = iterable;
/* 208 */                                           Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable3, 10));
/* 209 */                                           Iterator it2 = iterable3.iterator();
                                                    while (it2.hasNext()) {
/* 210 */                                               arrayList3.add((String) ((Pair) it2.next()).getSecond());
                                                    }
/* 88 */                                            cache(new AnkiModel(j, str4, kind, (List) arrayList3, list2, modelConfig3.getCss(), modelConfig3.getOriginalStockKind()));
                                                    str2 = str5;
                                                    cursor3 = cursor7;
                                                    i2 = i3;
                                                    str3 = str6;
                                                } catch (Throwable th20) {
                                                    th3 = th20;
                                                }
                                            } catch (Throwable th21) {
                                                th3 = th21;
                                            }
                                        } catch (Throwable th22) {
                                            th2 = th22;
                                            throw th2;
                                        }
                                    } catch (Throwable th23) {
                                        th2 = th23;
                                    }
                                } else {
                                    try {
                                        throw new IllegalArgumentException("Failed requirement.".toString());
                                    } catch (Throwable th24) {
                                        th = th24;
                                    }
                                }
                            } catch (Throwable th25) {
                                th = th25;
                            }
                            try {
                                throw th;
                            } catch (Throwable th26) {
                                CloseableKt.closeFinally(cursorRawQuery4, th);
                                throw th26;
                            }
                        }
                        Unit unit3 = Unit.INSTANCE;
/* 88 */                CloseableKt.closeFinally(cursorRawQuery3, null);
                    } catch (Throwable th27) {
                        try {
                            throw th27;
                        } catch (Throwable th28) {
                            CloseableKt.closeFinally(cursorRawQuery3, th27);
                            throw th28;
                        }
                    }
                }

                /* JADX WARN: Code duplicated, block: B:24:0x0070  */
/* 111 */       private final void cache(AnkiModel model) {
                    boolean z;
                    boolean z2;
/* 112 */           if (StringsKt.isBlank(model.getName()) || model.getKind() < 0 || model.getFieldNames().isEmpty()) {
                        z = false;
                    } else {
                        Iterable fieldNames = model.getFieldNames();
/* 212 */               if (!(fieldNames instanceof Collection) || !((Collection) fieldNames).isEmpty()) {
/* 213 */                   Iterator it = fieldNames.iterator();
                            while (true) {
                                if (!it.hasNext()) {
/* 214 */                           z2 = true;
                                    break;
                                } else if (StringsKt.isBlank((String) it.next())) {
                                    z2 = false;
                                    break;
                                }
                            }
                        } else {
                            z2 = true;
                        }
/* 112 */               if (z2 && CollectionsKt.distinct(model.getFieldNames()).size() == model.getFieldNames().size()) {
                            z = true;
                        } else {
                            z = false;
                        }
                    }
                    if (!z) {
                        throw new IllegalArgumentException("Invalid model field names/kind".toString());
                    }
/* 113 */           Iterable templates = model.getTemplates();
/* 215 */           Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(templates, 10));
/* 216 */           Iterator it2 = templates.iterator();
                    while (it2.hasNext()) {
/* 217 */               arrayList.add(Integer.valueOf(((AnkiTemplate) it2.next()).getOrdinal()));
                    }
/* 1 */             AnkiPackageDatabaseKt.ordinals((List) arrayList);
                    if (model.getTemplates().isEmpty()) {
                        throw new IllegalArgumentException("Model has no templates".toString());
                    }
/* 114 */           this.modelsBytes += (long) AnkiStorageValidator.INSTANCE.validateModel(model.getFieldNames(), model.getTemplates(), CollectionsKt.listOf((Object[]) new String[]{model.getName(), model.getCss(), String.valueOf(model.getSourceId()), StringsKt.repeat("x", 36), StringsKt.repeat("x", 64)}), this.limits.getMaxModelStoredBytes());
                    if (!(this.modelsBytes <= ((long) this.limits.getMaxModelsBytes()))) {
                        throw new IllegalArgumentException(("Model collection exceeds " + this.limits.getMaxModelsBytes() + " stored bytes").toString());
                    }
                    if (!(this.models.put(Long.valueOf(model.getSourceId()), model) == null)) {
                        throw new IllegalArgumentException("Duplicate model ID".toString());
                    }
                }

/* 117 */       private final Map<Long, AnkiSourceDeck> readModernDecks(CoroutineContext context) {
                    LinkedHashMap result = new LinkedHashMap();
                    long bytes = 0;
/* 119 */           Cursor cursorRawQuery = this.db.rawQuery("SELECT id,length(CAST(name AS BLOB)),typeof(id),typeof(name) FROM decks ORDER BY id", null);
                    try {
                        Cursor cursor = cursorRawQuery;
/* 119 */               while (cursor.moveToNext()) {
/* 120 */                   JobKt.ensureActive(context);
                            if (!(Intrinsics.areEqual(cursor.getString(2), "integer") && Intrinsics.areEqual(cursor.getString(3), "text") && cursor.getLong(1) <= 4096)) {
/* 120 */                       throw new IllegalArgumentException("Invalid source deck scalar".toString());
                            }
/* 121 */                   long j = cursor.getLong(0);
                            if (!(j > 0)) {
/* 121 */                       throw new IllegalArgumentException("Invalid deck ID".toString());
                            }
/* 122 */                   Cursor cursorRawQuery2 = this.db.rawQuery("SELECT CAST(name AS BLOB) FROM decks WHERE id=?", new String[]{String.valueOf(j)});
                            try {
                                Cursor cursor2 = cursorRawQuery2;
/* 122 */                       if (!cursor2.moveToFirst()) {
/* 122 */                           throw new IllegalArgumentException("Failed requirement.".toString());
                                }
                                byte[] blob = cursor2.getBlob(0);
                                Intrinsics.checkNotNullExpressionValue(blob, "getBlob(...)");
/* 1 */                         String strDeckName = AnkiPackageDatabaseKt.deckName(StringsKt.replace$default(BoundedApkgKt.utf8(blob), "\u001f", "::", false, 4, (Object) null));
                                CloseableKt.closeFinally(cursorRawQuery2, null);
/* 123 */                       bytes += (long) AnkiStorageValidator.INSTANCE.utf8Bytes(strDeckName);
                                if (!(bytes <= ((long) this.limits.getMaxDecksBytes()))) {
                                    throw new IllegalArgumentException(("Source decks exceed " + this.limits.getMaxDecksBytes() + " bytes").toString());
                                }
                                result.put(Long.valueOf(j), new AnkiSourceDeck(j, strDeckName));
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    CloseableKt.closeFinally(cursorRawQuery2, th);
                                    throw th2;
                                }
                            }
                            try {
                                throw th;
                            } catch (Throwable th3) {
                                CloseableKt.closeFinally(cursorRawQuery, th);
                                throw th3;
                            }
                        }
                        Unit unit = Unit.INSTANCE;
/* 119 */               CloseableKt.closeFinally(cursorRawQuery, null);
/* 125 */               return MapsKt.toMap(result);
                    } catch (Throwable th4) {
                        throw th4;
                    }
                }

                /* JADX WARN: Code duplicated, block: B:38:0x00be  */
/* 127 */       private final Set<Long> validateNotes(CoroutineContext context) {
                    boolean z;
                    boolean z2;
                    Set invalidFields = new LinkedHashSet();
/* 129 */           Cursor cursorRawQuery = this.db.rawQuery("SELECT id,mid,length(CAST(guid AS BLOB)),length(CAST(tags AS BLOB)),length(CAST(flds AS BLOB)),typeof(id),typeof(mid),typeof(guid),typeof(tags),typeof(flds) FROM notes ORDER BY id", null);
                    try {
                        Cursor cursor = cursorRawQuery;
/* 129 */               while (cursor.moveToNext()) {
/* 130 */                   JobKt.ensureActive(context);
                            long j = 0;
                            boolean z3 = true;
/* 128 */                   if (cursor.getLong(0) <= 0 || !this.models.containsKey(Long.valueOf(cursor.getLong(1)))) {
                                z = false;
                            } else {
                                Iterable intRange = new IntRange(5, 6);
/* 219 */                       if (!(intRange instanceof Collection) || !((Collection) intRange).isEmpty()) {
/* 220 */                           Iterator it = intRange.iterator();
                                    while (true) {
                                        if (!it.hasNext()) {
/* 221 */                                   z3 = true;
                                            break;
                                        }
/* 220 */                               if (!Intrinsics.areEqual(cursor.getString(((IntIterator) it).nextInt()), "integer")) {
                                            z3 = false;
                                            break;
                                        }
                                    }
                                }
/* 130 */                       if (z3) {
                                    Iterable intRange2 = new IntRange(7, 9);
/* 219 */                           if (!(intRange2 instanceof Collection) || !((Collection) intRange2).isEmpty()) {
/* 220 */                               Iterator it2 = intRange2.iterator();
                                        while (true) {
                                            if (!it2.hasNext()) {
/* 221 */                                       z2 = true;
                                                break;
                                            }
/* 220 */                                   if (!Intrinsics.areEqual(cursor.getString(((IntIterator) it2).nextInt()), "text")) {
                                                z2 = false;
                                                break;
                                            }
                                        }
                                    } else {
                                        z2 = true;
                                    }
/* 130 */                           if (z2) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                } else {
                                    z = false;
                                }
                            }
                            if (!z) {
/* 130 */                       throw new IllegalArgumentException("Invalid note scalars/model relationship".toString());
                            }
/* 131 */                   Iterator<Integer> it3 = new IntRange(2, 4).iterator();
                            while (it3.hasNext()) {
/* 131 */                       j += cursor.getLong(((IntIterator) it3).nextInt());
                            }
                            if (!(j <= ((long) this.limits.getMaxNoteStoredBytes()))) {
                                throw new IllegalArgumentException(("Source note scalar exceeds " + this.limits.getMaxNoteStoredBytes() + " bytes").toString());
                            }
                        }
                        Unit unit = Unit.INSTANCE;
/* 129 */               CloseableKt.closeFinally(cursorRawQuery, null);
/* 133 */               Cursor cursorRawQuery2 = this.db.rawQuery("SELECT id,CAST(guid AS BLOB),mid,CAST(tags AS BLOB),CAST(flds AS BLOB) FROM notes ORDER BY id", null);
                        try {
                            Cursor cursor2 = cursorRawQuery2;
/* 133 */                   while (cursor2.moveToNext()) {
/* 134 */                       JobKt.ensureActive(context);
                                Intrinsics.checkNotNull(cursor2);
/* 128 */                       AnkiSourceNote ankiSourceNoteNote = note(cursor2);
/* 128 */                       if (ankiSourceNoteNote.getFields().size() != ((AnkiModel) MapsKt.getValue(this.models, Long.valueOf(ankiSourceNoteNote.getModelId()))).getFieldNames().size()) {
                                    invalidFields.add(Long.valueOf(ankiSourceNoteNote.getSourceId()));
                                }
                            }
                            Unit unit2 = Unit.INSTANCE;
/* 133 */                   CloseableKt.closeFinally(cursorRawQuery2, null);
/* 137 */                   return invalidFields;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorRawQuery2, th);
                                throw th2;
                            }
                        }
                    } catch (Throwable th3) {
                        try {
                            throw th3;
                        } catch (Throwable th4) {
                            CloseableKt.closeFinally(cursorRawQuery, th3);
                            throw th4;
                        }
                    }
                }

/* 139 */       private final AnkiSourceNote note(Cursor cursor) {
                    long j = cursor.getLong(0);
                    byte[] blob = cursor.getBlob(1);
                    Intrinsics.checkNotNullExpressionValue(blob, "getBlob(...)");
                    String strUtf8 = BoundedApkgKt.utf8(blob);
                    long j2 = cursor.getLong(2);
                    byte[] blob2 = cursor.getBlob(4);
                    Intrinsics.checkNotNullExpressionValue(blob2, "getBlob(...)");
                    List listSplit$default = StringsKt.split$default((CharSequence) BoundedApkgKt.utf8(blob2), new char[]{31}, false, 0, 6, (Object) null);
                    byte[] blob3 = cursor.getBlob(3);
                    Intrinsics.checkNotNullExpressionValue(blob3, "getBlob(...)");
                    String string = StringsKt.trim((CharSequence) BoundedApkgKt.utf8(blob3)).toString();
/* 140 */           AnkiSourceNote note = new AnkiSourceNote(j, strUtf8, j2, listSplit$default, string.length() == 0 ? CollectionsKt.emptyList() : new Regex("\\s+").split(string, 0));
/* 141 */           if (StringsKt.isBlank(note.getGuid())) {
                        throw new IllegalArgumentException("Invalid note GUID".toString());
                    }
/* 140 */           AnkiStorageValidator.INSTANCE.validateNote(note.getFields(), note.getTags(), CollectionsKt.listOf((Object[]) new String[]{note.getGuid(), StringsKt.repeat("x", 36), StringsKt.repeat("x", 36), StringsKt.repeat("x", 64)}), this.limits.getMaxFieldBytes(), this.limits.getMaxNoteStoredBytes());
/* 144 */           return note;
                }

/* 145 */       public final Cursor cards() {
/* 146 */           Cursor cursorRawQuery = this.db.rawQuery("SELECT id,nid,did,ord,odid,typeof(id),typeof(nid),typeof(did),typeof(ord),typeof(odid) FROM cards ORDER BY id", null);
                    Intrinsics.checkNotNullExpressionValue(cursorRawQuery, "rawQuery(...)");
                    return cursorRawQuery;
                }

                /* JADX WARN: Code duplicated, block: B:35:0x0091  */
/* 147 */       public final AnkiSourceCard card(Cursor cursor) {
                    boolean z;
                    boolean z2;
                    boolean z3;
                    Intrinsics.checkNotNullParameter(cursor, "cursor");
/* 148 */           Iterable intRange = new IntRange(5, 9);
/* 222 */           if (!(intRange instanceof Collection) || !((Collection) intRange).isEmpty()) {
/* 223 */               Iterator it = intRange.iterator();
                        while (true) {
                            if (!it.hasNext()) {
/* 224 */                       z = true;
                                break;
                            }
/* 223 */                   if (!Intrinsics.areEqual(cursor.getString(((IntIterator) it).nextInt()), "integer")) {
                                z = false;
                                break;
                            }
                        }
                    } else {
                        z = true;
                    }
                    if (z) {
                        Iterable intRange2 = new IntRange(0, 2);
/* 222 */               if (!(intRange2 instanceof Collection) || !((Collection) intRange2).isEmpty()) {
/* 223 */                   Iterator it2 = intRange2.iterator();
                            while (true) {
                                if (!it2.hasNext()) {
/* 224 */                           z3 = true;
                                    break;
                                }
/* 223 */                       if ((cursor.getLong(((IntIterator) it2).nextInt()) > 0 ? 1 : 0) == 0) {
                                    z3 = false;
                                    break;
                                }
                            }
                        } else {
                            z3 = true;
                        }
/* 148 */               if (!z3 || cursor.getLong(4) < 0) {
                            z2 = false;
                        } else {
                            z2 = true;
                        }
                    } else {
                        z2 = false;
                    }
                    if (z2) {
/* 149 */               return new AnkiSourceCard(cursor.getLong(0), cursor.getLong(1), cursor.getLong(2), AnkiPackageDatabaseKt.checkedOrdinal(cursor.getLong(3)), cursor.getLong(4));
                    }
                    throw new IllegalArgumentException("Invalid source card scalar".toString());
                }

/* 150 */       public final AnkiSourceNote noteForCard(long cardId) {
                    try {
/* 152 */               Cursor cursorRawQuery = this.db.rawQuery("SELECT n.id,CAST(n.guid AS BLOB),n.mid,CAST(n.tags AS BLOB),CAST(n.flds AS BLOB) FROM cards c JOIN notes n ON c.nid=n.id WHERE c.id=?", new String[]{String.valueOf(cardId)});
                        try {
                            Cursor cursor = cursorRawQuery;
/* 152 */                   if (!cursor.moveToFirst()) {
/* 152 */                       throw new IllegalArgumentException(("Unknown source card " + cardId).toString());
                            }
                            Intrinsics.checkNotNull(cursor);
                            AnkiSourceNote ankiSourceNoteNote = note(cursor);
                            CloseableKt.closeFinally(cursorRawQuery, null);
/* 153 */                   return ankiSourceNoteNote;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorRawQuery, th);
                                throw th2;
                            }
                        }
                    } catch (SQLiteException e) {
                        throw new ApkgException(ImportStage.DATABASE, "DATABASE: " + e.getMessage(), e);
                    }
                }

/* 153 */       public final AnkiModel modelForCard(long cardId) {
                    try {
/* 155 */               Cursor cursorRawQuery = this.db.rawQuery("SELECT n.mid FROM cards c JOIN notes n ON c.nid=n.id WHERE c.id=?", new String[]{String.valueOf(cardId)});
                        try {
                            Cursor cursor = cursorRawQuery;
/* 155 */                   if (!cursor.moveToFirst()) {
/* 155 */                       throw new IllegalArgumentException(("Unknown source card " + cardId).toString());
                            }
                            AnkiModel ankiModel = (AnkiModel) MapsKt.getValue(this.models, Long.valueOf(cursor.getLong(0)));
                            CloseableKt.closeFinally(cursorRawQuery, null);
/* 156 */                   return ankiModel;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorRawQuery, th);
                                throw th2;
                            }
                        }
                    } catch (SQLiteException e) {
                        throw new ApkgException(ImportStage.DATABASE, "DATABASE: " + e.getMessage(), e);
                    }
                }

/* 156 */       private final long scalar(String query) {
/* 157 */           Cursor cursorRawQuery = this.db.rawQuery(query, null);
                    try {
                        Cursor cursor = cursorRawQuery;
/* 157 */               if (!cursor.moveToFirst()) {
                            throw new IllegalArgumentException("Failed requirement.".toString());
                        }
                        long j = cursor.getLong(0);
                        CloseableKt.closeFinally(cursorRawQuery, null);
                        return j;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(cursorRawQuery, th);
                            throw th2;
                        }
                    }
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 157 */       public void close() {
/* 158 */           if (this.db.isOpen()) {
                        this.db.close();
                    }
                }
            }

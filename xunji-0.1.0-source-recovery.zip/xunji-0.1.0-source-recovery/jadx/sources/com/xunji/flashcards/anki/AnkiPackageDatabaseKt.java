            package com.xunji.flashcards.anki;

            import android.database.sqlite.SQLiteException;
            import androidx.autofill.HintConstants;
            import com.xunji.core.anki.ImportStage;
            import java.util.Collection;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.IndexedValue;
            import kotlin.collections.MapsKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonPrimitive;
            
            /* JADX INFO: compiled from: AnkiPackageDatabase.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u00004\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\u0014\u0010\u0004\u001a\u00020\u0005*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\f\u0010\u0006\u001a\u00020\u0005*\u00020\u0002H\u0002\u001a\f\u0010\u0007\u001a\u00020\b*\u00020\u0002H\u0002\u001a\u0010\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0005H\u0002\u001a\u0016\u0010\u000b\u001a\u00020\f2\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u000eH\u0002\u001a\u0010\u0010\u000f\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\"\u0010\u0010\u001a\u0002H\u0011\"\u0004\b\u0000\u0010\u00112\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u0002H\u00110\u0013H\u0082\b¢\u0006\u0002\u0010\u0014¨\u0006\u0015"}, d2 = {"string", "", "Lkotlinx/serialization/json/JsonObject;", HintConstants.AUTOFILL_HINT_NAME, "number", "", "identifier", "ordinal", "", "checkedOrdinal", "value", "ordinals", "", "values", "", "deckName", "databaseRead", "T", "action", "Lkotlin/Function0;", "(Lkotlin/jvm/functions/Function0;)Ljava/lang/Object;", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 159 */   public final class AnkiPackageDatabaseKt {
                /* JADX INFO: Access modifiers changed from: private */
/* 160 */       public static final String string(JsonObject $this$string, String name) {
/* 161 */           JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive((JsonElement) MapsKt.getValue($this$string, name));
/* 161 */           if (jsonPrimitive.isString()) {
                        return jsonPrimitive.getContent();
                    }
/* 161 */           throw new IllegalArgumentException(("Expected JSON string " + name).toString());
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 161 */       public static final long number(JsonObject $this$number, String name) {
/* 162 */           JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive((JsonElement) MapsKt.getValue($this$number, name));
/* 162 */           if (jsonPrimitive.isString()) {
/* 162 */               throw new IllegalArgumentException(("Expected JSON integer " + name).toString());
                    }
                    return JsonElementKt.getLong(jsonPrimitive);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 162 */       public static final long identifier(JsonObject $this$identifier) {
/* 163 */           JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive((JsonElement) MapsKt.getValue($this$identifier, "id"));
/* 163 */           long j = JsonElementKt.getLong(jsonPrimitive);
/* 163 */           if (Intrinsics.areEqual(jsonPrimitive.getContent(), String.valueOf(j))) {
                        return j;
                    }
                    throw new IllegalArgumentException("Invalid legacy JSON identifier".toString());
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 163 */       public static final int ordinal(JsonObject $this$ordinal) {
/* 164 */           return checkedOrdinal(number($this$ordinal, "ord"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 164 */       public static final int checkedOrdinal(long value) {
                    boolean z = false;
                    if (0 <= value && value < 2147483648L) {
                        z = true;
                    }
                    if (z) {
                        return (int) value;
                    }
                    throw new IllegalArgumentException("Invalid source ordinal".toString());
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 165 */       public static final void ordinals(List<Integer> list) {
/* 166 */           Iterable<IndexedValue> iterableWithIndex = CollectionsKt.withIndex(list);
                    boolean z = true;
/* 171 */           if (!(iterableWithIndex instanceof Collection) || !((Collection) iterableWithIndex).isEmpty()) {
                        for (IndexedValue indexedValue : iterableWithIndex) {
/* 172 */                   if (!(((Number) indexedValue.getValue()).intValue() == indexedValue.getIndex())) {
                                z = false;
                                break;
                            }
                        }
                    }
/* 166 */           if (!z) {
                        throw new IllegalArgumentException("Invalid field/template ordinals".toString());
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 166 */       public static final String deckName(String name) {
                    boolean z = false;
/* 167 */           if (!StringsKt.isBlank(name) && !StringsKt.contains$default((CharSequence) name, (char) 0, false, 2, (Object) null) && name.codePointCount(0, name.length()) <= 1024) {
                        z = true;
                    }
                    if (z) {
                        return name;
                    }
                    throw new IllegalArgumentException("Invalid/oversized source deck name".toString());
                }

/* 167 */       private static final <T> T databaseRead(Function0<? extends T> function0) {
                    try {
/* 168 */               return function0.invoke();
                    } catch (SQLiteException error) {
                        throw new ApkgException(ImportStage.DATABASE, "DATABASE: " + error.getMessage(), error);
                    }
                }
            }

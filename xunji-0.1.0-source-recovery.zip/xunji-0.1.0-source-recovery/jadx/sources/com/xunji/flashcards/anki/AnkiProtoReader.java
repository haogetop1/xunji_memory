            package com.xunji.flashcards.anki;

            import androidx.autofill.HintConstants;
            import com.google.protobuf.CodedInputStream;
            import java.io.ByteArrayInputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.util.ArrayList;
            import java.util.Arrays;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiProtoReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0012\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010#\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\bÁ\u0002\u0018\u00002\u00020\u0001:\u0003\"#$B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\b\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\nJ\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\nJ\u001c\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00110\u00102\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u0005J\u001e\u0010\u0015\u001a\u00020\u00162\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00050\u00182\u0006\u0010\u0019\u001a\u00020\u0005H\u0002J\u0018\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\u0005H\u0002J\u0018\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u0005H\u0002J%\u0010\u001d\u001a\u00020\u00162\u0006\u0010\u001e\u001a\u00020\u001b2\u0012\u0010\u001f\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020!0 H\u0082\bR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiProtoReader;", "", "<init>", "()V", "MAX_METADATA", "", "MAX_CONFIG", "MAX_MEDIA_MAP", "version", "bytes", "", "modelConfig", "Lcom/xunji/flashcards/anki/AnkiProtoReader$ModelConfig;", "templateConfig", "Lcom/xunji/flashcards/anki/AnkiProtoReader$TemplateConfig;", "media", "", "Lcom/xunji/flashcards/anki/AnkiProtoReader$MediaEntry;", "stream", "Ljava/io/InputStream;", "maxEntries", "unique", "", "seen", "", "tag", "bounded", "Lcom/google/protobuf/CodedInputStream;", "maximum", "fields", "input", "read", "Lkotlin/Function1;", "", "ModelConfig", "TemplateConfig", "MediaEntry", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */     public final class AnkiProtoReader {
                public static final int $stable = 0;
                public static final AnkiProtoReader INSTANCE = new AnkiProtoReader();
                private static final int MAX_CONFIG = 524288;
                private static final int MAX_MEDIA_MAP = 33554432;
                private static final int MAX_METADATA = 65536;

                /* JADX INFO: compiled from: AnkiProtoReader.kt */
                @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J'\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\n¨\u0006\u0017"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiProtoReader$ModelConfig;", "", "kind", "", "css", "", "originalStockKind", "<init>", "(ILjava/lang/String;I)V", "getKind", "()I", "getCss", "()Ljava/lang/String;", "getOriginalStockKind", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */         public static final /* data */ class ModelConfig {
                    public static final int $stable = 0;
                    private final String css;
                    private final int kind;
                    private final int originalStockKind;

                    public static /* synthetic */ ModelConfig copy$default(ModelConfig modelConfig, int i, String str, int i2, int i3, Object obj) {
                        if ((i3 & 1) != 0) {
                            i = modelConfig.kind;
                        }
                        if ((i3 & 2) != 0) {
                            str = modelConfig.css;
                        }
                        if ((i3 & 4) != 0) {
                            i2 = modelConfig.originalStockKind;
                        }
                        return modelConfig.copy(i, str, i2);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final int getKind() {
                        return this.kind;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final String getCss() {
                        return this.css;
                    }

                    /* JADX INFO: renamed from: component3, reason: from getter */
                    public final int getOriginalStockKind() {
                        return this.originalStockKind;
                    }

                    public final ModelConfig copy(int kind, String css, int originalStockKind) {
                        Intrinsics.checkNotNullParameter(css, "css");
                        return new ModelConfig(kind, css, originalStockKind);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof ModelConfig)) {
                            return false;
                        }
                        ModelConfig modelConfig = (ModelConfig) other;
                        return this.kind == modelConfig.kind && Intrinsics.areEqual(this.css, modelConfig.css) && this.originalStockKind == modelConfig.originalStockKind;
                    }

                    public int hashCode() {
                        return (((Integer.hashCode(this.kind) * 31) + this.css.hashCode()) * 31) + Integer.hashCode(this.originalStockKind);
                    }

                    public String toString() {
                        return "ModelConfig(kind=" + this.kind + ", css=" + this.css + ", originalStockKind=" + this.originalStockKind + ")";
                    }

/* 7 */             public ModelConfig(int kind, String css, int originalStockKind) {
                        Intrinsics.checkNotNullParameter(css, "css");
                        this.kind = kind;
                        this.css = css;
                        this.originalStockKind = originalStockKind;
                    }

/* 7 */             public final String getCss() {
/* 8 */                 return this.css;
                    }

/* 7 */             public final int getKind() {
/* 8 */                 return this.kind;
                    }

/* 7 */             public final int getOriginalStockKind() {
/* 8 */                 return this.originalStockKind;
                    }
                }

/* 6 */         private AnkiProtoReader() {
                }

                /* JADX INFO: compiled from: AnkiProtoReader.kt */
                @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0013"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiProtoReader$TemplateConfig;", "", "question", "", "answer", "<init>", "(Ljava/lang/String;Ljava/lang/String;)V", "getQuestion", "()Ljava/lang/String;", "getAnswer", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */         public static final /* data */ class TemplateConfig {
                    public static final int $stable = 0;
                    private final String answer;
                    private final String question;

                    public static /* synthetic */ TemplateConfig copy$default(TemplateConfig templateConfig, String str, String str2, int i, Object obj) {
                        if ((i & 1) != 0) {
                            str = templateConfig.question;
                        }
                        if ((i & 2) != 0) {
                            str2 = templateConfig.answer;
                        }
                        return templateConfig.copy(str, str2);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final String getQuestion() {
                        return this.question;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final String getAnswer() {
                        return this.answer;
                    }

                    public final TemplateConfig copy(String question, String answer) {
                        Intrinsics.checkNotNullParameter(question, "question");
                        Intrinsics.checkNotNullParameter(answer, "answer");
                        return new TemplateConfig(question, answer);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof TemplateConfig)) {
                            return false;
                        }
                        TemplateConfig templateConfig = (TemplateConfig) other;
                        return Intrinsics.areEqual(this.question, templateConfig.question) && Intrinsics.areEqual(this.answer, templateConfig.answer);
                    }

                    public int hashCode() {
                        return (this.question.hashCode() * 31) + this.answer.hashCode();
                    }

                    public String toString() {
                        return "TemplateConfig(question=" + this.question + ", answer=" + this.answer + ")";
                    }

/* 8 */             public TemplateConfig(String question, String answer) {
                        Intrinsics.checkNotNullParameter(question, "question");
                        Intrinsics.checkNotNullParameter(answer, "answer");
                        this.question = question;
                        this.answer = answer;
                    }

/* 8 */             public final String getAnswer() {
/* 9 */                 return this.answer;
                    }

/* 8 */             public final String getQuestion() {
/* 9 */                 return this.question;
                    }
                }

                /* JADX INFO: compiled from: AnkiProtoReader.kt */
                @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\b¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0015\u001a\u00020\bHÆ\u0003J1\u0010\u0016\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\bHÆ\u0001J\u0013\u0010\u0017\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001a\u001a\u00020\u001bHÖ\u0001J\t\u0010\u001c\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001d"}, d2 = {"Lcom/xunji/flashcards/anki/AnkiProtoReader$MediaEntry;", "", "index", "", HintConstants.AUTOFILL_HINT_NAME, "size", "", "sha1", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;J[B)V", "getIndex", "()Ljava/lang/String;", "getName", "getSize", "()J", "getSha1", "()[B", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */         public static final /* data */ class MediaEntry {
                    public static final int $stable = 8;
                    private final String index;
                    private final String name;
                    private final byte[] sha1;
                    private final long size;

                    public static /* synthetic */ MediaEntry copy$default(MediaEntry mediaEntry, String str, String str2, long j, byte[] bArr, int i, Object obj) {
                        if ((i & 1) != 0) {
                            str = mediaEntry.index;
                        }
                        if ((i & 2) != 0) {
                            str2 = mediaEntry.name;
                        }
                        if ((i & 4) != 0) {
                            j = mediaEntry.size;
                        }
                        if ((i & 8) != 0) {
                            bArr = mediaEntry.sha1;
                        }
                        byte[] bArr2 = bArr;
                        return mediaEntry.copy(str, str2, j, bArr2);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final String getIndex() {
                        return this.index;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final String getName() {
                        return this.name;
                    }

                    /* JADX INFO: renamed from: component3, reason: from getter */
                    public final long getSize() {
                        return this.size;
                    }

                    /* JADX INFO: renamed from: component4, reason: from getter */
                    public final byte[] getSha1() {
                        return this.sha1;
                    }

                    public final MediaEntry copy(String index, String name, long size, byte[] sha1) {
                        Intrinsics.checkNotNullParameter(index, "index");
                        Intrinsics.checkNotNullParameter(name, "name");
                        Intrinsics.checkNotNullParameter(sha1, "sha1");
                        return new MediaEntry(index, name, size, sha1);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof MediaEntry)) {
                            return false;
                        }
                        MediaEntry mediaEntry = (MediaEntry) other;
                        return Intrinsics.areEqual(this.index, mediaEntry.index) && Intrinsics.areEqual(this.name, mediaEntry.name) && this.size == mediaEntry.size && Intrinsics.areEqual(this.sha1, mediaEntry.sha1);
                    }

                    public int hashCode() {
                        return (((((this.index.hashCode() * 31) + this.name.hashCode()) * 31) + Long.hashCode(this.size)) * 31) + Arrays.hashCode(this.sha1);
                    }

                    public String toString() {
                        return "MediaEntry(index=" + this.index + ", name=" + this.name + ", size=" + this.size + ", sha1=" + Arrays.toString(this.sha1) + ")";
                    }

/* 9 */             public MediaEntry(String index, String name, long size, byte[] sha1) {
                        Intrinsics.checkNotNullParameter(index, "index");
                        Intrinsics.checkNotNullParameter(name, "name");
                        Intrinsics.checkNotNullParameter(sha1, "sha1");
                        this.index = index;
                        this.name = name;
                        this.size = size;
                        this.sha1 = sha1;
                    }

/* 9 */             public final String getIndex() {
/* 10 */                return this.index;
                    }

/* 9 */             public final String getName() {
/* 10 */                return this.name;
                    }

/* 9 */             public final byte[] getSha1() {
/* 10 */                return this.sha1;
                    }

/* 9 */             public final long getSize() {
/* 10 */                return this.size;
                    }
                }

/* 15 */        public final int version(byte[] bytes) throws IOException {
                    boolean z;
                    int i;
                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 16 */            CodedInputStream input = bounded(bytes, 65536);
/* 17 */            Object version = null;
                    do {
/* 93 */                int tag = input.readTag();
/* 94 */                z = false;
                        if (tag != 0) {
/* 95 */                    if (tag == 8) {
/* 94 */                        if (!(version == null)) {
                                    throw new IllegalArgumentException("duplicate package version".toString());
                                }
                                version = Integer.valueOf(input.readUInt32());
                                i = 1;
                            } else {
/* 94 */                        i = 0;
                            }
/* 95 */                    if (i != 0 || input.skipField(tag)) {
                                z = true;
                            }
                        } else {
/* 98 */                    input.checkLastTagWas(0);
/* 21 */                    if (version != null) {
                                return ((Number) version).intValue();
                            }
                            throw new IllegalStateException("package metadata has no version".toString());
                        }
                    } while (z);
                    throw new IllegalArgumentException("unexpected protobuf end group".toString());
                }

/* 23 */        public final ModelConfig modelConfig(byte[] bytes) throws IOException {
                    boolean z;
                    boolean z2;
                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 24 */            CodedInputStream input = bounded(bytes, 524288);
/* 25 */            int kind = 0;
                    String str = "";
                    int stock = 0;
/* 26 */            Set seen = new LinkedHashSet();
                    do {
/* 101 */               int tag = input.readTag();
/* 102 */               z = false;
                        if (tag != 0) {
                            switch (tag) {
                                case 8:
/* 103 */                           INSTANCE.unique(seen, tag);
                                    kind = input.readUInt32();
                                    z2 = true;
                                    break;
                                case 26:
/* 103 */                           INSTANCE.unique(seen, tag);
                                    String stringRequireUtf8 = input.readStringRequireUtf8();
                                    Intrinsics.checkNotNullExpressionValue(stringRequireUtf8, "readStringRequireUtf8(...)");
                                    str = stringRequireUtf8;
                                    z2 = true;
                                    break;
                                case 72:
/* 103 */                           INSTANCE.unique(seen, tag);
                                    stock = input.readUInt32();
                                    z2 = true;
                                    break;
                                default:
/* 32 */                            z2 = false;
                                    break;
                            }
/* 103 */                   if (z2 || input.skipField(tag)) {
                                z = true;
                            }
                        } else {
/* 105 */                   input.checkLastTagWas(0);
/* 35 */                    if (kind >= 0 && stock >= 0) {
                                z = true;
                            }
                            if (z) {
/* 36 */                        return new ModelConfig(kind, str, stock);
                            }
                            throw new IllegalArgumentException("invalid note type configuration".toString());
                        }
                    } while (z);
                    throw new IllegalArgumentException("unexpected protobuf end group".toString());
                }

/* 38 */        public final TemplateConfig templateConfig(byte[] bytes) throws IOException {
                    boolean z;
                    boolean z2;
                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 39 */            CodedInputStream input = bounded(bytes, 524288);
                    String str = "";
                    String str2 = "";
/* 41 */            Set seen = new LinkedHashSet();
                    do {
/* 108 */               int tag = input.readTag();
/* 109 */               z = false;
                        if (tag != 0) {
                            switch (tag) {
                                case 10:
/* 110 */                           INSTANCE.unique(seen, tag);
                                    String stringRequireUtf8 = input.readStringRequireUtf8();
/* 42 */                            Intrinsics.checkNotNullExpressionValue(stringRequireUtf8, "readStringRequireUtf8(...)");
                                    z2 = true;
                                    str = stringRequireUtf8;
                                    break;
                                case 18:
/* 110 */                           INSTANCE.unique(seen, tag);
                                    String stringRequireUtf9 = input.readStringRequireUtf8();
/* 42 */                            Intrinsics.checkNotNullExpressionValue(stringRequireUtf9, "readStringRequireUtf8(...)");
                                    z2 = true;
                                    str2 = stringRequireUtf9;
                                    break;
                                default:
/* 45 */                            z2 = false;
                                    break;
                            }
/* 110 */                   if (z2 || input.skipField(tag)) {
                                z = true;
                            }
                        } else {
/* 112 */                   input.checkLastTagWas(0);
/* 47 */                    return new TemplateConfig(str, str2);
                        }
                    } while (z);
                    throw new IllegalArgumentException("unexpected protobuf end group".toString());
                }

                /* JADX WARN: Code duplicated, block: B:40:0x00f5 A[LOOP:1: B:21:0x0073->B:40:0x00f5, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:84:0x0103 A[SYNTHETIC] */
/* 49 */        public final List<MediaEntry> media(InputStream stream, int maxEntries) throws IOException {
                    List result;
                    AnkiProtoReader ankiProtoReader;
                    int i;
                    boolean z;
                    boolean z2;
                    CodedInputStream codedInputStream;
                    boolean z3;
                    Intrinsics.checkNotNullParameter(stream, "stream");
/* 50 */            CodedInputStream input = bounded(stream, MAX_MEDIA_MAP);
/* 51 */            List result2 = new ArrayList();
                    AnkiProtoReader ankiProtoReader2 = this;
                    int i2 = 0;
                    while (true) {
/* 115 */               int tag = input.readTag();
                        if (tag == 0) {
/* 116 */                   List result3 = result2;
/* 52 */                    input.checkLastTagWas(0);
/* 74 */                    return result3;
                        }
/* 117 */               if (tag != 10) {
                            result = result2;
                            ankiProtoReader = ankiProtoReader2;
                            i = i2;
/* 116 */                   z = false;
                        } else {
/* 116 */                   if (!(result2.size() < maxEntries)) {
/* 54 */                        throw new IllegalArgumentException(("media entry count exceeds " + maxEntries).toString());
                            }
/* 55 */                    int rawVarint32 = input.readRawVarint32();
/* 116 */                   if (!(rawVarint32 >= 0 && rawVarint32 < 524289)) {
                                throw new IllegalArgumentException("media metadata entry is too large".toString());
                            }
/* 57 */                    int iPushLimit = input.pushLimit(rawVarint32);
/* 116 */                   byte[] bArr = new byte[0];
/* 59 */                    Set linkedHashSet = new LinkedHashSet();
/* 60 */                    AnkiProtoReader ankiProtoReader3 = INSTANCE;
                            CodedInputStream codedInputStream2 = input;
                            String str = "";
                            long uInt32 = 0;
                            while (true) {
/* 119 */                       int tag2 = codedInputStream2.readTag();
/* 120 */                       if (tag2 != 0) {
                                    switch (tag2) {
                                        case 10:
/* 121 */                                   INSTANCE.unique(linkedHashSet, tag2);
                                            String stringRequireUtf8 = input.readStringRequireUtf8();
                                            Intrinsics.checkNotNullExpressionValue(stringRequireUtf8, "readStringRequireUtf8(...)");
                                            str = stringRequireUtf8;
                                            z2 = true;
                                            break;
                                        case 16:
/* 121 */                                   INSTANCE.unique(linkedHashSet, tag2);
                                            uInt32 = ((long) input.readUInt32()) & 4294967295L;
                                            z2 = true;
                                            break;
                                        case 26:
/* 121 */                                   INSTANCE.unique(linkedHashSet, tag2);
                                            byte[] byteArray = input.readByteArray();
                                            Intrinsics.checkNotNullExpressionValue(byteArray, "readByteArray(...)");
                                            bArr = byteArray;
                                            z2 = true;
                                            break;
                                        case 2040:
/* 64 */                                    throw new IllegalArgumentException("modern media contains a legacy filename override");
                                        default:
                                            z2 = false;
                                            break;
                                    }
/* 121 */                           if (z2) {
                                        codedInputStream = codedInputStream2;
                                    } else {
                                        codedInputStream = codedInputStream2;
                                        if (!codedInputStream.skipField(tag2)) {
                                            z3 = false;
                                        }
                                        if (z3) {
                                            throw new IllegalArgumentException("unexpected protobuf end group".toString());
                                        }
                                        codedInputStream2 = codedInputStream;
                                        ankiProtoReader2 = ankiProtoReader2;
                                        result2 = result2;
                                        i2 = i2;
                                    }
                                    z3 = true;
                                    if (z3) {
                                        throw new IllegalArgumentException("unexpected protobuf end group".toString());
                                    }
                                    codedInputStream2 = codedInputStream;
                                    ankiProtoReader2 = ankiProtoReader2;
                                    result2 = result2;
                                    i2 = i2;
                                } else {
/* 120 */                           result = result2;
                                    ankiProtoReader = ankiProtoReader2;
                                    i = i2;
/* 123 */                           codedInputStream2.checkLastTagWas(0);
/* 67 */                            if (!(input.getBytesUntilLimit() == 0)) {
                                        throw new IllegalArgumentException("truncated media metadata".toString());
                                    }
/* 68 */                            input.popLimit(iPushLimit);
                                    if (!((str.length() > 0) && bArr.length == 20)) {
                                        throw new IllegalArgumentException("media metadata has an invalid name/digest".toString());
                                    }
/* 70 */                            result.add(new MediaEntry(String.valueOf(result.size()), str, uInt32, bArr));
/* 71 */                            z = true;
                                }
                            }
                        }
/* 117 */               if (!(z || input.skipField(tag))) {
                            throw new IllegalArgumentException("unexpected protobuf end group".toString());
                        }
                        ankiProtoReader2 = ankiProtoReader;
                        result2 = result;
                        i2 = i;
                    }
                }

/* 75 */        private final void unique(Set<Integer> seen, int tag) {
/* 76 */            if (!seen.add(Integer.valueOf(tag))) {
/* 76 */                throw new IllegalArgumentException(("duplicate protobuf field " + tag).toString());
                    }
                }

/* 77 */        private final CodedInputStream bounded(byte[] bytes, int maximum) {
/* 78 */            if (!(bytes.length <= maximum)) {
/* 78 */                throw new IllegalArgumentException(("protobuf exceeds " + maximum + " bytes").toString());
                    }
/* 79 */            return bounded(new ByteArrayInputStream(bytes), maximum);
                }

/* 80 */        private final CodedInputStream bounded(InputStream stream, int maximum) {
/* 81 */            CodedInputStream codedInputStreamNewInstance = CodedInputStream.newInstance(stream);
/* 81 */            codedInputStreamNewInstance.setSizeLimit(maximum);
                    codedInputStreamNewInstance.setRecursionLimit(64);
                    Intrinsics.checkNotNullExpressionValue(codedInputStreamNewInstance, "apply(...)");
                    return codedInputStreamNewInstance;
                }

/* 82 */        private final void fields(CodedInputStream input, Function1<? super Integer, Boolean> read) throws IOException {
                    boolean z;
                    do {
/* 84 */                int tag = input.readTag();
/* 85 */                z = false;
                        if (tag != 0) {
/* 86 */                    if (read.invoke(Integer.valueOf(tag)).booleanValue() || input.skipField(tag)) {
                                z = true;
                            }
                        } else {
/* 88 */                    input.checkLastTagWas(0);
/* 89 */                    return;
                        }
                    } while (z);
                    throw new IllegalArgumentException("unexpected protobuf end group".toString());
                }
            }

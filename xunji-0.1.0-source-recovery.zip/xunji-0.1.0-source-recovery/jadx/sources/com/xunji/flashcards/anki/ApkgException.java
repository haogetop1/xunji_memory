            package com.xunji.flashcards.anki;

            import com.xunji.core.anki.ImportStage;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ApkgReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0003\n\u0002\b\u0005\b\u0001\u0018\u00002\u00060\u0001j\u0002`\u0002B#\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b\t\u0010\nR\u0011\u0010\u0003\u001a\u00020\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Lcom/xunji/flashcards/anki/ApkgException;", "Ljava/lang/IllegalArgumentException;", "Lkotlin/IllegalArgumentException;", "stage", "Lcom/xunji/core/anki/ImportStage;", "message", "", "cause", "", "<init>", "(Lcom/xunji/core/anki/ImportStage;Ljava/lang/String;Ljava/lang/Throwable;)V", "getStage", "()Lcom/xunji/core/anki/ImportStage;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 28 */    public final class ApkgException extends IllegalArgumentException {
                public static final int $stable = 8;
                private final ImportStage stage;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
/* 29 */        public ApkgException(ImportStage stage, String message, Throwable cause) {
/* 30 */            super(message, cause);
                    Intrinsics.checkNotNullParameter(stage, "stage");
                    Intrinsics.checkNotNullParameter(message, "message");
                    this.stage = stage;
                }

/* 29 */        public final ImportStage getStage() {
/* 30 */            return this.stage;
                }
            }

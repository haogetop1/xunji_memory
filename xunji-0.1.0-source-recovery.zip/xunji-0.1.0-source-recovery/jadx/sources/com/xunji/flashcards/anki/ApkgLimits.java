            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: ApkgReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\"\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0081\b\u0018\u00002\u00020\u0001Bu\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\n\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\b\u0012\b\b\u0002\u0010\f\u001a\u00020\b\u0012\b\b\u0002\u0010\r\u001a\u00020\b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\b¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\bHÆ\u0003J\t\u0010#\u001a\u00020\bHÆ\u0003J\t\u0010$\u001a\u00020\bHÆ\u0003J\t\u0010%\u001a\u00020\bHÆ\u0003J\t\u0010&\u001a\u00020\bHÆ\u0003J\t\u0010'\u001a\u00020\bHÆ\u0003J\t\u0010(\u001a\u00020\bHÆ\u0003Jw\u0010)\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\b2\b\b\u0002\u0010\f\u001a\u00020\b2\b\b\u0002\u0010\r\u001a\u00020\b2\b\b\u0002\u0010\u000e\u001a\u00020\bHÆ\u0001J\u0013\u0010*\u001a\u00020+2\b\u0010,\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010-\u001a\u00020\bHÖ\u0001J\t\u0010.\u001a\u00020/HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0017R\u0011\u0010\n\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0017R\u0011\u0010\u000b\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0017R\u0011\u0010\f\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0017R\u0011\u0010\r\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0017R\u0011\u0010\u000e\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u0017¨\u00060"}, d2 = {"Lcom/xunji/flashcards/anki/ApkgLimits;", "", "maxInputBytes", "", "maxDecodedBytes", "maxDatabaseBytes", "maxMediaBytes", "maxZipEntries", "", "maxCards", "maxFieldBytes", "maxNoteStoredBytes", "maxModelStoredBytes", "maxModelsBytes", "maxDecksBytes", "<init>", "(JJJJIIIIIII)V", "getMaxInputBytes", "()J", "getMaxDecodedBytes", "getMaxDatabaseBytes", "getMaxMediaBytes", "getMaxZipEntries", "()I", "getMaxCards", "getMaxFieldBytes", "getMaxNoteStoredBytes", "getMaxModelStoredBytes", "getMaxModelsBytes", "getMaxDecksBytes", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "copy", "equals", "", "other", "hashCode", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 14 */    public final /* data */ class ApkgLimits {
                public static final int $stable = 0;
                private final int maxCards;
                private final long maxDatabaseBytes;
                private final int maxDecksBytes;
                private final long maxDecodedBytes;
                private final int maxFieldBytes;
                private final long maxInputBytes;
                private final long maxMediaBytes;
                private final int maxModelStoredBytes;
                private final int maxModelsBytes;
                private final int maxNoteStoredBytes;
                private final int maxZipEntries;

                public ApkgLimits() {
                    this(0L, 0L, 0L, 0L, 0, 0, 0, 0, 0, 0, 0, 2047);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getMaxInputBytes() {
                    return this.maxInputBytes;
                }

                /* JADX INFO: renamed from: component10, reason: from getter */
                public final int getMaxModelsBytes() {
                    return this.maxModelsBytes;
                }

                /* JADX INFO: renamed from: component11, reason: from getter */
                public final int getMaxDecksBytes() {
                    return this.maxDecksBytes;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final long getMaxDecodedBytes() {
                    return this.maxDecodedBytes;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getMaxDatabaseBytes() {
                    return this.maxDatabaseBytes;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final long getMaxMediaBytes() {
                    return this.maxMediaBytes;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final int getMaxZipEntries() {
                    return this.maxZipEntries;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final int getMaxCards() {
                    return this.maxCards;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final int getMaxFieldBytes() {
                    return this.maxFieldBytes;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final int getMaxNoteStoredBytes() {
                    return this.maxNoteStoredBytes;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final int getMaxModelStoredBytes() {
                    return this.maxModelStoredBytes;
                }

                public final ApkgLimits copy(long maxInputBytes, long maxDecodedBytes, long maxDatabaseBytes, long maxMediaBytes, int maxZipEntries, int maxCards, int maxFieldBytes, int maxNoteStoredBytes, int maxModelStoredBytes, int maxModelsBytes, int maxDecksBytes) {
                    return new ApkgLimits(maxInputBytes, maxDecodedBytes, maxDatabaseBytes, maxMediaBytes, maxZipEntries, maxCards, maxFieldBytes, maxNoteStoredBytes, maxModelStoredBytes, maxModelsBytes, maxDecksBytes);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ApkgLimits)) {
                        return false;
                    }
                    ApkgLimits apkgLimits = (ApkgLimits) other;
                    return this.maxInputBytes == apkgLimits.maxInputBytes && this.maxDecodedBytes == apkgLimits.maxDecodedBytes && this.maxDatabaseBytes == apkgLimits.maxDatabaseBytes && this.maxMediaBytes == apkgLimits.maxMediaBytes && this.maxZipEntries == apkgLimits.maxZipEntries && this.maxCards == apkgLimits.maxCards && this.maxFieldBytes == apkgLimits.maxFieldBytes && this.maxNoteStoredBytes == apkgLimits.maxNoteStoredBytes && this.maxModelStoredBytes == apkgLimits.maxModelStoredBytes && this.maxModelsBytes == apkgLimits.maxModelsBytes && this.maxDecksBytes == apkgLimits.maxDecksBytes;
                }

                public int hashCode() {
                    return (((((((((((((((((((Long.hashCode(this.maxInputBytes) * 31) + Long.hashCode(this.maxDecodedBytes)) * 31) + Long.hashCode(this.maxDatabaseBytes)) * 31) + Long.hashCode(this.maxMediaBytes)) * 31) + Integer.hashCode(this.maxZipEntries)) * 31) + Integer.hashCode(this.maxCards)) * 31) + Integer.hashCode(this.maxFieldBytes)) * 31) + Integer.hashCode(this.maxNoteStoredBytes)) * 31) + Integer.hashCode(this.maxModelStoredBytes)) * 31) + Integer.hashCode(this.maxModelsBytes)) * 31) + Integer.hashCode(this.maxDecksBytes);
                }

                public String toString() {
                    return "ApkgLimits(maxInputBytes=" + this.maxInputBytes + ", maxDecodedBytes=" + this.maxDecodedBytes + ", maxDatabaseBytes=" + this.maxDatabaseBytes + ", maxMediaBytes=" + this.maxMediaBytes + ", maxZipEntries=" + this.maxZipEntries + ", maxCards=" + this.maxCards + ", maxFieldBytes=" + this.maxFieldBytes + ", maxNoteStoredBytes=" + this.maxNoteStoredBytes + ", maxModelStoredBytes=" + this.maxModelStoredBytes + ", maxModelsBytes=" + this.maxModelsBytes + ", maxDecksBytes=" + this.maxDecksBytes + ")";
                }

/* 15 */        public ApkgLimits(long maxInputBytes, long maxDecodedBytes, long maxDatabaseBytes, long maxMediaBytes, int maxZipEntries, int maxCards, int maxFieldBytes, int maxNoteStoredBytes, int maxModelStoredBytes, int maxModelsBytes, int maxDecksBytes) {
/* 16 */            this.maxInputBytes = maxInputBytes;
/* 16 */            this.maxDecodedBytes = maxDecodedBytes;
/* 16 */            this.maxDatabaseBytes = maxDatabaseBytes;
/* 16 */            this.maxMediaBytes = maxMediaBytes;
/* 16 */            this.maxZipEntries = maxZipEntries;
/* 16 */            this.maxCards = maxCards;
/* 16 */            this.maxFieldBytes = maxFieldBytes;
/* 16 */            this.maxNoteStoredBytes = maxNoteStoredBytes;
/* 16 */            this.maxModelStoredBytes = maxModelStoredBytes;
/* 16 */            this.maxModelsBytes = maxModelsBytes;
/* 16 */            this.maxDecksBytes = maxDecksBytes;
                }

/* 16 */        public final long getMaxInputBytes() {
/* 17 */            return this.maxInputBytes;
                }

/* 17 */        public final long getMaxDecodedBytes() {
/* 18 */            return this.maxDecodedBytes;
                }

/* 18 */        public final long getMaxDatabaseBytes() {
/* 19 */            return this.maxDatabaseBytes;
                }

/* 19 */        public final long getMaxMediaBytes() {
/* 20 */            return this.maxMediaBytes;
                }

/* 20 */        public final int getMaxZipEntries() {
/* 21 */            return this.maxZipEntries;
                }

/* 21 */        public final int getMaxCards() {
/* 22 */            return this.maxCards;
                }

/* 22 */        public final int getMaxFieldBytes() {
/* 23 */            return this.maxFieldBytes;
                }

/* 23 */        public final int getMaxNoteStoredBytes() {
/* 24 */            return this.maxNoteStoredBytes;
                }

/* 24 */        public final int getMaxModelStoredBytes() {
/* 25 */            return this.maxModelStoredBytes;
                }

/* 25 */        public final int getMaxModelsBytes() {
/* 26 */            return this.maxModelsBytes;
                }

/* 26 */        public final int getMaxDecksBytes() {
/* 27 */            return this.maxDecksBytes;
                }
            }

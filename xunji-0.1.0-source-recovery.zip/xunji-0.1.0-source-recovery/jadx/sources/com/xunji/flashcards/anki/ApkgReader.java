            package com.xunji.flashcards.anki;

            import android.database.sqlite.SQLiteDatabase;
            import androidx.core.app.NotificationCompat;
            import com.fasterxml.jackson.core.JsonPointer;
            import com.github.luben.zstd.ZstdInputStream;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.core.anki.ImportStage;
            import java.io.File;
            import java.io.FileInputStream;
            import java.io.FileOutputStream;
            import java.io.FilterInputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.security.MessageDigest;
            import java.security.NoSuchAlgorithmException;
            import java.text.Normalizer;
            import java.util.ArrayList;
            import java.util.Arrays;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Locale;
            import java.util.Map;
            import java.util.Set;
            import java.util.UUID;
            import java.util.concurrent.CancellationException;
            import java.util.zip.ZipEntry;
            import java.util.zip.ZipInputStream;
            import kotlin.ExceptionsKt;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.collections.SetsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.io.FilesKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.text.Charsets;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineDispatcher;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.CoroutineScopeKt;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.JobKt;
            import kotlinx.coroutines.NonCancellable;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
            
            /* JADX INFO: compiled from: ApkgReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0001\u0018\u0000 #2\u00020\u0001:\u0001#B\u0011\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J@\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000b2\u0014\b\u0002\u0010\f\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\r2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0086@¢\u0006\u0002\u0010\u0012J,\u0010\u0013\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u000b0\u00142\u0006\u0010\b\u001a\u00020\t2\u0006\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u0017H\u0002J\\\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u00190\u00142\u0006\u0010\u001a\u001a\u00020\u001b2\u0006\u0010\u001c\u001a\u00020\u000b2\u0012\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\u0011\u0012\u0004\u0012\u00020\u000b0\u00142\u0006\u0010\u0015\u001a\u00020\u000b2\u0006\u0010\u0016\u001a\u00020\u00172\u0012\u0010\u001e\u001a\u000e\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\rH\u0002J\u0018\u0010\u001f\u001a\n !*\u0004\u0018\u00010 0 2\u0006\u0010\"\u001a\u00020\u000bH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006$"}, d2 = {"Lcom/xunji/flashcards/anki/ApkgReader;", "", "limits", "Lcom/xunji/flashcards/anki/ApkgLimits;", "<init>", "(Lcom/xunji/flashcards/anki/ApkgLimits;)V", "open", "Lcom/xunji/flashcards/anki/PreparedPackage;", "input", "Ljava/io/InputStream;", "stagingDir", "Ljava/io/File;", "onProgress", "Lkotlin/Function1;", "Lcom/xunji/core/anki/ImportProgress;", "", "sourceName", "", "(Ljava/io/InputStream;Ljava/io/File;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "unpack", "", "directory", "budget", "Lcom/xunji/flashcards/anki/DecodedBudget;", "readMedia", "Lcom/xunji/flashcards/anki/AnkiMediaFile;", "format", "Lcom/xunji/flashcards/anki/PackageFormat;", "manifest", "entries", NotificationCompat.CATEGORY_PROGRESS, "zstd", "Lcom/github/luben/zstd/ZstdInputStream;", "kotlin.jvm.PlatformType", "file", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 44 */    public final class ApkgReader {
                public static final int $stable = 0;
                private static final Companion Companion = new Companion();
                private static final Set<String> PACKAGE_NAMES = SetsKt.setOf((Object[]) new String[]{"meta", "media", "collection.anki2", "collection.anki21", "collection.anki21b"});
                private final ApkgLimits limits;

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.ApkgReader$open$1, reason: invalid class name */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.ApkgReader", f = "ApkgReader.kt", i = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1}, l = {51, 103}, m = "open", n = {"input", "stagingDir", "onProgress", "sourceName", "prepared", "enteredIo", "input", "stagingDir", "onProgress", "sourceName", "prepared", "enteredIo", "error"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return ApkgReader.this.open(null, null, null, null, this);
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
                public ApkgReader() {
                    this(null, 1);
                }

/* 45 */        public ApkgReader(ApkgLimits limits) {
                    Intrinsics.checkNotNullParameter(limits, "limits");
                    this.limits = limits;
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 46 */        public static /* synthetic */ Object open$default(ApkgReader apkgReader, InputStream inputStream, File file, Function1 function1, String str, Continuation continuation, int i, Object obj) {
/* 47 */            if ((i & 4) != 0) {
                        function1 = new Function1() { // from class: com.xunji.flashcards.anki.ApkgReader$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return ApkgReader.open$lambda$0((ImportProgress) obj2);
                            }
                        };
                    }
                    Function1 function2 = function1;
                    if ((i & 8) != 0) {
                        str = null;
                    }
                    return apkgReader.open(inputStream, file, function2, str, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 46 */        public static final Unit open$lambda$0(ImportProgress it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 47 */            return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:36:0x012f A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:37:0x0130  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
/* 46 */        public final Object open(InputStream input, File stagingDir, Function1<? super ImportProgress, Unit> function1, String sourceName, Continuation<? super PreparedPackage> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    ApkgReader apkgReader;
                    InputStream input2;
                    File stagingDir2;
                    CancellationException error;
                    Ref.BooleanRef enteredIo;
                    InputStream input3;
                    Ref.ObjectRef prepared;
                    Function1<? super ImportProgress, Unit> function2;
                    String sourceName2;
                    CoroutineContext coroutineContextPlus;
                    CancellationException error2;
                    AnonymousClass4 anonymousClass4;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                            apkgReader = this;
                        } else {
                            apkgReader = this;
                            anonymousClass1 = apkgReader.new AnonymousClass1(continuation);
                        }
                    } else {
                        apkgReader = this;
                        anonymousClass1 = apkgReader.new AnonymousClass1(continuation);
                    }
                    AnonymousClass1 anonymousClass2 = anonymousClass1;
                    Object $result = anonymousClass2.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass2.label) {
                        case 0:
/* 47 */                    ResultKt.throwOnFailure($result);
/* 48 */                    Ref.ObjectRef prepared2 = new Ref.ObjectRef();
/* 49 */                    Ref.BooleanRef enteredIo2 = new Ref.BooleanRef();
                            try {
/* 51 */                        CoroutineDispatcher io2 = Dispatchers.getIO();
                                input2 = input;
                                try {
                                    AnonymousClass3 anonymousClass3 = new AnonymousClass3(enteredIo2, input2, prepared2, sourceName, stagingDir, apkgReader, function1, null);
                                    input2 = input;
                                    anonymousClass2.L$0 = input2;
                                    anonymousClass2.L$1 = SpillingKt.nullOutSpilledVariable(stagingDir);
                                    anonymousClass2.L$2 = SpillingKt.nullOutSpilledVariable(function1);
                                    anonymousClass2.L$3 = SpillingKt.nullOutSpilledVariable(sourceName);
                                    anonymousClass2.L$4 = prepared2;
                                    anonymousClass2.L$5 = enteredIo2;
                                    anonymousClass2.label = 1;
                                    Object objWithContext = BuildersKt.withContext(io2, anonymousClass3, anonymousClass2);
                                    return objWithContext == coroutine_suspended ? coroutine_suspended : objWithContext;
                                } catch (CancellationException e) {
                                    e = e;
                                    stagingDir2 = stagingDir;
                                    error = e;
                                    enteredIo = enteredIo2;
                                    input3 = input2;
                                    prepared = prepared2;
                                    function2 = function1;
                                    sourceName2 = sourceName;
/* 103 */                           coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                    error2 = error;
                                    anonymousClass4 = new AnonymousClass4(enteredIo, input3, prepared, error, null);
                                    anonymousClass2.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                                    anonymousClass2.L$1 = SpillingKt.nullOutSpilledVariable(stagingDir2);
                                    anonymousClass2.L$2 = SpillingKt.nullOutSpilledVariable(function2);
                                    anonymousClass2.L$3 = SpillingKt.nullOutSpilledVariable(sourceName2);
                                    anonymousClass2.L$4 = SpillingKt.nullOutSpilledVariable(prepared);
                                    anonymousClass2.L$5 = SpillingKt.nullOutSpilledVariable(enteredIo);
                                    anonymousClass2.L$6 = error2;
                                    anonymousClass2.label = 2;
                                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, anonymousClass2) == coroutine_suspended) {
/* 47 */                                return coroutine_suspended;
                                    }
/* 107 */                           throw error2;
                                }
                            } catch (CancellationException e2) {
                                e = e2;
                                input2 = input;
                            }
                            break;
                        case 1:
                            Ref.BooleanRef enteredIo3 = (Ref.BooleanRef) anonymousClass2.L$5;
                            Ref.ObjectRef prepared3 = (Ref.ObjectRef) anonymousClass2.L$4;
                            sourceName2 = (String) anonymousClass2.L$3;
                            function2 = (Function1) anonymousClass2.L$2;
                            stagingDir2 = (File) anonymousClass2.L$1;
                            InputStream input4 = (InputStream) anonymousClass2.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
                                return $result;
                            } catch (CancellationException e3) {
                                error = e3;
                                enteredIo = enteredIo3;
                                prepared = prepared3;
                                input3 = input4;
                            }
                            break;
                        case 2:
                            CancellationException error3 = (CancellationException) anonymousClass2.L$6;
                            ResultKt.throwOnFailure($result);
/* 107 */                   throw error3;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 103 */           coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                    error2 = error;
                    anonymousClass4 = new AnonymousClass4(enteredIo, input3, prepared, error, null);
                    anonymousClass2.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                    anonymousClass2.L$1 = SpillingKt.nullOutSpilledVariable(stagingDir2);
                    anonymousClass2.L$2 = SpillingKt.nullOutSpilledVariable(function2);
                    anonymousClass2.L$3 = SpillingKt.nullOutSpilledVariable(sourceName2);
                    anonymousClass2.L$4 = SpillingKt.nullOutSpilledVariable(prepared);
                    anonymousClass2.L$5 = SpillingKt.nullOutSpilledVariable(enteredIo);
                    anonymousClass2.L$6 = error2;
                    anonymousClass2.label = 2;
                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, anonymousClass2) == coroutine_suspended) {
/* 47 */                return coroutine_suspended;
                    }
/* 107 */           throw error2;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.ApkgReader$open$3, reason: invalid class name */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/PreparedPackage;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.ApkgReader$open$3", f = "ApkgReader.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 49 */        static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super PreparedPackage>, Object> {
                    final /* synthetic */ Ref.BooleanRef $enteredIo;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Function1<ImportProgress, Unit> $onProgress;
                    final /* synthetic */ Ref.ObjectRef<PreparedPackage> $prepared;
                    final /* synthetic */ String $sourceName;
                    final /* synthetic */ File $stagingDir;
                    private /* synthetic */ Object L$0;
                    int label;
                    final /* synthetic */ ApkgReader this$0;

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.ApkgReader$open$3$WhenMappings */
                    /* JADX INFO: compiled from: ApkgReader.kt */
                    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                    public static final /* synthetic */ class WhenMappings {
                        public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                        static {
                            int[] iArr = new int[PackageFormat.values().length];
                            try {
                                iArr[PackageFormat.LEGACY1.ordinal()] = 1;
                            } catch (NoSuchFieldError e) {
                            }
                            try {
                                iArr[PackageFormat.LEGACY2.ordinal()] = 2;
                            } catch (NoSuchFieldError e2) {
                            }
                            try {
                                iArr[PackageFormat.LATEST.ordinal()] = 3;
                            } catch (NoSuchFieldError e3) {
                            }
                            $EnumSwitchMapping$0 = iArr;
                        }
                    }

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    AnonymousClass3(Ref.BooleanRef booleanRef, InputStream inputStream, Ref.ObjectRef<PreparedPackage> objectRef, String str, File file, ApkgReader apkgReader, Function1<? super ImportProgress, Unit> function1, Continuation<? super AnonymousClass3> continuation) {
                        super(2, continuation);
                        this.$enteredIo = booleanRef;
                        this.$input = inputStream;
                        this.$prepared = objectRef;
                        this.$sourceName = str;
                        this.$stagingDir = file;
                        this.this$0 = apkgReader;
                        this.$onProgress = function1;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass3 anonymousClass3 = new AnonymousClass3(this.$enteredIo, this.$input, this.$prepared, this.$sourceName, this.$stagingDir, this.this$0, this.$onProgress, continuation);
                        anonymousClass3.L$0 = obj;
                        return anonymousClass3;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super PreparedPackage> continuation) {
                        return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
                    /* JADX WARN: Code duplicated, block: B:101:0x01b9 A[Catch: all -> 0x0491, TRY_LEAVE, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:107:0x01e0 A[Catch: all -> 0x0491, TRY_LEAVE, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:136:0x024e A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:138:0x0258 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:141:0x026c  */
                    /* JADX WARN: Code duplicated, block: B:145:0x0274 A[Catch: all -> 0x0491, TRY_LEAVE, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:150:0x02a2 A[Catch: all -> 0x0491, TRY_LEAVE, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:157:0x02fc A[Catch: all -> 0x036a, LOOP:0: B:155:0x02f6->B:157:0x02fc, LOOP_END, TryCatch #3 {all -> 0x036a, blocks: (B:154:0x02c5, B:155:0x02f6, B:157:0x02fc, B:158:0x030b), top: B:274:0x02c5 }] */
                    /* JADX WARN: Code duplicated, block: B:188:0x037a  */
                    /* JADX WARN: Code duplicated, block: B:196:0x03a3 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:198:0x03d9 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:202:0x03fa A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:204:0x0410 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:206:0x043d A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:210:0x0453 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:247:0x0502 A[Catch: all -> 0x0538, TryCatch #14 {all -> 0x0538, blocks: (B:245:0x04fe, B:247:0x0502, B:250:0x050f, B:251:0x052c, B:252:0x052d, B:255:0x0537, B:235:0x04e3, B:236:0x04e6), top: B:289:0x0029 }] */
                    /* JADX WARN: Code duplicated, block: B:249:0x050d  */
                    /* JADX WARN: Code duplicated, block: B:252:0x052d A[Catch: all -> 0x0538, TryCatch #14 {all -> 0x0538, blocks: (B:245:0x04fe, B:247:0x0502, B:250:0x050f, B:251:0x052c, B:252:0x052d, B:255:0x0537, B:235:0x04e3, B:236:0x04e6), top: B:289:0x0029 }] */
                    /* JADX WARN: Code duplicated, block: B:80:0x0174 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:81:0x0177 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:83:0x017d A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:91:0x019d A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:95:0x01a5  */
                    /* JADX WARN: Code duplicated, block: B:97:0x01a8 A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Code duplicated, block: B:99:0x01ae A[Catch: all -> 0x0491, TryCatch #28 {all -> 0x0491, blocks: (B:54:0x0119, B:57:0x0131, B:63:0x013e, B:67:0x014b, B:68:0x0155, B:69:0x0158, B:76:0x0167, B:77:0x016c, B:70:0x015b, B:84:0x017f, B:85:0x0188, B:86:0x018b, B:208:0x044f, B:209:0x0452, B:89:0x0197, B:91:0x019d, B:97:0x01a8, B:99:0x01ae, B:101:0x01b9, B:105:0x01d1, B:107:0x01e0, B:116:0x0229, B:139:0x025a, B:145:0x0274, B:148:0x028c, B:150:0x02a2, B:189:0x0385, B:190:0x0390, B:195:0x039f, B:196:0x03a3, B:197:0x03d8, B:134:0x024a, B:135:0x024d, B:136:0x024e, B:138:0x0258, B:198:0x03d9, B:199:0x03ef, B:202:0x03fa, B:203:0x040f, B:204:0x0410, B:205:0x043c, B:206:0x043d, B:207:0x044e, B:71:0x015e, B:72:0x0161, B:78:0x016d, B:80:0x0174, B:81:0x0177, B:83:0x017d, B:210:0x0453, B:211:0x045f, B:212:0x0460, B:213:0x0471, B:216:0x047c, B:217:0x0490, B:132:0x0248, B:146:0x027c, B:193:0x039d), top: B:303:0x00ea, inners: #23, #27, #34 }] */
                    /* JADX WARN: Multi-variable type inference failed */
                    /* JADX WARN: Type inference failed for: r0v75, types: [T, com.xunji.flashcards.anki.PreparedPackage, java.lang.Object] */
                    /* JADX WARN: Type inference failed for: r2v17 */
                    /* JADX WARN: Type inference failed for: r2v18 */
                    /* JADX WARN: Type inference failed for: r2v23 */
                    /* JADX WARN: Type inference failed for: r2v24 */
                    /* JADX WARN: Type inference failed for: r2v74 */
                    /* JADX WARN: Type inference failed for: r2v76 */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 50 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        String message;
                        Throwable th;
                        Object directory;
                        Object directory2;
                        Object source;
                        PackageFormat packageFormat;
                        boolean z;
                        Object obj;
                        File file;
                        Object obj2;
                        File file2;
                        ImportStage importStage;
                        File file3;
                        File file4;
                        DecodedBudget decodedBudget;
                        long length;
                        FileInputStream fileInputStream;
                        byte[] nBytesCompat;
                        byte[] bytes;
                        AnkiPackageDatabase ankiPackageDatabase;
                        ImportStage importStage2;
                        Iterator it;
                        ZstdInputStream zstdInputStreamZstd;
                        Throwable th2;
                        FileOutputStream fileOutputStream;
                        Throwable th3;
                        CoroutineScope coroutineScope = (CoroutineScope) this.L$0;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 52 */                        this.$enteredIo.element = true;
                                ImportStage importStage3 = ImportStage.PACKAGE;
/* 54 */                        Object source2 = null;
                                Object source3 = null;
                                try {
                                    try {
/* 56 */                                InputStream inputStream = this.$input;
                                        String str = this.$sourceName;
                                        File file5 = this.$stagingDir;
                                        ApkgReader apkgReader = this.this$0;
                                        Function1<ImportProgress, Unit> function1 = this.$onProgress;
                                        try {
                                            InputStream inputStream2 = inputStream;
                                            if (str != null) {
                                                source = null;
                                                try {
                                                    try {
/* 57 */                                                String strSubstringAfterLast$default = StringsKt.substringAfterLast$default(StringsKt.substringAfterLast$default(str, JsonPointer.SEPARATOR, (String) null, 2, (Object) null), AbstractJsonLexerKt.STRING_ESC, (String) null, 2, (Object) null);
                                                        Locale ROOT = Locale.ROOT;
                                                        Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                                                        String lowerCase = strSubstringAfterLast$default.toLowerCase(ROOT);
                                                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
/* 54 */                                                directory = null;
                                                        directory2 = null;
                                                        try {
/* 57 */                                                    if (!(StringsKt.endsWith$default(lowerCase, ".apkg", false, 2, (Object) null) && !Intrinsics.areEqual(lowerCase, "collection.apkg"))) {
/* 59 */                                                        throw new IllegalArgumentException("Only deck .apkg packages are supported; collection backups are not supported".toString());
                                                            }
/* 57 */                                                    Unit unit = Unit.INSTANCE;
                                                        } catch (Throwable th4) {
                                                            th = th4;
                                                        }
                                                    } catch (Throwable th5) {
                                                        th = th5;
                                                    }
                                                } catch (Throwable th6) {
                                                    th = th6;
                                                }
                                            } else {
/* 54 */                                        directory = null;
                                                directory2 = null;
                                            }
                                            try {
                                                try {
/* 61 */                                            if (((file5.isDirectory() || file5.mkdirs()) ? 1 : directory2) == 0) {
/* 61 */                                                throw new IllegalArgumentException("Cannot create import staging directory".toString());
                                                    }
                                                    if ((file5.getUsableSpace() > 0 ? 1 : directory2) == 0) {
/* 62 */                                                throw new IllegalArgumentException("No free staging space is available".toString());
                                                    }
/* 63 */                                            File file6 = new File(file5, "anki-" + UUID.randomUUID());
                                                    try {
                                                        try {
/* 64 */                                                    if (!file6.mkdir()) {
/* 64 */                                                        throw new IllegalArgumentException("Cannot create package staging directory".toString());
                                                            }
                                                            try {
/* 65 */                                                        DecodedBudget decodedBudget2 = new DecodedBudget(apkgReader.limits.getMaxDecodedBytes(), coroutineScope.getCoroutineContext());
                                                                boolean z2 = false;
                                                                source = null;
/* 66 */                                                        function1.invoke(new ImportProgress(importStage3, 0L, null, 4));
                                                                CoroutineScopeKt.ensureActive(coroutineScope);
/* 46 */                                                        Map mapUnpack = apkgReader.unpack(inputStream2, file6, decodedBudget2);
/* 68 */                                                        ImportStage importStage4 = ImportStage.METADATA;
/* 69 */                                                        if (!((mapUnpack.get("meta") == null && mapUnpack.containsKey("collection.anki21b")) ? false : true)) {
/* 69 */                                                            throw new IllegalArgumentException("Modern database requires package metadata; dummy legacy fallback is forbidden".toString());
                                                                }
/* 70 */                                                        File file7 = (File) mapUnpack.get("meta");
                                                                String str2 = "collection.anki2";
                                                                if (file7 != null) {
                                                                    switch (AnkiProtoReader.INSTANCE.version(FilesKt.readBytes(file7))) {
                                                                        case 1:
                                                                            packageFormat = PackageFormat.LEGACY1;
                                                                            break;
                                                                        case 2:
                                                                            packageFormat = PackageFormat.LEGACY2;
                                                                            break;
                                                                        case 3:
/* 71 */                                                                    packageFormat = PackageFormat.LATEST;
                                                                            break;
                                                                        default:
/* 72 */                                                                    throw new IllegalArgumentException("Unknown Anki package metadata version");
                                                                    }
/* 70 */                                                            if (packageFormat == null) {
/* 74 */                                                                if (mapUnpack.containsKey("collection.anki21")) {
                                                                            packageFormat = PackageFormat.LEGACY2;
                                                                        } else {
/* 75 */                                                                    if (mapUnpack.containsKey("collection.anki2")) {
                                                                                throw new IllegalArgumentException("Missing supported package metadata/database");
                                                                            }
                                                                            packageFormat = PackageFormat.LEGACY1;
                                                                        }
                                                                    }
                                                                } else if (mapUnpack.containsKey("collection.anki21")) {
                                                                    packageFormat = PackageFormat.LEGACY2;
                                                                } else {
/* 75 */                                                            if (mapUnpack.containsKey("collection.anki2")) {
                                                                        throw new IllegalArgumentException("Missing supported package metadata/database");
                                                                    }
                                                                    packageFormat = PackageFormat.LEGACY1;
                                                                }
                                                                switch (WhenMappings.$EnumSwitchMapping$0[packageFormat.ordinal()]) {
                                                                    case 1:
/* 79 */                                                                if (mapUnpack.containsKey("collection.anki21b") || packageFormat == PackageFormat.LATEST) {
                                                                            z = true;
                                                                        } else {
                                                                            z = false;
                                                                        }
                                                                        if (!z) {
/* 79 */                                                                    throw new IllegalArgumentException("Modern database conflicts with package metadata version".toString());
                                                                        }
/* 80 */                                                                obj = mapUnpack.get(str2);
                                                                        if (obj == null) {
                                                                            throw new IllegalStateException(("Metadata-selected database " + str2 + " is missing").toString());
                                                                        }
                                                                        file = (File) obj;
/* 81 */                                                                obj2 = mapUnpack.get("media");
                                                                        if (obj2 == null) {
/* 81 */                                                                    throw new IllegalStateException("Package media manifest is missing".toString());
                                                                        }
                                                                        file2 = (File) obj2;
/* 82 */                                                                importStage = ImportStage.DATABASE;
                                                                        try {
                                                                            importStage3 = importStage;
                                                                            function1.invoke(new ImportProgress(importStage, 0L, null, 4));
/* 83 */                                                                    file3 = new File(file6, "source.db");
/* 84 */                                                                    if (packageFormat == PackageFormat.LATEST) {
/* 46 */                                                                        zstdInputStreamZstd = apkgReader.zstd(file);
                                                                                try {
                                                                                    ZstdInputStream zstdInputStream = zstdInputStreamZstd;
                                                                                    file4 = file6;
                                                                                    try {
                                                                                        try {
/* 84 */                                                                                    fileOutputStream = new FileOutputStream(file3);
                                                                                            try {
/* 84 */                                                                                        Intrinsics.checkNotNull(zstdInputStream);
                                                                                                decodedBudget = decodedBudget2;
                                                                                                try {
/* 46 */                                                                                            long jCopyDecoded$default = BoundedApkgKt.copyDecoded$default(zstdInputStream, fileOutputStream, apkgReader.limits.getMaxDatabaseBytes(), decodedBudget, "database", null, null, null, 224, null);
                                                                                                    CloseableKt.closeFinally(fileOutputStream, null);
                                                                                                    Boxing.boxLong(jCopyDecoded$default);
                                                                                                    CloseableKt.closeFinally(zstdInputStreamZstd, null);
                                                                                                } catch (Throwable th7) {
                                                                                                    th3 = th7;
                                                                                                    try {
                                                                                                        throw th3;
                                                                                                    } catch (Throwable th8) {
                                                                                                        CloseableKt.closeFinally(fileOutputStream, th3);
                                                                                                        throw th8;
                                                                                                    }
                                                                                                }
                                                                                            } catch (Throwable th9) {
                                                                                                th3 = th9;
                                                                                            }
                                                                                        } catch (Throwable th10) {
                                                                                            th2 = th10;
                                                                                            try {
                                                                                                throw th2;
                                                                                            } catch (Throwable th11) {
                                                                                                CloseableKt.closeFinally(zstdInputStreamZstd, th2);
                                                                                                throw th11;
                                                                                            }
                                                                                        }
                                                                                    } catch (Throwable th12) {
                                                                                        th2 = th12;
                                                                                        throw th2;
                                                                                    }
                                                                                } catch (Throwable th13) {
                                                                                    th2 = th13;
                                                                                }
                                                                            } else {
/* 85 */                                                                        file4 = file6;
                                                                                decodedBudget = decodedBudget2;
                                                                                if (!file.renameTo(file3)) {
/* 85 */                                                                            throw new IllegalArgumentException("Cannot stage source database".toString());
                                                                                }
                                                                                Unit unit2 = Unit.INSTANCE;
                                                                            }
/* 46 */                                                                    long maxDatabaseBytes = apkgReader.limits.getMaxDatabaseBytes();
                                                                            length = file3.length();
                                                                            if (16 <= length && length <= maxDatabaseBytes) {
                                                                                z2 = true;
                                                                            }
                                                                            if (!z2) {
                                                                                throw new IllegalArgumentException(("Database exceeds " + apkgReader.limits.getMaxDatabaseBytes() + " bytes or is truncated").toString());
                                                                            }
/* 87 */                                                                    fileInputStream = new FileInputStream(file3);
                                                                            try {
/* 87 */                                                                        nBytesCompat = BoundedApkgKt.readNBytesCompat(fileInputStream, 16);
                                                                                CloseableKt.closeFinally(fileInputStream, null);
                                                                                bytes = "SQLite format 3\u0000".getBytes(Charsets.UTF_8);
                                                                                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                                                                if (!Arrays.equals(nBytesCompat, bytes)) {
/* 87 */                                                                            throw new IllegalArgumentException("Invalid SQLite database header".toString());
                                                                                }
/* 88 */                                                                        SQLiteDatabase sQLiteDatabaseOpenDatabase = SQLiteDatabase.openDatabase(file3.getPath(), null, 17);
                                                                                Intrinsics.checkNotNull(sQLiteDatabaseOpenDatabase);
/* 89 */                                                                        ankiPackageDatabase = new AnkiPackageDatabase(sQLiteDatabaseOpenDatabase, apkgReader.limits);
                                                                                try {
/* 90 */                                                                            ankiPackageDatabase.validate(packageFormat, coroutineScope.getCoroutineContext(), function1);
/* 91 */                                                                            importStage2 = ImportStage.MEDIA;
                                                                                    try {
                                                                                        function1.invoke(new ImportProgress(importStage2, 0L, null, 4));
                                                                                        File file8 = file4;
/* 46 */                                                                                Map media = apkgReader.readMedia(packageFormat, file2, mapUnpack, file8, decodedBudget, function1);
/* 174 */                                                                               it = mapUnpack.values().iterator();
                                                                                        while (it.hasNext()) {
/* 93 */                                                                                    ((File) it.next()).delete();
                                                                                        }
                                                                                        try {
/* 94 */                                                                                    function1.invoke(new ImportProgress(ImportStage.READY, ankiPackageDatabase.getCardCount(), Boxing.boxLong(ankiPackageDatabase.getCardCount())));
                                                                                            CoroutineScopeKt.ensureActive(coroutineScope);
/* 95 */                                                                                    ?? preparedPackage = new PreparedPackage(file8, ankiPackageDatabase, packageFormat, media);
                                                                                            try {
/* 56 */                                                                                        CloseableKt.closeFinally(inputStream, null);
/* 97 */                                                                                        CoroutineScopeKt.ensureActive(coroutineScope);
                                                                                                try {
                                                                                                    this.$prepared.element = preparedPackage;
/* 99 */                                                                                            return preparedPackage;
                                                                                                } catch (CancellationException e) {
/* 98 */                                                                                            error = e;
                                                                                                    throw error;
                                                                                                } catch (Exception e2) {
                                                                                                    error = e2;
                                                                                                    importStage3 = importStage2;
                                                                                                    if (!(error instanceof ApkgException)) {
                                                                                                        throw error;
                                                                                                    }
                                                                                                    ImportStage importStage5 = importStage3;
                                                                                                    message = error.getMessage();
                                                                                                    if (message == null) {
                                                                                                        message = "package read failed";
                                                                                                    }
                                                                                                    throw new ApkgException(importStage5, importStage3 + ": " + message, error);
                                                                                                } catch (Throwable th14) {
                                                                                                    error = th14;
                                                                                                    source3 = ankiPackageDatabase;
                                                                                                    source2 = file6;
                                                                                                    if (0 == 0) {
                                                                                                        try {
                                                                                                            AnkiPackageDatabase ankiPackageDatabase2 = (AnkiPackageDatabase) source3;
                                                                                                            if (ankiPackageDatabase2 != null) {
                                                                                                                ankiPackageDatabase2.close();
                                                                                                                Unit unit3 = Unit.INSTANCE;
                                                                                                            }
                                                                                                        } finally {
                                                                                                            File file9 = (File) source2;
                                                                                                            if (file9 != null) {
                                                                                                                Boxing.boxBoolean(FilesKt.deleteRecursively(file9));
                                                                                                            }
                                                                                                        }
                                                                                                        break;
                                                                                                    }
                                                                                                    throw error;
                                                                                                }
                                                                                            } catch (CancellationException e3) {
/* 98 */                                                                                        error = e3;
                                                                                            } catch (Exception e4) {
                                                                                                error = e4;
                                                                                            } catch (Throwable th15) {
/* 99 */                                                                                        error = th15;
                                                                                            }
                                                                                        } catch (Throwable th16) {
/* 56 */                                                                                    th = th16;
                                                                                            th = th;
                                                                                            importStage3 = importStage2;
                                                                                            throw th;
                                                                                        }
                                                                                    } catch (Throwable th17) {
                                                                                        th = th17;
                                                                                    }
                                                                                } catch (Throwable th18) {
                                                                                    th = th18;
                                                                                }
                                                                            } catch (Throwable th19) {
                                                                                try {
                                                                                    throw th19;
                                                                                } catch (Throwable th20) {
                                                                                    CloseableKt.closeFinally(fileInputStream, th19);
                                                                                    throw th20;
                                                                                }
                                                                            }
                                                                        } catch (Throwable th21) {
                                                                            importStage3 = importStage;
                                                                            th = th21;
                                                                        }
                                                                        break;
                                                                    case 2:
                                                                        str2 = "collection.anki21";
/* 79 */                                                                if (mapUnpack.containsKey("collection.anki21b")) {
                                                                            z = true;
                                                                        } else {
                                                                            z = true;
                                                                        }
                                                                        if (!z) {
/* 79 */                                                                    throw new IllegalArgumentException("Modern database conflicts with package metadata version".toString());
                                                                        }
/* 80 */                                                                obj = mapUnpack.get(str2);
                                                                        if (obj == null) {
                                                                            throw new IllegalStateException(("Metadata-selected database " + str2 + " is missing").toString());
                                                                        }
                                                                        file = (File) obj;
/* 81 */                                                                obj2 = mapUnpack.get("media");
                                                                        if (obj2 == null) {
/* 81 */                                                                    throw new IllegalStateException("Package media manifest is missing".toString());
                                                                        }
                                                                        file2 = (File) obj2;
/* 82 */                                                                importStage = ImportStage.DATABASE;
                                                                        importStage3 = importStage;
                                                                        function1.invoke(new ImportProgress(importStage, 0L, null, 4));
/* 83 */                                                                file3 = new File(file6, "source.db");
/* 84 */                                                                if (packageFormat == PackageFormat.LATEST) {
/* 46 */                                                                    zstdInputStreamZstd = apkgReader.zstd(file);
                                                                            ZstdInputStream zstdInputStream2 = zstdInputStreamZstd;
                                                                            file4 = file6;
/* 84 */                                                                    fileOutputStream = new FileOutputStream(file3);
/* 84 */                                                                    Intrinsics.checkNotNull(zstdInputStream2);
                                                                            decodedBudget = decodedBudget2;
/* 46 */                                                                    long jCopyDecoded$default2 = BoundedApkgKt.copyDecoded$default(zstdInputStream2, fileOutputStream, apkgReader.limits.getMaxDatabaseBytes(), decodedBudget, "database", null, null, null, 224, null);
                                                                            CloseableKt.closeFinally(fileOutputStream, null);
                                                                            Boxing.boxLong(jCopyDecoded$default2);
                                                                            CloseableKt.closeFinally(zstdInputStreamZstd, null);
                                                                        } else {
/* 85 */                                                                    file4 = file6;
                                                                            decodedBudget = decodedBudget2;
                                                                            if (!file.renameTo(file3)) {
/* 85 */                                                                        throw new IllegalArgumentException("Cannot stage source database".toString());
                                                                            }
                                                                            Unit unit4 = Unit.INSTANCE;
                                                                        }
/* 46 */                                                                long maxDatabaseBytes2 = apkgReader.limits.getMaxDatabaseBytes();
                                                                        length = file3.length();
                                                                        if (16 <= length) {
                                                                            z2 = true;
                                                                        }
                                                                        if (!z2) {
                                                                            throw new IllegalArgumentException(("Database exceeds " + apkgReader.limits.getMaxDatabaseBytes() + " bytes or is truncated").toString());
                                                                        }
/* 87 */                                                                fileInputStream = new FileInputStream(file3);
/* 87 */                                                                nBytesCompat = BoundedApkgKt.readNBytesCompat(fileInputStream, 16);
                                                                        CloseableKt.closeFinally(fileInputStream, null);
                                                                        bytes = "SQLite format 3\u0000".getBytes(Charsets.UTF_8);
                                                                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                                                        if (!Arrays.equals(nBytesCompat, bytes)) {
/* 87 */                                                                    throw new IllegalArgumentException("Invalid SQLite database header".toString());
                                                                        }
/* 88 */                                                                SQLiteDatabase sQLiteDatabaseOpenDatabase2 = SQLiteDatabase.openDatabase(file3.getPath(), null, 17);
                                                                        Intrinsics.checkNotNull(sQLiteDatabaseOpenDatabase2);
/* 89 */                                                                ankiPackageDatabase = new AnkiPackageDatabase(sQLiteDatabaseOpenDatabase2, apkgReader.limits);
/* 90 */                                                                ankiPackageDatabase.validate(packageFormat, coroutineScope.getCoroutineContext(), function1);
/* 91 */                                                                importStage2 = ImportStage.MEDIA;
                                                                        function1.invoke(new ImportProgress(importStage2, 0L, null, 4));
                                                                        File file10 = file4;
/* 46 */                                                                Map media2 = apkgReader.readMedia(packageFormat, file2, mapUnpack, file10, decodedBudget, function1);
/* 174 */                                                               it = mapUnpack.values().iterator();
                                                                        while (it.hasNext()) {
/* 93 */                                                                    ((File) it.next()).delete();
                                                                        }
/* 94 */                                                                function1.invoke(new ImportProgress(ImportStage.READY, ankiPackageDatabase.getCardCount(), Boxing.boxLong(ankiPackageDatabase.getCardCount())));
                                                                        CoroutineScopeKt.ensureActive(coroutineScope);
/* 95 */                                                                ?? preparedPackage2 = new PreparedPackage(file10, ankiPackageDatabase, packageFormat, media2);
/* 56 */                                                                CloseableKt.closeFinally(inputStream, null);
/* 97 */                                                                CoroutineScopeKt.ensureActive(coroutineScope);
                                                                        this.$prepared.element = preparedPackage2;
/* 99 */                                                                return preparedPackage2;
                                                                    case 3:
                                                                        str2 = "collection.anki21b";
/* 79 */                                                                if (mapUnpack.containsKey("collection.anki21b")) {
                                                                            z = true;
                                                                        } else {
                                                                            z = true;
                                                                        }
                                                                        if (!z) {
/* 79 */                                                                    throw new IllegalArgumentException("Modern database conflicts with package metadata version".toString());
                                                                        }
/* 80 */                                                                obj = mapUnpack.get(str2);
                                                                        if (obj == null) {
                                                                            throw new IllegalStateException(("Metadata-selected database " + str2 + " is missing").toString());
                                                                        }
                                                                        file = (File) obj;
/* 81 */                                                                obj2 = mapUnpack.get("media");
                                                                        if (obj2 == null) {
/* 81 */                                                                    throw new IllegalStateException("Package media manifest is missing".toString());
                                                                        }
                                                                        file2 = (File) obj2;
/* 82 */                                                                importStage = ImportStage.DATABASE;
                                                                        importStage3 = importStage;
                                                                        function1.invoke(new ImportProgress(importStage, 0L, null, 4));
/* 83 */                                                                file3 = new File(file6, "source.db");
/* 84 */                                                                if (packageFormat == PackageFormat.LATEST) {
/* 46 */                                                                    zstdInputStreamZstd = apkgReader.zstd(file);
                                                                            ZstdInputStream zstdInputStream3 = zstdInputStreamZstd;
                                                                            file4 = file6;
/* 84 */                                                                    fileOutputStream = new FileOutputStream(file3);
/* 84 */                                                                    Intrinsics.checkNotNull(zstdInputStream3);
                                                                            decodedBudget = decodedBudget2;
/* 46 */                                                                    long jCopyDecoded$default3 = BoundedApkgKt.copyDecoded$default(zstdInputStream3, fileOutputStream, apkgReader.limits.getMaxDatabaseBytes(), decodedBudget, "database", null, null, null, 224, null);
                                                                            CloseableKt.closeFinally(fileOutputStream, null);
                                                                            Boxing.boxLong(jCopyDecoded$default3);
                                                                            CloseableKt.closeFinally(zstdInputStreamZstd, null);
                                                                        } else {
/* 85 */                                                                    file4 = file6;
                                                                            decodedBudget = decodedBudget2;
                                                                            if (!file.renameTo(file3)) {
/* 85 */                                                                        throw new IllegalArgumentException("Cannot stage source database".toString());
                                                                            }
                                                                            Unit unit5 = Unit.INSTANCE;
                                                                        }
/* 46 */                                                                long maxDatabaseBytes3 = apkgReader.limits.getMaxDatabaseBytes();
                                                                        length = file3.length();
                                                                        if (16 <= length) {
                                                                            z2 = true;
                                                                        }
                                                                        if (!z2) {
                                                                            throw new IllegalArgumentException(("Database exceeds " + apkgReader.limits.getMaxDatabaseBytes() + " bytes or is truncated").toString());
                                                                        }
/* 87 */                                                                fileInputStream = new FileInputStream(file3);
/* 87 */                                                                nBytesCompat = BoundedApkgKt.readNBytesCompat(fileInputStream, 16);
                                                                        CloseableKt.closeFinally(fileInputStream, null);
                                                                        bytes = "SQLite format 3\u0000".getBytes(Charsets.UTF_8);
                                                                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                                                        if (!Arrays.equals(nBytesCompat, bytes)) {
/* 87 */                                                                    throw new IllegalArgumentException("Invalid SQLite database header".toString());
                                                                        }
/* 88 */                                                                SQLiteDatabase sQLiteDatabaseOpenDatabase3 = SQLiteDatabase.openDatabase(file3.getPath(), null, 17);
                                                                        Intrinsics.checkNotNull(sQLiteDatabaseOpenDatabase3);
/* 89 */                                                                ankiPackageDatabase = new AnkiPackageDatabase(sQLiteDatabaseOpenDatabase3, apkgReader.limits);
/* 90 */                                                                ankiPackageDatabase.validate(packageFormat, coroutineScope.getCoroutineContext(), function1);
/* 91 */                                                                importStage2 = ImportStage.MEDIA;
                                                                        function1.invoke(new ImportProgress(importStage2, 0L, null, 4));
                                                                        File file11 = file4;
/* 46 */                                                                Map media3 = apkgReader.readMedia(packageFormat, file2, mapUnpack, file11, decodedBudget, function1);
/* 174 */                                                               it = mapUnpack.values().iterator();
                                                                        while (it.hasNext()) {
/* 93 */                                                                    ((File) it.next()).delete();
                                                                        }
/* 94 */                                                                function1.invoke(new ImportProgress(ImportStage.READY, ankiPackageDatabase.getCardCount(), Boxing.boxLong(ankiPackageDatabase.getCardCount())));
                                                                        CoroutineScopeKt.ensureActive(coroutineScope);
/* 95 */                                                                ?? preparedPackage3 = new PreparedPackage(file11, ankiPackageDatabase, packageFormat, media3);
/* 56 */                                                                CloseableKt.closeFinally(inputStream, null);
/* 97 */                                                                CoroutineScopeKt.ensureActive(coroutineScope);
                                                                        this.$prepared.element = preparedPackage3;
/* 99 */                                                                return preparedPackage3;
                                                                    default:
/* 78 */                                                                throw new NoWhenBranchMatchedException();
                                                                }
                                                            } catch (Throwable th22) {
                                                                th = th22;
                                                            }
                                                        } catch (Throwable th23) {
                                                            th = th23;
                                                        }
                                                    } catch (Throwable th24) {
                                                        th = th24;
                                                    }
                                                } catch (Throwable th25) {
                                                    th = th25;
                                                }
                                            } catch (Throwable th26) {
                                                th = th26;
                                            }
                                        } catch (Throwable th27) {
                                            th = th27;
                                        }
                                        try {
                                            throw th;
                                        } catch (Throwable th28) {
                                            try {
                                                CloseableKt.closeFinally(inputStream, th);
                                                throw th28;
                                            } catch (CancellationException error) {
                                                throw error;
                                            } catch (Exception e5) {
/* 99 */                                        error = e5;
                                                if (!(error instanceof ApkgException)) {
                                                    throw error;
                                                }
                                                ImportStage importStage6 = importStage3;
                                                message = error.getMessage();
                                                if (message == null) {
                                                    message = "package read failed";
                                                }
                                                throw new ApkgException(importStage6, importStage3 + ": " + message, error);
                                            }
                                        }
                                    } catch (Throwable th29) {
/* 99 */                                error = th29;
                                    }
                                } catch (CancellationException error2) {
                                    throw error2;
                                } catch (Exception e6) {
                                    error = e6;
                                } catch (Throwable th30) {
/* 99 */                            error = th30;
                                }
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.ApkgReader$open$4, reason: invalid class name */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.ApkgReader$open$4", f = "ApkgReader.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 101 */       static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Ref.BooleanRef $enteredIo;
                    final /* synthetic */ CancellationException $error;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Ref.ObjectRef<PreparedPackage> $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass4(Ref.BooleanRef booleanRef, InputStream inputStream, Ref.ObjectRef<PreparedPackage> objectRef, CancellationException cancellationException, Continuation<? super AnonymousClass4> continuation) {
                        super(2, continuation);
                        this.$enteredIo = booleanRef;
                        this.$input = inputStream;
                        this.$prepared = objectRef;
                        this.$error = cancellationException;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass4(this.$enteredIo, this.$input, this.$prepared, this.$error, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 102 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 104 */                           if (!this.$enteredIo.element) {
                                        this.$input.close();
                                    }
                                    PreparedPackage preparedPackage = this.$prepared.element;
                                    if (preparedPackage == null) {
                                        return null;
                                    }
                                    preparedPackage.close();
                                    return Unit.INSTANCE;
                                } catch (Exception cleanup) {
                                    ExceptionsKt.addSuppressed(this.$error, cleanup);
                                    return Unit.INSTANCE;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:39:0x00e1  */
                /* JADX WARN: Type inference failed for: r0v9, types: [com.xunji.flashcards.anki.ApkgReader$unpack$1$counted$1] */
/* 111 */       public final Map<String, File> unpack(final InputStream input, File directory, DecodedBudget budget) {
                    Throwable th;
                    Throwable th2;
                    long maxMediaBytes;
                    Throwable th3;
                    File file = directory;
                    LinkedHashMap result = new LinkedHashMap();
                    LinkedHashMap records = new LinkedHashMap();
                    File archive = new File(file, "archive.zip");
/* 113 */           FileOutputStream fileOutputStream = new FileOutputStream(archive);
                    try {
                        final FileOutputStream fileOutputStream2 = fileOutputStream;
                        final DecodedBudget decodedBudget = budget;
                        try {
/* 112 */                   final ?? r0 = new FilterInputStream(input) { // from class: com.xunji.flashcards.anki.ApkgReader$unpack$1$counted$1
                                private long size;

/* 114 */                       public final long getSize() {
/* 115 */                           return this.size;
                                }

/* 114 */                       public final void setSize(long j) {
/* 115 */                           this.size = j;
                                }

                                @Override // java.io.FilterInputStream, java.io.InputStream
/* 115 */                       public int read() throws IOException {
/* 116 */                           int i = ((FilterInputStream) this).in.read();
                                    FileOutputStream fileOutputStream3 = fileOutputStream2;
/* 116 */                           if (i >= 0) {
                                        count(1);
                                        fileOutputStream3.write(i);
                                    }
                                    return i;
                                }

                                @Override // java.io.FilterInputStream, java.io.InputStream
/* 116 */                       public int read(byte[] bytes, int offset, int length) throws IOException {
                                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 117 */                           int i = ((FilterInputStream) this).in.read(bytes, offset, length);
                                    FileOutputStream fileOutputStream3 = fileOutputStream2;
/* 117 */                           if (i > 0) {
                                        count(i);
                                        fileOutputStream3.write(bytes, offset, i);
                                    }
                                    return i;
                                }

                                @Override // java.io.FilterInputStream, java.io.InputStream
/* 117 */                       public long skip(long n) {
/* 118 */                           return BoundedApkgKt.consumeSkip(this, n);
                                }

/* 118 */                       private final void count(int n) {
/* 119 */                           JobKt.ensureActive(decodedBudget.getContext());
                                    this.size += (long) n;
                                    boolean z = this.size <= this.limits.getMaxInputBytes();
                                    ApkgReader apkgReader = this;
                                    if (z) {
                                    } else {
                                        throw new IllegalArgumentException(("Input ZIP exceeds " + apkgReader.limits.getMaxInputBytes() + " bytes").toString());
                                    }
                                }
                            };
/* 122 */                   ZipInputStream zipInputStream = new ZipInputStream(new FilterInputStream(r0) { // from class: com.xunji.flashcards.anki.ApkgReader$unpack$1$borrowed$1
                                {
/* 121 */                           super(r0);
                                }

                                @Override // java.io.FilterInputStream, java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
/* 120 */                       public void close() {
                                }
                            });
                            try {
                                ZipInputStream zipInputStream2 = zipInputStream;
                                while (true) {
/* 124 */                           JobKt.ensureActive(decodedBudget.getContext());
                                    ZipEntry nextEntry = zipInputStream2.getNextEntry();
                                    if (nextEntry == null) {
                                        try {
/* 135 */                                   byte[] bArr = new byte[65536];
/* 136 */                                   while (r0.read(bArr) >= 0) {
                                                JobKt.ensureActive(decodedBudget.getContext());
                                            }
                                            Unit unit = Unit.INSTANCE;
                                            try {
/* 122 */                                       CloseableKt.closeFinally(zipInputStream, null);
                                                Unit unit2 = Unit.INSTANCE;
/* 113 */                                       CloseableKt.closeFinally(fileOutputStream, null);
/* 112 */                                       BoundedApkgKt.validateZipDirectory$default(archive, records, this.limits.getMaxZipEntries(), decodedBudget.getContext(), null, 16, null);
                                                archive.delete();
/* 140 */                                       return result;
                                            } catch (Throwable th4) {
                                                th = th4;
                                                try {
                                                    throw th;
                                                } catch (Throwable th5) {
                                                    CloseableKt.closeFinally(fileOutputStream, th);
                                                    throw th5;
                                                }
                                            }
                                        } catch (Throwable th6) {
                                            th2 = th6;
                                            throw th2;
                                        }
                                    }
                                    boolean z = true;
                                    LinkedHashMap records2 = records;
/* 112 */                           if (!(result.size() < this.limits.getMaxZipEntries())) {
                                        throw new IllegalArgumentException(("ZIP entry count exceeds " + this.limits.getMaxZipEntries()).toString());
                                    }
                                    try {
/* 126 */                               String name = nextEntry.getName();
/* 127 */                               if (nextEntry.isDirectory()) {
/* 127 */                                   z = false;
                                        } else {
                                            try {
                                                if (!PACKAGE_NAMES.contains(name)) {
                                                    Intrinsics.checkNotNull(name);
                                                    if (!BoundedApkgKt.isIndex(name)) {
/* 127 */                                               z = false;
                                                    }
                                                }
                                            } catch (Throwable th7) {
                                                th2 = th7;
                                            }
                                        }
                                        if (!z) {
/* 127 */                                   throw new IllegalArgumentException(("Unsafe or unsupported ZIP entry name: " + name).toString());
                                        }
/* 128 */                               if (result.containsKey(name)) {
/* 128 */                                   throw new IllegalArgumentException(("Duplicate ZIP entry name: " + name).toString());
                                        }
/* 129 */                               Intrinsics.checkNotNull(name);
                                        LinkedHashMap result2 = result;
                                        File archive2 = archive;
                                        try {
                                            if (StringsKt.startsWith$default(name, "collection.", false, 2, (Object) null)) {
/* 112 */                                       maxMediaBytes = this.limits.getMaxDatabaseBytes();
                                            } else if (Intrinsics.areEqual(name, "meta")) {
                                                maxMediaBytes = 65536;
                                            } else {
/* 112 */                                       maxMediaBytes = Intrinsics.areEqual(name, "media") ? 33554432L : this.limits.getMaxMediaBytes();
                                            }
                                            long j = maxMediaBytes;
/* 130 */                                   File file2 = new File(file, "entry-" + result2.size());
/* 131 */                                   FileOutputStream fileOutputStream3 = new FileOutputStream(file2);
                                            try {
                                                try {
/* 131 */                                           long jCopyDecoded$default = BoundedApkgKt.copyDecoded$default(zipInputStream2, fileOutputStream3, j, budget, "ZIP entry " + name, null, null, null, 224, null);
                                                    CloseableKt.closeFinally(fileOutputStream3, null);
                                                    result2.put(name, file2);
                                                    zipInputStream2.closeEntry();
/* 124 */                                           records2.put(name, new ZipRecord(jCopyDecoded$default, nextEntry.getCompressedSize(), nextEntry.getCrc(), nextEntry.getMethod()));
                                                    file = directory;
                                                    decodedBudget = budget;
                                                    records = records2;
                                                    result = result2;
                                                    archive = archive2;
                                                } catch (Throwable th8) {
                                                    th3 = th8;
                                                    try {
                                                        throw th3;
                                                    } catch (Throwable th9) {
                                                        CloseableKt.closeFinally(fileOutputStream3, th3);
                                                        throw th9;
                                                    }
                                                }
                                            } catch (Throwable th10) {
                                                th3 = th10;
                                            }
                                        } catch (Throwable th11) {
                                            th2 = th11;
                                        }
                                    } catch (Throwable th12) {
                                        th2 = th12;
                                    }
                                    try {
                                        throw th2;
                                    } catch (Throwable th13) {
                                        try {
                                            CloseableKt.closeFinally(zipInputStream, th2);
                                            throw th13;
                                        } catch (Throwable th14) {
                                            th = th14;
                                            throw th;
                                        }
                                    }
                                }
                            } catch (Throwable th15) {
                                th2 = th15;
                            }
                        } catch (Throwable th16) {
                            th = th16;
                            th = th;
                            throw th;
                        }
                    } catch (Throwable th17) {
                        th = th17;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 143 */       public final Map<String, AnkiMediaFile> readMedia(PackageFormat format, File manifest, Map<String, ? extends File> entries, File directory, DecodedBudget budget, Function1<? super ImportProgress, Unit> progress) throws NoSuchAlgorithmException {
                    DecodedBudget decodedBudget;
                    List<AnkiProtoReader.MediaEntry> listMedia;
                    int i;
                    Throwable th;
                    long jCopyDecoded$default;
                    Throwable th2;
                    Throwable th3;
                    PackageFormat packageFormat = format;
                    if (packageFormat == PackageFormat.LATEST) {
/* 144 */               ZstdInputStream zstdInputStreamZstd = zstd(manifest);
                        try {
                            ZstdInputStream zstdInputStream = zstdInputStreamZstd;
/* 144 */                   AnkiProtoReader ankiProtoReader = AnkiProtoReader.INSTANCE;
                            Intrinsics.checkNotNull(zstdInputStream);
                            decodedBudget = budget;
                            try {
/* 144 */                       listMedia = ankiProtoReader.media(new DecodedInputStream(zstdInputStream, 33554432L, decodedBudget), this.limits.getMaxZipEntries());
                                CloseableKt.closeFinally(zstdInputStreamZstd, null);
                            } catch (Throwable th4) {
                                th = th4;
                                Throwable th5 = th;
                                try {
                                    throw th5;
                                } catch (Throwable th6) {
                                    CloseableKt.closeFinally(zstdInputStreamZstd, th5);
                                    throw th6;
                                }
                            }
                        } catch (Throwable th7) {
                            th = th7;
                        }
                    } else {
                        decodedBudget = budget;
/* 145 */               Map jsonObject = JsonElementKt.getJsonObject(BoundedJson.INSTANCE.parse(BoundedApkgKt.utf8(FilesKt.readBytes(manifest))));
/* 174 */               Collection arrayList = new ArrayList(jsonObject.size());
                        for (Map.Entry<String, JsonElement> entry : jsonObject.entrySet()) {
                            String key = entry.getKey();
                            JsonElement value = entry.getValue();
/* 146 */                   if (!BoundedApkgKt.isIndex(key)) {
/* 173 */                       throw new IllegalArgumentException(("Ambiguous legacy media index: " + key).toString());
                            }
                            if (!JsonElementKt.getJsonPrimitive(value).isString()) {
                                throw new IllegalArgumentException("Media filenames must be strings".toString());
                            }
/* 176 */                   arrayList.add(new AnkiProtoReader.MediaEntry(key, JsonElementKt.getJsonPrimitive(value).getContent(), -1L, new byte[0]));
                        }
                        listMedia = (List) arrayList;
                    }
/* 149 */           Iterable iterable = listMedia;
/* 178 */           Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 179 */           Iterator it = iterable.iterator();
                    while (it.hasNext()) {
/* 180 */               arrayList2.add(((AnkiProtoReader.MediaEntry) it.next()).getIndex());
                    }
/* 149 */           if (!(CollectionsKt.toSet((List) arrayList2).size() == listMedia.size())) {
                        throw new IllegalArgumentException("Duplicate media index".toString());
                    }
/* 150 */           Iterable iterableKeySet = entries.keySet();
/* 182 */           Collection arrayList3 = new ArrayList();
                    for (Object obj : iterableKeySet) {
/* 183 */               if (BoundedApkgKt.isIndex((String) obj)) {
                            arrayList3.add(obj);
                        }
                    }
/* 150 */           Set set = CollectionsKt.toSet((List) arrayList3);
                    Iterable iterable2 = listMedia;
/* 185 */           Collection arrayList4 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable2, 10));
/* 186 */           Iterator it2 = iterable2.iterator();
                    while (it2.hasNext()) {
/* 187 */               arrayList4.add(((AnkiProtoReader.MediaEntry) it2.next()).getIndex());
                    }
/* 150 */           if (!Intrinsics.areEqual(set, CollectionsKt.toSet((List) arrayList4))) {
                        throw new IllegalArgumentException("Media manifest and ZIP entries disagree".toString());
                    }
/* 151 */           Set normalized = new LinkedHashSet();
                    LinkedHashMap result = new LinkedHashMap();
/* 189 */           int i2 = 0;
                    for (Object obj2 : listMedia) {
                        int i3 = i2 + 1;
                        if (i2 < 0) {
                            CollectionsKt.throwIndexOverflow();
                        }
                        AnkiProtoReader.MediaEntry mediaEntry = (AnkiProtoReader.MediaEntry) obj2;
                        int i4 = i2;
/* 153 */               JobKt.ensureActive(decodedBudget.getContext());
                        BoundedApkgKt.safeMediaName(mediaEntry.getName());
/* 154 */               String strNormalize = Normalizer.normalize(mediaEntry.getName(), Normalizer.Form.NFC);
                        Intrinsics.checkNotNullExpressionValue(strNormalize, "normalize(...)");
                        if (!normalized.add(strNormalize)) {
                            throw new IllegalArgumentException(("Ambiguous duplicate media filename: " + mediaEntry.getName()).toString());
                        }
                        if (!(mediaEntry.getSize() <= this.limits.getMaxMediaBytes())) {
                            throw new IllegalArgumentException(("Media exceeds " + this.limits.getMaxMediaBytes() + " bytes").toString());
                        }
                        Set normalized2 = normalized;
/* 156 */               File file = (File) MapsKt.getValue(entries, mediaEntry.getIndex());
                        LinkedHashMap result2 = result;
                        File file2 = new File(directory, "media-" + i4);
/* 157 */               MessageDigest messageDigest = MessageDigest.getInstance("SHA-1");
                        MessageDigest messageDigest2 = MessageDigest.getInstance("SHA-256");
/* 158 */               if (packageFormat == PackageFormat.LATEST) {
/* 144 */                   ZstdInputStream zstdInputStreamZstd2 = zstd(file);
                            try {
                                ZstdInputStream zstdInputStream2 = zstdInputStreamZstd2;
/* 158 */                       FileOutputStream fileOutputStream = new FileOutputStream(file2);
                                try {
                                    FileOutputStream fileOutputStream2 = fileOutputStream;
/* 158 */                           Intrinsics.checkNotNull(zstdInputStream2);
                                    try {
                                        i = i4;
                                        try {
/* 144 */                                   jCopyDecoded$default = BoundedApkgKt.copyDecoded$default(zstdInputStream2, fileOutputStream2, this.limits.getMaxMediaBytes(), budget, "media", messageDigest, messageDigest2, null, 128, null);
                                            try {
                                                CloseableKt.closeFinally(fileOutputStream, null);
                                                CloseableKt.closeFinally(zstdInputStreamZstd2, null);
                                            } catch (Throwable th8) {
                                                th2 = th8;
                                                try {
                                                    throw th2;
                                                } catch (Throwable th9) {
                                                    CloseableKt.closeFinally(zstdInputStreamZstd2, th2);
                                                    throw th9;
                                                }
                                            }
                                        } catch (Throwable th10) {
                                            th3 = th10;
                                            try {
                                                throw th3;
                                            } catch (Throwable th11) {
                                                CloseableKt.closeFinally(fileOutputStream, th3);
                                                throw th11;
                                            }
                                        }
                                    } catch (Throwable th12) {
                                        th3 = th12;
                                    }
                                } catch (Throwable th13) {
                                    th3 = th13;
                                }
                            } catch (Throwable th14) {
                                th2 = th14;
                            }
                        } else {
                            i = i4;
/* 159 */                   FileInputStream fileInputStream = new FileInputStream(file);
                            try {
                                FileInputStream fileInputStream2 = fileInputStream;
/* 159 */                       FileOutputStream fileOutputStream3 = new FileOutputStream(file2);
                                try {
                                    try {
                                        try {
/* 144 */                                   long jCopyDecoded = BoundedApkgKt.copyDecoded(fileInputStream2, fileOutputStream3, this.limits.getMaxMediaBytes(), null, "media", messageDigest, messageDigest2, budget.getContext());
                                            messageDigest = messageDigest;
                                            messageDigest2 = messageDigest2;
                                            CloseableKt.closeFinally(fileOutputStream3, null);
                                            CloseableKt.closeFinally(fileInputStream, null);
                                            jCopyDecoded$default = jCopyDecoded;
                                        } catch (Throwable th15) {
                                            th = th15;
                                            try {
                                                throw th;
                                            } catch (Throwable th16) {
                                                try {
                                                    CloseableKt.closeFinally(fileOutputStream3, th);
                                                    throw th16;
                                                } catch (Throwable th17) {
                                                    th = th17;
                                                    Throwable th18 = th;
                                                    try {
                                                        throw th18;
                                                    } catch (Throwable th19) {
                                                        CloseableKt.closeFinally(fileInputStream, th18);
                                                        throw th19;
                                                    }
                                                }
                                            }
                                        }
                                    } catch (Throwable th20) {
                                        th = th20;
                                    }
                                } catch (Throwable th21) {
                                    th = th21;
                                }
                            } catch (Throwable th22) {
                                th = th22;
                            }
                        }
/* 158 */               long j = jCopyDecoded$default;
/* 160 */               byte[] bArrDigest = messageDigest.digest();
                        if (!(mediaEntry.getSize() < 0 || (j == mediaEntry.getSize() && Arrays.equals(bArrDigest, mediaEntry.getSha1())))) {
                            throw new IllegalArgumentException(("Media size/SHA-1 mismatch: " + mediaEntry.getName()).toString());
                        }
/* 162 */               byte[] bArrDigest2 = messageDigest2.digest();
                        Intrinsics.checkNotNullExpressionValue(bArrDigest2, "digest(...)");
                        String strHex = BoundedApkgKt.hex(bArrDigest2);
                        File file3 = new File(directory, strHex);
/* 163 */               if (file3.exists()) {
                            file2.delete();
                        } else if (!file2.renameTo(file3)) {
                            throw new IllegalArgumentException("Cannot stage verified media".toString());
                        }
                        String name = mediaEntry.getName();
                        String name2 = mediaEntry.getName();
                        Intrinsics.checkNotNull(bArrDigest);
/* 164 */               result2.put(name, new AnkiMediaFile(name2, file3, j, BoundedApkgKt.hex(bArrDigest), strHex));
/* 165 */               progress.invoke(new ImportProgress(ImportStage.MEDIA, ((long) i) + 1, Long.valueOf(listMedia.size())));
/* 190 */               packageFormat = format;
                        decodedBudget = budget;
                        i2 = i3;
                        normalized = normalized2;
                        result = result2;
                    }
/* 167 */           return MapsKt.toMap(result);
                }

                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lcom/xunji/flashcards/anki/ApkgReader$Companion;", "", "<init>", "()V", "PACKAGE_NAMES", "", "", "getPACKAGE_NAMES", "()Ljava/util/Set;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 168 */       private static final class Companion {
/* 169 */           private Companion() {
                    }

/* 169 */           public final Set<String> getPACKAGE_NAMES() {
/* 46 */                return ApkgReader.PACKAGE_NAMES;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 168 */       public final ZstdInputStream zstd(File file) {
/* 169 */           return new ZstdInputStream(new FileInputStream(file)).setLongMax(26).setContinuous(false);
                }
            }

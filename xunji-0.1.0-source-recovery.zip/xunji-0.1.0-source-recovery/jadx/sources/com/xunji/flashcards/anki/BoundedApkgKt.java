            package com.xunji.flashcards.anki;

            import androidx.autofill.HintConstants;
            import androidx.core.internal.view.SupportMenu;
            import com.fasterxml.jackson.core.JsonPointer;
            import com.xunji.core.anki.AnkiStorageValidator;
            import java.io.File;
            import java.io.IOException;
            import java.io.InputStream;
            import java.io.OutputStream;
            import java.io.RandomAccessFile;
            import java.nio.ByteBuffer;
            import java.nio.ByteOrder;
            import java.nio.charset.CodingErrorAction;
            import java.security.MessageDigest;
            import java.util.Arrays;
            import java.util.HashSet;
            import java.util.Iterator;
            import java.util.Map;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.UByte;
            import kotlin.UShort;
            import kotlin.Unit;
            import kotlin.collections.ArraysKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            import kotlin.text.Charsets;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.JobKt;
            import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
            
            /* JADX INFO: compiled from: BoundedApkg.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000f\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0018\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0001H\u0000\u001aV\u0010\u0005\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00012\b\u0010\t\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000b\u001a\u00020\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\u000e2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u0011H\u0000\u001a\u0014\u0010\u0012\u001a\u00020\u0013*\u00020\u00032\u0006\u0010\u0014\u001a\u00020\u0015H\u0000\u001a\u0010\u0010\u0016\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u0013H\u0000\u001a\u0010\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\fH\u0000\u001a\u0010\u0010\u001b\u001a\u00020\u001c2\u0006\u0010\u001a\u001a\u00020\fH\u0000\u001a\u0010\u0010\u001d\u001a\u00020\f2\u0006\u0010\u0017\u001a\u00020\u0013H\u0000\u001aJ\u0010\u001e\u001a\u00020\u001c2\u0006\u0010\u001f\u001a\u00020 2\u0012\u0010!\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020#0\"2\u0006\u0010\b\u001a\u00020\u00152\u0006\u0010\u0010\u001a\u00020\u00112\u0014\b\u0002\u0010$\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u00190%H\u0000¨\u0006&"}, d2 = {"consumeSkip", "", "input", "Ljava/io/InputStream;", "requested", "copyDecoded", "output", "Ljava/io/OutputStream;", "maximum", "budget", "Lcom/xunji/flashcards/anki/DecodedBudget;", "label", "", "sha1", "Ljava/security/MessageDigest;", "sha256", "context", "Lkotlin/coroutines/CoroutineContext;", "readNBytesCompat", "", "count", "", "utf8", "bytes", "isIndex", "", HintConstants.AUTOFILL_HINT_NAME, "safeMediaName", "", "hex", "validateZipDirectory", "file", "Ljava/io/File;", "records", "", "Lcom/xunji/flashcards/anki/ZipRecord;", "markCentral", "Lkotlin/Function1;", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 24 */    public final class BoundedApkgKt {
/* 25 */        public static final long consumeSkip(InputStream input, long requested) {
                    int count;
                    Intrinsics.checkNotNullParameter(input, "input");
                    if (requested <= 0) {
/* 26 */                return 0L;
                    }
/* 27 */            byte[] buffer = new byte[8192];
                    long skipped = 0;
                    while (skipped < requested && (count = input.read(buffer, 0, (int) Math.min(buffer.length, requested - skipped))) >= 0) {
                        skipped += (long) count;
                    }
/* 29 */            return skipped;
                }

/* 30 */        public static /* synthetic */ long copyDecoded$default(InputStream inputStream, OutputStream outputStream, long j, DecodedBudget decodedBudget, String str, MessageDigest messageDigest, MessageDigest messageDigest2, CoroutineContext coroutineContext, int i, Object obj) {
/* 31 */            if ((i & 32) != 0) {
                        messageDigest = null;
                    }
                    if ((i & 64) != 0) {
                        messageDigest2 = null;
                    }
                    if ((i & 128) != 0) {
                        coroutineContext = decodedBudget != null ? decodedBudget.getContext() : null;
                    }
                    return copyDecoded(inputStream, outputStream, j, decodedBudget, str, messageDigest, messageDigest2, coroutineContext);
                }

/* 31 */        public static final long copyDecoded(InputStream input, OutputStream output, long maximum, DecodedBudget budget, String label, MessageDigest sha1, MessageDigest sha256, CoroutineContext context) throws IOException {
                    Intrinsics.checkNotNullParameter(input, "input");
                    Intrinsics.checkNotNullParameter(output, "output");
                    Intrinsics.checkNotNullParameter(label, "label");
/* 32 */            byte[] buffer = new byte[65536];
                    long total = 0;
                    while (true) {
/* 34 */                if (context != null) {
                            JobKt.ensureActive(context);
                        }
                        int size = input.read(buffer);
                        if (size < 0) {
/* 38 */                    return total;
                        }
                        if (size != 0) {
/* 35 */                    total += (long) size;
                            if (!(total <= maximum)) {
/* 35 */                        throw new IllegalArgumentException((label + " exceeds " + maximum + " bytes").toString());
                            }
                            if (budget != null) {
                                budget.add(size);
                            }
/* 36 */                    output.write(buffer, 0, size);
                            if (sha1 != null) {
                                sha1.update(buffer, 0, size);
                            }
                            if (sha256 != null) {
                                sha256.update(buffer, 0, size);
                            }
                        }
                    }
                }

/* 40 */        public static final byte[] readNBytesCompat(InputStream $this$readNBytesCompat, int count) throws IOException {
                    Intrinsics.checkNotNullParameter($this$readNBytesCompat, "<this>");
/* 41 */            byte[] result = new byte[count];
                    int offset = 0;
/* 42 */            while (offset < count) {
                        int n = $this$readNBytesCompat.read(result, offset, count - offset);
                        if (n < 0) {
                            byte[] bArrCopyOf = Arrays.copyOf(result, offset);
                            Intrinsics.checkNotNullExpressionValue(bArrCopyOf, "copyOf(...)");
                            return bArrCopyOf;
                        }
                        if (n > 0) {
                            offset += n;
                        }
                    }
/* 43 */            return result;
                }

/* 44 */        public static final String utf8(byte[] bytes) {
                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 45 */            String string = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
                    Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                    return string;
                }

                /* JADX WARN: Code duplicated, block: B:33:0x005f  */
/* 45 */        public static final boolean isIndex(String name) {
                    boolean z;
                    boolean z2;
                    Intrinsics.checkNotNullParameter(name, "name");
/* 46 */            if (name.length() > 0) {
                        String str = name;
/* 158 */               int i = 0;
                        while (true) {
                            if (i >= str.length()) {
/* 159 */                       z = true;
                                break;
                            }
                            char cCharAt = str.charAt(i);
/* 158 */                   if ((('0' > cCharAt || cCharAt >= ':') ? (char) 0 : (char) 1) == 0) {
                                z = false;
                                break;
                            }
                            i++;
                        }
/* 46 */                if (z && (Intrinsics.areEqual(name, "0") || name.charAt(0) != '0')) {
                            Integer intOrNull = StringsKt.toIntOrNull(name);
                            if (intOrNull == null) {
                                z2 = false;
                            } else {
/* 46 */                        if ((intOrNull.intValue() >= 0 ? 1 : 0) == 1) {
                                    z2 = true;
                                } else {
                                    z2 = false;
                                }
                            }
                            if (z2) {
                                return true;
                            }
                        }
                    }
                    return false;
                }

/* 47 */        public static final void safeMediaName(String name) {
                    Intrinsics.checkNotNullParameter(name, "name");
                    if (!((!(name.length() > 0) || Intrinsics.areEqual(name, ".") || Intrinsics.areEqual(name, "..") || StringsKt.contains$default((CharSequence) name, JsonPointer.SEPARATOR, false, 2, (Object) null) || StringsKt.contains$default((CharSequence) name, AbstractJsonLexerKt.STRING_ESC, false, 2, (Object) null) || StringsKt.contains$default((CharSequence) name, (char) 0, false, 2, (Object) null) || new Regex("^[A-Za-z]:").containsMatchIn(name)) ? false : true)) {
/* 48 */                throw new IllegalArgumentException(("Unsafe media filename: " + name).toString());
                    }
/* 49 */            AnkiStorageValidator.INSTANCE.utf8Bytes(name);
                }

/* 50 */        public static final String hex(byte[] bytes) {
                    Intrinsics.checkNotNullParameter(bytes, "bytes");
/* 51 */            return ArraysKt.joinToString$default(bytes, (CharSequence) "", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, new Function1() { // from class: com.xunji.flashcards.anki.BoundedApkgKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BoundedApkgKt.hex$lambda$0(((Byte) obj).byteValue());
                        }
                    }, 30, (Object) null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 50 */        public static final CharSequence hex$lambda$0(byte it) {
/* 51 */            String str = String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(it)}, 1));
                    Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                    return str;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.BoundedApkgKt$validateZipDirectory$1, reason: invalid class name */
                /* JADX INFO: compiled from: BoundedApkg.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 88 */        static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function1<String, Boolean> {
                    AnonymousClass1(Object obj) {
                        super(1, obj, HashSet.class, "add", "add(Ljava/lang/Object;)Z", 0);
                    }

                    @Override // kotlin.jvm.functions.Function1
/* 89 */            public final Boolean invoke(String p0) {
                        Intrinsics.checkNotNullParameter(p0, "p0");
/* 90 */                return Boolean.valueOf(((HashSet) this.receiver).add(p0));
                    }
                }

/* 89 */        public static /* synthetic */ void validateZipDirectory$default(File file, Map map, int i, CoroutineContext coroutineContext, Function1 function1, int i2, Object obj) {
/* 90 */            if ((i2 & 16) != 0) {
                        function1 = new AnonymousClass1(new HashSet());
                    }
                    validateZipDirectory(file, map, i, coroutineContext, function1);
                }

                /* JADX WARN: Code duplicated, block: B:100:0x01c4  */
                /* JADX WARN: Code duplicated, block: B:102:0x01c7 A[Catch: all -> 0x066b, TRY_ENTER, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:104:0x01d5  */
                /* JADX WARN: Code duplicated, block: B:105:0x01d8  */
                /* JADX WARN: Code duplicated, block: B:107:0x01dc A[Catch: all -> 0x066b, TRY_LEAVE, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:152:0x02b2 A[Catch: all -> 0x066b, TRY_ENTER, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:154:0x02b8  */
                /* JADX WARN: Code duplicated, block: B:155:0x02ba  */
                /* JADX WARN: Code duplicated, block: B:157:0x02bd A[Catch: all -> 0x066b, TRY_LEAVE, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:162:0x02e7  */
                /* JADX WARN: Code duplicated, block: B:164:0x02eb A[Catch: all -> 0x066b, TRY_ENTER, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:172:0x030e A[Catch: all -> 0x066b, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:178:0x033f  */
                /* JADX WARN: Code duplicated, block: B:179:0x0341  */
                /* JADX WARN: Code duplicated, block: B:181:0x0344 A[Catch: all -> 0x03b7, TryCatch #3 {all -> 0x03b7, blocks: (B:176:0x0328, B:181:0x0344, B:187:0x0355, B:189:0x036b, B:192:0x0375, B:195:0x037f, B:200:0x039b, B:197:0x0388, B:198:0x0396, B:201:0x03a6, B:202:0x03b6), top: B:334:0x0328 }] */
                /* JADX WARN: Code duplicated, block: B:183:0x034e A[DONT_INVERT] */
                /* JADX WARN: Code duplicated, block: B:184:0x0350  */
                /* JADX WARN: Code duplicated, block: B:185:0x0352  */
                /* JADX WARN: Code duplicated, block: B:187:0x0355 A[Catch: all -> 0x03b7, TryCatch #3 {all -> 0x03b7, blocks: (B:176:0x0328, B:181:0x0344, B:187:0x0355, B:189:0x036b, B:192:0x0375, B:195:0x037f, B:200:0x039b, B:197:0x0388, B:198:0x0396, B:201:0x03a6, B:202:0x03b6), top: B:334:0x0328 }] */
                /* JADX WARN: Code duplicated, block: B:189:0x036b A[Catch: all -> 0x03b7, TryCatch #3 {all -> 0x03b7, blocks: (B:176:0x0328, B:181:0x0344, B:187:0x0355, B:189:0x036b, B:192:0x0375, B:195:0x037f, B:200:0x039b, B:197:0x0388, B:198:0x0396, B:201:0x03a6, B:202:0x03b6), top: B:334:0x0328 }] */
                /* JADX WARN: Code duplicated, block: B:192:0x0375 A[Catch: all -> 0x03b7, TryCatch #3 {all -> 0x03b7, blocks: (B:176:0x0328, B:181:0x0344, B:187:0x0355, B:189:0x036b, B:192:0x0375, B:195:0x037f, B:200:0x039b, B:197:0x0388, B:198:0x0396, B:201:0x03a6, B:202:0x03b6), top: B:334:0x0328 }] */
                /* JADX WARN: Code duplicated, block: B:195:0x037f A[Catch: all -> 0x03b7, TryCatch #3 {all -> 0x03b7, blocks: (B:176:0x0328, B:181:0x0344, B:187:0x0355, B:189:0x036b, B:192:0x0375, B:195:0x037f, B:200:0x039b, B:197:0x0388, B:198:0x0396, B:201:0x03a6, B:202:0x03b6), top: B:334:0x0328 }] */
                /* JADX WARN: Code duplicated, block: B:199:0x0397  */
                /* JADX WARN: Code duplicated, block: B:207:0x03c2 A[EDGE_INSN: B:207:0x03c2->B:208:0x03c4 BREAK  A[LOOP:2: B:173:0x031d->B:200:0x039b]] */
                /* JADX WARN: Code duplicated, block: B:220:0x03f2  */
                /* JADX WARN: Code duplicated, block: B:222:0x03f5  */
                /* JADX WARN: Code duplicated, block: B:22:0x00ad  */
                /* JADX WARN: Code duplicated, block: B:230:0x040a A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:232:0x041c  */
                /* JADX WARN: Code duplicated, block: B:233:0x041f  */
                /* JADX WARN: Code duplicated, block: B:235:0x0423 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:240:0x0436  */
                /* JADX WARN: Code duplicated, block: B:242:0x0439 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:247:0x0451  */
                /* JADX WARN: Code duplicated, block: B:255:0x046b A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:257:0x047a A[Catch: all -> 0x06c4, LOOP:1: B:127:0x0222->B:257:0x047a, LOOP_END, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:297:0x05ce A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:299:0x05e2 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:301:0x05f9 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:303:0x0610 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:305:0x0629 A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:307:0x063f A[Catch: all -> 0x06c4, TryCatch #1 {all -> 0x06c4, blocks: (B:209:0x03c8, B:211:0x03d2, B:213:0x03da, B:215:0x03e2, B:217:0x03ea, B:224:0x03f9, B:230:0x040a, B:235:0x0423, B:237:0x042e, B:242:0x0439, B:249:0x0454, B:255:0x046b, B:257:0x047a, B:258:0x048f, B:259:0x049b, B:260:0x049c, B:261:0x04a8, B:262:0x04a9, B:263:0x04b9, B:264:0x04ba, B:265:0x04cc, B:266:0x04cd, B:267:0x04df, B:268:0x04e0, B:269:0x04f4, B:270:0x04f5, B:271:0x0507, B:272:0x0508, B:273:0x0522, B:274:0x0523, B:275:0x053d, B:276:0x053e, B:277:0x0558, B:278:0x0559, B:279:0x056d, B:280:0x056e, B:282:0x0580, B:287:0x058c, B:291:0x0594, B:292:0x059f, B:293:0x05a0, B:294:0x05b6, B:295:0x05b7, B:296:0x05cd, B:297:0x05ce, B:298:0x05e1, B:299:0x05e2, B:300:0x05f8, B:301:0x05f9, B:302:0x060f, B:303:0x0610, B:304:0x0628, B:305:0x0629, B:306:0x063e, B:307:0x063f, B:309:0x066a, B:308:0x0655, B:312:0x0671, B:313:0x0687, B:314:0x0688, B:315:0x069b, B:316:0x069c, B:317:0x06b0, B:318:0x06b1, B:319:0x06c3), top: B:331:0x003b }] */
                /* JADX WARN: Code duplicated, block: B:334:0x0328 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:343:0x048f A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:346:0x053e A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:347:0x0523 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:348:0x0508 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:349:0x03a6 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:350:0x0388 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:351:0x04f5 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:352:0x04e0 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:353:0x04cd A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:354:0x04ba A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:355:0x04a9 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:356:0x049c A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:357:0x03bc A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:70:0x0155  */
                /* JADX WARN: Code duplicated, block: B:73:0x015a A[Catch: all -> 0x066b, TRY_ENTER, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:78:0x0172  */
                /* JADX WARN: Code duplicated, block: B:80:0x0175 A[Catch: all -> 0x066b, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:82:0x0185  */
                /* JADX WARN: Code duplicated, block: B:83:0x0188  */
                /* JADX WARN: Code duplicated, block: B:85:0x018c A[Catch: all -> 0x066b, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:87:0x0196 A[Catch: all -> 0x066b, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:89:0x01a5  */
                /* JADX WARN: Code duplicated, block: B:90:0x01a7  */
                /* JADX WARN: Code duplicated, block: B:93:0x01ac A[Catch: all -> 0x066b, TRY_LEAVE, TryCatch #5 {all -> 0x066b, blocks: (B:47:0x00fa, B:126:0x021c, B:128:0x0224, B:137:0x024a, B:152:0x02b2, B:157:0x02bd, B:164:0x02eb, B:172:0x030e, B:173:0x031d, B:63:0x013d, B:73:0x015a, B:75:0x016a, B:80:0x0175, B:85:0x018c, B:87:0x0196, B:93:0x01ac, B:102:0x01c7, B:107:0x01dc), top: B:337:0x00fa }] */
                /* JADX WARN: Code duplicated, block: B:96:0x01ba A[Catch: all -> 0x0202, TRY_ENTER, TRY_LEAVE, TryCatch #0 {all -> 0x0202, blocks: (B:111:0x01f7, B:131:0x023a, B:145:0x0286, B:159:0x02d8, B:66:0x014b, B:96:0x01ba), top: B:329:0x014b }] */
/* 90 */        public static final void validateZipDirectory(File file, Map<String, ZipRecord> records, int maximum, CoroutineContext context, Function1<? super String, Boolean> function1) {
                    Throwable th;
                    Object next;
                    boolean z;
                    long jValidateZipDirectory$lambda$0$u64;
                    boolean z2;
                    boolean z3;
                    long jValidateZipDirectory$lambda$0$u65;
                    long j;
                    boolean z4;
                    boolean z5;
                    long jValidateZipDirectory$lambda$0$u66;
                    boolean z6;
                    long jValidateZipDirectory$lambda$0$u67;
                    long j2;
                    long j3;
                    int i;
                    int i2;
                    int i3;
                    int i4;
                    boolean z7;
                    boolean z8;
                    long jValidateZipDirectory$lambda$0$u32;
                    String strUtf8;
                    boolean z9;
                    byte[] bArr;
                    ByteBuffer byteBufferOrder;
                    boolean z10;
                    boolean z11;
                    Set<String> set;
                    long j4;
                    int i5;
                    int i6;
                    int i7;
                    boolean z12;
                    boolean z13;
                    ByteBuffer byteBufferOrder2;
                    boolean z14;
                    long filePointer;
                    boolean z15;
                    long j5;
                    boolean z16;
                    int iValidateZipDirectory$lambda$0$u16;
                    int iValidateZipDirectory$lambda$0$u17;
                    boolean z17;
                    byte[] bArr2;
                    boolean z18;
                    Function1<? super String, Boolean> markCentral = function1;
                    Intrinsics.checkNotNullParameter(file, "file");
                    Intrinsics.checkNotNullParameter(records, "records");
                    Intrinsics.checkNotNullParameter(context, "context");
                    Intrinsics.checkNotNullParameter(markCentral, "markCentral");
/* 91 */            Set<String> setKeySet = records.keySet();
/* 92 */            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "r");
                    try {
                        RandomAccessFile randomAccessFile2 = randomAccessFile;
/* 96 */                long length = randomAccessFile2.length();
                        try {
                            try {
                                if (!(length >= 22)) {
/* 96 */                            throw new IllegalArgumentException("Truncated ZIP end record".toString());
                                }
/* 97 */                        long jMax = Math.max(0L, length - ((long) 65557));
                                randomAccessFile2.seek(jMax);
                                byte[] bArr3 = new byte[(int) (length - jMax)];
                                randomAccessFile2.readFully(bArr3);
/* 160 */                       Iterator<Integer> it = RangesKt.downTo(bArr3.length - 22, 0).iterator();
/* 160 */                       do {
                                    if (!it.hasNext()) {
/* 161 */                               next = null;
                                        break;
                                    }
                                    try {
                                        next = it.next();
                                        int iIntValue = ((Number) next).intValue();
/* 98 */                                if (bArr3[iIntValue] == 80 && bArr3[iIntValue + 1] == 75 && bArr3[iIntValue + 2] == 5 && bArr3[iIntValue + 3] == 6) {
                                            if (iIntValue + 22 + (((bArr3[iIntValue + 21] & UByte.MAX_VALUE) << 8) | (bArr3[iIntValue + 20] & UByte.MAX_VALUE)) == bArr3.length) {
                                                z18 = true;
                                            } else {
                                                z18 = false;
                                            }
                                        } else {
                                            z18 = false;
                                        }
                                    } catch (Throwable th2) {
                                        th = th2;
                                    }
/* 160 */                       } while (!z18);
/* 98 */                        Integer num = (Integer) next;
/* 99 */                        if (!(num != null)) {
/* 99 */                            throw new IllegalArgumentException("Missing/truncated ZIP central directory end record".toString());
                                }
                                long jIntValue = ((long) num.intValue()) + jMax;
/* 100 */                       randomAccessFile2.seek(((long) 4) + jIntValue);
                                if (!(validateZipDirectory$lambda$0$u16(randomAccessFile2) == 0 && validateZipDirectory$lambda$0$u16(randomAccessFile2) == 0)) {
/* 100 */                           throw new IllegalArgumentException("Multi-disk ZIP is unsupported".toString());
                                }
/* 101 */                       int iValidateZipDirectory$lambda$0$u18 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                long jValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                if (!(((long) iValidateZipDirectory$lambda$0$u18) == jValidateZipDirectory$lambda$0$u16)) {
/* 101 */                           throw new IllegalArgumentException("Ambiguous ZIP entry counts".toString());
                                }
                                try {
/* 102 */                           long jValidateZipDirectory$lambda$0$u33 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
                                    long jValidateZipDirectory$lambda$0$u34 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
                                    long j6 = jIntValue;
                                    if (jValidateZipDirectory$lambda$0$u16 == 65535 || jValidateZipDirectory$lambda$0$u33 == 4294967295L || jValidateZipDirectory$lambda$0$u34 == 4294967295L) {
                                        if (!(jIntValue >= 20)) {
                                            throw new IllegalArgumentException("Failed requirement.".toString());
                                        }
                                        long j7 = 20;
                                        randomAccessFile2.seek(jIntValue - j7);
                                        if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 117853008) {
                                            try {
                                                if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 0) {
                                                    z = true;
                                                } else {
                                                    z = false;
                                                }
                                                if (z) {
                                                    throw new IllegalArgumentException("Invalid ZIP64 locator".toString());
                                                }
/* 105 */                                       jValidateZipDirectory$lambda$0$u64 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 1 || jValidateZipDirectory$lambda$0$u64 >= jIntValue - j7) {
                                                    z2 = false;
                                                } else {
                                                    z2 = true;
                                                }
                                                if (z2) {
                                                    throw new IllegalArgumentException("Invalid ZIP64 locator".toString());
                                                }
/* 106 */                                       randomAccessFile2.seek(jValidateZipDirectory$lambda$0$u64);
                                                if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 101075792) {
                                                    z3 = true;
                                                } else {
                                                    z3 = false;
                                                }
                                                if (z3) {
/* 106 */                                           throw new IllegalArgumentException("Missing ZIP64 end record".toString());
                                                }
                                                jValidateZipDirectory$lambda$0$u65 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                if (jValidateZipDirectory$lambda$0$u65 >= 44) {
/* 106 */                                           j = jValidateZipDirectory$lambda$0$u64;
/* 106 */                                           z4 = jValidateZipDirectory$lambda$0$u65 == ((jIntValue - j7) - jValidateZipDirectory$lambda$0$u64) - ((long) 12);
                                                    if (z4) {
/* 107 */                                               throw new IllegalArgumentException("Invalid ZIP64 end size".toString());
                                                    }
/* 108 */                                           validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                    validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                    if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 0 || validateZipDirectory$lambda$0$u32(randomAccessFile2) != 0) {
                                                        z5 = false;
                                                    } else {
                                                        z5 = true;
                                                    }
                                                    if (z5) {
/* 108 */                                               throw new IllegalArgumentException("Multi-disk ZIP64 is unsupported".toString());
                                                    }
/* 109 */                                           jValidateZipDirectory$lambda$0$u66 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                    jValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                    if (jValidateZipDirectory$lambda$0$u66 == jValidateZipDirectory$lambda$0$u16) {
                                                        z6 = true;
                                                    } else {
                                                        z6 = false;
                                                    }
                                                    if (z6) {
                                                        throw new IllegalArgumentException("Failed requirement.".toString());
                                                    }
                                                    long jValidateZipDirectory$lambda$0$u68 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                    j6 = j;
                                                    jValidateZipDirectory$lambda$0$u67 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                    j2 = jValidateZipDirectory$lambda$0$u68;
                                                } else {
/* 106 */                                           j = jValidateZipDirectory$lambda$0$u64;
                                                }
                                                if (z4) {
/* 107 */                                           throw new IllegalArgumentException("Invalid ZIP64 end size".toString());
                                                }
/* 108 */                                       validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 0) {
                                                    z5 = false;
                                                } else {
                                                    z5 = false;
                                                }
                                                if (z5) {
/* 108 */                                           throw new IllegalArgumentException("Multi-disk ZIP64 is unsupported".toString());
                                                }
/* 109 */                                       jValidateZipDirectory$lambda$0$u66 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                jValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                if (jValidateZipDirectory$lambda$0$u66 == jValidateZipDirectory$lambda$0$u16) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
                                                if (z6) {
                                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                                }
                                                long jValidateZipDirectory$lambda$0$u69 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                j6 = j;
                                                jValidateZipDirectory$lambda$0$u67 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                j2 = jValidateZipDirectory$lambda$0$u69;
                                            } catch (Throwable th3) {
                                                th = th3;
                                            }
                                        } else {
                                            z = false;
                                            if (z) {
                                                throw new IllegalArgumentException("Invalid ZIP64 locator".toString());
                                            }
/* 105 */                                   jValidateZipDirectory$lambda$0$u64 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 1) {
                                                z2 = false;
                                            } else {
                                                z2 = false;
                                            }
                                            if (z2) {
                                                throw new IllegalArgumentException("Invalid ZIP64 locator".toString());
                                            }
/* 106 */                                   randomAccessFile2.seek(jValidateZipDirectory$lambda$0$u64);
                                            if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 101075792) {
                                                z3 = true;
                                            } else {
                                                z3 = false;
                                            }
                                            if (z3) {
/* 106 */                                       throw new IllegalArgumentException("Missing ZIP64 end record".toString());
                                            }
                                            jValidateZipDirectory$lambda$0$u65 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            if (jValidateZipDirectory$lambda$0$u65 >= 44) {
/* 106 */                                       j = jValidateZipDirectory$lambda$0$u64;
/* 106 */                                       if (jValidateZipDirectory$lambda$0$u65 == ((jIntValue - j7) - jValidateZipDirectory$lambda$0$u64) - ((long) 12)) {
                                                }
                                                if (z4) {
/* 107 */                                           throw new IllegalArgumentException("Invalid ZIP64 end size".toString());
                                                }
/* 108 */                                       validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                                if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 0) {
                                                    z5 = false;
                                                } else {
                                                    z5 = false;
                                                }
                                                if (z5) {
/* 108 */                                           throw new IllegalArgumentException("Multi-disk ZIP64 is unsupported".toString());
                                                }
/* 109 */                                       jValidateZipDirectory$lambda$0$u66 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                jValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                if (jValidateZipDirectory$lambda$0$u66 == jValidateZipDirectory$lambda$0$u16) {
                                                    z6 = true;
                                                } else {
                                                    z6 = false;
                                                }
                                                if (z6) {
                                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                                }
                                                long jValidateZipDirectory$lambda$0$u610 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                j6 = j;
                                                jValidateZipDirectory$lambda$0$u67 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                                j2 = jValidateZipDirectory$lambda$0$u610;
                                            } else {
/* 106 */                                       j = jValidateZipDirectory$lambda$0$u64;
                                            }
                                            if (z4) {
/* 107 */                                       throw new IllegalArgumentException("Invalid ZIP64 end size".toString());
                                            }
/* 108 */                                   validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                            validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                            if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 0) {
                                                z5 = false;
                                            } else {
                                                z5 = false;
                                            }
                                            if (z5) {
/* 108 */                                       throw new IllegalArgumentException("Multi-disk ZIP64 is unsupported".toString());
                                            }
/* 109 */                                   jValidateZipDirectory$lambda$0$u66 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            jValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            if (jValidateZipDirectory$lambda$0$u66 == jValidateZipDirectory$lambda$0$u16) {
                                                z6 = true;
                                            } else {
                                                z6 = false;
                                            }
                                            if (z6) {
                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                            }
                                            long jValidateZipDirectory$lambda$0$u611 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            j6 = j;
                                            jValidateZipDirectory$lambda$0$u67 = validateZipDirectory$lambda$0$u64(randomAccessFile2);
                                            j2 = jValidateZipDirectory$lambda$0$u611;
                                        }
                                        throw th;
                                    }
                                    j2 = jValidateZipDirectory$lambda$0$u33;
                                    jValidateZipDirectory$lambda$0$u67 = jValidateZipDirectory$lambda$0$u34;
/* 111 */                           if (!(jValidateZipDirectory$lambda$0$u16 <= ((long) maximum) && jValidateZipDirectory$lambda$0$u16 == ((long) setKeySet.size()))) {
/* 111 */                               throw new IllegalArgumentException("ZIP central entry count disagrees with streamed entries".toString());
                                    }
                                    if (!(jValidateZipDirectory$lambda$0$u67 <= j6 && j2 == j6 - jValidateZipDirectory$lambda$0$u67)) {
/* 112 */                               throw new IllegalArgumentException("Invalid ZIP central directory bounds".toString());
                                    }
                                    randomAccessFile2.seek(jValidateZipDirectory$lambda$0$u67);
/* 113 */                           int i8 = 0;
/* 114 */                           int i9 = (int) jValidateZipDirectory$lambda$0$u16;
                                    int i10 = 0;
                                    while (i10 < i9) {
/* 115 */                               JobKt.ensureActive(context);
                                        long j8 = jValidateZipDirectory$lambda$0$u67;
                                        if (!(randomAccessFile2.getFilePointer() + ((long) 46) <= j6 && validateZipDirectory$lambda$0$u32(randomAccessFile2) == 33639248)) {
/* 115 */                                   throw new IllegalArgumentException("Corrupt ZIP central directory".toString());
                                        }
/* 116 */                               validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        int iValidateZipDirectory$lambda$0$u19 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        int iValidateZipDirectory$lambda$0$u110 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        randomAccessFile2.skipBytes(4);
/* 117 */                               long jValidateZipDirectory$lambda$0$u35 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
                                        long jValidateZipDirectory$lambda$0$u36 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
                                        long jValidateZipDirectory$lambda$0$u37 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
/* 118 */                               int iValidateZipDirectory$lambda$0$u111 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        int iValidateZipDirectory$lambda$0$u112 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        int iValidateZipDirectory$lambda$0$u113 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
/* 119 */                               int i11 = iValidateZipDirectory$lambda$0$u18;
                                        if (1 <= iValidateZipDirectory$lambda$0$u111 && iValidateZipDirectory$lambda$0$u111 < 129) {
                                            j3 = jValidateZipDirectory$lambda$0$u16;
                                            i2 = iValidateZipDirectory$lambda$0$u112;
                                            i = i9;
                                            i4 = i10;
                                            i3 = iValidateZipDirectory$lambda$0$u113;
                                            z7 = (((randomAccessFile2.getFilePointer() + 12) + ((long) iValidateZipDirectory$lambda$0$u111)) + ((long) i2)) + ((long) i3) <= j6;
                                            if (z7) {
/* 119 */                                       throw new IllegalArgumentException("Invalid ZIP central filename/entry bounds".toString());
                                            }
/* 120 */                                   if (validateZipDirectory$lambda$0$u16(randomAccessFile2) == 0) {
                                                z8 = true;
                                            } else {
                                                z8 = false;
                                            }
                                            if (z8) {
/* 120 */                                       throw new IllegalArgumentException("Multi-disk ZIP entry".toString());
                                            }
                                            randomAccessFile2.skipBytes(6);
                                            jValidateZipDirectory$lambda$0$u32 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
/* 121 */                                   byte[] bArr4 = new byte[iValidateZipDirectory$lambda$0$u111];
                                            randomAccessFile2.readFully(bArr4);
                                            strUtf8 = utf8(bArr4);
/* 122 */                                   if (setKeySet.contains(strUtf8) || !markCentral.invoke(strUtf8).booleanValue()) {
                                                z9 = false;
                                            } else {
                                                z9 = true;
                                            }
                                            if (z9) {
/* 122 */                                       throw new IllegalArgumentException("ZIP central filename mismatch/duplicate".toString());
                                            }
/* 123 */                                   bArr = new byte[i2];
                                            randomAccessFile2.readFully(bArr);
                                            randomAccessFile2.skipBytes(i3);
                                            if (jValidateZipDirectory$lambda$0$u37 != 4294967295L || jValidateZipDirectory$lambda$0$u36 == 4294967295L || jValidateZipDirectory$lambda$0$u32 == 4294967295L) {
/* 125 */                                       byteBufferOrder = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
                                                z10 = false;
                                                while (true) {
/* 126 */                                           z11 = z10;
                                                    set = setKeySet;
                                                    if (byteBufferOrder.remaining() < 4) {
                                                        if (!z11) {
/* 139 */                                                   throw new IllegalArgumentException("Missing ZIP64 central extra".toString());
                                                        }
                                                        j4 = jValidateZipDirectory$lambda$0$u32;
                                                        break;
                                                    }
                                                    try {
/* 127 */                                               i5 = byteBufferOrder.getShort() & SupportMenu.USER_MASK;
                                                        i6 = byteBufferOrder.getShort() & UShort.MAX_VALUE;
/* 128 */                                               i7 = i2;
                                                        if (i6 <= byteBufferOrder.remaining()) {
                                                            z12 = true;
                                                        } else {
                                                            z12 = false;
                                                        }
                                                        if (!z12) {
/* 128 */                                                   throw new IllegalArgumentException("Truncated ZIP64 central extra".toString());
                                                        }
/* 129 */                                               int iPosition = byteBufferOrder.position() + i6;
/* 130 */                                               int i12 = i3;
                                                        if (i5 == 1) {
/* 131 */                                                   if (z11) {
                                                                z13 = false;
                                                            } else {
                                                                z13 = true;
                                                            }
                                                            if (!z13) {
/* 131 */                                                       throw new IllegalArgumentException("Duplicate ZIP64 central extra".toString());
                                                            }
                                                            byteBufferOrder2 = byteBufferOrder.slice().order(ByteOrder.LITTLE_ENDIAN);
                                                            byteBufferOrder2.limit(i6);
                                                            if (jValidateZipDirectory$lambda$0$u37 == 4294967295L) {
                                                                jValidateZipDirectory$lambda$0$u37 = byteBufferOrder2.getLong();
                                                            }
                                                            if (jValidateZipDirectory$lambda$0$u36 == 4294967295L) {
                                                                jValidateZipDirectory$lambda$0$u36 = byteBufferOrder2.getLong();
                                                            }
                                                            if (jValidateZipDirectory$lambda$0$u32 == 4294967295L) {
                                                                jValidateZipDirectory$lambda$0$u32 = byteBufferOrder2.getLong();
                                                            }
                                                            z10 = true;
                                                        } else {
                                                            z10 = z11;
                                                        }
/* 137 */                                               byteBufferOrder.position(iPosition);
                                                        i2 = i7;
                                                        setKeySet = set;
                                                        i3 = i12;
                                                    } catch (Throwable th4) {
/* 92 */                                                th = th4;
                                                        th = th;
                                                        throw th;
                                                    }
                                                }
                                            } else {
                                                set = setKeySet;
                                                j4 = jValidateZipDirectory$lambda$0$u32;
                                            }
/* 141 */                                   i8++;
/* 122 */                                   ZipRecord zipRecord = (ZipRecord) MapsKt.getValue(records, strUtf8);
/* 143 */                                   if ((iValidateZipDirectory$lambda$0$u19 & 1) != 0 && jValidateZipDirectory$lambda$0$u35 == zipRecord.getCrc() && jValidateZipDirectory$lambda$0$u37 == zipRecord.getSize() && jValidateZipDirectory$lambda$0$u36 == zipRecord.getCompressedSize() && iValidateZipDirectory$lambda$0$u110 == zipRecord.getMethod()) {
                                                z14 = true;
                                            } else {
                                                z14 = false;
                                            }
                                            if (z14) {
/* 143 */                                       throw new IllegalArgumentException("ZIP central size/CRC/method disagrees with streamed entry".toString());
                                            }
                                            if (j4 < 0 && ((long) 30) + j4 <= j8) {
/* 144 */                                       throw new IllegalArgumentException("Invalid ZIP local entry offset".toString());
                                            }
/* 145 */                                   filePointer = randomAccessFile2.getFilePointer();
                                            randomAccessFile2.seek(j4);
                                            if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 67324752) {
                                                z15 = true;
                                            } else {
                                                z15 = false;
                                            }
                                            if (z15) {
/* 146 */                                       throw new IllegalArgumentException("ZIP central offset does not reference a local entry".toString());
                                            }
                                            validateZipDirectory$lambda$0$u16(randomAccessFile2);
/* 147 */                                   j5 = j4;
                                            if (validateZipDirectory$lambda$0$u16(randomAccessFile2) == iValidateZipDirectory$lambda$0$u19 || validateZipDirectory$lambda$0$u16(randomAccessFile2) != iValidateZipDirectory$lambda$0$u110) {
                                                z16 = false;
                                            } else {
                                                z16 = true;
                                            }
                                            if (z16) {
/* 147 */                                       throw new IllegalArgumentException("ZIP local/central flags or method disagree".toString());
                                            }
                                            randomAccessFile2.skipBytes(16);
/* 148 */                                   iValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                            iValidateZipDirectory$lambda$0$u17 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                            if (1 <= iValidateZipDirectory$lambda$0$u16 || iValidateZipDirectory$lambda$0$u16 >= 129) {
                                                z17 = false;
                                            } else {
                                                z17 = true;
                                            }
                                            if (!z17 && ((j5 + 30) + ((long) iValidateZipDirectory$lambda$0$u16)) + ((long) iValidateZipDirectory$lambda$0$u17) <= j8) {
/* 149 */                                       throw new IllegalArgumentException("Invalid ZIP local filename bounds".toString());
                                            }
/* 150 */                                   bArr2 = new byte[iValidateZipDirectory$lambda$0$u16];
                                            randomAccessFile2.readFully(bArr2);
/* 122 */                                   if (Intrinsics.areEqual(utf8(bArr2), strUtf8)) {
/* 151 */                                       throw new IllegalArgumentException("ZIP local/central filenames disagree".toString());
                                            }
                                            randomAccessFile2.seek(filePointer);
/* 114 */                                   i10 = i4 + 1;
                                            markCentral = function1;
                                            i9 = i;
                                            jValidateZipDirectory$lambda$0$u67 = j8;
                                            iValidateZipDirectory$lambda$0$u18 = i11;
                                            jValidateZipDirectory$lambda$0$u16 = j3;
                                            setKeySet = set;
                                        } else {
                                            j3 = jValidateZipDirectory$lambda$0$u16;
                                            i = i9;
                                            i2 = iValidateZipDirectory$lambda$0$u112;
                                            i3 = iValidateZipDirectory$lambda$0$u113;
                                            i4 = i10;
                                        }
                                        if (z7) {
/* 119 */                                   throw new IllegalArgumentException("Invalid ZIP central filename/entry bounds".toString());
                                        }
/* 120 */                               if (validateZipDirectory$lambda$0$u16(randomAccessFile2) == 0) {
                                            z8 = true;
                                        } else {
                                            z8 = false;
                                        }
                                        if (z8) {
/* 120 */                                   throw new IllegalArgumentException("Multi-disk ZIP entry".toString());
                                        }
                                        randomAccessFile2.skipBytes(6);
                                        jValidateZipDirectory$lambda$0$u32 = validateZipDirectory$lambda$0$u32(randomAccessFile2);
/* 121 */                               byte[] bArr5 = new byte[iValidateZipDirectory$lambda$0$u111];
                                        randomAccessFile2.readFully(bArr5);
                                        strUtf8 = utf8(bArr5);
/* 122 */                               if (setKeySet.contains(strUtf8)) {
                                            z9 = false;
                                        } else {
                                            z9 = false;
                                        }
                                        if (z9) {
/* 122 */                                   throw new IllegalArgumentException("ZIP central filename mismatch/duplicate".toString());
                                        }
/* 123 */                               bArr = new byte[i2];
                                        randomAccessFile2.readFully(bArr);
                                        randomAccessFile2.skipBytes(i3);
                                        if (jValidateZipDirectory$lambda$0$u37 != 4294967295L) {
/* 125 */                                   byteBufferOrder = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
                                            z10 = false;
                                            while (true) {
/* 126 */                                       z11 = z10;
                                                set = setKeySet;
                                                if (byteBufferOrder.remaining() < 4) {
                                                    if (!z11) {
/* 139 */                                               throw new IllegalArgumentException("Missing ZIP64 central extra".toString());
                                                    }
                                                    j4 = jValidateZipDirectory$lambda$0$u32;
                                                    break;
                                                }
/* 127 */                                       i5 = byteBufferOrder.getShort() & SupportMenu.USER_MASK;
                                                i6 = byteBufferOrder.getShort() & UShort.MAX_VALUE;
/* 128 */                                       i7 = i2;
                                                if (i6 <= byteBufferOrder.remaining()) {
                                                    z12 = true;
                                                } else {
                                                    z12 = false;
                                                }
                                                if (!z12) {
/* 128 */                                           throw new IllegalArgumentException("Truncated ZIP64 central extra".toString());
                                                }
/* 129 */                                       int iPosition2 = byteBufferOrder.position() + i6;
/* 130 */                                       int i13 = i3;
                                                if (i5 == 1) {
/* 131 */                                           if (z11) {
                                                        z13 = true;
                                                    } else {
                                                        z13 = false;
                                                    }
                                                    if (!z13) {
/* 131 */                                               throw new IllegalArgumentException("Duplicate ZIP64 central extra".toString());
                                                    }
                                                    byteBufferOrder2 = byteBufferOrder.slice().order(ByteOrder.LITTLE_ENDIAN);
                                                    byteBufferOrder2.limit(i6);
                                                    if (jValidateZipDirectory$lambda$0$u37 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u37 = byteBufferOrder2.getLong();
                                                    }
                                                    if (jValidateZipDirectory$lambda$0$u36 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u36 = byteBufferOrder2.getLong();
                                                    }
                                                    if (jValidateZipDirectory$lambda$0$u32 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u32 = byteBufferOrder2.getLong();
                                                    }
                                                    z10 = true;
                                                } else {
                                                    z10 = z11;
                                                }
/* 137 */                                       byteBufferOrder.position(iPosition2);
                                                i2 = i7;
                                                setKeySet = set;
                                                i3 = i13;
                                            }
                                        } else {
/* 125 */                                   byteBufferOrder = ByteBuffer.wrap(bArr).order(ByteOrder.LITTLE_ENDIAN);
                                            z10 = false;
                                            while (true) {
/* 126 */                                       z11 = z10;
                                                set = setKeySet;
                                                if (byteBufferOrder.remaining() < 4) {
                                                    if (!z11) {
/* 139 */                                               throw new IllegalArgumentException("Missing ZIP64 central extra".toString());
                                                    }
                                                    j4 = jValidateZipDirectory$lambda$0$u32;
                                                    break;
                                                }
/* 127 */                                       i5 = byteBufferOrder.getShort() & SupportMenu.USER_MASK;
                                                i6 = byteBufferOrder.getShort() & UShort.MAX_VALUE;
/* 128 */                                       i7 = i2;
                                                if (i6 <= byteBufferOrder.remaining()) {
                                                    z12 = true;
                                                } else {
                                                    z12 = false;
                                                }
                                                if (!z12) {
/* 128 */                                           throw new IllegalArgumentException("Truncated ZIP64 central extra".toString());
                                                }
/* 129 */                                       int iPosition3 = byteBufferOrder.position() + i6;
/* 130 */                                       int i14 = i3;
                                                if (i5 == 1) {
/* 131 */                                           if (z11) {
                                                        z13 = true;
                                                    } else {
                                                        z13 = false;
                                                    }
                                                    if (!z13) {
/* 131 */                                               throw new IllegalArgumentException("Duplicate ZIP64 central extra".toString());
                                                    }
                                                    byteBufferOrder2 = byteBufferOrder.slice().order(ByteOrder.LITTLE_ENDIAN);
                                                    byteBufferOrder2.limit(i6);
                                                    if (jValidateZipDirectory$lambda$0$u37 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u37 = byteBufferOrder2.getLong();
                                                    }
                                                    if (jValidateZipDirectory$lambda$0$u36 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u36 = byteBufferOrder2.getLong();
                                                    }
                                                    if (jValidateZipDirectory$lambda$0$u32 == 4294967295L) {
                                                        jValidateZipDirectory$lambda$0$u32 = byteBufferOrder2.getLong();
                                                    }
                                                    z10 = true;
                                                } else {
                                                    z10 = z11;
                                                }
/* 137 */                                       byteBufferOrder.position(iPosition3);
                                                i2 = i7;
                                                setKeySet = set;
                                                i3 = i14;
                                            }
                                        }
/* 141 */                               i8++;
/* 122 */                               ZipRecord zipRecord2 = (ZipRecord) MapsKt.getValue(records, strUtf8);
/* 143 */                               if ((iValidateZipDirectory$lambda$0$u19 & 1) != 0) {
                                            z14 = false;
                                        } else {
                                            z14 = false;
                                        }
                                        if (z14) {
/* 143 */                                   throw new IllegalArgumentException("ZIP central size/CRC/method disagrees with streamed entry".toString());
                                        }
                                        if (j4 < 0 && ((long) 30) + j4 <= j8) {
/* 144 */                                   throw new IllegalArgumentException("Invalid ZIP local entry offset".toString());
                                        }
/* 145 */                               filePointer = randomAccessFile2.getFilePointer();
                                        randomAccessFile2.seek(j4);
                                        if (validateZipDirectory$lambda$0$u32(randomAccessFile2) == 67324752) {
                                            z15 = true;
                                        } else {
                                            z15 = false;
                                        }
                                        if (z15) {
/* 146 */                                   throw new IllegalArgumentException("ZIP central offset does not reference a local entry".toString());
                                        }
                                        validateZipDirectory$lambda$0$u16(randomAccessFile2);
/* 147 */                               j5 = j4;
                                        if (validateZipDirectory$lambda$0$u16(randomAccessFile2) == iValidateZipDirectory$lambda$0$u19) {
                                            z16 = false;
                                        } else {
                                            z16 = false;
                                        }
                                        if (z16) {
/* 147 */                                   throw new IllegalArgumentException("ZIP local/central flags or method disagree".toString());
                                        }
                                        randomAccessFile2.skipBytes(16);
/* 148 */                               iValidateZipDirectory$lambda$0$u16 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        iValidateZipDirectory$lambda$0$u17 = validateZipDirectory$lambda$0$u16(randomAccessFile2);
                                        if (1 <= iValidateZipDirectory$lambda$0$u16) {
                                            z17 = false;
                                        } else {
                                            z17 = false;
                                        }
                                        if (!z17 && ((j5 + 30) + ((long) iValidateZipDirectory$lambda$0$u16)) + ((long) iValidateZipDirectory$lambda$0$u17) <= j8) {
/* 149 */                                   throw new IllegalArgumentException("Invalid ZIP local filename bounds".toString());
                                        }
/* 150 */                               bArr2 = new byte[iValidateZipDirectory$lambda$0$u16];
                                        randomAccessFile2.readFully(bArr2);
/* 122 */                               if (Intrinsics.areEqual(utf8(bArr2), strUtf8)) {
/* 151 */                                   throw new IllegalArgumentException("ZIP local/central filenames disagree".toString());
                                        }
                                        randomAccessFile2.seek(filePointer);
/* 114 */                               i10 = i4 + 1;
                                        markCentral = function1;
                                        i9 = i;
                                        jValidateZipDirectory$lambda$0$u67 = j8;
                                        iValidateZipDirectory$lambda$0$u18 = i11;
                                        jValidateZipDirectory$lambda$0$u16 = j3;
                                        setKeySet = set;
                                    }
                                    if (!(randomAccessFile2.getFilePointer() == j6 && i8 == setKeySet.size())) {
/* 153 */                               throw new IllegalArgumentException("Corrupt ZIP central directory length".toString());
                                    }
                                    Unit unit = Unit.INSTANCE;
/* 92 */                            CloseableKt.closeFinally(randomAccessFile, null);
/* 155 */                           return;
                                } catch (Throwable th5) {
/* 92 */                            th = th5;
                                    th = th;
                                }
                                throw th;
                            } catch (Throwable th6) {
                                CloseableKt.closeFinally(randomAccessFile, th);
                                throw th6;
                            }
                        } catch (Throwable th7) {
/* 92 */                    th = th7;
                        }
                    } catch (Throwable th8) {
                        th = th8;
                    }
                    th = th;
                }

/* 92 */        private static final int validateZipDirectory$lambda$0$u16(RandomAccessFile $archive) {
/* 93 */            return $archive.readUnsignedByte() | ($archive.readUnsignedByte() << 8);
                }

/* 93 */        private static final long validateZipDirectory$lambda$0$u32(RandomAccessFile $archive) {
/* 94 */            return ((long) Integer.reverseBytes($archive.readInt())) & 4294967295L;
                }

/* 94 */        private static final long validateZipDirectory$lambda$0$u64(RandomAccessFile $archive) {
/* 95 */            long jReverseBytes = Long.reverseBytes($archive.readLong());
                    if (jReverseBytes >= 0) {
                        return jReverseBytes;
                    }
                    throw new IllegalArgumentException("Invalid ZIP64 offset/size".toString());
                }
            }

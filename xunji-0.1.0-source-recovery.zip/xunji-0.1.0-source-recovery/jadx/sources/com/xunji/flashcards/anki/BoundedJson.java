            package com.xunji.flashcards.anki;

            import androidx.core.view.MotionEventCompat;
            import java.util.LinkedHashSet;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.MagicApiIntrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.jvm.internal.Reflection;
            import kotlin.reflect.KType;
            import kotlin.text.StringsKt;
            import kotlinx.serialization.SerializersKt;
            import kotlinx.serialization.json.Json;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.modules.SerializersModule;
            
            /* JADX INFO: compiled from: BoundedApkg.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\bÁ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007¨\u0006\b"}, d2 = {"Lcom/xunji/flashcards/anki/BoundedJson;", "", "<init>", "()V", "parse", "Lkotlinx/serialization/json/JsonElement;", "text", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 52 */    public final class BoundedJson {
                public static final int $stable = 0;
                public static final BoundedJson INSTANCE = new BoundedJson();

/* 53 */        private BoundedJson() {
                }

/* 55 */        public final JsonElement parse(String text) {
                    Intrinsics.checkNotNullParameter(text, "text");
/* 56 */            Ref.IntRef offset = new Ref.IntRef();
/* 84 */            parse$value(offset, text, 0);
                    parse$whitespace(offset, text);
                    if (offset.element == text.length()) {
                        return Json.INSTANCE.parseToJsonElement(text);
                    }
                    throw new IllegalArgumentException("Trailing JSON input".toString());
                }

/* 56 */        private static final void parse$whitespace(Ref.IntRef offset, String $text) {
                    while (offset.element < $text.length() && StringsKt.contains$default((CharSequence) " \n\r\t", $text.charAt(offset.element), false, 2, (Object) null)) {
                        offset.element++;
                    }
                }

/* 58 */        private static final String parse$string(Ref.IntRef offset, String $text) {
/* 59 */            int start = offset.element;
                    offset.element = start + 1;
                    if (!(start < $text.length() && $text.charAt(start) == '\"')) {
                        throw new IllegalArgumentException("Expected JSON string".toString());
                    }
/* 60 */            while (offset.element < $text.length()) {
                        int i = offset.element;
                        offset.element = i + 1;
                        switch ($text.charAt(i)) {
                            case MotionEventCompat.AXIS_GENERIC_3 /* 34 */:
                                Json json = Json.INSTANCE;
                                String strSubstring = $text.substring(start, offset.element);
                                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
/* 158 */                       SerializersModule serializersModule = json.getSerializersModule();
                                KType kTypeTypeOf = Reflection.typeOf(String.class);
                                MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
                                return (String) json.decodeFromString(SerializersKt.serializer(serializersModule, kTypeTypeOf), strSubstring);
                            case '\\':
                                offset.element++;
                                break;
                        }
                    }
/* 61 */            throw new IllegalArgumentException("Truncated JSON string");
                }

                /* JADX WARN: Code duplicated, block: B:27:0x007a  */
/* 63 */        private static final void parse$value(Ref.IntRef offset, String $text, int depth) {
                    boolean z;
/* 64 */            parse$whitespace(offset, $text);
                    if (!(offset.element < $text.length())) {
                        throw new IllegalArgumentException("Truncated JSON value".toString());
                    }
                    switch ($text.charAt(offset.element)) {
                        case MotionEventCompat.AXIS_GENERIC_3 /* 34 */:
/* 80 */                    parse$string(offset, $text);
/* 83 */                    return;
                        case '[':
/* 76 */                    if (!(depth < 64)) {
                                throw new IllegalArgumentException("JSON nesting exceeds 64 levels".toString());
                            }
                            offset.element++;
                            parse$whitespace(offset, $text);
/* 77 */                    if (offset.element < $text.length() && $text.charAt(offset.element) == ']') {
                                offset.element++;
                                return;
                            }
                            while (true) {
/* 78 */                        parse$value(offset, $text, depth + 1);
                                parse$whitespace(offset, $text);
                                if (!(offset.element < $text.length())) {
                                    throw new IllegalArgumentException("Truncated JSON array".toString());
                                }
                                int i = offset.element;
                                offset.element = i + 1;
                                switch ($text.charAt(i)) {
                                    case MotionEventCompat.AXIS_GENERIC_13 /* 44 */:
                                        break;
                                    case ']':
                                        return;
                                    default:
                                        throw new IllegalArgumentException("Invalid JSON array delimiter");
                                }
                            }
                            break;
                        case '{':
/* 67 */                    if (!(depth < 64)) {
                                throw new IllegalArgumentException("JSON nesting exceeds 64 levels".toString());
                            }
                            offset.element++;
                            parse$whitespace(offset, $text);
                            Set names = new LinkedHashSet();
/* 68 */                    if (offset.element < $text.length() && $text.charAt(offset.element) == '}') {
                                offset.element++;
                                return;
                            }
                            while (true) {
/* 70 */                        parse$whitespace(offset, $text);
                                if (!names.add(parse$string(offset, $text))) {
                                    throw new IllegalArgumentException("Duplicate JSON object key".toString());
                                }
                                parse$whitespace(offset, $text);
                                if (offset.element < $text.length()) {
                                    int i2 = offset.element;
                                    offset.element = i2 + 1;
                                    if ($text.charAt(i2) == ':') {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                } else {
                                    z = false;
                                }
                                if (!z) {
                                    throw new IllegalArgumentException("Invalid JSON object".toString());
                                }
/* 71 */                        parse$value(offset, $text, depth + 1);
                                parse$whitespace(offset, $text);
                                if (!(offset.element < $text.length())) {
                                    throw new IllegalArgumentException("Truncated JSON object".toString());
                                }
/* 72 */                        int i3 = offset.element;
                                offset.element = i3 + 1;
                                switch ($text.charAt(i3)) {
                                    case MotionEventCompat.AXIS_GENERIC_13 /* 44 */:
                                        break;
                                    case '}':
                                        return;
                                    default:
                                        throw new IllegalArgumentException("Invalid JSON object delimiter");
                                }
                            }
                            break;
                        default:
/* 81 */                    int start = offset.element;
/* 81 */                    while (offset.element < $text.length() && !StringsKt.contains$default((CharSequence) ",]} \n\r\t", $text.charAt(offset.element), false, 2, (Object) null)) {
                                offset.element++;
                            }
                            if (!(offset.element > start)) {
                                throw new IllegalArgumentException("Invalid JSON value".toString());
                            }
/* 83 */                    return;
                    }
                }
            }

            package com.xunji.flashcards.anki;

            import androidx.autofill.HintConstants;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiCardPresenter.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J'\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0016"}, d2 = {"Lcom/xunji/flashcards/anki/CardMedia;", "", "namespace", "", HintConstants.AUTOFILL_HINT_NAME, "mime", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getNamespace", "()Ljava/lang/String;", "getName", "getMime", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 10 */    public final /* data */ class CardMedia {
                public static final int $stable = 0;
                private final String mime;
                private final String name;
                private final String namespace;

                public static /* synthetic */ CardMedia copy$default(CardMedia cardMedia, String str, String str2, String str3, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = cardMedia.namespace;
                    }
                    if ((i & 2) != 0) {
                        str2 = cardMedia.name;
                    }
                    if ((i & 4) != 0) {
                        str3 = cardMedia.mime;
                    }
                    return cardMedia.copy(str, str2, str3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getNamespace() {
                    return this.namespace;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getMime() {
                    return this.mime;
                }

                public final CardMedia copy(String namespace, String name, String mime) {
                    Intrinsics.checkNotNullParameter(namespace, "namespace");
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(mime, "mime");
                    return new CardMedia(namespace, name, mime);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof CardMedia)) {
                        return false;
                    }
                    CardMedia cardMedia = (CardMedia) other;
                    return Intrinsics.areEqual(this.namespace, cardMedia.namespace) && Intrinsics.areEqual(this.name, cardMedia.name) && Intrinsics.areEqual(this.mime, cardMedia.mime);
                }

                public int hashCode() {
                    return (((this.namespace.hashCode() * 31) + this.name.hashCode()) * 31) + this.mime.hashCode();
                }

                public String toString() {
                    return "CardMedia(namespace=" + this.namespace + ", name=" + this.name + ", mime=" + this.mime + ")";
                }

/* 11 */        public CardMedia(String namespace, String name, String mime) {
                    Intrinsics.checkNotNullParameter(namespace, "namespace");
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(mime, "mime");
                    this.namespace = namespace;
                    this.name = name;
                    this.mime = mime;
                }

/* 11 */        public final String getMime() {
/* 12 */            return this.mime;
                }

/* 11 */        public final String getName() {
/* 12 */            return this.name;
                }

/* 11 */        public final String getNamespace() {
/* 12 */            return this.namespace;
                }
            }

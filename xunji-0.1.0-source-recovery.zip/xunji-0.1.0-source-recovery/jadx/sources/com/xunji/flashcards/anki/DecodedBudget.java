            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.JobKt;
            
            /* JADX INFO: compiled from: BoundedApkg.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0000\b\u0001\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u000e\u0010\f\u001a\u00020\u0003X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0011"}, d2 = {"Lcom/xunji/flashcards/anki/DecodedBudget;", "", "maximum", "", "context", "Lkotlin/coroutines/CoroutineContext;", "<init>", "(JLkotlin/coroutines/CoroutineContext;)V", "getMaximum", "()J", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "bytes", "add", "", "n", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public final class DecodedBudget {
                public static final int $stable = 8;
                private long bytes;
                private final CoroutineContext context;
                private final long maximum;

/* 13 */        public DecodedBudget(long maximum, CoroutineContext context) {
                    Intrinsics.checkNotNullParameter(context, "context");
                    this.maximum = maximum;
                    this.context = context;
                }

/* 13 */        public final CoroutineContext getContext() {
/* 14 */            return this.context;
                }

/* 13 */        public final long getMaximum() {
/* 14 */            return this.maximum;
                }

/* 15 */        public final void add(int n) {
/* 16 */            JobKt.ensureActive(this.context);
                    this.bytes += (long) n;
                    if (this.bytes <= this.maximum) {
                    } else {
                        throw new IllegalArgumentException(("Total decoded bytes exceed " + this.maximum).toString());
                    }
                }
            }

            package com.xunji.flashcards.anki;

            import java.io.FilterInputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.JobKt;
            
            /* JADX INFO: compiled from: BoundedApkg.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0000\b\u0001\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\b\u0010\u000b\u001a\u00020\fH\u0016J \u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0010\u001a\u00020\fH\u0016J\u0010\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\u0005H\u0016J\u0010\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0012\u001a\u00020\fH\u0002R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0005X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0015"}, d2 = {"Lcom/xunji/flashcards/anki/DecodedInputStream;", "Ljava/io/FilterInputStream;", "input", "Ljava/io/InputStream;", "maximum", "", "budget", "Lcom/xunji/flashcards/anki/DecodedBudget;", "<init>", "(Ljava/io/InputStream;JLcom/xunji/flashcards/anki/DecodedBudget;)V", "bytes", "read", "", "buffer", "", "offset", "length", "skip", "n", "count", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final class DecodedInputStream extends FilterInputStream {
                public static final int $stable = 8;
                private final DecodedBudget budget;
                private long bytes;
                private final long maximum;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
/* 17 */        public DecodedInputStream(InputStream input, long maximum, DecodedBudget budget) {
/* 18 */            super(input);
                    Intrinsics.checkNotNullParameter(input, "input");
                    Intrinsics.checkNotNullParameter(budget, "budget");
                    this.maximum = maximum;
                    this.budget = budget;
                }

                @Override // java.io.FilterInputStream, java.io.InputStream
/* 19 */        public int read() throws IOException {
/* 20 */            JobKt.ensureActive(this.budget.getContext());
                    int i = ((FilterInputStream) this).in.read();
/* 20 */            if (i >= 0) {
                        count(1);
                    }
                    return i;
                }

                @Override // java.io.FilterInputStream, java.io.InputStream
/* 20 */        public int read(byte[] buffer, int offset, int length) throws IOException {
                    Intrinsics.checkNotNullParameter(buffer, "buffer");
/* 21 */            JobKt.ensureActive(this.budget.getContext());
                    int i = ((FilterInputStream) this).in.read(buffer, offset, length);
/* 21 */            if (i > 0) {
                        count(i);
                    }
                    return i;
                }

                @Override // java.io.FilterInputStream, java.io.InputStream
/* 21 */        public long skip(long n) {
/* 22 */            return BoundedApkgKt.consumeSkip(this, n);
                }

/* 22 */        private final void count(int n) {
/* 23 */            this.budget.add(n);
                    this.bytes += (long) n;
                    if (this.bytes <= this.maximum) {
                    } else {
                        throw new IllegalArgumentException(("Decoded media manifest exceeds " + this.maximum + " bytes").toString());
                    }
                }
            }

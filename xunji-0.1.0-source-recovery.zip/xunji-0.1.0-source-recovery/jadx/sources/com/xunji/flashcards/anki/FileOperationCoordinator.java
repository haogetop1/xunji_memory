            package com.xunji.flashcards.anki;

            import androidx.core.view.MotionEventCompat;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.sync.Mutex;
            import kotlinx.coroutines.sync.MutexKt;
            
            /* JADX INFO: compiled from: FileOperationCoordinator.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0001\u0018\u00002\u00020\u0001:\u0001\u0013B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J=\u0010\u000b\u001a\u0002H\f\"\u0004\b\u0000\u0010\f2'\u0010\r\u001a#\b\u0001\u0012\u0004\u0012\u00020\u000f\u0012\n\u0012\b\u0012\u0004\u0012\u0002H\f0\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u00010\u000e¢\u0006\u0002\b\u0011H\u0086@¢\u0006\u0002\u0010\u0012R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u001e\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0007@BX\u0086\u000e¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\n¨\u0006\u0014"}, d2 = {"Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "", "<init>", "()V", "mutex", "Lkotlinx/coroutines/sync/Mutex;", "value", "", "restoreEpoch", "getRestoreEpoch", "()J", "withLock", "T", "block", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;", "Lkotlin/coroutines/Continuation;", "Lkotlin/ExtensionFunctionType;", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Operation", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */     public final class FileOperationCoordinator {
                public static final int $stable = 8;
                private final Mutex mutex = MutexKt.Mutex$default(false, 1, null);
                private volatile long restoreEpoch;

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.FileOperationCoordinator$withLock$1, reason: invalid class name */
                /* JADX INFO: compiled from: FileOperationCoordinator.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.FileOperationCoordinator", f = "FileOperationCoordinator.kt", i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1}, l = {MotionEventCompat.AXIS_GENERIC_6, 16}, m = "withLock", n = {"block", "operation", "$this$withLock\\1", "owner\\1", "$i$f$withLock\\1\\14", "block", "operation", "$this$withLock\\1", "owner\\1", "$i$f$withLock\\1\\14", "$i$a$-withLock-FileOperationCoordinator$withLock$2\\2\\39\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0", "L$0", "L$1", "L$2", "L$3", "I$0", "I$1"}, v = 1)
                static final class AnonymousClass1<T> extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return FileOperationCoordinator.this.withLock(null, this);
                    }
                }

/* 8 */         public final long getRestoreEpoch() {
/* 9 */             return this.restoreEpoch;
                }

                /* JADX WARN: Code duplicated, block: B:26:0x00a8 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:27:0x00a9  */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 11 */        public final <T> Object withLock(Function2<? super Operation, ? super Continuation<? super T>, ? extends Object> function2, Continuation<? super T> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    Operation operation;
                    int i;
                    Mutex mutex;
                    Object obj;
                    Object obj2;
                    Mutex mutex2;
                    Operation operation2;
                    Throwable th;
                    Object objInvoke;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 13 */                    Operation operation3 = new Operation(this);
/* 14 */                    Mutex mutex3 = this.mutex;
/* 37 */                    anonymousClass1.L$0 = function2;
                            anonymousClass1.L$1 = operation3;
                            anonymousClass1.L$2 = mutex3;
                            anonymousClass1.L$3 = operation3;
                            anonymousClass1.I$0 = 0;
                            anonymousClass1.label = 1;
                            if (mutex3.lock(operation3, anonymousClass1) == coroutine_suspended) {
/* 12 */                        return coroutine_suspended;
                            }
                            operation = operation3;
/* 37 */                    i = 0;
                            mutex = mutex3;
                            obj = operation3;
                            try {
/* 15 */                        operation.setActive$app_debug(true);
                                try {
/* 16 */                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(function2);
                                    anonymousClass1.L$1 = operation;
                                    anonymousClass1.L$2 = mutex;
                                    anonymousClass1.L$3 = obj;
                                    anonymousClass1.I$0 = i;
/* 39 */                            anonymousClass1.I$1 = 0;
                                    anonymousClass1.label = 2;
                                    objInvoke = function2.invoke(operation, anonymousClass1);
                                    if (objInvoke == coroutine_suspended) {
/* 12 */                                return coroutine_suspended;
                                    }
                                    operation.setActive$app_debug(false);
/* 41 */                            mutex.unlock(obj);
/* 14 */                            return objInvoke;
                                } catch (Throwable th2) {
                                    obj2 = obj;
                                    mutex2 = mutex;
                                    operation2 = operation;
                                    th = th2;
                                    try {
                                        operation2.setActive$app_debug(false);
                                        throw th;
                                    } catch (Throwable th3) {
/* 41 */                                th = th3;
                                        mutex = mutex2;
                                        obj = obj2;
                                        mutex.unlock(obj);
                                        throw th;
                                    }
                                }
                            } catch (Throwable th4) {
                                th = th4;
                                mutex.unlock(obj);
                                throw th;
                            }
                        case 1:
/* 12 */                    i = anonymousClass1.I$0;
                            obj = (Operation) anonymousClass1.L$3;
                            mutex = (Mutex) anonymousClass1.L$2;
                            operation = (Operation) anonymousClass1.L$1;
                            function2 = (Function2) anonymousClass1.L$0;
                            ResultKt.throwOnFailure($result);
/* 15 */                    operation.setActive$app_debug(true);
/* 16 */                    anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(function2);
                            anonymousClass1.L$1 = operation;
                            anonymousClass1.L$2 = mutex;
                            anonymousClass1.L$3 = obj;
                            anonymousClass1.I$0 = i;
/* 39 */                    anonymousClass1.I$1 = 0;
                            anonymousClass1.label = 2;
                            objInvoke = function2.invoke(operation, anonymousClass1);
                            if (objInvoke == coroutine_suspended) {
/* 12 */                        return coroutine_suspended;
                            }
                            operation.setActive$app_debug(false);
/* 41 */                    mutex.unlock(obj);
/* 14 */                    return objInvoke;
                        case 2:
                            int i2 = anonymousClass1.I$1;
                            int i3 = anonymousClass1.I$0;
                            obj2 = (Operation) anonymousClass1.L$3;
                            mutex2 = (Mutex) anonymousClass1.L$2;
                            operation2 = (Operation) anonymousClass1.L$1;
                            try {
                                ResultKt.throwOnFailure($result);
                                operation = operation2;
                                mutex = mutex2;
                                obj = obj2;
                                objInvoke = $result;
                                operation.setActive$app_debug(false);
/* 41 */                        mutex.unlock(obj);
/* 14 */                        return objInvoke;
                            } catch (Throwable th5) {
/* 16 */                        th = th5;
                                operation2.setActive$app_debug(false);
                                throw th;
                            }
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: compiled from: FileOperationCoordinator.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0015\u0010\f\u001a\u00020\r2\u0006\u0010\u000e\u001a\u00020\u0003H\u0000¢\u0006\u0002\b\u000fJ\u000e\u0010\u0010\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u0012J\u0006\u0010\u0013\u001a\u00020\rR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u001a\u0010\u0006\u001a\u00020\u0007X\u0080\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\b\u0010\t\"\u0004\b\n\u0010\u000b¨\u0006\u0014"}, d2 = {"Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;", "", "coordinator", "Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "<init>", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator;)V", "active", "", "getActive$app_debug", "()Z", "setActive$app_debug", "(Z)V", "checkOwner", "", "owner", "checkOwner$app_debug", "requireEpoch", "expected", "", "markRestoreCommitted", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 18 */        public static final class Operation {
                    public static final int $stable = 8;
                    private boolean active;
                    private final FileOperationCoordinator coordinator;

/* 19 */            public Operation(FileOperationCoordinator coordinator) {
                        Intrinsics.checkNotNullParameter(coordinator, "coordinator");
                        this.coordinator = coordinator;
                    }

                    /* JADX INFO: renamed from: getActive$app_debug, reason: from getter */
/* 20 */            public final boolean getActive() {
/* 21 */                return this.active;
                    }

/* 20 */            public final void setActive$app_debug(boolean z) {
/* 21 */                this.active = z;
                    }

/* 22 */            public final void checkOwner$app_debug(FileOperationCoordinator owner) {
                        Intrinsics.checkNotNullParameter(owner, "owner");
/* 23 */                if (!(this.active && this.coordinator == owner && holdsLock(this))) {
                            throw new IllegalStateException("File operation requires its active coordination lock".toString());
                        }
                    }

/* 25 */            public final void requireEpoch(long expected) {
/* 26 */                checkOwner$app_debug(this.coordinator);
                        if (!(this.coordinator.getRestoreEpoch() == expected)) {
                            throw new IllegalArgumentException("Data was restored; repeat import preflight".toString());
                        }
                    }

/* 29 */            public final void markRestoreCommitted() {
/* 30 */                checkOwner$app_debug(this.coordinator);
                        if (!(this.coordinator.getRestoreEpoch() < Long.MAX_VALUE)) {
                            throw new IllegalStateException("Restore epoch exhausted".toString());
                        }
/* 32 */                FileOperationCoordinator fileOperationCoordinator = this.coordinator;
/* 7 */                 fileOperationCoordinator.restoreEpoch = fileOperationCoordinator.getRestoreEpoch() + 1;
                    }
                }
            }

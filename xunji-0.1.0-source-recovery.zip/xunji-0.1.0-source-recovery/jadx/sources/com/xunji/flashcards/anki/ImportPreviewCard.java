            package com.xunji.flashcards.anki;

            import androidx.core.app.NotificationCompat;
            import com.xunji.core.anki.ImportIssue;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0081\b\u0018\u00002\u00020\u0001B=\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0005\u0012\u0006\u0010\t\u001a\u00020\n\u0012\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0005HÆ\u0003J\t\u0010\u001f\u001a\u00020\nHÆ\u0003J\u000f\u0010 \u001a\b\u0012\u0004\u0012\u00020\r0\fHÆ\u0003JK\u0010!\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\fHÆ\u0001J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010%\u001a\u00020\u0007HÖ\u0001J\t\u0010&\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\b\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\r0\f¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001a¨\u0006'"}, d2 = {"Lcom/xunji/flashcards/anki/ImportPreviewCard;", "", "sourceCardId", "", "guid", "", "ordinal", "", "deckName", NotificationCompat.CATEGORY_STATUS, "Lcom/xunji/flashcards/anki/PreviewStatus;", "issues", "", "Lcom/xunji/core/anki/ImportIssue;", "<init>", "(JLjava/lang/String;ILjava/lang/String;Lcom/xunji/flashcards/anki/PreviewStatus;Ljava/util/List;)V", "getSourceCardId", "()J", "getGuid", "()Ljava/lang/String;", "getOrdinal", "()I", "getDeckName", "getStatus", "()Lcom/xunji/flashcards/anki/PreviewStatus;", "getIssues", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 23 */    public final /* data */ class ImportPreviewCard {
                public static final int $stable = 8;
                private final String deckName;
                private final String guid;
                private final List<ImportIssue> issues;
                private final int ordinal;
                private final long sourceCardId;
                private final PreviewStatus status;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ ImportPreviewCard copy$default(ImportPreviewCard importPreviewCard, long j, String str, int i, String str2, PreviewStatus previewStatus, List list, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        j = importPreviewCard.sourceCardId;
                    }
                    long j2 = j;
                    if ((i2 & 2) != 0) {
                        str = importPreviewCard.guid;
                    }
                    String str3 = str;
                    if ((i2 & 4) != 0) {
                        i = importPreviewCard.ordinal;
                    }
                    int i3 = i;
                    if ((i2 & 8) != 0) {
                        str2 = importPreviewCard.deckName;
                    }
                    String str4 = str2;
                    if ((i2 & 16) != 0) {
                        previewStatus = importPreviewCard.status;
                    }
                    PreviewStatus previewStatus2 = previewStatus;
                    if ((i2 & 32) != 0) {
                        list = importPreviewCard.issues;
                    }
                    return importPreviewCard.copy(j2, str3, i3, str4, previewStatus2, list);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSourceCardId() {
                    return this.sourceCardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getGuid() {
                    return this.guid;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getOrdinal() {
                    return this.ordinal;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getDeckName() {
                    return this.deckName;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final PreviewStatus getStatus() {
                    return this.status;
                }

                public final List<ImportIssue> component6() {
                    return this.issues;
                }

                public final ImportPreviewCard copy(long sourceCardId, String guid, int ordinal, String deckName, PreviewStatus status, List<ImportIssue> issues) {
                    Intrinsics.checkNotNullParameter(guid, "guid");
                    Intrinsics.checkNotNullParameter(deckName, "deckName");
                    Intrinsics.checkNotNullParameter(status, "status");
                    Intrinsics.checkNotNullParameter(issues, "issues");
                    return new ImportPreviewCard(sourceCardId, guid, ordinal, deckName, status, issues);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ImportPreviewCard)) {
                        return false;
                    }
                    ImportPreviewCard importPreviewCard = (ImportPreviewCard) other;
                    return this.sourceCardId == importPreviewCard.sourceCardId && Intrinsics.areEqual(this.guid, importPreviewCard.guid) && this.ordinal == importPreviewCard.ordinal && Intrinsics.areEqual(this.deckName, importPreviewCard.deckName) && this.status == importPreviewCard.status && Intrinsics.areEqual(this.issues, importPreviewCard.issues);
                }

                public int hashCode() {
                    return (((((((((Long.hashCode(this.sourceCardId) * 31) + this.guid.hashCode()) * 31) + Integer.hashCode(this.ordinal)) * 31) + this.deckName.hashCode()) * 31) + this.status.hashCode()) * 31) + this.issues.hashCode();
                }

                public String toString() {
                    return "ImportPreviewCard(sourceCardId=" + this.sourceCardId + ", guid=" + this.guid + ", ordinal=" + this.ordinal + ", deckName=" + this.deckName + ", status=" + this.status + ", issues=" + this.issues + ")";
                }

/* 24 */        public ImportPreviewCard(long sourceCardId, String guid, int ordinal, String deckName, PreviewStatus status, List<ImportIssue> issues) {
                    Intrinsics.checkNotNullParameter(guid, "guid");
                    Intrinsics.checkNotNullParameter(deckName, "deckName");
                    Intrinsics.checkNotNullParameter(status, "status");
                    Intrinsics.checkNotNullParameter(issues, "issues");
/* 26 */            this.sourceCardId = sourceCardId;
                    this.guid = guid;
                    this.ordinal = ordinal;
                    this.deckName = deckName;
/* 27 */            this.status = status;
                    this.issues = issues;
                }

/* 25 */        public final String getDeckName() {
/* 26 */            return this.deckName;
                }

/* 25 */        public final String getGuid() {
/* 26 */            return this.guid;
                }

/* 25 */        public final int getOrdinal() {
/* 26 */            return this.ordinal;
                }

/* 25 */        public final long getSourceCardId() {
/* 26 */            return this.sourceCardId;
                }

/* 26 */        public final List<ImportIssue> getIssues() {
/* 27 */            return this.issues;
                }

/* 26 */        public final PreviewStatus getStatus() {
/* 27 */            return this.status;
                }
            }

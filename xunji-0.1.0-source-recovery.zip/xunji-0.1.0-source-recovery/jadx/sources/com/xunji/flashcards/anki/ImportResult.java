            package com.xunji.flashcards.anki;

            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0081\b\u0018\u00002\u00020\u0001BC\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00030\t¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\u0015\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00030\tHÆ\u0003JQ\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\u0014\b\u0002\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00030\tHÆ\u0001J\u0013\u0010\u001c\u001a\u00020\u001d2\b\u0010\u001e\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001f\u001a\u00020\u0003HÖ\u0001J\t\u0010 \u001a\u00020\nHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u001d\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00030\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014¨\u0006!"}, d2 = {"Lcom/xunji/flashcards/anki/ImportResult;", "", "addedCards", "", "duplicateCards", "skippedCards", "addedNotes", "addedDecks", "reasons", "", "", "<init>", "(IIIIILjava/util/Map;)V", "getAddedCards", "()I", "getDuplicateCards", "getSkippedCards", "getAddedNotes", "getAddedDecks", "getReasons", "()Ljava/util/Map;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 39 */    public final /* data */ class ImportResult {
                public static final int $stable = 8;
                private final int addedCards;
                private final int addedDecks;
                private final int addedNotes;
                private final int duplicateCards;
                private final Map<String, Integer> reasons;
                private final int skippedCards;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ ImportResult copy$default(ImportResult importResult, int i, int i2, int i3, int i4, int i5, Map map, int i6, Object obj) {
                    if ((i6 & 1) != 0) {
                        i = importResult.addedCards;
                    }
                    if ((i6 & 2) != 0) {
                        i2 = importResult.duplicateCards;
                    }
                    if ((i6 & 4) != 0) {
                        i3 = importResult.skippedCards;
                    }
                    if ((i6 & 8) != 0) {
                        i4 = importResult.addedNotes;
                    }
                    if ((i6 & 16) != 0) {
                        i5 = importResult.addedDecks;
                    }
                    if ((i6 & 32) != 0) {
                        map = importResult.reasons;
                    }
                    int i7 = i5;
                    Map map2 = map;
                    return importResult.copy(i, i2, i3, i4, i7, map2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final int getAddedCards() {
                    return this.addedCards;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getDuplicateCards() {
                    return this.duplicateCards;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getSkippedCards() {
                    return this.skippedCards;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getAddedNotes() {
                    return this.addedNotes;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final int getAddedDecks() {
                    return this.addedDecks;
                }

                public final Map<String, Integer> component6() {
                    return this.reasons;
                }

                public final ImportResult copy(int addedCards, int duplicateCards, int skippedCards, int addedNotes, int addedDecks, Map<String, Integer> reasons) {
                    Intrinsics.checkNotNullParameter(reasons, "reasons");
                    return new ImportResult(addedCards, duplicateCards, skippedCards, addedNotes, addedDecks, reasons);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ImportResult)) {
                        return false;
                    }
                    ImportResult importResult = (ImportResult) other;
                    return this.addedCards == importResult.addedCards && this.duplicateCards == importResult.duplicateCards && this.skippedCards == importResult.skippedCards && this.addedNotes == importResult.addedNotes && this.addedDecks == importResult.addedDecks && Intrinsics.areEqual(this.reasons, importResult.reasons);
                }

                public int hashCode() {
                    return (((((((((Integer.hashCode(this.addedCards) * 31) + Integer.hashCode(this.duplicateCards)) * 31) + Integer.hashCode(this.skippedCards)) * 31) + Integer.hashCode(this.addedNotes)) * 31) + Integer.hashCode(this.addedDecks)) * 31) + this.reasons.hashCode();
                }

                public String toString() {
                    return "ImportResult(addedCards=" + this.addedCards + ", duplicateCards=" + this.duplicateCards + ", skippedCards=" + this.skippedCards + ", addedNotes=" + this.addedNotes + ", addedDecks=" + this.addedDecks + ", reasons=" + this.reasons + ")";
                }

/* 40 */        public ImportResult(int addedCards, int duplicateCards, int skippedCards, int addedNotes, int addedDecks, Map<String, Integer> reasons) {
                    Intrinsics.checkNotNullParameter(reasons, "reasons");
/* 42 */            this.addedCards = addedCards;
                    this.duplicateCards = duplicateCards;
                    this.skippedCards = skippedCards;
/* 43 */            this.addedNotes = addedNotes;
                    this.addedDecks = addedDecks;
                    this.reasons = reasons;
                }

/* 41 */        public final int getAddedCards() {
/* 42 */            return this.addedCards;
                }

/* 41 */        public final int getDuplicateCards() {
/* 42 */            return this.duplicateCards;
                }

/* 41 */        public final int getSkippedCards() {
/* 42 */            return this.skippedCards;
                }

/* 42 */        public final int getAddedDecks() {
/* 43 */            return this.addedDecks;
                }

/* 42 */        public final int getAddedNotes() {
/* 43 */            return this.addedNotes;
                }

/* 42 */        public final Map<String, Integer> getReasons() {
/* 43 */            return this.reasons;
                }
            }

            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore", f = "MediaStore.kt", i = {0, 1, 1, 1, 1}, l = {154, 158}, m = "collectGarbageLocked$app_debug", n = {"operation", "operation", "entries\\1", "entry\\1", "$i$a$-use-MediaStore$collectGarbageLocked$3\\1\\155\\0"}, s = {"L$0", "L$0", "L$2", "L$3", "I$0"}, v = 1)
            final class MediaStore$collectGarbageLocked$1 extends ContinuationImpl {
                int I$0;
                Object L$0;
                Object L$1;
                Object L$2;
                Object L$3;
                Object L$4;
                int label;
                /* synthetic */ Object result;
                final /* synthetic */ MediaStore this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                MediaStore$collectGarbageLocked$1(MediaStore mediaStore, Continuation<? super MediaStore$collectGarbageLocked$1> continuation) {
                    super(continuation);
                    this.this$0 = mediaStore;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Object invokeSuspend(Object obj) {
                    this.result = obj;
                    this.label |= Integer.MIN_VALUE;
                    return this.this$0.collectGarbageLocked$app_debug(null, this);
                }
            }

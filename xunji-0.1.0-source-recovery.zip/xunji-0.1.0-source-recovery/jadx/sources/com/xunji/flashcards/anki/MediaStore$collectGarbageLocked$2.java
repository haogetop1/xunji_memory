            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$collectGarbageLocked$2", f = "MediaStore.kt", i = {}, l = {154}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 152 */   final class MediaStore$collectGarbageLocked$2 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                int label;
                final /* synthetic */ MediaStore this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                MediaStore$collectGarbageLocked$2(MediaStore mediaStore, Continuation<? super MediaStore$collectGarbageLocked$2> continuation) {
                    super(1, continuation);
                    this.this$0 = mediaStore;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Continuation<?> continuation) {
                    return new MediaStore$collectGarbageLocked$2(this.this$0, continuation);
                }

                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Continuation<? super Unit> continuation) {
                    return ((MediaStore$collectGarbageLocked$2) create(continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 153 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.label = 1;
/* 56 */                    if (this.this$0.db.ankiDao().deleteUnusedMediaMappings(this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore", f = "MediaStore.kt", i = {0}, l = {148}, m = "initializeLocked$app_debug", n = {"operation"}, s = {"L$0"}, v = 1)
            final class MediaStore$initializeLocked$1 extends ContinuationImpl {
                Object L$0;
                int label;
                /* synthetic */ Object result;
                final /* synthetic */ MediaStore this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                MediaStore$initializeLocked$1(MediaStore mediaStore, Continuation<? super MediaStore$initializeLocked$1> continuation) {
                    super(continuation);
                    this.this$0 = mediaStore;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Object invokeSuspend(Object obj) {
                    this.result = obj;
                    this.label |= Integer.MIN_VALUE;
                    return this.this$0.initializeLocked$app_debug(null, this);
                }
            }

            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore", f = "MediaStore.kt", i = {0, 0, 0, 1, 1, 1, 1}, l = {125, WorkQueueKt.MASK}, m = "promoteObjectLocked$app_debug", n = {"operation", "file", "media", "operation", "file", "media", "target"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3"}, v = 1)
            final class MediaStore$promoteObjectLocked$1 extends ContinuationImpl {
                Object L$0;
                Object L$1;
                Object L$2;
                Object L$3;
                int label;
                /* synthetic */ Object result;
                final /* synthetic */ MediaStore this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                MediaStore$promoteObjectLocked$1(MediaStore mediaStore, Continuation<? super MediaStore$promoteObjectLocked$1> continuation) {
                    super(continuation);
                    this.this$0 = mediaStore;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Object invokeSuspend(Object obj) {
                    this.result = obj;
                    this.label |= Integer.MIN_VALUE;
                    return this.this$0.promoteObjectLocked$app_debug(null, null, null, this);
                }
            }

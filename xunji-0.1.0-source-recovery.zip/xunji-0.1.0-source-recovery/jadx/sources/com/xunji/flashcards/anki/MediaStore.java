            package com.xunji.flashcards.anki;

            import androidx.autofill.HintConstants;
            import com.xunji.core.anki.AnkiStorageValidator;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.File;
            import java.io.FileDescriptor;
            import java.io.FileInputStream;
            import java.io.FileOutputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.nio.ByteBuffer;
            import java.nio.file.DirectoryStream;
            import java.nio.file.Files;
            import java.nio.file.Path;
            import java.security.MessageDigest;
            import java.security.NoSuchAlgorithmException;
            import java.text.Normalizer;
            import java.util.ArrayList;
            import java.util.Arrays;
            import java.util.Collection;
            import java.util.Comparator;
            import java.util.Iterator;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Locale;
            import java.util.Map;
            import java.util.Set;
            import java.util.concurrent.CancellationException;
            import kotlin.ExceptionsKt;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.UByte;
            import kotlin.Unit;
            import kotlin.collections.ArraysKt;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.IntIterator;
            import kotlin.comparisons.ComparisonsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.text.Charsets;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.JobKt;
            import kotlinx.coroutines.NonCancellable;
            import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0001\u0018\u0000 :2\u00020\u0001:\u0001:B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\u000e\u0010\u000e\u001a\u00020\u000fH\u0086@¢\u0006\u0002\u0010\u0010J\u001e\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0016H\u0086@¢\u0006\u0002\u0010\u0017J\u0016\u0010\u0018\u001a\u00020\u000f2\u0006\u0010\u0019\u001a\u00020\u0012H\u0086@¢\u0006\u0002\u0010\u001aJ\u001e\u0010\u001b\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010\u0019\u001a\u00020\u0012H\u0086@¢\u0006\u0002\u0010\u001eJ \u0010\u001f\u001a\u00020 2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010!\u001a\u00020\"H\u0080@¢\u0006\u0004\b#\u0010$J(\u0010%\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001d2\u0006\u0010&\u001a\u00020\u00032\u0006\u0010!\u001a\u00020\"H\u0080@¢\u0006\u0004\b'\u0010(J \u0010)\u001a\u0004\u0018\u00010 2\u0006\u0010\u0013\u001a\u00020\u00142\u0006\u0010*\u001a\u00020\u0014H\u0086@¢\u0006\u0002\u0010+J\u000e\u0010,\u001a\u00020\u000fH\u0086@¢\u0006\u0002\u0010\u0010J\u0018\u0010-\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001dH\u0080@¢\u0006\u0004\b.\u0010/J\u0018\u00100\u001a\u00020\u000f2\u0006\u0010\u001c\u001a\u00020\u001dH\u0080@¢\u0006\u0004\b1\u0010/J\u0010\u00102\u001a\u00020\u00032\u0006\u00103\u001a\u00020\u0014H\u0002J \u00104\u001a\u00020\u000f2\u0006\u0010!\u001a\u0002052\b\u00106\u001a\u0004\u0018\u00010\u0003H\u0082@¢\u0006\u0002\u00107J\u001e\u00108\u001a\u00020\u000f2\u0006\u0010&\u001a\u00020\u00032\u0006\u0010!\u001a\u00020\"H\u0082@¢\u0006\u0002\u00109R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006;"}, d2 = {"Lcom/xunji/flashcards/anki/MediaStore;", "", "root", "Ljava/io/File;", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "coordinator", "Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "<init>", "(Ljava/io/File;Lcom/xunji/flashcards/data/XunjiDatabase;Lcom/xunji/flashcards/anki/FileOperationCoordinator;)V", "objects", "staging", "initialized", "", "initialize", "", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "stage", "Lcom/xunji/flashcards/anki/StagedMedia;", "namespace", "", "source", "Lcom/xunji/flashcards/anki/PreparedPackage;", "(Ljava/lang/String;Lcom/xunji/flashcards/anki/PreparedPackage;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "promote", "staged", "(Lcom/xunji/flashcards/anki/StagedMedia;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "promoteLocked", "operation", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;Lcom/xunji/flashcards/anki/StagedMedia;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "openObjectLocked", "Ljava/io/InputStream;", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "openObjectLocked$app_debug", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;Lcom/xunji/flashcards/data/AnkiMediaEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "promoteObjectLocked", "file", "promoteObjectLocked$app_debug", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;Ljava/io/File;Lcom/xunji/flashcards/data/AnkiMediaEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "open", HintConstants.AUTOFILL_HINT_NAME, "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectGarbage", "initializeLocked", "initializeLocked$app_debug", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collectGarbageLocked", "collectGarbageLocked$app_debug", "objectFile", "hash", "copyVerified", "Lcom/xunji/flashcards/anki/AnkiMediaFile;", "target", "(Lcom/xunji/flashcards/anki/AnkiMediaFile;Ljava/io/File;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "verifyObject", "(Ljava/io/File;Lcom/xunji/flashcards/data/AnkiMediaEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 54 */    public final class MediaStore {
                private static final long MAX_MEDIA_BYTES = 67108864;
                private final FileOperationCoordinator coordinator;
                private final XunjiDatabase db;
                private boolean initialized;
                private final File objects;
                private final File root;
                private final File staging;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = 8;

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$stage$1, reason: invalid class name */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore", f = "MediaStore.kt", i = {0, 0, 0, 1, 1, 1, 1}, l = {66, 92}, m = "stage", n = {"namespace", "source", "staged", "namespace", "source", "staged", "error"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return MediaStore.this.stage(null, null, this);
                    }
                }

/* 55 */        public MediaStore(File root, XunjiDatabase db, FileOperationCoordinator coordinator) {
                    Intrinsics.checkNotNullParameter(root, "root");
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(coordinator, "coordinator");
                    this.root = root;
                    this.db = db;
                    this.coordinator = coordinator;
/* 57 */            this.objects = new File(this.root, "objects");
/* 58 */            this.staging = new File(this.root, "staging");
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$initialize$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$initialize$2", f = "MediaStore.kt", i = {0}, l = {LockFreeTaskQueueCore.CLOSED_SHIFT}, m = "invokeSuspend", n = {"$this$withLock"}, s = {"L$0"}, v = 1)
/* 58 */        static final class C04142 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Unit>, Object> {
                    private /* synthetic */ Object L$0;
                    int label;

                    C04142(Continuation<? super C04142> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04142 c04142 = MediaStore.this.new C04142(continuation);
                        c04142.L$0 = obj;
                        return c04142;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) {
                        return ((C04142) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$initialize$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: MediaStore.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$initialize$2$1", f = "MediaStore.kt", i = {}, l = {LockFreeTaskQueueCore.CLOSED_SHIFT}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 59 */            static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                        final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                        int label;
                        final /* synthetic */ MediaStore this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(MediaStore mediaStore, FileOperationCoordinator.Operation operation, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.this$0 = mediaStore;
                            this.$$this$withLock = operation;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new AnonymousClass1(this.this$0, this.$$this$withLock, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 60 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
                                    this.label = 1;
                                    if (this.this$0.initializeLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            return Unit.INSTANCE;
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 60 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                this.label = 1;
                                if (BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass1(MediaStore.this, $this$withLock, null), this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

/* 60 */        public final Object initialize(Continuation<? super Unit> continuation) throws Throwable {
/* 61 */            Object objWithLock = this.coordinator.withLock(new C04142(null), continuation);
                    return objWithLock == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithLock : Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 62 */        public final Object stage(String namespace, PreparedPackage source, Continuation<? super StagedMedia> continuation) {
                    AnonymousClass1 anonymousClass1;
                    Ref.ObjectRef staged;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    AnonymousClass1 anonymousClass2 = anonymousClass1;
                    Object $result = anonymousClass2.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass2.label) {
                        case 0:
/* 63 */                    ResultKt.throwOnFailure($result);
/* 64 */                    staged = new Ref.ObjectRef();
                            try {
/* 66 */                        FileOperationCoordinator fileOperationCoordinator = this.coordinator;
                                try {
                                    C04182 c04182 = new C04182(namespace, source, staged, null);
                                    anonymousClass2.L$0 = SpillingKt.nullOutSpilledVariable(namespace);
                                    anonymousClass2.L$1 = SpillingKt.nullOutSpilledVariable(source);
                                    anonymousClass2.L$2 = staged;
                                    anonymousClass2.label = 1;
                                    Object objWithLock = fileOperationCoordinator.withLock(c04182, anonymousClass2);
                                    return objWithLock == coroutine_suspended ? coroutine_suspended : objWithLock;
                                } catch (CancellationException e) {
                                    error = e;
                                    namespace = namespace;
                                    source = source;
                                }
                            } catch (CancellationException e2) {
                                error = e2;
                            }
                            break;
                        case 1:
                            Ref.ObjectRef staged2 = (Ref.ObjectRef) anonymousClass2.L$2;
                            source = (PreparedPackage) anonymousClass2.L$1;
                            namespace = (String) anonymousClass2.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
                                return $result;
                            } catch (CancellationException e3) {
/* 91 */                        error = e3;
                                staged = staged2;
                            }
                            break;
                        case 2:
                            CancellationException error = (CancellationException) anonymousClass2.L$3;
                            ResultKt.throwOnFailure($result);
/* 95 */                    throw error;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 92 */            CoroutineContext coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                    AnonymousClass3 anonymousClass3 = new AnonymousClass3(staged, error, null);
                    anonymousClass2.L$0 = SpillingKt.nullOutSpilledVariable(namespace);
                    anonymousClass2.L$1 = SpillingKt.nullOutSpilledVariable(source);
                    anonymousClass2.L$2 = SpillingKt.nullOutSpilledVariable(staged);
                    anonymousClass2.L$3 = error;
                    anonymousClass2.label = 2;
                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass3, anonymousClass2) == coroutine_suspended) {
/* 63 */                return coroutine_suspended;
                    }
/* 95 */            throw error;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$stage$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/StagedMedia;", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$stage$2", f = "MediaStore.kt", i = {0}, l = {67}, m = "invokeSuspend", n = {"$this$withLock"}, s = {"L$0"}, v = 1)
/* 64 */        static final class C04182 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super StagedMedia>, Object> {
                    final /* synthetic */ String $namespace;
                    final /* synthetic */ PreparedPackage $source;
                    final /* synthetic */ Ref.ObjectRef<StagedMedia> $staged;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04182(String str, PreparedPackage preparedPackage, Ref.ObjectRef<StagedMedia> objectRef, Continuation<? super C04182> continuation) {
                        super(2, continuation);
                        this.$namespace = str;
                        this.$source = preparedPackage;
                        this.$staged = objectRef;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04182 c04182 = MediaStore.this.new C04182(this.$namespace, this.$source, this.$staged, continuation);
                        c04182.L$0 = obj;
                        return c04182;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super StagedMedia> continuation) {
                        return ((C04182) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$stage$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: MediaStore.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/anki/StagedMedia;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$stage$2$1", f = "MediaStore.kt", i = {0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2}, l = {68, 80, 81}, m = "invokeSuspend", n = {"$this$withContext", "$this$withContext", "directory", "mappings", "$this$forEach\\2", "element\\2", "media\\3", "file\\3", "mime\\3", "$i$f$forEach\\2\\74", "$i$a$-forEach-MediaStore$stage$2$1$2\\3\\287\\0", "$this$withContext", "directory", "mappings", "$this$forEach\\2", "element\\2", "media\\3", "file\\3", "mime\\3", "$i$f$forEach\\2\\74", "$i$a$-forEach-MediaStore$stage$2$1$2\\3\\287\\0"}, s = {"L$0", "L$0", "L$1", "L$2", "L$3", "L$7", "L$8", "L$9", "L$10", "I$0", "I$1", "L$0", "L$1", "L$2", "L$3", "L$7", "L$8", "L$9", "L$10", "I$0", "I$1"}, v = 1)
/* 65 */            static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super StagedMedia>, Object> {
                        final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                        final /* synthetic */ String $namespace;
                        final /* synthetic */ PreparedPackage $source;
                        final /* synthetic */ Ref.ObjectRef<StagedMedia> $staged;
                        int I$0;
                        int I$1;
                        private /* synthetic */ Object L$0;
                        Object L$1;
                        Object L$10;
                        Object L$2;
                        Object L$3;
                        Object L$4;
                        Object L$5;
                        Object L$6;
                        Object L$7;
                        Object L$8;
                        Object L$9;
                        int label;
                        final /* synthetic */ MediaStore this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(MediaStore mediaStore, FileOperationCoordinator.Operation operation, String str, PreparedPackage preparedPackage, Ref.ObjectRef<StagedMedia> objectRef, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.this$0 = mediaStore;
                            this.$$this$withLock = operation;
                            this.$namespace = str;
                            this.$source = preparedPackage;
                            this.$staged = objectRef;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, this.$$this$withLock, this.$namespace, this.$source, this.$staged, continuation);
                            anonymousClass1.L$0 = obj;
                            return anonymousClass1;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super StagedMedia> continuation) {
                            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:26:0x010b A[Catch: Exception -> 0x024d, TryCatch #3 {Exception -> 0x024d, blocks: (B:24:0x0105, B:26:0x010b, B:29:0x0126), top: B:76:0x0105 }] */
                        /* JADX WARN: Code duplicated, block: B:28:0x0124  */
                        /* JADX WARN: Type inference failed for: r0v13, types: [T, com.xunji.flashcards.anki.StagedMedia, java.lang.Object] */
                        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:28:0x0124 -> B:49:0x022a). Please report as a decompilation issue!!! */
                        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:45:0x01d4 -> B:46:0x01e4). Please report as a decompilation issue!!! */
                        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                            */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 66 */                public final java.lang.Object invokeSuspend(java.lang.Object r23) {
                            /*
                                Method dump skipped, instruction units count: 652
                                To view this dump change 'Code comments level' option to 'DEBUG'
                            */
                            throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.anki.MediaStore.C04182.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 65 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                this.label = 1;
/* 67 */                        Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass1(MediaStore.this, $this$withLock, this.$namespace, this.$source, this.$staged, null), this);
                                if (objWithContext == coroutine_suspended) {
/* 66 */                            return coroutine_suspended;
                                }
/* 89 */                        return objWithContext;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$stage$3, reason: invalid class name */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$stage$3", f = "MediaStore.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 90 */        static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ CancellationException $error;
                    final /* synthetic */ Ref.ObjectRef<StagedMedia> $staged;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass3(Ref.ObjectRef<StagedMedia> objectRef, CancellationException cancellationException, Continuation<? super AnonymousClass3> continuation) {
                        super(2, continuation);
                        this.$staged = objectRef;
                        this.$error = cancellationException;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass3(this.$staged, this.$error, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 91 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 93 */                            StagedMedia stagedMedia = this.$staged.element;
                                    if (stagedMedia == null) {
                                        return null;
                                    }
                                    stagedMedia.close();
                                    return Unit.INSTANCE;
                                } catch (Exception cleanup) {
                                    ExceptionsKt.addSuppressed(this.$error, cleanup);
                                    return Unit.INSTANCE;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$promote$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$promote$2", f = "MediaStore.kt", i = {0}, l = {99}, m = "invokeSuspend", n = {"$this$withLock"}, s = {"L$0"}, v = 1)
/* 97 */        static final class C04162 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Unit>, Object> {
                    final /* synthetic */ StagedMedia $staged;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04162(StagedMedia stagedMedia, Continuation<? super C04162> continuation) {
                        super(2, continuation);
                        this.$staged = stagedMedia;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04162 c04162 = MediaStore.this.new C04162(this.$staged, continuation);
                        c04162.L$0 = obj;
                        return c04162;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) {
                        return ((C04162) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 98 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                this.label = 1;
                                if (MediaStore.this.promoteLocked($this$withLock, this.$staged, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

/* 98 */        public final Object promote(StagedMedia staged, Continuation<? super Unit> continuation) throws Throwable {
/* 99 */            Object objWithLock = this.coordinator.withLock(new C04162(staged, null), continuation);
                    return objWithLock == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithLock : Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$promoteLocked$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$promoteLocked$2", f = "MediaStore.kt", i = {0, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2}, l = {103, 107, 110}, m = "invokeSuspend", n = {"$this$withContext", "$this$withContext", "$this$forEach\\3", "element\\3", "media\\4", "target\\4", "$i$f$forEach\\3\\104", "$i$a$-forEach-MediaStore$promoteLocked$2$2\\4\\294\\0", "$this$withContext", "$this$forEach\\3", "element\\3", "media\\4", "target\\4", "source\\4", "$i$f$forEach\\3\\104", "$i$a$-forEach-MediaStore$promoteLocked$2$2\\4\\294\\0"}, s = {"L$0", "L$0", "L$1", "L$5", "L$6", "L$7", "I$0", "I$1", "L$0", "L$1", "L$5", "L$6", "L$7", "L$8", "I$0", "I$1"}, v = 1)
/* 100 */       static final class C04172 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ FileOperationCoordinator.Operation $operation;
                    final /* synthetic */ StagedMedia $staged;
                    int I$0;
                    int I$1;
                    private /* synthetic */ Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    int label;
                    final /* synthetic */ MediaStore this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04172(FileOperationCoordinator.Operation operation, MediaStore mediaStore, StagedMedia stagedMedia, Continuation<? super C04172> continuation) {
                        super(2, continuation);
                        this.$operation = operation;
                        this.this$0 = mediaStore;
                        this.$staged = stagedMedia;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04172 c04172 = new C04172(this.$operation, this.this$0, this.$staged, continuation);
                        c04172.L$0 = obj;
                        return c04172;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04172) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:21:0x00ef  */
                    /* JADX WARN: Code duplicated, block: B:23:0x010c  */
                    /* JADX WARN: Code duplicated, block: B:25:0x013c A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:26:0x013d  */
                    /* JADX WARN: Code duplicated, block: B:28:0x014a  */
                    /* JADX WARN: Code duplicated, block: B:30:0x0182 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:31:0x0183  */
                    /* JADX WARN: Code duplicated, block: B:34:0x018b  */
                    /* JADX WARN: Code duplicated, block: B:36:0x019c  */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:31:0x0183 -> B:32:0x0185). Please report as a decompilation issue!!! */
                    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                        */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 101 */           public final java.lang.Object invokeSuspend(java.lang.Object r18) {
                        /*
                            Method dump skipped, instruction units count: 436
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.anki.MediaStore.C04172.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

/* 101 */       public final Object promoteLocked(FileOperationCoordinator.Operation operation, StagedMedia staged, Continuation<? super Unit> continuation) {
/* 102 */           Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new C04172(operation, this, staged, null), continuation);
                    return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
                }

/* 116 */       public final Object openObjectLocked$app_debug(FileOperationCoordinator.Operation operation, AnkiMediaEntity media, Continuation<? super InputStream> continuation) throws IOException {
/* 117 */           operation.checkOwner$app_debug(this.coordinator);
/* 118 */           File file = objectFile(media.getSha256());
/* 119 */           if (!file.isFile() || file.length() != media.getSize()) {
/* 119 */               throw new IOException("Stored media object is missing or has changed");
                    }
/* 120 */           return new FileInputStream(file);
                }

                /* JADX WARN: Code duplicated, block: B:19:0x0080  */
                /* JADX WARN: Code duplicated, block: B:21:0x00a1 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:22:0x00a2  */
                /* JADX WARN: Code duplicated, block: B:25:0x00a6  */
                /* JADX WARN: Code duplicated, block: B:27:0x00ac  */
                /* JADX WARN: Code duplicated, block: B:29:0x00af  */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 122 */       public final Object promoteObjectLocked$app_debug(FileOperationCoordinator.Operation operation, File file, AnkiMediaEntity media, Continuation<? super Unit> continuation) throws Throwable {
                    MediaStore$promoteObjectLocked$1 mediaStore$promoteObjectLocked$1;
                    File target;
                    if (continuation instanceof MediaStore$promoteObjectLocked$1) {
                        mediaStore$promoteObjectLocked$1 = (MediaStore$promoteObjectLocked$1) continuation;
                        if ((mediaStore$promoteObjectLocked$1.label & Integer.MIN_VALUE) != 0) {
                            mediaStore$promoteObjectLocked$1.label -= Integer.MIN_VALUE;
                        } else {
                            mediaStore$promoteObjectLocked$1 = new MediaStore$promoteObjectLocked$1(this, continuation);
                        }
                    } else {
                        mediaStore$promoteObjectLocked$1 = new MediaStore$promoteObjectLocked$1(this, continuation);
                    }
                    Object $result = mediaStore$promoteObjectLocked$1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (mediaStore$promoteObjectLocked$1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 124 */                   operation.checkOwner$app_debug(this.coordinator);
/* 125 */                   mediaStore$promoteObjectLocked$1.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                            mediaStore$promoteObjectLocked$1.L$1 = file;
                            mediaStore$promoteObjectLocked$1.L$2 = media;
                            mediaStore$promoteObjectLocked$1.label = 1;
                            if (verifyObject(file, media, mediaStore$promoteObjectLocked$1) == coroutine_suspended) {
/* 123 */                       return coroutine_suspended;
                            }
/* 126 */                   target = objectFile(media.getSha256());
/* 127 */                   if (target.exists()) {
/* 128 */                       if (file.renameTo(target)) {
/* 128 */                           throw new IOException("Cannot promote restored media");
                                }
/* 129 */                       return Unit.INSTANCE;
                            }
                            mediaStore$promoteObjectLocked$1.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                            mediaStore$promoteObjectLocked$1.L$1 = SpillingKt.nullOutSpilledVariable(file);
                            mediaStore$promoteObjectLocked$1.L$2 = SpillingKt.nullOutSpilledVariable(media);
                            mediaStore$promoteObjectLocked$1.L$3 = SpillingKt.nullOutSpilledVariable(target);
                            mediaStore$promoteObjectLocked$1.label = 2;
                            if (verifyObject(target, media, mediaStore$promoteObjectLocked$1) == coroutine_suspended) {
/* 123 */                       return coroutine_suspended;
                            }
/* 129 */                   return Unit.INSTANCE;
                        case 1:
                            media = (AnkiMediaEntity) mediaStore$promoteObjectLocked$1.L$2;
                            file = (File) mediaStore$promoteObjectLocked$1.L$1;
                            operation = (FileOperationCoordinator.Operation) mediaStore$promoteObjectLocked$1.L$0;
                            ResultKt.throwOnFailure($result);
/* 126 */                   target = objectFile(media.getSha256());
/* 127 */                   if (target.exists()) {
/* 128 */                       if (file.renameTo(target)) {
/* 128 */                           throw new IOException("Cannot promote restored media");
                                }
/* 129 */                       return Unit.INSTANCE;
                            }
                            mediaStore$promoteObjectLocked$1.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                            mediaStore$promoteObjectLocked$1.L$1 = SpillingKt.nullOutSpilledVariable(file);
                            mediaStore$promoteObjectLocked$1.L$2 = SpillingKt.nullOutSpilledVariable(media);
                            mediaStore$promoteObjectLocked$1.L$3 = SpillingKt.nullOutSpilledVariable(target);
                            mediaStore$promoteObjectLocked$1.label = 2;
                            if (verifyObject(target, media, mediaStore$promoteObjectLocked$1) == coroutine_suspended) {
/* 123 */                       return coroutine_suspended;
                            }
/* 129 */                   return Unit.INSTANCE;
                        case 2:
                            ResultKt.throwOnFailure($result);
/* 129 */                   return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$open$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Ljava/io/FileInputStream;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$open$2", f = "MediaStore.kt", i = {}, l = {133}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 130 */       static final class C04152 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super FileInputStream>, Object> {
                    final /* synthetic */ String $name;
                    final /* synthetic */ String $namespace;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04152(String str, String str2, Continuation<? super C04152> continuation) {
                        super(2, continuation);
                        this.$namespace = str;
                        this.$name = str2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return MediaStore.this.new C04152(this.$namespace, this.$name, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super FileInputStream> continuation) {
                        return ((C04152) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 131 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objMedia;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 56 */                        objMedia = MediaStore.this.db.ankiDao().media(this.$namespace, this.$name, this);
                                if (objMedia == coroutine_suspended) {
/* 132 */                           return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                objMedia = $result;
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 133 */               AnkiMediaEntity media = (AnkiMediaEntity) objMedia;
                        if (media == null) {
                            return null;
                        }
/* 56 */                File file = MediaStore.this.objectFile(media.getSha256());
/* 135 */               if (!file.isFile() || file.length() != media.getSize()) {
/* 135 */                   throw new IOException("Stored media object is missing or has changed");
                        }
/* 136 */               return new FileInputStream(file);
                    }
                }

/* 131 */       public final Object open(String namespace, String name, Continuation<? super InputStream> continuation) {
/* 132 */           return BuildersKt.withContext(Dispatchers.getIO(), new C04152(namespace, name, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$collectGarbage$2, reason: invalid class name */
                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$collectGarbage$2", f = "MediaStore.kt", i = {0}, l = {139}, m = "invokeSuspend", n = {"$this$withLock"}, s = {"L$0"}, v = 1)
/* 136 */       static final class AnonymousClass2 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Unit>, Object> {
                    private /* synthetic */ Object L$0;
                    int label;

                    AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass2 anonymousClass2 = MediaStore.this.new AnonymousClass2(continuation);
                        anonymousClass2.L$0 = obj;
                        return anonymousClass2;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass2) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.anki.MediaStore$collectGarbage$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: MediaStore.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.anki.MediaStore$collectGarbage$2$1", f = "MediaStore.kt", i = {}, l = {139, 139}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 137 */           static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                        final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                        int label;
                        final /* synthetic */ MediaStore this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(MediaStore mediaStore, FileOperationCoordinator.Operation operation, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.this$0 = mediaStore;
                            this.$$this$withLock = operation;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new AnonymousClass1(this.this$0, this.$$this$withLock, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:13:0x003d A[RETURN] */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 138 */               public final Object invokeSuspend(Object $result) throws Throwable {
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
                                    this.label = 1;
                                    if (this.this$0.initializeLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    this.label = 2;
                                    if (this.this$0.collectGarbageLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    this.label = 2;
                                    if (this.this$0.collectGarbageLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    return Unit.INSTANCE;
                                case 2:
                                    ResultKt.throwOnFailure($result);
                                    return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 138 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                this.label = 1;
                                if (BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass1(MediaStore.this, $this$withLock, null), this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

/* 138 */       public final Object collectGarbage(Continuation<? super Unit> continuation) throws Throwable {
/* 139 */           Object objWithLock = this.coordinator.withLock(new AnonymousClass2(null), continuation);
                    return objWithLock == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithLock : Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 140 */       public final Object initializeLocked$app_debug(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) throws Throwable {
                    MediaStore$initializeLocked$1 mediaStore$initializeLocked$1;
                    if (continuation instanceof MediaStore$initializeLocked$1) {
                        mediaStore$initializeLocked$1 = (MediaStore$initializeLocked$1) continuation;
                        if ((mediaStore$initializeLocked$1.label & Integer.MIN_VALUE) != 0) {
                            mediaStore$initializeLocked$1.label -= Integer.MIN_VALUE;
                        } else {
                            mediaStore$initializeLocked$1 = new MediaStore$initializeLocked$1(this, continuation);
                        }
                    } else {
                        mediaStore$initializeLocked$1 = new MediaStore$initializeLocked$1(this, continuation);
                    }
                    Object $result = mediaStore$initializeLocked$1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (mediaStore$initializeLocked$1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 142 */                   operation.checkOwner$app_debug(this.coordinator);
/* 143 */                   if (this.initialized) {
                                return Unit.INSTANCE;
                            }
/* 144 */                   if ((!this.objects.isDirectory() && !this.objects.mkdirs()) || (!this.staging.isDirectory() && !this.staging.mkdirs())) {
                                throw new IOException("Cannot create media storage");
                            }
/* 145 */                   DirectoryStream<Path> directoryStreamNewDirectoryStream = Files.newDirectoryStream(this.staging.toPath());
                            try {
/* 146 */                       Iterator<Path> it = directoryStreamNewDirectoryStream.iterator();
                                Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                                while (it.hasNext()) {
                                    Path next = it.next();
                                    JobKt.ensureActive(mediaStore$initializeLocked$1.getContext());
                                    File file = next.toFile();
                                    Intrinsics.checkNotNullExpressionValue(file, "toFile(...)");
                                    MediaStoreKt.deletePrivateTree(file);
                                }
                                Unit unit = Unit.INSTANCE;
/* 145 */                       CloseableKt.closeFinally(directoryStreamNewDirectoryStream, null);
/* 148 */                       mediaStore$initializeLocked$1.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                                mediaStore$initializeLocked$1.label = 1;
                                if (collectGarbageLocked$app_debug(operation, mediaStore$initializeLocked$1) == coroutine_suspended) {
/* 141 */                           return coroutine_suspended;
                                }
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    CloseableKt.closeFinally(directoryStreamNewDirectoryStream, th);
                                    throw th2;
                                }
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 149 */           this.initialized = true;
/* 150 */           return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:27:0x00b3 A[Catch: all -> 0x0125, TRY_LEAVE, TryCatch #1 {all -> 0x0125, blocks: (B:25:0x00ad, B:27:0x00b3, B:38:0x011d), top: B:51:0x00ad }] */
                /* JADX WARN: Code duplicated, block: B:29:0x00eb A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:30:0x00ec  */
                /* JADX WARN: Code duplicated, block: B:33:0x0100 A[Catch: all -> 0x0115, TRY_LEAVE, TryCatch #2 {all -> 0x0115, blocks: (B:31:0x00f8, B:33:0x0100), top: B:53:0x00f8 }] */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:30:0x00ec -> B:53:0x00f8). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
/* 151 */       public final java.lang.Object collectGarbageLocked$app_debug(com.xunji.flashcards.anki.FileOperationCoordinator.Operation r18, kotlin.coroutines.Continuation<? super kotlin.Unit> r19) {
                    /*
                        Method dump skipped, instruction units count: 320
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.anki.MediaStore.collectGarbageLocked$app_debug(com.xunji.flashcards.anki.FileOperationCoordinator$Operation, kotlin.coroutines.Continuation):java.lang.Object");
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 163 */       public final File objectFile(String hash) {
/* 164 */           if (new Regex("[0-9a-f]{64}").matches(hash)) {
/* 165 */               return new File(this.objects, hash);
                    }
                    throw new IllegalArgumentException("Invalid media object digest".toString());
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 168 */       public final Object copyVerified(AnkiMediaFile media, File target, Continuation<? super Unit> continuation) throws NoSuchAlgorithmException, IOException {
                    Throwable th;
                    FileDescriptor fd;
/* 169 */           MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
                    MessageDigest sha256 = MessageDigest.getInstance("SHA-256");
/* 170 */           long size = 0;
/* 171 */           FileInputStream fileInputStream = new FileInputStream(media.getFile());
                    try {
                        FileInputStream fileInputStream2 = fileInputStream;
/* 171 */               FileOutputStream fileOutputStream = target != null ? new FileOutputStream(target) : null;
                        try {
                            FileOutputStream fileOutputStream2 = fileOutputStream;
/* 172 */                   byte[] bArr = new byte[65536];
                            while (true) {
/* 174 */                       JobKt.ensureActive(continuation.getContext());
/* 175 */                       int i = fileInputStream2.read(bArr);
                                if (i < 0) {
/* 180 */                           if (fileOutputStream2 != null && (fd = fileOutputStream2.getFD()) != null) {
                                        fd.sync();
                                        Unit unit = Unit.INSTANCE;
                                    }
/* 171 */                           CloseableKt.closeFinally(fileOutputStream, null);
/* 171 */                           CloseableKt.closeFinally(fileInputStream, null);
                                    if (size == media.getSize()) {
                                        byte[] bArrDigest = sha1.digest();
                                        Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
                                        if (Intrinsics.areEqual(BoundedApkgKt.hex(bArrDigest), media.getSha1())) {
                                            byte[] bArrDigest2 = sha256.digest();
                                            Intrinsics.checkNotNullExpressionValue(bArrDigest2, "digest(...)");
                                            if (Intrinsics.areEqual(BoundedApkgKt.hex(bArrDigest2), media.getSha256())) {
/* 183 */                                       return Unit.INSTANCE;
                                            }
                                        }
                                    }
/* 182 */                           throw new IOException("Staged media size/digest differs");
                                }
                                if (i != 0) {
/* 176 */                           size += (long) i;
                                    if (size > media.getSize() || size > MAX_MEDIA_BYTES) {
/* 177 */                               throw new IOException("Staged media exceeds declared size");
                                    }
/* 178 */                           sha1.update(bArr, 0, i);
/* 178 */                           sha256.update(bArr, 0, i);
                                    if (fileOutputStream2 != null) {
/* 178 */                               fileOutputStream2.write(bArr, 0, i);
                                    }
                                }
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    CloseableKt.closeFinally(fileInputStream, th);
                                    throw th2;
                                }
                            }
                        } catch (Throwable th3) {
                            try {
                                throw th3;
                            } catch (Throwable th4) {
                                try {
                                    CloseableKt.closeFinally(fileOutputStream, th3);
                                    throw th4;
                                } catch (Throwable th5) {
                                    th = th5;
                                }
                            }
                        }
                    } catch (Throwable th6) {
                        th = th6;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 185 */       public final Object verifyObject(File file, AnkiMediaEntity media, Continuation<? super Unit> continuation) throws NoSuchAlgorithmException, IOException {
/* 186 */           if (!file.isFile() || file.length() != media.getSize()) {
/* 186 */               throw new IOException("Immutable media object is missing or has changed");
                    }
/* 187 */           MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 188 */           FileInputStream fileInputStream = new FileInputStream(file);
                    try {
                        FileInputStream fileInputStream2 = fileInputStream;
/* 189 */               byte[] bArr = new byte[65536];
                        while (true) {
/* 190 */                   JobKt.ensureActive(continuation.getContext());
                            int i = fileInputStream2.read(bArr);
                            if (i < 0) {
                                break;
                            }
                            if (i > 0) {
                                digest.update(bArr, 0, i);
                            }
                        }
                        Unit unit = Unit.INSTANCE;
/* 188 */               CloseableKt.closeFinally(fileInputStream, null);
/* 192 */               byte[] bArrDigest = digest.digest();
                        Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
                        if (!Intrinsics.areEqual(BoundedApkgKt.hex(bArrDigest), media.getSha256())) {
/* 192 */                   throw new IOException("Immutable media object digest differs");
                        }
/* 193 */               return Unit.INSTANCE;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(fileInputStream, th);
                            throw th2;
                        }
                    }
                }

                /* JADX INFO: compiled from: MediaStore.kt */
                @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\n\b\u0086\u0003\u0018\u00002\u00020\u0001:\u0001\u0017B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001a\u0010\u0006\u001a\u00020\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\n0\tJ\u0014\u0010\u0006\u001a\u00020\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\f0\u000bJ\u000e\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\fJ(\u0010\u0010\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u00072\u0006\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0007H\u0002J\u0012\u0010\u0015\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0012\u001a\u00020\u0007H\u0002J\u0010\u0010\u0016\u001a\u0004\u0018\u00010\u00072\u0006\u0010\b\u001a\u00020\nR\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lcom/xunji/flashcards/anki/MediaStore$Companion;", "", "<init>", "()V", "MAX_MEDIA_BYTES", "", "namespaceFor", "", "media", "", "Lcom/xunji/flashcards/anki/AnkiMediaFile;", "", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "validateMediaRow", "", "entry", "validateMediaRowText", "namespace", HintConstants.AUTOFILL_HINT_NAME, "sha256", "mime", "expectedMime", "mimeFor", "NamespaceDigest", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 193 */       public static final class Companion {
/* 194 */           private Companion() {
                    }

                    /* JADX WARN: Code duplicated, block: B:22:0x007f  */
/* 198 */           public final String namespaceFor(Map<String, AnkiMediaFile> media) throws IOException {
                        Map<String, AnkiMediaFile> map;
                        boolean z;
                        Intrinsics.checkNotNullParameter(media, "media");
/* 199 */               if (!(media.size() <= 100000)) {
                            throw new IllegalArgumentException("Media manifest has too many entries".toString());
                        }
/* 200 */               Map<String, AnkiMediaFile> map2 = media;
/* 287 */               Collection arrayList = new ArrayList();
                        for (Map.Entry<String, AnkiMediaFile> entry : map2.entrySet()) {
                            String key = entry.getKey();
                            AnkiMediaFile value = entry.getValue();
/* 201 */                   if (Intrinsics.areEqual(key, value.getOriginalName())) {
                                long size = value.getSize();
                                if (0 <= size && size < 67108865) {
                                    map = map2;
                                    z = new Regex("[0-9a-f]{64}").matches(value.getSha256());
                                } else {
                                    map = map2;
                                }
                            } else {
                                map = map2;
                            }
                            if (!z) {
                                throw new IllegalArgumentException("Invalid media manifest entry".toString());
                            }
/* 202 */                   String strMimeFor = MediaStore.INSTANCE.mimeFor(value);
/* 202 */                   AnkiMediaEntity ankiMediaEntity = strMimeFor != null ? new AnkiMediaEntity("", key, value.getSha256(), value.getSize(), strMimeFor) : null;
/* 295 */                   if (ankiMediaEntity != null) {
/* 295 */                       arrayList.add(ankiMediaEntity);
                            }
                            map2 = map;
                        }
/* 200 */               return namespaceFor((List<AnkiMediaEntity>) arrayList);
                    }

/* 206 */           public final String namespaceFor(List<AnkiMediaEntity> media) {
                        Intrinsics.checkNotNullParameter(media, "media");
/* 207 */               if (!(media.size() <= 100000)) {
                            throw new IllegalArgumentException("Media manifest has too many entries".toString());
                        }
/* 208 */               Set names = new LinkedHashSet();
                        for (AnkiMediaEntity ankiMediaEntity : media) {
/* 210 */                   MediaStore.INSTANCE.validateMediaRow(ankiMediaEntity);
/* 211 */                   String strNormalize = Normalizer.normalize(ankiMediaEntity.getOriginalName(), Normalizer.Form.NFC);
                            Intrinsics.checkNotNullExpressionValue(strNormalize, "normalize(...)");
                            if (!names.add(strNormalize)) {
                                throw new IllegalArgumentException("Ambiguous duplicate media filename".toString());
                            }
                        }
/* 213 */               NamespaceDigest accumulator = new NamespaceDigest();
/* 303 */               Iterator it = CollectionsKt.sortedWith(media, new Comparator() { // from class: com.xunji.flashcards.anki.MediaStore$Companion$namespaceFor$$inlined$sortedBy$1
                            /* JADX WARN: Multi-variable type inference failed */
                            @Override // java.util.Comparator
/* 101 */                   public final int compare(T t, T t2) {
/* 102 */                       return ComparisonsKt.compareValues(((AnkiMediaEntity) t).getOriginalName(), ((AnkiMediaEntity) t2).getOriginalName());
                            }
                        }).iterator();
                        while (it.hasNext()) {
/* 214 */                   accumulator.add((AnkiMediaEntity) it.next());
                        }
/* 215 */               return accumulator.finish();
                    }

                    /* JADX WARN: Code duplicated, block: B:14:0x005d  */
/* 217 */           public final void validateMediaRow(AnkiMediaEntity entry) {
                        boolean z;
                        Intrinsics.checkNotNullParameter(entry, "entry");
/* 218 */               validateMediaRowText(entry.getNamespace(), entry.getOriginalName(), entry.getSha256(), entry.getMime());
/* 219 */               BoundedApkgKt.safeMediaName(entry.getOriginalName());
/* 220 */               long size = entry.getSize();
                        if (0 <= size && size < 67108865) {
                            z = new Regex("[0-9a-f]{64}").matches(entry.getSha256()) && Intrinsics.areEqual(entry.getMime(), expectedMime(entry.getOriginalName()));
                        }
                        if (!z) {
                            throw new IllegalArgumentException("Invalid retained media entry".toString());
                        }
                    }

                    /* JADX INFO: compiled from: MediaStore.kt */
                    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u000b\u001a\u00020\f2\u0006\u0010\r\u001a\u00020\u000eJ\u0006\u0010\u000f\u001a\u00020\bR\u0016\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u0004\u0018\u00010\bX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\nX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lcom/xunji/flashcards/anki/MediaStore$Companion$NamespaceDigest;", "", "<init>", "()V", "digest", "Ljava/security/MessageDigest;", "kotlin.jvm.PlatformType", "previous", "", "count", "", "add", "", "entry", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "finish", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 226 */           public static final class NamespaceDigest {
                        public static final int $stable = 8;
                        private int count;
                        private final MessageDigest digest = MessageDigest.getInstance("SHA-256");
                        private String previous;

                        /* JADX WARN: Code duplicated, block: B:9:0x002b  */
/* 227 */               public final void add(AnkiMediaEntity entry) {
                            Intrinsics.checkNotNullParameter(entry, "entry");
/* 228 */                   MediaStore.INSTANCE.validateMediaRow(entry);
                            boolean z = true;
/* 229 */                   this.count++;
                            if (this.count > 100000) {
                                z = false;
                            } else if (this.previous != null) {
                                String str = this.previous;
                                Intrinsics.checkNotNull(str);
                                if (str.compareTo(entry.getOriginalName()) >= 0) {
                                    z = false;
                                }
                            }
                            if (!z) {
                                throw new IllegalArgumentException("Invalid media namespace order/count".toString());
                            }
/* 230 */                   this.previous = entry.getOriginalName();
/* 231 */                   byte[] text = entry.getOriginalName().getBytes(Charsets.UTF_8);
                            Intrinsics.checkNotNullExpressionValue(text, "getBytes(...)");
/* 232 */                   this.digest.update(ByteBuffer.allocate(4).putInt(text.length).array());
                            this.digest.update(text);
/* 233 */                   this.digest.update(ByteBuffer.allocate(8).putLong(entry.getSize()).array());
                            MessageDigest messageDigest = this.digest;
                            byte[] bytes = entry.getSha256().getBytes(Charsets.US_ASCII);
                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                            messageDigest.update(bytes);
/* 234 */                   byte[] mime = entry.getMime().getBytes(Charsets.US_ASCII);
                            Intrinsics.checkNotNullExpressionValue(mime, "getBytes(...)");
/* 235 */                   this.digest.update(ByteBuffer.allocate(4).putInt(mime.length).array());
                            this.digest.update(mime);
                        }

/* 236 */               public final String finish() {
/* 237 */                   byte[] bArrDigest = this.digest.digest();
                            Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
                            return BoundedApkgKt.hex(bArrDigest);
                        }
                    }

/* 239 */           private final void validateMediaRowText(String namespace, String name, String sha256, String mime) {
                        int remaining = 524288;
/* 242 */               String[] strArr = new String[4];
                        String strRepeat = namespace;
                        boolean z = true;
                        if (strRepeat.length() == 0) {
/* 242 */                   strRepeat = StringsKt.repeat("0", 64);
                        }
                        strArr[0] = strRepeat;
                        strArr[1] = name;
                        strArr[2] = sha256;
                        strArr[3] = mime;
                        for (String str : CollectionsKt.listOf((Object[]) strArr)) {
/* 243 */                   if (!(str.length() <= remaining)) {
                                throw new IllegalArgumentException("Stored media text exceeds 512 KiB".toString());
                            }
/* 244 */                   int iUtf8Bytes = AnkiStorageValidator.INSTANCE.utf8Bytes(str);
/* 245 */                   if (!(iUtf8Bytes <= remaining)) {
                                throw new IllegalArgumentException("Stored media text exceeds 512 KiB".toString());
                            }
/* 246 */                   remaining -= iUtf8Bytes;
                        }
/* 248 */               if (!(namespace.length() == 0)) {
                            if (!new Regex("[0-9a-f]{64}").matches(namespace)) {
                                z = false;
                            }
                        }
                        if (!z) {
                            throw new IllegalArgumentException("Invalid media namespace".toString());
                        }
                    }

                    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
                    /* JADX WARN: Code duplicated, block: B:51:0x00b1 A[RETURN, SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:56:0x00c1 A[ORIG_RETURN, RETURN] */
/* 249 */           private final String expectedMime(String name) {
/* 250 */               String strSubstringAfterLast = StringsKt.substringAfterLast(name, '.', "");
                        Locale ROOT = Locale.ROOT;
                        Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                        String lowerCase = strSubstringAfterLast.toLowerCase(ROOT);
                        Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                        switch (lowerCase) {
                            case "gif":
/* 251 */                       return "image/gif";
                            case "jpg":
/* 251 */                       return "image/jpeg";
                            case "m4a":
/* 252 */                       return "audio/mp4";
                            case "mp3":
/* 252 */                       return "audio/mpeg";
                            case "ogg":
/* 252 */                       return "audio/ogg";
                            case "otf":
/* 253 */                       return "font/otf";
                            case "png":
/* 251 */                       return "image/png";
                            case "ttf":
/* 253 */                       return "font/ttf";
                            case "wav":
/* 252 */                       return "audio/wav";
                            case "jpeg":
/* 251 */                       return "image/jpeg";
                            case "webp":
/* 251 */                       return "image/webp";
                            case "woff":
/* 253 */                       return "font/woff";
                            case "woff2":
/* 253 */                       return "font/woff2";
                            default:
/* 254 */                       return null;
                        }
                    }

                    /* JADX WARN: Code duplicated, block: B:76:0x016e  */
                    /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
/* 257 */           public final String mimeFor(AnkiMediaFile media) throws IOException {
                        Intrinsics.checkNotNullParameter(media, "media");
/* 258 */               String strSubstringAfterLast = StringsKt.substringAfterLast(media.getOriginalName(), '.', "");
                        Locale ROOT = Locale.ROOT;
                        Intrinsics.checkNotNullExpressionValue(ROOT, "ROOT");
                        String extension = strSubstringAfterLast.toLowerCase(ROOT);
                        Intrinsics.checkNotNullExpressionValue(extension, "toLowerCase(...)");
/* 259 */               String expected = expectedMime(media.getOriginalName());
                        if (expected == null) {
                            return null;
                        }
/* 260 */               validateMediaRowText("", media.getOriginalName(), media.getSha256(), expected);
/* 261 */               BoundedApkgKt.safeMediaName(media.getOriginalName());
/* 262 */               FileInputStream fileInputStream = new FileInputStream(media.getFile());
                        try {
/* 262 */                   byte[] bArr = new byte[16];
                            boolean valid = false;
/* 262 */                   byte[] header = Arrays.copyOf(bArr, Math.max(0, fileInputStream.read(bArr)));
                            Intrinsics.checkNotNullExpressionValue(header, "copyOf(...)");
                            CloseableKt.closeFinally(fileInputStream, null);
                            switch (extension.hashCode()) {
                                case 102340:
/* 265 */                           if (extension.equals("gif") && (mimeFor$text(header, 0, "GIF87a") || mimeFor$text(header, 0, "GIF89a"))) {
                                        valid = true;
                                    }
                                    break;
                                case 105441:
/* 265 */                           if (extension.equals("jpg")) {
/* 267 */                               valid = mimeFor$starts(header, 255, 216, 255);
                                    }
                                    break;
                                case 106458:
/* 265 */                           if (extension.equals("m4a")) {
/* 273 */                               valid = mimeFor$text(header, 4, "ftyp");
                                    }
                                    break;
                                case 108272:
/* 265 */                           if (extension.equals("mp3") && (mimeFor$text(header, 0, "ID3") || (header.length >= 2 && (header[0] & UByte.MAX_VALUE) == 255 && (header[1] & 224) == 224))) {
                                        valid = true;
                                    }
                                    break;
                                case 109967:
/* 265 */                           if (extension.equals("ogg")) {
/* 272 */                               valid = mimeFor$text(header, 0, "OggS");
                                    }
                                    break;
                                case 110369:
/* 265 */                           if (extension.equals("otf")) {
/* 275 */                               valid = mimeFor$text(header, 0, "OTTO");
                                    }
                                    break;
                                case 111145:
/* 265 */                           if (extension.equals("png")) {
/* 266 */                               valid = mimeFor$starts(header, 137, 80, 78, 71, 13, 10, 26, 10);
                                    }
                                    break;
                                case 115174:
/* 265 */                           if (extension.equals("ttf") && (mimeFor$starts(header, 0, 1, 0, 0) || mimeFor$text(header, 0, "true"))) {
                                        valid = true;
                                    }
                                    break;
                                case 117484:
/* 271 */                           if (extension.equals("wav") && mimeFor$text(header, 0, "RIFF") && mimeFor$text(header, 8, "WAVE")) {
                                        valid = true;
                                    }
                                    break;
                                case 3268712:
/* 265 */                           if (extension.equals("jpeg")) {
/* 267 */                               valid = mimeFor$starts(header, 255, 216, 255);
                                    }
                                    break;
                                case 3645340:
/* 265 */                           if (extension.equals("webp") && mimeFor$text(header, 0, "RIFF") && mimeFor$text(header, 8, "WEBP")) {
                                        valid = true;
                                    }
                                    break;
                                case 3655064:
/* 265 */                           if (extension.equals("woff")) {
/* 276 */                               valid = mimeFor$text(header, 0, "wOFF");
                                    }
                                    break;
                                case 113307034:
                                    if (extension.equals("woff2")) {
/* 277 */                               valid = mimeFor$text(header, 0, "wOF2");
                                    }
                                    break;
                            }
/* 280 */                   if (valid) {
/* 281 */                       return expected;
                            }
/* 280 */                   throw new IOException("Media content differs from MIME: " + media.getOriginalName());
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(fileInputStream, th);
                                throw th2;
                            }
                        }
                    }

/* 262 */           private static final boolean mimeFor$starts(byte[] header, int... bytes) {
                        boolean z;
/* 263 */               if (header.length < bytes.length) {
                            return false;
                        }
                        Iterable indices = ArraysKt.getIndices(bytes);
/* 307 */               if ((indices instanceof Collection) && ((Collection) indices).isEmpty()) {
                            z = true;
                        } else {
/* 308 */                   Iterator it = indices.iterator();
                            while (it.hasNext()) {
                                int iNextInt = ((IntIterator) it).nextInt();
/* 308 */                       if (((header[iNextInt] & 255) == bytes[iNextInt] ? 1 : 0) == 0) {
                                    z = false;
                                }
                            }
/* 309 */                   z = true;
                        }
                        return z;
                    }

/* 263 */           private static final boolean mimeFor$text(byte[] header, int offset, String value) {
                        boolean z;
/* 264 */               if (header.length < value.length() + offset) {
                            return false;
                        }
                        Iterable indices = StringsKt.getIndices(value);
/* 310 */               if ((indices instanceof Collection) && ((Collection) indices).isEmpty()) {
                            z = true;
                        } else {
/* 311 */                   Iterator it = indices.iterator();
                            while (it.hasNext()) {
                                int iNextInt = ((IntIterator) it).nextInt();
/* 311 */                       if ((header[offset + iNextInt] == value.charAt(iNextInt) ? 1 : 0) == 0) {
                                    z = false;
                                }
                            }
/* 312 */                   z = true;
                        }
                        return z;
                    }
                }
            }

            package com.xunji.flashcards.anki;

            import java.io.File;
            import java.io.IOException;
            import java.nio.file.FileVisitResult;
            import java.nio.file.Files;
            import java.nio.file.NoSuchFileException;
            import java.nio.file.Path;
            import java.nio.file.SimpleFileVisitor;
            import java.nio.file.attribute.BasicFileAttributes;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0010\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0000¨\u0006\u0004"}, d2 = {"deletePrivateTree", "", "directory", "Ljava/io/File;", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 30 */    public final class MediaStoreKt {
/* 31 */        public static final void deletePrivateTree(File directory) throws IOException {
                    Intrinsics.checkNotNullParameter(directory, "directory");
/* 32 */            Files.walkFileTree(directory.toPath(), new SimpleFileVisitor<Path>() { // from class: com.xunji.flashcards.anki.MediaStoreKt.deletePrivateTree.1
                        @Override // java.nio.file.SimpleFileVisitor, java.nio.file.FileVisitor
/* 33 */                public FileVisitResult visitFile(Path file, BasicFileAttributes attributes) throws IOException {
                            Intrinsics.checkNotNullParameter(file, "file");
                            Intrinsics.checkNotNullParameter(attributes, "attributes");
/* 34 */                    Files.delete(file);
/* 35 */                    return FileVisitResult.CONTINUE;
                        }

                        @Override // java.nio.file.SimpleFileVisitor, java.nio.file.FileVisitor
/* 37 */                public FileVisitResult postVisitDirectory(Path dir, IOException error) throws IOException {
                            Intrinsics.checkNotNullParameter(dir, "dir");
/* 38 */                    if (error != null) {
/* 38 */                        throw error;
                            }
/* 39 */                    Files.delete(dir);
/* 40 */                    return FileVisitResult.CONTINUE;
                        }

                        @Override // java.nio.file.SimpleFileVisitor, java.nio.file.FileVisitor
/* 42 */                public FileVisitResult visitFileFailed(Path file, IOException error) throws IOException {
                            Intrinsics.checkNotNullParameter(file, "file");
                            Intrinsics.checkNotNullParameter(error, "error");
/* 43 */                    if (!(error instanceof NoSuchFileException)) {
/* 43 */                        throw error;
                            }
/* 44 */                    return FileVisitResult.CONTINUE;
                        }
                    });
                }
            }

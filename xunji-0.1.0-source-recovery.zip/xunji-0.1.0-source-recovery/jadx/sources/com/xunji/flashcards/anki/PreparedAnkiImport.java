            package com.xunji.flashcards.anki;

            import java.io.Closeable;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.Map;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportService.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\"\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0001\u0018\u00002\u00020\u0001BO\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\u0006\u0010\f\u001a\u00020\r\u0012\u0014\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\r\u0012\u0006\u0012\u0004\u0018\u00010\t0\u000f¢\u0006\u0004\b\u0010\u0010\u0011J\u0016\u0010%\u001a\u00020&2\u000e\b\u0002\u0010'\u001a\b\u0012\u0004\u0012\u00020\t0!J\r\u0010(\u001a\u00020&H\u0000¢\u0006\u0002\b)J\b\u0010*\u001a\u00020&H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0004\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0014\u0010\f\u001a\u00020\rX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\"\u0010\u000e\u001a\u0010\u0012\u0004\u0012\u00020\r\u0012\u0006\u0012\u0004\u0018\u00010\t0\u000fX\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u000e\u0010\u001e\u001a\u00020\u001fX\u0082\u000e¢\u0006\u0002\n\u0000R.\u0010\"\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010!2\u000e\u0010 \u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010!@BX\u0080\u000e¢\u0006\b\n\u0000\u001a\u0004\b#\u0010$¨\u0006+"}, d2 = {"Lcom/xunji/flashcards/anki/PreparedAnkiImport;", "Ljava/io/Closeable;", "owner", "Lcom/xunji/flashcards/anki/AnkiImportService;", "source", "Lcom/xunji/flashcards/anki/PreparedPackage;", "format", "Lcom/xunji/flashcards/anki/PackageFormat;", "restoreEpoch", "", "report", "Lcom/xunji/flashcards/anki/AnkiImportReport;", "namespace", "", "revisions", "", "<init>", "(Lcom/xunji/flashcards/anki/AnkiImportService;Lcom/xunji/flashcards/anki/PreparedPackage;Lcom/xunji/flashcards/anki/PackageFormat;JLcom/xunji/flashcards/anki/AnkiImportReport;Ljava/lang/String;Ljava/util/Map;)V", "getSource$app_debug", "()Lcom/xunji/flashcards/anki/PreparedPackage;", "getFormat", "()Lcom/xunji/flashcards/anki/PackageFormat;", "getRestoreEpoch", "()J", "getReport", "()Lcom/xunji/flashcards/anki/AnkiImportReport;", "getNamespace$app_debug", "()Ljava/lang/String;", "getRevisions$app_debug", "()Ljava/util/Map;", "closed", "", "value", "", "selected", "getSelected$app_debug", "()Ljava/util/Set;", "confirmCompatible", "", "ids", "ensureOpen", "ensureOpen$app_debug", "close", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 45 */    public final class PreparedAnkiImport implements Closeable {
                public static final int $stable = 8;
                private boolean closed;
                private final PackageFormat format;
                private final String namespace;
                private final AnkiImportService owner;
                private final AnkiImportReport report;
                private final long restoreEpoch;
                private final Map<String, Long> revisions;
                private Set<Long> selected;
                private final PreparedPackage source;

/* 46 */        public PreparedAnkiImport(AnkiImportService owner, PreparedPackage source, PackageFormat format, long restoreEpoch, AnkiImportReport report, String namespace, Map<String, Long> revisions) {
                    Intrinsics.checkNotNullParameter(owner, "owner");
                    Intrinsics.checkNotNullParameter(source, "source");
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(report, "report");
                    Intrinsics.checkNotNullParameter(namespace, "namespace");
                    Intrinsics.checkNotNullParameter(revisions, "revisions");
/* 48 */            this.owner = owner;
                    this.source = source;
/* 49 */            this.format = format;
                    this.restoreEpoch = restoreEpoch;
                    this.report = report;
/* 50 */            this.namespace = namespace;
                    this.revisions = revisions;
                }

                /* JADX INFO: renamed from: getSource$app_debug, reason: from getter */
/* 47 */        public final PreparedPackage getSource() {
/* 48 */            return this.source;
                }

/* 48 */        public final PackageFormat getFormat() {
/* 49 */            return this.format;
                }

/* 48 */        public final AnkiImportReport getReport() {
/* 49 */            return this.report;
                }

/* 48 */        public final long getRestoreEpoch() {
/* 49 */            return this.restoreEpoch;
                }

                /* JADX INFO: renamed from: getNamespace$app_debug, reason: from getter */
/* 49 */        public final String getNamespace() {
/* 50 */            return this.namespace;
                }

/* 49 */        public final Map<String, Long> getRevisions$app_debug() {
/* 50 */            return this.revisions;
                }

/* 52 */        public final Set<Long> getSelected$app_debug() {
/* 53 */            return this.selected;
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 54 */        public static /* synthetic */ void confirmCompatible$default(PreparedAnkiImport preparedAnkiImport, Set set, int i, Object obj) {
/* 55 */            if ((i & 1) != 0) {
                        Iterable cards = preparedAnkiImport.report.getCards();
/* 358 */               Collection arrayList = new ArrayList();
                        for (Object obj2 : cards) {
/* 359 */                   if (((ImportPreviewCard) obj2).getStatus() == PreviewStatus.COMPATIBLE) {
                                arrayList.add(obj2);
                            }
                        }
                        Iterable iterable = (List) arrayList;
/* 361 */               Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 362 */               Iterator it = iterable.iterator();
                        while (it.hasNext()) {
/* 363 */                   arrayList2.add(Long.valueOf(((ImportPreviewCard) it.next()).getSourceCardId()));
                        }
/* 55 */                set = CollectionsKt.toSet((List) arrayList2);
                    }
                    preparedAnkiImport.confirmCompatible(set);
                }

/* 55 */        public final void confirmCompatible(Set<Long> ids) {
                    boolean z;
                    Intrinsics.checkNotNullParameter(ids, "ids");
/* 56 */            ensureOpen$app_debug();
/* 57 */            Iterable cards = this.report.getCards();
/* 347 */           Collection arrayList = new ArrayList();
/* 348 */           Iterator it = cards.iterator();
                    while (true) {
                        z = false;
                        if (!it.hasNext()) {
                            break;
                        }
                        Object next = it.next();
/* 348 */               if (((ImportPreviewCard) next).getStatus() == PreviewStatus.COMPATIBLE) {
                            arrayList.add(next);
                        }
                    }
                    Iterable iterable = (List) arrayList;
/* 350 */           Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 351 */           Iterator it2 = iterable.iterator();
                    while (it2.hasNext()) {
/* 352 */               arrayList2.add(Long.valueOf(((ImportPreviewCard) it2.next()).getSourceCardId()));
                    }
/* 57 */            Set allowed = CollectionsKt.toSet((List) arrayList2);
/* 58 */            Set<Long> set = ids;
/* 354 */           if (!(set instanceof Collection) || !set.isEmpty()) {
/* 355 */               Iterator it3 = set.iterator();
/* 355 */               do {
                            if (!it3.hasNext()) {
/* 356 */                       z = true;
                                break;
                            }
/* 355 */               } while (allowed.contains(Long.valueOf(((Number) it3.next()).longValue())));
                    } else {
                        z = true;
                    }
/* 58 */            if (!z) {
                        throw new IllegalArgumentException("Only compatible source cards can be selected".toString());
                    }
/* 59 */            this.selected = CollectionsKt.toSet(ids);
                }

/* 60 */        public final void ensureOpen$app_debug() {
/* 61 */            if (this.closed) {
                        throw new IllegalStateException("Import preview expired; select the package again".toString());
                    }
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 62 */        public void close() {
/* 63 */            if (!this.closed) {
/* 64 */                this.closed = true;
                        try {
/* 65 */                    this.source.close();
                        } finally {
                            this.owner.release$app_debug(this);
                        }
                    }
                }
            }

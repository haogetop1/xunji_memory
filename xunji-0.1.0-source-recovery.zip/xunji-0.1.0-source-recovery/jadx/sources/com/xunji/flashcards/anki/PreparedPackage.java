            package com.xunji.flashcards.anki;

            import androidx.core.view.MotionEventCompat;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiSourceCard;
            import com.xunji.core.anki.AnkiSourceDeck;
            import com.xunji.core.anki.AnkiSourceNote;
            import com.xunji.core.anki.ImportIssue;
            import java.io.Closeable;
            import java.io.File;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.FilesKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.CoroutineScopeKt;
            import kotlinx.coroutines.Dispatchers;
            
            /* JADX INFO: compiled from: ApkgReader.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000v\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0001\u0018\u00002\u00020\u0001B5\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\u0004\b\f\u0010\rJ2\u0010\u001f\u001a\u00020 2\"\u0010!\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020#\u0012\n\u0012\b\u0012\u0004\u0012\u00020 0$\u0012\u0006\u0012\u0004\u0018\u00010%0\"H\u0086@¢\u0006\u0002\u0010&J\u0016\u0010'\u001a\u00020(2\u0006\u0010)\u001a\u00020\u0017H\u0086@¢\u0006\u0002\u0010*J\u0016\u0010+\u001a\u00020,2\u0006\u0010)\u001a\u00020\u0017H\u0086@¢\u0006\u0002\u0010*J\b\u0010-\u001a\u00020 H\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u001d\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u000b0\t¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0012\u001a\u00020\u00138F¢\u0006\u0006\u001a\u0004\b\u0014\u0010\u0015R\u001d\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0017\u0012\u0004\u0012\u00020\u00180\t8F¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u0011R\u0017\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u001c0\u001b8F¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001e¨\u0006."}, d2 = {"Lcom/xunji/flashcards/anki/PreparedPackage;", "Ljava/io/Closeable;", "directory", "Ljava/io/File;", "source", "Lcom/xunji/flashcards/anki/AnkiPackageDatabase;", "format", "Lcom/xunji/flashcards/anki/PackageFormat;", "media", "", "", "Lcom/xunji/flashcards/anki/AnkiMediaFile;", "<init>", "(Ljava/io/File;Lcom/xunji/flashcards/anki/AnkiPackageDatabase;Lcom/xunji/flashcards/anki/PackageFormat;Ljava/util/Map;)V", "getFormat", "()Lcom/xunji/flashcards/anki/PackageFormat;", "getMedia", "()Ljava/util/Map;", "cardCount", "", "getCardCount", "()I", "decks", "", "Lcom/xunji/core/anki/AnkiSourceDeck;", "getDecks", "issues", "", "Lcom/xunji/core/anki/ImportIssue;", "getIssues", "()Ljava/util/List;", "forEachCard", "", "action", "Lkotlin/Function2;", "Lcom/xunji/core/anki/AnkiSourceCard;", "Lkotlin/coroutines/Continuation;", "", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readNote", "Lcom/xunji/core/anki/AnkiSourceNote;", "cardId", "(JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readModel", "Lcom/xunji/core/anki/AnkiModel;", "close", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 32 */    public final class PreparedPackage implements Closeable {
                public static final int $stable = 8;
                private final File directory;
                private final PackageFormat format;
                private final Map<String, AnkiMediaFile> media;
                private final AnkiPackageDatabase source;

/* 33 */        public PreparedPackage(File directory, AnkiPackageDatabase source, PackageFormat format, Map<String, AnkiMediaFile> media) {
                    Intrinsics.checkNotNullParameter(directory, "directory");
                    Intrinsics.checkNotNullParameter(source, "source");
                    Intrinsics.checkNotNullParameter(format, "format");
                    Intrinsics.checkNotNullParameter(media, "media");
                    this.directory = directory;
                    this.source = source;
                    this.format = format;
                    this.media = media;
                }

/* 33 */        public final PackageFormat getFormat() {
/* 34 */            return this.format;
                }

/* 33 */        public final Map<String, AnkiMediaFile> getMedia() {
/* 34 */            return this.media;
                }

/* 34 */        public final int getCardCount() {
/* 35 */            return this.source.getCardCount();
                }

/* 35 */        public final Map<Long, AnkiSourceDeck> getDecks() {
/* 36 */            return this.source.getDecks();
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.PreparedPackage$forEachCard$2, reason: invalid class name */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.PreparedPackage$forEachCard$2", f = "ApkgReader.kt", i = {0, 0, 0}, l = {MotionEventCompat.AXIS_GENERIC_8}, m = "invokeSuspend", n = {"$this$withContext", "cursor\\1", "$i$a$-use-PreparedPackage$forEachCard$2$1\\1\\39\\0"}, s = {"L$0", "L$4", "I$0"}, v = 1)
/* 36 */        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Function2<AnkiSourceCard, Continuation<? super Unit>, Object> $action;
                    int I$0;
                    private /* synthetic */ Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    AnonymousClass2(Function2<? super AnkiSourceCard, ? super Continuation<? super Unit>, ? extends Object> function2, Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                        this.$action = function2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass2 anonymousClass2 = PreparedPackage.this.new AnonymousClass2(this.$action, continuation);
                        anonymousClass2.L$0 = obj;
                        return anonymousClass2;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:16:0x0055 A[Catch: all -> 0x007f, TryCatch #3 {all -> 0x007f, blocks: (B:14:0x004f, B:16:0x0055, B:20:0x0077), top: B:37:0x004f }] */
                    /* JADX WARN: Code duplicated, block: B:18:0x0075 A[RETURN] */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0073 -> B:19:0x0076). Please report as a decompilation issue!!! */
                    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                        */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 37 */            public final java.lang.Object invokeSuspend(java.lang.Object r12) {
                        /*
                            r11 = this;
                            java.lang.Object r0 = r11.L$0
                            kotlinx.coroutines.CoroutineScope r0 = (kotlinx.coroutines.CoroutineScope) r0
                            java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
                            int r2 = r11.label
                            r3 = 0
                            switch(r2) {
                                case 0: goto L30;
                                case 1: goto L16;
                                default: goto Le;
                            }
                        Le:
                            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
                            java.lang.String r2 = "call to 'resume' before 'invoke' with coroutine"
                            r1.<init>(r2)
                            throw r1
                        L16:
                            int r2 = r11.I$0
                            java.lang.Object r4 = r11.L$4
                            android.database.Cursor r4 = (android.database.Cursor) r4
                            java.lang.Object r5 = r11.L$3
                            com.xunji.flashcards.anki.PreparedPackage r5 = (com.xunji.flashcards.anki.PreparedPackage) r5
                            java.lang.Object r6 = r11.L$2
                            kotlin.jvm.functions.Function2 r6 = (kotlin.jvm.functions.Function2) r6
                            java.lang.Object r7 = r11.L$1
                            java.io.Closeable r7 = (java.io.Closeable) r7
                            kotlin.ResultKt.throwOnFailure(r12)     // Catch: java.lang.Throwable -> L2d
                            r8 = r11
                            goto L76
                        L2d:
                            r1 = move-exception
                            r8 = r11
                            goto L83
                        L30:
                            kotlin.ResultKt.throwOnFailure(r12)
                            com.xunji.flashcards.anki.PreparedPackage r2 = com.xunji.flashcards.anki.PreparedPackage.this
                            com.xunji.flashcards.anki.AnkiPackageDatabase r2 = com.xunji.flashcards.anki.PreparedPackage.access$getSource$p(r2)
                            android.database.Cursor r2 = r2.cards()
                            r7 = r2
                            java.io.Closeable r7 = (java.io.Closeable) r7
                            kotlin.jvm.functions.Function2<com.xunji.core.anki.AnkiSourceCard, kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> r2 = r11.$action
                            com.xunji.flashcards.anki.PreparedPackage r4 = com.xunji.flashcards.anki.PreparedPackage.this
                            r5 = r7
                            android.database.Cursor r5 = (android.database.Cursor) r5     // Catch: java.lang.Throwable -> L81
                            r6 = 0
                            r8 = r6
                            r6 = r2
                            r2 = r8
                            r8 = r5
                            r5 = r4
                            r4 = r8
                            r8 = r11
                        L4f:
                            boolean r9 = r4.moveToNext()     // Catch: java.lang.Throwable -> L7f
                            if (r9 == 0) goto L77
                            kotlinx.coroutines.CoroutineScopeKt.ensureActive(r0)     // Catch: java.lang.Throwable -> L7f
                            com.xunji.flashcards.anki.AnkiPackageDatabase r9 = com.xunji.flashcards.anki.PreparedPackage.access$getSource$p(r5)     // Catch: java.lang.Throwable -> L7f
                            com.xunji.core.anki.AnkiSourceCard r9 = r9.card(r4)     // Catch: java.lang.Throwable -> L7f
                            r8.L$0 = r0     // Catch: java.lang.Throwable -> L7f
                            r8.L$1 = r7     // Catch: java.lang.Throwable -> L7f
                            r8.L$2 = r6     // Catch: java.lang.Throwable -> L7f
                            r8.L$3 = r5     // Catch: java.lang.Throwable -> L7f
                            r8.L$4 = r4     // Catch: java.lang.Throwable -> L7f
                            r8.I$0 = r2     // Catch: java.lang.Throwable -> L7f
                            r10 = 1
                            r8.label = r10     // Catch: java.lang.Throwable -> L7f
                            java.lang.Object r9 = r6.invoke(r9, r8)     // Catch: java.lang.Throwable -> L7f
                            if (r9 != r1) goto L76
                            return r1
                        L76:
                            goto L4f
                        L77:
                            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L7f
                            kotlin.io.CloseableKt.closeFinally(r7, r3)
                            kotlin.Unit r1 = kotlin.Unit.INSTANCE
                            return r1
                        L7f:
                            r1 = move-exception
                            goto L83
                        L81:
                            r1 = move-exception
                            r8 = r11
                        L83:
                            throw r1     // Catch: java.lang.Throwable -> L84
                        L84:
                            r2 = move-exception
                            kotlin.io.CloseableKt.closeFinally(r7, r1)
                            throw r2
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.anki.PreparedPackage.AnonymousClass2.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

/* 36 */        public final List<ImportIssue> getIssues() {
/* 37 */            return this.source.getIssues();
                }

/* 37 */        public final Object forEachCard(Function2<? super AnkiSourceCard, ? super Continuation<? super Unit>, ? extends Object> function2, Continuation<? super Unit> continuation) {
/* 38 */            Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(function2, null), continuation);
                    return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.PreparedPackage$readNote$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/core/anki/AnkiSourceNote;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.PreparedPackage$readNote$2", f = "ApkgReader.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 39 */        static final class C04202 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super AnkiSourceNote>, Object> {
                    final /* synthetic */ long $cardId;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04202(long j, Continuation<? super C04202> continuation) {
                        super(2, continuation);
                        this.$cardId = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04202 c04202 = PreparedPackage.this.new C04202(this.$cardId, continuation);
                        c04202.L$0 = obj;
                        return c04202;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super AnkiSourceNote> continuation) {
                        return ((C04202) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 40 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        CoroutineScope $this$withContext = (CoroutineScope) this.L$0;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                CoroutineScopeKt.ensureActive($this$withContext);
/* 34 */                        return PreparedPackage.this.source.noteForCard(this.$cardId);
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.anki.PreparedPackage$readModel$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ApkgReader.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/core/anki/AnkiModel;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.anki.PreparedPackage$readModel$2", f = "ApkgReader.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 40 */        static final class C04192 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super AnkiModel>, Object> {
                    final /* synthetic */ long $cardId;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04192(long j, Continuation<? super C04192> continuation) {
                        super(2, continuation);
                        this.$cardId = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04192 c04192 = PreparedPackage.this.new C04192(this.$cardId, continuation);
                        c04192.L$0 = obj;
                        return c04192;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super AnkiModel> continuation) {
                        return ((C04192) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 41 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        CoroutineScope $this$withContext = (CoroutineScope) this.L$0;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                CoroutineScopeKt.ensureActive($this$withContext);
/* 34 */                        return PreparedPackage.this.source.modelForCard(this.$cardId);
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 40 */        public final Object readNote(long cardId, Continuation<? super AnkiSourceNote> continuation) {
/* 41 */            return BuildersKt.withContext(Dispatchers.getIO(), new C04202(cardId, null), continuation);
                }

/* 41 */        public final Object readModel(long cardId, Continuation<? super AnkiModel> continuation) {
/* 42 */            return BuildersKt.withContext(Dispatchers.getIO(), new C04192(cardId, null), continuation);
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 42 */        public void close() {
                    try {
/* 43 */                this.source.close();
                    } finally {
                        FilesKt.deleteRecursively(this.directory);
                    }
                }
            }

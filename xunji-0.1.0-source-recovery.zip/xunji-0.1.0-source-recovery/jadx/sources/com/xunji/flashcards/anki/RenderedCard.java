            package com.xunji.flashcards.anki;

            import com.xunji.core.anki.CardSide;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiCardPresenter.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0012\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BA\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0012\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\b\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000b¢\u0006\u0004\b\f\u0010\rJ\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\u0015\u0010\u001a\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\bHÆ\u0003J\u000f\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\t0\u000bHÆ\u0003JM\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00032\u0014\b\u0002\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\b2\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000bHÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020!HÖ\u0001J\t\u0010\"\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u001d\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\t0\b¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0017\u0010\n\u001a\b\u0012\u0004\u0012\u00020\t0\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016¨\u0006#"}, d2 = {"Lcom/xunji/flashcards/anki/RenderedCard;", "", "cardId", "", "side", "Lcom/xunji/core/anki/CardSide;", "html", "media", "", "Lcom/xunji/flashcards/anki/CardMedia;", "audio", "", "<init>", "(Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Ljava/lang/String;Ljava/util/Map;Ljava/util/List;)V", "getCardId", "()Ljava/lang/String;", "getSide", "()Lcom/xunji/core/anki/CardSide;", "getHtml", "getMedia", "()Ljava/util/Map;", "getAudio", "()Ljava/util/List;", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */    public final /* data */ class RenderedCard {
                public static final int $stable = 8;
                private final List<CardMedia> audio;
                private final String cardId;
                private final String html;
                private final Map<String, CardMedia> media;
                private final CardSide side;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ RenderedCard copy$default(RenderedCard renderedCard, String str, CardSide cardSide, String str2, Map map, List list, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = renderedCard.cardId;
                    }
                    if ((i & 2) != 0) {
                        cardSide = renderedCard.side;
                    }
                    if ((i & 4) != 0) {
                        str2 = renderedCard.html;
                    }
                    if ((i & 8) != 0) {
                        map = renderedCard.media;
                    }
                    if ((i & 16) != 0) {
                        list = renderedCard.audio;
                    }
                    List list2 = list;
                    String str3 = str2;
                    return renderedCard.copy(str, cardSide, str3, map, list2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final CardSide getSide() {
                    return this.side;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getHtml() {
                    return this.html;
                }

                public final Map<String, CardMedia> component4() {
                    return this.media;
                }

                public final List<CardMedia> component5() {
                    return this.audio;
                }

                public final RenderedCard copy(String cardId, CardSide side, String html, Map<String, CardMedia> media, List<CardMedia> audio) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(side, "side");
                    Intrinsics.checkNotNullParameter(html, "html");
                    Intrinsics.checkNotNullParameter(media, "media");
                    Intrinsics.checkNotNullParameter(audio, "audio");
                    return new RenderedCard(cardId, side, html, media, audio);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof RenderedCard)) {
                        return false;
                    }
                    RenderedCard renderedCard = (RenderedCard) other;
                    return Intrinsics.areEqual(this.cardId, renderedCard.cardId) && this.side == renderedCard.side && Intrinsics.areEqual(this.html, renderedCard.html) && Intrinsics.areEqual(this.media, renderedCard.media) && Intrinsics.areEqual(this.audio, renderedCard.audio);
                }

                public int hashCode() {
                    return (((((((this.cardId.hashCode() * 31) + this.side.hashCode()) * 31) + this.html.hashCode()) * 31) + this.media.hashCode()) * 31) + this.audio.hashCode();
                }

                public String toString() {
                    return "RenderedCard(cardId=" + this.cardId + ", side=" + this.side + ", html=" + this.html + ", media=" + this.media + ", audio=" + this.audio + ")";
                }

/* 12 */        public RenderedCard(String cardId, CardSide side, String html, Map<String, CardMedia> media, List<CardMedia> audio) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(side, "side");
                    Intrinsics.checkNotNullParameter(html, "html");
                    Intrinsics.checkNotNullParameter(media, "media");
                    Intrinsics.checkNotNullParameter(audio, "audio");
                    this.cardId = cardId;
                    this.side = side;
                    this.html = html;
                    this.media = media;
                    this.audio = audio;
                }

/* 12 */        public final List<CardMedia> getAudio() {
/* 13 */            return this.audio;
                }

/* 12 */        public final String getCardId() {
/* 13 */            return this.cardId;
                }

/* 12 */        public final String getHtml() {
/* 13 */            return this.html;
                }

/* 12 */        public final Map<String, CardMedia> getMedia() {
/* 13 */            return this.media;
                }

/* 12 */        public final CardSide getSide() {
/* 13 */            return this.side;
                }
            }

            package com.xunji.flashcards.anki;

            import com.xunji.flashcards.data.AnkiMediaEntity;
            import java.io.Closeable;
            import java.io.File;
            import java.io.IOException;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: MediaStore.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0001\u0018\u00002\u00020\u0001B\u001f\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\u0004\b\u0007\u0010\bJ\r\u0010\u000f\u001a\u00020\u0010H\u0000¢\u0006\u0002\b\u0011J\b\u0010\u0012\u001a\u00020\u0010H\u0016R\u0014\u0010\u0002\u001a\u00020\u0003X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u000e\u0010\r\u001a\u00020\u000eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\u0013"}, d2 = {"Lcom/xunji/flashcards/anki/StagedMedia;", "Ljava/io/Closeable;", "directory", "Ljava/io/File;", "mappings", "", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "<init>", "(Ljava/io/File;Ljava/util/List;)V", "getDirectory$app_debug", "()Ljava/io/File;", "getMappings", "()Ljava/util/List;", "closed", "", "ensureOpen", "", "ensureOpen$app_debug", "close", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 47 */    public final class StagedMedia implements Closeable {
                public static final int $stable = 8;
                private boolean closed;
                private final File directory;
                private final List<AnkiMediaEntity> mappings;

/* 48 */        public StagedMedia(File directory, List<AnkiMediaEntity> mappings) {
                    Intrinsics.checkNotNullParameter(directory, "directory");
                    Intrinsics.checkNotNullParameter(mappings, "mappings");
                    this.directory = directory;
                    this.mappings = mappings;
                }

                /* JADX INFO: renamed from: getDirectory$app_debug, reason: from getter */
/* 48 */        public final File getDirectory() {
/* 49 */            return this.directory;
                }

/* 48 */        public final List<AnkiMediaEntity> getMappings() {
/* 49 */            return this.mappings;
                }

/* 50 */        public final void ensureOpen$app_debug() {
/* 51 */            if (this.closed) {
                        throw new IllegalStateException("Staged media is closed".toString());
                    }
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 51 */        public void close() throws IOException {
/* 52 */            if (this.closed) {
                        return;
                    }
                    this.closed = true;
                    MediaStoreKt.deletePrivateTree(this.directory);
                }
            }

            package com.xunji.flashcards.anki;

            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: BoundedApkg.kt */
            /* JADX INFO: loaded from: classes15.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\b\u0081\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0007HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0007HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000bR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/anki/ZipRecord;", "", "size", "", "compressedSize", "crc", "method", "", "<init>", "(JJJI)V", "getSize", "()J", "getCompressedSize", "getCrc", "getMethod", "()I", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 87 */    public final /* data */ class ZipRecord {
                public static final int $stable = 0;
                private final long compressedSize;
                private final long crc;
                private final int method;
                private final long size;

                public static /* synthetic */ ZipRecord copy$default(ZipRecord zipRecord, long j, long j2, long j3, int i, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        j = zipRecord.size;
                    }
                    long j4 = j;
                    if ((i2 & 2) != 0) {
                        j2 = zipRecord.compressedSize;
                    }
                    long j5 = j2;
                    if ((i2 & 4) != 0) {
                        j3 = zipRecord.crc;
                    }
                    long j6 = j3;
                    if ((i2 & 8) != 0) {
                        i = zipRecord.method;
                    }
                    return zipRecord.copy(j4, j5, j6, i);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final long getSize() {
                    return this.size;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final long getCompressedSize() {
                    return this.compressedSize;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getCrc() {
                    return this.crc;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getMethod() {
                    return this.method;
                }

                public final ZipRecord copy(long size, long compressedSize, long crc, int method) {
                    return new ZipRecord(size, compressedSize, crc, method);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ZipRecord)) {
                        return false;
                    }
                    ZipRecord zipRecord = (ZipRecord) other;
                    return this.size == zipRecord.size && this.compressedSize == zipRecord.compressedSize && this.crc == zipRecord.crc && this.method == zipRecord.method;
                }

                public int hashCode() {
                    return (((((Long.hashCode(this.size) * 31) + Long.hashCode(this.compressedSize)) * 31) + Long.hashCode(this.crc)) * 31) + Integer.hashCode(this.method);
                }

                public String toString() {
                    return "ZipRecord(size=" + this.size + ", compressedSize=" + this.compressedSize + ", crc=" + this.crc + ", method=" + this.method + ")";
                }

/* 88 */        public ZipRecord(long size, long compressedSize, long crc, int method) {
                    this.size = size;
                    this.compressedSize = compressedSize;
                    this.crc = crc;
                    this.method = method;
                }

/* 88 */        public final long getCompressedSize() {
/* 89 */            return this.compressedSize;
                }

/* 88 */        public final long getCrc() {
/* 89 */            return this.crc;
                }

/* 88 */        public final int getMethod() {
/* 89 */            return this.method;
                }

/* 88 */        public final long getSize() {
/* 89 */            return this.size;
                }
            }

            package com.xunji.flashcards.backup;
            
            /* JADX INFO: compiled from: D8$$SyntheticClass */
            /* JADX INFO: loaded from: classes12.dex */
            public final /* synthetic */ class BackupArchive$$ExternalSyntheticBackport0 {
            }

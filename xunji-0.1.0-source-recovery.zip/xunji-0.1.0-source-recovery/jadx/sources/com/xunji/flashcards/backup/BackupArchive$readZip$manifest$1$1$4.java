            package com.xunji.flashcards.backup;

            import com.xunji.core.backup.BackupManifest;
            import java.io.ByteArrayOutputStream;
            import java.security.MessageDigest;
            import java.util.Map;
            import java.util.zip.ZipInputStream;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Ref;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive$readZip$manifest$1$1$4", f = "BackupArchive.kt", i = {}, l = {172}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 167 */   final class BackupArchive$readZip$manifest$1$1$4 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                final /* synthetic */ byte[] $buffer;
                final /* synthetic */ Map<String, Long> $counts;
                final /* synthetic */ MessageDigest $digest;
                final /* synthetic */ ByteArrayOutputStream $line;
                final /* synthetic */ BackupManifest $m;
                final /* synthetic */ Ref.IntRef $previousType;
                final /* synthetic */ Ref.LongRef $total;
                final /* synthetic */ ZipInputStream $zip;
                int label;
                final /* synthetic */ BackupArchive this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                BackupArchive$readZip$manifest$1$1$4(BackupArchive backupArchive, ZipInputStream zipInputStream, byte[] bArr, Ref.LongRef longRef, BackupManifest backupManifest, MessageDigest messageDigest, ByteArrayOutputStream byteArrayOutputStream, Ref.IntRef intRef, Map<String, Long> map, Continuation<? super BackupArchive$readZip$manifest$1$1$4> continuation) {
                    super(1, continuation);
                    this.this$0 = backupArchive;
                    this.$zip = zipInputStream;
                    this.$buffer = bArr;
                    this.$total = longRef;
                    this.$m = backupManifest;
                    this.$digest = messageDigest;
                    this.$line = byteArrayOutputStream;
                    this.$previousType = intRef;
                    this.$counts = map;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Continuation<?> continuation) {
                    return new BackupArchive$readZip$manifest$1$1$4(this.this$0, this.$zip, this.$buffer, this.$total, this.$m, this.$digest, this.$line, this.$previousType, this.$counts, continuation);
                }

                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Continuation<? super Unit> continuation) {
                    return ((BackupArchive$readZip$manifest$1$1$4) create(continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Code duplicated, block: B:10:0x0047 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:13:0x0051 A[DONT_INVERT] */
                /* JADX WARN: Code duplicated, block: B:14:0x0053  */
                /* JADX WARN: Code duplicated, block: B:16:0x006e  */
                /* JADX WARN: Code duplicated, block: B:17:0x0070  */
                /* JADX WARN: Code duplicated, block: B:19:0x0073  */
                /* JADX WARN: Code duplicated, block: B:21:0x007d  */
                /* JADX WARN: Code duplicated, block: B:23:0x0085  */
                /* JADX WARN: Code duplicated, block: B:25:0x008d  */
                /* JADX WARN: Code duplicated, block: B:26:0x008f  */
                /* JADX WARN: Code duplicated, block: B:28:0x0092  */
                /* JADX WARN: Code duplicated, block: B:30:0x00c6  */
                /* JADX WARN: Code duplicated, block: B:32:0x00da  */
                /* JADX WARN: Code duplicated, block: B:33:0x00dc  */
                /* JADX WARN: Code duplicated, block: B:35:0x00df  */
                /* JADX WARN: Code duplicated, block: B:37:0x0120  */
                /* JADX WARN: Code duplicated, block: B:38:0x0122  */
                /* JADX WARN: Code duplicated, block: B:40:0x0125  */
                /* JADX WARN: Code duplicated, block: B:49:0x0170  */
                /* JADX WARN: Code duplicated, block: B:51:0x017c  */
                /* JADX WARN: Code duplicated, block: B:52:0x017e  */
                /* JADX WARN: Code duplicated, block: B:54:0x0181  */
                /* JADX WARN: Code duplicated, block: B:59:0x019d  */
                /* JADX WARN: Code duplicated, block: B:77:0x0162 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:78:0x0154 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:79:0x0146 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:80:0x0138 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:81:0x018b A[SYNTHETIC] */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:9:0x0045 -> B:11:0x0048). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions count limit reached at block B:33:0x00dc
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 168 */       public final java.lang.Object invokeSuspend(java.lang.Object r18) {
                    /*
                        Method dump skipped, instruction units count: 520
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive$readZip$manifest$1$1$4.invokeSuspend(java.lang.Object):java.lang.Object");
                }
            }

            package com.xunji.flashcards.backup;

            import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.BufferedOutputStream;
            import java.security.MessageDigest;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.text.Charsets;
            import kotlinx.serialization.json.JsonElementBuildersKt;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonObjectBuilder;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive$snapshot$2$1", f = "BackupArchive.kt", i = {}, l = {106}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 103 */   final class BackupArchive$snapshot$2$1 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                final /* synthetic */ Map<String, Long> $counts;
                final /* synthetic */ MessageDigest $digest;
                final /* synthetic */ BufferedOutputStream $output;
                final /* synthetic */ Ref.LongRef $size;
                final /* synthetic */ XunjiDatabase $source;
                int label;
                final /* synthetic */ BackupArchive this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                BackupArchive$snapshot$2$1(BackupArchive backupArchive, XunjiDatabase xunjiDatabase, BufferedOutputStream bufferedOutputStream, MessageDigest messageDigest, Ref.LongRef longRef, Map<String, Long> map, Continuation<? super BackupArchive$snapshot$2$1> continuation) {
                    super(1, continuation);
                    this.this$0 = backupArchive;
                    this.$source = xunjiDatabase;
                    this.$output = bufferedOutputStream;
                    this.$digest = messageDigest;
                    this.$size = longRef;
                    this.$counts = map;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Continuation<?> continuation) {
                    return new BackupArchive$snapshot$2$1(this.this$0, this.$source, this.$output, this.$digest, this.$size, this.$counts, continuation);
                }

                @Override // kotlin.jvm.functions.Function1
                public final Object invoke(Continuation<? super Unit> continuation) {
                    return ((BackupArchive$snapshot$2$1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$snapshot$2$1$1, reason: invalid class name */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\n"}, d2 = {"<anonymous>", "", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "", "row", "Lkotlinx/serialization/json/JsonObject;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive$snapshot$2$1$1", f = "BackupArchive.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 104 */       static final class AnonymousClass1 extends SuspendLambda implements Function3<String, JsonObject, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Map<String, Long> $counts;
                    final /* synthetic */ MessageDigest $digest;
                    final /* synthetic */ BufferedOutputStream $output;
                    final /* synthetic */ Ref.LongRef $size;
                    /* synthetic */ Object L$0;
                    /* synthetic */ Object L$1;
                    int label;
                    final /* synthetic */ BackupArchive this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(BackupArchive backupArchive, BufferedOutputStream bufferedOutputStream, MessageDigest messageDigest, Ref.LongRef longRef, Map<String, Long> map, Continuation<? super AnonymousClass1> continuation) {
                        super(3, continuation);
                        this.this$0 = backupArchive;
                        this.$output = bufferedOutputStream;
                        this.$digest = messageDigest;
                        this.$size = longRef;
                        this.$counts = map;
                    }

                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(String str, JsonObject jsonObject, Continuation<? super Unit> continuation) {
                        AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, this.$output, this.$digest, this.$size, this.$counts, continuation);
                        anonymousClass1.L$0 = str;
                        anonymousClass1.L$1 = jsonObject;
                        return anonymousClass1.invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 105 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        String type = (String) this.L$0;
                        JsonObject row = (JsonObject) this.L$1;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 107 */                       BackupArchive.checkSpace$default(this.this$0, 0L, 1, null);
/* 343 */                       JsonObjectBuilder jsonObjectBuilder = new JsonObjectBuilder();
/* 344 */                       JsonElementBuildersKt.put(jsonObjectBuilder, ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, type);
/* 344 */                       jsonObjectBuilder.put("data", row);
/* 108 */                       byte[] bytes = jsonObjectBuilder.build().toString().getBytes(Charsets.UTF_8);
                                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
/* 109 */                       if (!(bytes.length <= 16777216)) {
                                    throw new IllegalArgumentException("Backup record exceeds 16 MiB".toString());
                                }
/* 110 */                       this.$output.write(bytes);
                                this.$output.write(10);
                                this.$digest.update(bytes);
                                this.$digest.update((byte) 10);
/* 111 */                       this.$size.element = Math.addExact(this.$size.element, ((long) bytes.length) + 1);
                                this.$counts.put(type, Boxing.boxLong(Math.addExact(((Number) MapsKt.getValue(this.$counts, type)).longValue(), 1L)));
/* 112 */                       if (Intrinsics.areEqual(type, "anki_media")) {
/* 18 */                            this.this$0.indexObject(BackupArchiveKt.media(row));
                                }
/* 113 */                       return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 104 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.label = 1;
/* 106 */                   if (this.this$0.forEachRecord(this.$source, new AnonymousClass1(this.this$0, this.$output, this.$digest, this.$size, this.$counts, null), this) == coroutine_suspended) {
/* 105 */                       return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 114 */           return Unit.INSTANCE;
                }
            }

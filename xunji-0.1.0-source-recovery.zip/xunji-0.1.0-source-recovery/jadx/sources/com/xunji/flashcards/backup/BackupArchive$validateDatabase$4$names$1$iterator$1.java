            package com.xunji.flashcards.backup;

            import android.database.Cursor;
            import com.xunji.flashcards.data.AnkiNoteEntity;
            import java.util.Iterator;
            import java.util.NoSuchElementException;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.TuplesKt;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.internal.markers.KMappedMarker;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000%\n\u0000\n\u0002\u0010(\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u001c\u0010\u000f\u001a\u0018\u0012\u0004\u0012\u00020\u0004\u0012\f\u0012\n \u0010*\u0004\u0018\u00010\u00020\u0002\u0018\u00010\nJ\t\u0010\u0011\u001a\u00020\u0012H\u0096\u0002J\t\u0010\t\u001a\u00020\u0002H\u0096\u0002R\u001a\u0010\u0003\u001a\u00020\u0004X\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR(\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u0002\u0018\u00010\nX\u0086\u000e¢\u0006\u000e\n\u0000\u001a\u0004\b\u000b\u0010\f\"\u0004\b\r\u0010\u000e¨\u0006\u0013"}, d2 = {"com/xunji/flashcards/backup/BackupArchive$validateDatabase$4$names$1$iterator$1", "", "", "last", "", "getLast", "()J", "setLast", "(J)V", "next", "Lkotlin/Pair;", "getNext", "()Lkotlin/Pair;", "setNext", "(Lkotlin/Pair;)V", "read", "kotlin.jvm.PlatformType", "hasNext", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 273 */   public final class BackupArchive$validateDatabase$4$names$1$iterator$1 implements Iterator<String>, KMappedMarker {
                final /* synthetic */ AnkiNoteEntity $n;
                private long last;
                private Pair<Long, String> next = read();
                final /* synthetic */ BackupArchive this$0;

                @Override // java.util.Iterator
                public void remove() {
                    throw new UnsupportedOperationException("Operation is not supported for read-only collection");
                }

/* 274 */       BackupArchive$validateDatabase$4$names$1$iterator$1(BackupArchive $receiver, AnkiNoteEntity $n) {
                    this.this$0 = $receiver;
                    this.$n = $n;
                }

/* 275 */       public final long getLast() {
/* 276 */           return this.last;
                }

/* 275 */       public final void setLast(long j) {
/* 276 */           this.last = j;
                }

/* 276 */       public final Pair<Long, String> getNext() {
/* 277 */           return this.next;
                }

/* 276 */       public final void setNext(Pair<Long, String> pair) {
/* 277 */           this.next = pair;
                }

/* 277 */       public final Pair<Long, String> read() {
/* 18 */            Cursor cursorQuery = this.this$0.getSql().query("SELECT rowid,originalName FROM anki_media WHERE namespace=? AND rowid>? ORDER BY rowid LIMIT 1", new Object[]{this.$n.getMediaNamespace(), Long.valueOf(this.last)});
                    try {
                        Cursor cursor = cursorQuery;
/* 278 */               Pair<Long, String> pair = cursor.moveToFirst() ? TuplesKt.to(Long.valueOf(cursor.getLong(0)), cursor.getString(1)) : null;
                        CloseableKt.closeFinally(cursorQuery, null);
                        return pair;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(cursorQuery, th);
                            throw th2;
                        }
                    }
                }

                @Override // java.util.Iterator
/* 278 */       public boolean hasNext() {
                    return this.next != null;
                }

                @Override // java.util.Iterator
/* 279 */       public String next() {
/* 280 */           Pair<Long, String> pair = this.next;
                    if (pair == null) {
                        throw new NoSuchElementException();
                    }
                    this.last = pair.getFirst().longValue();
                    this.next = read();
                    return pair.getSecond();
                }
            }

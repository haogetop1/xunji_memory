            package com.xunji.flashcards.backup;

            import com.xunji.flashcards.data.AnkiMediaEntity;
            import java.io.Closeable;
            import java.io.InputStream;
            import java.util.zip.ZipEntry;
            import java.util.zip.ZipOutputStream;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive$writeZip$2$4", f = "BackupArchive.kt", i = {0, 1, 1, 1}, l = {131, 131}, m = "invokeSuspend", n = {"media", "media", "it\\2", "$i$a$-use-BackupArchive$writeZip$2$4$2\\2\\131\\0"}, s = {"L$0", "L$0", "L$2", "I$0"}, v = 1)
/* 127 */   final class BackupArchive$writeZip$2$4 extends SuspendLambda implements Function2<AnkiMediaEntity, Continuation<? super Unit>, Object> {
                final /* synthetic */ Function2<AnkiMediaEntity, Continuation<? super InputStream>, Object> $openMedia;
                final /* synthetic */ ZipOutputStream $zip;
                int I$0;
                /* synthetic */ Object L$0;
                Object L$1;
                Object L$2;
                int label;
                final /* synthetic */ BackupArchive this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                /* JADX WARN: Multi-variable type inference failed */
                BackupArchive$writeZip$2$4(ZipOutputStream zipOutputStream, Function2<? super AnkiMediaEntity, ? super Continuation<? super InputStream>, ? extends Object> function2, BackupArchive backupArchive, Continuation<? super BackupArchive$writeZip$2$4> continuation) {
                    super(2, continuation);
                    this.$zip = zipOutputStream;
                    this.$openMedia = function2;
                    this.this$0 = backupArchive;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    BackupArchive$writeZip$2$4 backupArchive$writeZip$2$4 = new BackupArchive$writeZip$2$4(this.$zip, this.$openMedia, this.this$0, continuation);
                    backupArchive$writeZip$2$4.L$0 = obj;
                    return backupArchive$writeZip$2$4;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(AnkiMediaEntity ankiMediaEntity, Continuation<? super Unit> continuation) {
                    return ((BackupArchive$writeZip$2$4) create(ankiMediaEntity, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Code duplicated, block: B:21:0x0094 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:22:0x0095  */
                /* JADX WARN: Code duplicated, block: B:25:0x00a6 A[Catch: all -> 0x00c1, TRY_LEAVE, TryCatch #0 {all -> 0x00c1, blocks: (B:23:0x0096, B:25:0x00a6, B:29:0x00b5, B:30:0x00c0, B:19:0x008e), top: B:37:0x008e }] */
                /* JADX WARN: Code duplicated, block: B:28:0x00b4  */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 128 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    Closeable closeable;
                    Object objInvoke;
                    BackupArchive$writeZip$2$4 backupArchive$writeZip$2$4;
                    Object objCopy;
                    AnkiMediaEntity media = (AnkiMediaEntity) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    try {
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 130 */                       ZipOutputStream zipOutputStream = this.$zip;
                                ZipEntry zipEntry = new ZipEntry("media/" + media.getSha256());
/* 343 */                       zipEntry.setTime(0L);
                                zipOutputStream.putNextEntry(zipEntry);
/* 131 */                       Function2<AnkiMediaEntity, Continuation<? super InputStream>, Object> function2 = this.$openMedia;
                                this.L$0 = media;
                                this.label = 1;
                                objInvoke = function2.invoke(media, this);
                                if (objInvoke == coroutine_suspended) {
/* 129 */                           return coroutine_suspended;
                                }
                                closeable = (Closeable) objInvoke;
                                BackupArchive backupArchive = this.this$0;
                                InputStream inputStream = (InputStream) closeable;
/* 131 */                       ZipOutputStream zipOutputStream2 = this.$zip;
                                long size = media.getSize();
                                this.L$0 = media;
                                this.L$1 = closeable;
                                this.L$2 = SpillingKt.nullOutSpilledVariable(inputStream);
/* 343 */                       this.I$0 = 0;
                                this.label = 2;
                                backupArchive$writeZip$2$4 = this;
                                try {
/* 18 */                            objCopy = backupArchive.copy(inputStream, zipOutputStream2, size, backupArchive$writeZip$2$4);
                                    if (objCopy == coroutine_suspended) {
/* 129 */                               return coroutine_suspended;
                                    }
                                    if (!Intrinsics.areEqual(((Pair) objCopy).getSecond(), media.getSha256())) {
/* 131 */                               throw new IllegalArgumentException("Stored media digest differs".toString());
                                    }
                                    Unit unit = Unit.INSTANCE;
                                    CloseableKt.closeFinally(closeable, null);
                                    backupArchive$writeZip$2$4.$zip.closeEntry();
/* 132 */                           return Unit.INSTANCE;
                                } catch (Throwable th) {
                                    th = th;
                                    Throwable th2 = th;
                                    try {
                                        throw th2;
                                    } catch (Throwable th3) {
                                        CloseableKt.closeFinally(closeable, th2);
                                        throw th3;
                                    }
                                }
                            case 1:
/* 129 */                       ResultKt.throwOnFailure($result);
                                objInvoke = $result;
                                closeable = (Closeable) objInvoke;
                                BackupArchive backupArchive2 = this.this$0;
                                InputStream inputStream2 = (InputStream) closeable;
/* 131 */                       ZipOutputStream zipOutputStream3 = this.$zip;
                                long size2 = media.getSize();
                                this.L$0 = media;
                                this.L$1 = closeable;
                                this.L$2 = SpillingKt.nullOutSpilledVariable(inputStream2);
/* 343 */                       this.I$0 = 0;
                                this.label = 2;
                                backupArchive$writeZip$2$4 = this;
/* 18 */                        objCopy = backupArchive2.copy(inputStream2, zipOutputStream3, size2, backupArchive$writeZip$2$4);
                                if (objCopy == coroutine_suspended) {
/* 129 */                           return coroutine_suspended;
                                }
                                if (!Intrinsics.areEqual(((Pair) objCopy).getSecond(), media.getSha256())) {
/* 131 */                           throw new IllegalArgumentException("Stored media digest differs".toString());
                                }
                                Unit unit2 = Unit.INSTANCE;
                                CloseableKt.closeFinally(closeable, null);
                                backupArchive$writeZip$2$4.$zip.closeEntry();
/* 132 */                       return Unit.INSTANCE;
                            case 2:
                                int i = this.I$0;
                                closeable = (Closeable) this.L$1;
                                ResultKt.throwOnFailure($result);
                                backupArchive$writeZip$2$4 = this;
                                objCopy = $result;
                                if (!Intrinsics.areEqual(((Pair) objCopy).getSecond(), media.getSha256())) {
/* 131 */                           throw new IllegalArgumentException("Stored media digest differs".toString());
                                }
                                Unit unit3 = Unit.INSTANCE;
                                CloseableKt.closeFinally(closeable, null);
                                backupArchive$writeZip$2$4.$zip.closeEntry();
/* 132 */                       return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    } catch (Throwable th4) {
/* 131 */               th = th4;
                    }
                }
            }

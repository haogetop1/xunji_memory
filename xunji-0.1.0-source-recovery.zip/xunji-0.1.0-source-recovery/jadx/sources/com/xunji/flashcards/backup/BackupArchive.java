            package com.xunji.flashcards.backup;

            import android.database.Cursor;
            import androidx.collection.SieveCacheKt;
            import androidx.compose.runtime.ComposerKt;
            import androidx.core.view.MotionEventCompat;
            import androidx.room.RoomDatabaseKt;
            import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
            import androidx.sqlite.db.SupportSQLiteDatabase;
            import androidx.sqlite.db.SupportSQLiteStatement;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.backup.BackupCodec;
            import com.xunji.core.backup.BackupManifest;
            import com.xunji.core.backup.BackupValidator;
            import com.xunji.flashcards.anki.BoundedApkgKt;
            import com.xunji.flashcards.anki.BoundedJson;
            import com.xunji.flashcards.anki.MediaStore;
            import com.xunji.flashcards.anki.ZipRecord;
            import com.xunji.flashcards.data.AnkiDao;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.EntityMappersKt;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.BufferedOutputStream;
            import java.io.ByteArrayOutputStream;
            import java.io.Closeable;
            import java.io.File;
            import java.io.FileInputStream;
            import java.io.FileOutputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.io.OutputStream;
            import java.io.Serializable;
            import java.security.MessageDigest;
            import java.text.Normalizer;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.Set;
            import java.util.zip.ZipEntry;
            import java.util.zip.ZipOutputStream;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.AbstractMap;
            import kotlin.collections.AbstractSet;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.ranges.RangesKt;
            import kotlin.text.Charsets;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.JobKt;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.JsonNull;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonObjectBuilder;
            import kotlinx.serialization.json.JsonPrimitive;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000 \u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010$\n\u0002\u0010\u000e\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0001\u0018\u00002\u00020\u0001B%\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u0006\u0010\u001f\u001a\u00020 J\u0010\u0010!\u001a\u00020 2\b\b\u0002\u0010\"\u001a\u00020\bJ\u0010\u0010#\u001a\u00020\b2\u0006\u0010$\u001a\u00020\u0015H\u0002J\u0018\u0010%\u001a\u00020 2\u0006\u0010$\u001a\u00020\u00152\u0006\u0010&\u001a\u00020\u0015H\u0002JB\u0010'\u001a\u00020 2\b\b\u0002\u0010(\u001a\u00020\u00032(\u0010)\u001a$\b\u0001\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020+\u0012\n\u0012\b\u0012\u0004\u0012\u00020 0,\u0012\u0006\u0012\u0004\u0018\u00010\u00010*H\u0086@¢\u0006\u0002\u0010-J\f\u0010.\u001a\u00020+*\u00020/H\u0002J\u0016\u00100\u001a\u00020 2\u0006\u00101\u001a\u00020\u00152\u0006\u00102\u001a\u00020+J\u0018\u00103\u001a\u00020 2\u0006\u00101\u001a\u00020\u00152\u0006\u00104\u001a\u00020+H\u0002J\u0010\u00105\u001a\u00020 2\u0006\u00106\u001a\u000207H\u0002J2\u00108\u001a\u00020 2\"\u0010)\u001a\u001e\b\u0001\u0012\u0004\u0012\u000207\u0012\n\u0012\b\u0012\u0004\u0012\u00020 0,\u0012\u0006\u0012\u0004\u0018\u00010\u000109H\u0086@¢\u0006\u0002\u0010:J\u001e\u0010;\u001a\u00020<2\u0006\u0010(\u001a\u00020\u00032\u0006\u0010=\u001a\u00020\bH\u0086@¢\u0006\u0002\u0010>J:\u0010?\u001a\u00020\u00052\u0006\u0010@\u001a\u00020<2\"\u0010A\u001a\u001e\b\u0001\u0012\u0004\u0012\u000207\u0012\n\u0012\b\u0012\u0004\u0012\u00020B0,\u0012\u0006\u0012\u0004\u0018\u00010\u000109H\u0086@¢\u0006\u0002\u0010CJ\u0016\u0010D\u001a\u00020<2\u0006\u0010E\u001a\u00020BH\u0086@¢\u0006\u0002\u0010FJ\u0010\u0010G\u001a\u00020 2\u0006\u0010H\u001a\u00020IH\u0002J\u0014\u0010J\u001a\u000e\u0012\u0004\u0012\u00020\u0015\u0012\u0004\u0012\u00020K0\u0014H\u0002J\u000e\u0010L\u001a\u00020 H\u0086@¢\u0006\u0002\u0010MJ\u001e\u0010N\u001a\u00020O2\u0006\u0010E\u001a\u00020B2\u0006\u0010P\u001a\u00020QH\u0082@¢\u0006\u0002\u0010RJ\u001e\u0010S\u001a\u00020Q2\u0006\u0010E\u001a\u00020B2\u0006\u0010T\u001a\u00020OH\u0082@¢\u0006\u0002\u0010UJ2\u0010V\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00150\u00172\u0006\u0010E\u001a\u00020B2\u0006\u0010W\u001a\u00020X2\u0006\u0010Y\u001a\u00020\bH\u0082@¢\u0006\u0002\u0010ZR\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\u00020\u00108BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b\u0011\u0010\u0012RI\u0010\u0013\u001a0\u0012\u0004\u0012\u00020\u0015\u0012&\u0012$\u0012 \u0012\u001e\u0012\f\u0012\n \u0018*\u0004\u0018\u00010\u00150\u0015\u0012\f\u0012\n \u0018*\u0004\u0018\u00010\u00150\u00150\u00170\u00160\u00148BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u0019\u0010\u001aR\u0011\u0010\u001d\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u000e¨\u0006["}, d2 = {"Lcom/xunji/flashcards/backup/BackupArchive;", "", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "directory", "Ljava/io/File;", "availableSpace", "Lkotlin/Function0;", "", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;Ljava/io/File;Lkotlin/jvm/functions/Function0;)V", "getDb", "()Lcom/xunji/flashcards/data/XunjiDatabase;", "getDirectory", "()Ljava/io/File;", "sql", "Landroidx/sqlite/db/SupportSQLiteDatabase;", "getSql", "()Landroidx/sqlite/db/SupportSQLiteDatabase;", "columns", "", "", "", "Lkotlin/Pair;", "kotlin.jvm.PlatformType", "getColumns", "()Ljava/util/Map;", "columns$delegate", "Lkotlin/Lazy;", "mediaDirectory", "getMediaDirectory", "initialize", "", "checkSpace", "required", "scalar", "query", "requireEmpty", "message", "forEachRecord", "source", "action", "Lkotlin/Function3;", "Lkotlinx/serialization/json/JsonObject;", "Lkotlin/coroutines/Continuation;", "(Lcom/xunji/flashcards/data/XunjiDatabase;Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "jsonRow", "Landroid/database/Cursor;", "insert", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "validateRow", "r", "indexObject", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "objects", "Lkotlin/Function2;", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "snapshot", "Lcom/xunji/core/backup/BackupManifest;", "exportedAt", "(Lcom/xunji/flashcards/data/XunjiDatabase;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "writeZip", "manifest", "openMedia", "Ljava/io/InputStream;", "(Lcom/xunji/core/backup/BackupManifest;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readZip", "input", "(Ljava/io/InputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "saveZipEntry", "entry", "Ljava/util/zip/ZipEntry;", "zipRecords", "Lcom/xunji/flashcards/anki/ZipRecord;", "validateDatabase", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readBounded", "", "maximum", "", "(Ljava/io/InputStream;ILkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readChunk", "buffer", "(Ljava/io/InputStream;[BLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "copy", "output", "Ljava/io/OutputStream;", "expected", "(Ljava/io/InputStream;Ljava/io/OutputStream;JLkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final class BackupArchive {
                public static final int $stable = 8;
                private final Function0<Long> availableSpace;

                /* JADX INFO: renamed from: columns$delegate, reason: from kotlin metadata */
                private final Lazy columns;
                private final XunjiDatabase db;
                private final File directory;
                private final File mediaDirectory;

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$copy$1, reason: invalid class name */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0, 0, 0, 0}, l = {324}, m = "copy", n = {"input", "output", "digest", "buffer", "expected", "total"}, s = {"L$0", "L$1", "L$2", "L$3", "J$0", "J$1"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    long J$0;
                    long J$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 18 */                return BackupArchive.this.copy(null, null, 0L, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$forEachRecord$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0, 0, 0}, l = {MotionEventCompat.AXIS_GENERIC_10}, m = "forEachRecord", n = {"source", "action", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "c\\1", "$i$a$-use-BackupArchive$forEachRecord$2\\1\\40\\0"}, s = {"L$0", "L$1", "L$3", "L$5", "I$0"}, v = 1)
                static final class C04211 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    int label;
                    /* synthetic */ Object result;

                    C04211(Continuation<? super C04211> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.forEachRecord(null, null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$objects$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0}, l = {98}, m = "objects", n = {"action", "c\\1", "$i$a$-use-BackupArchive$objects$2\\1\\97\\0"}, s = {"L$0", "L$2", "I$0"}, v = 1)
                static final class C04221 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    int label;
                    /* synthetic */ Object result;

                    C04221(Continuation<? super C04221> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.objects(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$readZip$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3}, l = {155, 169, ComposerKt.providerValuesKey, 219}, m = "readZip", n = {"input", "rawFile", "context", "rawOutput\\1", "rawBytes\\1", "maximumRaw\\1", "tee\\1", "zip\\2", "manifestEntry\\2", "$i$a$-use-BackupArchive$readZip$manifest$1\\1\\140\\0", "$i$a$-use-BackupArchive$readZip$manifest$1$1\\2\\152\\1", "input", "rawFile", "context", "rawOutput\\1", "rawBytes\\1", "maximumRaw\\1", "tee\\1", "zip\\2", "manifestEntry\\2", "manifestText\\2", "m\\2", "recordsEntry\\2", "counts\\2", "total\\2", "previousType\\2", "digest\\2", "buffer\\2", "line\\2", "$i$a$-use-BackupArchive$readZip$manifest$1\\1\\140\\0", "$i$a$-use-BackupArchive$readZip$manifest$1$1\\2\\152\\1", "input", "rawFile", "context", "rawOutput\\1", "rawBytes\\1", "maximumRaw\\1", "tee\\1", "zip\\2", "manifestEntry\\2", "manifestText\\2", "m\\2", "recordsEntry\\2", "counts\\2", "total\\2", "previousType\\2", "digest\\2", "buffer\\2", "line\\2", "entry\\2", "hash\\2", "media\\2", "file\\2", "it\\13", "$i$a$-use-BackupArchive$readZip$manifest$1\\1\\140\\0", "$i$a$-use-BackupArchive$readZip$manifest$1$1\\2\\152\\1", "count\\2", "bytes\\2", "$i$a$-use-BackupArchive$readZip$manifest$1$1$result$1\\13\\203\\2", "input", "rawFile", "context", "manifest"}, s = {"L$0", "L$1", "L$2", "L$4", "L$5", "L$6", "L$7", "L$9", "L$10", "I$0", "I$1", "L$0", "L$1", "L$2", "L$4", "L$5", "L$6", "L$7", "L$9", "L$10", "L$11", "L$12", "L$13", "L$14", "L$15", "L$16", "L$17", "L$18", "L$19", "I$0", "I$1", "L$0", "L$1", "L$2", "L$4", "L$5", "L$6", "L$7", "L$9", "L$10", "L$11", "L$12", "L$13", "L$14", "L$15", "L$16", "L$17", "L$18", "L$19", "L$20", "L$21", "L$22", "L$23", "L$25", "I$0", "I$1", "J$0", "J$1", "I$2", "L$0", "L$1", "L$2", "L$3"}, v = 1)
                static final class C04231 extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    int I$2;
                    long J$0;
                    long J$1;
                    Object L$0;
                    Object L$1;
                    Object L$10;
                    Object L$11;
                    Object L$12;
                    Object L$13;
                    Object L$14;
                    Object L$15;
                    Object L$16;
                    Object L$17;
                    Object L$18;
                    Object L$19;
                    Object L$2;
                    Object L$20;
                    Object L$21;
                    Object L$22;
                    Object L$23;
                    Object L$24;
                    Object L$25;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    Object L$9;
                    int label;
                    /* synthetic */ Object result;

                    C04231(Continuation<? super C04231> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.readZip(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$snapshot$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0, 0, 0, 0, 0}, l = {105}, m = "snapshot", n = {"source", "counts", "digest", "size", "output\\4", "exportedAt", "$i$a$-use-BackupArchive$snapshot$2\\4\\104\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "L$5", "J$0", "I$0"}, v = 1)
                static final class C04241 extends ContinuationImpl {
                    int I$0;
                    long J$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    int label;
                    /* synthetic */ Object result;

                    C04241(Continuation<? super C04241> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.snapshot(null, 0L, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$validateDatabase$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {}, l = {244, 245}, m = "validateDatabase", n = {}, s = {}, v = 1)
                static final class C04251 extends ContinuationImpl {
                    int label;
                    /* synthetic */ Object result;

                    C04251(Continuation<? super C04251> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.validateDatabase(this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$writeZip$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive", f = "BackupArchive.kt", i = {0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1}, l = {128, 129}, m = "writeZip", n = {"manifest", "openMedia", "file", "zip\\1", "it\\4", "$i$a$-use-BackupArchive$writeZip$2\\1\\125\\0", "$i$a$-use-BackupArchive$writeZip$2$3\\4\\128\\1", "manifest", "openMedia", "file", "zip\\1", "$i$a$-use-BackupArchive$writeZip$2\\1\\125\\0"}, s = {"L$0", "L$1", "L$2", "L$4", "L$6", "I$0", "I$1", "L$0", "L$1", "L$2", "L$4", "I$0"}, v = 1)
                static final class C04261 extends ContinuationImpl {
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    int label;
                    /* synthetic */ Object result;

                    C04261(Continuation<? super C04261> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupArchive.this.writeZip(null, null, this);
                    }
                }

/* 17 */        public BackupArchive(XunjiDatabase db, File directory, Function0<Long> availableSpace) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(directory, "directory");
                    Intrinsics.checkNotNullParameter(availableSpace, "availableSpace");
                    this.db = db;
                    this.directory = directory;
                    this.availableSpace = availableSpace;
/* 20 */            this.columns = LazyKt.lazy(new Function0() { // from class: com.xunji.flashcards.backup.BackupArchive$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return BackupArchive.columns_delegate$lambda$0(this.f$0);
                        }
                    });
/* 25 */            File file = new File(this.directory, "media");
/* 25 */            if (file.mkdirs() || file.isDirectory()) {
                        this.mediaDirectory = file;
/* 18 */                return;
                    }
/* 25 */            throw new IllegalStateException("Check failed.");
                }

/* 17 */        public final XunjiDatabase getDb() {
/* 18 */            return this.db;
                }

/* 17 */        public final File getDirectory() {
/* 18 */            return this.directory;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 18 */        public final SupportSQLiteDatabase getSql() {
/* 19 */            return this.db.getOpenHelper().getWritableDatabase();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final Map columns_delegate$lambda$0(BackupArchive this$0) {
/* 20 */            Iterable recordTypes = BackupCodec.INSTANCE.getRecordTypes();
/* 376 */           Map linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(recordTypes, 10)), 16));
/* 378 */           Iterator it = recordTypes.iterator();
                    while (it.hasNext()) {
                        Object next = it.next();
/* 379 */               Cursor cursorQuery = this$0.db.query("PRAGMA table_info(`" + ((String) next) + "`)", (Object[]) null);
                        try {
                            Cursor cursor = cursorQuery;
/* 21 */                    List listCreateListBuilder = CollectionsKt.createListBuilder();
                            List list = listCreateListBuilder;
/* 22 */                    while (cursor.moveToNext()) {
                                List list2 = list;
                                list2.add(TuplesKt.to(cursor.getString(1), cursor.getString(2)));
                                list = list2;
                                it = it;
                            }
/* 23 */                    Iterator it2 = it;
/* 21 */                    List listBuild = CollectionsKt.build(listCreateListBuilder);
/* 21 */                    CloseableKt.closeFinally(cursorQuery, null);
/* 379 */                   linkedHashMap.put(next, listBuild);
                            it = it2;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorQuery, th);
                                throw th2;
                            }
                        }
                    }
                    return linkedHashMap;
                }

/* 19 */        private final Map<String, List<Pair<String, String>>> getColumns() {
/* 20 */            return (Map) getValue();
                }

/* 24 */        public final File getMediaDirectory() {
/* 25 */            return this.mediaDirectory;
                }

/* 27 */        public final void initialize() {
/* 28 */            getSql().execSQL("CREATE TABLE backup_zip_entries (name TEXT PRIMARY KEY NOT NULL,size INTEGER NOT NULL,compressedSize INTEGER NOT NULL,crc INTEGER NOT NULL,method INTEGER NOT NULL,seen INTEGER NOT NULL DEFAULT 0)");
/* 29 */            getSql().execSQL("CREATE TABLE backup_objects (sha256 TEXT PRIMARY KEY NOT NULL,size INTEGER NOT NULL,mime TEXT NOT NULL,originalName TEXT NOT NULL,received INTEGER NOT NULL DEFAULT 0)");
/* 30 */            getSql().execSQL("CREATE TABLE backup_media_order (namespace TEXT NOT NULL,normalizedName TEXT NOT NULL,originalName TEXT NOT NULL,sortKey BLOB NOT NULL,PRIMARY KEY(namespace,normalizedName))");
/* 31 */            getSql().execSQL("CREATE INDEX backup_media_sort ON backup_media_order(namespace,sortKey)");
                }

/* 32 */        public static /* synthetic */ void checkSpace$default(BackupArchive backupArchive, long j, int i, Object obj) {
/* 33 */            if ((i & 1) != 0) {
                        j = BackupCodec.SAFETY_BYTES;
                    }
                    backupArchive.checkSpace(j);
                }

/* 33 */        public final void checkSpace(long required) {
                    if (!(invoke().longValue() >= required)) {
                        throw new IllegalArgumentException("Insufficient free space for backup (256 MiB safety reserve required)".toString());
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public final long scalar(String query) {
/* 36 */            Cursor cursorQuery = this.db.query(query, (Object[]) null);
                    try {
                        Cursor cursor = cursorQuery;
/* 36 */                if (!cursor.moveToFirst()) {
                            throw new IllegalStateException("Check failed.");
                        }
                        long j = cursor.getLong(0);
                        CloseableKt.closeFinally(cursorQuery, null);
                        return j;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(cursorQuery, th);
                            throw th2;
                        }
                    }
                }

/* 36 */        private final void requireEmpty(String query, String message) {
/* 37 */            Cursor cursorQuery = this.db.query(query, (Object[]) null);
                    try {
/* 37 */                if (cursorQuery.moveToFirst()) {
                            throw new IllegalArgumentException(message.toString());
                        }
                        Unit unit = Unit.INSTANCE;
                        CloseableKt.closeFinally(cursorQuery, null);
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(cursorQuery, th);
                            throw th2;
                        }
                    }
                }

/* 38 */        public static /* synthetic */ Object forEachRecord$default(BackupArchive backupArchive, XunjiDatabase xunjiDatabase, Function3 function3, Continuation continuation, int i, Object obj) {
/* 39 */            if ((i & 1) != 0) {
                        xunjiDatabase = backupArchive.db;
                    }
                    return backupArchive.forEachRecord(xunjiDatabase, function3, continuation);
                }

                /* JADX WARN: Code duplicated, block: B:25:0x00bc A[Catch: all -> 0x00ed, TryCatch #3 {all -> 0x00ed, blocks: (B:23:0x00b6, B:25:0x00bc, B:29:0x00e1), top: B:47:0x00b6 }] */
                /* JADX WARN: Code duplicated, block: B:27:0x00de A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Type inference failed for: r14v1 */
                /* JADX WARN: Type inference failed for: r14v2, types: [java.lang.Throwable] */
                /* JADX WARN: Type inference failed for: r14v3 */
                /* JADX WARN: Type inference failed for: r14v4 */
                /* JADX WARN: Type inference failed for: r14v5 */
                /* JADX WARN: Type inference failed for: r14v6 */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:22:0x00ae -> B:47:0x00b6). Please report as a decompilation issue!!! */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:26:0x00dc -> B:28:0x00df). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
/* 38 */        public final java.lang.Object forEachRecord(com.xunji.flashcards.data.XunjiDatabase r17, kotlin.jvm.functions.Function3<? super java.lang.String, ? super kotlinx.serialization.json.JsonObject, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r18, kotlin.coroutines.Continuation<? super kotlin.Unit> r19) {
                    /*
                        Method dump skipped, instruction units count: 268
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive.forEachRecord(com.xunji.flashcards.data.XunjiDatabase, kotlin.jvm.functions.Function3, kotlin.coroutines.Continuation):java.lang.Object");
                }

/* 43 */        private final JsonObject jsonRow(Cursor $this$jsonRow) {
                    JsonNull jsonNullJsonPrimitive;
/* 344 */           JsonObjectBuilder jsonObjectBuilder = new JsonObjectBuilder();
                    int columnCount = $this$jsonRow.getColumnCount();
                    for (int i = 0; i < columnCount; i++) {
                        String columnName = $this$jsonRow.getColumnName(i);
                        Intrinsics.checkNotNullExpressionValue(columnName, "getColumnName(...)");
                        switch ($this$jsonRow.getType(i)) {
                            case 0:
/* 46 */                        jsonNullJsonPrimitive = JsonNull.INSTANCE;
                                break;
                            case 1:
/* 47 */                        jsonNullJsonPrimitive = JsonElementKt.JsonPrimitive(Long.valueOf($this$jsonRow.getLong(i)));
                                break;
                            case 2:
/* 48 */                        jsonNullJsonPrimitive = JsonElementKt.JsonPrimitive(Double.valueOf($this$jsonRow.getDouble(i)));
                                break;
                            case 3:
/* 49 */                        jsonNullJsonPrimitive = JsonElementKt.JsonPrimitive($this$jsonRow.getString(i));
                                break;
                            default:
/* 49 */                        throw new IllegalStateException("Unexpected backup BLOB column".toString());
                        }
/* 45 */                jsonObjectBuilder.put(columnName, jsonNullJsonPrimitive);
                    }
/* 346 */           return jsonObjectBuilder.build();
                }

                /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
/* 53 */        public final void insert(String type, JsonObject row) {
                    Object objValueOf;
                    Intrinsics.checkNotNullParameter(type, "type");
                    Intrinsics.checkNotNullParameter(row, "row");
/* 54 */            Iterable iterable = getColumns().get(type);
                    if (iterable == null) {
                        throw new IllegalArgumentException("Unknown backup record type".toString());
                    }
                    Iterable iterable2 = (List) iterable;
/* 55 */            Set<String> setKeySet = row.keySet();
                    Iterable iterable3 = iterable2;
/* 347 */           Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable3, 10));
/* 348 */           Iterator it = iterable3.iterator();
                    while (it.hasNext()) {
/* 349 */               arrayList.add((String) ((Pair) it.next()).getFirst());
                    }
/* 55 */            if (!Intrinsics.areEqual(setKeySet, CollectionsKt.toSet((List) arrayList))) {
                        throw new IllegalArgumentException("Unknown or missing backup fields".toString());
                    }
/* 56 */            Iterable<Pair> iterable4 = iterable2;
/* 351 */           Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable4, 10));
                    for (Pair pair : iterable4) {
                        String str = (String) pair.component1();
                        String str2 = (String) pair.component2();
/* 57 */                JsonElement jsonElement = (JsonElement) MapsKt.getValue(row, str);
                        if (!Intrinsics.areEqual(jsonElement, JsonNull.INSTANCE)) {
/* 59 */                    JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive(jsonElement);
/* 60 */                    if (str2 != null) {
                                switch (str2.hashCode()) {
                                    case -1618932450:
/* 60 */                                if (str2.equals("INTEGER")) {
/* 62 */                                    if (jsonPrimitive.isString()) {
/* 62 */                                        throw new IllegalArgumentException("Failed requirement.".toString());
                                            }
                                            objValueOf = Long.valueOf(JsonElementKt.getLong(jsonPrimitive));
                                        }
                                        break;
                                    case 2511262:
/* 60 */                                if (str2.equals("REAL")) {
/* 63 */                                    if (jsonPrimitive.isString()) {
                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                            }
                                            Double dValueOf = Double.valueOf(JsonElementKt.getDouble(jsonPrimitive));
/* 63 */                                    if (!(Math.abs(dValueOf.doubleValue()) <= Double.MAX_VALUE)) {
                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                            }
                                            objValueOf = dValueOf;
                                        }
                                        break;
                                    case 2571565:
                                        if (str2.equals("TEXT")) {
/* 61 */                                    if (!jsonPrimitive.isString()) {
                                                throw new IllegalArgumentException("Failed requirement.".toString());
                                            }
                                            objValueOf = jsonPrimitive.getContent();
                                        }
                                        break;
                                    default:
                                        break;
                                }
                            }
/* 63 */                    throw new IllegalStateException("Unsupported backup column".toString());
                        }
                        objValueOf = null;
/* 353 */               arrayList2.add(objValueOf);
                    }
/* 355 */           Object[] values = ((List) arrayList2).toArray(new Object[0]);
/* 68 */            validateRow(type, row);
/* 69 */            getSql().execSQL("INSERT INTO `" + type + "` (" + CollectionsKt.joinToString$default(iterable2, null, null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.backup.BackupArchive$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupArchive.insert$lambda$4((Pair) obj);
                        }
                    }, 31, null) + ") VALUES (" + CollectionsKt.joinToString$default(iterable2, null, null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.backup.BackupArchive$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return BackupArchive.insert$lambda$5((Pair) obj);
                        }
                    }, 31, null) + ")", values);
/* 70 */            if (Intrinsics.areEqual(type, "anki_media")) {
/* 1 */                 AnkiMediaEntity media = BackupArchiveKt.media(row);
/* 72 */                indexObject(media);
/* 73 */                SupportSQLiteDatabase sql = getSql();
                        byte[] bytes = media.getOriginalName().getBytes(Charsets.UTF_16BE);
                        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                        sql.execSQL("INSERT INTO backup_media_order VALUES (?,?,?,?)", new Serializable[]{media.getNamespace(), Normalizer.normalize(media.getOriginalName(), Normalizer.Form.NFC), media.getOriginalName(), bytes});
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 68 */        public static final CharSequence insert$lambda$4(Pair it) {
                    Intrinsics.checkNotNullParameter(it, "it");
                    return "`" + it.getFirst() + "`";
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 68 */        public static final CharSequence insert$lambda$5(Pair it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 69 */            return "?";
                }

                /* JADX WARN: Code duplicated, block: B:59:0x012d  */
                /* JADX WARN: Failed to restore switch over string. Please report as a decompilation issue */
/* 76 */        private final void validateRow(String type, JsonObject r) {
                    boolean z;
                    boolean z2;
                    switch (type.hashCode()) {
                        case -160710468:
/* 77 */                    if (type.equals("schedules")) {
/* 1 */                         BackupValidator.INSTANCE.schedule(EntityMappersKt.toModel(BackupArchiveKt.schedule(r)));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 94431075:
/* 77 */                    if (type.equals("cards")) {
/* 1 */                         BackupValidator.INSTANCE.card(EntityMappersKt.toModel(BackupArchiveKt.card(r)));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 95459562:
/* 77 */                    if (type.equals("decks")) {
/* 1 */                         BackupValidator.INSTANCE.deck(EntityMappersKt.toModel(BackupArchiveKt.deck(r)), true);
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 176482415:
/* 77 */                    if (type.equals("anki_cards")) {
/* 1 */                         BackupValidator.INSTANCE.id(BackupArchiveKt.text(r, "cardId"));
/* 1 */                         BackupValidator.INSTANCE.id(BackupArchiveKt.text(r, "noteId"));
/* 1 */                         long jM8916long = BackupArchiveKt.m8916long(r, "ordinal");
                                if (!(0 <= jM8916long && jM8916long <= SieveCacheKt.NodeLinkMask)) {
                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                }
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 185823472:
/* 77 */                    if (type.equals("anki_media")) {
/* 1 */                         MediaStore.INSTANCE.validateMediaRow(BackupArchiveKt.media(r));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 187060173:
/* 77 */                    if (type.equals("anki_notes")) {
/* 1 */                         AnkiRepository.INSTANCE.validateNote(BackupArchiveKt.note(r));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 1359699510:
/* 77 */                    if (type.equals("review_logs")) {
/* 1 */                         BoundedJson.INSTANCE.parse(BackupArchiveKt.text(r, "beforeSchedule"));
/* 1 */                         BoundedJson.INSTANCE.parse(BackupArchiveKt.text(r, "afterSchedule"));
/* 1 */                         BackupValidator.INSTANCE.log(EntityMappersKt.toModel(BackupArchiveKt.log(r)));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 1434631203:
/* 77 */                    if (type.equals("settings")) {
/* 1 */                         if (!(BackupArchiveKt.m8916long(r, "id") == 0)) {
                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                }
/* 1 */                         BackupValidator.INSTANCE.settings(EntityMappersKt.toModel(BackupArchiveKt.settings(r)));
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 1474792158:
/* 77 */                    if (type.equals("anki_models")) {
/* 1 */                         AnkiRepository.INSTANCE.validateModel(BackupArchiveKt.model(r));
/* 1 */                         AnkiModel model = AnkiRepository.INSTANCE.asModel(BackupArchiveKt.model(r));
                                int kind = model.getKind();
                                if (!((!(kind >= 0 && kind < 2) || model.getFieldNames().isEmpty() || model.getTemplates().isEmpty()) ? false : true)) {
                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                }
                                Iterable templates = model.getTemplates();
/* 357 */                       Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(templates, 10));
/* 358 */                       Iterator it = templates.iterator();
                                while (it.hasNext()) {
/* 359 */                           arrayList.add(Integer.valueOf(((AnkiTemplate) it.next()).getOrdinal()));
                                }
/* 83 */                        if (CollectionsKt.distinct((List) arrayList).size() == model.getTemplates().size()) {
                                    Iterable templates2 = model.getTemplates();
/* 361 */                           if ((templates2 instanceof Collection) && ((Collection) templates2).isEmpty()) {
                                        z2 = true;
                                    } else {
/* 362 */                               Iterator it2 = templates2.iterator();
                                        while (true) {
                                            if (it2.hasNext()) {
/* 362 */                                       if (!(((AnkiTemplate) it2.next()).getOrdinal() >= 0)) {
                                                    z2 = false;
                                                }
                                            } else {
/* 363 */                                       z2 = true;
                                            }
                                        }
                                    }
/* 83 */                            z = z2;
                                }
                                if (!z) {
                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                }
/* 89 */                        return;
                            }
/* 89 */                    return;
                        case 1996717974:
                            if (type.equals("anki_deck_sources")) {
/* 1 */                         BackupValidator.INSTANCE.id(BackupArchiveKt.text(r, "localDeckId"));
/* 1 */                         Long.parseLong(BackupArchiveKt.text(r, "sourceDeckId"));
/* 1 */                         String name = BackupArchiveKt.text(r, "originalFullName");
                                if (!((StringsKt.isBlank(name) || StringsKt.contains$default((CharSequence) name, (char) 0, false, 2, (Object) null) || name.codePointCount(0, name.length()) > 1024) ? false : true)) {
                                    throw new IllegalArgumentException("Failed requirement.".toString());
                                }
/* 89 */                        return;
                            }
/* 89 */                    return;
                        default:
/* 89 */                    return;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 90 */        public final void indexObject(AnkiMediaEntity media) {
/* 91 */            getSql().execSQL("INSERT OR IGNORE INTO backup_objects(sha256,size,mime,originalName) VALUES(?,?,?,?)", new Object[]{media.getSha256(), Long.valueOf(media.getSize()), media.getMime(), media.getOriginalName()});
/* 92 */            Cursor cursorQuery = getSql().query("SELECT size,mime FROM backup_objects WHERE sha256=?", new String[]{media.getSha256()});
                    try {
                        Cursor cursor = cursorQuery;
/* 93 */                if (!cursor.moveToFirst()) {
                            throw new IllegalStateException("Check failed.");
                        }
                        boolean z = false;
                        if (cursor.getLong(0) == media.getSize() && Intrinsics.areEqual(cursor.getString(1), media.getMime())) {
                            z = true;
                        }
                        if (z) {
                            Unit unit = Unit.INSTANCE;
/* 92 */                    CloseableKt.closeFinally(cursorQuery, null);
                        }
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(cursorQuery, th);
                            throw th2;
                        }
                    }
                }

                /* JADX WARN: Code duplicated, block: B:22:0x007e A[Catch: all -> 0x00d6, TRY_LEAVE, TryCatch #1 {all -> 0x00d6, blocks: (B:20:0x0078, B:22:0x007e), top: B:44:0x0078 }] */
                /* JADX WARN: Code duplicated, block: B:26:0x00c0 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:27:0x00c1  */
                /* JADX WARN: Code duplicated, block: B:7:0x001a  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:27:0x00c1 -> B:28:0x00c3). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
/* 95 */        public final java.lang.Object objects(kotlin.jvm.functions.Function2<? super com.xunji.flashcards.data.AnkiMediaEntity, ? super kotlin.coroutines.Continuation<? super kotlin.Unit>, ? extends java.lang.Object> r21, kotlin.coroutines.Continuation<? super kotlin.Unit> r22) {
                    /*
                        Method dump skipped, instruction units count: 244
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive.objects(kotlin.jvm.functions.Function2, kotlin.coroutines.Continuation):java.lang.Object");
                }

                /* JADX WARN: Code duplicated, block: B:35:0x012f  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
/* 100 */       public final Object snapshot(XunjiDatabase source, long exportedAt, Continuation<? super BackupManifest> continuation) throws Throwable {
                    C04241 c04241;
                    long j;
                    Closeable closeable;
                    Throwable th;
                    Map counts;
                    long exportedAt2;
                    Ref.LongRef size;
                    MessageDigest digest;
                    FileOutputStream fileOutputStream;
                    if (continuation instanceof C04241) {
                        c04241 = (C04241) continuation;
                        if ((c04241.label & Integer.MIN_VALUE) != 0) {
                            c04241.label -= Integer.MIN_VALUE;
                        } else {
                            c04241 = new C04241(continuation);
                        }
                    } else {
                        c04241 = new C04241(continuation);
                    }
                    C04241 c04242 = c04241;
                    Object $result = c04242.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04242.label) {
                        case 0:
/* 101 */                   j = 0;
                            ResultKt.throwOnFailure($result);
/* 102 */                   Iterable recordTypes = BackupCodec.INSTANCE.getRecordTypes();
/* 364 */                   Map linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(recordTypes, 10)), 16));
                            for (Object obj : recordTypes) {
/* 367 */                       linkedHashMap.put(obj, Boxing.boxLong(0L));
                            }
/* 102 */                   Map counts2 = MapsKt.toMutableMap(linkedHashMap);
/* 103 */                   MessageDigest digest2 = MessageDigest.getInstance("SHA-256");
                            Ref.LongRef size2 = new Ref.LongRef();
/* 104 */                   OutputStream fileOutputStream2 = new FileOutputStream(new File(this.directory, "records.jsonl"));
                            BufferedOutputStream bufferedOutputStream = fileOutputStream2 instanceof BufferedOutputStream ? (BufferedOutputStream) fileOutputStream2 : new BufferedOutputStream(fileOutputStream2, 8192);
                            try {
                                BufferedOutputStream bufferedOutputStream2 = bufferedOutputStream;
/* 105 */                       XunjiDatabase xunjiDatabase = source;
                                BackupArchive$snapshot$2$1 backupArchive$snapshot$2$1 = new BackupArchive$snapshot$2$1(this, source, bufferedOutputStream2, digest2, size2, counts2, null);
                                c04242.L$0 = SpillingKt.nullOutSpilledVariable(source);
                                c04242.L$1 = counts2;
                                c04242.L$2 = digest2;
                                c04242.L$3 = size2;
                                c04242.L$4 = bufferedOutputStream;
                                c04242.L$5 = SpillingKt.nullOutSpilledVariable(bufferedOutputStream2);
                                try {
                                    c04242.J$0 = exportedAt;
                                    c04242.I$0 = 0;
                                    c04242.label = 1;
                                    if (RoomDatabaseKt.withTransaction(xunjiDatabase, backupArchive$snapshot$2$1, c04242) == coroutine_suspended) {
/* 101 */                               return coroutine_suspended;
                                    }
/* 105 */                           counts = counts2;
                                    exportedAt2 = exportedAt;
                                    size = size2;
                                    closeable = bufferedOutputStream;
                                    digest = digest2;
                                    try {
/* 115 */                               Unit unit = Unit.INSTANCE;
/* 104 */                               CloseableKt.closeFinally(closeable, null);
                                        if (((Number) MapsKt.getValue(counts, "settings")).longValue() == j) {
/* 118 */                                   byte[] bytes = "{\"type\":\"settings\",\"data\":{\"id\":0,\"newCardsPerDay\":20,\"themeMode\":\"SYSTEM\",\"schemaVersion\":1}}\n".getBytes(Charsets.UTF_8);
                                            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
/* 119 */                                   fileOutputStream = new FileOutputStream(new File(this.directory, "records.jsonl"), true);
                                            try {
/* 119 */                                       fileOutputStream.write(bytes);
                                                Unit unit2 = Unit.INSTANCE;
/* 104 */                                       CloseableKt.closeFinally(fileOutputStream, null);
                                                digest.update(bytes);
                                                size.element += (long) bytes.length;
/* 117 */                                       counts.put("settings", Boxing.boxLong(1L));
                                            } catch (Throwable th2) {
                                                try {
                                                    throw th2;
                                                } catch (Throwable th3) {
                                                    CloseableKt.closeFinally(fileOutputStream, th2);
                                                    throw th3;
                                                }
                                            }
                                        }
                                        long j2 = size.element;
                                        byte[] bArrDigest = digest.digest();
                                        Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
/* 121 */                               return new BackupManifest((String) null, 0, exportedAt2, counts, j2, BoundedApkgKt.hex(bArrDigest), scalar("SELECT count(*) FROM backup_objects"), scalar("SELECT COALESCE(sum(size),0) FROM backup_objects"), 3);
                                    } catch (Throwable th4) {
                                        th = th4;
                                        try {
                                            throw th;
                                        } catch (Throwable th5) {
                                            CloseableKt.closeFinally(closeable, th);
                                            throw th5;
                                        }
                                    }
                                } catch (Throwable th6) {
                                    closeable = bufferedOutputStream;
                                    th = th6;
                                    throw th;
                                }
                            } catch (Throwable th7) {
                                closeable = bufferedOutputStream;
                                th = th7;
                            }
                            break;
                        case 1:
                            int i = c04242.I$0;
                            long exportedAt3 = c04242.J$0;
                            closeable = (Closeable) c04242.L$4;
                            size = (Ref.LongRef) c04242.L$3;
                            digest = (MessageDigest) c04242.L$2;
                            counts = (Map) c04242.L$1;
                            j = 0;
                            try {
                                ResultKt.throwOnFailure($result);
                                exportedAt2 = exportedAt3;
/* 115 */                       Unit unit3 = Unit.INSTANCE;
/* 104 */                       CloseableKt.closeFinally(closeable, null);
                                if (((Number) MapsKt.getValue(counts, "settings")).longValue() == j) {
/* 118 */                           byte[] bytes2 = "{\"type\":\"settings\",\"data\":{\"id\":0,\"newCardsPerDay\":20,\"themeMode\":\"SYSTEM\",\"schemaVersion\":1}}\n".getBytes(Charsets.UTF_8);
                                    Intrinsics.checkNotNullExpressionValue(bytes2, "getBytes(...)");
/* 119 */                           fileOutputStream = new FileOutputStream(new File(this.directory, "records.jsonl"), true);
/* 119 */                           fileOutputStream.write(bytes2);
                                    Unit unit4 = Unit.INSTANCE;
/* 104 */                           CloseableKt.closeFinally(fileOutputStream, null);
                                    digest.update(bytes2);
                                    size.element += (long) bytes2.length;
/* 117 */                           counts.put("settings", Boxing.boxLong(1L));
                                }
                                long j3 = size.element;
                                byte[] bArrDigest2 = digest.digest();
                                Intrinsics.checkNotNullExpressionValue(bArrDigest2, "digest(...)");
/* 121 */                       return new BackupManifest((String) null, 0, exportedAt2, counts, j3, BoundedApkgKt.hex(bArrDigest2), scalar("SELECT count(*) FROM backup_objects"), scalar("SELECT COALESCE(sum(size),0) FROM backup_objects"), 3);
                            } catch (Throwable th8) {
                                th = th8;
                                throw th;
                            }
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX WARN: Code duplicated, block: B:42:0x0175 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:43:0x0176  */
                /* JADX WARN: Code duplicated, block: B:7:0x001a  */
/* 122 */       public final Object writeZip(BackupManifest manifest, Function2<? super AnkiMediaEntity, ? super Continuation<? super InputStream>, ? extends Object> function2, Continuation<? super File> continuation) throws Throwable {
                    C04261 c04261;
                    ZipOutputStream zipOutputStream;
                    Throwable th;
                    Closeable closeable;
                    File file;
                    Throwable th2;
                    Closeable closeable2;
                    Object objCopy;
                    ZipOutputStream zipOutputStream2;
                    int i;
                    Function2<? super AnkiMediaEntity, ? super Continuation<? super InputStream>, ? extends Object> function3;
                    BackupManifest manifest2;
                    Function2<? super AnkiMediaEntity, ? super Continuation<? super Unit>, ? extends Object> backupArchive$writeZip$2$4;
                    ZipOutputStream zipOutputStream3;
                    File file2;
                    if (continuation instanceof C04261) {
                        c04261 = (C04261) continuation;
                        if ((c04261.label & Integer.MIN_VALUE) != 0) {
                            c04261.label -= Integer.MIN_VALUE;
                        } else {
                            c04261 = new C04261(continuation);
                        }
                    } else {
                        c04261 = new C04261(continuation);
                    }
                    C04261 c04262 = c04261;
                    Object $result = c04262.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04262.label) {
                        case 0:
/* 123 */                   ResultKt.throwOnFailure($result);
/* 124 */                   File file3 = new File(this.directory, "backup.xunji.zip");
                            OutputStream fileOutputStream = new FileOutputStream(file3);
/* 125 */                   zipOutputStream = new ZipOutputStream(fileOutputStream instanceof BufferedOutputStream ? (BufferedOutputStream) fileOutputStream : new BufferedOutputStream(fileOutputStream, 65536));
                            try {
                                ZipOutputStream zipOutputStream4 = zipOutputStream;
/* 126 */                       ZipEntry zipEntry = new ZipEntry("manifest.json");
                                try {
/* 343 */                           zipEntry.setTime(0L);
                                    zipOutputStream4.putNextEntry(zipEntry);
                                    byte[] bytes = BackupCodec.INSTANCE.encodeManifest(manifest).getBytes(Charsets.UTF_8);
                                    Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                    zipOutputStream4.write(bytes);
                                    zipOutputStream4.closeEntry();
/* 127 */                           ZipEntry zipEntry2 = new ZipEntry("records.jsonl");
/* 127 */                           zipEntry2.setTime(0L);
                                    zipOutputStream4.putNextEntry(zipEntry2);
/* 128 */                           InputStream fileInputStream = new FileInputStream(new File(this.directory, "records.jsonl"));
                                    try {
                                        InputStream inputStream = (FileInputStream) fileInputStream;
/* 128 */                               InputStream inputStream2 = inputStream;
                                        ZipOutputStream zipOutputStream5 = zipOutputStream4;
                                        long recordsBytes = manifest.getRecordsBytes();
                                        c04262.L$0 = SpillingKt.nullOutSpilledVariable(manifest);
                                        try {
                                            c04262.L$1 = function2;
/* 126 */                                   file = file3;
                                            try {
                                                c04262.L$2 = file;
                                                c04262.L$3 = zipOutputStream;
                                                c04262.L$4 = zipOutputStream4;
                                                c04262.L$5 = fileInputStream;
                                                c04262.L$6 = SpillingKt.nullOutSpilledVariable(inputStream);
                                                c04262.I$0 = 0;
/* 343 */                                       c04262.I$1 = 0;
                                                c04262.label = 1;
                                                objCopy = copy(inputStream2, zipOutputStream5, recordsBytes, c04262);
                                                if (objCopy == coroutine_suspended) {
/* 123 */                                           return coroutine_suspended;
                                                }
/* 128 */                                       closeable2 = fileInputStream;
                                                zipOutputStream2 = zipOutputStream4;
                                                i = 0;
                                                function3 = function2;
                                                manifest2 = manifest;
                                                try {
                                                    try {
                                                        CloseableKt.closeFinally(closeable2, null);
                                                        zipOutputStream2.closeEntry();
/* 129 */                                               backupArchive$writeZip$2$4 = new BackupArchive$writeZip$2$4(zipOutputStream2, function3, this, null);
                                                        c04262.L$0 = SpillingKt.nullOutSpilledVariable(manifest2);
                                                        c04262.L$1 = SpillingKt.nullOutSpilledVariable(function3);
                                                        c04262.L$2 = file;
                                                        c04262.L$3 = zipOutputStream;
                                                        c04262.L$4 = zipOutputStream2;
                                                        c04262.L$5 = null;
                                                        c04262.L$6 = null;
                                                        c04262.I$0 = i;
                                                        c04262.label = 2;
                                                        if (objects(backupArchive$writeZip$2$4, c04262) == coroutine_suspended) {
/* 123 */                                                   return coroutine_suspended;
                                                        }
                                                        zipOutputStream3 = zipOutputStream2;
                                                        file2 = file;
                                                        closeable = zipOutputStream;
                                                        try {
/* 133 */                                                   zipOutputStream3.finish();
                                                            Unit unit = Unit.INSTANCE;
/* 125 */                                                   CloseableKt.closeFinally(closeable, null);
/* 135 */                                                   return file2;
                                                        } catch (Throwable th3) {
                                                            th = th3;
                                                            try {
                                                                throw th;
                                                            } catch (Throwable th4) {
                                                                CloseableKt.closeFinally(closeable, th);
                                                                throw th4;
                                                            }
                                                        }
                                                    } catch (Throwable th5) {
                                                        th = th5;
                                                        closeable = zipOutputStream;
                                                        throw th;
                                                    }
                                                } catch (Throwable th6) {
                                                    th2 = th6;
                                                    try {
                                                        throw th2;
                                                    } catch (Throwable th7) {
                                                        try {
                                                            CloseableKt.closeFinally(closeable2, th2);
                                                            throw th7;
                                                        } catch (Throwable th8) {
                                                            th = th8;
                                                            closeable = zipOutputStream;
                                                            throw th;
                                                        }
                                                    }
                                                }
                                            } catch (Throwable th9) {
                                                th2 = th9;
                                                closeable2 = fileInputStream;
                                                throw th2;
                                            }
                                        } catch (Throwable th10) {
                                            th = th10;
/* 126 */                                   file = file3;
                                            th2 = th;
                                            closeable2 = fileInputStream;
                                            throw th2;
                                        }
                                    } catch (Throwable th11) {
                                        th = th11;
                                    }
                                } catch (Throwable th12) {
                                    th = th12;
                                    closeable = zipOutputStream;
                                    throw th;
                                }
                            } catch (Throwable th13) {
                                th = th13;
                                closeable = zipOutputStream;
                            }
                            break;
                        case 1:
/* 123 */                   int i2 = c04262.I$1;
                            i = c04262.I$0;
                            closeable2 = (Closeable) c04262.L$5;
                            zipOutputStream2 = (ZipOutputStream) c04262.L$4;
                            Closeable closeable3 = (Closeable) c04262.L$3;
                            File file4 = (File) c04262.L$2;
                            function3 = (Function2) c04262.L$1;
                            manifest2 = (BackupManifest) c04262.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
                                file = file4;
                                zipOutputStream = closeable3;
                                objCopy = $result;
                                CloseableKt.closeFinally(closeable2, null);
                                zipOutputStream2.closeEntry();
/* 129 */                       backupArchive$writeZip$2$4 = new BackupArchive$writeZip$2$4(zipOutputStream2, function3, this, null);
                                c04262.L$0 = SpillingKt.nullOutSpilledVariable(manifest2);
                                c04262.L$1 = SpillingKt.nullOutSpilledVariable(function3);
                                c04262.L$2 = file;
                                c04262.L$3 = zipOutputStream;
                                c04262.L$4 = zipOutputStream2;
                                c04262.L$5 = null;
                                c04262.L$6 = null;
                                c04262.I$0 = i;
                                c04262.label = 2;
                                if (objects(backupArchive$writeZip$2$4, c04262) == coroutine_suspended) {
/* 123 */                           return coroutine_suspended;
                                }
                                zipOutputStream3 = zipOutputStream2;
                                file2 = file;
                                closeable = zipOutputStream;
/* 133 */                       zipOutputStream3.finish();
                                Unit unit2 = Unit.INSTANCE;
/* 125 */                       CloseableKt.closeFinally(closeable, null);
/* 135 */                       return file2;
                            } catch (Throwable th14) {
                                file = file4;
                                th2 = th14;
                                zipOutputStream = closeable3;
                                throw th2;
                            }
                        case 2:
                            int i3 = c04262.I$0;
                            zipOutputStream3 = (ZipOutputStream) c04262.L$4;
                            closeable = (Closeable) c04262.L$3;
                            file2 = (File) c04262.L$2;
                            Function2<? super AnkiMediaEntity, ? super Continuation<? super InputStream>, ? extends Object> function4 = (Function2) c04262.L$1;
                            try {
                                ResultKt.throwOnFailure($result);
                                function3 = function4;
/* 133 */                       zipOutputStream3.finish();
                                Unit unit3 = Unit.INSTANCE;
/* 125 */                       CloseableKt.closeFinally(closeable, null);
/* 135 */                       return file2;
                            } catch (Throwable th15) {
                                th = th15;
                                throw th;
                            }
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX WARN: Code duplicated, block: B:115:0x0562 A[Catch: all -> 0x0622, TRY_ENTER, TryCatch #1 {all -> 0x0622, blocks: (B:115:0x0562, B:117:0x056a, B:122:0x0579, B:123:0x057d, B:125:0x0583, B:141:0x0616, B:142:0x0621, B:149:0x0652, B:151:0x066c), top: B:289:0x0652 }] */
                /* JADX WARN: Code duplicated, block: B:117:0x056a A[Catch: all -> 0x0622, TryCatch #1 {all -> 0x0622, blocks: (B:115:0x0562, B:117:0x056a, B:122:0x0579, B:123:0x057d, B:125:0x0583, B:141:0x0616, B:142:0x0621, B:149:0x0652, B:151:0x066c), top: B:289:0x0652 }] */
                /* JADX WARN: Code duplicated, block: B:120:0x0575  */
                /* JADX WARN: Code duplicated, block: B:122:0x0579 A[Catch: all -> 0x0622, TryCatch #1 {all -> 0x0622, blocks: (B:115:0x0562, B:117:0x056a, B:122:0x0579, B:123:0x057d, B:125:0x0583, B:141:0x0616, B:142:0x0621, B:149:0x0652, B:151:0x066c), top: B:289:0x0652 }] */
                /* JADX WARN: Code duplicated, block: B:125:0x0583 A[Catch: all -> 0x0622, LOOP:0: B:123:0x057d->B:125:0x0583, LOOP_END, TRY_LEAVE, TryCatch #1 {all -> 0x0622, blocks: (B:115:0x0562, B:117:0x056a, B:122:0x0579, B:123:0x057d, B:125:0x0583, B:141:0x0616, B:142:0x0621, B:149:0x0652, B:151:0x066c), top: B:289:0x0652 }] */
                /* JADX WARN: Code duplicated, block: B:131:0x05a5  */
                /* JADX WARN: Code duplicated, block: B:133:0x05ef A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:134:0x05f0  */
                /* JADX WARN: Code duplicated, block: B:136:0x05fb  */
                /* JADX WARN: Code duplicated, block: B:140:0x0615  */
                /* JADX WARN: Code duplicated, block: B:145:0x063b  */
                /* JADX WARN: Code duplicated, block: B:151:0x066c A[Catch: all -> 0x0622, TRY_LEAVE, TryCatch #1 {all -> 0x0622, blocks: (B:115:0x0562, B:117:0x056a, B:122:0x0579, B:123:0x057d, B:125:0x0583, B:141:0x0616, B:142:0x0621, B:149:0x0652, B:151:0x066c), top: B:289:0x0652 }] */
                /* JADX WARN: Code duplicated, block: B:154:0x0674  */
                /* JADX WARN: Code duplicated, block: B:157:0x067b A[Catch: all -> 0x0abe, TRY_ENTER, TRY_LEAVE, TryCatch #26 {all -> 0x0abe, blocks: (B:113:0x0555, B:146:0x0648, B:157:0x067b, B:170:0x06f0), top: B:335:0x0555 }] */
                /* JADX WARN: Code duplicated, block: B:163:0x06ae  */
                /* JADX WARN: Code duplicated, block: B:166:0x06c6  */
                /* JADX WARN: Code duplicated, block: B:168:0x06c9 A[Catch: all -> 0x0a6b, TRY_ENTER, TRY_LEAVE, TryCatch #9 {all -> 0x0a6b, blocks: (B:158:0x069d, B:168:0x06c9), top: B:303:0x069d }] */
                /* JADX WARN: Code duplicated, block: B:185:0x07bc A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:186:0x07bd  */
                /* JADX WARN: Code duplicated, block: B:191:0x080b A[Catch: all -> 0x0898, TryCatch #39 {all -> 0x0898, blocks: (B:189:0x07fb, B:191:0x080b, B:193:0x083c, B:194:0x087c, B:195:0x0888, B:196:0x0889, B:197:0x0897), top: B:361:0x07fb }] */
                /* JADX WARN: Code duplicated, block: B:193:0x083c A[Catch: all -> 0x0898, TryCatch #39 {all -> 0x0898, blocks: (B:189:0x07fb, B:191:0x080b, B:193:0x083c, B:194:0x087c, B:195:0x0888, B:196:0x0889, B:197:0x0897), top: B:361:0x07fb }] */
                /* JADX WARN: Code duplicated, block: B:194:0x087c A[Catch: all -> 0x0898, TryCatch #39 {all -> 0x0898, blocks: (B:189:0x07fb, B:191:0x080b, B:193:0x083c, B:194:0x087c, B:195:0x0888, B:196:0x0889, B:197:0x0897), top: B:361:0x07fb }] */
                /* JADX WARN: Code duplicated, block: B:196:0x0889 A[Catch: all -> 0x0898, TryCatch #39 {all -> 0x0898, blocks: (B:189:0x07fb, B:191:0x080b, B:193:0x083c, B:194:0x087c, B:195:0x0888, B:196:0x0889, B:197:0x0897), top: B:361:0x07fb }] */
                /* JADX WARN: Code duplicated, block: B:223:0x0a47  */
                /* JADX WARN: Code duplicated, block: B:289:0x0652 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:315:0x06a8 A[EXC_TOP_SPLITTER, SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:7:0x001a  */
                /* JADX WARN: Multi-variable type inference failed */
                /* JADX WARN: Not initialized variable reg: 35, insn: 0x0bf9: MOVE (r2 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY]) = 
                  (r35 I:??[int, float, boolean, short, byte, char, OBJECT, ARRAY] A[D('$i$a$-use-BackupArchive$readZip$manifest$1\1\140\0' int)])
                , block:B:266:0x0bea */
                /* JADX WARN: Path cross not found for [B:355:0x04fe, B:109:0x051b], limit reached: 361 */
                /* JADX WARN: Type inference failed for: r10v35 */
                /* JADX WARN: Type inference failed for: r10v43, types: [java.lang.Object, kotlin.coroutines.CoroutineContext] */
                /* JADX WARN: Type inference failed for: r10v57 */
                /* JADX WARN: Type inference failed for: r14v10 */
                /* JADX WARN: Type inference failed for: r14v27 */
                /* JADX WARN: Type inference failed for: r14v8 */
                /* JADX WARN: Type inference failed for: r1v80 */
                /* JADX WARN: Type inference failed for: r20v0 */
                /* JADX WARN: Type inference failed for: r20v1 */
                /* JADX WARN: Type inference failed for: r20v2 */
                /* JADX WARN: Type inference failed for: r20v3 */
                /* JADX WARN: Type inference failed for: r27v15 */
                /* JADX WARN: Type inference failed for: r27v18 */
                /* JADX WARN: Type inference failed for: r27v19 */
                /* JADX WARN: Type inference failed for: r27v21 */
                /* JADX WARN: Type inference failed for: r29v33 */
                /* JADX WARN: Type inference failed for: r29v35 */
                /* JADX WARN: Type inference failed for: r29v36 */
                /* JADX WARN: Type inference failed for: r29v37 */
                /* JADX WARN: Type inference failed for: r29v41 */
                /* JADX WARN: Type inference failed for: r2v39 */
                /* JADX WARN: Type inference failed for: r2v42 */
                /* JADX WARN: Type inference failed for: r2v44, types: [com.xunji.flashcards.backup.BackupArchive$readZip$manifest$1$tee$1, java.lang.Object] */
                /* JADX WARN: Type inference failed for: r2v55 */
                /* JADX WARN: Type inference failed for: r2v59 */
                /* JADX WARN: Type inference failed for: r2v63 */
                /* JADX WARN: Type inference failed for: r31v0 */
                /* JADX WARN: Type inference failed for: r31v1 */
                /* JADX WARN: Type inference failed for: r31v15 */
                /* JADX WARN: Type inference failed for: r31v16 */
                /* JADX WARN: Type inference failed for: r31v18 */
                /* JADX WARN: Type inference failed for: r31v19 */
                /* JADX WARN: Type inference failed for: r31v2 */
                /* JADX WARN: Type inference failed for: r31v20 */
                /* JADX WARN: Type inference failed for: r31v24 */
                /* JADX WARN: Type inference failed for: r31v29 */
                /* JADX WARN: Type inference failed for: r31v30 */
                /* JADX WARN: Type inference failed for: r31v31 */
                /* JADX WARN: Type inference failed for: r31v32 */
                /* JADX WARN: Type inference failed for: r31v33 */
                /* JADX WARN: Type inference failed for: r31v34 */
                /* JADX WARN: Type inference failed for: r31v35 */
                /* JADX WARN: Type inference failed for: r31v36 */
                /* JADX WARN: Type inference failed for: r31v37 */
                /* JADX WARN: Type inference failed for: r31v38 */
                /* JADX WARN: Type inference failed for: r31v5 */
                /* JADX WARN: Type inference failed for: r31v6 */
                /* JADX WARN: Type inference failed for: r31v7 */
                /* JADX WARN: Type inference failed for: r32v0 */
                /* JADX WARN: Type inference failed for: r32v1 */
                /* JADX WARN: Type inference failed for: r32v14 */
                /* JADX WARN: Type inference failed for: r32v15 */
                /* JADX WARN: Type inference failed for: r32v16 */
                /* JADX WARN: Type inference failed for: r32v17 */
                /* JADX WARN: Type inference failed for: r32v18 */
                /* JADX WARN: Type inference failed for: r32v2 */
                /* JADX WARN: Type inference failed for: r32v38 */
                /* JADX WARN: Type inference failed for: r32v42 */
                /* JADX WARN: Type inference failed for: r32v43 */
                /* JADX WARN: Type inference failed for: r32v44 */
                /* JADX WARN: Type inference failed for: r32v45 */
                /* JADX WARN: Type inference failed for: r32v46 */
                /* JADX WARN: Type inference failed for: r32v47 */
                /* JADX WARN: Type inference failed for: r32v48 */
                /* JADX WARN: Type inference failed for: r32v49 */
                /* JADX WARN: Type inference failed for: r32v5 */
                /* JADX WARN: Type inference failed for: r32v50 */
                /* JADX WARN: Type inference failed for: r32v51 */
                /* JADX WARN: Type inference failed for: r32v6 */
                /* JADX WARN: Type inference failed for: r32v7 */
                /* JADX WARN: Type inference failed for: r37v0 */
                /* JADX WARN: Type inference failed for: r37v13 */
                /* JADX WARN: Type inference failed for: r37v2 */
                /* JADX WARN: Type inference failed for: r37v3 */
                /* JADX WARN: Type inference failed for: r37v4 */
                /* JADX WARN: Type inference failed for: r37v5 */
                /* JADX WARN: Type inference failed for: r37v6 */
                /* JADX WARN: Type inference failed for: r37v7 */
                /* JADX WARN: Type inference failed for: r37v9 */
                /* JADX WARN: Type inference failed for: r39v0 */
                /* JADX WARN: Type inference failed for: r39v1 */
                /* JADX WARN: Type inference failed for: r39v10 */
                /* JADX WARN: Type inference failed for: r39v11 */
                /* JADX WARN: Type inference failed for: r39v12 */
                /* JADX WARN: Type inference failed for: r39v13 */
                /* JADX WARN: Type inference failed for: r39v14 */
                /* JADX WARN: Type inference failed for: r39v15 */
                /* JADX WARN: Type inference failed for: r39v16 */
                /* JADX WARN: Type inference failed for: r39v2, types: [java.lang.Object] */
                /* JADX WARN: Type inference failed for: r39v5 */
                /* JADX WARN: Type inference failed for: r39v6 */
                /* JADX WARN: Type inference failed for: r3v30 */
                /* JADX WARN: Type inference failed for: r3v35 */
                /* JADX WARN: Type inference failed for: r3v36, types: [com.xunji.flashcards.backup.BackupArchive] */
                /* JADX WARN: Type inference failed for: r3v37 */
                /* JADX WARN: Type inference failed for: r3v58 */
                /* JADX WARN: Type inference failed for: r3v60, types: [com.xunji.flashcards.backup.BackupArchive] */
                /* JADX WARN: Type inference failed for: r3v63 */
                /* JADX WARN: Type inference failed for: r3v66 */
                /* JADX WARN: Type inference failed for: r41v0 */
                /* JADX WARN: Type inference failed for: r41v11 */
                /* JADX WARN: Type inference failed for: r41v13 */
                /* JADX WARN: Type inference failed for: r41v15 */
                /* JADX WARN: Type inference failed for: r41v17 */
                /* JADX WARN: Type inference failed for: r41v18 */
                /* JADX WARN: Type inference failed for: r41v19 */
                /* JADX WARN: Type inference failed for: r41v22 */
                /* JADX WARN: Type inference failed for: r41v23 */
                /* JADX WARN: Type inference failed for: r41v24 */
                /* JADX WARN: Type inference failed for: r41v7 */
                /* JADX WARN: Type inference failed for: r41v9 */
                /* JADX WARN: Type inference failed for: r42v0 */
                /* JADX WARN: Type inference failed for: r42v10 */
                /* JADX WARN: Type inference failed for: r42v11 */
                /* JADX WARN: Type inference failed for: r42v12 */
                /* JADX WARN: Type inference failed for: r42v13 */
                /* JADX WARN: Type inference failed for: r42v14 */
                /* JADX WARN: Type inference failed for: r42v15 */
                /* JADX WARN: Type inference failed for: r42v16 */
                /* JADX WARN: Type inference failed for: r42v17 */
                /* JADX WARN: Type inference failed for: r42v18 */
                /* JADX WARN: Type inference failed for: r42v19 */
                /* JADX WARN: Type inference failed for: r42v2 */
                /* JADX WARN: Type inference failed for: r42v20 */
                /* JADX WARN: Type inference failed for: r42v21 */
                /* JADX WARN: Type inference failed for: r42v22 */
                /* JADX WARN: Type inference failed for: r42v25 */
                /* JADX WARN: Type inference failed for: r42v26 */
                /* JADX WARN: Type inference failed for: r42v27 */
                /* JADX WARN: Type inference failed for: r42v3 */
                /* JADX WARN: Type inference failed for: r42v4 */
                /* JADX WARN: Type inference failed for: r42v9 */
                /* JADX WARN: Type inference failed for: r47v0 */
                /* JADX WARN: Type inference failed for: r47v10, types: [com.xunji.flashcards.backup.BackupArchive] */
                /* JADX WARN: Type inference failed for: r47v11 */
                /* JADX WARN: Type inference failed for: r47v12 */
                /* JADX WARN: Type inference failed for: r47v13 */
                /* JADX WARN: Type inference failed for: r47v14 */
                /* JADX WARN: Type inference failed for: r47v15 */
                /* JADX WARN: Type inference failed for: r47v16 */
                /* JADX WARN: Type inference failed for: r47v17 */
                /* JADX WARN: Type inference failed for: r47v18 */
                /* JADX WARN: Type inference failed for: r47v19 */
                /* JADX WARN: Type inference failed for: r47v2 */
                /* JADX WARN: Type inference failed for: r47v20 */
                /* JADX WARN: Type inference failed for: r47v3 */
                /* JADX WARN: Type inference failed for: r47v4 */
                /* JADX WARN: Type inference failed for: r47v9 */
                /* JADX WARN: Type inference failed for: r4v15 */
                /* JADX WARN: Type inference failed for: r4v18, types: [java.io.Closeable, java.lang.Object] */
                /* JADX WARN: Type inference failed for: r4v33 */
                /* JADX WARN: Type inference failed for: r50v1 */
                /* JADX WARN: Type inference failed for: r50v10 */
                /* JADX WARN: Type inference failed for: r50v11 */
                /* JADX WARN: Type inference failed for: r50v12 */
                /* JADX WARN: Type inference failed for: r50v2 */
                /* JADX WARN: Type inference failed for: r50v3 */
                /* JADX WARN: Type inference failed for: r50v9 */
                /* JADX WARN: Type inference failed for: r59v2 */
                /* JADX WARN: Type inference failed for: r59v3 */
                /* JADX WARN: Type inference failed for: r59v5 */
                /* JADX WARN: Type inference failed for: r8v11 */
                /* JADX WARN: Type inference failed for: r8v12, types: [java.io.Closeable] */
                /* JADX WARN: Type inference failed for: r8v20 */
                /* JADX WARN: Type inference failed for: r8v26 */
                /* JADX WARN: Type inference failed for: r8v27 */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:186:0x07bd -> B:319:0x07f8). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
/* 136 */       public final java.lang.Object readZip(final java.io.InputStream r58, kotlin.coroutines.Continuation<? super com.xunji.core.backup.BackupManifest> r59) {
                    /*
                        Method dump skipped, instruction units count: 3216
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive.readZip(java.io.InputStream, kotlin.coroutines.Continuation):java.lang.Object");
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 215 */       public static final boolean readZip$lambda$1(BackupArchive this$0, String name) {
                    Intrinsics.checkNotNullParameter(name, "name");
/* 216 */           SupportSQLiteStatement supportSQLiteStatementCompileStatement = this$0.getSql().compileStatement("UPDATE backup_zip_entries SET seen=1 WHERE name=? AND seen=0");
                    try {
                        SupportSQLiteStatement supportSQLiteStatement = supportSQLiteStatementCompileStatement;
/* 216 */               supportSQLiteStatement.bindString(1, name);
/* 216 */               boolean z = supportSQLiteStatement.executeUpdateDelete() == 1;
                        CloseableKt.closeFinally(supportSQLiteStatementCompileStatement, null);
                        return z;
                    } catch (Throwable th) {
                        try {
                            throw th;
                        } catch (Throwable th2) {
                            CloseableKt.closeFinally(supportSQLiteStatementCompileStatement, th);
                            throw th2;
                        }
                    }
                }

/* 222 */       private final void saveZipEntry(ZipEntry entry) {
                    if (!(entry.getSize() >= 0 && entry.getCompressedSize() >= 0 && entry.getCrc() >= 0)) {
                        throw new IllegalArgumentException("Incomplete ZIP entry".toString());
                    }
/* 224 */           SupportSQLiteDatabase sql = getSql();
                    String name = entry.getName();
                    Intrinsics.checkNotNullExpressionValue(name, "getName(...)");
                    sql.execSQL("INSERT INTO backup_zip_entries(name,size,compressedSize,crc,method) VALUES(?,?,?,?,?)", new Object[]{name, Long.valueOf(entry.getSize()), Long.valueOf(entry.getCompressedSize()), Long.valueOf(entry.getCrc()), Integer.valueOf(entry.getMethod())});
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$zipRecords$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(d1 = {"\u0000'\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\u0010&\n\u0002\b\u0007*\u0001\u0000\b\n\u0018\u00002\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\u0001J\u0013\u0010\u000f\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0010\u001a\u00020\u0002H\u0096\u0002R\u0014\u0010\u0004\u001a\u00020\u00058VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007R&\u0010\b\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0002\u0012\u0004\u0012\u00020\u00030\n0\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000b\u0010\fR\u001a\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00020\t8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b\u000e\u0010\f¨\u0006\u0011"}, d2 = {"com/xunji/flashcards/backup/BackupArchive$zipRecords$1", "Lkotlin/collections/AbstractMap;", "", "Lcom/xunji/flashcards/anki/ZipRecord;", "size", "", "getSize", "()I", "entries", "", "", "getEntries", "()Ljava/util/Set;", "keys", "getKeys", "get", "key", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 225 */       public static final class C04271 extends AbstractMap<String, ZipRecord> {
/* 226 */           C04271() {
                    }

                    @Override // kotlin.collections.AbstractMap, java.util.Map
/* 226 */           public final /* bridge */ boolean containsKey(Object key) {
/* 227 */               if (key instanceof String) {
                            return containsKey((String) key);
                        }
                        return false;
                    }

/* 226 */           public /* bridge */ boolean containsKey(String key) {
/* 227 */               return super.containsKey((Object) key);
                    }

/* 226 */           public /* bridge */ boolean containsValue(ZipRecord value) {
/* 227 */               return super.containsValue((Object) value);
                    }

                    @Override // kotlin.collections.AbstractMap, java.util.Map
/* 226 */           public final /* bridge */ boolean containsValue(Object value) {
/* 227 */               if (value instanceof ZipRecord) {
                            return containsValue((ZipRecord) value);
                        }
                        return false;
                    }

                    @Override // kotlin.collections.AbstractMap, java.util.Map
/* 226 */           public final /* bridge */ ZipRecord get(Object key) {
/* 227 */               if (key instanceof String) {
                            return get((String) key);
                        }
                        return null;
                    }

                    @Override // kotlin.collections.AbstractMap, java.util.Map
/* 226 */           public final /* bridge */ /* synthetic */ Object get(Object key) {
/* 227 */               if (key instanceof String) {
                            return get((String) key);
                        }
                        return null;
                    }

/* 226 */           public final /* bridge */ ZipRecord getOrDefault(Object key, ZipRecord defaultValue) {
                        return !(key instanceof String) ? defaultValue : getOrDefault((String) key, defaultValue);
                    }

/* 226 */           public /* bridge */ ZipRecord getOrDefault(String key, ZipRecord defaultValue) {
/* 227 */               return (ZipRecord) super.getOrDefault((Object) key, defaultValue);
                    }

                    @Override // java.util.Map
/* 226 */           public final /* bridge */ /* synthetic */ Object getOrDefault(Object key, Object defaultValue) {
                        return !(key instanceof String) ? defaultValue : getOrDefault((String) key, (ZipRecord) defaultValue);
                    }

                    @Override // kotlin.collections.AbstractMap
/* 227 */           public int getSize() {
/* 18 */                return (int) BackupArchive.this.scalar("SELECT count(*) FROM backup_zip_entries");
                    }

                    @Override // kotlin.collections.AbstractMap, androidx.compose.runtime.external.kotlinx.collections.immutable.ImmutableMap
/* 228 */           public Set<Map.Entry<String, ZipRecord>> getEntries() {
/* 229 */               throw new IllegalStateException("ZIP metadata is disk-backed".toString());
                    }

                    @Override // kotlin.collections.AbstractMap, androidx.compose.runtime.external.kotlinx.collections.immutable.ImmutableMap
/* 229 */           public Set<String> getKeys() {
                        final BackupArchive backupArchive = BackupArchive.this;
/* 230 */               return new AbstractSet<String>() { // from class: com.xunji.flashcards.backup.BackupArchive$zipRecords$1$keys$1
                            @Override // kotlin.collections.AbstractCollection, java.util.Collection, java.util.List
/* 229 */                   public final /* bridge */ boolean contains(Object element) {
/* 230 */                       if (element instanceof String) {
                                    return contains((String) element);
                                }
                                return false;
                            }

                            @Override // kotlin.collections.AbstractCollection
/* 230 */                   public int getSize() {
/* 18 */                        return (int) backupArchive.scalar("SELECT count(*) FROM backup_zip_entries");
                            }

/* 231 */                   public boolean contains(String element) {
                                Intrinsics.checkNotNullParameter(element, "element");
                                return this.get((Object) element) != null;
                            }

                            @Override // kotlin.collections.AbstractSet, kotlin.collections.AbstractCollection, java.util.Collection, java.lang.Iterable, java.util.List
/* 232 */                   public Iterator<String> iterator() {
/* 233 */                       throw new IllegalStateException("ZIP metadata is disk-backed".toString());
                            }
                        };
                    }

/* 234 */           public ZipRecord get(String key) {
                        Intrinsics.checkNotNullParameter(key, "key");
/* 18 */                Cursor cursorQuery = BackupArchive.this.getSql().query("SELECT size,compressedSize,crc,method FROM backup_zip_entries WHERE name=?", new String[]{key});
                        try {
                            Cursor cursor = cursorQuery;
/* 236 */                   ZipRecord zipRecord = cursor.moveToFirst() ? new ZipRecord(cursor.getLong(0), cursor.getLong(1), cursor.getLong(2), cursor.getInt(3)) : null;
/* 235 */                   CloseableKt.closeFinally(cursorQuery, null);
/* 237 */                   return zipRecord;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(cursorQuery, th);
                                throw th2;
                            }
                        }
                    }
                }

/* 226 */       private final Map<String, ZipRecord> zipRecords() {
/* 227 */           return new C04271();
                }

                /* JADX WARN: Code duplicated, block: B:24:0x0080  */
                /* JADX WARN: Code duplicated, block: B:26:0x0083  */
                /* JADX WARN: Code duplicated, block: B:28:0x0098 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:34:0x00b4 A[Catch: all -> 0x0120, TRY_ENTER, TryCatch #0 {all -> 0x0120, blocks: (B:30:0x00a8, B:31:0x00ac, B:34:0x00b4, B:37:0x00cf, B:40:0x00dd, B:41:0x00e8, B:42:0x00e9, B:43:0x00f4, B:44:0x00fb), top: B:64:0x00a8 }] */
                /* JADX WARN: Code duplicated, block: B:36:0x00cd A[DONT_INVERT] */
                /* JADX WARN: Code duplicated, block: B:37:0x00cf A[Catch: all -> 0x0120, TryCatch #0 {all -> 0x0120, blocks: (B:30:0x00a8, B:31:0x00ac, B:34:0x00b4, B:37:0x00cf, B:40:0x00dd, B:41:0x00e8, B:42:0x00e9, B:43:0x00f4, B:44:0x00fb), top: B:64:0x00a8 }] */
                /* JADX WARN: Code duplicated, block: B:39:0x00dc  */
                /* JADX WARN: Code duplicated, block: B:47:0x0103  */
                /* JADX WARN: Code duplicated, block: B:50:0x0111  */
                /* JADX WARN: Code duplicated, block: B:60:0x012a  */
                /* JADX WARN: Code duplicated, block: B:68:0x00dd A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:70:0x00f4 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 238 */       public final Object validateDatabase(Continuation<? super Unit> continuation) throws Throwable {
                    C04251 c04251;
                    Object objModelStorageBytes;
                    AnonymousClass4 anonymousClass4;
                    Object namespace;
                    MediaStore.Companion.NamespaceDigest namespaceDigest;
                    Cursor cursorQuery;
                    Cursor cursor;
                    AnkiMediaEntity ankiMediaEntityMedia;
                    if (continuation instanceof C04251) {
                        c04251 = (C04251) continuation;
                        if ((c04251.label & Integer.MIN_VALUE) != 0) {
                            c04251.label -= Integer.MIN_VALUE;
                        } else {
                            c04251 = new C04251(continuation);
                        }
                    } else {
                        c04251 = new C04251(continuation);
                    }
                    C04251 c04252 = c04251;
                    Object $result = c04252.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04252.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 240 */                   requireEmpty("PRAGMA foreign_key_check", "Invalid backup foreign key");
/* 241 */                   requireEmpty("SELECT id FROM cards WHERE id NOT IN (SELECT cardId FROM schedules)", "Missing schedule");
/* 242 */                   requireEmpty("SELECT r.id FROM review_logs r JOIN cards c ON c.id=r.cardId WHERE r.deckId<>c.deckId", "Log/deck mismatch");
                            if (!(scalar("SELECT count(*) FROM settings WHERE id=0") == 1)) {
                                throw new IllegalArgumentException("Missing settings".toString());
                            }
/* 244 */                   AnkiDao ankiDao = this.db.ankiDao();
                            c04252.label = 1;
                            objModelStorageBytes = ankiDao.modelStorageBytes(c04252);
                            if (objModelStorageBytes == coroutine_suspended) {
/* 239 */                       return coroutine_suspended;
                            }
/* 244 */                   if (((Number) objModelStorageBytes).longValue() <= 33554432) {
                                throw new IllegalArgumentException("Stored model collection exceeds 32 MiB".toString());
                            }
/* 245 */                   anonymousClass4 = new AnonymousClass4(null);
                            c04252.label = 2;
                            if (forEachRecord$default(this, null, anonymousClass4, c04252, 1, null) == coroutine_suspended) {
/* 239 */                       return coroutine_suspended;
                            }
/* 293 */                   namespace = null;
                            namespaceDigest = null;
/* 294 */                   cursorQuery = getSql().query("SELECT m.* FROM anki_media m JOIN backup_media_order o ON m.namespace=o.namespace AND m.originalName=o.originalName ORDER BY o.namespace,o.sortKey");
                            try {
                                cursor = cursorQuery;
/* 295 */                       while (cursor.moveToNext()) {
/* 296 */                           JobKt.ensureActive(c04252.getContext());
/* 1 */                             ankiMediaEntityMedia = BackupArchiveKt.media(jsonRow(cursor));
/* 297 */                           if (!Intrinsics.areEqual(namespace, ankiMediaEntityMedia.getNamespace())) {
/* 298 */                               if (namespace != null) {
                                            Intrinsics.checkNotNull(namespaceDigest);
                                            if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                                throw new IllegalArgumentException("Media namespace digest differs".toString());
                                            }
                                        }
/* 299 */                               namespace = ankiMediaEntityMedia.getNamespace();
                                        namespaceDigest = new MediaStore.Companion.NamespaceDigest();
                                    }
/* 301 */                           Intrinsics.checkNotNull(namespaceDigest);
                                    namespaceDigest.add(ankiMediaEntityMedia);
                                }
                                Unit unit = Unit.INSTANCE;
/* 294 */                       CloseableKt.closeFinally(cursorQuery, null);
/* 304 */                       if (namespace != null) {
                                    Intrinsics.checkNotNull(namespaceDigest);
                                    if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                        throw new IllegalArgumentException("Media namespace digest differs".toString());
                                    }
                                }
/* 305 */                       return Unit.INSTANCE;
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    CloseableKt.closeFinally(cursorQuery, th);
                                    throw th2;
                                }
                            }
                        case 1:
                            ResultKt.throwOnFailure($result);
                            objModelStorageBytes = $result;
/* 244 */                   if (((Number) objModelStorageBytes).longValue() <= 33554432) {
                                throw new IllegalArgumentException("Stored model collection exceeds 32 MiB".toString());
                            }
/* 245 */                   anonymousClass4 = new AnonymousClass4(null);
                            c04252.label = 2;
                            if (forEachRecord$default(this, null, anonymousClass4, c04252, 1, null) == coroutine_suspended) {
/* 239 */                       return coroutine_suspended;
                            }
/* 293 */                   namespace = null;
                            namespaceDigest = null;
/* 294 */                   cursorQuery = getSql().query("SELECT m.* FROM anki_media m JOIN backup_media_order o ON m.namespace=o.namespace AND m.originalName=o.originalName ORDER BY o.namespace,o.sortKey");
                            cursor = cursorQuery;
/* 295 */                   while (cursor.moveToNext()) {
/* 296 */                       JobKt.ensureActive(c04252.getContext());
/* 1 */                         ankiMediaEntityMedia = BackupArchiveKt.media(jsonRow(cursor));
/* 297 */                       if (!Intrinsics.areEqual(namespace, ankiMediaEntityMedia.getNamespace())) {
/* 298 */                           if (namespace != null) {
                                        Intrinsics.checkNotNull(namespaceDigest);
                                        if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                            throw new IllegalArgumentException("Media namespace digest differs".toString());
                                        }
                                    }
/* 299 */                           namespace = ankiMediaEntityMedia.getNamespace();
                                    namespaceDigest = new MediaStore.Companion.NamespaceDigest();
                                }
/* 301 */                       Intrinsics.checkNotNull(namespaceDigest);
                                namespaceDigest.add(ankiMediaEntityMedia);
                            }
                            Unit unit2 = Unit.INSTANCE;
/* 294 */                   CloseableKt.closeFinally(cursorQuery, null);
/* 304 */                   if (namespace != null) {
                                Intrinsics.checkNotNull(namespaceDigest);
                                if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                    throw new IllegalArgumentException("Media namespace digest differs".toString());
                                }
                            }
/* 305 */                   return Unit.INSTANCE;
                        case 2:
                            ResultKt.throwOnFailure($result);
/* 293 */                   namespace = null;
                            namespaceDigest = null;
/* 294 */                   cursorQuery = getSql().query("SELECT m.* FROM anki_media m JOIN backup_media_order o ON m.namespace=o.namespace AND m.originalName=o.originalName ORDER BY o.namespace,o.sortKey");
                            cursor = cursorQuery;
/* 295 */                   while (cursor.moveToNext()) {
/* 296 */                       JobKt.ensureActive(c04252.getContext());
/* 1 */                         ankiMediaEntityMedia = BackupArchiveKt.media(jsonRow(cursor));
/* 297 */                       if (!Intrinsics.areEqual(namespace, ankiMediaEntityMedia.getNamespace())) {
/* 298 */                           if (namespace != null) {
                                        Intrinsics.checkNotNull(namespaceDigest);
                                        if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                            throw new IllegalArgumentException("Media namespace digest differs".toString());
                                        }
                                    }
/* 299 */                           namespace = ankiMediaEntityMedia.getNamespace();
                                    namespaceDigest = new MediaStore.Companion.NamespaceDigest();
                                }
/* 301 */                       Intrinsics.checkNotNull(namespaceDigest);
                                namespaceDigest.add(ankiMediaEntityMedia);
                            }
                            Unit unit3 = Unit.INSTANCE;
/* 294 */                   CloseableKt.closeFinally(cursorQuery, null);
/* 304 */                   if (namespace != null) {
                                Intrinsics.checkNotNull(namespaceDigest);
                                if (!Intrinsics.areEqual(namespaceDigest.finish(), namespace)) {
                                    throw new IllegalArgumentException("Media namespace digest differs".toString());
                                }
                            }
/* 305 */                   return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupArchive$validateDatabase$4, reason: invalid class name */
                /* JADX INFO: compiled from: BackupArchive.kt */
                @Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\n"}, d2 = {"<anonymous>", "", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "", "row", "Lkotlinx/serialization/json/JsonObject;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupArchive$validateDatabase$4", f = "BackupArchive.kt", i = {0, 0, 0, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6}, l = {262, 267, 268, 271, 271, 287, 288}, m = "invokeSuspend", n = {ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", "m", "ordinal", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", "m", "card", "ordinal", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", "m", "card", "deck", "names", "context", "side", "rendered", "$this$forEach\\17", "element\\17", "it\\18", "ordinal", "$i$f$forEach\\17\\287", "$i$a$-forEach-BackupArchive$validateDatabase$4$9\\18\\349\\0", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "row", "n", "m", "card", "deck", "names", "context", "side", "rendered", "$this$forEach\\19", "element\\19", "it\\20", "ordinal", "$i$f$forEach\\19\\288", "$i$a$-forEach-BackupArchive$validateDatabase$4$10\\20\\351\\0"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$9", "L$10", "L$11", "L$14", "L$15", "I$0", "I$1", "I$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$7", "L$9", "L$10", "L$11", "L$14", "L$15", "I$0", "I$1", "I$2"}, v = 1)
/* 243 */       static final class AnonymousClass4 extends SuspendLambda implements Function3<String, JsonObject, Continuation<? super Unit>, Object> {
                    int I$0;
                    int I$1;
                    int I$2;
                    /* synthetic */ Object L$0;
                    /* synthetic */ Object L$1;
                    Object L$10;
                    Object L$11;
                    Object L$12;
                    Object L$13;
                    Object L$14;
                    Object L$15;
                    Object L$16;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    Object L$7;
                    Object L$8;
                    Object L$9;
                    int label;

                    AnonymousClass4(Continuation<? super AnonymousClass4> continuation) {
                        super(3, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(String str, JsonObject jsonObject, Continuation<? super Unit> continuation) {
                        AnonymousClass4 anonymousClass4 = BackupArchive.this.new AnonymousClass4(continuation);
                        anonymousClass4.L$0 = str;
                        anonymousClass4.L$1 = jsonObject;
                        return anonymousClass4.invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:121:0x044c  */
                    /* JADX WARN: Code duplicated, block: B:123:0x04c4 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:124:0x04c5  */
                    /* JADX WARN: Code duplicated, block: B:127:0x04e6  */
                    /* JADX WARN: Code duplicated, block: B:128:0x04eb  */
                    /* JADX WARN: Code duplicated, block: B:131:0x04f5  */
                    /* JADX WARN: Code duplicated, block: B:203:0x073f  */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:131:0x04f5 -> B:119:0x0446). Please report as a decompilation issue!!! */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:134:0x0517 -> B:135:0x053c). Please report as a decompilation issue!!! */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:140:0x05bf -> B:141:0x05d1). Please report as a decompilation issue!!! */
                    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                        */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 244 */           public final java.lang.Object invokeSuspend(java.lang.Object r27) {
                        /*
                            Method dump skipped, instruction units count: 1926
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive.AnonymousClass4.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 306 */       public final Object readBounded(InputStream input, int maximum, Continuation<? super byte[]> continuation) throws IOException {
/* 307 */           ByteArrayOutputStream output = new ByteArrayOutputStream();
                    byte[] buffer = new byte[8192];
                    while (true) {
/* 308 */               JobKt.ensureActive(continuation.getContext());
                        int n = input.read(buffer);
                        if (n < 0) {
/* 309 */                   byte[] byteArray = output.toByteArray();
                            Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                            return byteArray;
                        }
                        if (n != 0) {
                            if (!(((long) output.size()) + ((long) n) <= ((long) maximum))) {
                                throw new IllegalArgumentException("Manifest exceeds 1 MiB".toString());
                            }
                            output.write(buffer, 0, n);
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 312 */       public final Object readChunk(InputStream input, byte[] buffer, Continuation<? super Integer> continuation) throws IOException {
/* 313 */           int total = 0;
/* 314 */           while (total < buffer.length) {
/* 315 */               JobKt.ensureActive(continuation.getContext());
/* 316 */               int n = input.read(buffer, total, buffer.length - total);
/* 317 */               if (n < 0) {
                            return Boxing.boxInt(total == 0 ? -1 : total);
                        }
/* 318 */               if (n > 0) {
                            total += n;
                        }
                    }
/* 320 */           return Boxing.boxInt(total);
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:16:0x0099 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:17:0x009a  */
                /* JADX WARN: Code duplicated, block: B:20:0x00ab A[DONT_INVERT] */
                /* JADX WARN: Code duplicated, block: B:21:0x00ad  */
                /* JADX WARN: Code duplicated, block: B:23:0x00b8  */
                /* JADX WARN: Code duplicated, block: B:24:0x00ba  */
                /* JADX WARN: Code duplicated, block: B:26:0x00bd  */
                /* JADX WARN: Code duplicated, block: B:27:0x00cc  */
                /* JADX WARN: Code duplicated, block: B:29:0x00da  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x009a -> B:18:0x00a2). Please report as a decompilation issue!!! */
                /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                    jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    */
/* 321 */       public final java.lang.Object copy(java.io.InputStream r19, java.io.OutputStream r20, long r21, kotlin.coroutines.Continuation<? super kotlin.Pair<java.lang.Long, java.lang.String>> r23) {
                    /*
                        Method dump skipped, instruction units count: 282
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupArchive.copy(java.io.InputStream, java.io.OutputStream, long, kotlin.coroutines.Continuation):java.lang.Object");
                }
            }

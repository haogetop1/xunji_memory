            package com.xunji.flashcards.backup;

            import androidx.autofill.HintConstants;
            import androidx.collection.SieveCacheKt;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.AnkiModelEntity;
            import com.xunji.flashcards.data.AnkiNoteEntity;
            import com.xunji.flashcards.data.CardEntity;
            import com.xunji.flashcards.data.DeckEntity;
            import com.xunji.flashcards.data.ReviewLogEntity;
            import com.xunji.flashcards.data.ScheduleEntity;
            import com.xunji.flashcards.data.SettingsEntity;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.MapsKt;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.JsonNull;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonPrimitive;
            
            /* JADX INFO: compiled from: BackupArchive.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000T\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u001a\u0014\u0010\u0000\u001a\u00020\u0001*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\u0014\u0010\u0004\u001a\u00020\u0005*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\u0014\u0010\u0006\u001a\u00020\u0007*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002\u001a\u001b\u0010\b\u001a\u0004\u0018\u00010\u0005*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002¢\u0006\u0002\u0010\t\u001a\u001b\u0010\n\u001a\u0004\u0018\u00010\u000b*\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0001H\u0002¢\u0006\u0002\u0010\f\u001a\f\u0010\r\u001a\u00020\u000e*\u00020\u0002H\u0002\u001a\f\u0010\u000f\u001a\u00020\u0010*\u00020\u0002H\u0002\u001a\f\u0010\u0011\u001a\u00020\u0012*\u00020\u0002H\u0002\u001a\f\u0010\u0013\u001a\u00020\u0014*\u00020\u0002H\u0002\u001a\f\u0010\u0015\u001a\u00020\u0016*\u00020\u0002H\u0002\u001a\f\u0010\u0017\u001a\u00020\u0018*\u00020\u0002H\u0002\u001a\f\u0010\u0019\u001a\u00020\u001a*\u00020\u0002H\u0002\u001a\f\u0010\u001b\u001a\u00020\u001c*\u00020\u0002H\u0002¨\u0006\u001d"}, d2 = {"text", "", "Lkotlinx/serialization/json/JsonObject;", "key", "long", "", "int", "", "nullLong", "(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Ljava/lang/Long;", "nullDouble", "", "(Lkotlinx/serialization/json/JsonObject;Ljava/lang/String;)Ljava/lang/Double;", "deck", "Lcom/xunji/flashcards/data/DeckEntity;", "card", "Lcom/xunji/flashcards/data/CardEntity;", "schedule", "Lcom/xunji/flashcards/data/ScheduleEntity;", "log", "Lcom/xunji/flashcards/data/ReviewLogEntity;", "settings", "Lcom/xunji/flashcards/data/SettingsEntity;", "model", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "note", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 327 */   public final class BackupArchiveKt {
                /* JADX INFO: Access modifiers changed from: private */
/* 328 */       public static final String text(JsonObject $this$text, String key) {
/* 329 */           JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive((JsonElement) MapsKt.getValue($this$text, key));
/* 329 */           if (jsonPrimitive.isString()) {
                        return jsonPrimitive.getContent();
                    }
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX INFO: renamed from: long, reason: not valid java name */
/* 329 */       public static final long m8916long(JsonObject $this$long, String key) {
/* 330 */           JsonPrimitive jsonPrimitive = JsonElementKt.getJsonPrimitive((JsonElement) MapsKt.getValue($this$long, key));
/* 330 */           if (jsonPrimitive.isString()) {
                        throw new IllegalArgumentException("Failed requirement.".toString());
                    }
                    return JsonElementKt.getLong(jsonPrimitive);
                }

                /* JADX INFO: renamed from: int, reason: not valid java name */
/* 330 */       private static final int m8915int(JsonObject $this$int, String key) {
/* 331 */           long jM8916long = m8916long($this$int, key);
                    boolean z = false;
                    if (SieveCacheKt.NodeMetaAndPreviousMask <= jM8916long && jM8916long <= SieveCacheKt.NodeLinkMask) {
                        z = true;
                    }
                    if (z) {
                        return (int) jM8916long;
                    }
                    throw new IllegalArgumentException("Failed requirement.".toString());
                }

/* 331 */       private static final Long nullLong(JsonObject $this$nullLong, String key) {
                    JsonPrimitive jsonPrimitive;
/* 332 */           Object value = MapsKt.getValue($this$nullLong, key);
/* 332 */           if (Intrinsics.areEqual((JsonElement) value, JsonNull.INSTANCE)) {
                        value = null;
                    }
                    JsonElement jsonElement = (JsonElement) value;
                    if (jsonElement == null || (jsonPrimitive = JsonElementKt.getJsonPrimitive(jsonElement)) == null) {
                        return null;
                    }
                    return Long.valueOf(JsonElementKt.getLong(jsonPrimitive));
                }

/* 332 */       private static final Double nullDouble(JsonObject $this$nullDouble, String key) {
                    JsonPrimitive jsonPrimitive;
/* 333 */           Object value = MapsKt.getValue($this$nullDouble, key);
/* 333 */           if (Intrinsics.areEqual((JsonElement) value, JsonNull.INSTANCE)) {
                        value = null;
                    }
                    JsonElement jsonElement = (JsonElement) value;
                    if (jsonElement == null || (jsonPrimitive = JsonElementKt.getJsonPrimitive(jsonElement)) == null) {
                        return null;
                    }
                    return Double.valueOf(JsonElementKt.getDouble(jsonPrimitive));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 333 */       public static final DeckEntity deck(JsonObject $this$deck) {
/* 334 */           return new DeckEntity(text($this$deck, "id"), text($this$deck, HintConstants.AUTOFILL_HINT_NAME), m8916long($this$deck, "createdAt"), m8916long($this$deck, "updatedAt"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 334 */       public static final CardEntity card(JsonObject $this$card) {
/* 335 */           return new CardEntity(text($this$card, "id"), text($this$card, "deckId"), text($this$card, "front"), text($this$card, "back"), text($this$card, "example"), m8916long($this$card, "createdAt"), m8916long($this$card, "updatedAt"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 335 */       public static final ScheduleEntity schedule(JsonObject $this$schedule) {
                    Integer numValueOf;
/* 336 */           String strText = text($this$schedule, "cardId");
                    String strText2 = text($this$schedule, "phase");
                    Long lNullLong = nullLong($this$schedule, "step");
                    if (lNullLong != null) {
                        Long l = lNullLong;
                        long jLongValue = l.longValue();
                        boolean z = false;
                        if (SieveCacheKt.NodeMetaAndPreviousMask <= jLongValue && jLongValue <= SieveCacheKt.NodeLinkMask) {
                            z = true;
                        }
                        if (!z) {
                            throw new IllegalArgumentException("Failed requirement.".toString());
                        }
                        Unit unit = Unit.INSTANCE;
                        numValueOf = Integer.valueOf((int) l.longValue());
                    } else {
                        numValueOf = null;
                    }
                    return new ScheduleEntity(strText, strText2, numValueOf, nullDouble($this$schedule, "stability"), nullDouble($this$schedule, "difficulty"), m8916long($this$schedule, "dueAt"), nullLong($this$schedule, "lastReviewAt"), nullLong($this$schedule, "firstReviewedAt"), m8916long($this$schedule, "revision"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 336 */       public static final ReviewLogEntity log(JsonObject $this$log) {
/* 337 */           String strText = text($this$log, "id");
                    String strText2 = text($this$log, "cardId");
                    String strText3 = text($this$log, "deckId");
                    String strText4 = text($this$log, "sessionId");
                    int iM8915int = m8915int($this$log, "rating");
/* 337 */           boolean z = false;
/* 343 */           if (1 <= iM8915int && iM8915int < 5) {
                        z = true;
                    }
                    if (!z) {
                        throw new IllegalArgumentException("Failed requirement.".toString());
                    }
                    Unit unit = Unit.INSTANCE;
                    return new ReviewLogEntity(strText, strText2, strText3, strText4, iM8915int, m8916long($this$log, "reviewedAt"), m8916long($this$log, "durationMs"), text($this$log, "beforeSchedule"), text($this$log, "afterSchedule"), nullLong($this$log, "undoneAt"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 337 */       public static final SettingsEntity settings(JsonObject $this$settings) {
/* 338 */           return new SettingsEntity(m8915int($this$settings, "id"), m8915int($this$settings, "newCardsPerDay"), text($this$settings, "themeMode"), m8915int($this$settings, "schemaVersion"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 338 */       public static final AnkiModelEntity model(JsonObject $this$model) {
/* 339 */           return new AnkiModelEntity(text($this$model, "id"), text($this$model, "sourceModelId"), text($this$model, "contentHash"), text($this$model, HintConstants.AUTOFILL_HINT_NAME), m8915int($this$model, "kind"), m8915int($this$model, "originalStockKind"), text($this$model, "fieldNames"), text($this$model, "templates"), text($this$model, "css"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 339 */       public static final AnkiNoteEntity note(JsonObject $this$note) {
/* 340 */           return new AnkiNoteEntity(text($this$note, "id"), text($this$note, "sourceGuid"), text($this$note, "modelId"), text($this$note, "fields"), text($this$note, "tags"), text($this$note, "mediaNamespace"), m8916long($this$note, "revision"));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 340 */       public static final AnkiMediaEntity media(JsonObject $this$media) {
/* 341 */           return new AnkiMediaEntity(text($this$media, "namespace"), text($this$media, "originalName"), text($this$media, "sha256"), m8916long($this$media, "size"), text($this$media, "mime"));
                }
            }

            package com.xunji.flashcards.backup;

            import android.content.ContentResolver;
            import android.net.Uri;
            import java.io.IOException;
            import java.io.InputStream;
            import java.io.OutputStream;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            
            /* JADX INFO: compiled from: BackupFileGateway.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\b\u0007\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u0006\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\tH\u0097@¢\u0006\u0002\u0010\nJ\u0016\u0010\u000b\u001a\u00020\f2\u0006\u0010\b\u001a\u00020\tH\u0097@¢\u0006\u0002\u0010\nR\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\r"}, d2 = {"Lcom/xunji/flashcards/backup/BackupFileGateway;", "Lcom/xunji/flashcards/backup/FileGateway;", "resolver", "Landroid/content/ContentResolver;", "<init>", "(Landroid/content/ContentResolver;)V", "write", "Ljava/io/OutputStream;", "uri", "Landroid/net/Uri;", "(Landroid/net/Uri;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "read", "Ljava/io/InputStream;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 15 */    public final class BackupFileGateway implements FileGateway {
                public static final int $stable = 8;
                private final ContentResolver resolver;

/* 16 */        public BackupFileGateway(ContentResolver resolver) {
                    Intrinsics.checkNotNullParameter(resolver, "resolver");
                    this.resolver = resolver;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupFileGateway$write$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupFileGateway.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Ljava/io/OutputStream;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupFileGateway$write$2", f = "BackupFileGateway.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 17 */        static final class C04282 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super OutputStream>, Object> {
                    final /* synthetic */ Uri $uri;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04282(Uri uri, Continuation<? super C04282> continuation) {
                        super(2, continuation);
                        this.$uri = uri;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return BackupFileGateway.this.new C04282(this.$uri, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super OutputStream> continuation) {
                        return ((C04282) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 18 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 17 */                        OutputStream outputStreamOpenOutputStream = BackupFileGateway.this.resolver.openOutputStream(this.$uri, "wt");
                                if (outputStreamOpenOutputStream != null) {
                                    return outputStreamOpenOutputStream;
                                }
                                throw new IOException("无法打开文件");
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // com.xunji.flashcards.backup.FileGateway
/* 18 */        public Object write(Uri uri, Continuation<? super OutputStream> continuation) {
/* 19 */            return BuildersKt.withContext(Dispatchers.getIO(), new C04282(uri, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupFileGateway$read$2, reason: invalid class name */
                /* JADX INFO: compiled from: BackupFileGateway.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Ljava/io/InputStream;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupFileGateway$read$2", f = "BackupFileGateway.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 19 */        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super InputStream>, Object> {
                    final /* synthetic */ Uri $uri;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(Uri uri, Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                        this.$uri = uri;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return BackupFileGateway.this.new AnonymousClass2(this.$uri, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super InputStream> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 20 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 17 */                        InputStream inputStreamOpenInputStream = BackupFileGateway.this.resolver.openInputStream(this.$uri);
                                if (inputStreamOpenInputStream != null) {
                                    return inputStreamOpenInputStream;
                                }
                                throw new IOException("无法读取文件");
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // com.xunji.flashcards.backup.FileGateway
/* 20 */        public Object read(Uri uri, Continuation<? super InputStream> continuation) {
/* 21 */            return BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(uri, null), continuation);
                }
            }

            package com.xunji.flashcards.backup;

            import com.xunji.flashcards.anki.FileOperationCoordinator;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
            
            /* JADX INFO: compiled from: BackupService.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "Ljava/io/InputStream;", "it", "Lcom/xunji/flashcards/data/AnkiMediaEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$export$2$1$completed$1", f = "BackupService.kt", i = {0}, l = {LockFreeTaskQueueCore.FROZEN_SHIFT}, m = "invokeSuspend", n = {"it"}, s = {"L$0"}, v = 1)
/* 58 */    final class BackupService$export$2$1$completed$1 extends SuspendLambda implements Function2<AnkiMediaEntity, Continuation<? super InputStream>, Object> {
                final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                /* synthetic */ Object L$0;
                int label;
                final /* synthetic */ BackupService this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                BackupService$export$2$1$completed$1(BackupService backupService, FileOperationCoordinator.Operation operation, Continuation<? super BackupService$export$2$1$completed$1> continuation) {
                    super(2, continuation);
                    this.this$0 = backupService;
                    this.$$this$withLock = operation;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    BackupService$export$2$1$completed$1 backupService$export$2$1$completed$1 = new BackupService$export$2$1$completed$1(this.this$0, this.$$this$withLock, continuation);
                    backupService$export$2$1$completed$1.L$0 = obj;
                    return backupService$export$2$1$completed$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(AnkiMediaEntity ankiMediaEntity, Continuation<? super InputStream> continuation) {
                    return ((BackupService$export$2$1$completed$1) create(ankiMediaEntity, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 59 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    AnkiMediaEntity it = (AnkiMediaEntity) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.L$0 = SpillingKt.nullOutSpilledVariable(it);
                            this.label = 1;
/* 28 */                    Object objOpenObjectLocked$app_debug = this.this$0.media.openObjectLocked$app_debug(this.$$this$withLock, it, this);
                            return objOpenObjectLocked$app_debug == coroutine_suspended ? coroutine_suspended : objOpenObjectLocked$app_debug;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            return $result;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

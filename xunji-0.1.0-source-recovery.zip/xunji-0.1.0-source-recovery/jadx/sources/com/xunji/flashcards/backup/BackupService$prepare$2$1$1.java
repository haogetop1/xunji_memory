            package com.xunji.flashcards.backup;

            import androidx.compose.material.MenuKt;
            import com.xunji.flashcards.anki.FileOperationCoordinator;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Ref;
            
            /* JADX INFO: compiled from: BackupService.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$prepare$2$1$1", f = "BackupService.kt", i = {0}, l = {MenuKt.OutTransitionDuration}, m = "invokeSuspend", n = {"$this$withLock"}, s = {"L$0"}, v = 1)
/* 73 */    final class BackupService$prepare$2$1$1 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Unit>, Object> {
                final /* synthetic */ Ref.ObjectRef<BackupArchive> $archive;
                private /* synthetic */ Object L$0;
                int label;
                final /* synthetic */ BackupService this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                BackupService$prepare$2$1$1(BackupService backupService, Ref.ObjectRef<BackupArchive> objectRef, Continuation<? super BackupService$prepare$2$1$1> continuation) {
                    super(2, continuation);
                    this.this$0 = backupService;
                    this.$archive = objectRef;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    BackupService$prepare$2$1$1 backupService$prepare$2$1$1 = new BackupService$prepare$2$1$1(this.this$0, this.$archive, continuation);
                    backupService$prepare$2$1$1.L$0 = obj;
                    return backupService$prepare$2$1$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) {
                    return ((BackupService$prepare$2$1$1) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Type inference failed for: r2v4, types: [T, com.xunji.flashcards.backup.BackupArchive] */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 74 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                            this.label = 1;
/* 28 */                    if (this.this$0.initializeLocked($this$withLock, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 28 */            this.$archive.element = this.this$0.newArchive();
                    return Unit.INSTANCE;
                }
            }

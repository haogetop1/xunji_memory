            package com.xunji.flashcards.backup;

            import android.content.Context;
            import android.util.Log;
            import androidx.compose.material.MenuKt;
            import androidx.core.location.LocationRequestCompat;
            import androidx.core.view.MotionEventCompat;
            import androidx.room.Room;
            import androidx.room.RoomDatabaseKt;
            import androidx.savedstate.serialization.ClassDiscriminatorModeKt;
            import androidx.sqlite.db.SupportSQLiteDatabase;
            import com.xunji.core.backup.BackupCodec;
            import com.xunji.core.backup.BackupDocument;
            import com.xunji.core.backup.BackupManifest;
            import com.xunji.flashcards.anki.BoundedApkgKt;
            import com.xunji.flashcards.anki.BoundedJson;
            import com.xunji.flashcards.anki.FileOperationCoordinator;
            import com.xunji.flashcards.anki.MediaStore;
            import com.xunji.flashcards.anki.MediaStoreKt;
            import com.xunji.flashcards.data.AnkiMediaEntity;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.io.BufferedInputStream;
            import java.io.ByteArrayOutputStream;
            import java.io.Closeable;
            import java.io.File;
            import java.io.FileInputStream;
            import java.io.InputStream;
            import java.io.OutputStream;
            import java.io.PushbackInputStream;
            import java.nio.file.DirectoryStream;
            import java.nio.file.Files;
            import java.nio.file.Path;
            import java.time.Clock;
            import java.util.ArrayList;
            import java.util.Arrays;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.UUID;
            import java.util.concurrent.CancellationException;
            import kotlin.ExceptionsKt;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlin.ranges.RangesKt;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineDispatcher;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.JobKt;
            import kotlinx.coroutines.NonCancellable;
            import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonNull;
            import kotlinx.serialization.json.JsonObject;
            import kotlinx.serialization.json.JsonPrimitive;
            
            /* JADX INFO: compiled from: BackupService.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001BK\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\b\u0002\u0010\f\u001a\u00020\r\u0012\u000e\b\u0002\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f¢\u0006\u0004\b\u0011\u0010\u0012J\u0016\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u0018H\u0082@¢\u0006\u0002\u0010\u0019J\b\u0010\u001a\u001a\u00020\u001bH\u0002J\u0016\u0010\u001c\u001a\u00020\u00162\u0006\u0010\u001d\u001a\u00020\u001eH\u0086@¢\u0006\u0002\u0010\u001fJ\u0016\u0010 \u001a\u00020!2\u0006\u0010\"\u001a\u00020#H\u0086@¢\u0006\u0002\u0010$J\u001e\u0010%\u001a\u00020&2\u0006\u0010\"\u001a\u00020#2\u0006\u0010'\u001a\u00020\u001bH\u0082@¢\u0006\u0002\u0010(J\u0016\u0010)\u001a\u00020\u00162\u0006\u0010*\u001a\u00020!H\u0086@¢\u0006\u0002\u0010+R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00100\u000fX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0013\u001a\u00020\u0014X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006,"}, d2 = {"Lcom/xunji/flashcards/backup/BackupService;", "", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "context", "Landroid/content/Context;", "media", "Lcom/xunji/flashcards/anki/MediaStore;", "coordinator", "Lcom/xunji/flashcards/anki/FileOperationCoordinator;", "root", "Ljava/io/File;", "clock", "Ljava/time/Clock;", "availableSpace", "Lkotlin/Function0;", "", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;Landroid/content/Context;Lcom/xunji/flashcards/anki/MediaStore;Lcom/xunji/flashcards/anki/FileOperationCoordinator;Ljava/io/File;Ljava/time/Clock;Lkotlin/jvm/functions/Function0;)V", "initialized", "", "initializeLocked", "", "operation", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;", "(Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "newArchive", "Lcom/xunji/flashcards/backup/BackupArchive;", "export", "output", "Ljava/io/OutputStream;", "(Ljava/io/OutputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "prepare", "Lcom/xunji/flashcards/backup/PreparedBackup;", "input", "Ljava/io/InputStream;", "(Ljava/io/InputStream;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "readV1", "Lcom/xunji/core/backup/BackupManifest;", "stage", "(Ljava/io/InputStream;Lcom/xunji/flashcards/backup/BackupArchive;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "replace", "prepared", "(Lcom/xunji/flashcards/backup/PreparedBackup;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 26 */    public final class BackupService {
                public static final int $stable = 8;
                private final Function0<Long> availableSpace;
                private final Clock clock;
                private final Context context;
                private final FileOperationCoordinator coordinator;
                private final XunjiDatabase db;
                private boolean initialized;
                private final MediaStore media;
                private final File root;

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$initializeLocked$1, reason: invalid class name */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService", f = "BackupService.kt", i = {0}, l = {MotionEventCompat.AXIS_GENERIC_4}, m = "initializeLocked", n = {"operation"}, s = {"L$0"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 28 */                return BackupService.this.initializeLocked(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$prepare$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService", f = "BackupService.kt", i = {0, 0, 0, 1, 1, 1, 1}, l = {73, 86}, m = "prepare", n = {"input", "prepared", "archive", "input", "prepared", "archive", "e"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3"}, v = 1)
                static final class C04291 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    C04291(Continuation<? super C04291> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupService.this.prepare(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$readV1$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService", f = "BackupService.kt", i = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1}, l = {101, 109}, m = "readV1", n = {"input", "stage", "output", "buffer", "text", "d", "input", "stage", "output", "buffer", "text", "d"}, s = {"L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5"}, v = 1)
                static final class C04311 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    int label;
                    /* synthetic */ Object result;

                    C04311(Continuation<? super C04311> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 28 */                return BackupService.this.readV1(null, null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService", f = "BackupService.kt", i = {0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3}, l = {119, 152, 152, 152}, m = "replace", n = {"prepared", "caller", "committed", "prepared", "caller", "committed", "prepared", "caller", "committed", "prepared", "caller", "committed"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2"}, v = 1)
                static final class C04331 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    C04331(Continuation<? super C04331> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return BackupService.this.replace(null, this);
                    }
                }

/* 27 */        public BackupService(XunjiDatabase db, Context context, MediaStore media, FileOperationCoordinator coordinator, File root, Clock clock, Function0<Long> availableSpace) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(context, "context");
                    Intrinsics.checkNotNullParameter(media, "media");
                    Intrinsics.checkNotNullParameter(coordinator, "coordinator");
                    Intrinsics.checkNotNullParameter(root, "root");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    Intrinsics.checkNotNullParameter(availableSpace, "availableSpace");
/* 29 */            this.db = db;
                    this.context = context;
                    this.media = media;
/* 30 */            this.coordinator = coordinator;
                    this.root = root;
/* 31 */            this.clock = clock;
                    this.availableSpace = availableSpace;
                }

/* 27 */        public /* synthetic */ BackupService(XunjiDatabase xunjiDatabase, Context context, MediaStore mediaStore, FileOperationCoordinator fileOperationCoordinator, final File file, Clock clock, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
                    Clock clock2;
                    Function0 function1;
/* 28 */            if ((i & 32) == 0) {
/* 28 */                clock2 = clock;
                    } else {
/* 31 */                Clock clockSystemUTC = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clockSystemUTC, "systemUTC(...)");
                        clock2 = clockSystemUTC;
                    }
                    if ((i & 64) == 0) {
/* 28 */                function1 = function0;
                    } else {
/* 31 */                function1 = new Function0() { // from class: com.xunji.flashcards.backup.BackupService$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
/* 31 */                        return Long.valueOf(file.getUsableSpace());
                            }
                        };
                    }
                    this(xunjiDatabase, context, mediaStore, fileOperationCoordinator, file, clock2, function1);
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 33 */        public final Object initializeLocked(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 35 */                    MediaStore mediaStore = this.media;
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                            anonymousClass1.label = 1;
                            if (mediaStore.initializeLocked$app_debug(operation, anonymousClass1) == coroutine_suspended) {
/* 34 */                        return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 36 */            if (!this.initialized) {
/* 37 */                if (!(this.root.mkdirs() || this.root.isDirectory())) {
/* 37 */                    throw new IllegalStateException("Check failed.");
                        }
/* 38 */                DirectoryStream<Path> directoryStreamNewDirectoryStream = Files.newDirectoryStream(this.root.toPath());
                        try {
/* 39 */                    Iterator<Path> it = directoryStreamNewDirectoryStream.iterator();
                            Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                            while (it.hasNext()) {
                                Path next = it.next();
                                JobKt.ensureActive(anonymousClass1.getContext());
                                File file = next.toFile();
                                Intrinsics.checkNotNullExpressionValue(file, "toFile(...)");
                                MediaStoreKt.deletePrivateTree(file);
                            }
                            Unit unit = Unit.INSTANCE;
/* 38 */                    CloseableKt.closeFinally(directoryStreamNewDirectoryStream, null);
/* 41 */                    this.initialized = true;
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(directoryStreamNewDirectoryStream, th);
                                throw th2;
                            }
                        }
                    }
/* 43 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 44 */        public final BackupArchive newArchive() {
/* 45 */            File dir = new File(this.root, UUID.randomUUID().toString());
                    if (!dir.mkdir()) {
/* 45 */                throw new IllegalStateException("Check failed.");
                    }
/* 46 */            Context applicationContext = this.context.getApplicationContext();
                    Intrinsics.checkNotNullExpressionValue(applicationContext, "getApplicationContext(...)");
                    XunjiDatabase staging = (XunjiDatabase) Room.databaseBuilder(applicationContext, XunjiDatabase.class, new File(dir, "staging.db").getAbsolutePath()).build();
                    try {
/* 47 */                BackupArchive backupArchive = new BackupArchive(staging, dir, this.availableSpace);
/* 47 */                backupArchive.initialize();
                        return backupArchive;
                    } catch (Throwable e) {
                        try {
/* 49 */                    staging.close();
                            MediaStoreKt.deletePrivateTree(dir);
                        } catch (Exception cleanup) {
                            ExceptionsKt.addSuppressed(e, cleanup);
                        }
/* 50 */                throw e;
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$export$2, reason: invalid class name */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$export$2", f = "BackupService.kt", i = {0}, l = {54}, m = "invokeSuspend", n = {"$this$withContext"}, s = {"L$0"}, v = 1)
/* 51 */        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ OutputStream $output;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(OutputStream outputStream, Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                        this.$output = outputStream;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass2 anonymousClass2 = BackupService.this.new AnonymousClass2(this.$output, continuation);
                        anonymousClass2.L$0 = obj;
                        return anonymousClass2;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$export$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: BackupService.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$export$2$1", f = "BackupService.kt", i = {0, 1, 1, 2, 2, 2}, l = {55, 59, LockFreeTaskQueueCore.FROZEN_SHIFT}, m = "invokeSuspend", n = {"$this$withLock", "$this$withLock", "archive", "$this$withLock", "archive", "manifest"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2"}, v = 1)
/* 52 */            static final class AnonymousClass1 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Unit>, Object> {
                        final /* synthetic */ CoroutineScope $$this$withContext;
                        final /* synthetic */ OutputStream $output;
                        private /* synthetic */ Object L$0;
                        Object L$1;
                        Object L$2;
                        int label;
                        final /* synthetic */ BackupService this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(BackupService backupService, OutputStream outputStream, CoroutineScope coroutineScope, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.this$0 = backupService;
                            this.$output = outputStream;
                            this.$$this$withContext = coroutineScope;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, this.$output, this.$$this$withContext, continuation);
                            anonymousClass1.L$0 = obj;
                            return anonymousClass1;
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Unit> continuation) {
                            return ((AnonymousClass1) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:21:0x0074 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:24:0x009a A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:25:0x009b  */
                        /* JADX WARN: Code duplicated, block: B:30:0x00be A[DONT_INVERT] */
                        /* JADX WARN: Code duplicated, block: B:48:0x00c5 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:49:0x00c0 A[SYNTHETIC] */
                        /* JADX WARN: Code duplicated, block: B:51:0x00b1 A[SYNTHETIC] */
                        /* JADX WARN: Multi-variable type inference failed */
                        /* JADX WARN: Type inference failed for: r2v0, types: [int] */
                        /* JADX WARN: Type inference failed for: r2v12 */
                        /* JADX WARN: Type inference failed for: r2v13 */
                        /* JADX WARN: Type inference failed for: r2v9, types: [com.xunji.flashcards.backup.BackupArchive] */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 53 */                public final Object invokeSuspend(Object obj) throws Throwable {
                            Object objSnapshot;
                            BackupArchive backupArchive;
                            Object objWriteZip;
                            FileInputStream fileInputStream;
                            CoroutineScope coroutineScope;
                            OutputStream outputStream;
                            FileInputStream fileInputStream2;
                            byte[] bArr;
                            int i;
                            FileOperationCoordinator.Operation operation = (FileOperationCoordinator.Operation) this.L$0;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
/* 54 */                    BackupArchive backupArchive2 = this.label;
                            try {
                                switch (backupArchive2) {
                                    case 0:
                                        ResultKt.throwOnFailure(obj);
                                        this.L$0 = operation;
                                        this.label = 1;
/* 28 */                                if (this.this$0.initializeLocked(operation, this) == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
/* 28 */                                BackupArchive backupArchiveNewArchive = this.this$0.newArchive();
/* 58 */                                BackupArchive.checkSpace$default(backupArchiveNewArchive, 0L, 1, null);
                                        this.L$0 = operation;
                                        this.L$1 = backupArchiveNewArchive;
                                        this.label = 2;
/* 28 */                                objSnapshot = backupArchiveNewArchive.snapshot(this.this$0.db, this.this$0.clock.millis(), this);
                                        backupArchive = backupArchiveNewArchive;
                                        if (objSnapshot == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
                                        BackupManifest backupManifest = (BackupManifest) objSnapshot;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                                        this.L$1 = backupArchive;
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(backupManifest);
                                        this.label = 3;
/* 60 */                                objWriteZip = backupArchive.writeZip(backupManifest, new BackupService$export$2$1$completed$1(this.this$0, operation, null), this);
                                        if (objWriteZip == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
                                        backupArchive2 = backupArchive;
/* 61 */                                fileInputStream = new FileInputStream((File) objWriteZip);
                                        coroutineScope = this.$$this$withContext;
                                        outputStream = this.$output;
                                        try {
                                            fileInputStream2 = fileInputStream;
/* 62 */                                    bArr = new byte[65536];
                                            while (true) {
/* 63 */                                        JobKt.ensureActive(coroutineScope.getCoroutineContext());
                                                i = fileInputStream2.read(bArr);
                                                if (i >= 0) {
                                                    Unit unit = Unit.INSTANCE;
/* 61 */                                            CloseableKt.closeFinally(fileInputStream, null);
/* 65 */                                            this.$output.flush();
/* 66 */                                            backupArchive2.getDb().close();
                                                    MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
/* 67 */                                            return Unit.INSTANCE;
                                                }
                                                if (i > 0) {
                                                    outputStream.write(bArr, 0, i);
                                                }
/* 66 */                                        backupArchive2.getDb().close();
                                                MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
                                                throw th;
                                            }
                                        } catch (Throwable th) {
                                            try {
                                                throw th;
                                            } catch (Throwable th2) {
                                                CloseableKt.closeFinally(fileInputStream, th);
                                                throw th2;
                                            }
                                        }
                                    case 1:
/* 54 */                                ResultKt.throwOnFailure(obj);
/* 28 */                                BackupArchive backupArchiveNewArchive2 = this.this$0.newArchive();
/* 58 */                                BackupArchive.checkSpace$default(backupArchiveNewArchive2, 0L, 1, null);
                                        this.L$0 = operation;
                                        this.L$1 = backupArchiveNewArchive2;
                                        this.label = 2;
/* 28 */                                objSnapshot = backupArchiveNewArchive2.snapshot(this.this$0.db, this.this$0.clock.millis(), this);
                                        backupArchive = backupArchiveNewArchive2;
                                        if (objSnapshot == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
                                        BackupManifest backupManifest2 = (BackupManifest) objSnapshot;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                                        this.L$1 = backupArchive;
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(backupManifest2);
                                        this.label = 3;
/* 60 */                                objWriteZip = backupArchive.writeZip(backupManifest2, new BackupService$export$2$1$completed$1(this.this$0, operation, null), this);
                                        if (objWriteZip == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
                                        backupArchive2 = backupArchive;
/* 61 */                                fileInputStream = new FileInputStream((File) objWriteZip);
                                        coroutineScope = this.$$this$withContext;
                                        outputStream = this.$output;
                                        fileInputStream2 = fileInputStream;
/* 62 */                                bArr = new byte[65536];
                                        while (true) {
/* 63 */                                    JobKt.ensureActive(coroutineScope.getCoroutineContext());
                                            i = fileInputStream2.read(bArr);
                                            if (i >= 0) {
                                                Unit unit2 = Unit.INSTANCE;
/* 61 */                                        CloseableKt.closeFinally(fileInputStream, null);
/* 65 */                                        this.$output.flush();
/* 66 */                                        backupArchive2.getDb().close();
                                                MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
/* 67 */                                        return Unit.INSTANCE;
                                            }
                                            if (i > 0) {
                                                outputStream.write(bArr, 0, i);
                                            }
/* 66 */                                    backupArchive2.getDb().close();
                                            MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
                                            throw th;
                                        }
                                    case 2:
                                        BackupArchive backupArchive3 = (BackupArchive) this.L$1;
                                        ResultKt.throwOnFailure(obj);
                                        objSnapshot = obj;
                                        backupArchive = backupArchive3;
                                        BackupManifest backupManifest3 = (BackupManifest) objSnapshot;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(operation);
                                        this.L$1 = backupArchive;
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(backupManifest3);
                                        this.label = 3;
/* 60 */                                objWriteZip = backupArchive.writeZip(backupManifest3, new BackupService$export$2$1$completed$1(this.this$0, operation, null), this);
                                        if (objWriteZip == coroutine_suspended) {
/* 54 */                                    return coroutine_suspended;
                                        }
                                        backupArchive2 = backupArchive;
/* 61 */                                fileInputStream = new FileInputStream((File) objWriteZip);
                                        coroutineScope = this.$$this$withContext;
                                        outputStream = this.$output;
                                        fileInputStream2 = fileInputStream;
/* 62 */                                bArr = new byte[65536];
                                        while (true) {
/* 63 */                                    JobKt.ensureActive(coroutineScope.getCoroutineContext());
                                            i = fileInputStream2.read(bArr);
                                            if (i >= 0) {
                                                Unit unit3 = Unit.INSTANCE;
/* 61 */                                        CloseableKt.closeFinally(fileInputStream, null);
/* 65 */                                        this.$output.flush();
/* 66 */                                        backupArchive2.getDb().close();
                                                MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
/* 67 */                                        return Unit.INSTANCE;
                                            }
                                            if (i > 0) {
                                                outputStream.write(bArr, 0, i);
                                            }
/* 66 */                                    backupArchive2.getDb().close();
                                            MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
                                            throw th;
                                        }
                                    case 3:
                                        BackupArchive backupArchive4 = (BackupArchive) this.L$1;
                                        ResultKt.throwOnFailure(obj);
                                        objWriteZip = obj;
                                        backupArchive2 = backupArchive4;
/* 61 */                                fileInputStream = new FileInputStream((File) objWriteZip);
                                        coroutineScope = this.$$this$withContext;
                                        outputStream = this.$output;
                                        fileInputStream2 = fileInputStream;
/* 62 */                                bArr = new byte[65536];
                                        while (true) {
/* 63 */                                    JobKt.ensureActive(coroutineScope.getCoroutineContext());
                                            i = fileInputStream2.read(bArr);
                                            if (i >= 0) {
                                                Unit unit4 = Unit.INSTANCE;
/* 61 */                                        CloseableKt.closeFinally(fileInputStream, null);
/* 65 */                                        this.$output.flush();
/* 66 */                                        backupArchive2.getDb().close();
                                                MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
/* 67 */                                        return Unit.INSTANCE;
                                            }
                                            if (i > 0) {
                                                outputStream.write(bArr, 0, i);
                                            }
/* 66 */                                    backupArchive2.getDb().close();
                                            MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
                                            throw th;
                                        }
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            } catch (Throwable th3) {
/* 66 */                        backupArchive2.getDb().close();
                                MediaStoreKt.deletePrivateTree(backupArchive2.getDirectory());
                                throw th3;
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 52 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        CoroutineScope $this$withContext = (CoroutineScope) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable($this$withContext);
                                this.label = 1;
/* 28 */                        if (BackupService.this.coordinator.withLock(new AnonymousClass1(BackupService.this, this.$output, $this$withContext, null), this) == coroutine_suspended) {
/* 53 */                            return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 68 */                return Unit.INSTANCE;
                    }
                }

/* 52 */        public final Object export(OutputStream output, Continuation<? super Unit> continuation) {
/* 53 */            Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(output, null), continuation);
                    return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:36:0x00d3 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:37:0x00d4  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
/* 68 */        public final Object prepare(InputStream input, Continuation<? super PreparedBackup> continuation) throws Throwable {
                    C04291 c04291;
                    BackupService backupService;
                    InputStream input2;
                    Throwable e;
                    InputStream input3;
                    Ref.ObjectRef archive;
                    Ref.ObjectRef prepared;
                    CoroutineContext coroutineContextPlus;
                    AnonymousClass3 anonymousClass3;
                    if (continuation instanceof C04291) {
                        c04291 = (C04291) continuation;
                        if ((c04291.label & Integer.MIN_VALUE) != 0) {
                            c04291.label -= Integer.MIN_VALUE;
                            backupService = this;
                        } else {
                            backupService = this;
                            c04291 = backupService.new C04291(continuation);
                        }
                    } else {
                        backupService = this;
                        c04291 = backupService.new C04291(continuation);
                    }
                    C04291 c04292 = c04291;
                    Object $result = c04292.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04292.label) {
                        case 0:
/* 69 */                    ResultKt.throwOnFailure($result);
/* 70 */                    Ref.ObjectRef prepared2 = new Ref.ObjectRef();
/* 71 */                    Ref.ObjectRef archive2 = new Ref.ObjectRef();
                            try {
/* 73 */                        CoroutineDispatcher io2 = Dispatchers.getIO();
                                input2 = input;
                                try {
                                    C04302 c04302 = new C04302(input2, backupService, archive2, prepared2, null);
                                    input2 = input;
                                    c04292.L$0 = input2;
                                    c04292.L$1 = prepared2;
                                    c04292.L$2 = archive2;
                                    c04292.label = 1;
                                    Object objWithContext = BuildersKt.withContext(io2, c04302, c04292);
                                    return objWithContext == coroutine_suspended ? coroutine_suspended : objWithContext;
                                } catch (Throwable th) {
                                    th = th;
                                    e = th;
                                    input3 = input2;
                                    archive = archive2;
                                    prepared = prepared2;
/* 86 */                            coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                    anonymousClass3 = new AnonymousClass3(prepared, archive, e, input3, null);
                                    c04292.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                                    c04292.L$1 = SpillingKt.nullOutSpilledVariable(prepared);
                                    c04292.L$2 = SpillingKt.nullOutSpilledVariable(archive);
                                    c04292.L$3 = e;
                                    c04292.label = 2;
                                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass3, c04292) == coroutine_suspended) {
/* 69 */                                return coroutine_suspended;
                                    }
/* 91 */                            throw e;
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                input2 = input;
                            }
                            break;
                        case 1:
                            Ref.ObjectRef archive3 = (Ref.ObjectRef) c04292.L$2;
                            Ref.ObjectRef prepared3 = (Ref.ObjectRef) c04292.L$1;
                            InputStream input4 = (InputStream) c04292.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
                                return $result;
                            } catch (Throwable th3) {
                                e = th3;
                                archive = archive3;
                                prepared = prepared3;
                                input3 = input4;
                            }
                            break;
                        case 2:
                            Throwable e2 = (Throwable) c04292.L$3;
                            ResultKt.throwOnFailure($result);
/* 91 */                    throw e2;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
/* 86 */            coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                    anonymousClass3 = new AnonymousClass3(prepared, archive, e, input3, null);
                    c04292.L$0 = SpillingKt.nullOutSpilledVariable(input3);
                    c04292.L$1 = SpillingKt.nullOutSpilledVariable(prepared);
                    c04292.L$2 = SpillingKt.nullOutSpilledVariable(archive);
                    c04292.L$3 = e;
                    c04292.label = 2;
                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass3, c04292) == coroutine_suspended) {
/* 69 */                return coroutine_suspended;
                    }
/* 91 */            throw e;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$prepare$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/backup/PreparedBackup;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$prepare$2", f = "BackupService.kt", i = {0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2}, l = {MenuKt.OutTransitionDuration, 81, 81}, m = "invokeSuspend", n = {"source\\1", "$i$a$-use-BackupService$prepare$2$1\\1\\74\\0", "source\\1", "stage\\1", "stream\\1", "prefix\\1", "$i$a$-use-BackupService$prepare$2$1\\1\\74\\0", "size\\1", "source\\1", "stage\\1", "stream\\1", "prefix\\1", "$i$a$-use-BackupService$prepare$2$1\\1\\74\\0", "size\\1"}, s = {"L$4", "I$0", "L$3", "L$4", "L$5", "L$6", "I$0", "I$1", "L$3", "L$4", "L$5", "L$6", "I$0", "I$1"}, v = 1)
/* 71 */        static final class C04302 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super PreparedBackup>, Object> {
                    final /* synthetic */ Ref.ObjectRef<BackupArchive> $archive;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Ref.ObjectRef<PreparedBackup> $prepared;
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    Object L$6;
                    int label;
                    final /* synthetic */ BackupService this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04302(InputStream inputStream, BackupService backupService, Ref.ObjectRef<BackupArchive> objectRef, Ref.ObjectRef<PreparedBackup> objectRef2, Continuation<? super C04302> continuation) {
                        super(2, continuation);
                        this.$input = inputStream;
                        this.this$0 = backupService;
                        this.$archive = objectRef;
                        this.$prepared = objectRef2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04302(this.$input, this.this$0, this.$archive, this.$prepared, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super PreparedBackup> continuation) {
                        return ((C04302) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:22:0x00ce A[Catch: all -> 0x0156, TryCatch #0 {all -> 0x0156, blocks: (B:7:0x0032, B:39:0x0146, B:40:0x0148, B:10:0x0058, B:34:0x0117, B:13:0x0075, B:20:0x00b3, B:22:0x00ce, B:25:0x00d8, B:26:0x00da, B:28:0x00e0, B:30:0x00eb, B:35:0x011a, B:16:0x008a), top: B:48:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:24:0x00d6 A[DONT_INVERT] */
                    /* JADX WARN: Code duplicated, block: B:28:0x00e0 A[Catch: all -> 0x0156, TryCatch #0 {all -> 0x0156, blocks: (B:7:0x0032, B:39:0x0146, B:40:0x0148, B:10:0x0058, B:34:0x0117, B:13:0x0075, B:20:0x00b3, B:22:0x00ce, B:25:0x00d8, B:26:0x00da, B:28:0x00e0, B:30:0x00eb, B:35:0x011a, B:16:0x008a), top: B:48:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:37:0x0144 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:38:0x0145  */
                    /* JADX WARN: Code duplicated, block: B:53:0x00da A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:54:0x00d8 A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:56:0x00cc A[SYNTHETIC] */
                    /* JADX WARN: Type inference failed for: r11v4, types: [T, com.xunji.flashcards.backup.PreparedBackup, java.lang.Object] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 72 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        InputStream inputStream;
                        Ref.ObjectRef<BackupArchive> objectRef;
                        BackupService backupService;
                        Ref.ObjectRef<PreparedBackup> objectRef2;
                        int i;
                        InputStream inputStream2;
                        BackupArchive backupArchive;
                        PushbackInputStream pushbackInputStream;
                        byte[] bArr;
                        int i2;
                        Object v1;
                        Object zip;
                        int i3;
                        BackupManifest backupManifest;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 74 */                            inputStream = this.$input;
                                    BackupService backupService2 = this.this$0;
                                    objectRef = this.$archive;
                                    Ref.ObjectRef<PreparedBackup> objectRef3 = this.$prepared;
                                    InputStream inputStream3 = inputStream;
/* 28 */                            FileOperationCoordinator fileOperationCoordinator = backupService2.coordinator;
                                    BackupService$prepare$2$1$1 backupService$prepare$2$1$1 = new BackupService$prepare$2$1$1(backupService2, objectRef, null);
                                    this.L$0 = inputStream;
                                    this.L$1 = backupService2;
                                    this.L$2 = objectRef;
                                    this.L$3 = objectRef3;
                                    this.L$4 = inputStream3;
                                    this.I$0 = 0;
                                    this.label = 1;
                                    if (fileOperationCoordinator.withLock(backupService$prepare$2$1$1, this) == coroutine_suspended) {
/* 73 */                                return coroutine_suspended;
                                    }
/* 75 */                            backupService = backupService2;
                                    objectRef2 = objectRef3;
                                    i = 0;
                                    inputStream2 = inputStream3;
/* 76 */                            BackupArchive backupArchive2 = objectRef.element;
                                    Intrinsics.checkNotNull(backupArchive2);
                                    backupArchive = backupArchive2;
/* 77 */                            pushbackInputStream = new PushbackInputStream(new BufferedInputStream(inputStream2), 4);
/* 78 */                            bArr = new byte[4];
                                    i2 = 0;
/* 79 */                            while (i2 < 4) {
                                        i3 = pushbackInputStream.read(bArr, i2, 4 - i2);
                                        if (i3 >= 0) {
/* 80 */                                    pushbackInputStream.unread(bArr, 0, i2);
/* 81 */                                    if (i2 == 4 || !Arrays.equals(bArr, new byte[]{80, 75, 3, 4})) {
                                                this.L$0 = inputStream;
                                                this.L$1 = backupService;
                                                this.L$2 = objectRef2;
                                                this.L$3 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                                this.L$4 = backupArchive;
                                                this.L$5 = SpillingKt.nullOutSpilledVariable(pushbackInputStream);
                                                this.L$6 = SpillingKt.nullOutSpilledVariable(bArr);
                                                this.I$0 = i;
                                                this.I$1 = i2;
                                                this.label = 3;
/* 28 */                                        v1 = backupService.readV1(pushbackInputStream, backupArchive, this);
                                                if (v1 == coroutine_suspended) {
/* 73 */                                            return coroutine_suspended;
                                                }
/* 73 */                                        backupManifest = (BackupManifest) v1;
/* 82 */                                        ?? preparedBackup = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                                        objectRef2.element = preparedBackup;
/* 74 */                                        CloseableKt.closeFinally(inputStream, null);
/* 83 */                                        return preparedBackup;
                                            }
                                            this.L$0 = inputStream;
                                            this.L$1 = backupService;
                                            this.L$2 = objectRef2;
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                            this.L$4 = backupArchive;
                                            this.L$5 = SpillingKt.nullOutSpilledVariable(pushbackInputStream);
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(bArr);
                                            this.I$0 = i;
                                            this.I$1 = i2;
                                            this.label = 2;
                                            zip = backupArchive.readZip(pushbackInputStream, this);
                                            if (zip == coroutine_suspended) {
/* 73 */                                        return coroutine_suspended;
                                            }
                                            backupManifest = (BackupManifest) zip;
/* 82 */                                    ?? preparedBackup2 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                                    objectRef2.element = preparedBackup2;
/* 74 */                                    CloseableKt.closeFinally(inputStream, null);
/* 83 */                                    return preparedBackup2;
                                        }
                                        if (i3 > 0) {
                                            i2 += i3;
                                        }
                                    }
/* 80 */                            pushbackInputStream.unread(bArr, 0, i2);
/* 81 */                            if (i2 == 4) {
                                    }
                                    this.L$0 = inputStream;
                                    this.L$1 = backupService;
                                    this.L$2 = objectRef2;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                    this.L$4 = backupArchive;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(pushbackInputStream);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(bArr);
                                    this.I$0 = i;
                                    this.I$1 = i2;
                                    this.label = 3;
/* 28 */                            v1 = backupService.readV1(pushbackInputStream, backupArchive, this);
                                    if (v1 == coroutine_suspended) {
/* 73 */                                return coroutine_suspended;
                                    }
/* 73 */                            backupManifest = (BackupManifest) v1;
/* 82 */                            ?? preparedBackup3 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                            objectRef2.element = preparedBackup3;
/* 74 */                            CloseableKt.closeFinally(inputStream, null);
/* 83 */                            return preparedBackup3;
                                case 1:
                                    i = this.I$0;
                                    InputStream inputStream4 = (InputStream) this.L$4;
                                    Ref.ObjectRef<PreparedBackup> objectRef4 = (Ref.ObjectRef) this.L$3;
                                    objectRef = (Ref.ObjectRef) this.L$2;
                                    BackupService backupService3 = (BackupService) this.L$1;
                                    inputStream = (Closeable) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objectRef2 = objectRef4;
                                    backupService = backupService3;
                                    inputStream2 = inputStream4;
/* 76 */                            BackupArchive backupArchive3 = objectRef.element;
                                    Intrinsics.checkNotNull(backupArchive3);
                                    backupArchive = backupArchive3;
/* 77 */                            pushbackInputStream = new PushbackInputStream(new BufferedInputStream(inputStream2), 4);
/* 78 */                            bArr = new byte[4];
                                    i2 = 0;
/* 79 */                            while (i2 < 4) {
                                        i3 = pushbackInputStream.read(bArr, i2, 4 - i2);
                                        if (i3 >= 0) {
/* 80 */                                    pushbackInputStream.unread(bArr, 0, i2);
/* 81 */                                    if (i2 == 4) {
                                                break;
                                            }
                                            this.L$0 = inputStream;
                                            this.L$1 = backupService;
                                            this.L$2 = objectRef2;
                                            this.L$3 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                            this.L$4 = backupArchive;
                                            this.L$5 = SpillingKt.nullOutSpilledVariable(pushbackInputStream);
                                            this.L$6 = SpillingKt.nullOutSpilledVariable(bArr);
                                            this.I$0 = i;
                                            this.I$1 = i2;
                                            this.label = 3;
/* 28 */                                    v1 = backupService.readV1(pushbackInputStream, backupArchive, this);
                                            if (v1 == coroutine_suspended) {
/* 73 */                                        return coroutine_suspended;
                                            }
/* 73 */                                    backupManifest = (BackupManifest) v1;
/* 82 */                                    ?? preparedBackup4 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                                    objectRef2.element = preparedBackup4;
/* 74 */                                    CloseableKt.closeFinally(inputStream, null);
/* 83 */                                    return preparedBackup4;
                                        }
                                        if (i3 > 0) {
                                            i2 += i3;
                                        }
                                    }
/* 80 */                            pushbackInputStream.unread(bArr, 0, i2);
/* 81 */                            if (i2 == 4) {
                                        break;
                                    }
                                    this.L$0 = inputStream;
                                    this.L$1 = backupService;
                                    this.L$2 = objectRef2;
                                    this.L$3 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                    this.L$4 = backupArchive;
                                    this.L$5 = SpillingKt.nullOutSpilledVariable(pushbackInputStream);
                                    this.L$6 = SpillingKt.nullOutSpilledVariable(bArr);
                                    this.I$0 = i;
                                    this.I$1 = i2;
                                    this.label = 3;
/* 28 */                            v1 = backupService.readV1(pushbackInputStream, backupArchive, this);
                                    if (v1 == coroutine_suspended) {
/* 73 */                                return coroutine_suspended;
                                    }
/* 73 */                            backupManifest = (BackupManifest) v1;
/* 82 */                            ?? preparedBackup5 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                            objectRef2.element = preparedBackup5;
/* 74 */                            CloseableKt.closeFinally(inputStream, null);
/* 83 */                            return preparedBackup5;
                                case 2:
                                    int i4 = this.I$1;
                                    int i5 = this.I$0;
                                    backupArchive = (BackupArchive) this.L$4;
                                    objectRef2 = (Ref.ObjectRef) this.L$2;
                                    backupService = (BackupService) this.L$1;
                                    inputStream = (Closeable) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    zip = $result;
                                    backupManifest = (BackupManifest) zip;
/* 82 */                            ?? preparedBackup6 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                            objectRef2.element = preparedBackup6;
/* 74 */                            CloseableKt.closeFinally(inputStream, null);
/* 83 */                            return preparedBackup6;
                                case 3:
                                    int i6 = this.I$1;
                                    int i7 = this.I$0;
                                    backupArchive = (BackupArchive) this.L$4;
                                    objectRef2 = (Ref.ObjectRef) this.L$2;
                                    backupService = (BackupService) this.L$1;
                                    inputStream = (Closeable) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    v1 = $result;
/* 73 */                            backupManifest = (BackupManifest) v1;
/* 82 */                            ?? preparedBackup7 = new PreparedBackup(backupArchive, backupManifest, backupService);
/* 82 */                            objectRef2.element = preparedBackup7;
/* 74 */                            CloseableKt.closeFinally(inputStream, null);
/* 83 */                            return preparedBackup7;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (Throwable th) {
                            try {
                                throw th;
                            } catch (Throwable th2) {
                                CloseableKt.closeFinally(inputStream, th);
                                throw th2;
                            }
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$prepare$3, reason: invalid class name */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$prepare$3", f = "BackupService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 84 */        static final class AnonymousClass3 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Ref.ObjectRef<BackupArchive> $archive;
                    final /* synthetic */ Throwable $e;
                    final /* synthetic */ InputStream $input;
                    final /* synthetic */ Ref.ObjectRef<PreparedBackup> $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass3(Ref.ObjectRef<PreparedBackup> objectRef, Ref.ObjectRef<BackupArchive> objectRef2, Throwable th, InputStream inputStream, Continuation<? super AnonymousClass3> continuation) {
                        super(2, continuation);
                        this.$prepared = objectRef;
                        this.$archive = objectRef2;
                        this.$e = th;
                        this.$input = inputStream;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass3(this.$prepared, this.$archive, this.$e, this.$input, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass3) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 85 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 87 */                            if (this.$prepared.element != null) {
                                        PreparedBackup preparedBackup = this.$prepared.element;
                                        Intrinsics.checkNotNull(preparedBackup);
                                        preparedBackup.close();
                                    } else {
                                        BackupArchive backupArchive = this.$archive.element;
                                        if (backupArchive != null) {
/* 87 */                                    backupArchive.getDb().close();
                                            MediaStoreKt.deletePrivateTree(backupArchive.getDirectory());
                                        }
                                    }
                                    break;
                                } catch (Exception cleanup) {
                                    ExceptionsKt.addSuppressed(this.$e, cleanup);
                                }
                                try {
/* 89 */                            this.$input.close();
                                    break;
                                } catch (Exception cleanup2) {
                                    ExceptionsKt.addSuppressed(this.$e, cleanup2);
                                }
/* 90 */                        return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:33:0x013d A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:34:0x013e  */
                /* JADX WARN: Code duplicated, block: B:38:0x0172 A[LOOP:0: B:36:0x016c->B:38:0x0172, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:7:0x001a  */
                /* JADX WARN: Multi-variable type inference failed */
/* 93 */        public final Object readV1(InputStream inputStream, BackupArchive backupArchive, Continuation<? super BackupManifest> continuation) throws Throwable {
                    C04311 c04311;
                    InputStream inputStream2;
                    long j;
                    byte[] bArr;
                    String str;
                    ByteArrayOutputStream byteArrayOutputStream;
                    BackupDocument backupDocument;
                    BackupDocument backupDocument2;
                    ByteArrayOutputStream byteArrayOutputStream2;
                    LinkedHashMap linkedHashMap;
                    BackupArchive backupArchive2 = backupArchive;
                    if (continuation instanceof C04311) {
                        c04311 = (C04311) continuation;
                        if ((c04311.label & Integer.MIN_VALUE) != 0) {
                            c04311.label -= Integer.MIN_VALUE;
                        } else {
                            c04311 = new C04311(continuation);
                        }
                    } else {
                        c04311 = new C04311(continuation);
                    }
                    Object obj = c04311.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    long j2 = 0;
                    boolean z = true;
                    switch (c04311.label) {
                        case 0:
                            ResultKt.throwOnFailure(obj);
/* 95 */                    ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
                            byte[] bArr2 = new byte[8192];
                            while (true) {
/* 96 */                        JobKt.ensureActive(c04311.getContext());
                                BackupArchive.checkSpace$default(backupArchive2, j2, 1, null);
                                inputStream2 = inputStream;
                                int i = inputStream2.read(bArr2);
                                if (i < 0) {
                                    j = j2;
/* 99 */                            byte[] byteArray = byteArrayOutputStream3.toByteArray();
                                    Intrinsics.checkNotNullExpressionValue(byteArray, "toByteArray(...)");
                                    String strUtf8 = BoundedApkgKt.utf8(byteArray);
                                    BoundedJson.INSTANCE.parse(strUtf8);
/* 100 */                           BackupDocument backupDocumentDecode = BackupCodec.INSTANCE.decode(strUtf8);
/* 101 */                           XunjiDatabase db = backupArchive2.getDb();
                                    C04323 c04323 = new C04323(backupArchive2, backupDocumentDecode, null);
                                    c04311.L$0 = SpillingKt.nullOutSpilledVariable(inputStream2);
                                    c04311.L$1 = backupArchive2;
                                    c04311.L$2 = byteArrayOutputStream3;
                                    c04311.L$3 = SpillingKt.nullOutSpilledVariable(bArr2);
                                    c04311.L$4 = SpillingKt.nullOutSpilledVariable(strUtf8);
                                    c04311.L$5 = backupDocumentDecode;
                                    c04311.label = 1;
                                    if (RoomDatabaseKt.withTransaction(db, c04323, c04311) == coroutine_suspended) {
/* 94 */                                return coroutine_suspended;
                                    }
/* 101 */                           bArr = bArr2;
                                    str = strUtf8;
                                    byteArrayOutputStream = byteArrayOutputStream3;
                                    backupDocument = backupDocumentDecode;
                                } else if (i != 0) {
                                    long j3 = j2;
                                    if ((((long) byteArrayOutputStream3.size()) + ((long) i) <= 52428800) != true) {
                                        throw new IllegalArgumentException("备份超过 50 MiB 上限".toString());
                                    }
                                    byteArrayOutputStream3.write(bArr2, 0, i);
                                    j2 = j3;
                                }
                            }
/* 109 */                   c04311.L$0 = SpillingKt.nullOutSpilledVariable(inputStream2);
                            c04311.L$1 = SpillingKt.nullOutSpilledVariable(backupArchive2);
                            c04311.L$2 = byteArrayOutputStream;
                            c04311.L$3 = SpillingKt.nullOutSpilledVariable(bArr);
                            c04311.L$4 = SpillingKt.nullOutSpilledVariable(str);
                            c04311.L$5 = backupDocument;
                            c04311.label = 2;
                            if (backupArchive2.validateDatabase(c04311) == coroutine_suspended) {
/* 94 */                        return coroutine_suspended;
                            }
/* 109 */                   backupDocument2 = backupDocument;
                            byteArrayOutputStream2 = byteArrayOutputStream;
/* 110 */                   List<String> recordTypes = BackupCodec.INSTANCE.getRecordTypes();
/* 161 */                   linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(recordTypes, 10)), 16));
                            for (Object obj2 : recordTypes) {
                                boolean z2 = z;
/* 164 */                       linkedHashMap.put(obj2, Boxing.boxLong(j));
/* 110 */                       backupArchive2 = backupArchive2;
                                z = z2;
                            }
/* 110 */                   Map mutableMap = MapsKt.toMutableMap(linkedHashMap);
/* 111 */                   Pair[] pairArr = new Pair[5];
                            pairArr[0] = TuplesKt.to("decks", Boxing.boxLong(backupDocument2.getDecks().size()));
                            pairArr[z ? 1 : 0] = TuplesKt.to("cards", Boxing.boxLong(backupDocument2.getCards().size()));
                            pairArr[2] = TuplesKt.to("schedules", Boxing.boxLong(backupDocument2.getSchedules().size()));
                            pairArr[3] = TuplesKt.to("review_logs", Boxing.boxLong(backupDocument2.getReviewLogs().size()));
                            pairArr[4] = TuplesKt.to("settings", Boxing.boxLong(1L));
                            mutableMap.putAll(MapsKt.mapOf(pairArr));
/* 112 */                   return new BackupManifest((String) null, 0, backupDocument2.getExportedAt(), mutableMap, byteArrayOutputStream2.size(), "", 0L, 0L, 3);
                        case 1:
                            backupDocument = (BackupDocument) c04311.L$5;
                            str = (String) c04311.L$4;
                            bArr = (byte[]) c04311.L$3;
                            ByteArrayOutputStream byteArrayOutputStream4 = (ByteArrayOutputStream) c04311.L$2;
                            backupArchive2 = (BackupArchive) c04311.L$1;
                            InputStream inputStream3 = (InputStream) c04311.L$0;
                            ResultKt.throwOnFailure(obj);
                            j = 0;
                            byteArrayOutputStream = byteArrayOutputStream4;
                            inputStream2 = inputStream3;
/* 109 */                   c04311.L$0 = SpillingKt.nullOutSpilledVariable(inputStream2);
                            c04311.L$1 = SpillingKt.nullOutSpilledVariable(backupArchive2);
                            c04311.L$2 = byteArrayOutputStream;
                            c04311.L$3 = SpillingKt.nullOutSpilledVariable(bArr);
                            c04311.L$4 = SpillingKt.nullOutSpilledVariable(str);
                            c04311.L$5 = backupDocument;
                            c04311.label = 2;
                            if (backupArchive2.validateDatabase(c04311) == coroutine_suspended) {
/* 94 */                        return coroutine_suspended;
                            }
/* 109 */                   backupDocument2 = backupDocument;
                            byteArrayOutputStream2 = byteArrayOutputStream;
/* 110 */                   List<String> recordTypes2 = BackupCodec.INSTANCE.getRecordTypes();
/* 161 */                   linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(recordTypes2, 10)), 16));
                            while (r21.hasNext()) {
                                boolean z3 = z;
/* 164 */                       linkedHashMap.put(obj2, Boxing.boxLong(j));
/* 110 */                       backupArchive2 = backupArchive2;
                                z = z3;
                            }
/* 110 */                   Map mutableMap2 = MapsKt.toMutableMap(linkedHashMap);
/* 111 */                   Pair[] pairArr2 = new Pair[5];
                            pairArr2[0] = TuplesKt.to("decks", Boxing.boxLong(backupDocument2.getDecks().size()));
                            pairArr2[z ? 1 : 0] = TuplesKt.to("cards", Boxing.boxLong(backupDocument2.getCards().size()));
                            pairArr2[2] = TuplesKt.to("schedules", Boxing.boxLong(backupDocument2.getSchedules().size()));
                            pairArr2[3] = TuplesKt.to("review_logs", Boxing.boxLong(backupDocument2.getReviewLogs().size()));
                            pairArr2[4] = TuplesKt.to("settings", Boxing.boxLong(1L));
                            mutableMap2.putAll(MapsKt.mapOf(pairArr2));
/* 112 */                   return new BackupManifest((String) null, 0, backupDocument2.getExportedAt(), mutableMap2, byteArrayOutputStream2.size(), "", 0L, 0L, 3);
                        case 2:
                            backupDocument2 = (BackupDocument) c04311.L$5;
                            byteArrayOutputStream2 = (ByteArrayOutputStream) c04311.L$2;
                            backupArchive2 = (BackupArchive) c04311.L$1;
                            ResultKt.throwOnFailure(obj);
                            j = 0;
/* 110 */                   List<String> recordTypes3 = BackupCodec.INSTANCE.getRecordTypes();
/* 161 */                   linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(recordTypes3, 10)), 16));
                            while (r21.hasNext()) {
                                boolean z4 = z;
/* 164 */                       linkedHashMap.put(obj2, Boxing.boxLong(j));
/* 110 */                       backupArchive2 = backupArchive2;
                                z = z4;
                            }
/* 110 */                   Map mutableMap3 = MapsKt.toMutableMap(linkedHashMap);
/* 111 */                   Pair[] pairArr3 = new Pair[5];
                            pairArr3[0] = TuplesKt.to("decks", Boxing.boxLong(backupDocument2.getDecks().size()));
                            pairArr3[z ? 1 : 0] = TuplesKt.to("cards", Boxing.boxLong(backupDocument2.getCards().size()));
                            pairArr3[2] = TuplesKt.to("schedules", Boxing.boxLong(backupDocument2.getSchedules().size()));
                            pairArr3[3] = TuplesKt.to("review_logs", Boxing.boxLong(backupDocument2.getReviewLogs().size()));
                            pairArr3[4] = TuplesKt.to("settings", Boxing.boxLong(1L));
                            mutableMap3.putAll(MapsKt.mapOf(pairArr3));
/* 112 */                   return new BackupManifest((String) null, 0, backupDocument2.getExportedAt(), mutableMap3, byteArrayOutputStream2.size(), "", 0L, 0L, 3);
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$readV1$3, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$readV1$3", f = "BackupService.kt", i = {0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4}, l = {103, LocationRequestCompat.QUALITY_LOW_POWER, 105, 106, 107}, m = "invokeSuspend", n = {"dao", "$this$forEach\\1", "element\\1", "it\\2", "$i$f$forEach\\1\\103", "$i$a$-forEach-BackupService$readV1$3$1\\2\\160\\0", "dao", "$this$forEach\\3", "element\\3", "it\\4", "$i$f$forEach\\3\\104", "$i$a$-forEach-BackupService$readV1$3$2\\4\\162\\0", "dao", "$this$forEach\\5", "element\\5", "it\\6", "$i$f$forEach\\5\\105", "$i$a$-forEach-BackupService$readV1$3$3\\6\\164\\0", "dao", "$this$forEach\\7", "element\\7", "it\\8", "$i$f$forEach\\7\\106", "$i$a$-forEach-BackupService$readV1$3$4\\8\\166\\0", "dao"}, s = {"L$0", "L$1", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$3", "L$4", "I$0", "I$1", "L$0", "L$1", "L$3", "L$4", "I$0", "I$1", "L$0"}, v = 1)
/* 99 */        static final class C04323 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ BackupDocument $d;
                    final /* synthetic */ BackupArchive $stage;
                    int I$0;
                    int I$1;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04323(BackupArchive backupArchive, BackupDocument backupDocument, Continuation<? super C04323> continuation) {
                        super(1, continuation);
                        this.$stage = backupArchive;
                        this.$d = backupDocument;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return new C04323(this.$stage, this.$d, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04323) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:14:0x00c9  */
                    /* JADX WARN: Code duplicated, block: B:16:0x00ff A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:17:0x0100  */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:17:0x0100 -> B:18:0x0109). Please report as a decompilation issue!!! */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:25:0x015e -> B:26:0x0167). Please report as a decompilation issue!!! */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:33:0x01bc -> B:34:0x01c5). Please report as a decompilation issue!!! */
                    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:41:0x021c -> B:42:0x0224). Please report as a decompilation issue!!! */
                    /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                        jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                        */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 100 */           public final java.lang.Object invokeSuspend(java.lang.Object r13) {
                        /*
                            Method dump skipped, instruction units count: 614
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.backup.BackupService.C04323.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

                /* JADX WARN: Code duplicated, block: B:49:0x010f A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:50:0x0110  */
                /* JADX WARN: Code duplicated, block: B:57:0x011b  */
                /* JADX WARN: Code duplicated, block: B:70:0x015a A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:71:0x015b  */
                /* JADX WARN: Code duplicated, block: B:79:0x0169  */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
                /* JADX WARN: Code duplicated, block: B:80:0x016a A[Catch: all -> 0x016b, TRY_ENTER, TRY_LEAVE, TryCatch #8 {all -> 0x016b, blocks: (B:66:0x012c, B:80:0x016a), top: B:104:0x012c }] */
                /* JADX WARN: Code duplicated, block: B:85:0x0199 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:86:0x019a  */
                /* JADX WARN: Code duplicated, block: B:92:0x01a6  */
                /* JADX WARN: Code duplicated, block: B:93:0x01a7 A[ORIG_RETURN] */
                /* JADX WARN: Code duplicated, block: B:98:0x0130 A[EXC_TOP_SPLITTER, SYNTHETIC] */
/* 113 */       public final Object replace(PreparedBackup prepared, Continuation<? super Unit> continuation) throws Throwable {
                    C04331 c04331;
                    Job caller;
                    Ref.BooleanRef committed;
                    CancellationException cancellationException;
                    Job caller2;
                    Ref.BooleanRef committed2;
                    Throwable th;
                    Ref.BooleanRef committed3;
                    CoroutineContext coroutineContextPlus;
                    AnonymousClass4 anonymousClass4;
                    Ref.BooleanRef committed4;
                    CoroutineContext coroutineContextPlus2;
                    AnonymousClass4 anonymousClass5;
                    Ref.BooleanRef committed5;
                    CoroutineContext coroutineContextPlus3;
                    AnonymousClass4 anonymousClass6;
                    if (continuation instanceof C04331) {
                        c04331 = (C04331) continuation;
                        if ((c04331.label & Integer.MIN_VALUE) != 0) {
                            c04331.label -= Integer.MIN_VALUE;
                        } else {
                            c04331 = new C04331(continuation);
                        }
                    } else {
                        c04331 = new C04331(continuation);
                    }
                    C04331 c04332 = c04331;
                    Object $result = c04332.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04332.label) {
                        case 0:
/* 114 */                   ResultKt.throwOnFailure($result);
/* 115 */                   if (!(prepared.getOwner() == this)) {
                                throw new IllegalArgumentException("Backup preview belongs to another service".toString());
                            }
/* 116 */                   prepared.acquire$app_debug();
/* 117 */                   caller = (Job) c04332.getContext().get(Job.INSTANCE);
                            committed = new Ref.BooleanRef();
                            try {
/* 119 */                       CoroutineDispatcher io2 = Dispatchers.getIO();
                                try {
                                    C04343 c04343 = new C04343(caller, prepared, committed, null);
                                    c04332.L$0 = prepared;
                                    c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                    c04332.L$2 = committed;
                                    c04332.label = 1;
                                    if (BuildersKt.withContext(io2, c04343, c04332) == coroutine_suspended) {
/* 114 */                               return coroutine_suspended;
                                    }
/* 119 */                           caller2 = caller;
                                    prepared = prepared;
                                    committed2 = committed;
                                    try {
/* 152 */                               coroutineContextPlus3 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                        anonymousClass6 = new AnonymousClass4(prepared, committed2, null);
                                        c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                        c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller2);
                                        c04332.L$2 = committed2;
                                        c04332.label = 2;
                                        if (BuildersKt.withContext(coroutineContextPlus3, anonymousClass6, c04332) == coroutine_suspended) {
/* 114 */                                   return coroutine_suspended;
                                        }
/* 157 */                               return Unit.INSTANCE;
                                    } catch (CancellationException e) {
/* 155 */                               e = e;
                                        committed5 = committed2;
                                        if (!committed5.element) {
/* 155 */                                   throw e;
                                        }
                                    }
                                } catch (CancellationException e2) {
/* 150 */                           e = e2;
                                    prepared = prepared;
                                    try {
                                        if (committed.element) {
/* 150 */                                   throw e;
                                        }
                                        try {
/* 152 */                                   coroutineContextPlus2 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                            anonymousClass5 = new AnonymousClass4(prepared, committed, null);
                                            c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                            c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                            c04332.L$2 = committed;
                                            c04332.label = 3;
                                            if (BuildersKt.withContext(coroutineContextPlus2, anonymousClass5, c04332) == coroutine_suspended) {
/* 114 */                                       return coroutine_suspended;
                                            }
                                        } catch (CancellationException e3) {
/* 155 */                                   e = e3;
                                            committed4 = committed;
                                            if (!committed4.element) {
/* 155 */                                       throw e;
                                            }
                                        }
                                    } catch (Throwable e4) {
                                        cancellationException = e4;
                                        try {
                                            coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                            anonymousClass4 = new AnonymousClass4(prepared, committed, null);
                                            c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                            c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                            c04332.L$2 = committed;
                                            c04332.L$3 = cancellationException;
                                            c04332.label = 4;
                                            if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, c04332) == coroutine_suspended) {
/* 114 */                                       return coroutine_suspended;
                                            }
/* 152 */                                   throw cancellationException;
                                        } catch (CancellationException e5) {
/* 155 */                                   e = e5;
                                            th = cancellationException;
                                            committed3 = committed;
                                            if (committed3.element) {
                                                throw th;
                                            }
                                            throw e;
                                        }
                                    }
                                } catch (Throwable e6) {
                                    cancellationException = e6;
                                    prepared = prepared;
                                    coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                    anonymousClass4 = new AnonymousClass4(prepared, committed, null);
                                    c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                    c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                    c04332.L$2 = committed;
                                    c04332.L$3 = cancellationException;
                                    c04332.label = 4;
                                    if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, c04332) == coroutine_suspended) {
/* 114 */                               return coroutine_suspended;
                                    }
/* 152 */                           throw cancellationException;
                                }
                            } catch (CancellationException e7) {
/* 150 */                       e = e7;
                            } catch (Throwable th2) {
                                cancellationException = th2;
                                prepared = prepared;
                            }
                            break;
                        case 1:
/* 114 */                   committed2 = (Ref.BooleanRef) c04332.L$2;
                            caller2 = (Job) c04332.L$1;
                            prepared = (PreparedBackup) c04332.L$0;
                            try {
                                ResultKt.throwOnFailure($result);
/* 152 */                       coroutineContextPlus3 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass6 = new AnonymousClass4(prepared, committed2, null);
                                c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller2);
                                c04332.L$2 = committed2;
                                c04332.label = 2;
                                if (BuildersKt.withContext(coroutineContextPlus3, anonymousClass6, c04332) == coroutine_suspended) {
/* 114 */                           return coroutine_suspended;
                                }
/* 157 */                       return Unit.INSTANCE;
                            } catch (CancellationException e8) {
/* 150 */                       e = e8;
                                committed = committed2;
                                caller = caller2;
                                if (committed.element) {
/* 150 */                           throw e;
                                }
/* 152 */                       coroutineContextPlus2 = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass5 = new AnonymousClass4(prepared, committed, null);
                                c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                c04332.L$2 = committed;
                                c04332.label = 3;
                                if (BuildersKt.withContext(coroutineContextPlus2, anonymousClass5, c04332) == coroutine_suspended) {
/* 114 */                           return coroutine_suspended;
                                }
                            } catch (Throwable th3) {
                                committed = committed2;
                                caller = caller2;
                                cancellationException = th3;
                                coroutineContextPlus = NonCancellable.INSTANCE.plus(Dispatchers.getIO());
                                anonymousClass4 = new AnonymousClass4(prepared, committed, null);
                                c04332.L$0 = SpillingKt.nullOutSpilledVariable(prepared);
                                c04332.L$1 = SpillingKt.nullOutSpilledVariable(caller);
                                c04332.L$2 = committed;
                                c04332.L$3 = cancellationException;
                                c04332.label = 4;
                                if (BuildersKt.withContext(coroutineContextPlus, anonymousClass4, c04332) == coroutine_suspended) {
/* 114 */                           return coroutine_suspended;
                                }
/* 152 */                       throw cancellationException;
                            }
                        case 2:
/* 114 */                   committed5 = (Ref.BooleanRef) c04332.L$2;
                            try {
                                ResultKt.throwOnFailure($result);
                                break;
                            } catch (CancellationException e9) {
/* 155 */                       e = e9;
                                if (!committed5.element) {
/* 155 */                           throw e;
                                }
                            }
/* 157 */                   return Unit.INSTANCE;
                        case 3:
/* 114 */                   committed4 = (Ref.BooleanRef) c04332.L$2;
                            try {
                                ResultKt.throwOnFailure($result);
                                break;
                            } catch (CancellationException e10) {
/* 155 */                       e = e10;
                                if (!committed4.element) {
/* 155 */                           throw e;
                                }
                            }
/* 157 */                   return Unit.INSTANCE;
                        case 4:
                            th = (Throwable) c04332.L$3;
                            committed3 = (Ref.BooleanRef) c04332.L$2;
                            try {
                                ResultKt.throwOnFailure($result);
                                throw th;
                            } catch (CancellationException e11) {
/* 155 */                       e = e11;
                                if (committed3.element) {
                                    throw e;
                                }
                                throw th;
                            }
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3", f = "BackupService.kt", i = {}, l = {MenuKt.InTransitionDuration}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 117 */       static final class C04343 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Object>, Object> {
                    final /* synthetic */ Job $caller;
                    final /* synthetic */ Ref.BooleanRef $committed;
                    final /* synthetic */ PreparedBackup $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04343(Job job, PreparedBackup preparedBackup, Ref.BooleanRef booleanRef, Continuation<? super C04343> continuation) {
                        super(2, continuation);
                        this.$caller = job;
                        this.$prepared = preparedBackup;
                        this.$committed = booleanRef;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return BackupService.this.new C04343(this.$caller, this.$prepared, this.$committed, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Object invoke(CoroutineScope coroutineScope, Continuation<? super Object> continuation) {
                        return invoke2(coroutineScope, (Continuation<Object>) continuation);
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final Object invoke2(CoroutineScope coroutineScope, Continuation<Object> continuation) {
                        return ((C04343) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3$1, reason: invalid class name */
                    /* JADX INFO: compiled from: BackupService.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lcom/xunji/flashcards/anki/FileOperationCoordinator$Operation;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3$1", f = "BackupService.kt", i = {0, 1, 1, 2, 2}, l = {121, 125, 126}, m = "invokeSuspend", n = {"$this$withLock", "$this$withLock", "archive", "$this$withLock", "archive"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1"}, v = 1)
/* 118 */           static final class AnonymousClass1 extends SuspendLambda implements Function2<FileOperationCoordinator.Operation, Continuation<? super Object>, Object> {
                        final /* synthetic */ Job $caller;
                        final /* synthetic */ Ref.BooleanRef $committed;
                        final /* synthetic */ PreparedBackup $prepared;
                        private /* synthetic */ Object L$0;
                        Object L$1;
                        int label;
                        final /* synthetic */ BackupService this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(BackupService backupService, Job job, PreparedBackup preparedBackup, Ref.BooleanRef booleanRef, Continuation<? super AnonymousClass1> continuation) {
                            super(2, continuation);
                            this.this$0 = backupService;
                            this.$caller = job;
                            this.$prepared = preparedBackup;
                            this.$committed = booleanRef;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.this$0, this.$caller, this.$prepared, this.$committed, continuation);
                            anonymousClass1.L$0 = obj;
                            return anonymousClass1;
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final Object invoke2(FileOperationCoordinator.Operation operation, Continuation<Object> continuation) {
                            return ((AnonymousClass1) create(operation, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ Object invoke(FileOperationCoordinator.Operation operation, Continuation<? super Object> continuation) {
                            return invoke2(operation, (Continuation<Object>) continuation);
                        }

                        /* JADX WARN: Code duplicated, block: B:14:0x0045  */
                        /* JADX WARN: Code duplicated, block: B:17:0x005b  */
                        /* JADX WARN: Code duplicated, block: B:18:0x005d  */
                        /* JADX WARN: Code duplicated, block: B:20:0x0060  */
                        /* JADX WARN: Code duplicated, block: B:22:0x0085 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:23:0x0086  */
                        /* JADX WARN: Code duplicated, block: B:26:0x00b2 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:27:0x00b3  */
                        /* JADX WARN: Code duplicated, block: B:29:0x00b5  */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 119 */               public final Object invokeSuspend(Object $result) throws Throwable {
                            Job job;
                            boolean z;
                            BackupArchive archive;
                            BackupArchive archive2;
                            Object objWithContext;
                            FileOperationCoordinator.Operation $this$withLock = (FileOperationCoordinator.Operation) this.L$0;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
                                    this.L$0 = $this$withLock;
                                    this.label = 1;
/* 28 */                            if (this.this$0.initializeLocked($this$withLock, this) == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 121 */                           job = this.$caller;
                                    if (job != null) {
                                        JobKt.ensureActive(job);
                                    }
                                    if (this.this$0.coordinator.getRestoreEpoch() < Long.MAX_VALUE) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
                                        throw new IllegalArgumentException("Restore epoch exhausted".toString());
                                    }
/* 123 */                           archive = this.$prepared.getArchive();
/* 124 */                           BackupArchive.checkSpace$default(archive, 0L, 1, null);
                                    this.L$0 = $this$withLock;
                                    this.L$1 = archive;
                                    this.label = 2;
/* 125 */                           if (archive.objects(new AnonymousClass2(this.this$0, $this$withLock, archive, null), this) == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 125 */                           archive2 = archive;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(archive2);
                                    this.label = 3;
/* 126 */                           objWithContext = BuildersKt.withContext(NonCancellable.INSTANCE, new C00983(this.this$0, $this$withLock, this.$committed, archive2, this.$caller, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 147 */                           return objWithContext;
                                case 1:
                                    ResultKt.throwOnFailure($result);
/* 121 */                           job = this.$caller;
                                    if (job != null) {
                                        JobKt.ensureActive(job);
                                    }
                                    if (this.this$0.coordinator.getRestoreEpoch() < Long.MAX_VALUE) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
                                        throw new IllegalArgumentException("Restore epoch exhausted".toString());
                                    }
/* 123 */                           archive = this.$prepared.getArchive();
/* 124 */                           BackupArchive.checkSpace$default(archive, 0L, 1, null);
                                    this.L$0 = $this$withLock;
                                    this.L$1 = archive;
                                    this.label = 2;
/* 125 */                           if (archive.objects(new AnonymousClass2(this.this$0, $this$withLock, archive, null), this) == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 125 */                           archive2 = archive;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(archive2);
                                    this.label = 3;
/* 126 */                           objWithContext = BuildersKt.withContext(NonCancellable.INSTANCE, new C00983(this.this$0, $this$withLock, this.$committed, archive2, this.$caller, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 147 */                           return objWithContext;
                                case 2:
                                    BackupArchive archive3 = (BackupArchive) this.L$1;
                                    ResultKt.throwOnFailure($result);
                                    archive2 = archive3;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable($this$withLock);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(archive2);
                                    this.label = 3;
/* 126 */                           objWithContext = BuildersKt.withContext(NonCancellable.INSTANCE, new C00983(this.this$0, $this$withLock, this.$committed, archive2, this.$caller, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 120 */                               return coroutine_suspended;
                                    }
/* 147 */                           return objWithContext;
                                case 3:
                                    ResultKt.throwOnFailure($result);
                                    return $result;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }

                        /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: BackupService.kt */
                        @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "mapping", "Lcom/xunji/flashcards/data/AnkiMediaEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3$1$2", f = "BackupService.kt", i = {0}, l = {125}, m = "invokeSuspend", n = {"mapping"}, s = {"L$0"}, v = 1)
/* 123 */               static final class AnonymousClass2 extends SuspendLambda implements Function2<AnkiMediaEntity, Continuation<? super Unit>, Object> {
                            final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                            final /* synthetic */ BackupArchive $archive;
                            /* synthetic */ Object L$0;
                            int label;
                            final /* synthetic */ BackupService this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            AnonymousClass2(BackupService backupService, FileOperationCoordinator.Operation operation, BackupArchive backupArchive, Continuation<? super AnonymousClass2> continuation) {
                                super(2, continuation);
                                this.this$0 = backupService;
                                this.$$this$withLock = operation;
                                this.$archive = backupArchive;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.this$0, this.$$this$withLock, this.$archive, continuation);
                                anonymousClass2.L$0 = obj;
                                return anonymousClass2;
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(AnkiMediaEntity ankiMediaEntity, Continuation<? super Unit> continuation) {
                                return ((AnonymousClass2) create(ankiMediaEntity, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 124 */                   public final Object invokeSuspend(Object $result) throws Throwable {
                                AnkiMediaEntity mapping = (AnkiMediaEntity) this.L$0;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(mapping);
                                        this.label = 1;
/* 28 */                                if (this.this$0.media.promoteObjectLocked$app_debug(this.$$this$withLock, new File(this.$archive.getMediaDirectory(), mapping.getSha256()), mapping, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                return Unit.INSTANCE;
                            }
                        }

                        /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3$1$3, reason: invalid class name and collision with other inner class name */
                        /* JADX INFO: compiled from: BackupService.kt */
                        @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                        @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3$1$3", f = "BackupService.kt", i = {}, l = {WorkQueueKt.MASK, 146}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 124 */               static final class C00983 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Object>, Object> {
                            final /* synthetic */ FileOperationCoordinator.Operation $$this$withLock;
                            final /* synthetic */ BackupArchive $archive;
                            final /* synthetic */ Job $caller;
                            final /* synthetic */ Ref.BooleanRef $committed;
                            int label;
                            final /* synthetic */ BackupService this$0;

                            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                            C00983(BackupService backupService, FileOperationCoordinator.Operation operation, Ref.BooleanRef booleanRef, BackupArchive backupArchive, Job job, Continuation<? super C00983> continuation) {
                                super(2, continuation);
                                this.this$0 = backupService;
                                this.$$this$withLock = operation;
                                this.$committed = booleanRef;
                                this.$archive = backupArchive;
                                this.$caller = job;
                            }

                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                            public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                                return new C00983(this.this$0, this.$$this$withLock, this.$committed, this.$archive, this.$caller, continuation);
                            }

                            @Override // kotlin.jvm.functions.Function2
                            public /* bridge */ /* synthetic */ Object invoke(CoroutineScope coroutineScope, Continuation<? super Object> continuation) {
                                return invoke2(coroutineScope, (Continuation<Object>) continuation);
                            }

                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                            public final Object invoke2(CoroutineScope coroutineScope, Continuation<Object> continuation) {
                                return ((C00983) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                            }

                            /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3$1$3$1, reason: invalid class name and collision with other inner class name */
                            /* JADX INFO: compiled from: BackupService.kt */
                            @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3$1$3$1", f = "BackupService.kt", i = {0}, l = {131}, m = "invokeSuspend", n = {"sql"}, s = {"L$0"}, v = 1)
/* 125 */                   static final class C00991 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                                final /* synthetic */ BackupArchive $archive;
                                final /* synthetic */ Job $caller;
                                Object L$0;
                                int label;
                                final /* synthetic */ BackupService this$0;

                                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                C00991(BackupService backupService, BackupArchive backupArchive, Job job, Continuation<? super C00991> continuation) {
                                    super(1, continuation);
                                    this.this$0 = backupService;
                                    this.$archive = backupArchive;
                                    this.$caller = job;
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Continuation<Unit> create(Continuation<?> continuation) {
                                    return new C00991(this.this$0, this.$archive, this.$caller, continuation);
                                }

                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Continuation<? super Unit> continuation) {
                                    return ((C00991) create(continuation)).invokeSuspend(Unit.INSTANCE);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 126 */                       public final Object invokeSuspend(Object $result) throws Throwable {
                                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
/* 28 */                                    SupportSQLiteDatabase sql = this.this$0.db.getOpenHelper().getWritableDatabase();
/* 160 */                                   Iterator it = CollectionsKt.listOf((Object[]) new String[]{"anki_cards", "anki_media", "anki_notes", "anki_models", "anki_deck_sources", "review_logs", "schedules", "cards", "decks", "settings"}).iterator();
                                            while (it.hasNext()) {
/* 130 */                                       sql.execSQL("DELETE FROM `" + ((String) it.next()) + "`");
                                            }
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(sql);
                                            this.label = 1;
/* 131 */                                   if (BackupArchive.forEachRecord$default(this.$archive, null, new AnonymousClass2(this.$caller, this.$archive, sql, null), this, 1, null) == coroutine_suspended) {
/* 127 */                                       return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
/* 143 */                           Job job = this.$caller;
                                    if (job == null) {
                                        return null;
                                    }
                                    JobKt.ensureActive(job);
                                    return Unit.INSTANCE;
                                }

                                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$3$1$3$1$2, reason: invalid class name */
                                /* JADX INFO: compiled from: BackupService.kt */
                                @Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H\n"}, d2 = {"<anonymous>", "", ClassDiscriminatorModeKt.CLASS_DISCRIMINATOR_KEY, "", "row", "Lkotlinx/serialization/json/JsonObject;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$3$1$3$1$2", f = "BackupService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 129 */                       static final class AnonymousClass2 extends SuspendLambda implements Function3<String, JsonObject, Continuation<? super Unit>, Object> {
                                    final /* synthetic */ BackupArchive $archive;
                                    final /* synthetic */ Job $caller;
                                    final /* synthetic */ SupportSQLiteDatabase $sql;
                                    /* synthetic */ Object L$0;
                                    /* synthetic */ Object L$1;
                                    int label;

                                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                                    AnonymousClass2(Job job, BackupArchive backupArchive, SupportSQLiteDatabase supportSQLiteDatabase, Continuation<? super AnonymousClass2> continuation) {
                                        super(3, continuation);
                                        this.$caller = job;
                                        this.$archive = backupArchive;
                                        this.$sql = supportSQLiteDatabase;
                                    }

                                    @Override // kotlin.jvm.functions.Function3
                                    public final Object invoke(String str, JsonObject jsonObject, Continuation<? super Unit> continuation) {
                                        AnonymousClass2 anonymousClass2 = new AnonymousClass2(this.$caller, this.$archive, this.$sql, continuation);
                                        anonymousClass2.L$0 = str;
                                        anonymousClass2.L$1 = jsonObject;
                                        return anonymousClass2.invokeSuspend(Unit.INSTANCE);
                                    }

                                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 130 */                           public final Object invokeSuspend(Object $result) throws Throwable {
                                        Object longOrNull;
                                        Object obj;
                                        String type = (String) this.L$0;
                                        JsonObject row = (JsonObject) this.L$1;
                                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                        switch (this.label) {
                                            case 0:
                                                ResultKt.throwOnFailure($result);
/* 132 */                                       Job job = this.$caller;
                                                if (job != null) {
                                                    JobKt.ensureActive(job);
                                                }
                                                BackupArchive.checkSpace$default(this.$archive, 0L, 1, null);
/* 133 */                                       Iterable fields = CollectionsKt.toList(row.keySet());
/* 134 */                                       Iterable iterable = fields;
/* 160 */                                       Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 161 */                                       Iterator it = iterable.iterator();
                                                while (it.hasNext()) {
/* 162 */                                           JsonElement jsonElement = (JsonElement) MapsKt.getValue(row, (String) it.next());
/* 136 */                                           if (Intrinsics.areEqual(jsonElement, JsonNull.INSTANCE)) {
                                                        obj = null;
                                                    } else {
/* 137 */                                               Intrinsics.checkNotNull(jsonElement, "null cannot be cast to non-null type kotlinx.serialization.json.JsonPrimitive");
                                                        JsonPrimitive jsonPrimitive = (JsonPrimitive) jsonElement;
/* 138 */                                               if (jsonPrimitive.isString()) {
                                                            longOrNull = jsonPrimitive.getContent();
                                                        } else {
                                                            longOrNull = StringsKt.toLongOrNull(jsonPrimitive.getContent());
                                                            if (longOrNull == null) {
                                                                longOrNull = Boxing.boxDouble(Double.parseDouble(jsonPrimitive.getContent()));
                                                            }
                                                        }
                                                        obj = longOrNull;
                                                    }
/* 162 */                                           arrayList.add(obj);
                                                }
/* 164 */                                       Object[] values = ((List) arrayList).toArray(new Object[0]);
/* 141 */                                       execSQL("INSERT INTO `" + type + "` (" + CollectionsKt.joinToString$default(fields, null, null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.backup.BackupService$replace$3$1$3$1$2$$ExternalSyntheticLambda0
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj2) {
                                                        return BackupService.C04343.AnonymousClass1.C00983.C00991.AnonymousClass2.invokeSuspend$lambda$1((String) obj2);
                                                    }
                                                }, 31, null) + ") VALUES (" + CollectionsKt.joinToString$default(fields, null, null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.backup.BackupService$replace$3$1$3$1$2$$ExternalSyntheticLambda1
                                                    @Override // kotlin.jvm.functions.Function1
                                                    public final Object invoke(Object obj2) {
                                                        return BackupService.C04343.AnonymousClass1.C00983.C00991.AnonymousClass2.invokeSuspend$lambda$2((String) obj2);
                                                    }
                                                }, 31, null) + ")", values);
/* 142 */                                       return Unit.INSTANCE;
                                            default:
                                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                        }
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
/* 140 */                           public static final CharSequence invokeSuspend$lambda$1(String it) {
/* 141 */                               return "`" + it + "`";
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
/* 140 */                           public static final CharSequence invokeSuspend$lambda$2(String it) {
/* 141 */                               return "?";
                                    }
                                }
                            }

                            /* JADX WARN: Code duplicated, block: B:17:0x005e A[RETURN] */
                            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 125 */                   public final Object invokeSuspend(Object $result) throws Throwable {
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                try {
                                    switch (this.label) {
                                        case 0:
                                            ResultKt.throwOnFailure($result);
                                            this.label = 1;
/* 28 */                                    if (RoomDatabaseKt.withTransaction(this.this$0.db, new C00991(this.this$0, this.$archive, this.$caller, null), this) == coroutine_suspended) {
/* 126 */                                       return coroutine_suspended;
                                            }
/* 145 */                                   this.$$this$withLock.markRestoreCommitted();
                                            this.$committed.element = true;
                                            this.label = 2;
/* 28 */                                    if (this.this$0.media.collectGarbageLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
/* 126 */                                       return coroutine_suspended;
                                            }
/* 146 */                                   return Unit.INSTANCE;
                                        case 1:
/* 126 */                                   ResultKt.throwOnFailure($result);
/* 145 */                                   this.$$this$withLock.markRestoreCommitted();
                                            this.$committed.element = true;
                                            this.label = 2;
/* 28 */                                    if (this.this$0.media.collectGarbageLocked$app_debug(this.$$this$withLock, this) == coroutine_suspended) {
/* 126 */                                       return coroutine_suspended;
                                            }
/* 146 */                                   return Unit.INSTANCE;
                                        case 2:
                                            ResultKt.throwOnFailure($result);
/* 146 */                                   return Unit.INSTANCE;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                } catch (Exception e) {
                                    return Boxing.boxInt(Log.w("BackupService", "Restored data; media cleanup will retry on startup", e));
                                }
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 118 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 28 */                        Object objWithLock = BackupService.this.coordinator.withLock(new AnonymousClass1(BackupService.this, this.$caller, this.$prepared, this.$committed, null), this);
                                if (objWithLock == coroutine_suspended) {
/* 119 */                           return coroutine_suspended;
                                }
/* 148 */                       return objWithLock;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.backup.BackupService$replace$4, reason: invalid class name */
                /* JADX INFO: compiled from: BackupService.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.backup.BackupService$replace$4", f = "BackupService.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 150 */       static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Object>, Object> {
                    final /* synthetic */ Ref.BooleanRef $committed;
                    final /* synthetic */ PreparedBackup $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass4(PreparedBackup preparedBackup, Ref.BooleanRef booleanRef, Continuation<? super AnonymousClass4> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedBackup;
                        this.$committed = booleanRef;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass4(this.$prepared, this.$committed, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public /* bridge */ /* synthetic */ Object invoke(CoroutineScope coroutineScope, Continuation<? super Object> continuation) {
                        return invoke2(coroutineScope, (Continuation<Object>) continuation);
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final Object invoke2(CoroutineScope coroutineScope, Continuation<Object> continuation) {
                        return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 151 */           public final Object invokeSuspend(Object $result) throws Exception {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
/* 153 */                           this.$prepared.close();
                                    this.$prepared.release$app_debug();
                                    return Unit.INSTANCE;
                                } catch (Exception e) {
                                    if (this.$committed.element) {
                                        return Boxing.boxInt(Log.w("BackupService", "Restored data; backup staging cleanup will retry on startup", e));
                                    }
                                    throw e;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }
            }

            package com.xunji.flashcards.backup;

            import android.net.Uri;
            import java.io.InputStream;
            import java.io.OutputStream;
            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            
            /* JADX INFO: compiled from: BackupFileGateway.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\bf\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H¦@¢\u0006\u0002\u0010\u0006J\u0016\u0010\u0007\u001a\u00020\b2\u0006\u0010\u0004\u001a\u00020\u0005H¦@¢\u0006\u0002\u0010\u0006¨\u0006\tÀ\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/backup/FileGateway;", "", "write", "Ljava/io/OutputStream;", "uri", "Landroid/net/Uri;", "(Landroid/net/Uri;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "read", "Ljava/io/InputStream;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface FileGateway {
                Object read(Uri uri, Continuation<? super InputStream> continuation);

                Object write(Uri uri, Continuation<? super OutputStream> continuation);
            }

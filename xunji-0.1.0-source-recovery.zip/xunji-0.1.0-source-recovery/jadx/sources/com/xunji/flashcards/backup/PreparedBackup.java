            package com.xunji.flashcards.backup;

            import com.github.luben.zstd.BuildConfig;
            import com.xunji.core.backup.BackupManifest;
            import com.xunji.flashcards.anki.MediaStoreKt;
            import java.io.Closeable;
            import java.io.IOException;
            import kotlin.Metadata;
            import kotlin.collections.MapsKt;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: BackupService.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\t\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001B!\b\u0000\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\r\u0010\u001b\u001a\u00020\u001cH\u0000¢\u0006\u0002\b\u001dJ\r\u0010\u001e\u001a\u00020\u001cH\u0000¢\u0006\u0002\b\u001fJ\b\u0010 \u001a\u00020\u001cH\u0016J\b\u0010!\u001a\u00020\u001cH\u0002R\u0014\u0010\u0002\u001a\u00020\u0003X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0014\u0010\u0004\u001a\u00020\u0005X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0014\u0010\u0006\u001a\u00020\u0007X\u0080\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0011\u0010\u0010\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0014\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0013R\u0011\u0010\u0016\u001a\u00020\u00118F¢\u0006\u0006\u001a\u0004\b\u0017\u0010\u0013R\u000e\u0010\u0018\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001a\u001a\u00020\u0019X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006\""}, d2 = {"Lcom/xunji/flashcards/backup/PreparedBackup;", "Ljava/io/Closeable;", "archive", "Lcom/xunji/flashcards/backup/BackupArchive;", "manifest", "Lcom/xunji/core/backup/BackupManifest;", "owner", "", "<init>", "(Lcom/xunji/flashcards/backup/BackupArchive;Lcom/xunji/core/backup/BackupManifest;Ljava/lang/Object;)V", "getArchive$app_debug", "()Lcom/xunji/flashcards/backup/BackupArchive;", "getManifest$app_debug", "()Lcom/xunji/core/backup/BackupManifest;", "getOwner$app_debug", "()Ljava/lang/Object;", "deckCount", "", "getDeckCount", "()J", "cardCount", "getCardCount", "logCount", "getLogCount", "closed", "", "busy", "acquire", "", "acquire$app_debug", BuildConfig.BUILD_TYPE, "release$app_debug", "close", "cleanup", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 14 */    public final class PreparedBackup implements Closeable {
                public static final int $stable = 8;
                private final BackupArchive archive;
                private boolean busy;
                private boolean closed;
                private final BackupManifest manifest;
                private final Object owner;

/* 15 */        public PreparedBackup(BackupArchive archive, BackupManifest manifest, Object owner) {
                    Intrinsics.checkNotNullParameter(archive, "archive");
                    Intrinsics.checkNotNullParameter(manifest, "manifest");
                    Intrinsics.checkNotNullParameter(owner, "owner");
                    this.archive = archive;
                    this.manifest = manifest;
                    this.owner = owner;
                }

                /* JADX INFO: renamed from: getArchive$app_debug, reason: from getter */
/* 15 */        public final BackupArchive getArchive() {
/* 16 */            return this.archive;
                }

                /* JADX INFO: renamed from: getManifest$app_debug, reason: from getter */
/* 15 */        public final BackupManifest getManifest() {
/* 16 */            return this.manifest;
                }

                /* JADX INFO: renamed from: getOwner$app_debug, reason: from getter */
/* 15 */        public final Object getOwner() {
/* 16 */            return this.owner;
                }

/* 16 */        public final long getDeckCount() {
/* 17 */            return ((Number) MapsKt.getValue(this.manifest.getCounts(), "decks")).longValue();
                }

/* 17 */        public final long getCardCount() {
/* 18 */            return ((Number) MapsKt.getValue(this.manifest.getCounts(), "cards")).longValue();
                }

/* 18 */        public final long getLogCount() {
/* 19 */            return ((Number) MapsKt.getValue(this.manifest.getCounts(), "review_logs")).longValue();
                }

/* 21 */        public final synchronized void acquire$app_debug() {
/* 22 */            if (!((this.closed || this.busy) ? false : true)) {
/* 22 */                throw new IllegalStateException("Backup preview expired".toString());
                    }
                    this.busy = true;
                }

/* 22 */        public final synchronized void release$app_debug() {
/* 23 */            this.busy = false;
                    if (this.closed) {
                        cleanup();
                    }
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 23 */        public synchronized void close() {
/* 24 */            if (!this.closed) {
                        this.closed = true;
                        if (!this.busy) {
                            cleanup();
                        }
                    }
                }

/* 24 */        private final void cleanup() throws IOException {
/* 25 */            this.archive.getDb().close();
                    MediaStoreKt.deletePrivateTree(this.archive.getDirectory());
                }
            }

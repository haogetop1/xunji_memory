            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000f\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0010\u001a\u00020\u0006HÆ\u0003J'\u0010\u0011\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0006HÆ\u0001J\u0013\u0010\u0012\u001a\u00020\u00132\b\u0010\u0014\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0015\u001a\u00020\u0006HÖ\u0001J\t\u0010\u0016\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\nR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\nR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\r¨\u0006\u0017"}, d2 = {"Lcom/xunji/flashcards/data/AnkiCardEntity;", "", "cardId", "", "noteId", "ordinal", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;I)V", "getCardId", "()Ljava/lang/String;", "getNoteId", "getOrdinal", "()I", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 21 */    public final /* data */ class AnkiCardEntity {
                public static final int $stable = 0;
                private final String cardId;
                private final String noteId;
                private final int ordinal;

                public static /* synthetic */ AnkiCardEntity copy$default(AnkiCardEntity ankiCardEntity, String str, String str2, int i, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        str = ankiCardEntity.cardId;
                    }
                    if ((i2 & 2) != 0) {
                        str2 = ankiCardEntity.noteId;
                    }
                    if ((i2 & 4) != 0) {
                        i = ankiCardEntity.ordinal;
                    }
                    return ankiCardEntity.copy(str, str2, i);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getNoteId() {
                    return this.noteId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final int getOrdinal() {
                    return this.ordinal;
                }

                public final AnkiCardEntity copy(String cardId, String noteId, int ordinal) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(noteId, "noteId");
                    return new AnkiCardEntity(cardId, noteId, ordinal);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiCardEntity)) {
                        return false;
                    }
                    AnkiCardEntity ankiCardEntity = (AnkiCardEntity) other;
                    return Intrinsics.areEqual(this.cardId, ankiCardEntity.cardId) && Intrinsics.areEqual(this.noteId, ankiCardEntity.noteId) && this.ordinal == ankiCardEntity.ordinal;
                }

                public int hashCode() {
                    return (((this.cardId.hashCode() * 31) + this.noteId.hashCode()) * 31) + Integer.hashCode(this.ordinal);
                }

                public String toString() {
                    return "AnkiCardEntity(cardId=" + this.cardId + ", noteId=" + this.noteId + ", ordinal=" + this.ordinal + ")";
                }

/* 22 */        public AnkiCardEntity(String cardId, String noteId, int ordinal) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(noteId, "noteId");
/* 27 */            this.cardId = cardId;
                    this.noteId = noteId;
                    this.ordinal = ordinal;
                }

/* 26 */        public final String getCardId() {
/* 27 */            return this.cardId;
                }

/* 26 */        public final String getNoteId() {
/* 27 */            return this.noteId;
                }

/* 26 */        public final int getOrdinal() {
/* 27 */            return this.ordinal;
                }
            }

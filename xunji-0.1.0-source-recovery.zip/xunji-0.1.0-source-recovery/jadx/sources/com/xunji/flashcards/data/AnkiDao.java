            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            
            /* JADX INFO: compiled from: AnkiDao.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\bg\u0018\u00002\u00020\u0001J\u0018\u0010\u0002\u001a\u0004\u0018\u00010\u00032\u0006\u0010\u0004\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0007\u001a\u0004\u0018\u00010\u00032\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0016\u0010\t\u001a\u00020\n2\u0006\u0010\u0002\u001a\u00020\u0003H§@¢\u0006\u0002\u0010\u000bJ\u000e\u0010\f\u001a\u00020\nH§@¢\u0006\u0002\u0010\rJ\u0018\u0010\u000e\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0004\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0018\u0010\u0010\u001a\u0004\u0018\u00010\u000f2\u0006\u0010\u0011\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0016\u0010\u0012\u001a\u00020\n2\u0006\u0010\u000e\u001a\u00020\u000fH§@¢\u0006\u0002\u0010\u0013J&\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0016\u001a\u00020\n2\u0006\u0010\u0017\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0018J\u0018\u0010\u0019\u001a\u0004\u0018\u00010\u001a2\u0006\u0010\u001b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u001c\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001a0\u001d2\u0006\u0010\u001e\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u0016\u0010\u001f\u001a\u00020 2\u0006\u0010\u0019\u001a\u00020\u001aH§@¢\u0006\u0002\u0010!J \u0010\"\u001a\u0004\u0018\u00010#2\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u0005H§@¢\u0006\u0002\u0010%J\u0016\u0010&\u001a\u00020 2\u0006\u0010'\u001a\u00020#H§@¢\u0006\u0002\u0010(J\u001c\u0010)\u001a\b\u0012\u0004\u0012\u00020*0\u001d2\u0006\u0010+\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J \u0010)\u001a\u0004\u0018\u00010*2\u0006\u0010+\u001a\u00020\u00052\u0006\u0010$\u001a\u00020\u0005H§@¢\u0006\u0002\u0010%J\u001c\u0010,\u001a\u00020 2\f\u0010)\u001a\b\u0012\u0004\u0012\u00020*0\u001dH§@¢\u0006\u0002\u0010-J\u0016\u0010.\u001a\u00020/2\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u0006J\u000e\u00100\u001a\u00020 H§@¢\u0006\u0002\u0010\r¨\u00061À\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/data/AnkiDao;", "", "model", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "id", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "modelByHash", "hash", "insertModel", "", "(Lcom/xunji/flashcards/data/AnkiModelEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "modelStorageBytes", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "note", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "noteByGuid", "guid", "insertNote", "(Lcom/xunji/flashcards/data/AnkiNoteEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateFields", "", "expectedRevision", "fields", "(Ljava/lang/String;JLjava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "link", "Lcom/xunji/flashcards/data/AnkiCardEntity;", "cardId", "links", "", "noteId", "insertLink", "", "(Lcom/xunji/flashcards/data/AnkiCardEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deckSource", "Lcom/xunji/flashcards/data/AnkiDeckSourceEntity;", HintConstants.AUTOFILL_HINT_NAME, "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertDeckSource", "source", "(Lcom/xunji/flashcards/data/AnkiDeckSourceEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "namespace", "insertMedia", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "mediaHashExists", "", "deleteUnusedMediaMappings", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface AnkiDao {
                Object deckSource(String str, String str2, Continuation<? super AnkiDeckSourceEntity> continuation);

                Object deleteUnusedMediaMappings(Continuation<? super Unit> continuation);

                Object insertDeckSource(AnkiDeckSourceEntity ankiDeckSourceEntity, Continuation<? super Unit> continuation);

                Object insertLink(AnkiCardEntity ankiCardEntity, Continuation<? super Unit> continuation);

                Object insertMedia(List<AnkiMediaEntity> list, Continuation<? super Unit> continuation);

                Object insertModel(AnkiModelEntity ankiModelEntity, Continuation<? super Long> continuation);

                Object insertNote(AnkiNoteEntity ankiNoteEntity, Continuation<? super Long> continuation);

                Object link(String str, Continuation<? super AnkiCardEntity> continuation);

                Object links(String str, Continuation<? super List<AnkiCardEntity>> continuation);

                Object media(String str, String str2, Continuation<? super AnkiMediaEntity> continuation);

                Object media(String str, Continuation<? super List<AnkiMediaEntity>> continuation);

                Object mediaHashExists(String str, Continuation<? super Boolean> continuation);

                Object model(String str, Continuation<? super AnkiModelEntity> continuation);

                Object modelByHash(String str, Continuation<? super AnkiModelEntity> continuation);

                Object modelStorageBytes(Continuation<? super Long> continuation);

                Object note(String str, Continuation<? super AnkiNoteEntity> continuation);

                Object noteByGuid(String str, Continuation<? super AnkiNoteEntity> continuation);

                Object updateFields(String str, long j, String str2, Continuation<? super Integer> continuation);
            }

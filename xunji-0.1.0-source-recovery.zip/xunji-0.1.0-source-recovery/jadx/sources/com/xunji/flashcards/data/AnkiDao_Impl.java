            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import androidx.room.EntityInsertAdapter;
            import androidx.room.RoomDatabase;
            import androidx.room.util.DBUtil;
            import androidx.room.util.SQLiteConnectionUtil;
            import androidx.room.util.SQLiteStatementUtil;
            import androidx.sqlite.SQLiteConnection;
            import androidx.sqlite.SQLiteStatement;
            import java.util.ArrayList;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.reflect.KClass;
            
            /* JADX INFO: compiled from: AnkiDao_Impl.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0006\b\u0007\u0018\u0000 ;2\u00020\u0001:\u0001;B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u0014J\u0016\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u0016\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u0017J\u0016\u0010\u0018\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\fH\u0096@¢\u0006\u0002\u0010\u001bJ\u0016\u0010\u001c\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u000eH\u0096@¢\u0006\u0002\u0010\u001eJ\u001c\u0010\u001f\u001a\u00020\u00192\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00100!H\u0096@¢\u0006\u0002\u0010\"J\u0018\u0010\u0013\u001a\u0004\u0018\u00010\b2\u0006\u0010#\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J\u0018\u0010&\u001a\u0004\u0018\u00010\b2\u0006\u0010'\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J\u000e\u0010(\u001a\u00020\u0012H\u0096@¢\u0006\u0002\u0010)J\u0018\u0010\u0016\u001a\u0004\u0018\u00010\n2\u0006\u0010#\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J\u0018\u0010*\u001a\u0004\u0018\u00010\n2\u0006\u0010+\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J\u0018\u0010\u001a\u001a\u0004\u0018\u00010\f2\u0006\u0010,\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J\u001c\u0010-\u001a\b\u0012\u0004\u0012\u00020\f0!2\u0006\u0010.\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J \u0010/\u001a\u0004\u0018\u00010\u000e2\u0006\u0010#\u001a\u00020$2\u0006\u00100\u001a\u00020$H\u0096@¢\u0006\u0002\u00101J\u001c\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00100!2\u0006\u00102\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J \u0010 \u001a\u0004\u0018\u00010\u00102\u0006\u00102\u001a\u00020$2\u0006\u00100\u001a\u00020$H\u0096@¢\u0006\u0002\u00101J\u0016\u00103\u001a\u0002042\u0006\u0010'\u001a\u00020$H\u0096@¢\u0006\u0002\u0010%J&\u00105\u001a\u0002062\u0006\u0010#\u001a\u00020$2\u0006\u00107\u001a\u00020\u00122\u0006\u00108\u001a\u00020$H\u0096@¢\u0006\u0002\u00109J\u000e\u0010:\u001a\u00020\u0019H\u0096@¢\u0006\u0002\u0010)R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006<"}, d2 = {"Lcom/xunji/flashcards/data/AnkiDao_Impl;", "Lcom/xunji/flashcards/data/AnkiDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfAnkiModelEntity", "Landroidx/room/EntityInsertAdapter;", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "__insertAdapterOfAnkiNoteEntity", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "__insertAdapterOfAnkiCardEntity", "Lcom/xunji/flashcards/data/AnkiCardEntity;", "__insertAdapterOfAnkiDeckSourceEntity", "Lcom/xunji/flashcards/data/AnkiDeckSourceEntity;", "__insertAdapterOfAnkiMediaEntity", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "insertModel", "", "model", "(Lcom/xunji/flashcards/data/AnkiModelEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertNote", "note", "(Lcom/xunji/flashcards/data/AnkiNoteEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertLink", "", "link", "(Lcom/xunji/flashcards/data/AnkiCardEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertDeckSource", "source", "(Lcom/xunji/flashcards/data/AnkiDeckSourceEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertMedia", "media", "", "(Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "id", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "modelByHash", "hash", "modelStorageBytes", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "noteByGuid", "guid", "cardId", "links", "noteId", "deckSource", HintConstants.AUTOFILL_HINT_NAME, "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "namespace", "mediaHashExists", "", "updateFields", "", "expectedRevision", "fields", "(Ljava/lang/String;JLjava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteUnusedMediaMappings", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 19 */    public final class AnkiDao_Impl implements AnkiDao {
                private final RoomDatabase __db;
                private final EntityInsertAdapter<AnkiCardEntity> __insertAdapterOfAnkiCardEntity;
                private final EntityInsertAdapter<AnkiDeckSourceEntity> __insertAdapterOfAnkiDeckSourceEntity;
                private final EntityInsertAdapter<AnkiMediaEntity> __insertAdapterOfAnkiMediaEntity;
                private final EntityInsertAdapter<AnkiModelEntity> __insertAdapterOfAnkiModelEntity;
                private final EntityInsertAdapter<AnkiNoteEntity> __insertAdapterOfAnkiNoteEntity;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = 8;

/* 20 */        public AnkiDao_Impl(RoomDatabase __db) {
                    Intrinsics.checkNotNullParameter(__db, "__db");
/* 38 */            this.__db = __db;
/* 39 */            this.__insertAdapterOfAnkiModelEntity = new EntityInsertAdapter<AnkiModelEntity>() { // from class: com.xunji.flashcards.data.AnkiDao_Impl.1
                        @Override // androidx.room.EntityInsertAdapter
/* 39 */                protected String createQuery() {
/* 40 */                    return "INSERT OR IGNORE INTO `anki_models` (`id`,`sourceModelId`,`contentHash`,`name`,`kind`,`originalStockKind`,`fieldNames`,`templates`,`css`) VALUES (?,?,?,?,?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 42 */                public void bind(SQLiteStatement statement, AnkiModelEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 43 */                    statement.mo8756bindText(1, entity.getId());
/* 44 */                    statement.mo8756bindText(2, entity.getSourceModelId());
/* 45 */                    statement.mo8756bindText(3, entity.getContentHash());
/* 46 */                    statement.mo8756bindText(4, entity.getName());
/* 47 */                    statement.mo8754bindLong(5, entity.getKind());
/* 48 */                    statement.mo8754bindLong(6, entity.getOriginalStockKind());
/* 49 */                    statement.mo8756bindText(7, entity.getFieldNames());
/* 50 */                    statement.mo8756bindText(8, entity.getTemplates());
/* 51 */                    statement.mo8756bindText(9, entity.getCss());
                        }
                    };
/* 54 */            this.__insertAdapterOfAnkiNoteEntity = new EntityInsertAdapter<AnkiNoteEntity>() { // from class: com.xunji.flashcards.data.AnkiDao_Impl.2
                        @Override // androidx.room.EntityInsertAdapter
/* 54 */                protected String createQuery() {
/* 55 */                    return "INSERT OR IGNORE INTO `anki_notes` (`id`,`sourceGuid`,`modelId`,`fields`,`tags`,`mediaNamespace`,`revision`) VALUES (?,?,?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 57 */                public void bind(SQLiteStatement statement, AnkiNoteEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 58 */                    statement.mo8756bindText(1, entity.getId());
/* 59 */                    statement.mo8756bindText(2, entity.getSourceGuid());
/* 60 */                    statement.mo8756bindText(3, entity.getModelId());
/* 61 */                    statement.mo8756bindText(4, entity.getFields());
/* 62 */                    statement.mo8756bindText(5, entity.getTags());
/* 63 */                    statement.mo8756bindText(6, entity.getMediaNamespace());
/* 64 */                    statement.mo8754bindLong(7, entity.getRevision());
                        }
                    };
/* 67 */            this.__insertAdapterOfAnkiCardEntity = new EntityInsertAdapter<AnkiCardEntity>() { // from class: com.xunji.flashcards.data.AnkiDao_Impl.3
                        @Override // androidx.room.EntityInsertAdapter
/* 67 */                protected String createQuery() {
/* 68 */                    return "INSERT OR ABORT INTO `anki_cards` (`cardId`,`noteId`,`ordinal`) VALUES (?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 70 */                public void bind(SQLiteStatement statement, AnkiCardEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 71 */                    statement.mo8756bindText(1, entity.getCardId());
/* 72 */                    statement.mo8756bindText(2, entity.getNoteId());
/* 73 */                    statement.mo8754bindLong(3, entity.getOrdinal());
                        }
                    };
/* 76 */            this.__insertAdapterOfAnkiDeckSourceEntity = new EntityInsertAdapter<AnkiDeckSourceEntity>() { // from class: com.xunji.flashcards.data.AnkiDao_Impl.4
                        @Override // androidx.room.EntityInsertAdapter
/* 76 */                protected String createQuery() {
/* 77 */                    return "INSERT OR ABORT INTO `anki_deck_sources` (`sourceDeckId`,`originalFullName`,`localDeckId`) VALUES (?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 79 */                public void bind(SQLiteStatement statement, AnkiDeckSourceEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 80 */                    statement.mo8756bindText(1, entity.getSourceDeckId());
/* 81 */                    statement.mo8756bindText(2, entity.getOriginalFullName());
/* 82 */                    statement.mo8756bindText(3, entity.getLocalDeckId());
                        }
                    };
/* 85 */            this.__insertAdapterOfAnkiMediaEntity = new EntityInsertAdapter<AnkiMediaEntity>() { // from class: com.xunji.flashcards.data.AnkiDao_Impl.5
                        @Override // androidx.room.EntityInsertAdapter
/* 85 */                protected String createQuery() {
/* 86 */                    return "INSERT OR ABORT INTO `anki_media` (`namespace`,`originalName`,`sha256`,`size`,`mime`) VALUES (?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 88 */                public void bind(SQLiteStatement statement, AnkiMediaEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 89 */                    statement.mo8756bindText(1, entity.getNamespace());
/* 90 */                    statement.mo8756bindText(2, entity.getOriginalName());
/* 91 */                    statement.mo8756bindText(3, entity.getSha256());
/* 92 */                    statement.mo8754bindLong(4, entity.getSize());
/* 93 */                    statement.mo8756bindText(5, entity.getMime());
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 97 */        public Object insertModel(final AnkiModelEntity model, Continuation<? super Long> continuation) {
/* 98 */            return DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return Long.valueOf(AnkiDao_Impl.insertModel$lambda$0(this.f$0, model, (SQLiteConnection) obj));
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 98 */        public static final long insertModel$lambda$0(AnkiDao_Impl this$0, AnkiModelEntity $model, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 99 */            long _result = this$0.__insertAdapterOfAnkiModelEntity.insertAndReturnId(_connection, $model);
/* 100 */           return _result;
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 102 */       public Object insertNote(final AnkiNoteEntity note, Continuation<? super Long> continuation) {
/* 103 */           return DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda15
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return Long.valueOf(AnkiDao_Impl.insertNote$lambda$0(this.f$0, note, (SQLiteConnection) obj));
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 103 */       public static final long insertNote$lambda$0(AnkiDao_Impl this$0, AnkiNoteEntity $note, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 104 */           long _result = this$0.__insertAdapterOfAnkiNoteEntity.insertAndReturnId(_connection, $note);
/* 105 */           return _result;
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 107 */       public Object insertLink(final AnkiCardEntity link, Continuation<? super Unit> continuation) {
/* 108 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.insertLink$lambda$0(this.f$0, link, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final Unit insertLink$lambda$0(AnkiDao_Impl this$0, AnkiCardEntity $link, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 109 */           this$0.__insertAdapterOfAnkiCardEntity.insert(_connection, $link);
/* 110 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 111 */       public Object insertDeckSource(final AnkiDeckSourceEntity source, Continuation<? super Unit> continuation) {
/* 112 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.insertDeckSource$lambda$0(this.f$0, source, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 112 */       public static final Unit insertDeckSource$lambda$0(AnkiDao_Impl this$0, AnkiDeckSourceEntity $source, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 113 */           this$0.__insertAdapterOfAnkiDeckSourceEntity.insert(_connection, $source);
/* 114 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 115 */       public Object insertMedia(final List<AnkiMediaEntity> list, Continuation<? super Unit> continuation) {
/* 116 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda7
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.insertMedia$lambda$0(this.f$0, list, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 116 */       public static final Unit insertMedia$lambda$0(AnkiDao_Impl this$0, List $media, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 117 */           this$0.__insertAdapterOfAnkiMediaEntity.insert(_connection, $media);
/* 118 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 120 */       public Object model(final String id, Continuation<? super AnkiModelEntity> continuation) {
/* 121 */           final String _sql = "SELECT * FROM anki_models WHERE id=?";
/* 122 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.model$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 122 */       public static final AnkiModelEntity model$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    AnkiModelEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 123 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 126 */               _stmt.mo8756bindText(1, $id);
/* 127 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 128 */               int _columnIndexOfSourceModelId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sourceModelId");
/* 129 */               int _columnIndexOfContentHash = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "contentHash");
/* 130 */               int _columnIndexOfName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, HintConstants.AUTOFILL_HINT_NAME);
/* 131 */               int _columnIndexOfKind = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "kind");
/* 132 */               int _columnIndexOfOriginalStockKind = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "originalStockKind");
/* 133 */               int _columnIndexOfFieldNames = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "fieldNames");
/* 134 */               int _columnIndexOfTemplates = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "templates");
/* 135 */               int _columnIndexOfCss = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "css");
/* 137 */               if (_stmt.step()) {
/* 139 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 141 */                   String _tmpSourceModelId = _stmt.getText(_columnIndexOfSourceModelId);
/* 143 */                   String _tmpContentHash = _stmt.getText(_columnIndexOfContentHash);
/* 145 */                   String _tmpName = _stmt.getText(_columnIndexOfName);
                            int _tmpKind = (int) _stmt.getLong(_columnIndexOfKind);
                            int _tmpOriginalStockKind = (int) _stmt.getLong(_columnIndexOfOriginalStockKind);
/* 151 */                   String _tmpFieldNames = _stmt.getText(_columnIndexOfFieldNames);
/* 153 */                   String _tmpTemplates = _stmt.getText(_columnIndexOfTemplates);
/* 155 */                   String _tmpCss = _stmt.getText(_columnIndexOfCss);
/* 149 */                   _result = new AnkiModelEntity(_tmpId, _tmpSourceModelId, _tmpContentHash, _tmpName, _tmpKind, _tmpOriginalStockKind, _tmpFieldNames, _tmpTemplates, _tmpCss);
                        } else {
                            _result = null;
                        }
/* 163 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 167 */       public Object modelByHash(final String hash, Continuation<? super AnkiModelEntity> continuation) {
/* 168 */           final String _sql = "SELECT * FROM anki_models WHERE contentHash=?";
/* 169 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.modelByHash$lambda$0(_sql, hash, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 169 */       public static final AnkiModelEntity modelByHash$lambda$0(String $_sql, String $hash, SQLiteConnection _connection) {
                    AnkiModelEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 170 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 173 */               _stmt.mo8756bindText(1, $hash);
/* 174 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 175 */               int _columnIndexOfSourceModelId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sourceModelId");
/* 176 */               int _columnIndexOfContentHash = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "contentHash");
/* 177 */               int _columnIndexOfName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, HintConstants.AUTOFILL_HINT_NAME);
/* 178 */               int _columnIndexOfKind = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "kind");
/* 179 */               int _columnIndexOfOriginalStockKind = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "originalStockKind");
/* 180 */               int _columnIndexOfFieldNames = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "fieldNames");
/* 181 */               int _columnIndexOfTemplates = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "templates");
/* 182 */               int _columnIndexOfCss = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "css");
/* 184 */               if (_stmt.step()) {
/* 186 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 188 */                   String _tmpSourceModelId = _stmt.getText(_columnIndexOfSourceModelId);
/* 190 */                   String _tmpContentHash = _stmt.getText(_columnIndexOfContentHash);
/* 192 */                   String _tmpName = _stmt.getText(_columnIndexOfName);
                            int _tmpKind = (int) _stmt.getLong(_columnIndexOfKind);
                            int _tmpOriginalStockKind = (int) _stmt.getLong(_columnIndexOfOriginalStockKind);
/* 198 */                   String _tmpFieldNames = _stmt.getText(_columnIndexOfFieldNames);
/* 200 */                   String _tmpTemplates = _stmt.getText(_columnIndexOfTemplates);
/* 202 */                   String _tmpCss = _stmt.getText(_columnIndexOfCss);
/* 196 */                   _result = new AnkiModelEntity(_tmpId, _tmpSourceModelId, _tmpContentHash, _tmpName, _tmpKind, _tmpOriginalStockKind, _tmpFieldNames, _tmpTemplates, _tmpCss);
                        } else {
                            _result = null;
                        }
/* 210 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 214 */       public Object modelStorageBytes(Continuation<? super Long> continuation) {
/* 215 */           final String _sql = "SELECT COALESCE(SUM(length(CAST(id AS BLOB))+length(CAST(sourceModelId AS BLOB))+length(CAST(contentHash AS BLOB))+length(CAST(name AS BLOB))+length(CAST(fieldNames AS BLOB))+length(CAST(templates AS BLOB))+length(CAST(css AS BLOB))),0) FROM anki_models";
/* 216 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return Long.valueOf(AnkiDao_Impl.modelStorageBytes$lambda$0(_sql, (SQLiteConnection) obj));
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 216 */       public static final long modelStorageBytes$lambda$0(String $_sql, SQLiteConnection _connection) {
                    long _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 217 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 220 */               if (_stmt.step()) {
/* 222 */                   _result = _stmt.getLong(0);
                        } else {
/* 225 */                   _result = 0;
                        }
/* 230 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 234 */       public Object note(final String id, Continuation<? super AnkiNoteEntity> continuation) {
/* 235 */           final String _sql = "SELECT * FROM anki_notes WHERE id=?";
/* 236 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.note$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 236 */       public static final AnkiNoteEntity note$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    AnkiNoteEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 237 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 240 */               _stmt.mo8756bindText(1, $id);
/* 241 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 242 */               int _columnIndexOfSourceGuid = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sourceGuid");
/* 243 */               int _columnIndexOfModelId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "modelId");
/* 244 */               int _columnIndexOfFields = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "fields");
/* 245 */               int _columnIndexOfTags = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "tags");
/* 246 */               int _columnIndexOfMediaNamespace = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "mediaNamespace");
/* 247 */               int _columnIndexOfRevision = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "revision");
/* 249 */               if (_stmt.step()) {
/* 251 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 253 */                   String _tmpSourceGuid = _stmt.getText(_columnIndexOfSourceGuid);
/* 255 */                   String _tmpModelId = _stmt.getText(_columnIndexOfModelId);
/* 257 */                   String _tmpFields = _stmt.getText(_columnIndexOfFields);
/* 259 */                   String _tmpTags = _stmt.getText(_columnIndexOfTags);
/* 261 */                   String _tmpMediaNamespace = _stmt.getText(_columnIndexOfMediaNamespace);
/* 263 */                   long _tmpRevision = _stmt.getLong(_columnIndexOfRevision);
/* 264 */                   _result = new AnkiNoteEntity(_tmpId, _tmpSourceGuid, _tmpModelId, _tmpFields, _tmpTags, _tmpMediaNamespace, _tmpRevision);
                        } else {
/* 266 */                   _result = null;
                        }
/* 271 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 275 */       public Object noteByGuid(final String guid, Continuation<? super AnkiNoteEntity> continuation) {
/* 276 */           final String _sql = "SELECT * FROM anki_notes WHERE sourceGuid=?";
/* 277 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.noteByGuid$lambda$0(_sql, guid, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 277 */       public static final AnkiNoteEntity noteByGuid$lambda$0(String $_sql, String $guid, SQLiteConnection _connection) {
                    AnkiNoteEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 278 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 281 */               _stmt.mo8756bindText(1, $guid);
/* 282 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 283 */               int _columnIndexOfSourceGuid = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sourceGuid");
/* 284 */               int _columnIndexOfModelId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "modelId");
/* 285 */               int _columnIndexOfFields = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "fields");
/* 286 */               int _columnIndexOfTags = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "tags");
/* 287 */               int _columnIndexOfMediaNamespace = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "mediaNamespace");
/* 288 */               int _columnIndexOfRevision = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "revision");
/* 290 */               if (_stmt.step()) {
/* 292 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 294 */                   String _tmpSourceGuid = _stmt.getText(_columnIndexOfSourceGuid);
/* 296 */                   String _tmpModelId = _stmt.getText(_columnIndexOfModelId);
/* 298 */                   String _tmpFields = _stmt.getText(_columnIndexOfFields);
/* 300 */                   String _tmpTags = _stmt.getText(_columnIndexOfTags);
/* 302 */                   String _tmpMediaNamespace = _stmt.getText(_columnIndexOfMediaNamespace);
/* 304 */                   long _tmpRevision = _stmt.getLong(_columnIndexOfRevision);
/* 305 */                   _result = new AnkiNoteEntity(_tmpId, _tmpSourceGuid, _tmpModelId, _tmpFields, _tmpTags, _tmpMediaNamespace, _tmpRevision);
                        } else {
/* 307 */                   _result = null;
                        }
/* 312 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 316 */       public Object link(final String cardId, Continuation<? super AnkiCardEntity> continuation) {
/* 317 */           final String _sql = "SELECT * FROM anki_cards WHERE cardId=?";
/* 318 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.link$lambda$0(_sql, cardId, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 318 */       public static final AnkiCardEntity link$lambda$0(String $_sql, String $cardId, SQLiteConnection _connection) {
                    AnkiCardEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 319 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 322 */               _stmt.mo8756bindText(1, $cardId);
/* 323 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 324 */               int _columnIndexOfNoteId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "noteId");
/* 325 */               int _columnIndexOfOrdinal = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "ordinal");
/* 327 */               if (_stmt.step()) {
/* 329 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 331 */                   String _tmpNoteId = _stmt.getText(_columnIndexOfNoteId);
/* 333 */                   int _tmpOrdinal = (int) _stmt.getLong(_columnIndexOfOrdinal);
/* 334 */                   _result = new AnkiCardEntity(_tmpCardId, _tmpNoteId, _tmpOrdinal);
                        } else {
/* 336 */                   _result = null;
                        }
/* 341 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 345 */       public Object links(final String noteId, Continuation<? super List<AnkiCardEntity>> continuation) {
/* 346 */           final String _sql = "SELECT * FROM anki_cards WHERE noteId=? ORDER BY ordinal";
/* 347 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.links$lambda$0(_sql, noteId, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 347 */       public static final List links$lambda$0(String $_sql, String $noteId, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 348 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 351 */               _stmt.mo8756bindText(1, $noteId);
/* 352 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 353 */               int _columnIndexOfNoteId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "noteId");
/* 354 */               int _columnIndexOfOrdinal = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "ordinal");
/* 355 */               List _result = new ArrayList();
/* 356 */               while (_stmt.step()) {
/* 359 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 361 */                   String _tmpNoteId = _stmt.getText(_columnIndexOfNoteId);
/* 363 */                   int _tmpOrdinal = (int) _stmt.getLong(_columnIndexOfOrdinal);
/* 364 */                   AnkiCardEntity _item = new AnkiCardEntity(_tmpCardId, _tmpNoteId, _tmpOrdinal);
/* 365 */                   _result.add(_item);
                        }
/* 369 */               _stmt.close();
/* 370 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 374 */       public Object deckSource(final String id, final String name, Continuation<? super AnkiDeckSourceEntity> continuation) {
/* 375 */           final String _sql = "SELECT * FROM anki_deck_sources WHERE sourceDeckId=? AND originalFullName=?";
/* 376 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.deckSource$lambda$0(_sql, id, name, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 376 */       public static final AnkiDeckSourceEntity deckSource$lambda$0(String $_sql, String $id, String $name, SQLiteConnection _connection) {
                    AnkiDeckSourceEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 377 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 380 */               _stmt.mo8756bindText(1, $id);
/* 382 */               _stmt.mo8756bindText(2, $name);
/* 383 */               int _columnIndexOfSourceDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sourceDeckId");
/* 384 */               int _columnIndexOfOriginalFullName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "originalFullName");
/* 385 */               int _columnIndexOfLocalDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "localDeckId");
/* 387 */               if (_stmt.step()) {
/* 389 */                   String _tmpSourceDeckId = _stmt.getText(_columnIndexOfSourceDeckId);
/* 391 */                   String _tmpOriginalFullName = _stmt.getText(_columnIndexOfOriginalFullName);
/* 393 */                   String _tmpLocalDeckId = _stmt.getText(_columnIndexOfLocalDeckId);
/* 394 */                   _result = new AnkiDeckSourceEntity(_tmpSourceDeckId, _tmpOriginalFullName, _tmpLocalDeckId);
                        } else {
/* 396 */                   _result = null;
                        }
/* 401 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 405 */       public Object media(final String namespace, Continuation<? super List<AnkiMediaEntity>> continuation) {
/* 406 */           final String _sql = "SELECT * FROM anki_media WHERE namespace=? ORDER BY originalName";
/* 407 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.media$lambda$0(_sql, namespace, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 407 */       public static final List media$lambda$0(String $_sql, String $namespace, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 408 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 411 */               _stmt.mo8756bindText(1, $namespace);
/* 412 */               int _columnIndexOfNamespace = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "namespace");
/* 413 */               int _columnIndexOfOriginalName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "originalName");
/* 414 */               int _columnIndexOfSha256 = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sha256");
/* 415 */               int _columnIndexOfSize = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "size");
/* 416 */               int _columnIndexOfMime = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "mime");
/* 417 */               List _result = new ArrayList();
/* 418 */               while (_stmt.step()) {
/* 421 */                   String _tmpNamespace = _stmt.getText(_columnIndexOfNamespace);
/* 423 */                   String _tmpOriginalName = _stmt.getText(_columnIndexOfOriginalName);
/* 425 */                   String _tmpSha256 = _stmt.getText(_columnIndexOfSha256);
/* 427 */                   long _tmpSize = _stmt.getLong(_columnIndexOfSize);
/* 429 */                   String _tmpMime = _stmt.getText(_columnIndexOfMime);
/* 430 */                   AnkiMediaEntity _item = new AnkiMediaEntity(_tmpNamespace, _tmpOriginalName, _tmpSha256, _tmpSize, _tmpMime);
/* 431 */                   _result.add(_item);
                        }
/* 435 */               _stmt.close();
/* 436 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 440 */       public Object media(final String namespace, final String name, Continuation<? super AnkiMediaEntity> continuation) {
/* 441 */           final String _sql = "SELECT * FROM anki_media WHERE namespace=? AND originalName=?";
/* 442 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.media$lambda$1(_sql, namespace, name, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 442 */       public static final AnkiMediaEntity media$lambda$1(String $_sql, String $namespace, String $name, SQLiteConnection _connection) throws Throwable {
                    AnkiMediaEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 443 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 446 */               _stmt.mo8756bindText(1, $namespace);
                        try {
/* 448 */                   _stmt.mo8756bindText(2, $name);
/* 449 */                   int _columnIndexOfNamespace = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "namespace");
/* 450 */                   int _columnIndexOfOriginalName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "originalName");
/* 451 */                   int _columnIndexOfSha256 = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sha256");
/* 452 */                   int _columnIndexOfSize = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "size");
/* 453 */                   int _columnIndexOfMime = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "mime");
/* 455 */                   if (_stmt.step()) {
/* 457 */                       String _tmpNamespace = _stmt.getText(_columnIndexOfNamespace);
/* 459 */                       String _tmpOriginalName = _stmt.getText(_columnIndexOfOriginalName);
/* 461 */                       String _tmpSha256 = _stmt.getText(_columnIndexOfSha256);
/* 463 */                       long _tmpSize = _stmt.getLong(_columnIndexOfSize);
/* 465 */                       String _tmpMime = _stmt.getText(_columnIndexOfMime);
/* 466 */                       _result = new AnkiMediaEntity(_tmpNamespace, _tmpOriginalName, _tmpSha256, _tmpSize, _tmpMime);
                            } else {
/* 468 */                       _result = null;
                            }
/* 472 */                   _stmt.close();
/* 473 */                   return _result;
                        } catch (Throwable th) {
/* 472 */                   th = th;
                            _stmt.close();
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 477 */       public Object mediaHashExists(final String hash, Continuation<? super Boolean> continuation) {
/* 478 */           final String _sql = "SELECT EXISTS(SELECT 1 FROM anki_media WHERE sha256=?)";
/* 479 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda13
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return Boolean.valueOf(AnkiDao_Impl.mediaHashExists$lambda$0(_sql, hash, (SQLiteConnection) obj));
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 479 */       public static final boolean mediaHashExists$lambda$0(String $_sql, String $hash, SQLiteConnection _connection) {
                    boolean _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 480 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 483 */               _stmt.mo8756bindText(1, $hash);
/* 485 */               if (_stmt.step()) {
/* 487 */                   _result = false;
/* 487 */                   int _tmp = (int) _stmt.getLong(0);
/* 488 */                   if (_tmp != 0) {
                                _result = true;
                            }
                        } else {
/* 490 */                   _result = false;
                        }
/* 495 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 503 */       public Object updateFields(final String id, final long expectedRevision, final String fields, Continuation<? super Integer> continuation) {
/* 504 */           final String _sql = "UPDATE anki_notes SET fields=?, revision=revision+1 WHERE id=? AND revision=?";
/* 505 */           return DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return Integer.valueOf(AnkiDao_Impl.updateFields$lambda$0(_sql, fields, id, expectedRevision, (SQLiteConnection) obj));
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 505 */       public static final int updateFields$lambda$0(String $_sql, String $fields, String $id, long $expectedRevision, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 506 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 509 */               _stmt.mo8756bindText(1, $fields);
/* 511 */               _stmt.mo8756bindText(2, $id);
/* 513 */               _stmt.mo8754bindLong(3, $expectedRevision);
/* 514 */               _stmt.step();
/* 515 */               return SQLiteConnectionUtil.getTotalChangedRows(_connection);
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.AnkiDao
/* 522 */       public Object deleteUnusedMediaMappings(Continuation<? super Unit> continuation) {
/* 523 */           final String _sql = "DELETE FROM anki_media WHERE namespace NOT IN (SELECT mediaNamespace FROM anki_notes)";
/* 524 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.AnkiDao_Impl$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return AnkiDao_Impl.deleteUnusedMediaMappings$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 524 */       public static final Unit deleteUnusedMediaMappings$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 525 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 527 */               _stmt.step();
/* 531 */               return Unit.INSTANCE;
                    } finally {
                        _stmt.close();
                    }
                }

                /* JADX INFO: compiled from: AnkiDao_Impl.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/flashcards/data/AnkiDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 532 */       public static final class Companion {
/* 533 */           private Companion() {
                    }

/* 534 */           public final List<KClass<?>> getRequiredConverters() {
/* 535 */               return CollectionsKt.emptyList();
                    }
                }
            }

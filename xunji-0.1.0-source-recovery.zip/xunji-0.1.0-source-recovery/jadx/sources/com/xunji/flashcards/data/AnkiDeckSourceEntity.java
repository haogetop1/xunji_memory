            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\t\u0010\r\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000e\u001a\u00020\u0003HÆ\u0003J'\u0010\u000f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0010\u001a\u00020\u00112\b\u0010\u0012\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0013\u001a\u00020\u0014HÖ\u0001J\t\u0010\u0015\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\tR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\t¨\u0006\u0016"}, d2 = {"Lcom/xunji/flashcards/data/AnkiDeckSourceEntity;", "", "sourceDeckId", "", "originalFullName", "localDeckId", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getSourceDeckId", "()Ljava/lang/String;", "getOriginalFullName", "getLocalDeckId", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 27 */    public final /* data */ class AnkiDeckSourceEntity {
                public static final int $stable = 0;
                private final String localDeckId;
                private final String originalFullName;
                private final String sourceDeckId;

                public static /* synthetic */ AnkiDeckSourceEntity copy$default(AnkiDeckSourceEntity ankiDeckSourceEntity, String str, String str2, String str3, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = ankiDeckSourceEntity.sourceDeckId;
                    }
                    if ((i & 2) != 0) {
                        str2 = ankiDeckSourceEntity.originalFullName;
                    }
                    if ((i & 4) != 0) {
                        str3 = ankiDeckSourceEntity.localDeckId;
                    }
                    return ankiDeckSourceEntity.copy(str, str2, str3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getSourceDeckId() {
                    return this.sourceDeckId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getOriginalFullName() {
                    return this.originalFullName;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getLocalDeckId() {
                    return this.localDeckId;
                }

                public final AnkiDeckSourceEntity copy(String sourceDeckId, String originalFullName, String localDeckId) {
                    Intrinsics.checkNotNullParameter(sourceDeckId, "sourceDeckId");
                    Intrinsics.checkNotNullParameter(originalFullName, "originalFullName");
                    Intrinsics.checkNotNullParameter(localDeckId, "localDeckId");
                    return new AnkiDeckSourceEntity(sourceDeckId, originalFullName, localDeckId);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiDeckSourceEntity)) {
                        return false;
                    }
                    AnkiDeckSourceEntity ankiDeckSourceEntity = (AnkiDeckSourceEntity) other;
                    return Intrinsics.areEqual(this.sourceDeckId, ankiDeckSourceEntity.sourceDeckId) && Intrinsics.areEqual(this.originalFullName, ankiDeckSourceEntity.originalFullName) && Intrinsics.areEqual(this.localDeckId, ankiDeckSourceEntity.localDeckId);
                }

                public int hashCode() {
                    return (((this.sourceDeckId.hashCode() * 31) + this.originalFullName.hashCode()) * 31) + this.localDeckId.hashCode();
                }

                public String toString() {
                    return "AnkiDeckSourceEntity(sourceDeckId=" + this.sourceDeckId + ", originalFullName=" + this.originalFullName + ", localDeckId=" + this.localDeckId + ")";
                }

/* 28 */        public AnkiDeckSourceEntity(String sourceDeckId, String originalFullName, String localDeckId) {
                    Intrinsics.checkNotNullParameter(sourceDeckId, "sourceDeckId");
                    Intrinsics.checkNotNullParameter(originalFullName, "originalFullName");
                    Intrinsics.checkNotNullParameter(localDeckId, "localDeckId");
/* 32 */            this.sourceDeckId = sourceDeckId;
                    this.originalFullName = originalFullName;
                    this.localDeckId = localDeckId;
                }

/* 31 */        public final String getLocalDeckId() {
/* 32 */            return this.localDeckId;
                }

/* 31 */        public final String getOriginalFullName() {
/* 32 */            return this.originalFullName;
                }

/* 31 */        public final String getSourceDeckId() {
/* 32 */            return this.sourceDeckId;
                }
            }

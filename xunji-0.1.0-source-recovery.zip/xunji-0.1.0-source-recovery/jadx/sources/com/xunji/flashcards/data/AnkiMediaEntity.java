            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0011\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B/\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0004\b\t\u0010\nJ\t\u0010\u0012\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0007HÆ\u0003J\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J;\u0010\u0017\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001b\u001a\u00020\u001cHÖ\u0001J\t\u0010\u001d\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000b\u0010\fR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\fR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\fR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\f¨\u0006\u001e"}, d2 = {"Lcom/xunji/flashcards/data/AnkiMediaEntity;", "", "namespace", "", "originalName", "sha256", "size", "", "mime", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V", "getNamespace", "()Ljava/lang/String;", "getOriginalName", "getSha256", "getSize", "()J", "getMime", "component1", "component2", "component3", "component4", "component5", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 32 */    public final /* data */ class AnkiMediaEntity {
                public static final int $stable = 0;
                private final String mime;
                private final String namespace;
                private final String originalName;
                private final String sha256;
                private final long size;

                public static /* synthetic */ AnkiMediaEntity copy$default(AnkiMediaEntity ankiMediaEntity, String str, String str2, String str3, long j, String str4, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = ankiMediaEntity.namespace;
                    }
                    if ((i & 2) != 0) {
                        str2 = ankiMediaEntity.originalName;
                    }
                    if ((i & 4) != 0) {
                        str3 = ankiMediaEntity.sha256;
                    }
                    if ((i & 8) != 0) {
                        j = ankiMediaEntity.size;
                    }
                    if ((i & 16) != 0) {
                        str4 = ankiMediaEntity.mime;
                    }
                    String str5 = str4;
                    String str6 = str3;
                    return ankiMediaEntity.copy(str, str2, str6, j, str5);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getNamespace() {
                    return this.namespace;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getOriginalName() {
                    return this.originalName;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getSha256() {
                    return this.sha256;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final long getSize() {
                    return this.size;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getMime() {
                    return this.mime;
                }

                public final AnkiMediaEntity copy(String namespace, String originalName, String sha256, long size, String mime) {
                    Intrinsics.checkNotNullParameter(namespace, "namespace");
                    Intrinsics.checkNotNullParameter(originalName, "originalName");
                    Intrinsics.checkNotNullParameter(sha256, "sha256");
                    Intrinsics.checkNotNullParameter(mime, "mime");
                    return new AnkiMediaEntity(namespace, originalName, sha256, size, mime);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiMediaEntity)) {
                        return false;
                    }
                    AnkiMediaEntity ankiMediaEntity = (AnkiMediaEntity) other;
                    return Intrinsics.areEqual(this.namespace, ankiMediaEntity.namespace) && Intrinsics.areEqual(this.originalName, ankiMediaEntity.originalName) && Intrinsics.areEqual(this.sha256, ankiMediaEntity.sha256) && this.size == ankiMediaEntity.size && Intrinsics.areEqual(this.mime, ankiMediaEntity.mime);
                }

                public int hashCode() {
                    return (((((((this.namespace.hashCode() * 31) + this.originalName.hashCode()) * 31) + this.sha256.hashCode()) * 31) + Long.hashCode(this.size)) * 31) + this.mime.hashCode();
                }

                public String toString() {
                    return "AnkiMediaEntity(namespace=" + this.namespace + ", originalName=" + this.originalName + ", sha256=" + this.sha256 + ", size=" + this.size + ", mime=" + this.mime + ")";
                }

/* 33 */        public AnkiMediaEntity(String namespace, String originalName, String sha256, long size, String mime) {
                    Intrinsics.checkNotNullParameter(namespace, "namespace");
                    Intrinsics.checkNotNullParameter(originalName, "originalName");
                    Intrinsics.checkNotNullParameter(sha256, "sha256");
                    Intrinsics.checkNotNullParameter(mime, "mime");
/* 35 */            this.namespace = namespace;
                    this.originalName = originalName;
                    this.sha256 = sha256;
                    this.size = size;
                    this.mime = mime;
                }

/* 34 */        public final String getMime() {
/* 35 */            return this.mime;
                }

/* 34 */        public final String getNamespace() {
/* 35 */            return this.namespace;
                }

/* 34 */        public final String getOriginalName() {
/* 35 */            return this.originalName;
                }

/* 34 */        public final String getSha256() {
/* 35 */            return this.sha256;
                }

/* 34 */        public final long getSize() {
/* 35 */            return this.size;
                }
            }

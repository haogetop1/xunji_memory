            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u001c\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BO\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\n\u001a\u00020\u0003\u0012\u0006\u0010\u000b\u001a\u00020\u0003\u0012\u0006\u0010\f\u001a\u00020\u0003¢\u0006\u0004\b\r\u0010\u000eJ\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\bHÆ\u0003J\t\u0010\u001f\u001a\u00020\bHÆ\u0003J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003Jc\u0010#\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\n\u001a\u00020\u00032\b\b\u0002\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\f\u001a\u00020\u0003HÆ\u0001J\u0013\u0010$\u001a\u00020%2\b\u0010&\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010'\u001a\u00020\bHÖ\u0001J\t\u0010(\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0010R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0010R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0010R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0011\u0010\t\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0015R\u0011\u0010\n\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0010R\u0011\u0010\u000b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0010R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0010¨\u0006)"}, d2 = {"Lcom/xunji/flashcards/data/AnkiModelEntity;", "", "id", "", "sourceModelId", "contentHash", HintConstants.AUTOFILL_HINT_NAME, "kind", "", "originalStockKind", "fieldNames", "templates", "css", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", "getId", "()Ljava/lang/String;", "getSourceModelId", "getContentHash", "getName", "getKind", "()I", "getOriginalStockKind", "getFieldNames", "getTemplates", "getCss", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */     public final /* data */ class AnkiModelEntity {
                public static final int $stable = 0;
                private final String contentHash;
                private final String css;
                private final String fieldNames;
                private final String id;
                private final int kind;
                private final String name;
                private final int originalStockKind;
                private final String sourceModelId;
                private final String templates;

                public static /* synthetic */ AnkiModelEntity copy$default(AnkiModelEntity ankiModelEntity, String str, String str2, String str3, String str4, int i, int i2, String str5, String str6, String str7, int i3, Object obj) {
                    if ((i3 & 1) != 0) {
                        str = ankiModelEntity.id;
                    }
                    if ((i3 & 2) != 0) {
                        str2 = ankiModelEntity.sourceModelId;
                    }
                    if ((i3 & 4) != 0) {
                        str3 = ankiModelEntity.contentHash;
                    }
                    if ((i3 & 8) != 0) {
                        str4 = ankiModelEntity.name;
                    }
                    if ((i3 & 16) != 0) {
                        i = ankiModelEntity.kind;
                    }
                    if ((i3 & 32) != 0) {
                        i2 = ankiModelEntity.originalStockKind;
                    }
                    if ((i3 & 64) != 0) {
                        str5 = ankiModelEntity.fieldNames;
                    }
                    if ((i3 & 128) != 0) {
                        str6 = ankiModelEntity.templates;
                    }
                    if ((i3 & 256) != 0) {
                        str7 = ankiModelEntity.css;
                    }
                    String str8 = str6;
                    String str9 = str7;
                    int i4 = i2;
                    String str10 = str5;
                    int i5 = i;
                    String str11 = str3;
                    return ankiModelEntity.copy(str, str2, str11, str4, i5, i4, str10, str8, str9);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getSourceModelId() {
                    return this.sourceModelId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getContentHash() {
                    return this.contentHash;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final int getKind() {
                    return this.kind;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final int getOriginalStockKind() {
                    return this.originalStockKind;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final String getFieldNames() {
                    return this.fieldNames;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final String getTemplates() {
                    return this.templates;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final String getCss() {
                    return this.css;
                }

                public final AnkiModelEntity copy(String id, String sourceModelId, String contentHash, String name, int kind, int originalStockKind, String fieldNames, String templates, String css) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(sourceModelId, "sourceModelId");
                    Intrinsics.checkNotNullParameter(contentHash, "contentHash");
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(fieldNames, "fieldNames");
                    Intrinsics.checkNotNullParameter(templates, "templates");
                    Intrinsics.checkNotNullParameter(css, "css");
                    return new AnkiModelEntity(id, sourceModelId, contentHash, name, kind, originalStockKind, fieldNames, templates, css);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiModelEntity)) {
                        return false;
                    }
                    AnkiModelEntity ankiModelEntity = (AnkiModelEntity) other;
                    return Intrinsics.areEqual(this.id, ankiModelEntity.id) && Intrinsics.areEqual(this.sourceModelId, ankiModelEntity.sourceModelId) && Intrinsics.areEqual(this.contentHash, ankiModelEntity.contentHash) && Intrinsics.areEqual(this.name, ankiModelEntity.name) && this.kind == ankiModelEntity.kind && this.originalStockKind == ankiModelEntity.originalStockKind && Intrinsics.areEqual(this.fieldNames, ankiModelEntity.fieldNames) && Intrinsics.areEqual(this.templates, ankiModelEntity.templates) && Intrinsics.areEqual(this.css, ankiModelEntity.css);
                }

                public int hashCode() {
                    return (((((((((((((((this.id.hashCode() * 31) + this.sourceModelId.hashCode()) * 31) + this.contentHash.hashCode()) * 31) + this.name.hashCode()) * 31) + Integer.hashCode(this.kind)) * 31) + Integer.hashCode(this.originalStockKind)) * 31) + this.fieldNames.hashCode()) * 31) + this.templates.hashCode()) * 31) + this.css.hashCode();
                }

                public String toString() {
                    return "AnkiModelEntity(id=" + this.id + ", sourceModelId=" + this.sourceModelId + ", contentHash=" + this.contentHash + ", name=" + this.name + ", kind=" + this.kind + ", originalStockKind=" + this.originalStockKind + ", fieldNames=" + this.fieldNames + ", templates=" + this.templates + ", css=" + this.css + ")";
                }

/* 7 */         public AnkiModelEntity(String id, String sourceModelId, String contentHash, String name, int kind, int originalStockKind, String fieldNames, String templates, String css) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(sourceModelId, "sourceModelId");
                    Intrinsics.checkNotNullParameter(contentHash, "contentHash");
                    Intrinsics.checkNotNullParameter(name, "name");
                    Intrinsics.checkNotNullParameter(fieldNames, "fieldNames");
                    Intrinsics.checkNotNullParameter(templates, "templates");
                    Intrinsics.checkNotNullParameter(css, "css");
/* 10 */            this.id = id;
                    this.sourceModelId = sourceModelId;
                    this.contentHash = contentHash;
/* 11 */            this.name = name;
                    this.kind = kind;
                    this.originalStockKind = originalStockKind;
/* 12 */            this.fieldNames = fieldNames;
                    this.templates = templates;
                    this.css = css;
                }

/* 9 */         public final String getContentHash() {
/* 10 */            return this.contentHash;
                }

/* 9 */         public final String getId() {
/* 10 */            return this.id;
                }

/* 9 */         public final String getSourceModelId() {
/* 10 */            return this.sourceModelId;
                }

/* 10 */        public final int getKind() {
/* 11 */            return this.kind;
                }

/* 10 */        public final String getName() {
/* 11 */            return this.name;
                }

/* 10 */        public final int getOriginalStockKind() {
/* 11 */            return this.originalStockKind;
                }

/* 11 */        public final String getCss() {
/* 12 */            return this.css;
                }

/* 11 */        public final String getFieldNames() {
/* 12 */            return this.fieldNames;
                }

/* 11 */        public final String getTemplates() {
/* 12 */            return this.templates;
                }
            }

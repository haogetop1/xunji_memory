            package com.xunji.flashcards.data;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B3\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0014\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0005HÆ\u0003J\u000f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\b0\u0007HÆ\u0003J\u000f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\n0\u0007HÆ\u0003J=\u0010\u0018\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u00072\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007HÆ\u0001J\u0013\u0010\u0019\u001a\u00020\u001a2\b\u0010\u001b\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u001c\u001a\u00020\u001dHÖ\u0001J\t\u0010\u001e\u001a\u00020\u001fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0017\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012¨\u0006 "}, d2 = {"Lcom/xunji/flashcards/data/AnkiNoteContent;", "", "note", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "model", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "links", "", "Lcom/xunji/flashcards/data/AnkiCardEntity;", "media", "Lcom/xunji/flashcards/data/AnkiMediaEntity;", "<init>", "(Lcom/xunji/flashcards/data/AnkiNoteEntity;Lcom/xunji/flashcards/data/AnkiModelEntity;Ljava/util/List;Ljava/util/List;)V", "getNote", "()Lcom/xunji/flashcards/data/AnkiNoteEntity;", "getModel", "()Lcom/xunji/flashcards/data/AnkiModelEntity;", "getLinks", "()Ljava/util/List;", "getMedia", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 35 */    public final /* data */ class AnkiNoteContent {
                public static final int $stable = 8;
                private final List<AnkiCardEntity> links;
                private final List<AnkiMediaEntity> media;
                private final AnkiModelEntity model;
                private final AnkiNoteEntity note;

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ AnkiNoteContent copy$default(AnkiNoteContent ankiNoteContent, AnkiNoteEntity ankiNoteEntity, AnkiModelEntity ankiModelEntity, List list, List list2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        ankiNoteEntity = ankiNoteContent.note;
                    }
                    if ((i & 2) != 0) {
                        ankiModelEntity = ankiNoteContent.model;
                    }
                    if ((i & 4) != 0) {
                        list = ankiNoteContent.links;
                    }
                    if ((i & 8) != 0) {
                        list2 = ankiNoteContent.media;
                    }
                    return ankiNoteContent.copy(ankiNoteEntity, ankiModelEntity, list, list2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final AnkiNoteEntity getNote() {
                    return this.note;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final AnkiModelEntity getModel() {
                    return this.model;
                }

                public final List<AnkiCardEntity> component3() {
                    return this.links;
                }

                public final List<AnkiMediaEntity> component4() {
                    return this.media;
                }

                public final AnkiNoteContent copy(AnkiNoteEntity note, AnkiModelEntity model, List<AnkiCardEntity> links, List<AnkiMediaEntity> media) {
                    Intrinsics.checkNotNullParameter(note, "note");
                    Intrinsics.checkNotNullParameter(model, "model");
                    Intrinsics.checkNotNullParameter(links, "links");
                    Intrinsics.checkNotNullParameter(media, "media");
                    return new AnkiNoteContent(note, model, links, media);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiNoteContent)) {
                        return false;
                    }
                    AnkiNoteContent ankiNoteContent = (AnkiNoteContent) other;
                    return Intrinsics.areEqual(this.note, ankiNoteContent.note) && Intrinsics.areEqual(this.model, ankiNoteContent.model) && Intrinsics.areEqual(this.links, ankiNoteContent.links) && Intrinsics.areEqual(this.media, ankiNoteContent.media);
                }

                public int hashCode() {
                    return (((((this.note.hashCode() * 31) + this.model.hashCode()) * 31) + this.links.hashCode()) * 31) + this.media.hashCode();
                }

                public String toString() {
                    return "AnkiNoteContent(note=" + this.note + ", model=" + this.model + ", links=" + this.links + ", media=" + this.media + ")";
                }

/* 36 */        public AnkiNoteContent(AnkiNoteEntity note, AnkiModelEntity model, List<AnkiCardEntity> links, List<AnkiMediaEntity> media) {
                    Intrinsics.checkNotNullParameter(note, "note");
                    Intrinsics.checkNotNullParameter(model, "model");
                    Intrinsics.checkNotNullParameter(links, "links");
                    Intrinsics.checkNotNullParameter(media, "media");
                    this.note = note;
                    this.model = model;
                    this.links = links;
                    this.media = media;
                }

/* 36 */        public final List<AnkiCardEntity> getLinks() {
/* 37 */            return this.links;
                }

/* 36 */        public final List<AnkiMediaEntity> getMedia() {
/* 37 */            return this.media;
                }

/* 36 */        public final AnkiModelEntity getModel() {
/* 37 */            return this.model;
                }

/* 36 */        public final AnkiNoteEntity getNote() {
/* 37 */            return this.note;
                }
            }

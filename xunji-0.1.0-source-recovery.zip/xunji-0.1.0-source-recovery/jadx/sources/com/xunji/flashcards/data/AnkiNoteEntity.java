            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiEntities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0010\t\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\nHÆ\u0003JO\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\nHÆ\u0001J\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\"HÖ\u0001J\t\u0010#\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\b\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000eR\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015¨\u0006$"}, d2 = {"Lcom/xunji/flashcards/data/AnkiNoteEntity;", "", "id", "", "sourceGuid", "modelId", "fields", "tags", "mediaNamespace", "revision", "", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V", "getId", "()Ljava/lang/String;", "getSourceGuid", "getModelId", "getFields", "getTags", "getMediaNamespace", "getRevision", "()J", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */    public final /* data */ class AnkiNoteEntity {
                public static final int $stable = 0;
                private final String fields;
                private final String id;
                private final String mediaNamespace;
                private final String modelId;
                private final long revision;
                private final String sourceGuid;
                private final String tags;

                public static /* synthetic */ AnkiNoteEntity copy$default(AnkiNoteEntity ankiNoteEntity, String str, String str2, String str3, String str4, String str5, String str6, long j, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = ankiNoteEntity.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = ankiNoteEntity.sourceGuid;
                    }
                    if ((i & 4) != 0) {
                        str3 = ankiNoteEntity.modelId;
                    }
                    if ((i & 8) != 0) {
                        str4 = ankiNoteEntity.fields;
                    }
                    if ((i & 16) != 0) {
                        str5 = ankiNoteEntity.tags;
                    }
                    if ((i & 32) != 0) {
                        str6 = ankiNoteEntity.mediaNamespace;
                    }
                    if ((i & 64) != 0) {
                        j = ankiNoteEntity.revision;
                    }
                    long j2 = j;
                    String str7 = str5;
                    String str8 = str6;
                    return ankiNoteEntity.copy(str, str2, str3, str4, str7, str8, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getSourceGuid() {
                    return this.sourceGuid;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getModelId() {
                    return this.modelId;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getFields() {
                    return this.fields;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getTags() {
                    return this.tags;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final String getMediaNamespace() {
                    return this.mediaNamespace;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getRevision() {
                    return this.revision;
                }

                public final AnkiNoteEntity copy(String id, String sourceGuid, String modelId, String fields, String tags, String mediaNamespace, long revision) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(sourceGuid, "sourceGuid");
                    Intrinsics.checkNotNullParameter(modelId, "modelId");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    Intrinsics.checkNotNullParameter(mediaNamespace, "mediaNamespace");
                    return new AnkiNoteEntity(id, sourceGuid, modelId, fields, tags, mediaNamespace, revision);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiNoteEntity)) {
                        return false;
                    }
                    AnkiNoteEntity ankiNoteEntity = (AnkiNoteEntity) other;
                    return Intrinsics.areEqual(this.id, ankiNoteEntity.id) && Intrinsics.areEqual(this.sourceGuid, ankiNoteEntity.sourceGuid) && Intrinsics.areEqual(this.modelId, ankiNoteEntity.modelId) && Intrinsics.areEqual(this.fields, ankiNoteEntity.fields) && Intrinsics.areEqual(this.tags, ankiNoteEntity.tags) && Intrinsics.areEqual(this.mediaNamespace, ankiNoteEntity.mediaNamespace) && this.revision == ankiNoteEntity.revision;
                }

                public int hashCode() {
                    return (((((((((((this.id.hashCode() * 31) + this.sourceGuid.hashCode()) * 31) + this.modelId.hashCode()) * 31) + this.fields.hashCode()) * 31) + this.tags.hashCode()) * 31) + this.mediaNamespace.hashCode()) * 31) + Long.hashCode(this.revision);
                }

                public String toString() {
                    return "AnkiNoteEntity(id=" + this.id + ", sourceGuid=" + this.sourceGuid + ", modelId=" + this.modelId + ", fields=" + this.fields + ", tags=" + this.tags + ", mediaNamespace=" + this.mediaNamespace + ", revision=" + this.revision + ")";
                }

/* 14 */        public AnkiNoteEntity(String id, String sourceGuid, String modelId, String fields, String tags, String mediaNamespace, long revision) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(sourceGuid, "sourceGuid");
                    Intrinsics.checkNotNullParameter(modelId, "modelId");
                    Intrinsics.checkNotNullParameter(fields, "fields");
                    Intrinsics.checkNotNullParameter(tags, "tags");
                    Intrinsics.checkNotNullParameter(mediaNamespace, "mediaNamespace");
/* 19 */            this.id = id;
                    this.sourceGuid = sourceGuid;
                    this.modelId = modelId;
/* 20 */            this.fields = fields;
                    this.tags = tags;
                    this.mediaNamespace = mediaNamespace;
                    this.revision = revision;
                }

/* 18 */        public final String getId() {
/* 19 */            return this.id;
                }

/* 18 */        public final String getModelId() {
/* 19 */            return this.modelId;
                }

/* 18 */        public final String getSourceGuid() {
/* 19 */            return this.sourceGuid;
                }

/* 19 */        public final String getFields() {
/* 20 */            return this.fields;
                }

/* 19 */        public final String getMediaNamespace() {
/* 20 */            return this.mediaNamespace;
                }

/* 19 */        public final long getRevision() {
/* 20 */            return this.revision;
                }

/* 19 */        public final String getTags() {
/* 20 */            return this.tags;
                }
            }

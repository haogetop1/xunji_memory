            package com.xunji.flashcards.data;

            import com.xunji.core.anki.AnkiEditValidator;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiNoteContentModel;
            import com.xunji.core.anki.AnkiSavedCardContext;
            import com.xunji.core.anki.ValidatedFields;
            import java.util.LinkedHashMap;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.ranges.RangesKt;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: AnkiRepository.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/core/anki/ValidatedFields;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$updateFields$2$1$validated$1", f = "AnkiRepository.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 59 */    final class AnkiRepository$updateFields$2$1$validated$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super ValidatedFields>, Object> {
                final /* synthetic */ AnkiNoteContent $content;
                final /* synthetic */ List<AnkiSavedCardContext> $contexts;
                final /* synthetic */ List<String> $fields;
                final /* synthetic */ AnkiNoteEntity $note;
                final /* synthetic */ AnkiModel $sourceModel;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnkiRepository$updateFields$2$1$validated$1(AnkiModel ankiModel, AnkiNoteEntity ankiNoteEntity, List<AnkiSavedCardContext> list, AnkiNoteContent ankiNoteContent, List<String> list2, Continuation<? super AnkiRepository$updateFields$2$1$validated$1> continuation) {
                    super(2, continuation);
                    this.$sourceModel = ankiModel;
                    this.$note = ankiNoteEntity;
                    this.$contexts = list;
                    this.$content = ankiNoteContent;
                    this.$fields = list2;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new AnkiRepository$updateFields$2$1$validated$1(this.$sourceModel, this.$note, this.$contexts, this.$content, this.$fields, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super ValidatedFields> continuation) {
                    return ((AnkiRepository$updateFields$2$1$validated$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX WARN: Multi-variable type inference failed */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 60 */        public final Object invokeSuspend(Object obj) throws Throwable {
                    IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure(obj);
/* 62 */                    AnkiEditValidator ankiEditValidator = new AnkiEditValidator(null, 1);
                            AnkiModel ankiModel = this.$sourceModel;
                            List<String> listStrings = AnkiRepository.INSTANCE.strings(this.$note.getFields());
                            List<AnkiSavedCardContext> list = this.$contexts;
                            List<AnkiMediaEntity> media = this.$content.getMedia();
/* 129 */                   LinkedHashMap linkedHashMap = new LinkedHashMap(RangesKt.coerceAtLeast(MapsKt.mapCapacity(CollectionsKt.collectionSizeOrDefault(media, 10)), 16));
                            for (AnkiMediaEntity ankiMediaEntity : media) {
                                List<AnkiMediaEntity> list2 = media;
/* 62 */                        Pair pair = TuplesKt.to(ankiMediaEntity.getOriginalName(), ankiMediaEntity.getMime());
/* 131 */                       linkedHashMap.put(pair.getFirst(), pair.getSecond());
                                media = list2;
                            }
/* 62 */                    return ankiEditValidator.validate(new AnkiNoteContentModel(ankiModel, listStrings, list, linkedHashMap), this.$fields);
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

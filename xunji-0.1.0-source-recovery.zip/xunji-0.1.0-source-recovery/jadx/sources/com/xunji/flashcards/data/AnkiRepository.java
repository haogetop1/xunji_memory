            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import androidx.compose.material.MenuKt;
            import androidx.core.view.MotionEventCompat;
            import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
            import androidx.room.RoomDatabaseKt;
            import com.fasterxml.jackson.core.internal.shaded.fdp.v2_19_2.FastDoubleMath;
            import com.xunji.core.anki.AnkiModel;
            import com.xunji.core.anki.AnkiSourceNote;
            import com.xunji.core.anki.AnkiStorageValidator;
            import com.xunji.core.anki.AnkiTemplate;
            import com.xunji.core.anki.TemplateContext;
            import com.xunji.flashcards.anki.BoundedJson;
            import java.security.MessageDigest;
            import java.util.ArrayList;
            import java.util.Arrays;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.UUID;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.ArraysKt;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.MagicApiIntrinsics;
            import kotlin.jvm.internal.Reflection;
            import kotlin.reflect.KType;
            import kotlin.reflect.KTypeProjection;
            import kotlin.text.Charsets;
            import kotlin.text.Regex;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
            import kotlinx.serialization.SerializersKt;
            import kotlinx.serialization.json.Json;
            import kotlinx.serialization.json.JsonElement;
            import kotlinx.serialization.json.JsonElementBuildersKt;
            import kotlinx.serialization.json.JsonElementKt;
            import kotlinx.serialization.json.JsonObjectBuilder;
            import kotlinx.serialization.modules.SerializersModule;
            
            /* JADX INFO: compiled from: AnkiRepository.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000`\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0001\u0018\u0000 $2\u00020\u0001:\u0001$B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0018\u0010\b\u001a\u0004\u0018\u00010\t2\u0006\u0010\n\u001a\u00020\u000bH\u0086@¢\u0006\u0002\u0010\fJ\u0016\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000eH\u0086@¢\u0006\u0002\u0010\u0010J\u0016\u0010\u0011\u001a\u00020\u00122\u0006\u0010\u0013\u001a\u00020\u0012H\u0086@¢\u0006\u0002\u0010\u0014J,\u0010\u0015\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u00192\f\u0010\u001a\u001a\b\u0012\u0004\u0012\u00020\u000b0\u001bH\u0086@¢\u0006\u0002\u0010\u001cJ(\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\t2\u0006\u0010 \u001a\u00020!2\b\b\u0002\u0010\u000f\u001a\u00020\"H\u0086@¢\u0006\u0002\u0010#R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006%"}, d2 = {"Lcom/xunji/flashcards/data/AnkiRepository;", "", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;)V", "dao", "Lcom/xunji/flashcards/data/AnkiDao;", "noteForCard", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "cardId", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertModel", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "model", "(Lcom/xunji/flashcards/data/AnkiModelEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertNote", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "note", "(Lcom/xunji/flashcards/data/AnkiNoteEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateFields", "", "noteId", "expectedRevision", "", "fields", "", "(Ljava/lang/String;JLjava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "context", "Lcom/xunji/core/anki/TemplateContext;", "content", "link", "Lcom/xunji/flashcards/data/AnkiCardEntity;", "Lcom/xunji/core/anki/AnkiModel;", "(Lcom/xunji/flashcards/data/AnkiNoteContent;Lcom/xunji/flashcards/data/AnkiCardEntity;Lcom/xunji/core/anki/AnkiModel;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */    public final class AnkiRepository {
                private final AnkiDao dao;
                private final XunjiDatabase db;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = XunjiDatabase.$stable;

                /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$context$1, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository", f = "AnkiRepository.kt", i = {0, 0, 0, 1, 1, 1, 1}, l = {74, MenuKt.OutTransitionDuration}, m = "context", n = {"content", "link", "model", "content", "link", "model", "card"}, s = {"L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return AnkiRepository.this.context(null, null, null, this);
                    }
                }

/* 12 */        public AnkiRepository(XunjiDatabase db) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    this.db = db;
/* 14 */            this.dao = this.db.ankiDao();
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$noteForCard$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$noteForCard$2", f = "AnkiRepository.kt", i = {}, l = {17}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 14 */        static final class C04362 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super AnkiNoteContent>, Object> {
                    final /* synthetic */ String $cardId;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04362(String str, Continuation<? super C04362> continuation) {
                        super(2, continuation);
                        this.$cardId = str;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiRepository.this.new C04362(this.$cardId, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super AnkiNoteContent> continuation) {
                        return ((C04362) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$noteForCard$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiRepository.kt */
                    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiNoteContent;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$noteForCard$2$1", f = "AnkiRepository.kt", i = {1, 2, 2, 3, 3, 3, 4, 4, 4}, l = {18, 19, 20, 21, 21}, m = "invokeSuspend", n = {"link", "link", "note", "link", "note", "model", "link", "note", "model"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2"}, v = 1)
/* 15 */            static final class AnonymousClass1 extends SuspendLambda implements Function1<Continuation<? super AnkiNoteContent>, Object> {
                        final /* synthetic */ String $cardId;
                        Object L$0;
                        Object L$1;
                        Object L$2;
                        Object L$3;
                        Object L$4;
                        Object L$5;
                        int label;
                        final /* synthetic */ AnkiRepository this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(AnkiRepository ankiRepository, String str, Continuation<? super AnonymousClass1> continuation) {
                            super(1, continuation);
                            this.this$0 = ankiRepository;
                            this.$cardId = str;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Continuation<?> continuation) {
                            return new AnonymousClass1(this.this$0, this.$cardId, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Continuation<? super AnkiNoteContent> continuation) {
                            return ((AnonymousClass1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:16:0x0083 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:18:0x0085  */
                        /* JADX WARN: Code duplicated, block: B:20:0x00a1 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:22:0x00a4  */
                        /* JADX WARN: Code duplicated, block: B:24:0x00c4 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:25:0x00c5  */
                        /* JADX WARN: Code duplicated, block: B:27:0x00ca  */
                        /* JADX WARN: Code duplicated, block: B:29:0x00f4 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:30:0x00f5  */
                        /* JADX WARN: Code duplicated, block: B:33:0x0129 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:34:0x012a  */
                        /* JADX WARN: Code duplicated, block: B:37:0x0135  */
                        /* JADX WARN: Code duplicated, block: B:39:0x0143  */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 16 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            Object objLink;
                            AnkiCardEntity link;
                            Object objNote;
                            AnkiNoteEntity note;
                            Object objModel;
                            AnkiCardEntity link2;
                            AnkiNoteEntity note2;
                            AnkiModelEntity model;
                            Object objLinks;
                            AnkiNoteEntity note3;
                            AnkiCardEntity link3;
                            AnkiNoteEntity ankiNoteEntity;
                            AnkiModelEntity ankiModelEntity;
                            List list;
                            Object objMedia;
                            List list2;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
                                    this.label = 1;
/* 13 */                            objLink = this.this$0.dao.link(this.$cardId, this);
                                    if (objLink == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 18 */                            link = (AnkiCardEntity) objLink;
                                    if (link == null) {
                                        return null;
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link);
                                    this.label = 2;
/* 13 */                            objNote = this.this$0.dao.note(link.getNoteId(), this);
                                    if (objNote == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 19 */                            if (objNote == null) {
                                        throw new IllegalArgumentException("Anki note is missing".toString());
                                    }
                                    note = (AnkiNoteEntity) objNote;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link);
                                    this.L$1 = note;
                                    this.label = 3;
/* 13 */                            objModel = this.this$0.dao.model(note.getModelId(), this);
                                    if (objModel == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
                                    link2 = link;
/* 20 */                            note2 = note;
                                    if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link2);
                                    this.L$1 = note2;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = note2;
                                    this.L$4 = model;
                                    this.label = 4;
/* 13 */                            objLinks = this.this$0.dao.links(note2.getId(), this);
                                    if (objLinks == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            note3 = note2;
                                    link3 = link2;
                                    ankiNoteEntity = note3;
                                    ankiModelEntity = model;
                                    list = (List) objLinks;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = ankiNoteEntity;
                                    this.L$4 = ankiModelEntity;
                                    this.L$5 = list;
                                    this.label = 5;
/* 13 */                            objMedia = this.this$0.dao.media(note3.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            list2 = list;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    objLink = $result;
/* 18 */                            link = (AnkiCardEntity) objLink;
                                    if (link == null) {
                                        return null;
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link);
                                    this.label = 2;
/* 13 */                            objNote = this.this$0.dao.note(link.getNoteId(), this);
                                    if (objNote == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 19 */                            if (objNote == null) {
                                        throw new IllegalArgumentException("Anki note is missing".toString());
                                    }
                                    note = (AnkiNoteEntity) objNote;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link);
                                    this.L$1 = note;
                                    this.label = 3;
/* 13 */                            objModel = this.this$0.dao.model(note.getModelId(), this);
                                    if (objModel == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
                                    link2 = link;
/* 20 */                            note2 = note;
                                    if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link2);
                                    this.L$1 = note2;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = note2;
                                    this.L$4 = model;
                                    this.label = 4;
/* 13 */                            objLinks = this.this$0.dao.links(note2.getId(), this);
                                    if (objLinks == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            note3 = note2;
                                    link3 = link2;
                                    ankiNoteEntity = note3;
                                    ankiModelEntity = model;
                                    list = (List) objLinks;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = ankiNoteEntity;
                                    this.L$4 = ankiModelEntity;
                                    this.L$5 = list;
                                    this.label = 5;
/* 13 */                            objMedia = this.this$0.dao.media(note3.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            list2 = list;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                case 2:
                                    link = (AnkiCardEntity) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objNote = $result;
/* 19 */                            if (objNote == null) {
                                        throw new IllegalArgumentException("Anki note is missing".toString());
                                    }
                                    note = (AnkiNoteEntity) objNote;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link);
                                    this.L$1 = note;
                                    this.label = 3;
/* 13 */                            objModel = this.this$0.dao.model(note.getModelId(), this);
                                    if (objModel == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
                                    link2 = link;
/* 20 */                            note2 = note;
                                    if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link2);
                                    this.L$1 = note2;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = note2;
                                    this.L$4 = model;
                                    this.label = 4;
/* 13 */                            objLinks = this.this$0.dao.links(note2.getId(), this);
                                    if (objLinks == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            note3 = note2;
                                    link3 = link2;
                                    ankiNoteEntity = note3;
                                    ankiModelEntity = model;
                                    list = (List) objLinks;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = ankiNoteEntity;
                                    this.L$4 = ankiModelEntity;
                                    this.L$5 = list;
                                    this.label = 5;
/* 13 */                            objMedia = this.this$0.dao.media(note3.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            list2 = list;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                case 3:
                                    note2 = (AnkiNoteEntity) this.L$1;
                                    link2 = (AnkiCardEntity) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objModel = $result;
                                    if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link2);
                                    this.L$1 = note2;
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = note2;
                                    this.L$4 = model;
                                    this.label = 4;
/* 13 */                            objLinks = this.this$0.dao.links(note2.getId(), this);
                                    if (objLinks == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            note3 = note2;
                                    link3 = link2;
                                    ankiNoteEntity = note3;
                                    ankiModelEntity = model;
                                    list = (List) objLinks;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = ankiNoteEntity;
                                    this.L$4 = ankiModelEntity;
                                    this.L$5 = list;
                                    this.label = 5;
/* 13 */                            objMedia = this.this$0.dao.media(note3.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            list2 = list;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                case 4:
                                    ankiModelEntity = (AnkiModelEntity) this.L$4;
                                    ankiNoteEntity = (AnkiNoteEntity) this.L$3;
                                    model = (AnkiModelEntity) this.L$2;
                                    AnkiNoteEntity note4 = (AnkiNoteEntity) this.L$1;
                                    AnkiCardEntity link4 = (AnkiCardEntity) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    link3 = link4;
                                    note3 = note4;
                                    objLinks = $result;
                                    list = (List) objLinks;
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(link3);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(note3);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(model);
                                    this.L$3 = ankiNoteEntity;
                                    this.L$4 = ankiModelEntity;
                                    this.L$5 = list;
                                    this.label = 5;
/* 13 */                            objMedia = this.this$0.dao.media(note3.getMediaNamespace(), this);
                                    if (objMedia == coroutine_suspended) {
/* 17 */                                return coroutine_suspended;
                                    }
/* 21 */                            list2 = list;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                case 5:
                                    list2 = (List) this.L$5;
                                    ankiModelEntity = (AnkiModelEntity) this.L$4;
                                    ankiNoteEntity = (AnkiNoteEntity) this.L$3;
                                    ResultKt.throwOnFailure($result);
                                    objMedia = $result;
                                    return new AnkiNoteContent(ankiNoteEntity, ankiModelEntity, list2, (List) objMedia);
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 15 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 13 */                        Object objWithTransaction = RoomDatabaseKt.withTransaction(AnkiRepository.this.db, new AnonymousClass1(AnkiRepository.this, this.$cardId, null), this);
                                if (objWithTransaction == coroutine_suspended) {
/* 16 */                            return coroutine_suspended;
                                }
/* 22 */                        return objWithTransaction;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 15 */        public final Object noteForCard(String cardId, Continuation<? super AnkiNoteContent> continuation) {
/* 16 */            return BuildersKt.withContext(Dispatchers.getIO(), new C04362(cardId, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$insertModel$2, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$insertModel$2", f = "AnkiRepository.kt", i = {}, l = {26}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 23 */        static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super AnkiModelEntity>, Object> {
                    final /* synthetic */ AnkiModelEntity $model;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(AnkiModelEntity ankiModelEntity, Continuation<? super AnonymousClass2> continuation) {
                        super(2, continuation);
                        this.$model = ankiModelEntity;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiRepository.this.new AnonymousClass2(this.$model, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super AnkiModelEntity> continuation) {
                        return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$insertModel$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiRepository.kt */
                    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiModelEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$insertModel$2$1", f = "AnkiRepository.kt", i = {0, 1, 2}, l = {MotionEventCompat.AXIS_RELATIVE_Y, 29, 30}, m = "invokeSuspend", n = {"bytes", "bytes", "bytes"}, s = {"I$0", "I$0", "I$0"}, v = 1)
/* 24 */            static final class AnonymousClass1 extends SuspendLambda implements Function1<Continuation<? super AnkiModelEntity>, Object> {
                        final /* synthetic */ AnkiModelEntity $model;
                        int I$0;
                        int label;
                        final /* synthetic */ AnkiRepository this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(AnkiModelEntity ankiModelEntity, AnkiRepository ankiRepository, Continuation<? super AnonymousClass1> continuation) {
                            super(1, continuation);
                            this.$model = ankiModelEntity;
                            this.this$0 = ankiRepository;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Continuation<?> continuation) {
                            return new AnonymousClass1(this.$model, this.this$0, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Continuation<? super AnkiModelEntity> continuation) {
                            return ((AnonymousClass1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:14:0x0052  */
                        /* JADX WARN: Code duplicated, block: B:16:0x0054  */
                        /* JADX WARN: Code duplicated, block: B:18:0x0068 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:21:0x0078  */
                        /* JADX WARN: Code duplicated, block: B:22:0x007a  */
                        /* JADX WARN: Code duplicated, block: B:24:0x007d  */
                        /* JADX WARN: Code duplicated, block: B:26:0x0093 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:27:0x0094  */
                        /* JADX WARN: Code duplicated, block: B:30:0x00a1  */
                        /* JADX WARN: Code duplicated, block: B:32:0x00a4  */
                        /* JADX WARN: Code duplicated, block: B:34:0x00a7  */
                        /* JADX WARN: Code duplicated, block: B:36:0x00b5  */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 25 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            int bytes;
                            Object objModelByHash;
                            AnkiModelEntity ankiModelEntity;
                            Object objModelStorageBytes;
                            boolean z;
                            Object objInsertModel;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 27 */                            bytes = AnkiRepository.INSTANCE.validateModel(this.$model);
                                    this.I$0 = bytes;
                                    this.label = 1;
/* 13 */                            objModelByHash = this.this$0.dao.modelByHash(this.$model.getContentHash(), this);
                                    if (objModelByHash == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
/* 28 */                            ankiModelEntity = (AnkiModelEntity) objModelByHash;
                                    if (ankiModelEntity != null) {
/* 28 */                                return ankiModelEntity;
                                    }
                                    this.I$0 = bytes;
                                    this.label = 2;
/* 13 */                            objModelStorageBytes = this.this$0.dao.modelStorageBytes(this);
                                    if (objModelStorageBytes == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objModelStorageBytes).longValue() + ((long) bytes) <= 33554432) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (!z) {
                                        throw new IllegalArgumentException("Stored model collection exceeds 32 MiB".toString());
                                    }
                                    this.I$0 = bytes;
                                    this.label = 3;
/* 13 */                            objInsertModel = this.this$0.dao.insertModel(this.$model, this);
                                    if (objInsertModel == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertModel).longValue() != -1) {
/* 31 */                                return this.$model;
                                    }
                                    throw new IllegalArgumentException("Local model UUID conflicts".toString());
                                case 1:
                                    bytes = this.I$0;
                                    ResultKt.throwOnFailure($result);
                                    objModelByHash = $result;
/* 28 */                            ankiModelEntity = (AnkiModelEntity) objModelByHash;
                                    if (ankiModelEntity != null) {
/* 28 */                                return ankiModelEntity;
                                    }
                                    this.I$0 = bytes;
                                    this.label = 2;
/* 13 */                            objModelStorageBytes = this.this$0.dao.modelStorageBytes(this);
                                    if (objModelStorageBytes == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objModelStorageBytes).longValue() + ((long) bytes) <= 33554432) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (!z) {
                                        throw new IllegalArgumentException("Stored model collection exceeds 32 MiB".toString());
                                    }
                                    this.I$0 = bytes;
                                    this.label = 3;
/* 13 */                            objInsertModel = this.this$0.dao.insertModel(this.$model, this);
                                    if (objInsertModel == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertModel).longValue() != -1) {
/* 31 */                                return this.$model;
                                    }
                                    throw new IllegalArgumentException("Local model UUID conflicts".toString());
                                case 2:
                                    bytes = this.I$0;
                                    ResultKt.throwOnFailure($result);
                                    objModelStorageBytes = $result;
                                    if (((Number) objModelStorageBytes).longValue() + ((long) bytes) <= 33554432) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (!z) {
                                        throw new IllegalArgumentException("Stored model collection exceeds 32 MiB".toString());
                                    }
                                    this.I$0 = bytes;
                                    this.label = 3;
/* 13 */                            objInsertModel = this.this$0.dao.insertModel(this.$model, this);
                                    if (objInsertModel == coroutine_suspended) {
/* 26 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertModel).longValue() != -1) {
/* 31 */                                return this.$model;
                                    }
                                    throw new IllegalArgumentException("Local model UUID conflicts".toString());
                                case 3:
                                    int i = this.I$0;
                                    ResultKt.throwOnFailure($result);
                                    objInsertModel = $result;
                                    if (((Number) objInsertModel).longValue() != -1) {
/* 31 */                                return this.$model;
                                    }
                                    throw new IllegalArgumentException("Local model UUID conflicts".toString());
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 24 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 13 */                        Object objWithTransaction = RoomDatabaseKt.withTransaction(AnkiRepository.this.db, new AnonymousClass1(this.$model, AnkiRepository.this, null), this);
                                if (objWithTransaction == coroutine_suspended) {
/* 25 */                            return coroutine_suspended;
                                }
/* 32 */                        return objWithTransaction;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 24 */        public final Object insertModel(AnkiModelEntity model, Continuation<? super AnkiModelEntity> continuation) {
/* 25 */            return BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass2(model, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$insertNote$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$insertNote$2", f = "AnkiRepository.kt", i = {}, l = {36}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 33 */        static final class C04352 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super AnkiNoteEntity>, Object> {
                    final /* synthetic */ AnkiNoteEntity $note;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04352(AnkiNoteEntity ankiNoteEntity, Continuation<? super C04352> continuation) {
                        super(2, continuation);
                        this.$note = ankiNoteEntity;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiRepository.this.new C04352(this.$note, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super AnkiNoteEntity> continuation) {
                        return ((C04352) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$insertNote$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiRepository.kt */
                    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/data/AnkiNoteEntity;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$insertNote$2$1", f = "AnkiRepository.kt", i = {0, 1, 1, 2, 2}, l = {MotionEventCompat.AXIS_GENERIC_7, MotionEventCompat.AXIS_GENERIC_9, MotionEventCompat.AXIS_GENERIC_13}, m = "invokeSuspend", n = {"fields", "fields", "model", "fields", "model"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1"}, v = 1)
/* 34 */            static final class AnonymousClass1 extends SuspendLambda implements Function1<Continuation<? super AnkiNoteEntity>, Object> {
                        final /* synthetic */ AnkiNoteEntity $note;
                        Object L$0;
                        Object L$1;
                        int label;
                        final /* synthetic */ AnkiRepository this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(AnkiNoteEntity ankiNoteEntity, AnkiRepository ankiRepository, Continuation<? super AnonymousClass1> continuation) {
                            super(1, continuation);
                            this.$note = ankiNoteEntity;
                            this.this$0 = ankiRepository;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Continuation<?> continuation) {
                            return new AnonymousClass1(this.$note, this.this$0, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Continuation<? super AnkiNoteEntity> continuation) {
                            return ((AnonymousClass1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:13:0x005f  */
                        /* JADX WARN: Code duplicated, block: B:15:0x0075  */
                        /* JADX WARN: Code duplicated, block: B:16:0x0077  */
                        /* JADX WARN: Code duplicated, block: B:18:0x007a  */
                        /* JADX WARN: Code duplicated, block: B:20:0x009e A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:21:0x009f  */
                        /* JADX WARN: Code duplicated, block: B:24:0x00a6  */
                        /* JADX WARN: Code duplicated, block: B:26:0x00b7 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:27:0x00b8  */
                        /* JADX WARN: Code duplicated, block: B:29:0x00c6  */
                        /* JADX WARN: Code duplicated, block: B:31:0x00e6 A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:32:0x00e7  */
                        /* JADX WARN: Code duplicated, block: B:35:0x00f5  */
                        /* JADX WARN: Code duplicated, block: B:37:0x00f8  */
                        /* JADX WARN: Code duplicated, block: B:39:0x00fb  */
                        /* JADX WARN: Code duplicated, block: B:41:0x0109  */
                        /* JADX WARN: Code duplicated, block: B:43:0x0117  */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 35 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            List<String> listValidateNote;
                            Object objModel;
                            AnkiModelEntity model;
                            boolean z;
                            Object objNoteByGuid;
                            List<String> list;
                            AnkiModelEntity model2;
                            AnkiNoteEntity ankiNoteEntity;
                            Object objInsertNote;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 37 */                            listValidateNote = AnkiRepository.INSTANCE.validateNote(this.$note);
                                    this.L$0 = listValidateNote;
                                    this.label = 1;
/* 13 */                            objModel = this.this$0.dao.model(this.$note.getModelId(), this);
                                    if (objModel == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
/* 38 */                            if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
/* 39 */                            if (listValidateNote.size() == AnkiRepository.INSTANCE.strings(model.getFieldNames()).size()) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
                                        throw new IllegalArgumentException("Note field mapping differs from model".toString());
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(listValidateNote);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(model);
                                    this.label = 2;
/* 13 */                            objNoteByGuid = this.this$0.dao.noteByGuid(this.$note.getSourceGuid(), this);
                                    if (objNoteByGuid == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    list = listValidateNote;
/* 40 */                            model2 = model;
                                    ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
                                    if (ankiNoteEntity != null) {
/* 41 */                                if (Intrinsics.areEqual(ankiNoteEntity.getModelId(), this.$note.getModelId())) {
/* 42 */                                    return ankiNoteEntity;
                                        }
                                        throw new IllegalArgumentException("Existing GUID uses a conflicting model; repeat preflight".toString());
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(list);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(model2);
                                    this.label = 3;
/* 13 */                            objInsertNote = this.this$0.dao.insertNote(this.$note, this);
                                    if (objInsertNote == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertNote).longValue() != -1) {
/* 45 */                                return this.$note;
                                    }
                                    throw new IllegalArgumentException("Local note UUID conflicts".toString());
                                case 1:
                                    listValidateNote = (List) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objModel = $result;
/* 38 */                            if (objModel != null) {
                                        throw new IllegalArgumentException("Anki model is missing".toString());
                                    }
                                    model = (AnkiModelEntity) objModel;
/* 39 */                            if (listValidateNote.size() == AnkiRepository.INSTANCE.strings(model.getFieldNames()).size()) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
                                        throw new IllegalArgumentException("Note field mapping differs from model".toString());
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(listValidateNote);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(model);
                                    this.label = 2;
/* 13 */                            objNoteByGuid = this.this$0.dao.noteByGuid(this.$note.getSourceGuid(), this);
                                    if (objNoteByGuid == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    list = listValidateNote;
/* 40 */                            model2 = model;
                                    ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
                                    if (ankiNoteEntity != null) {
/* 41 */                                if (Intrinsics.areEqual(ankiNoteEntity.getModelId(), this.$note.getModelId())) {
/* 42 */                                    return ankiNoteEntity;
                                        }
                                        throw new IllegalArgumentException("Existing GUID uses a conflicting model; repeat preflight".toString());
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(list);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(model2);
                                    this.label = 3;
/* 13 */                            objInsertNote = this.this$0.dao.insertNote(this.$note, this);
                                    if (objInsertNote == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertNote).longValue() != -1) {
/* 45 */                                return this.$note;
                                    }
                                    throw new IllegalArgumentException("Local note UUID conflicts".toString());
                                case 2:
                                    model2 = (AnkiModelEntity) this.L$1;
                                    list = (List) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objNoteByGuid = $result;
                                    ankiNoteEntity = (AnkiNoteEntity) objNoteByGuid;
                                    if (ankiNoteEntity != null) {
/* 41 */                                if (Intrinsics.areEqual(ankiNoteEntity.getModelId(), this.$note.getModelId())) {
/* 42 */                                    return ankiNoteEntity;
                                        }
                                        throw new IllegalArgumentException("Existing GUID uses a conflicting model; repeat preflight".toString());
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(list);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(model2);
                                    this.label = 3;
/* 13 */                            objInsertNote = this.this$0.dao.insertNote(this.$note, this);
                                    if (objInsertNote == coroutine_suspended) {
/* 36 */                                return coroutine_suspended;
                                    }
                                    if (((Number) objInsertNote).longValue() != -1) {
/* 45 */                                return this.$note;
                                    }
                                    throw new IllegalArgumentException("Local note UUID conflicts".toString());
                                case 3:
                                    ResultKt.throwOnFailure($result);
                                    objInsertNote = $result;
                                    if (((Number) objInsertNote).longValue() != -1) {
/* 45 */                                return this.$note;
                                    }
                                    throw new IllegalArgumentException("Local note UUID conflicts".toString());
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 34 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 13 */                        Object objWithTransaction = RoomDatabaseKt.withTransaction(AnkiRepository.this.db, new AnonymousClass1(this.$note, AnkiRepository.this, null), this);
                                if (objWithTransaction == coroutine_suspended) {
/* 35 */                            return coroutine_suspended;
                                }
/* 46 */                        return objWithTransaction;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                return $result;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 34 */        public final Object insertNote(AnkiNoteEntity note, Continuation<? super AnkiNoteEntity> continuation) {
/* 35 */            return BuildersKt.withContext(Dispatchers.getIO(), new C04352(note, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$updateFields$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$updateFields$2", f = "AnkiRepository.kt", i = {}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 47 */        static final class C04372 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ long $expectedRevision;
                    final /* synthetic */ List<String> $fields;
                    final /* synthetic */ String $noteId;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04372(String str, long j, List<String> list, Continuation<? super C04372> continuation) {
                        super(2, continuation);
                        this.$noteId = str;
                        this.$expectedRevision = j;
                        this.$fields = list;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiRepository.this.new C04372(this.$noteId, this.$expectedRevision, this.$fields, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04372) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.data.AnkiRepository$updateFields$2$1, reason: invalid class name */
                    /* JADX INFO: compiled from: AnkiRepository.kt */
                    @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.data.AnkiRepository$updateFields$2$1", f = "AnkiRepository.kt", i = {1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8, 8, 8, 8}, l = {51, FastDoubleMath.DOUBLE_SIGNIFICAND_WIDTH, 58, 58, LockFreeTaskQueueCore.FROZEN_SHIFT, LockFreeTaskQueueCore.CLOSED_SHIFT, 66, 67, 69}, m = "invokeSuspend", n = {"note", "note", "model", "updated", "note", "model", "updated", "note", "model", "updated", "content", "sourceModel", "$this$map\\6", "$this$mapTo\\7", "destination\\7", "item\\7", "it\\8", "$i$f$map\\6\\60", "$i$f$mapTo\\7\\130", "$i$a$-map-AnkiRepository$updateFields$2$1$contexts$1\\8\\132\\0", "note", "model", "updated", "content", "sourceModel", "contexts", "note", "model", "updated", "content", "sourceModel", "contexts", "validated", "cardId", "preview", "now", "note", "model", "updated", "content", "sourceModel", "contexts", "validated", "cardId", "preview", "card", "now", "note", "model", "updated", "content", "sourceModel", "contexts", "validated", "now"}, s = {"L$0", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$7", "L$8", "L$10", "L$11", "I$0", "I$1", "I$2", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "L$9", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "L$8", "L$9", "L$10", "J$0", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$6", "J$0"}, v = 1)
/* 48 */            static final class AnonymousClass1 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                        final /* synthetic */ long $expectedRevision;
                        final /* synthetic */ List<String> $fields;
                        final /* synthetic */ String $noteId;
                        int I$0;
                        int I$1;
                        int I$2;
                        int I$3;
                        long J$0;
                        Object L$0;
                        Object L$1;
                        Object L$10;
                        Object L$11;
                        Object L$12;
                        Object L$13;
                        Object L$2;
                        Object L$3;
                        Object L$4;
                        Object L$5;
                        Object L$6;
                        Object L$7;
                        Object L$8;
                        Object L$9;
                        int label;
                        final /* synthetic */ AnkiRepository this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass1(AnkiRepository ankiRepository, String str, long j, List<String> list, Continuation<? super AnonymousClass1> continuation) {
                            super(1, continuation);
                            this.this$0 = ankiRepository;
                            this.$noteId = str;
                            this.$expectedRevision = j;
                            this.$fields = list;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Continuation<?> continuation) {
                            return new AnonymousClass1(this.this$0, this.$noteId, this.$expectedRevision, this.$fields, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Continuation<? super Unit> continuation) {
                            return ((AnonymousClass1) create(continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:47:0x0311  */
                        /* JADX WARN: Code duplicated, block: B:49:0x036d A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:50:0x036e  */
                        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:50:0x036e -> B:51:0x0382). Please report as a decompilation issue!!! */
                        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:67:0x051a -> B:68:0x0528). Please report as a decompilation issue!!! */
                        /*  JADX ERROR: JadxOverflowException in pass: RegionMakerVisitor
                            jadx.core.utils.exceptions.JadxOverflowException: Regions stack size limit reached
                            	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                            	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                            	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                            */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 49 */                public final java.lang.Object invokeSuspend(java.lang.Object r35) {
                            /*
                                Method dump skipped, instruction units count: 1544
                                To view this dump change 'Code comments level' option to 'DEBUG'
                            */
                            throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.data.AnkiRepository.C04372.AnonymousClass1.invokeSuspend(java.lang.Object):java.lang.Object");
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 48 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 13 */                        if (RoomDatabaseKt.withTransaction(AnkiRepository.this.db, new AnonymousClass1(AnkiRepository.this, this.$noteId, this.$expectedRevision, this.$fields, null), this) == coroutine_suspended) {
/* 49 */                            return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 71 */                return Unit.INSTANCE;
                    }
                }

/* 48 */        public final Object updateFields(String noteId, long expectedRevision, List<String> list, Continuation<? super Unit> continuation) {
/* 49 */            Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new C04372(noteId, expectedRevision, list, null), continuation);
                    return objWithContext == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithContext : Unit.INSTANCE;
                }

/* 72 */        public static /* synthetic */ Object context$default(AnkiRepository ankiRepository, AnkiNoteContent ankiNoteContent, AnkiCardEntity ankiCardEntity, AnkiModel ankiModel, Continuation continuation, int i, Object obj) {
/* 73 */            if ((i & 4) != 0) {
                        ankiModel = INSTANCE.asModel(ankiNoteContent.getModel());
                    }
                    return ankiRepository.context(ankiNoteContent, ankiCardEntity, ankiModel, continuation);
                }

                /* JADX WARN: Code duplicated, block: B:19:0x0084  */
                /* JADX WARN: Code duplicated, block: B:21:0x00a5 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:22:0x00a6  */
                /* JADX WARN: Code duplicated, block: B:24:0x00a9  */
                /* JADX WARN: Code duplicated, block: B:27:0x00bd  */
                /* JADX WARN: Code duplicated, block: B:29:0x00d2  */
                /* JADX WARN: Code duplicated, block: B:30:0x00d5  */
                /* JADX WARN: Code duplicated, block: B:32:0x00db  */
                /* JADX WARN: Code duplicated, block: B:39:0x00ed  */
                /* JADX WARN: Code duplicated, block: B:40:0x00f2  */
                /* JADX WARN: Code duplicated, block: B:42:0x00f5  */
                /* JADX WARN: Code duplicated, block: B:46:0x012e A[LOOP:1: B:44:0x0128->B:46:0x012e, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:49:0x0152  */
                /* JADX WARN: Code duplicated, block: B:51:0x0160  */
                /* JADX WARN: Code duplicated, block: B:54:0x00e3 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                /* JADX WARN: Instruction removed from duplicated block: B:27:0x00bd, please report this as an issue */
/* 72 */        public final Object context(AnkiNoteContent content, AnkiCardEntity link, AnkiModel model, Continuation<? super TemplateContext> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    AnkiNoteContent content2;
                    AnkiCardEntity link2;
                    Object obj;
                    AnkiModel model2;
                    Object objDeck;
                    Iterator it;
                    Object next;
                    AnkiTemplate template;
                    String name;
                    Collection arrayList;
                    Iterator it2;
                    int ordinal;
                    int ordinal2;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 74 */                    XunjiDao xunjiDaoDao = this.db.dao();
                            String cardId = link.getCardId();
                            content2 = content;
                            anonymousClass1.L$0 = content2;
                            anonymousClass1.L$1 = link;
                            anonymousClass1.L$2 = model;
                            anonymousClass1.label = 1;
                            Object objCard = xunjiDaoDao.card(cardId, anonymousClass1);
                            if (objCard == coroutine_suspended) {
/* 73 */                        return coroutine_suspended;
                            }
/* 74 */                    link2 = link;
                            obj = objCard;
                            model2 = model;
                            if (obj != null) {
                                throw new IllegalArgumentException("Card was deleted".toString());
                            }
                            CardEntity card = (CardEntity) obj;
/* 75 */                    XunjiDao xunjiDaoDao2 = this.db.dao();
                            String deckId = card.getDeckId();
                            anonymousClass1.L$0 = content2;
                            anonymousClass1.L$1 = link2;
                            anonymousClass1.L$2 = model2;
                            anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable(card);
                            anonymousClass1.label = 2;
                            objDeck = xunjiDaoDao2.deck(deckId, anonymousClass1);
                            if (objDeck == coroutine_suspended) {
/* 73 */                        return coroutine_suspended;
                            }
                            if (objDeck == null) {
                                throw new IllegalArgumentException("Deck was deleted".toString());
                            }
                            DeckEntity deck = (DeckEntity) objDeck;
/* 129 */                   it = model2.getTemplates().iterator();
/* 129 */                   do {
                                if (it.hasNext()) {
                                    next = it.next();
/* 76 */                            ordinal = ((AnkiTemplate) next).getOrdinal();
                                    if (model2.getKind() == 1) {
                                        ordinal2 = 0;
                                    } else {
                                        ordinal2 = link2.getOrdinal();
                                    }
                                } else {
/* 130 */                           next = null;
                                }
/* 76 */                        template = (AnkiTemplate) next;
/* 77 */                        String name2 = deck.getName();
                                if (template != null) {
                                    name = template.getName();
                                } else {
                                    name = null;
                                }
                                if (name == null) {
                                    name = "";
                                }
                                String str = name;
                                List<String> listStrings = INSTANCE.strings(content2.getNote().getTags());
                                String name3 = model2.getName();
                                Iterable media = content2.getMedia();
/* 131 */                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media, 10));
/* 132 */                       it2 = media.iterator();
                                while (it2.hasNext()) {
/* 133 */                           arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                                }
/* 77 */                        return new TemplateContext(name2, str, listStrings, name3, CollectionsKt.toSet((List) arrayList));
/* 129 */                   } while (!(ordinal == ordinal2));
/* 76 */                    template = (AnkiTemplate) next;
/* 77 */                    String name4 = deck.getName();
                            if (template != null) {
                                name = template.getName();
                            } else {
                                name = null;
                            }
                            if (name == null) {
                                name = "";
                            }
                            String str2 = name;
                            List<String> listStrings2 = INSTANCE.strings(content2.getNote().getTags());
                            String name5 = model2.getName();
                            Iterable media2 = content2.getMedia();
/* 131 */                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media2, 10));
/* 132 */                   it2 = media2.iterator();
                            while (it2.hasNext()) {
/* 133 */                       arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                            }
/* 77 */                    return new TemplateContext(name4, str2, listStrings2, name5, CollectionsKt.toSet((List) arrayList));
                        case 1:
                            model2 = (AnkiModel) anonymousClass1.L$2;
                            link2 = (AnkiCardEntity) anonymousClass1.L$1;
                            content2 = (AnkiNoteContent) anonymousClass1.L$0;
                            ResultKt.throwOnFailure($result);
                            obj = $result;
                            if (obj != null) {
                                throw new IllegalArgumentException("Card was deleted".toString());
                            }
                            CardEntity card2 = (CardEntity) obj;
/* 75 */                    XunjiDao xunjiDaoDao3 = this.db.dao();
                            String deckId2 = card2.getDeckId();
                            anonymousClass1.L$0 = content2;
                            anonymousClass1.L$1 = link2;
                            anonymousClass1.L$2 = model2;
                            anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable(card2);
                            anonymousClass1.label = 2;
                            objDeck = xunjiDaoDao3.deck(deckId2, anonymousClass1);
                            if (objDeck == coroutine_suspended) {
/* 73 */                        return coroutine_suspended;
                            }
                            if (objDeck == null) {
                                throw new IllegalArgumentException("Deck was deleted".toString());
                            }
                            DeckEntity deck2 = (DeckEntity) objDeck;
/* 129 */                   it = model2.getTemplates().iterator();
/* 129 */                   do {
                                if (it.hasNext()) {
                                    next = it.next();
/* 76 */                            ordinal = ((AnkiTemplate) next).getOrdinal();
                                    if (model2.getKind() == 1) {
                                        ordinal2 = 0;
                                    } else {
                                        ordinal2 = link2.getOrdinal();
                                    }
                                } else {
/* 130 */                           next = null;
                                }
/* 76 */                        template = (AnkiTemplate) next;
/* 77 */                        String name6 = deck2.getName();
                                if (template != null) {
                                    name = template.getName();
                                } else {
                                    name = null;
                                }
                                if (name == null) {
                                    name = "";
                                }
                                String str3 = name;
                                List<String> listStrings3 = INSTANCE.strings(content2.getNote().getTags());
                                String name7 = model2.getName();
                                Iterable media3 = content2.getMedia();
/* 131 */                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media3, 10));
/* 132 */                       it2 = media3.iterator();
                                while (it2.hasNext()) {
/* 133 */                           arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                                }
/* 77 */                        return new TemplateContext(name6, str3, listStrings3, name7, CollectionsKt.toSet((List) arrayList));
/* 129 */                   } while (!(ordinal == ordinal2));
/* 76 */                    template = (AnkiTemplate) next;
/* 77 */                    String name8 = deck2.getName();
                            if (template != null) {
                                name = template.getName();
                            } else {
                                name = null;
                            }
                            if (name == null) {
                                name = "";
                            }
                            String str4 = name;
                            List<String> listStrings4 = INSTANCE.strings(content2.getNote().getTags());
                            String name9 = model2.getName();
                            Iterable media4 = content2.getMedia();
/* 131 */                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media4, 10));
/* 132 */                   it2 = media4.iterator();
                            while (it2.hasNext()) {
/* 133 */                       arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                            }
/* 77 */                    return new TemplateContext(name8, str4, listStrings4, name9, CollectionsKt.toSet((List) arrayList));
                        case 2:
                            model2 = (AnkiModel) anonymousClass1.L$2;
                            link2 = (AnkiCardEntity) anonymousClass1.L$1;
                            content2 = (AnkiNoteContent) anonymousClass1.L$0;
                            ResultKt.throwOnFailure($result);
                            objDeck = $result;
                            if (objDeck == null) {
                                throw new IllegalArgumentException("Deck was deleted".toString());
                            }
                            DeckEntity deck3 = (DeckEntity) objDeck;
/* 129 */                   it = model2.getTemplates().iterator();
/* 129 */                   do {
                                if (it.hasNext()) {
                                    next = it.next();
/* 76 */                            ordinal = ((AnkiTemplate) next).getOrdinal();
                                    if (model2.getKind() == 1) {
                                        ordinal2 = 0;
                                    } else {
                                        ordinal2 = link2.getOrdinal();
                                    }
                                } else {
/* 130 */                           next = null;
                                }
/* 76 */                        template = (AnkiTemplate) next;
/* 77 */                        String name10 = deck3.getName();
                                if (template != null) {
                                    name = template.getName();
                                } else {
                                    name = null;
                                }
                                if (name == null) {
                                    name = "";
                                }
                                String str5 = name;
                                List<String> listStrings5 = INSTANCE.strings(content2.getNote().getTags());
                                String name11 = model2.getName();
                                Iterable media5 = content2.getMedia();
/* 131 */                       arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media5, 10));
/* 132 */                       it2 = media5.iterator();
                                while (it2.hasNext()) {
/* 133 */                           arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                                }
/* 77 */                        return new TemplateContext(name10, str5, listStrings5, name11, CollectionsKt.toSet((List) arrayList));
/* 129 */                   } while (!(ordinal == ordinal2));
/* 76 */                    template = (AnkiTemplate) next;
/* 77 */                    String name12 = deck3.getName();
                            if (template != null) {
                                name = template.getName();
                            } else {
                                name = null;
                            }
                            if (name == null) {
                                name = "";
                            }
                            String str6 = name;
                            List<String> listStrings6 = INSTANCE.strings(content2.getNote().getTags());
                            String name13 = model2.getName();
                            Iterable media6 = content2.getMedia();
/* 131 */                   arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(media6, 10));
/* 132 */                   it2 = media6.iterator();
                            while (it2.hasNext()) {
/* 133 */                       arrayList.add(((AnkiMediaEntity) it2.next()).getOriginalName());
                            }
/* 77 */                    return new TemplateContext(name12, str6, listStrings6, name13, CollectionsKt.toSet((List) arrayList));
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: compiled from: AnkiRepository.kt */
                @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0007J\u0018\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u00052\b\b\u0002\u0010\n\u001a\u00020\u000bJ(\u0010\f\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\u0010\u001a\u00020\u000b2\b\b\u0002\u0010\n\u001a\u00020\u000bJ\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00122\u0006\u0010\u0013\u001a\u00020\rJ\u000e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0006\u001a\u00020\u0007J\u0014\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00122\u0006\u0010\u0017\u001a\u00020\u000bJ\u0016\u0010\u0018\u001a\u00020\u00152\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u000b0\u0012H\u0002J\u0010\u0010\u001a\u001a\u00020\u000b2\u0006\u0010\u0006\u001a\u00020\u0005H\u0002¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/data/AnkiRepository$Companion;", "", "<init>", "()V", "asModel", "Lcom/xunji/core/anki/AnkiModel;", "model", "Lcom/xunji/flashcards/data/AnkiModelEntity;", "modelSnapshot", "source", "id", "", "noteSnapshot", "Lcom/xunji/flashcards/data/AnkiNoteEntity;", "Lcom/xunji/core/anki/AnkiSourceNote;", "modelId", "namespace", "validateNote", "", "note", "validateModel", "", "strings", "json", "storedBytes", "text", "contentHash", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 78 */        public static final class Companion {
/* 79 */            private Companion() {
                    }

/* 80 */            public final AnkiModel asModel(AnkiModelEntity model) {
                        Intrinsics.checkNotNullParameter(model, "model");
                        long j = Long.parseLong(model.getSourceModelId());
                        String name = model.getName();
                        int kind = model.getKind();
                        List<String> listStrings = strings(model.getFieldNames());
                        Json json = Json.INSTANCE;
                        String templates = model.getTemplates();
/* 128 */               SerializersModule serializersModule = json.getSerializersModule();
                        KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 81 */                return new AnkiModel(j, name, kind, listStrings, (List) json.decodeFromString(SerializersKt.serializer(serializersModule, kTypeTypeOf), templates), model.getCss(), model.getOriginalStockKind());
                    }

/* 82 */            public static /* synthetic */ AnkiModelEntity modelSnapshot$default(Companion companion, AnkiModel ankiModel, String str, int i, Object obj) {
/* 83 */                if ((i & 2) != 0) {
                            str = UUID.randomUUID().toString();
                            Intrinsics.checkNotNullExpressionValue(str, "toString(...)");
                        }
                        return companion.modelSnapshot(ankiModel, str);
                    }

/* 83 */            public final AnkiModelEntity modelSnapshot(AnkiModel source, String id) {
                        Intrinsics.checkNotNullParameter(source, "source");
                        Intrinsics.checkNotNullParameter(id, "id");
/* 84 */                AnkiStorageValidator.validateModel$default(AnkiStorageValidator.INSTANCE, source.getFieldNames(), source.getTemplates(), CollectionsKt.listOf((Object[]) new String[]{id, String.valueOf(source.getSourceId()), StringsKt.repeat("x", 64), source.getName(), source.getCss()}), 0, 8, null);
                        String strValueOf = String.valueOf(source.getSourceId());
                        String strContentHash = contentHash(source);
                        String name = source.getName();
                        int kind = source.getKind();
                        int originalStockKind = source.getOriginalStockKind();
/* 86 */                Json json = Json.INSTANCE;
                        List<String> fieldNames = source.getFieldNames();
/* 129 */               SerializersModule serializersModule = json.getSerializersModule();
                        KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(String.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
                        String strEncodeToString = json.encodeToString(SerializersKt.serializer(serializersModule, kTypeTypeOf), fieldNames);
/* 86 */                Json json2 = Json.INSTANCE;
                        List<AnkiTemplate> templates = source.getTemplates();
/* 129 */               SerializersModule serializersModule2 = json2.getSerializersModule();
                        KType kTypeTypeOf2 = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 85 */                return new AnkiModelEntity(id, strValueOf, strContentHash, name, kind, originalStockKind, strEncodeToString, json2.encodeToString(SerializersKt.serializer(serializersModule2, kTypeTypeOf2), templates), source.getCss());
                    }

/* 87 */            public static /* synthetic */ AnkiNoteEntity noteSnapshot$default(Companion companion, AnkiSourceNote ankiSourceNote, String str, String str2, String str3, int i, Object obj) {
/* 88 */                if ((i & 8) != 0) {
                            str3 = UUID.randomUUID().toString();
                            Intrinsics.checkNotNullExpressionValue(str3, "toString(...)");
                        }
                        return companion.noteSnapshot(ankiSourceNote, str, str2, str3);
                    }

/* 88 */            public final AnkiNoteEntity noteSnapshot(AnkiSourceNote source, String modelId, String namespace, String id) {
                        Intrinsics.checkNotNullParameter(source, "source");
                        Intrinsics.checkNotNullParameter(modelId, "modelId");
                        Intrinsics.checkNotNullParameter(namespace, "namespace");
                        Intrinsics.checkNotNullParameter(id, "id");
/* 89 */                AnkiStorageValidator.validateNote$default(AnkiStorageValidator.INSTANCE, source.getFields(), source.getTags(), CollectionsKt.listOf((Object[]) new String[]{id, source.getGuid(), modelId, namespace}), 0, 0, 24, null);
                        String guid = source.getGuid();
                        Json json = Json.INSTANCE;
                        List<String> fields = source.getFields();
/* 130 */               SerializersModule serializersModule = json.getSerializersModule();
                        KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(String.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
                        String strEncodeToString = json.encodeToString(SerializersKt.serializer(serializersModule, kTypeTypeOf), fields);
/* 90 */                Json json2 = Json.INSTANCE;
                        List<String> tags = source.getTags();
/* 130 */               SerializersModule serializersModule2 = json2.getSerializersModule();
                        KType kTypeTypeOf2 = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(String.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 90 */                return new AnkiNoteEntity(id, guid, modelId, strEncodeToString, json2.encodeToString(SerializersKt.serializer(serializersModule2, kTypeTypeOf2), tags), namespace, 0L);
                    }

                    /* JADX WARN: Code duplicated, block: B:19:0x0067  */
/* 92 */            public final List<String> validateNote(AnkiNoteEntity note) {
                        boolean z;
                        Intrinsics.checkNotNullParameter(note, "note");
/* 93 */                if (!(Intrinsics.areEqual(UUID.fromString(note.getId()).toString(), note.getId()) && Intrinsics.areEqual(UUID.fromString(note.getModelId()).toString(), note.getModelId()))) {
                            throw new IllegalArgumentException("Invalid local note/model UUID".toString());
                        }
/* 94 */                if ((note.getSourceGuid().length() > 0) && note.getRevision() >= 0) {
                            z = new Regex("[0-9a-f]{64}").matches(note.getMediaNamespace());
                        }
                        if (!z) {
                            throw new IllegalArgumentException("Invalid Anki note identity".toString());
                        }
/* 95 */                storedBytes(CollectionsKt.listOf((Object[]) new String[]{note.getId(), note.getSourceGuid(), note.getModelId(), note.getFields(), note.getTags(), note.getMediaNamespace()}));
/* 96 */                List<String> listStrings = strings(note.getFields());
/* 97 */                AnkiStorageValidator.validateNote$default(AnkiStorageValidator.INSTANCE, listStrings, strings(note.getTags()), CollectionsKt.listOf((Object[]) new String[]{note.getId(), note.getSourceGuid(), note.getModelId(), note.getMediaNamespace()}), 0, 0, 24, null);
/* 98 */                return listStrings;
                    }

                    /* JADX WARN: Code duplicated, block: B:7:0x0030  */
/* 100 */           public final int validateModel(AnkiModelEntity model) {
                        boolean z;
                        Intrinsics.checkNotNullParameter(model, "model");
/* 101 */               if (Intrinsics.areEqual(UUID.fromString(model.getId()).toString(), model.getId())) {
                            if (new Regex("[0-9a-f]{64}").matches(model.getContentHash())) {
                                z = true;
                            } else {
                                z = false;
                            }
                        } else {
                            z = false;
                        }
                        if (!z) {
                            throw new IllegalArgumentException("Invalid local model identity".toString());
                        }
/* 102 */               int bytes = storedBytes(CollectionsKt.listOf((Object[]) new String[]{model.getId(), model.getSourceModelId(), model.getContentHash(), model.getName(), model.getFieldNames(), model.getTemplates(), model.getCss()}));
/* 103 */               List<String> listStrings = strings(model.getFieldNames());
/* 104 */               Json json = Json.INSTANCE;
                        JsonElement jsonElement = BoundedJson.INSTANCE.parse(model.getTemplates());
/* 132 */               SerializersModule serializersModule = json.getSerializersModule();
                        KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 104 */               List templates = (List) json.decodeFromJsonElement(SerializersKt.serializer(serializersModule, kTypeTypeOf), jsonElement);
/* 105 */               AnkiStorageValidator.validateModel$default(AnkiStorageValidator.INSTANCE, listStrings, templates, CollectionsKt.listOf((Object[]) new String[]{model.getId(), model.getSourceModelId(), model.getContentHash(), model.getName(), model.getCss()}), 0, 8, null);
/* 106 */               AnkiModel source = new AnkiModel(Long.parseLong(model.getSourceModelId()), model.getName(), model.getKind(), listStrings, templates, model.getCss(), model.getOriginalStockKind());
/* 107 */               if (Intrinsics.areEqual(model.getContentHash(), contentHash(source))) {
/* 108 */                   return bytes;
                        }
                        throw new IllegalArgumentException("Model content digest differs".toString());
                    }

/* 109 */           public final List<String> strings(String json) {
                        Intrinsics.checkNotNullParameter(json, "json");
/* 110 */               Iterable<JsonElement> jsonArray = JsonElementKt.getJsonArray(BoundedJson.INSTANCE.parse(json));
/* 133 */               Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(jsonArray, 10));
                        for (JsonElement jsonElement : jsonArray) {
/* 111 */                   if (!JsonElementKt.getJsonPrimitive(jsonElement).isString()) {
                                throw new IllegalArgumentException("Expected stored string array".toString());
                            }
/* 135 */                   arrayList.add(JsonElementKt.getJsonPrimitive(jsonElement).getContent());
                        }
                        return (List) arrayList;
                    }

/* 113 */           private final int storedBytes(List<String> text) {
/* 114 */               Iterator<T> it = text.iterator();
                        long bytes = 0;
                        while (it.hasNext()) {
/* 114 */                   bytes += (long) AnkiStorageValidator.INSTANCE.utf8Bytes((String) it.next());
                        }
                        if (bytes <= 524288) {
/* 116 */                   return (int) bytes;
                        }
                        throw new IllegalArgumentException("Stored Anki text exceeds 512 KiB".toString());
                    }

/* 118 */           private final String contentHash(AnkiModel model) {
/* 137 */               JsonObjectBuilder jsonObjectBuilder = new JsonObjectBuilder();
/* 138 */               JsonElementBuildersKt.put(jsonObjectBuilder, HintConstants.AUTOFILL_HINT_NAME, model.getName());
/* 138 */               JsonElementBuildersKt.put(jsonObjectBuilder, "kind", Integer.valueOf(model.getKind()));
/* 138 */               JsonElementBuildersKt.put(jsonObjectBuilder, "originalStockKind", Integer.valueOf(model.getOriginalStockKind()));
/* 121 */               Json json = Json.INSTANCE;
                        List<String> fieldNames = model.getFieldNames();
/* 139 */               SerializersModule serializersModule = json.getSerializersModule();
                        KType kTypeTypeOf = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(String.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 138 */               jsonObjectBuilder.put("fieldNames", json.encodeToJsonElement(SerializersKt.serializer(serializersModule, kTypeTypeOf), fieldNames));
                        Json json2 = Json.INSTANCE;
                        List<AnkiTemplate> templates = model.getTemplates();
/* 139 */               SerializersModule serializersModule2 = json2.getSerializersModule();
                        KType kTypeTypeOf2 = Reflection.typeOf(List.class, KTypeProjection.INSTANCE.invariant(Reflection.typeOf(AnkiTemplate.class)));
                        MagicApiIntrinsics.voidMagicApiCall("kotlinx.serialization.serializer.withModule");
/* 138 */               jsonObjectBuilder.put("templates", json2.encodeToJsonElement(SerializersKt.serializer(serializersModule2, kTypeTypeOf2), templates));
/* 138 */               JsonElementBuildersKt.put(jsonObjectBuilder, "css", model.getCss());
/* 122 */               byte[] content = jsonObjectBuilder.build().toString().getBytes(Charsets.UTF_8);
                        Intrinsics.checkNotNullExpressionValue(content, "getBytes(...)");
/* 123 */               byte[] bArrDigest = MessageDigest.getInstance("SHA-256").digest(content);
                        Intrinsics.checkNotNullExpressionValue(bArrDigest, "digest(...)");
                        return ArraysKt.joinToString$default(bArrDigest, (CharSequence) "", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, new Function1() { // from class: com.xunji.flashcards.data.AnkiRepository$Companion$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return AnkiRepository.Companion.contentHash$lambda$1(((Byte) obj).byteValue());
                            }
                        }, 30, (Object) null);
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 122 */           public static final CharSequence contentHash$lambda$1(byte it) {
/* 123 */               String str = String.format("%02x", Arrays.copyOf(new Object[]{Byte.valueOf(it)}, 1));
                        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                        return str;
                    }
                }
            }

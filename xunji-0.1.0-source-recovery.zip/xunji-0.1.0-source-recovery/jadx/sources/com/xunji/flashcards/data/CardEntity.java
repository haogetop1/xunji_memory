            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B?\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\tHÆ\u0003J\t\u0010\u001c\u001a\u00020\tHÆ\u0003JO\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\tHÆ\u0001J\u0013\u0010\u001e\u001a\u00020\u001f2\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\"HÖ\u0001J\t\u0010#\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000eR\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\n\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0014¨\u0006$"}, d2 = {"Lcom/xunji/flashcards/data/CardEntity;", "", "id", "", "deckId", "front", "back", "example", "createdAt", "", "updatedAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V", "getId", "()Ljava/lang/String;", "getDeckId", "getFront", "getBack", "getExample", "getCreatedAt", "()J", "getUpdatedAt", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */     public final /* data */ class CardEntity {
                public static final int $stable = 0;
                private final String back;
                private final long createdAt;
                private final String deckId;
                private final String example;
                private final String front;
                private final String id;
                private final long updatedAt;

                public static /* synthetic */ CardEntity copy$default(CardEntity cardEntity, String str, String str2, String str3, String str4, String str5, long j, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = cardEntity.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = cardEntity.deckId;
                    }
                    if ((i & 4) != 0) {
                        str3 = cardEntity.front;
                    }
                    if ((i & 8) != 0) {
                        str4 = cardEntity.back;
                    }
                    if ((i & 16) != 0) {
                        str5 = cardEntity.example;
                    }
                    if ((i & 32) != 0) {
                        j = cardEntity.createdAt;
                    }
                    if ((i & 64) != 0) {
                        j2 = cardEntity.updatedAt;
                    }
                    long j3 = j2;
                    long j4 = j;
                    String str6 = str5;
                    String str7 = str3;
                    return cardEntity.copy(str, str2, str7, str4, str6, j4, j3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getDeckId() {
                    return this.deckId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getFront() {
                    return this.front;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getBack() {
                    return this.back;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getExample() {
                    return this.example;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getCreatedAt() {
                    return this.createdAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getUpdatedAt() {
                    return this.updatedAt;
                }

                public final CardEntity copy(String id, String deckId, String front, String back, String example, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
                    return new CardEntity(id, deckId, front, back, example, createdAt, updatedAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof CardEntity)) {
                        return false;
                    }
                    CardEntity cardEntity = (CardEntity) other;
                    return Intrinsics.areEqual(this.id, cardEntity.id) && Intrinsics.areEqual(this.deckId, cardEntity.deckId) && Intrinsics.areEqual(this.front, cardEntity.front) && Intrinsics.areEqual(this.back, cardEntity.back) && Intrinsics.areEqual(this.example, cardEntity.example) && this.createdAt == cardEntity.createdAt && this.updatedAt == cardEntity.updatedAt;
                }

                public int hashCode() {
                    return (((((((((((this.id.hashCode() * 31) + this.deckId.hashCode()) * 31) + this.front.hashCode()) * 31) + this.back.hashCode()) * 31) + this.example.hashCode()) * 31) + Long.hashCode(this.createdAt)) * 31) + Long.hashCode(this.updatedAt);
                }

                public String toString() {
                    return "CardEntity(id=" + this.id + ", deckId=" + this.deckId + ", front=" + this.front + ", back=" + this.back + ", example=" + this.example + ", createdAt=" + this.createdAt + ", updatedAt=" + this.updatedAt + ")";
                }

/* 7 */         public CardEntity(String id, String deckId, String front, String back, String example, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
/* 9 */             this.id = id;
                    this.deckId = deckId;
                    this.front = front;
                    this.back = back;
                    this.example = example;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

/* 8 */         public final String getBack() {
/* 9 */             return this.back;
                }

/* 8 */         public final long getCreatedAt() {
/* 9 */             return this.createdAt;
                }

/* 8 */         public final String getDeckId() {
/* 9 */             return this.deckId;
                }

/* 8 */         public final String getExample() {
/* 9 */             return this.example;
                }

/* 8 */         public final String getFront() {
/* 9 */             return this.front;
                }

/* 8 */         public final String getId() {
/* 9 */             return this.id;
                }

/* 8 */         public final long getUpdatedAt() {
/* 9 */             return this.updatedAt;
                }
            }

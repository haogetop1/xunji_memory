            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0007HÆ\u0003J'\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0017\u001a\u00020\u0018HÖ\u0001J\t\u0010\u0019\u001a\u00020\u001aHÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0016\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0016\u0010\u0006\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/data/CardRelations;", "", "card", "Lcom/xunji/flashcards/data/CardEntity;", "schedule", "Lcom/xunji/flashcards/data/ScheduleEntity;", "deck", "Lcom/xunji/flashcards/data/DeckEntity;", "<init>", "(Lcom/xunji/flashcards/data/CardEntity;Lcom/xunji/flashcards/data/ScheduleEntity;Lcom/xunji/flashcards/data/DeckEntity;)V", "getCard", "()Lcom/xunji/flashcards/data/CardEntity;", "getSchedule", "()Lcom/xunji/flashcards/data/ScheduleEntity;", "getDeck", "()Lcom/xunji/flashcards/data/DeckEntity;", "component1", "component2", "component3", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 21 */    public final /* data */ class CardRelations {
                public static final int $stable = 0;
                private final CardEntity card;
                private final DeckEntity deck;
                private final ScheduleEntity schedule;

                public static /* synthetic */ CardRelations copy$default(CardRelations cardRelations, CardEntity cardEntity, ScheduleEntity scheduleEntity, DeckEntity deckEntity, int i, Object obj) {
                    if ((i & 1) != 0) {
                        cardEntity = cardRelations.card;
                    }
                    if ((i & 2) != 0) {
                        scheduleEntity = cardRelations.schedule;
                    }
                    if ((i & 4) != 0) {
                        deckEntity = cardRelations.deck;
                    }
                    return cardRelations.copy(cardEntity, scheduleEntity, deckEntity);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final CardEntity getCard() {
                    return this.card;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final ScheduleEntity getSchedule() {
                    return this.schedule;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final DeckEntity getDeck() {
                    return this.deck;
                }

                public final CardRelations copy(CardEntity card, ScheduleEntity schedule, DeckEntity deck) {
                    Intrinsics.checkNotNullParameter(card, "card");
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(deck, "deck");
                    return new CardRelations(card, schedule, deck);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof CardRelations)) {
                        return false;
                    }
                    CardRelations cardRelations = (CardRelations) other;
                    return Intrinsics.areEqual(this.card, cardRelations.card) && Intrinsics.areEqual(this.schedule, cardRelations.schedule) && Intrinsics.areEqual(this.deck, cardRelations.deck);
                }

                public int hashCode() {
                    return (((this.card.hashCode() * 31) + this.schedule.hashCode()) * 31) + this.deck.hashCode();
                }

                public String toString() {
                    return "CardRelations(card=" + this.card + ", schedule=" + this.schedule + ", deck=" + this.deck + ")";
                }

/* 22 */        public CardRelations(CardEntity card, ScheduleEntity schedule, DeckEntity deck) {
                    Intrinsics.checkNotNullParameter(card, "card");
                    Intrinsics.checkNotNullParameter(schedule, "schedule");
                    Intrinsics.checkNotNullParameter(deck, "deck");
/* 24 */            this.card = card;
/* 25 */            this.schedule = schedule;
/* 26 */            this.deck = deck;
                }

/* 23 */        public final CardEntity getCard() {
/* 24 */            return this.card;
                }

/* 24 */        public final ScheduleEntity getSchedule() {
/* 25 */            return this.schedule;
                }

/* 25 */        public final DeckEntity getDeck() {
/* 26 */            return this.deck;
                }
            }

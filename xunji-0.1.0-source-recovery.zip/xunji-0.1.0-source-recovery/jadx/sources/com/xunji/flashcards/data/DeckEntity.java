            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B'\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0006HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u0006HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000e¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/data/DeckEntity;", "", "id", "", HintConstants.AUTOFILL_HINT_NAME, "createdAt", "", "updatedAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;JJ)V", "getId", "()Ljava/lang/String;", "getName", "getCreatedAt", "()J", "getUpdatedAt", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final /* data */ class DeckEntity {
                public static final int $stable = 0;
                private final long createdAt;
                private final String id;
                private final String name;
                private final long updatedAt;

                public static /* synthetic */ DeckEntity copy$default(DeckEntity deckEntity, String str, String str2, long j, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = deckEntity.id;
                    }
                    if ((i & 2) != 0) {
                        str2 = deckEntity.name;
                    }
                    if ((i & 4) != 0) {
                        j = deckEntity.createdAt;
                    }
                    if ((i & 8) != 0) {
                        j2 = deckEntity.updatedAt;
                    }
                    long j3 = j2;
                    return deckEntity.copy(str, str2, j, j3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getName() {
                    return this.name;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final long getCreatedAt() {
                    return this.createdAt;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final long getUpdatedAt() {
                    return this.updatedAt;
                }

                public final DeckEntity copy(String id, String name, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(name, "name");
                    return new DeckEntity(id, name, createdAt, updatedAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof DeckEntity)) {
                        return false;
                    }
                    DeckEntity deckEntity = (DeckEntity) other;
                    return Intrinsics.areEqual(this.id, deckEntity.id) && Intrinsics.areEqual(this.name, deckEntity.name) && this.createdAt == deckEntity.createdAt && this.updatedAt == deckEntity.updatedAt;
                }

                public int hashCode() {
                    return (((((this.id.hashCode() * 31) + this.name.hashCode()) * 31) + Long.hashCode(this.createdAt)) * 31) + Long.hashCode(this.updatedAt);
                }

                public String toString() {
                    return "DeckEntity(id=" + this.id + ", name=" + this.name + ", createdAt=" + this.createdAt + ", updatedAt=" + this.updatedAt + ")";
                }

/* 4 */         public DeckEntity(String id, String name, long createdAt, long updatedAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(name, "name");
/* 6 */             this.id = id;
                    this.name = name;
                    this.createdAt = createdAt;
                    this.updatedAt = updatedAt;
                }

/* 5 */         public final long getCreatedAt() {
/* 6 */             return this.createdAt;
                }

/* 5 */         public final String getId() {
/* 6 */             return this.id;
                }

/* 5 */         public final String getName() {
/* 6 */             return this.name;
                }

/* 5 */         public final long getUpdatedAt() {
/* 6 */             return this.updatedAt;
                }
            }

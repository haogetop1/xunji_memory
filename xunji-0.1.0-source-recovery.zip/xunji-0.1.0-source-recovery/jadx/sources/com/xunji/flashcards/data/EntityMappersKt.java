            package com.xunji.flashcards.data;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.Rating;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.model.ThemeMode;
            import com.xunji.core.serialization.ScheduleCodec;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: EntityMappers.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\u001a\n\u0010\u0000\u001a\u00020\u0001*\u00020\u0002\u001a\n\u0010\u0003\u001a\u00020\u0002*\u00020\u0001\u001a\n\u0010\u0000\u001a\u00020\u0004*\u00020\u0005\u001a\n\u0010\u0003\u001a\u00020\u0005*\u00020\u0004\u001a\n\u0010\u0000\u001a\u00020\u0006*\u00020\u0007\u001a\n\u0010\u0003\u001a\u00020\u0007*\u00020\u0006\u001a\n\u0010\u0000\u001a\u00020\b*\u00020\t\u001a\n\u0010\u0003\u001a\u00020\t*\u00020\b\u001a\n\u0010\u0000\u001a\u00020\n*\u00020\u000b\u001a\n\u0010\u0003\u001a\u00020\u000b*\u00020\n\u001a\n\u0010\u0000\u001a\u00020\f*\u00020\r¨\u0006\u000e"}, d2 = {"toModel", "Lcom/xunji/core/model/Deck;", "Lcom/xunji/flashcards/data/DeckEntity;", "toEntity", "Lcom/xunji/core/model/Flashcard;", "Lcom/xunji/flashcards/data/CardEntity;", "Lcom/xunji/core/model/CardSchedule;", "Lcom/xunji/flashcards/data/ScheduleEntity;", "Lcom/xunji/core/model/ReviewLog;", "Lcom/xunji/flashcards/data/ReviewLogEntity;", "Lcom/xunji/core/model/AppSettings;", "Lcom/xunji/flashcards/data/SettingsEntity;", "Lcom/xunji/core/model/CardCandidate;", "Lcom/xunji/flashcards/data/CardRelations;", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 4 */     public final class EntityMappersKt {
/* 5 */         public static final Deck toModel(DeckEntity $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 6 */             return new Deck($this$toModel.getId(), $this$toModel.getName(), $this$toModel.getCreatedAt(), $this$toModel.getUpdatedAt());
                }

/* 6 */         public static final DeckEntity toEntity(Deck $this$toEntity) {
                    Intrinsics.checkNotNullParameter($this$toEntity, "<this>");
/* 7 */             return new DeckEntity($this$toEntity.getId(), $this$toEntity.getName(), $this$toEntity.getCreatedAt(), $this$toEntity.getUpdatedAt());
                }

/* 7 */         public static final Flashcard toModel(CardEntity $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 8 */             return new Flashcard($this$toModel.getId(), $this$toModel.getDeckId(), $this$toModel.getFront(), $this$toModel.getBack(), $this$toModel.getExample(), $this$toModel.getCreatedAt(), $this$toModel.getUpdatedAt());
                }

/* 8 */         public static final CardEntity toEntity(Flashcard $this$toEntity) {
                    Intrinsics.checkNotNullParameter($this$toEntity, "<this>");
/* 9 */             return new CardEntity($this$toEntity.getId(), $this$toEntity.getDeckId(), $this$toEntity.getFront(), $this$toEntity.getBack(), $this$toEntity.getExample(), $this$toEntity.getCreatedAt(), $this$toEntity.getUpdatedAt());
                }

/* 9 */         public static final CardSchedule toModel(ScheduleEntity $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 10 */            return new CardSchedule($this$toModel.getCardId(), Phase.valueOf($this$toModel.getPhase()), $this$toModel.getStep(), $this$toModel.getStability(), $this$toModel.getDifficulty(), $this$toModel.getDueAt(), $this$toModel.getLastReviewAt(), $this$toModel.getFirstReviewedAt(), $this$toModel.getRevision());
                }

/* 10 */        public static final ScheduleEntity toEntity(CardSchedule $this$toEntity) {
                    Intrinsics.checkNotNullParameter($this$toEntity, "<this>");
/* 11 */            return new ScheduleEntity($this$toEntity.getCardId(), $this$toEntity.getPhase().name(), $this$toEntity.getStep(), $this$toEntity.getStability(), $this$toEntity.getDifficulty(), $this$toEntity.getDueAt(), $this$toEntity.getLastReviewAt(), $this$toEntity.getFirstReviewedAt(), $this$toEntity.getRevision());
                }

/* 11 */        public static final ReviewLog toModel(ReviewLogEntity $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 12 */            return new ReviewLog($this$toModel.getId(), $this$toModel.getCardId(), $this$toModel.getDeckId(), $this$toModel.getSessionId(), Rating.getEntries().get($this$toModel.getRating() - 1), $this$toModel.getReviewedAt(), $this$toModel.getDurationMs(), ScheduleCodec.INSTANCE.decode($this$toModel.getBeforeSchedule()), ScheduleCodec.INSTANCE.decode($this$toModel.getAfterSchedule()), $this$toModel.getUndoneAt());
                }

/* 12 */        public static final ReviewLogEntity toEntity(ReviewLog $this$toEntity) {
                    Intrinsics.checkNotNullParameter($this$toEntity, "<this>");
/* 13 */            return new ReviewLogEntity($this$toEntity.getId(), $this$toEntity.getCardId(), $this$toEntity.getDeckId(), $this$toEntity.getSessionId(), $this$toEntity.getRating().ordinal() + 1, $this$toEntity.getReviewedAt(), $this$toEntity.getDurationMs(), ScheduleCodec.INSTANCE.encode($this$toEntity.getBeforeSchedule()), ScheduleCodec.INSTANCE.encode($this$toEntity.getAfterSchedule()), $this$toEntity.getUndoneAt());
                }

/* 13 */        public static final AppSettings toModel(SettingsEntity $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 14 */            return new AppSettings($this$toModel.getNewCardsPerDay(), ThemeMode.valueOf($this$toModel.getThemeMode()), $this$toModel.getSchemaVersion());
                }

/* 14 */        public static final SettingsEntity toEntity(AppSettings $this$toEntity) {
                    Intrinsics.checkNotNullParameter($this$toEntity, "<this>");
/* 15 */            return new SettingsEntity(0, $this$toEntity.getNewCardsPerDay(), $this$toEntity.getThemeMode().name(), $this$toEntity.getSchemaVersion());
                }

/* 15 */        public static final CardCandidate toModel(CardRelations $this$toModel) {
                    Intrinsics.checkNotNullParameter($this$toModel, "<this>");
/* 16 */            return new CardCandidate(toModel($this$toModel.getCard()), toModel($this$toModel.getSchedule()), $this$toModel.getDeck().getName());
                }
            }

            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0002\b\"\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BY\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\b\u0012\u0006\u0010\t\u001a\u00020\n\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\f\u001a\u00020\u0003\u0012\u0006\u0010\r\u001a\u00020\u0003\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\t\u0010$\u001a\u00020\bHÆ\u0003J\t\u0010%\u001a\u00020\nHÆ\u0003J\t\u0010&\u001a\u00020\nHÆ\u0003J\t\u0010'\u001a\u00020\u0003HÆ\u0003J\t\u0010(\u001a\u00020\u0003HÆ\u0003J\u0010\u0010)\u001a\u0004\u0018\u00010\nHÆ\u0003¢\u0006\u0002\u0010\u001eJt\u0010*\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\b2\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\u00032\b\b\u0002\u0010\r\u001a\u00020\u00032\n\b\u0002\u0010\u000e\u001a\u0004\u0018\u00010\nHÆ\u0001¢\u0006\u0002\u0010+J\u0013\u0010,\u001a\u00020-2\b\u0010.\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010/\u001a\u00020\bHÖ\u0001J\t\u00100\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0012R\u0011\u0010\u0006\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012R\u0011\u0010\u0007\u001a\u00020\b¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\f\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0012R\u0011\u0010\r\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u0012R\u0015\u0010\u000e\u001a\u0004\u0018\u00010\n¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001e¨\u00061"}, d2 = {"Lcom/xunji/flashcards/data/ReviewLogEntity;", "", "id", "", "cardId", "deckId", "sessionId", "rating", "", "reviewedAt", "", "durationMs", "beforeSchedule", "afterSchedule", "undoneAt", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Long;)V", "getId", "()Ljava/lang/String;", "getCardId", "getDeckId", "getSessionId", "getRating", "()I", "getReviewedAt", "()J", "getDurationMs", "getBeforeSchedule", "getAfterSchedule", "getUndoneAt", "()Ljava/lang/Long;", "Ljava/lang/Long;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IJJLjava/lang/String;Ljava/lang/String;Ljava/lang/Long;)Lcom/xunji/flashcards/data/ReviewLogEntity;", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public final /* data */ class ReviewLogEntity {
                public static final int $stable = 0;
                private final String afterSchedule;
                private final String beforeSchedule;
                private final String cardId;
                private final String deckId;
                private final long durationMs;
                private final String id;
                private final int rating;
                private final long reviewedAt;
                private final String sessionId;
                private final Long undoneAt;

                public static /* synthetic */ ReviewLogEntity copy$default(ReviewLogEntity reviewLogEntity, String str, String str2, String str3, String str4, int i, long j, long j2, String str5, String str6, Long l, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        str = reviewLogEntity.id;
                    }
                    if ((i2 & 2) != 0) {
                        str2 = reviewLogEntity.cardId;
                    }
                    if ((i2 & 4) != 0) {
                        str3 = reviewLogEntity.deckId;
                    }
                    if ((i2 & 8) != 0) {
                        str4 = reviewLogEntity.sessionId;
                    }
                    if ((i2 & 16) != 0) {
                        i = reviewLogEntity.rating;
                    }
                    if ((i2 & 32) != 0) {
                        j = reviewLogEntity.reviewedAt;
                    }
                    if ((i2 & 64) != 0) {
                        j2 = reviewLogEntity.durationMs;
                    }
                    if ((i2 & 128) != 0) {
                        str5 = reviewLogEntity.beforeSchedule;
                    }
                    if ((i2 & 256) != 0) {
                        str6 = reviewLogEntity.afterSchedule;
                    }
                    if ((i2 & 512) != 0) {
                        l = reviewLogEntity.undoneAt;
                    }
                    Long l2 = l;
                    String str7 = str5;
                    long j3 = j2;
                    long j4 = j;
                    String str8 = str4;
                    int i3 = i;
                    String str9 = str3;
                    return reviewLogEntity.copy(str, str2, str9, str8, i3, j4, j3, str7, str6, l2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component10, reason: from getter */
                public final Long getUndoneAt() {
                    return this.undoneAt;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getDeckId() {
                    return this.deckId;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final String getSessionId() {
                    return this.sessionId;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final int getRating() {
                    return this.rating;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getReviewedAt() {
                    return this.reviewedAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final long getDurationMs() {
                    return this.durationMs;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final String getBeforeSchedule() {
                    return this.beforeSchedule;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final String getAfterSchedule() {
                    return this.afterSchedule;
                }

                public final ReviewLogEntity copy(String id, String cardId, String deckId, String sessionId, int rating, long reviewedAt, long durationMs, String beforeSchedule, String afterSchedule, Long undoneAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(beforeSchedule, "beforeSchedule");
                    Intrinsics.checkNotNullParameter(afterSchedule, "afterSchedule");
                    return new ReviewLogEntity(id, cardId, deckId, sessionId, rating, reviewedAt, durationMs, beforeSchedule, afterSchedule, undoneAt);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ReviewLogEntity)) {
                        return false;
                    }
                    ReviewLogEntity reviewLogEntity = (ReviewLogEntity) other;
                    return Intrinsics.areEqual(this.id, reviewLogEntity.id) && Intrinsics.areEqual(this.cardId, reviewLogEntity.cardId) && Intrinsics.areEqual(this.deckId, reviewLogEntity.deckId) && Intrinsics.areEqual(this.sessionId, reviewLogEntity.sessionId) && this.rating == reviewLogEntity.rating && this.reviewedAt == reviewLogEntity.reviewedAt && this.durationMs == reviewLogEntity.durationMs && Intrinsics.areEqual(this.beforeSchedule, reviewLogEntity.beforeSchedule) && Intrinsics.areEqual(this.afterSchedule, reviewLogEntity.afterSchedule) && Intrinsics.areEqual(this.undoneAt, reviewLogEntity.undoneAt);
                }

                public int hashCode() {
                    return (((((((((((((((((this.id.hashCode() * 31) + this.cardId.hashCode()) * 31) + this.deckId.hashCode()) * 31) + this.sessionId.hashCode()) * 31) + Integer.hashCode(this.rating)) * 31) + Long.hashCode(this.reviewedAt)) * 31) + Long.hashCode(this.durationMs)) * 31) + this.beforeSchedule.hashCode()) * 31) + this.afterSchedule.hashCode()) * 31) + (this.undoneAt == null ? 0 : this.undoneAt.hashCode());
                }

                public String toString() {
                    return "ReviewLogEntity(id=" + this.id + ", cardId=" + this.cardId + ", deckId=" + this.deckId + ", sessionId=" + this.sessionId + ", rating=" + this.rating + ", reviewedAt=" + this.reviewedAt + ", durationMs=" + this.durationMs + ", beforeSchedule=" + this.beforeSchedule + ", afterSchedule=" + this.afterSchedule + ", undoneAt=" + this.undoneAt + ")";
                }

/* 13 */        public ReviewLogEntity(String id, String cardId, String deckId, String sessionId, int rating, long reviewedAt, long durationMs, String beforeSchedule, String afterSchedule, Long undoneAt) {
                    Intrinsics.checkNotNullParameter(id, "id");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(beforeSchedule, "beforeSchedule");
                    Intrinsics.checkNotNullParameter(afterSchedule, "afterSchedule");
/* 18 */            this.id = id;
                    this.cardId = cardId;
                    this.deckId = deckId;
                    this.sessionId = sessionId;
                    this.rating = rating;
                    this.reviewedAt = reviewedAt;
                    this.durationMs = durationMs;
                    this.beforeSchedule = beforeSchedule;
                    this.afterSchedule = afterSchedule;
                    this.undoneAt = undoneAt;
                }

/* 17 */        public final String getAfterSchedule() {
/* 18 */            return this.afterSchedule;
                }

/* 17 */        public final String getBeforeSchedule() {
/* 18 */            return this.beforeSchedule;
                }

/* 17 */        public final String getCardId() {
/* 18 */            return this.cardId;
                }

/* 17 */        public final String getDeckId() {
/* 18 */            return this.deckId;
                }

/* 17 */        public final long getDurationMs() {
/* 18 */            return this.durationMs;
                }

/* 17 */        public final String getId() {
/* 18 */            return this.id;
                }

/* 17 */        public final int getRating() {
/* 18 */            return this.rating;
                }

/* 17 */        public final long getReviewedAt() {
/* 18 */            return this.reviewedAt;
                }

/* 17 */        public final String getSessionId() {
/* 18 */            return this.sessionId;
                }

/* 17 */        public final Long getUndoneAt() {
/* 18 */            return this.undoneAt;
                }
            }

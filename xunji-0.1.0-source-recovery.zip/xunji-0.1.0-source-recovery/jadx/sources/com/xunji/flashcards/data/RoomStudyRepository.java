            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import androidx.core.view.MotionEventCompat;
            import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
            import androidx.room.RoomDatabaseKt;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.model.ThemeMode;
            import com.xunji.core.validation.InputValidator;
            import java.time.Clock;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.UUID;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.flow.Flow;
            import kotlinx.coroutines.flow.FlowCollector;
            
            /* JADX INFO: compiled from: RoomStudyRepository.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\b\u0007\u0018\u00002\u00020\u0001B)\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005\u0012\u000e\b\u0002\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007¢\u0006\u0004\b\t\u0010\nJ\u0014\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u000f0\u000eH\u0016J\u0014\u0010\u0011\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u000f0\u000eH\u0016J\u001c\u0010\u0013\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00100\u000f0\u000e2\u0006\u0010\u0014\u001a\u00020\bH\u0016J\u0014\u0010\u0015\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00160\u000f0\u000eH\u0016J\u0014\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00180\u000f0\u000eH\u0016J\u000e\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u001a0\u000eH\u0016J\u001e\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00100\u000f2\b\u0010\u0014\u001a\u0004\u0018\u00010\bH\u0096@¢\u0006\u0002\u0010\u001cJ\u0016\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u001e\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u001cJ\u001e\u0010\u001f\u001a\u00020 2\u0006\u0010!\u001a\u00020\b2\u0006\u0010\u001e\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\"J\u0016\u0010#\u001a\u00020 2\u0006\u0010!\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u001cJ8\u0010$\u001a\u00020%2\b\u0010!\u001a\u0004\u0018\u00010\b2\u0006\u0010\u0014\u001a\u00020\b2\u0006\u0010&\u001a\u00020\b2\u0006\u0010'\u001a\u00020\b2\u0006\u0010(\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010)J\u0016\u0010*\u001a\u00020 2\u0006\u0010!\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u001cJ\u0016\u0010+\u001a\u00020 2\u0006\u0010,\u001a\u00020\u001aH\u0096@¢\u0006\u0002\u0010-R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006."}, d2 = {"Lcom/xunji/flashcards/data/RoomStudyRepository;", "Lcom/xunji/flashcards/data/StudyRepository;", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "clock", "Ljava/time/Clock;", "idFactory", "Lkotlin/Function0;", "", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;Ljava/time/Clock;Lkotlin/jvm/functions/Function0;)V", "dao", "Lcom/xunji/flashcards/data/XunjiDao;", "observeAllCards", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/xunji/core/model/CardCandidate;", "observeDecks", "Lcom/xunji/core/model/Deck;", "observeCards", "deckId", "observeSchedules", "Lcom/xunji/core/model/CardSchedule;", "observeLogs", "Lcom/xunji/core/model/ReviewLog;", "observeSettings", "Lcom/xunji/core/model/AppSettings;", "candidates", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "createDeck", HintConstants.AUTOFILL_HINT_NAME, "renameDeck", "", "id", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteDeck", "saveCard", "Lcom/xunji/core/model/Flashcard;", "front", "back", "example", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteCard", "saveSettings", "settings", "(Lcom/xunji/core/model/AppSettings;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */     public final class RoomStudyRepository implements StudyRepository {
                public static final int $stable = 8;
                private final Clock clock;
                private final XunjiDao dao;
                private final XunjiDatabase db;
                private final Function0<String> idFactory;

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$candidates$1, reason: invalid class name */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository", f = "RoomStudyRepository.kt", i = {0}, l = {18}, m = "candidates", n = {"deckId"}, s = {"L$0"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return RoomStudyRepository.this.candidates(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$createDeck$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository", f = "RoomStudyRepository.kt", i = {0, 0}, l = {21}, m = "createDeck", n = {HintConstants.AUTOFILL_HINT_NAME, "deck"}, s = {"L$0", "L$1"}, v = 1)
                static final class C04381 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    int label;
                    /* synthetic */ Object result;

                    C04381(Continuation<? super C04381> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return RoomStudyRepository.this.createDeck(null, this);
                    }
                }

/* 9 */         public RoomStudyRepository(XunjiDatabase db, Clock clock, Function0<String> idFactory) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    Intrinsics.checkNotNullParameter(idFactory, "idFactory");
                    this.db = db;
                    this.clock = clock;
                    this.idFactory = idFactory;
/* 11 */            this.dao = this.db.dao();
                }

                /* JADX WARN: Illegal instructions before constructor call */
/* 9 */         public /* synthetic */ RoomStudyRepository(XunjiDatabase xunjiDatabase, Clock clock, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
/* 10 */            if ((i & 2) != 0) {
                        clock = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clock, "systemUTC(...)");
                    }
                    this(xunjiDatabase, clock, (i & 4) != 0 ? new Function0() { // from class: com.xunji.flashcards.data.RoomStudyRepository$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return RoomStudyRepository._init_$lambda$0();
                        }
                    } : function0);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 9 */         public static final String _init_$lambda$0() {
/* 10 */            return UUID.randomUUID().toString();
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 11 */        public Flow<List<CardCandidate>> observeAllCards() {
/* 12 */            final Flow<List<CardRelations>> flowWatchCandidates = this.dao.watchCandidates(null);
/* 51 */            return (Flow) new Flow<List<? extends CardCandidate>>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeAllCards$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeAllCards$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 9 */                 public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeAllCards$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeAllCards$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 10 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
/* 51 */                                Iterable iterable = (List) value;
/* 52 */                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 53 */                                Iterator<T> it = iterable.iterator();
                                        while (it.hasNext()) {
/* 54 */                                    arrayList.add(EntityMappersKt.toModel((CardRelations) it.next()));
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit((List) arrayList, anonymousClass1) == coroutine_suspended) {
/* 11 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super List<? extends CardCandidate>> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 12 */        public Flow<List<Deck>> observeDecks() {
/* 13 */            final Flow<List<DeckEntity>> flowWatchDecks = this.dao.watchDecks();
/* 56 */            return (Flow) new Flow<List<? extends Deck>>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeDecks$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeDecks$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 10 */                public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeDecks$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeDecks$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 11 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
/* 51 */                                Iterable iterable = (List) value;
/* 52 */                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 53 */                                Iterator<T> it = iterable.iterator();
                                        while (it.hasNext()) {
/* 54 */                                    arrayList.add(EntityMappersKt.toModel((DeckEntity) it.next()));
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit((List) arrayList, anonymousClass1) == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super List<? extends Deck>> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 13 */        public Flow<List<CardCandidate>> observeCards(String deckId) {
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
/* 14 */            final Flow<List<CardRelations>> flowWatchCandidates = this.dao.watchCandidates(deckId);
/* 61 */            return (Flow) new Flow<List<? extends CardCandidate>>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeCards$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeCards$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 11 */                public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeCards$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeCards$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 12 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
/* 51 */                                Iterable iterable = (List) value;
/* 52 */                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 53 */                                Iterator<T> it = iterable.iterator();
                                        while (it.hasNext()) {
/* 54 */                                    arrayList.add(EntityMappersKt.toModel((CardRelations) it.next()));
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit((List) arrayList, anonymousClass1) == coroutine_suspended) {
/* 13 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super List<? extends CardCandidate>> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 14 */        public Flow<List<CardSchedule>> observeSchedules() {
/* 15 */            final Flow<List<ScheduleEntity>> flowWatchSchedules = this.dao.watchSchedules();
/* 66 */            return (Flow) new Flow<List<? extends CardSchedule>>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeSchedules$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeSchedules$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 12 */                public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeSchedules$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeSchedules$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 13 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
/* 51 */                                Iterable iterable = (List) value;
/* 52 */                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 53 */                                Iterator<T> it = iterable.iterator();
                                        while (it.hasNext()) {
/* 54 */                                    arrayList.add(EntityMappersKt.toModel((ScheduleEntity) it.next()));
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit((List) arrayList, anonymousClass1) == coroutine_suspended) {
/* 14 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super List<? extends CardSchedule>> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 15 */        public Flow<List<ReviewLog>> observeLogs() {
/* 16 */            final Flow<List<ReviewLogEntity>> flowWatchLogs = this.dao.watchLogs();
/* 71 */            return (Flow) new Flow<List<? extends ReviewLog>>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeLogs$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeLogs$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 13 */                public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeLogs$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeLogs$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 14 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
/* 51 */                                Iterable iterable = (List) value;
/* 52 */                                Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 53 */                                Iterator<T> it = iterable.iterator();
                                        while (it.hasNext()) {
/* 54 */                                    arrayList.add(EntityMappersKt.toModel((ReviewLogEntity) it.next()));
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit((List) arrayList, anonymousClass1) == coroutine_suspended) {
/* 15 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super List<? extends ReviewLog>> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 16 */        public Flow<AppSettings> observeSettings() {
/* 17 */            final Flow<SettingsEntity> flowWatchSettings = this.dao.watchSettings();
/* 76 */            return new Flow<AppSettings>() { // from class: com.xunji.flashcards.data.RoomStudyRepository$observeSettings$$inlined$map$1

                        /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeSettings$$inlined$map$1$2, reason: invalid class name */
                        /* JADX INFO: compiled from: Emitters.kt */
                        @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 14 */                public static final class AnonymousClass2<T> implements FlowCollector {
                            final /* synthetic */ FlowCollector $this_unsafeFlow;

                            /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$observeSettings$$inlined$map$1$2$1, reason: invalid class name */
                            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                            @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$observeSettings$$inlined$map$1$2", f = "RoomStudyRepository.kt", i = {0, 0, 0, 0, 0}, l = {AccessibilityNodeInfoCompat.MAX_NUMBER_OF_PREFETCHED_NODES}, m = "emit", n = {"value", "$completion", "value", "$this$map_u24lambda_u245", "$i$a$-unsafeTransform-FlowKt__TransformKt$map$1\\1\\49\\0"}, s = {"L$0", "L$1", "L$2", "L$3", "I$0"}, v = 1)
                            public static final class AnonymousClass1 extends ContinuationImpl {
                                int I$0;
                                Object L$0;
                                Object L$1;
                                Object L$2;
                                Object L$3;
                                int label;
                                /* synthetic */ Object result;

                                public AnonymousClass1(Continuation continuation) {
                                    super(continuation);
                                }

                                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                                public final Object invokeSuspend(Object obj) {
                                    this.result = obj;
                                    this.label |= Integer.MIN_VALUE;
                                    return AnonymousClass2.this.emit(null, this);
                                }
                            }

                            public AnonymousClass2(FlowCollector flowCollector) {
                                this.$this_unsafeFlow = flowCollector;
                            }

                            /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                            @Override // kotlinx.coroutines.flow.FlowCollector
/* 15 */                    public final Object emit(Object value, Continuation $completion) throws Throwable {
                                AnonymousClass1 anonymousClass1;
                                AppSettings appSettings;
                                if ($completion instanceof AnonymousClass1) {
                                    anonymousClass1 = (AnonymousClass1) $completion;
                                    if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                                        anonymousClass1.label -= Integer.MIN_VALUE;
                                    } else {
                                        anonymousClass1 = new AnonymousClass1($completion);
                                    }
                                } else {
                                    anonymousClass1 = new AnonymousClass1($completion);
                                }
                                Object $result = anonymousClass1.result;
                                Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                                switch (anonymousClass1.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
/* 49 */                                FlowCollector $this$map_u24lambda_u245 = this.$this_unsafeFlow;
                                        Continuation $completion2 = anonymousClass1;
                                        SettingsEntity settingsEntity = (SettingsEntity) value;
/* 51 */                                if (settingsEntity == null || (appSettings = EntityMappersKt.toModel(settingsEntity)) == null) {
                                            appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                        }
/* 50 */                                anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$1 = SpillingKt.nullOutSpilledVariable($completion2);
                                        anonymousClass1.L$2 = SpillingKt.nullOutSpilledVariable(value);
                                        anonymousClass1.L$3 = SpillingKt.nullOutSpilledVariable($this$map_u24lambda_u245);
                                        anonymousClass1.I$0 = 0;
                                        anonymousClass1.label = 1;
                                        if ($this$map_u24lambda_u245.emit(appSettings, anonymousClass1) == coroutine_suspended) {
/* 16 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        int i = anonymousClass1.I$0;
                                        Object obj = anonymousClass1.L$2;
                                        Object obj2 = anonymousClass1.L$0;
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 49 */                        return Unit.INSTANCE;
                            }
                        }

                        @Override // kotlinx.coroutines.flow.Flow
/* 106 */               public Object collect(FlowCollector<? super AppSettings> flowCollector, Continuation $completion) {
/* 107 */                   Object objCollect = collect(new AnonymousClass2(flowCollector), $completion);
                            return objCollect == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objCollect : Unit.INSTANCE;
                        }
                    };
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
                @Override // com.xunji.flashcards.data.StudyRepository
/* 17 */        public Object candidates(String deckId, Continuation<? super List<CardCandidate>> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    Object objCandidates;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            XunjiDao xunjiDao = this.dao;
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(deckId);
                            anonymousClass1.label = 1;
                            objCandidates = xunjiDao.candidates(deckId, anonymousClass1);
                            if (objCandidates == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            objCandidates = $result;
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    Iterable iterable = (Iterable) objCandidates;
/* 81 */            Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 82 */            Iterator it = iterable.iterator();
                    while (it.hasNext()) {
/* 83 */                arrayList.add(EntityMappersKt.toModel((CardRelations) it.next()));
                    }
                    return (List) arrayList;
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
                @Override // com.xunji.flashcards.data.StudyRepository
/* 18 */        public Object createDeck(String name, Continuation<? super Deck> continuation) throws Throwable {
                    C04381 c04381;
                    if (continuation instanceof C04381) {
                        c04381 = (C04381) continuation;
                        if ((c04381.label & Integer.MIN_VALUE) != 0) {
                            c04381.label -= Integer.MIN_VALUE;
                        } else {
                            c04381 = new C04381(continuation);
                        }
                    } else {
                        c04381 = new C04381(continuation);
                    }
                    Object $result = c04381.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04381.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 20 */                    Deck deck = new Deck(invoke(), InputValidator.INSTANCE.deckName(name), this.clock.millis(), this.clock.millis());
/* 21 */                    XunjiDao xunjiDao = this.dao;
                            DeckEntity entity = EntityMappersKt.toEntity(deck);
                            c04381.L$0 = SpillingKt.nullOutSpilledVariable(name);
                            c04381.L$1 = deck;
                            c04381.label = 1;
                            if (xunjiDao.insertDeck(entity, c04381) == coroutine_suspended) {
/* 19 */                        return coroutine_suspended;
                            }
/* 21 */                    return deck;
                        case 1:
                            Deck deck2 = (Deck) c04381.L$1;
                            ResultKt.throwOnFailure($result);
/* 22 */                    return deck2;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$renameDeck$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$renameDeck$2", f = "RoomStudyRepository.kt", i = {0, 1, 1}, l = {26, 27}, m = "invokeSuspend", n = {"validName", "validName", "deck"}, s = {"L$0", "L$0", "L$1"}, v = 1)
/* 22 */        static final class C04402 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ String $id;
                    final /* synthetic */ String $name;
                    Object L$0;
                    Object L$1;
                    int label;
                    final /* synthetic */ RoomStudyRepository this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04402(String str, RoomStudyRepository roomStudyRepository, String str2, Continuation<? super C04402> continuation) {
                        super(1, continuation);
                        this.$name = str;
                        this.this$0 = roomStudyRepository;
                        this.$id = str2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return new C04402(this.$name, this.this$0, this.$id, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04402) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:13:0x004d  */
                    /* JADX WARN: Code duplicated, block: B:15:0x0089 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:16:0x008a  */
                    /* JADX WARN: Code duplicated, block: B:19:0x008f  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 23 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objDeck;
                        String validName;
                        DeckEntity deck;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 25 */                        String validName2 = InputValidator.INSTANCE.deckName(this.$name);
                                this.L$0 = validName2;
                                this.label = 1;
/* 10 */                        objDeck = this.this$0.dao.deck(this.$id, this);
                                if (objDeck == coroutine_suspended) {
/* 24 */                            return coroutine_suspended;
                                }
/* 26 */                        validName = validName2;
                                if (objDeck != null) {
                                    throw new IllegalArgumentException("牌组已被删除".toString());
                                }
                                deck = (DeckEntity) objDeck;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(validName);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(deck);
                                this.label = 2;
/* 10 */                        if (this.this$0.dao.updateDeck(DeckEntity.copy$default(deck, null, validName, 0L, Math.max(this.this$0.clock.millis(), deck.getCreatedAt()), 5, null), this) == coroutine_suspended) {
/* 24 */                            return coroutine_suspended;
                                }
/* 28 */                        return Unit.INSTANCE;
                            case 1:
                                String validName3 = (String) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objDeck = $result;
                                validName = validName3;
                                if (objDeck != null) {
                                    throw new IllegalArgumentException("牌组已被删除".toString());
                                }
                                deck = (DeckEntity) objDeck;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(validName);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(deck);
                                this.label = 2;
/* 10 */                        if (this.this$0.dao.updateDeck(DeckEntity.copy$default(deck, null, validName, 0L, Math.max(this.this$0.clock.millis(), deck.getCreatedAt()), 5, null), this) == coroutine_suspended) {
/* 24 */                            return coroutine_suspended;
                                }
/* 28 */                        return Unit.INSTANCE;
                            case 2:
                                ResultKt.throwOnFailure($result);
/* 28 */                        return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 23 */        public Object renameDeck(String id, String name, Continuation<? super Unit> continuation) {
/* 24 */            Object objWithTransaction = RoomDatabaseKt.withTransaction(this.db, new C04402(name, this, id, null), continuation);
                    return objWithTransaction == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithTransaction : Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$deleteDeck$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$deleteDeck$2", f = "RoomStudyRepository.kt", i = {}, l = {29}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 27 */        static final class C04392 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ String $id;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04392(String str, Continuation<? super C04392> continuation) {
                        super(1, continuation);
                        this.$id = str;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return RoomStudyRepository.this.new C04392(this.$id, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04392) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 28 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 10 */                        if (RoomStudyRepository.this.dao.deleteDeck(this.$id, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$saveCard$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/core/model/Flashcard;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$saveCard$2", f = "RoomStudyRepository.kt", i = {2, 3, 3, 3, 4, 4, 4, 5, 5, 5}, l = {32, 33, MotionEventCompat.AXIS_GENERIC_3, MotionEventCompat.AXIS_GENERIC_8, MotionEventCompat.AXIS_GENERIC_9, MotionEventCompat.AXIS_GENERIC_10}, m = "invokeSuspend", n = {"previous", "previous", "card", "now", "previous", "card", "now", "previous", "card", "now"}, s = {"L$0", "L$0", "L$1", "J$0", "L$0", "L$1", "J$0", "L$0", "L$1", "J$0"}, v = 1)
/* 28 */        static final class C04412 extends SuspendLambda implements Function1<Continuation<? super Flashcard>, Object> {
                    final /* synthetic */ String $back;
                    final /* synthetic */ String $deckId;
                    final /* synthetic */ String $example;
                    final /* synthetic */ String $front;
                    final /* synthetic */ String $id;
                    long J$0;
                    Object L$0;
                    Object L$1;
                    int label;
                    final /* synthetic */ RoomStudyRepository this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04412(String str, String str2, String str3, RoomStudyRepository roomStudyRepository, String str4, String str5, Continuation<? super C04412> continuation) {
                        super(1, continuation);
                        this.$front = str;
                        this.$back = str2;
                        this.$example = str3;
                        this.this$0 = roomStudyRepository;
                        this.$deckId = str4;
                        this.$id = str5;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return new C04412(this.$front, this.$back, this.$example, this.this$0, this.$deckId, this.$id, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Flashcard> continuation) {
                        return ((C04412) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:16:0x0080  */
                    /* JADX WARN: Code duplicated, block: B:18:0x0084  */
                    /* JADX WARN: Code duplicated, block: B:20:0x0098 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:22:0x009b  */
                    /* JADX WARN: Code duplicated, block: B:23:0x009e  */
                    /* JADX WARN: Code duplicated, block: B:25:0x00ac  */
                    /* JADX WARN: Code duplicated, block: B:28:0x00b1  */
                    /* JADX WARN: Code duplicated, block: B:30:0x00cb A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:33:0x00cf  */
                    /* JADX WARN: Code duplicated, block: B:34:0x00d1 A[PHI: r2
                      0x00d1: PHI (r2v20 'previous' com.xunji.flashcards.data.CardEntity) = (r2v14 'previous' com.xunji.flashcards.data.CardEntity), (r2v22 'previous' com.xunji.flashcards.data.CardEntity) binds: [B:27:0x00af, B:31:0x00cc] A[DONT_GENERATE, DONT_INLINE]] */
                    /* JADX WARN: Code duplicated, block: B:36:0x00d4  */
                    /* JADX WARN: Code duplicated, block: B:37:0x00d6  */
                    /* JADX WARN: Code duplicated, block: B:39:0x00e2  */
                    /* JADX WARN: Code duplicated, block: B:41:0x00e5  */
                    /* JADX WARN: Code duplicated, block: B:43:0x00f5  */
                    /* JADX WARN: Code duplicated, block: B:46:0x010b  */
                    /* JADX WARN: Code duplicated, block: B:47:0x0110  */
                    /* JADX WARN: Code duplicated, block: B:49:0x0113  */
                    /* JADX WARN: Code duplicated, block: B:50:0x0118  */
                    /* JADX WARN: Code duplicated, block: B:53:0x0122  */
                    /* JADX WARN: Code duplicated, block: B:55:0x0142 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:56:0x0143  */
                    /* JADX WARN: Code duplicated, block: B:59:0x0179 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:60:0x017a  */
                    /* JADX WARN: Code duplicated, block: B:62:0x017c  */
                    /* JADX WARN: Code duplicated, block: B:64:0x019c A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:65:0x019d  */
                    /* JADX WARN: Code duplicated, block: B:68:0x01a5  */
                    /* JADX WARN: Code duplicated, block: B:70:0x01b3  */
                    /* JADX WARN: Code duplicated, block: B:72:0x01c1  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 29 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objDeck;
                        CardEntity previous;
                        Object objCard;
                        Object objLink;
                        boolean z;
                        long now;
                        Flashcard card;
                        String str;
                        long createdAt;
                        long createdAt2;
                        long now2;
                        Flashcard card2;
                        CardEntity previous2;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 31 */                        InputValidator.INSTANCE.cardContent(this.$front, this.$back, this.$example);
                                this.label = 1;
/* 10 */                        objDeck = this.this$0.dao.deck(this.$deckId, this);
                                if (objDeck == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
/* 32 */                        if (objDeck != null) {
                                    throw new IllegalArgumentException("牌组已被删除".toString());
                                }
/* 33 */                        if (this.$id != null) {
                                    this.label = 2;
/* 10 */                            objCard = this.this$0.dao.card(this.$id, this);
                                    if (objCard == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
/* 33 */                            if (objCard == null) {
                                        throw new IllegalArgumentException("卡片已被删除".toString());
                                    }
                                    previous = (CardEntity) objCard;
                                } else {
                                    previous = null;
                                }
/* 34 */                        if (this.$id != null) {
                                    this.L$0 = previous;
                                    this.label = 3;
/* 10 */                            objLink = this.this$0.db.ankiDao().link(this.$id, this);
                                    if (objLink == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
/* 34 */                            if (objLink == null) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                } else {
                                    z = true;
                                }
                                if (z) {
                                    throw new IllegalArgumentException("Anki 卡片请通过原始字段编辑".toString());
                                }
/* 35 */                        if (previous != null || Intrinsics.areEqual(previous.getDeckId(), this.$deckId)) {
                                    throw new IllegalArgumentException("卡片不属于此牌组".toString());
                                }
/* 10 */                        now = this.this$0.clock.millis();
                                str = this.$id;
                                if (str == null) {
/* 10 */                            str = (String) invoke();
                                }
                                String str2 = this.$deckId;
                                String str3 = this.$front;
                                String str4 = this.$back;
                                String str5 = this.$example;
                                if (previous != null) {
                                    createdAt = previous.getCreatedAt();
                                } else {
                                    createdAt = now;
                                }
                                if (previous != null) {
                                    createdAt2 = previous.getCreatedAt();
                                } else {
                                    createdAt2 = now;
                                }
/* 37 */                        card = new Flashcard(str, str2, str3, str4, str5, createdAt, Math.max(now, createdAt2));
/* 38 */                        if (previous == null) {
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                    this.L$1 = card;
                                    this.J$0 = now;
                                    this.label = 6;
/* 10 */                            if (this.this$0.dao.updateCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
                                    return card;
                                }
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                this.L$1 = card;
                                this.J$0 = now;
                                this.label = 4;
/* 10 */                        if (this.this$0.dao.insertCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
/* 39 */                        now2 = now;
                                card2 = card;
                                previous2 = previous;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous2);
                                this.L$1 = card2;
                                this.J$0 = now2;
                                this.label = 5;
/* 10 */                        if (this.this$0.dao.putSchedule(EntityMappersKt.toEntity(new CardSchedule(card2.getId(), Phase.NEW, null, null, null, now2, null, null, 0L)), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
                                return card2;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                objDeck = $result;
/* 32 */                        if (objDeck != null) {
                                    throw new IllegalArgumentException("牌组已被删除".toString());
                                }
/* 33 */                        if (this.$id != null) {
                                    this.label = 2;
/* 10 */                            objCard = this.this$0.dao.card(this.$id, this);
                                    if (objCard == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
/* 33 */                            if (objCard == null) {
                                        throw new IllegalArgumentException("卡片已被删除".toString());
                                    }
                                    previous = (CardEntity) objCard;
                                } else {
                                    previous = null;
                                }
/* 34 */                        if (this.$id != null) {
                                    this.L$0 = previous;
                                    this.label = 3;
/* 10 */                            objLink = this.this$0.db.ankiDao().link(this.$id, this);
                                    if (objLink == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
/* 34 */                            if (objLink == null) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                } else {
                                    z = true;
                                }
                                if (z) {
                                    throw new IllegalArgumentException("Anki 卡片请通过原始字段编辑".toString());
                                }
/* 35 */                        if (previous != null || Intrinsics.areEqual(previous.getDeckId(), this.$deckId)) {
                                    throw new IllegalArgumentException("卡片不属于此牌组".toString());
                                }
/* 10 */                        now = this.this$0.clock.millis();
                                str = this.$id;
                                if (str == null) {
/* 10 */                            str = (String) invoke();
                                }
                                String str6 = this.$deckId;
                                String str7 = this.$front;
                                String str8 = this.$back;
                                String str9 = this.$example;
                                if (previous != null) {
                                    createdAt = previous.getCreatedAt();
                                } else {
                                    createdAt = now;
                                }
                                if (previous != null) {
                                    createdAt2 = previous.getCreatedAt();
                                } else {
                                    createdAt2 = now;
                                }
/* 37 */                        card = new Flashcard(str, str6, str7, str8, str9, createdAt, Math.max(now, createdAt2));
/* 38 */                        if (previous == null) {
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                    this.L$1 = card;
                                    this.J$0 = now;
                                    this.label = 6;
/* 10 */                            if (this.this$0.dao.updateCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
                                    return card;
                                }
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                this.L$1 = card;
                                this.J$0 = now;
                                this.label = 4;
/* 10 */                        if (this.this$0.dao.insertCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
/* 39 */                        now2 = now;
                                card2 = card;
                                previous2 = previous;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous2);
                                this.L$1 = card2;
                                this.J$0 = now2;
                                this.label = 5;
/* 10 */                        if (this.this$0.dao.putSchedule(EntityMappersKt.toEntity(new CardSchedule(card2.getId(), Phase.NEW, null, null, null, now2, null, null, 0L)), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
                                return card2;
                            case 2:
                                ResultKt.throwOnFailure($result);
                                objCard = $result;
/* 33 */                        if (objCard == null) {
                                    throw new IllegalArgumentException("卡片已被删除".toString());
                                }
                                previous = (CardEntity) objCard;
/* 34 */                        if (this.$id != null) {
                                    this.L$0 = previous;
                                    this.label = 3;
/* 10 */                            objLink = this.this$0.db.ankiDao().link(this.$id, this);
                                    if (objLink == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
/* 34 */                            if (objLink == null) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                } else {
                                    z = true;
                                }
                                if (z) {
                                    throw new IllegalArgumentException("Anki 卡片请通过原始字段编辑".toString());
                                }
/* 35 */                        if (previous != null || Intrinsics.areEqual(previous.getDeckId(), this.$deckId)) {
                                    throw new IllegalArgumentException("卡片不属于此牌组".toString());
                                }
/* 10 */                        now = this.this$0.clock.millis();
                                str = this.$id;
                                if (str == null) {
/* 10 */                            str = (String) invoke();
                                }
                                String str10 = this.$deckId;
                                String str11 = this.$front;
                                String str12 = this.$back;
                                String str13 = this.$example;
                                if (previous != null) {
                                    createdAt = previous.getCreatedAt();
                                } else {
                                    createdAt = now;
                                }
                                if (previous != null) {
                                    createdAt2 = previous.getCreatedAt();
                                } else {
                                    createdAt2 = now;
                                }
/* 37 */                        card = new Flashcard(str, str10, str11, str12, str13, createdAt, Math.max(now, createdAt2));
/* 38 */                        if (previous == null) {
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                    this.L$1 = card;
                                    this.J$0 = now;
                                    this.label = 6;
/* 10 */                            if (this.this$0.dao.updateCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
                                    return card;
                                }
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                this.L$1 = card;
                                this.J$0 = now;
                                this.label = 4;
/* 10 */                        if (this.this$0.dao.insertCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
/* 39 */                        now2 = now;
                                card2 = card;
                                previous2 = previous;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous2);
                                this.L$1 = card2;
                                this.J$0 = now2;
                                this.label = 5;
/* 10 */                        if (this.this$0.dao.putSchedule(EntityMappersKt.toEntity(new CardSchedule(card2.getId(), Phase.NEW, null, null, null, now2, null, null, 0L)), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
                                return card2;
                            case 3:
                                previous = (CardEntity) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objLink = $result;
/* 34 */                        if (objLink == null) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                if (z) {
                                    throw new IllegalArgumentException("Anki 卡片请通过原始字段编辑".toString());
                                }
/* 35 */                        if (previous != null || Intrinsics.areEqual(previous.getDeckId(), this.$deckId)) {
                                    throw new IllegalArgumentException("卡片不属于此牌组".toString());
                                }
/* 10 */                        now = this.this$0.clock.millis();
                                str = this.$id;
                                if (str == null) {
/* 10 */                            str = (String) invoke();
                                }
                                String str14 = this.$deckId;
                                String str15 = this.$front;
                                String str16 = this.$back;
                                String str17 = this.$example;
                                if (previous != null) {
                                    createdAt = previous.getCreatedAt();
                                } else {
                                    createdAt = now;
                                }
                                if (previous != null) {
                                    createdAt2 = previous.getCreatedAt();
                                } else {
                                    createdAt2 = now;
                                }
/* 37 */                        card = new Flashcard(str, str14, str15, str16, str17, createdAt, Math.max(now, createdAt2));
/* 38 */                        if (previous == null) {
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                    this.L$1 = card;
                                    this.J$0 = now;
                                    this.label = 6;
/* 10 */                            if (this.this$0.dao.updateCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                                return coroutine_suspended;
                                    }
                                    return card;
                                }
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous);
                                this.L$1 = card;
                                this.J$0 = now;
                                this.label = 4;
/* 10 */                        if (this.this$0.dao.insertCard(EntityMappersKt.toEntity(card), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
/* 39 */                        now2 = now;
                                card2 = card;
                                previous2 = previous;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous2);
                                this.L$1 = card2;
                                this.J$0 = now2;
                                this.label = 5;
/* 10 */                        if (this.this$0.dao.putSchedule(EntityMappersKt.toEntity(new CardSchedule(card2.getId(), Phase.NEW, null, null, null, now2, null, null, 0L)), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
                                return card2;
                            case 4:
                                long now3 = this.J$0;
                                Flashcard card3 = (Flashcard) this.L$1;
                                CardEntity previous3 = (CardEntity) this.L$0;
                                ResultKt.throwOnFailure($result);
                                now2 = now3;
                                card2 = card3;
                                previous2 = previous3;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(previous2);
                                this.L$1 = card2;
                                this.J$0 = now2;
                                this.label = 5;
/* 10 */                        if (this.this$0.dao.putSchedule(EntityMappersKt.toEntity(new CardSchedule(card2.getId(), Phase.NEW, null, null, null, now2, null, null, 0L)), this) == coroutine_suspended) {
/* 30 */                            return coroutine_suspended;
                                }
                                return card2;
                            case 5:
                                long now4 = this.J$0;
                                Flashcard card4 = (Flashcard) this.L$1;
                                ResultKt.throwOnFailure($result);
                                return card4;
                            case 6:
                                long j = this.J$0;
                                Flashcard card5 = (Flashcard) this.L$1;
                                ResultKt.throwOnFailure($result);
                                return card5;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 28 */        public Object deleteDeck(String id, Continuation<? super Unit> continuation) {
/* 29 */            Object objWithTransaction = RoomDatabaseKt.withTransaction(this.db, new C04392(id, null), continuation);
                    return objWithTransaction == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithTransaction : Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 29 */        public Object saveCard(String id, String deckId, String front, String back, String example, Continuation<? super Flashcard> continuation) {
/* 30 */            return RoomDatabaseKt.withTransaction(this.db, new C04412(front, back, example, this, deckId, id, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.data.RoomStudyRepository$deleteCard$2, reason: invalid class name */
                /* JADX INFO: compiled from: RoomStudyRepository.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.data.RoomStudyRepository$deleteCard$2", f = "RoomStudyRepository.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_13}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 42 */        static final class AnonymousClass2 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ String $id;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(String str, Continuation<? super AnonymousClass2> continuation) {
                        super(1, continuation);
                        this.$id = str;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return RoomStudyRepository.this.new AnonymousClass2(this.$id, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((AnonymousClass2) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 43 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 10 */                        if (RoomStudyRepository.this.dao.deleteCard(this.$id, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 43 */        public Object deleteCard(String id, Continuation<? super Unit> continuation) {
/* 44 */            Object objWithTransaction = RoomDatabaseKt.withTransaction(this.db, new AnonymousClass2(id, null), continuation);
                    return objWithTransaction == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objWithTransaction : Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.StudyRepository
/* 45 */        public Object saveSettings(AppSettings settings, Continuation<? super Unit> continuation) {
/* 46 */            int newCardsPerDay = settings.getNewCardsPerDay();
                    if (!((newCardsPerDay >= 0 && newCardsPerDay < 101) && settings.getSchemaVersion() == 1)) {
                        throw new IllegalArgumentException("每天新卡数量应为 0～100".toString());
                    }
/* 47 */            Object objPutSettings = this.dao.putSettings(EntityMappersKt.toEntity(settings), continuation);
                    return objPutSettings == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPutSettings : Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0006\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\"\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001BY\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\b\u0010\t\u001a\u0004\u0018\u00010\b\u0012\u0006\u0010\n\u001a\u00020\u000b\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u000b\u0012\b\u0010\r\u001a\u0004\u0018\u00010\u000b\u0012\u0006\u0010\u000e\u001a\u00020\u000b¢\u0006\u0004\b\u000f\u0010\u0010J\t\u0010\"\u001a\u00020\u0003HÆ\u0003J\t\u0010#\u001a\u00020\u0003HÆ\u0003J\u0010\u0010$\u001a\u0004\u0018\u00010\u0006HÆ\u0003¢\u0006\u0002\u0010\u0015J\u0010\u0010%\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u0018J\u0010\u0010&\u001a\u0004\u0018\u00010\bHÆ\u0003¢\u0006\u0002\u0010\u0018J\t\u0010'\u001a\u00020\u000bHÆ\u0003J\u0010\u0010(\u001a\u0004\u0018\u00010\u000bHÆ\u0003¢\u0006\u0002\u0010\u001eJ\u0010\u0010)\u001a\u0004\u0018\u00010\u000bHÆ\u0003¢\u0006\u0002\u0010\u001eJ\t\u0010*\u001a\u00020\u000bHÆ\u0003Jr\u0010+\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\b2\b\b\u0002\u0010\n\u001a\u00020\u000b2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\u000b2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000b2\b\b\u0002\u0010\u000e\u001a\u00020\u000bHÆ\u0001¢\u0006\u0002\u0010,J\u0013\u0010-\u001a\u00020.2\b\u0010/\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00100\u001a\u00020\u0006HÖ\u0001J\t\u00101\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0012R\u0015\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\n\n\u0002\u0010\u0016\u001a\u0004\b\u0014\u0010\u0015R\u0015\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u0019\u001a\u0004\b\u0017\u0010\u0018R\u0015\u0010\t\u001a\u0004\u0018\u00010\b¢\u0006\n\n\u0002\u0010\u0019\u001a\u0004\b\u001a\u0010\u0018R\u0011\u0010\n\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0015\u0010\f\u001a\u0004\u0018\u00010\u000b¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b\u001d\u0010\u001eR\u0015\u0010\r\u001a\u0004\u0018\u00010\u000b¢\u0006\n\n\u0002\u0010\u001f\u001a\u0004\b \u0010\u001eR\u0011\u0010\u000e\u001a\u00020\u000b¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\u001c¨\u00062"}, d2 = {"Lcom/xunji/flashcards/data/ScheduleEntity;", "", "cardId", "", "phase", "step", "", "stability", "", "difficulty", "dueAt", "", "lastReviewAt", "firstReviewedAt", "revision", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;JLjava/lang/Long;Ljava/lang/Long;J)V", "getCardId", "()Ljava/lang/String;", "getPhase", "getStep", "()Ljava/lang/Integer;", "Ljava/lang/Integer;", "getStability", "()Ljava/lang/Double;", "Ljava/lang/Double;", "getDifficulty", "getDueAt", "()J", "getLastReviewAt", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getFirstReviewedAt", "getRevision", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Integer;Ljava/lang/Double;Ljava/lang/Double;JLjava/lang/Long;Ljava/lang/Long;J)Lcom/xunji/flashcards/data/ScheduleEntity;", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */     public final /* data */ class ScheduleEntity {
                public static final int $stable = 0;
                private final String cardId;
                private final Double difficulty;
                private final long dueAt;
                private final Long firstReviewedAt;
                private final Long lastReviewAt;
                private final String phase;
                private final long revision;
                private final Double stability;
                private final Integer step;

                public static /* synthetic */ ScheduleEntity copy$default(ScheduleEntity scheduleEntity, String str, String str2, Integer num, Double d, Double d2, long j, Long l, Long l2, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = scheduleEntity.cardId;
                    }
                    if ((i & 2) != 0) {
                        str2 = scheduleEntity.phase;
                    }
                    if ((i & 4) != 0) {
                        num = scheduleEntity.step;
                    }
                    if ((i & 8) != 0) {
                        d = scheduleEntity.stability;
                    }
                    if ((i & 16) != 0) {
                        d2 = scheduleEntity.difficulty;
                    }
                    if ((i & 32) != 0) {
                        j = scheduleEntity.dueAt;
                    }
                    if ((i & 64) != 0) {
                        l = scheduleEntity.lastReviewAt;
                    }
                    if ((i & 128) != 0) {
                        l2 = scheduleEntity.firstReviewedAt;
                    }
                    if ((i & 256) != 0) {
                        j2 = scheduleEntity.revision;
                    }
                    long j3 = j;
                    Double d3 = d;
                    Double d4 = d2;
                    Integer num2 = num;
                    return scheduleEntity.copy(str, str2, num2, d3, d4, j3, l, l2, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getPhase() {
                    return this.phase;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final Integer getStep() {
                    return this.step;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final Double getStability() {
                    return this.stability;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final Double getDifficulty() {
                    return this.difficulty;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getDueAt() {
                    return this.dueAt;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final Long getLastReviewAt() {
                    return this.lastReviewAt;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final Long getFirstReviewedAt() {
                    return this.firstReviewedAt;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final long getRevision() {
                    return this.revision;
                }

                public final ScheduleEntity copy(String cardId, String phase, Integer step, Double stability, Double difficulty, long dueAt, Long lastReviewAt, Long firstReviewedAt, long revision) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(phase, "phase");
                    return new ScheduleEntity(cardId, phase, step, stability, difficulty, dueAt, lastReviewAt, firstReviewedAt, revision);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ScheduleEntity)) {
                        return false;
                    }
                    ScheduleEntity scheduleEntity = (ScheduleEntity) other;
                    return Intrinsics.areEqual(this.cardId, scheduleEntity.cardId) && Intrinsics.areEqual(this.phase, scheduleEntity.phase) && Intrinsics.areEqual(this.step, scheduleEntity.step) && Intrinsics.areEqual((Object) this.stability, (Object) scheduleEntity.stability) && Intrinsics.areEqual((Object) this.difficulty, (Object) scheduleEntity.difficulty) && this.dueAt == scheduleEntity.dueAt && Intrinsics.areEqual(this.lastReviewAt, scheduleEntity.lastReviewAt) && Intrinsics.areEqual(this.firstReviewedAt, scheduleEntity.firstReviewedAt) && this.revision == scheduleEntity.revision;
                }

                public int hashCode() {
                    return (((((((((((((((this.cardId.hashCode() * 31) + this.phase.hashCode()) * 31) + (this.step == null ? 0 : this.step.hashCode())) * 31) + (this.stability == null ? 0 : this.stability.hashCode())) * 31) + (this.difficulty == null ? 0 : this.difficulty.hashCode())) * 31) + Long.hashCode(this.dueAt)) * 31) + (this.lastReviewAt == null ? 0 : this.lastReviewAt.hashCode())) * 31) + (this.firstReviewedAt != null ? this.firstReviewedAt.hashCode() : 0)) * 31) + Long.hashCode(this.revision);
                }

                public String toString() {
                    return "ScheduleEntity(cardId=" + this.cardId + ", phase=" + this.phase + ", step=" + this.step + ", stability=" + this.stability + ", difficulty=" + this.difficulty + ", dueAt=" + this.dueAt + ", lastReviewAt=" + this.lastReviewAt + ", firstReviewedAt=" + this.firstReviewedAt + ", revision=" + this.revision + ")";
                }

/* 10 */        public ScheduleEntity(String cardId, String phase, Integer step, Double stability, Double difficulty, long dueAt, Long lastReviewAt, Long firstReviewedAt, long revision) {
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(phase, "phase");
/* 12 */            this.cardId = cardId;
                    this.phase = phase;
                    this.step = step;
                    this.stability = stability;
                    this.difficulty = difficulty;
                    this.dueAt = dueAt;
                    this.lastReviewAt = lastReviewAt;
                    this.firstReviewedAt = firstReviewedAt;
                    this.revision = revision;
                }

/* 11 */        public final String getCardId() {
/* 12 */            return this.cardId;
                }

/* 11 */        public final Double getDifficulty() {
/* 12 */            return this.difficulty;
                }

/* 11 */        public final long getDueAt() {
/* 12 */            return this.dueAt;
                }

/* 11 */        public final Long getFirstReviewedAt() {
/* 12 */            return this.firstReviewedAt;
                }

/* 11 */        public final Long getLastReviewAt() {
/* 12 */            return this.lastReviewAt;
                }

/* 11 */        public final String getPhase() {
/* 12 */            return this.phase;
                }

/* 11 */        public final long getRevision() {
/* 12 */            return this.revision;
                }

/* 11 */        public final Double getStability() {
/* 12 */            return this.stability;
                }

/* 11 */        public final Integer getStep() {
/* 12 */            return this.step;
                }
            }

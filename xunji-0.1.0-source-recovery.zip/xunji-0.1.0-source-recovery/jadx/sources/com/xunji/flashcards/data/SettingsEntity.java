            package com.xunji.flashcards.data;

            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Entities.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000f\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0087\b\u0018\u00002\u00020\u0001B+\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0012\u001a\u00020\u0006HÆ\u0003J\t\u0010\u0013\u001a\u00020\u0003HÆ\u0003J1\u0010\u0014\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\u0015\u001a\u00020\u00162\b\u0010\u0017\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÖ\u0001J\t\u0010\u0019\u001a\u00020\u0006HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\u000bR\u0011\u0010\u0005\u001a\u00020\u0006¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000b¨\u0006\u001a"}, d2 = {"Lcom/xunji/flashcards/data/SettingsEntity;", "", "id", "", "newCardsPerDay", "themeMode", "", "schemaVersion", "<init>", "(IILjava/lang/String;I)V", "getId", "()I", "getNewCardsPerDay", "getThemeMode", "()Ljava/lang/String;", "getSchemaVersion", "component1", "component2", "component3", "component4", "copy", "equals", "", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 18 */    public final /* data */ class SettingsEntity {
                public static final int $stable = 0;
                private final int id;
                private final int newCardsPerDay;
                private final int schemaVersion;
                private final String themeMode;

                public static /* synthetic */ SettingsEntity copy$default(SettingsEntity settingsEntity, int i, int i2, String str, int i3, int i4, Object obj) {
                    if ((i4 & 1) != 0) {
                        i = settingsEntity.id;
                    }
                    if ((i4 & 2) != 0) {
                        i2 = settingsEntity.newCardsPerDay;
                    }
                    if ((i4 & 4) != 0) {
                        str = settingsEntity.themeMode;
                    }
                    if ((i4 & 8) != 0) {
                        i3 = settingsEntity.schemaVersion;
                    }
                    return settingsEntity.copy(i, i2, str, i3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final int getId() {
                    return this.id;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final int getNewCardsPerDay() {
                    return this.newCardsPerDay;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getThemeMode() {
                    return this.themeMode;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getSchemaVersion() {
                    return this.schemaVersion;
                }

                public final SettingsEntity copy(int id, int newCardsPerDay, String themeMode, int schemaVersion) {
                    Intrinsics.checkNotNullParameter(themeMode, "themeMode");
                    return new SettingsEntity(id, newCardsPerDay, themeMode, schemaVersion);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof SettingsEntity)) {
                        return false;
                    }
                    SettingsEntity settingsEntity = (SettingsEntity) other;
                    return this.id == settingsEntity.id && this.newCardsPerDay == settingsEntity.newCardsPerDay && Intrinsics.areEqual(this.themeMode, settingsEntity.themeMode) && this.schemaVersion == settingsEntity.schemaVersion;
                }

                public int hashCode() {
                    return (((((Integer.hashCode(this.id) * 31) + Integer.hashCode(this.newCardsPerDay)) * 31) + this.themeMode.hashCode()) * 31) + Integer.hashCode(this.schemaVersion);
                }

                public String toString() {
                    return "SettingsEntity(id=" + this.id + ", newCardsPerDay=" + this.newCardsPerDay + ", themeMode=" + this.themeMode + ", schemaVersion=" + this.schemaVersion + ")";
                }

/* 19 */        public SettingsEntity(int id, int newCardsPerDay, String themeMode, int schemaVersion) {
                    Intrinsics.checkNotNullParameter(themeMode, "themeMode");
/* 21 */            this.id = id;
                    this.newCardsPerDay = newCardsPerDay;
                    this.themeMode = themeMode;
                    this.schemaVersion = schemaVersion;
                }

/* 20 */        public final int getId() {
/* 21 */            return this.id;
                }

/* 20 */        public final int getNewCardsPerDay() {
/* 21 */            return this.newCardsPerDay;
                }

/* 20 */        public final int getSchemaVersion() {
/* 21 */            return this.schemaVersion;
                }

/* 20 */        public final String getThemeMode() {
/* 21 */            return this.themeMode;
                }
            }

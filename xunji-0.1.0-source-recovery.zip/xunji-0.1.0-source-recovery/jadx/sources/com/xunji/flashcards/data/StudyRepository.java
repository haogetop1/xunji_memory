            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.ReviewLog;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlinx.coroutines.flow.Flow;
            
            /* JADX INFO: compiled from: StudyRepository.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\n\bf\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H&J\u0014\u0010\u0006\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00040\u0003H&J\u001c\u0010\b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00070\u00040\u00032\u0006\u0010\t\u001a\u00020\nH&J\u0014\u0010\u000b\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0\u00040\u0003H&J\u0014\u0010\r\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\u00040\u0003H&J\u000e\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\u0003H&J\u0016\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u0012\u001a\u00020\nH¦@¢\u0006\u0002\u0010\u0013J\u001e\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\n2\u0006\u0010\u0012\u001a\u00020\nH¦@¢\u0006\u0002\u0010\u0017J\u0016\u0010\u0018\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\nH¦@¢\u0006\u0002\u0010\u0013J8\u0010\u0019\u001a\u00020\u001a2\b\u0010\u0016\u001a\u0004\u0018\u00010\n2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u001b\u001a\u00020\n2\u0006\u0010\u001c\u001a\u00020\n2\u0006\u0010\u001d\u001a\u00020\nH¦@¢\u0006\u0002\u0010\u001eJ\u0016\u0010\u001f\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\nH¦@¢\u0006\u0002\u0010\u0013J\u001e\u0010 \u001a\b\u0012\u0004\u0012\u00020\u00070\u00042\b\u0010\t\u001a\u0004\u0018\u00010\nH¦@¢\u0006\u0002\u0010\u0013J\u0016\u0010!\u001a\u00020\u00152\u0006\u0010\"\u001a\u00020\u0010H¦@¢\u0006\u0002\u0010#¨\u0006$À\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/data/StudyRepository;", "", "observeDecks", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/xunji/core/model/Deck;", "observeAllCards", "Lcom/xunji/core/model/CardCandidate;", "observeCards", "deckId", "", "observeSchedules", "Lcom/xunji/core/model/CardSchedule;", "observeLogs", "Lcom/xunji/core/model/ReviewLog;", "observeSettings", "Lcom/xunji/core/model/AppSettings;", "createDeck", HintConstants.AUTOFILL_HINT_NAME, "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "renameDeck", "", "id", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteDeck", "saveCard", "Lcom/xunji/core/model/Flashcard;", "front", "back", "example", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteCard", "candidates", "saveSettings", "settings", "(Lcom/xunji/core/model/AppSettings;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface StudyRepository {
                Object candidates(String str, Continuation<? super List<CardCandidate>> continuation);

                Object createDeck(String str, Continuation<? super Deck> continuation);

                Object deleteCard(String str, Continuation<? super Unit> continuation);

                Object deleteDeck(String str, Continuation<? super Unit> continuation);

                Flow<List<CardCandidate>> observeAllCards();

                Flow<List<CardCandidate>> observeCards(String deckId);

                Flow<List<Deck>> observeDecks();

                Flow<List<ReviewLog>> observeLogs();

                Flow<List<CardSchedule>> observeSchedules();

                Flow<AppSettings> observeSettings();

                Object renameDeck(String str, String str2, Continuation<? super Unit> continuation);

                Object saveCard(String str, String str2, String str3, String str4, String str5, Continuation<? super Flashcard> continuation);

                Object saveSettings(AppSettings appSettings, Continuation<? super Unit> continuation);
            }

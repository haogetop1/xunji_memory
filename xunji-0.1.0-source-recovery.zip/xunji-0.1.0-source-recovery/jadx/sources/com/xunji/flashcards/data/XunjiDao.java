            package com.xunji.flashcards.data;

            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlinx.coroutines.flow.Flow;
            
            /* JADX INFO: compiled from: XunjiDao.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\bg\u0018\u00002\u00020\u0001J\u0014\u0010\u0002\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u00040\u0003H'J\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004H§@¢\u0006\u0002\u0010\u0007J\u0018\u0010\b\u001a\u0004\u0018\u00010\u00052\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0016\u0010\f\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u000eJ\u0016\u0010\u000f\u001a\u00020\r2\u0006\u0010\b\u001a\u00020\u0005H§@¢\u0006\u0002\u0010\u000eJ\u0016\u0010\u0010\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u000e\u0010\u0011\u001a\u00020\rH§@¢\u0006\u0002\u0010\u0007J\u001e\u0010\u0012\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130\u00040\u00032\b\u0010\u0014\u001a\u0004\u0018\u00010\nH'J\u001e\u0010\u0015\u001a\b\u0012\u0004\u0012\u00020\u00130\u00042\b\u0010\u0014\u001a\u0004\u0018\u00010\nH§@¢\u0006\u0002\u0010\u000bJ\u0014\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u0004H§@¢\u0006\u0002\u0010\u0007J\u0018\u0010\u0018\u001a\u0004\u0018\u00010\u00172\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0016\u0010\u0019\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u0017H§@¢\u0006\u0002\u0010\u001aJ\u0016\u0010\u001b\u001a\u00020\r2\u0006\u0010\u0018\u001a\u00020\u0017H§@¢\u0006\u0002\u0010\u001aJ\u0016\u0010\u001c\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0014\u0010\u001d\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u001e0\u00040\u0003H'J\u0014\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001e0\u0004H§@¢\u0006\u0002\u0010\u0007J\u0018\u0010 \u001a\u0004\u0018\u00010\u001e2\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0016\u0010!\u001a\u00020\r2\u0006\u0010 \u001a\u00020\u001eH§@¢\u0006\u0002\u0010\"J\u0014\u0010#\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020$0\u00040\u0003H'J\u0014\u0010%\u001a\b\u0012\u0004\u0012\u00020$0\u0004H§@¢\u0006\u0002\u0010\u0007J\u0018\u0010&\u001a\u0004\u0018\u00010$2\u0006\u0010\t\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0016\u0010'\u001a\u00020\r2\u0006\u0010&\u001a\u00020$H§@¢\u0006\u0002\u0010(J\u0016\u0010)\u001a\u00020\r2\u0006\u0010&\u001a\u00020$H§@¢\u0006\u0002\u0010(J\u0018\u0010*\u001a\u0004\u0018\u00010$2\u0006\u0010+\u001a\u00020\nH§@¢\u0006\u0002\u0010\u000bJ\u0010\u0010,\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010-0\u0003H'J\u0010\u0010.\u001a\u0004\u0018\u00010-H§@¢\u0006\u0002\u0010\u0007J\u0016\u0010/\u001a\u00020\r2\u0006\u0010.\u001a\u00020-H§@¢\u0006\u0002\u00100¨\u00061À\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDao;", "", "watchDecks", "Lkotlinx/coroutines/flow/Flow;", "", "Lcom/xunji/flashcards/data/DeckEntity;", "decks", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deck", "id", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertDeck", "", "(Lcom/xunji/flashcards/data/DeckEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateDeck", "deleteDeck", "deleteAllDecks", "watchCandidates", "Lcom/xunji/flashcards/data/CardRelations;", "deckId", "candidates", "cards", "Lcom/xunji/flashcards/data/CardEntity;", "card", "insertCard", "(Lcom/xunji/flashcards/data/CardEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateCard", "deleteCard", "watchSchedules", "Lcom/xunji/flashcards/data/ScheduleEntity;", "schedules", "schedule", "putSchedule", "(Lcom/xunji/flashcards/data/ScheduleEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "watchLogs", "Lcom/xunji/flashcards/data/ReviewLogEntity;", "logs", "log", "insertLog", "(Lcom/xunji/flashcards/data/ReviewLogEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateLog", "latestSessionLog", "sessionId", "watchSettings", "Lcom/xunji/flashcards/data/SettingsEntity;", "settings", "putSettings", "(Lcom/xunji/flashcards/data/SettingsEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface XunjiDao {
                Object candidates(String str, Continuation<? super List<CardRelations>> continuation);

                Object card(String str, Continuation<? super CardEntity> continuation);

                Object cards(Continuation<? super List<CardEntity>> continuation);

                Object deck(String str, Continuation<? super DeckEntity> continuation);

                Object decks(Continuation<? super List<DeckEntity>> continuation);

                Object deleteAllDecks(Continuation<? super Unit> continuation);

                Object deleteCard(String str, Continuation<? super Unit> continuation);

                Object deleteDeck(String str, Continuation<? super Unit> continuation);

                Object insertCard(CardEntity cardEntity, Continuation<? super Unit> continuation);

                Object insertDeck(DeckEntity deckEntity, Continuation<? super Unit> continuation);

                Object insertLog(ReviewLogEntity reviewLogEntity, Continuation<? super Unit> continuation);

                Object latestSessionLog(String str, Continuation<? super ReviewLogEntity> continuation);

                Object log(String str, Continuation<? super ReviewLogEntity> continuation);

                Object logs(Continuation<? super List<ReviewLogEntity>> continuation);

                Object putSchedule(ScheduleEntity scheduleEntity, Continuation<? super Unit> continuation);

                Object putSettings(SettingsEntity settingsEntity, Continuation<? super Unit> continuation);

                Object schedule(String str, Continuation<? super ScheduleEntity> continuation);

                Object schedules(Continuation<? super List<ScheduleEntity>> continuation);

                Object settings(Continuation<? super SettingsEntity> continuation);

                Object updateCard(CardEntity cardEntity, Continuation<? super Unit> continuation);

                Object updateDeck(DeckEntity deckEntity, Continuation<? super Unit> continuation);

                Object updateLog(ReviewLogEntity reviewLogEntity, Continuation<? super Unit> continuation);

                Flow<List<CardRelations>> watchCandidates(String deckId);

                Flow<List<DeckEntity>> watchDecks();

                Flow<List<ReviewLogEntity>> watchLogs();

                Flow<List<ScheduleEntity>> watchSchedules();

                Flow<SettingsEntity> watchSettings();
            }

            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import androidx.collection.ArrayMap;
            import androidx.room.EntityDeleteOrUpdateAdapter;
            import androidx.room.EntityInsertAdapter;
            import androidx.room.EntityUpsertAdapter;
            import androidx.room.RoomDatabase;
            import androidx.room.coroutines.FlowUtil;
            import androidx.room.util.DBUtil;
            import androidx.room.util.RelationUtil;
            import androidx.room.util.SQLiteStatementUtil;
            import androidx.room.util.StringUtil;
            import androidx.sqlite.SQLiteConnection;
            import androidx.sqlite.SQLiteStatement;
            import java.util.ArrayList;
            import java.util.List;
            import java.util.Set;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.reflect.KClass;
            import kotlinx.coroutines.flow.Flow;
            
            /* JADX INFO: compiled from: XunjiDao_Impl.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u0000 F2\u00020\u0001:\u0001FB\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\u0016\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u0019J\u0016\u0010\u001a\u001a\u00020\u00172\u0006\u0010\u001b\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u001cJ\u0016\u0010\u001d\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\fH\u0096@¢\u0006\u0002\u0010\u001fJ\u0016\u0010 \u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\bH\u0096@¢\u0006\u0002\u0010\u0019J\u0016\u0010!\u001a\u00020\u00172\u0006\u0010\u001b\u001a\u00020\nH\u0096@¢\u0006\u0002\u0010\u001cJ\u0016\u0010\"\u001a\u00020\u00172\u0006\u0010\u001e\u001a\u00020\fH\u0096@¢\u0006\u0002\u0010\u001fJ\u0016\u0010#\u001a\u00020\u00172\u0006\u0010$\u001a\u00020\u0013H\u0096@¢\u0006\u0002\u0010%J\u0016\u0010&\u001a\u00020\u00172\u0006\u0010'\u001a\u00020\u0015H\u0096@¢\u0006\u0002\u0010(J\u0014\u0010)\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0+0*H\u0016J\u0014\u0010,\u001a\b\u0012\u0004\u0012\u00020\b0+H\u0096@¢\u0006\u0002\u0010-J\u0018\u0010\u0018\u001a\u0004\u0018\u00010\b2\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u001e\u00101\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u0002020+0*2\b\u00103\u001a\u0004\u0018\u00010/H\u0016J\u001e\u00104\u001a\b\u0012\u0004\u0012\u0002020+2\b\u00103\u001a\u0004\u0018\u00010/H\u0096@¢\u0006\u0002\u00100J\u0014\u00105\u001a\b\u0012\u0004\u0012\u00020\n0+H\u0096@¢\u0006\u0002\u0010-J\u0018\u0010\u001b\u001a\u0004\u0018\u00010\n2\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u0014\u00106\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00130+0*H\u0016J\u0014\u00107\u001a\b\u0012\u0004\u0012\u00020\u00130+H\u0096@¢\u0006\u0002\u0010-J\u0018\u0010$\u001a\u0004\u0018\u00010\u00132\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u0014\u00108\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\f0+0*H\u0016J\u0014\u00109\u001a\b\u0012\u0004\u0012\u00020\f0+H\u0096@¢\u0006\u0002\u0010-J\u0018\u0010\u001e\u001a\u0004\u0018\u00010\f2\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u0018\u0010:\u001a\u0004\u0018\u00010\f2\u0006\u0010;\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u0010\u0010<\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00150*H\u0016J\u0010\u0010'\u001a\u0004\u0018\u00010\u0015H\u0096@¢\u0006\u0002\u0010-J\u0016\u0010=\u001a\u00020\u00172\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J\u000e\u0010>\u001a\u00020\u0017H\u0096@¢\u0006\u0002\u0010-J\u0016\u0010?\u001a\u00020\u00172\u0006\u0010.\u001a\u00020/H\u0096@¢\u0006\u0002\u00100J&\u0010@\u001a\u00020\u00172\u0006\u0010A\u001a\u00020B2\u0014\u0010C\u001a\u0010\u0012\u0004\u0012\u00020/\u0012\u0006\u0012\u0004\u0018\u00010\u00130DH\u0002J&\u0010E\u001a\u00020\u00172\u0006\u0010A\u001a\u00020B2\u0014\u0010C\u001a\u0010\u0012\u0004\u0012\u00020/\u0012\u0006\u0012\u0004\u0018\u00010\b0DH\u0002R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\b0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\t\u001a\b\u0012\u0004\u0012\u00020\n0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\f0\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\b0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\n0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\f0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u00130\u0012X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00150\u0012X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006G"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDao_Impl;", "Lcom/xunji/flashcards/data/XunjiDao;", "__db", "Landroidx/room/RoomDatabase;", "<init>", "(Landroidx/room/RoomDatabase;)V", "__insertAdapterOfDeckEntity", "Landroidx/room/EntityInsertAdapter;", "Lcom/xunji/flashcards/data/DeckEntity;", "__insertAdapterOfCardEntity", "Lcom/xunji/flashcards/data/CardEntity;", "__insertAdapterOfReviewLogEntity", "Lcom/xunji/flashcards/data/ReviewLogEntity;", "__updateAdapterOfDeckEntity", "Landroidx/room/EntityDeleteOrUpdateAdapter;", "__updateAdapterOfCardEntity", "__updateAdapterOfReviewLogEntity", "__upsertAdapterOfScheduleEntity", "Landroidx/room/EntityUpsertAdapter;", "Lcom/xunji/flashcards/data/ScheduleEntity;", "__upsertAdapterOfSettingsEntity", "Lcom/xunji/flashcards/data/SettingsEntity;", "insertDeck", "", "deck", "(Lcom/xunji/flashcards/data/DeckEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertCard", "card", "(Lcom/xunji/flashcards/data/CardEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "insertLog", "log", "(Lcom/xunji/flashcards/data/ReviewLogEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "updateDeck", "updateCard", "updateLog", "putSchedule", "schedule", "(Lcom/xunji/flashcards/data/ScheduleEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "putSettings", "settings", "(Lcom/xunji/flashcards/data/SettingsEntity;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "watchDecks", "Lkotlinx/coroutines/flow/Flow;", "", "decks", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "id", "", "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "watchCandidates", "Lcom/xunji/flashcards/data/CardRelations;", "deckId", "candidates", "cards", "watchSchedules", "schedules", "watchLogs", "logs", "latestSessionLog", "sessionId", "watchSettings", "deleteDeck", "deleteAllDecks", "deleteCard", "__fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity", "_connection", "Landroidx/sqlite/SQLiteConnection;", "_map", "Landroidx/collection/ArrayMap;", "__fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 29 */    public final class XunjiDao_Impl implements XunjiDao {
                private final RoomDatabase __db;
                private final EntityInsertAdapter<CardEntity> __insertAdapterOfCardEntity;
                private final EntityInsertAdapter<DeckEntity> __insertAdapterOfDeckEntity;
                private final EntityInsertAdapter<ReviewLogEntity> __insertAdapterOfReviewLogEntity;
                private final EntityDeleteOrUpdateAdapter<CardEntity> __updateAdapterOfCardEntity;
                private final EntityDeleteOrUpdateAdapter<DeckEntity> __updateAdapterOfDeckEntity;
                private final EntityDeleteOrUpdateAdapter<ReviewLogEntity> __updateAdapterOfReviewLogEntity;
                private final EntityUpsertAdapter<ScheduleEntity> __upsertAdapterOfScheduleEntity;
                private final EntityUpsertAdapter<SettingsEntity> __upsertAdapterOfSettingsEntity;

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = 8;

/* 30 */        public XunjiDao_Impl(RoomDatabase __db) {
                    Intrinsics.checkNotNullParameter(__db, "__db");
/* 54 */            this.__db = __db;
/* 55 */            this.__insertAdapterOfDeckEntity = new EntityInsertAdapter<DeckEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.1
                        @Override // androidx.room.EntityInsertAdapter
/* 55 */                protected String createQuery() {
/* 56 */                    return "INSERT OR ABORT INTO `decks` (`id`,`name`,`createdAt`,`updatedAt`) VALUES (?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 58 */                public void bind(SQLiteStatement statement, DeckEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 59 */                    statement.mo8756bindText(1, entity.getId());
/* 60 */                    statement.mo8756bindText(2, entity.getName());
/* 61 */                    statement.mo8754bindLong(3, entity.getCreatedAt());
/* 62 */                    statement.mo8754bindLong(4, entity.getUpdatedAt());
                        }
                    };
/* 65 */            this.__insertAdapterOfCardEntity = new EntityInsertAdapter<CardEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.2
                        @Override // androidx.room.EntityInsertAdapter
/* 65 */                protected String createQuery() {
/* 66 */                    return "INSERT OR ABORT INTO `cards` (`id`,`deckId`,`front`,`back`,`example`,`createdAt`,`updatedAt`) VALUES (?,?,?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 68 */                public void bind(SQLiteStatement statement, CardEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 69 */                    statement.mo8756bindText(1, entity.getId());
/* 70 */                    statement.mo8756bindText(2, entity.getDeckId());
/* 71 */                    statement.mo8756bindText(3, entity.getFront());
/* 72 */                    statement.mo8756bindText(4, entity.getBack());
/* 73 */                    statement.mo8756bindText(5, entity.getExample());
/* 74 */                    statement.mo8754bindLong(6, entity.getCreatedAt());
/* 75 */                    statement.mo8754bindLong(7, entity.getUpdatedAt());
                        }
                    };
/* 78 */            this.__insertAdapterOfReviewLogEntity = new EntityInsertAdapter<ReviewLogEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.3
                        @Override // androidx.room.EntityInsertAdapter
/* 78 */                protected String createQuery() {
/* 79 */                    return "INSERT OR ABORT INTO `review_logs` (`id`,`cardId`,`deckId`,`sessionId`,`rating`,`reviewedAt`,`durationMs`,`beforeSchedule`,`afterSchedule`,`undoneAt`) VALUES (?,?,?,?,?,?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 81 */                public void bind(SQLiteStatement statement, ReviewLogEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 82 */                    statement.mo8756bindText(1, entity.getId());
/* 83 */                    statement.mo8756bindText(2, entity.getCardId());
/* 84 */                    statement.mo8756bindText(3, entity.getDeckId());
/* 85 */                    statement.mo8756bindText(4, entity.getSessionId());
/* 86 */                    statement.mo8754bindLong(5, entity.getRating());
/* 87 */                    statement.mo8754bindLong(6, entity.getReviewedAt());
/* 88 */                    statement.mo8754bindLong(7, entity.getDurationMs());
/* 89 */                    statement.mo8756bindText(8, entity.getBeforeSchedule());
/* 90 */                    statement.mo8756bindText(9, entity.getAfterSchedule());
/* 91 */                    Long _tmpUndoneAt = entity.getUndoneAt();
                            if (_tmpUndoneAt != null) {
/* 92 */                        statement.mo8754bindLong(10, _tmpUndoneAt.longValue());
                            } else {
/* 93 */                        statement.mo8755bindNull(10);
                            }
                        }
                    };
/* 99 */            this.__updateAdapterOfDeckEntity = new EntityDeleteOrUpdateAdapter<DeckEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.4
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 99 */                protected String createQuery() {
/* 100 */                   return "UPDATE OR ABORT `decks` SET `id` = ?,`name` = ?,`createdAt` = ?,`updatedAt` = ? WHERE `id` = ?";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 102 */               public void bind(SQLiteStatement statement, DeckEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 103 */                   statement.mo8756bindText(1, entity.getId());
/* 104 */                   statement.mo8756bindText(2, entity.getName());
/* 105 */                   statement.mo8754bindLong(3, entity.getCreatedAt());
/* 106 */                   statement.mo8754bindLong(4, entity.getUpdatedAt());
/* 107 */                   statement.mo8756bindText(5, entity.getId());
                        }
                    };
/* 110 */           this.__updateAdapterOfCardEntity = new EntityDeleteOrUpdateAdapter<CardEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.5
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 110 */               protected String createQuery() {
/* 111 */                   return "UPDATE OR ABORT `cards` SET `id` = ?,`deckId` = ?,`front` = ?,`back` = ?,`example` = ?,`createdAt` = ?,`updatedAt` = ? WHERE `id` = ?";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 113 */               public void bind(SQLiteStatement statement, CardEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 114 */                   statement.mo8756bindText(1, entity.getId());
/* 115 */                   statement.mo8756bindText(2, entity.getDeckId());
/* 116 */                   statement.mo8756bindText(3, entity.getFront());
/* 117 */                   statement.mo8756bindText(4, entity.getBack());
/* 118 */                   statement.mo8756bindText(5, entity.getExample());
/* 119 */                   statement.mo8754bindLong(6, entity.getCreatedAt());
/* 120 */                   statement.mo8754bindLong(7, entity.getUpdatedAt());
/* 121 */                   statement.mo8756bindText(8, entity.getId());
                        }
                    };
/* 124 */           this.__updateAdapterOfReviewLogEntity = new EntityDeleteOrUpdateAdapter<ReviewLogEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.6
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 124 */               protected String createQuery() {
/* 125 */                   return "UPDATE OR ABORT `review_logs` SET `id` = ?,`cardId` = ?,`deckId` = ?,`sessionId` = ?,`rating` = ?,`reviewedAt` = ?,`durationMs` = ?,`beforeSchedule` = ?,`afterSchedule` = ?,`undoneAt` = ? WHERE `id` = ?";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 127 */               public void bind(SQLiteStatement statement, ReviewLogEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 128 */                   statement.mo8756bindText(1, entity.getId());
/* 129 */                   statement.mo8756bindText(2, entity.getCardId());
/* 130 */                   statement.mo8756bindText(3, entity.getDeckId());
/* 131 */                   statement.mo8756bindText(4, entity.getSessionId());
/* 132 */                   statement.mo8754bindLong(5, entity.getRating());
/* 133 */                   statement.mo8754bindLong(6, entity.getReviewedAt());
/* 134 */                   statement.mo8754bindLong(7, entity.getDurationMs());
/* 135 */                   statement.mo8756bindText(8, entity.getBeforeSchedule());
/* 136 */                   statement.mo8756bindText(9, entity.getAfterSchedule());
/* 137 */                   Long _tmpUndoneAt = entity.getUndoneAt();
                            if (_tmpUndoneAt != null) {
/* 138 */                       statement.mo8754bindLong(10, _tmpUndoneAt.longValue());
                            } else {
/* 139 */                       statement.mo8755bindNull(10);
                            }
/* 143 */                   statement.mo8756bindText(11, entity.getId());
                        }
                    };
/* 146 */           this.__upsertAdapterOfScheduleEntity = new EntityUpsertAdapter<>(new EntityInsertAdapter<ScheduleEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.7
                        @Override // androidx.room.EntityInsertAdapter
/* 146 */               protected String createQuery() {
/* 147 */                   return "INSERT INTO `schedules` (`cardId`,`phase`,`step`,`stability`,`difficulty`,`dueAt`,`lastReviewAt`,`firstReviewedAt`,`revision`) VALUES (?,?,?,?,?,?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 149 */               public void bind(SQLiteStatement statement, ScheduleEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 150 */                   statement.mo8756bindText(1, entity.getCardId());
/* 151 */                   statement.mo8756bindText(2, entity.getPhase());
/* 152 */                   Integer _tmpStep = entity.getStep();
                            if (_tmpStep != null) {
/* 153 */                       statement.mo8754bindLong(3, _tmpStep.intValue());
                            } else {
/* 154 */                       statement.mo8755bindNull(3);
                            }
/* 158 */                   Double _tmpStability = entity.getStability();
                            if (_tmpStability != null) {
/* 159 */                       statement.mo8753bindDouble(4, _tmpStability.doubleValue());
                            } else {
/* 160 */                       statement.mo8755bindNull(4);
                            }
/* 164 */                   Double _tmpDifficulty = entity.getDifficulty();
                            if (_tmpDifficulty != null) {
/* 165 */                       statement.mo8753bindDouble(5, _tmpDifficulty.doubleValue());
                            } else {
/* 166 */                       statement.mo8755bindNull(5);
                            }
/* 170 */                   statement.mo8754bindLong(6, entity.getDueAt());
/* 171 */                   Long _tmpLastReviewAt = entity.getLastReviewAt();
                            if (_tmpLastReviewAt != null) {
/* 172 */                       statement.mo8754bindLong(7, _tmpLastReviewAt.longValue());
                            } else {
/* 173 */                       statement.mo8755bindNull(7);
                            }
/* 177 */                   Long _tmpFirstReviewedAt = entity.getFirstReviewedAt();
                            if (_tmpFirstReviewedAt != null) {
/* 178 */                       statement.mo8754bindLong(8, _tmpFirstReviewedAt.longValue());
                            } else {
/* 179 */                       statement.mo8755bindNull(8);
                            }
/* 183 */                   statement.mo8754bindLong(9, entity.getRevision());
                        }
                    }, new EntityDeleteOrUpdateAdapter<ScheduleEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.8
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 185 */               protected String createQuery() {
/* 186 */                   return "UPDATE `schedules` SET `cardId` = ?,`phase` = ?,`step` = ?,`stability` = ?,`difficulty` = ?,`dueAt` = ?,`lastReviewAt` = ?,`firstReviewedAt` = ?,`revision` = ? WHERE `cardId` = ?";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 188 */               public void bind(SQLiteStatement statement, ScheduleEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 189 */                   statement.mo8756bindText(1, entity.getCardId());
/* 190 */                   statement.mo8756bindText(2, entity.getPhase());
/* 191 */                   Integer _tmpStep = entity.getStep();
                            if (_tmpStep != null) {
/* 192 */                       statement.mo8754bindLong(3, _tmpStep.intValue());
                            } else {
/* 193 */                       statement.mo8755bindNull(3);
                            }
/* 197 */                   Double _tmpStability = entity.getStability();
                            if (_tmpStability != null) {
/* 198 */                       statement.mo8753bindDouble(4, _tmpStability.doubleValue());
                            } else {
/* 199 */                       statement.mo8755bindNull(4);
                            }
/* 203 */                   Double _tmpDifficulty = entity.getDifficulty();
                            if (_tmpDifficulty != null) {
/* 204 */                       statement.mo8753bindDouble(5, _tmpDifficulty.doubleValue());
                            } else {
/* 205 */                       statement.mo8755bindNull(5);
                            }
/* 209 */                   statement.mo8754bindLong(6, entity.getDueAt());
/* 210 */                   Long _tmpLastReviewAt = entity.getLastReviewAt();
                            if (_tmpLastReviewAt != null) {
/* 211 */                       statement.mo8754bindLong(7, _tmpLastReviewAt.longValue());
                            } else {
/* 212 */                       statement.mo8755bindNull(7);
                            }
/* 216 */                   Long _tmpFirstReviewedAt = entity.getFirstReviewedAt();
                            if (_tmpFirstReviewedAt != null) {
/* 217 */                       statement.mo8754bindLong(8, _tmpFirstReviewedAt.longValue());
                            } else {
/* 218 */                       statement.mo8755bindNull(8);
                            }
/* 222 */                   statement.mo8754bindLong(9, entity.getRevision());
/* 223 */                   statement.mo8756bindText(10, entity.getCardId());
                        }
                    });
/* 226 */           this.__upsertAdapterOfSettingsEntity = new EntityUpsertAdapter<>(new EntityInsertAdapter<SettingsEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.9
                        @Override // androidx.room.EntityInsertAdapter
/* 226 */               protected String createQuery() {
/* 227 */                   return "INSERT INTO `settings` (`id`,`newCardsPerDay`,`themeMode`,`schemaVersion`) VALUES (?,?,?,?)";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityInsertAdapter
/* 229 */               public void bind(SQLiteStatement statement, SettingsEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 230 */                   statement.mo8754bindLong(1, entity.getId());
/* 231 */                   statement.mo8754bindLong(2, entity.getNewCardsPerDay());
/* 232 */                   statement.mo8756bindText(3, entity.getThemeMode());
/* 233 */                   statement.mo8754bindLong(4, entity.getSchemaVersion());
                        }
                    }, new EntityDeleteOrUpdateAdapter<SettingsEntity>() { // from class: com.xunji.flashcards.data.XunjiDao_Impl.10
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 235 */               protected String createQuery() {
/* 236 */                   return "UPDATE `settings` SET `id` = ?,`newCardsPerDay` = ?,`themeMode` = ?,`schemaVersion` = ? WHERE `id` = ?";
                        }

                        /* JADX INFO: Access modifiers changed from: protected */
                        @Override // androidx.room.EntityDeleteOrUpdateAdapter
/* 238 */               public void bind(SQLiteStatement statement, SettingsEntity entity) {
                            Intrinsics.checkNotNullParameter(statement, "statement");
                            Intrinsics.checkNotNullParameter(entity, "entity");
/* 239 */                   statement.mo8754bindLong(1, entity.getId());
/* 240 */                   statement.mo8754bindLong(2, entity.getNewCardsPerDay());
/* 241 */                   statement.mo8756bindText(3, entity.getThemeMode());
/* 242 */                   statement.mo8754bindLong(4, entity.getSchemaVersion());
/* 243 */                   statement.mo8754bindLong(5, entity.getId());
                        }
                    });
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 247 */       public Object insertDeck(final DeckEntity deck, Continuation<? super Unit> continuation) {
/* 248 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.insertDeck$lambda$0(this.f$0, deck, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 248 */       public static final Unit insertDeck$lambda$0(XunjiDao_Impl this$0, DeckEntity $deck, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 249 */           this$0.__insertAdapterOfDeckEntity.insert(_connection, $deck);
/* 250 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 251 */       public Object insertCard(final CardEntity card, Continuation<? super Unit> continuation) {
/* 252 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda24
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.insertCard$lambda$0(this.f$0, card, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 252 */       public static final Unit insertCard$lambda$0(XunjiDao_Impl this$0, CardEntity $card, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 253 */           this$0.__insertAdapterOfCardEntity.insert(_connection, $card);
/* 254 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 255 */       public Object insertLog(final ReviewLogEntity log, Continuation<? super Unit> continuation) {
/* 256 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda3
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.insertLog$lambda$0(this.f$0, log, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 256 */       public static final Unit insertLog$lambda$0(XunjiDao_Impl this$0, ReviewLogEntity $log, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 257 */           this$0.__insertAdapterOfReviewLogEntity.insert(_connection, $log);
/* 258 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 259 */       public Object updateDeck(final DeckEntity deck, Continuation<? super Unit> continuation) {
/* 260 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda2
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.updateDeck$lambda$0(this.f$0, deck, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 260 */       public static final Unit updateDeck$lambda$0(XunjiDao_Impl this$0, DeckEntity $deck, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 261 */           this$0.__updateAdapterOfDeckEntity.handle(_connection, $deck);
/* 262 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 263 */       public Object updateCard(final CardEntity card, Continuation<? super Unit> continuation) {
/* 264 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda11
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.updateCard$lambda$0(this.f$0, card, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 264 */       public static final Unit updateCard$lambda$0(XunjiDao_Impl this$0, CardEntity $card, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 265 */           this$0.__updateAdapterOfCardEntity.handle(_connection, $card);
/* 266 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 267 */       public Object updateLog(final ReviewLogEntity log, Continuation<? super Unit> continuation) {
/* 268 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda28
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.updateLog$lambda$0(this.f$0, log, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 268 */       public static final Unit updateLog$lambda$0(XunjiDao_Impl this$0, ReviewLogEntity $log, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 269 */           this$0.__updateAdapterOfReviewLogEntity.handle(_connection, $log);
/* 270 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 271 */       public Object putSchedule(final ScheduleEntity schedule, Continuation<? super Unit> continuation) {
/* 272 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.putSchedule$lambda$0(this.f$0, schedule, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 272 */       public static final Unit putSchedule$lambda$0(XunjiDao_Impl this$0, ScheduleEntity $schedule, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 273 */           this$0.__upsertAdapterOfScheduleEntity.upsert(_connection, $schedule);
/* 274 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 275 */       public Object putSettings(final SettingsEntity settings, Continuation<? super Unit> continuation) {
/* 276 */           Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.putSettings$lambda$0(this.f$0, settings, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 276 */       public static final Unit putSettings$lambda$0(XunjiDao_Impl this$0, SettingsEntity $settings, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 277 */           this$0.__upsertAdapterOfSettingsEntity.upsert(_connection, $settings);
/* 278 */           return Unit.INSTANCE;
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 280 */       public Flow<List<DeckEntity>> watchDecks() {
/* 281 */           final String _sql = "SELECT * FROM decks ORDER BY createdAt, id";
/* 282 */           return FlowUtil.createFlow(this.__db, false, new String[]{"decks"}, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.watchDecks$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 282 */       public static final List watchDecks$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 283 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 285 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 286 */               int _columnIndexOfName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, HintConstants.AUTOFILL_HINT_NAME);
/* 287 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 288 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 289 */               List _result = new ArrayList();
/* 290 */               while (_stmt.step()) {
/* 293 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 295 */                   String _tmpName = _stmt.getText(_columnIndexOfName);
/* 297 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 299 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 300 */                   DeckEntity _item = new DeckEntity(_tmpId, _tmpName, _tmpCreatedAt, _tmpUpdatedAt);
/* 301 */                   _result.add(_item);
                        }
/* 305 */               _stmt.close();
/* 306 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 310 */       public Object decks(Continuation<? super List<DeckEntity>> continuation) {
/* 311 */           final String _sql = "SELECT * FROM decks ORDER BY createdAt, id";
/* 312 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.decks$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 312 */       public static final List decks$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 313 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 315 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 316 */               int _columnIndexOfName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, HintConstants.AUTOFILL_HINT_NAME);
/* 317 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 318 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 319 */               List _result = new ArrayList();
/* 320 */               while (_stmt.step()) {
/* 323 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 325 */                   String _tmpName = _stmt.getText(_columnIndexOfName);
/* 327 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 329 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 330 */                   DeckEntity _item = new DeckEntity(_tmpId, _tmpName, _tmpCreatedAt, _tmpUpdatedAt);
/* 331 */                   _result.add(_item);
                        }
/* 335 */               _stmt.close();
/* 336 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 340 */       public Object deck(final String id, Continuation<? super DeckEntity> continuation) {
/* 341 */           final String _sql = "SELECT * FROM decks WHERE id=?";
/* 342 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda14
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.deck$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 342 */       public static final DeckEntity deck$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    DeckEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 343 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 346 */               _stmt.mo8756bindText(1, $id);
/* 347 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 348 */               int _columnIndexOfName = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, HintConstants.AUTOFILL_HINT_NAME);
/* 349 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 350 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 352 */               if (_stmt.step()) {
/* 354 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 356 */                   String _tmpName = _stmt.getText(_columnIndexOfName);
/* 358 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 360 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 361 */                   _result = new DeckEntity(_tmpId, _tmpName, _tmpCreatedAt, _tmpUpdatedAt);
                        } else {
/* 363 */                   _result = null;
                        }
/* 368 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 372 */       public Flow<List<CardRelations>> watchCandidates(final String deckId) {
/* 373 */           final String _sql = "SELECT * FROM cards WHERE (? IS NULL OR deckId=?) ORDER BY createdAt,id";
/* 374 */           return FlowUtil.createFlow(this.__db, true, new String[]{"schedules", "decks", "cards"}, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.watchCandidates$lambda$0(_sql, deckId, this, (SQLiteConnection) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 374 */       public static final List watchCandidates$lambda$0(String $_sql, String $deckId, XunjiDao_Impl this$0, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 375 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 378 */               if ($deckId == null) {
/* 379 */                   _stmt.mo8755bindNull(1);
                        } else {
/* 381 */                   _stmt.mo8756bindText(1, $deckId);
                        }
/* 383 */               int _argIndex = 2;
/* 384 */               if ($deckId == null) {
/* 385 */                   _stmt.mo8755bindNull(2);
                        } else {
/* 387 */                   _stmt.mo8756bindText(2, $deckId);
                        }
/* 389 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 390 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 391 */               int _columnIndexOfFront = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "front");
/* 392 */               int _columnIndexOfBack = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "back");
/* 393 */               int _columnIndexOfExample = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "example");
/* 394 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 395 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 396 */               ArrayMap<String, ScheduleEntity> arrayMap = new ArrayMap<>();
/* 397 */               ArrayMap<String, DeckEntity> arrayMap2 = new ArrayMap<>();
/* 398 */               while (_stmt.step()) {
/* 400 */                   String _tmpKey = _stmt.getText(_columnIndexOfId);
                            arrayMap.put(_tmpKey, null);
/* 403 */                   String _tmpKey_1 = _stmt.getText(_columnIndexOfDeckId);
/* 404 */                   arrayMap2.put(_tmpKey_1, null);
/* 401 */                   _argIndex = _argIndex;
                        }
                        _stmt.reset();
/* 407 */               this$0.__fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity(_connection, arrayMap);
/* 408 */               this$0.__fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity(_connection, arrayMap2);
/* 409 */               List _result = new ArrayList();
/* 410 */               while (_stmt.step()) {
/* 414 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 416 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 418 */                   String _tmpFront = _stmt.getText(_columnIndexOfFront);
/* 420 */                   String _tmpBack = _stmt.getText(_columnIndexOfBack);
/* 422 */                   String _tmpExample = _stmt.getText(_columnIndexOfExample);
/* 424 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 426 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 427 */                   CardEntity _tmpCard = new CardEntity(_tmpId, _tmpDeckId, _tmpFront, _tmpBack, _tmpExample, _tmpCreatedAt, _tmpUpdatedAt);
/* 430 */                   String _tmpKey_2 = _stmt.getText(_columnIndexOfId);
                            ScheduleEntity _tmpSchedule = arrayMap.get(_tmpKey_2);
/* 432 */                   if (_tmpSchedule == null) {
/* 433 */                       throw new IllegalStateException("Relationship item 'schedule' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'id' and entityColumn named 'cardId'.".toString());
                            }
/* 437 */                   String _tmpKey_3 = _stmt.getText(_columnIndexOfDeckId);
                            DeckEntity _tmpDeck = arrayMap2.get(_tmpKey_3);
/* 439 */                   if (_tmpDeck == null) {
/* 440 */                       throw new IllegalStateException("Relationship item 'deck' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'deckId' and entityColumn named 'id'.".toString());
                            }
                            CardRelations _item = new CardRelations(_tmpCard, _tmpSchedule, _tmpDeck);
/* 443 */                   _result.add(_item);
                        }
/* 447 */               _stmt.close();
/* 445 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 452 */       public Object candidates(final String deckId, Continuation<? super List<CardRelations>> continuation) {
/* 453 */           final String _sql = "SELECT * FROM cards WHERE (? IS NULL OR deckId=?) ORDER BY createdAt,id";
/* 454 */           return DBUtil.performSuspending(this.__db, true, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda23
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.candidates$lambda$0(_sql, deckId, this, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 454 */       public static final List candidates$lambda$0(String $_sql, String $deckId, XunjiDao_Impl this$0, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 455 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 458 */               if ($deckId == null) {
/* 459 */                   _stmt.mo8755bindNull(1);
                        } else {
/* 461 */                   _stmt.mo8756bindText(1, $deckId);
                        }
/* 463 */               int _argIndex = 2;
/* 464 */               if ($deckId == null) {
/* 465 */                   _stmt.mo8755bindNull(2);
                        } else {
/* 467 */                   _stmt.mo8756bindText(2, $deckId);
                        }
/* 469 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 470 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 471 */               int _columnIndexOfFront = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "front");
/* 472 */               int _columnIndexOfBack = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "back");
/* 473 */               int _columnIndexOfExample = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "example");
/* 474 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 475 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 476 */               ArrayMap<String, ScheduleEntity> arrayMap = new ArrayMap<>();
/* 477 */               ArrayMap<String, DeckEntity> arrayMap2 = new ArrayMap<>();
/* 478 */               while (_stmt.step()) {
/* 480 */                   String _tmpKey = _stmt.getText(_columnIndexOfId);
                            arrayMap.put(_tmpKey, null);
/* 483 */                   String _tmpKey_1 = _stmt.getText(_columnIndexOfDeckId);
/* 484 */                   arrayMap2.put(_tmpKey_1, null);
/* 481 */                   _argIndex = _argIndex;
                        }
                        _stmt.reset();
/* 487 */               this$0.__fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity(_connection, arrayMap);
/* 488 */               this$0.__fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity(_connection, arrayMap2);
/* 489 */               List _result = new ArrayList();
/* 490 */               while (_stmt.step()) {
/* 494 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 496 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 498 */                   String _tmpFront = _stmt.getText(_columnIndexOfFront);
/* 500 */                   String _tmpBack = _stmt.getText(_columnIndexOfBack);
/* 502 */                   String _tmpExample = _stmt.getText(_columnIndexOfExample);
/* 504 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 506 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 507 */                   CardEntity _tmpCard = new CardEntity(_tmpId, _tmpDeckId, _tmpFront, _tmpBack, _tmpExample, _tmpCreatedAt, _tmpUpdatedAt);
/* 510 */                   String _tmpKey_2 = _stmt.getText(_columnIndexOfId);
                            ScheduleEntity _tmpSchedule = arrayMap.get(_tmpKey_2);
/* 512 */                   if (_tmpSchedule == null) {
/* 513 */                       throw new IllegalStateException("Relationship item 'schedule' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'id' and entityColumn named 'cardId'.".toString());
                            }
/* 517 */                   String _tmpKey_3 = _stmt.getText(_columnIndexOfDeckId);
                            DeckEntity _tmpDeck = arrayMap2.get(_tmpKey_3);
/* 519 */                   if (_tmpDeck == null) {
/* 520 */                       throw new IllegalStateException("Relationship item 'deck' was expected to be NON-NULL but is NULL in @Relation involving a parent column named 'deckId' and entityColumn named 'id'.".toString());
                            }
                            CardRelations _item = new CardRelations(_tmpCard, _tmpSchedule, _tmpDeck);
/* 523 */                   _result.add(_item);
                        }
/* 527 */               _stmt.close();
/* 525 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 532 */       public Object cards(Continuation<? super List<CardEntity>> continuation) {
/* 533 */           final String _sql = "SELECT * FROM cards ORDER BY id";
/* 534 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda25
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.cards$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 534 */       public static final List cards$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 535 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 537 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 538 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 539 */               int _columnIndexOfFront = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "front");
/* 540 */               int _columnIndexOfBack = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "back");
/* 541 */               int _columnIndexOfExample = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "example");
/* 542 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 543 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 544 */               List _result = new ArrayList();
/* 545 */               while (_stmt.step()) {
/* 548 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 550 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 552 */                   String _tmpFront = _stmt.getText(_columnIndexOfFront);
/* 554 */                   String _tmpBack = _stmt.getText(_columnIndexOfBack);
/* 556 */                   String _tmpExample = _stmt.getText(_columnIndexOfExample);
/* 558 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 560 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 561 */                   CardEntity _item = new CardEntity(_tmpId, _tmpDeckId, _tmpFront, _tmpBack, _tmpExample, _tmpCreatedAt, _tmpUpdatedAt);
/* 562 */                   _result.add(_item);
                        }
/* 566 */               _stmt.close();
/* 567 */               return _result;
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 571 */       public Object card(final String id, Continuation<? super CardEntity> continuation) {
/* 572 */           final String _sql = "SELECT * FROM cards WHERE id=?";
/* 573 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.card$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 573 */       public static final CardEntity card$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    CardEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 574 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 577 */               _stmt.mo8756bindText(1, $id);
/* 578 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 579 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 580 */               int _columnIndexOfFront = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "front");
/* 581 */               int _columnIndexOfBack = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "back");
/* 582 */               int _columnIndexOfExample = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "example");
/* 583 */               int _columnIndexOfCreatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "createdAt");
/* 584 */               int _columnIndexOfUpdatedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "updatedAt");
/* 586 */               if (_stmt.step()) {
/* 588 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 590 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 592 */                   String _tmpFront = _stmt.getText(_columnIndexOfFront);
/* 594 */                   String _tmpBack = _stmt.getText(_columnIndexOfBack);
/* 596 */                   String _tmpExample = _stmt.getText(_columnIndexOfExample);
/* 598 */                   long _tmpCreatedAt = _stmt.getLong(_columnIndexOfCreatedAt);
/* 600 */                   long _tmpUpdatedAt = _stmt.getLong(_columnIndexOfUpdatedAt);
/* 601 */                   _result = new CardEntity(_tmpId, _tmpDeckId, _tmpFront, _tmpBack, _tmpExample, _tmpCreatedAt, _tmpUpdatedAt);
                        } else {
/* 603 */                   _result = null;
                        }
/* 608 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 612 */       public Flow<List<ScheduleEntity>> watchSchedules() {
/* 613 */           final String _sql = "SELECT * FROM schedules ORDER BY cardId";
/* 614 */           return FlowUtil.createFlow(this.__db, false, new String[]{"schedules"}, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda26
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.watchSchedules$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 614 */       public static final List watchSchedules$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Integer _tmpStep;
                    Double _tmpStability;
                    Double _tmpDifficulty;
                    Long _tmpLastReviewAt;
                    Long _tmpFirstReviewedAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 615 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 617 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 618 */               int _columnIndexOfPhase = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "phase");
/* 619 */               int _columnIndexOfStep = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "step");
/* 620 */               int _columnIndexOfStability = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "stability");
/* 621 */               int _columnIndexOfDifficulty = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "difficulty");
/* 622 */               int _columnIndexOfDueAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "dueAt");
/* 623 */               int _columnIndexOfLastReviewAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastReviewAt");
/* 624 */               int _columnIndexOfFirstReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "firstReviewedAt");
/* 625 */               int _columnIndexOfRevision = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "revision");
/* 626 */               List _result = new ArrayList();
/* 627 */               while (_stmt.step()) {
/* 630 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 632 */                   String _tmpPhase = _stmt.getText(_columnIndexOfPhase);
/* 634 */                   if (_stmt.isNull(_columnIndexOfStep)) {
/* 635 */                       _tmpStep = null;
                            } else {
                                Integer _tmpStep2 = Integer.valueOf((int) _stmt.getLong(_columnIndexOfStep));
                                _tmpStep = _tmpStep2;
                            }
/* 640 */                   if (_stmt.isNull(_columnIndexOfStability)) {
/* 641 */                       _tmpStability = null;
                            } else {
/* 643 */                       Double _tmpStability2 = Double.valueOf(_stmt.getDouble(_columnIndexOfStability));
                                _tmpStability = _tmpStability2;
                            }
/* 646 */                   if (_stmt.isNull(_columnIndexOfDifficulty)) {
/* 647 */                       _tmpDifficulty = null;
                            } else {
/* 649 */                       Double _tmpDifficulty2 = Double.valueOf(_stmt.getDouble(_columnIndexOfDifficulty));
                                _tmpDifficulty = _tmpDifficulty2;
                            }
/* 652 */                   long _tmpDueAt = _stmt.getLong(_columnIndexOfDueAt);
/* 654 */                   if (_stmt.isNull(_columnIndexOfLastReviewAt)) {
/* 655 */                       _tmpLastReviewAt = null;
                            } else {
/* 657 */                       Long _tmpLastReviewAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfLastReviewAt));
                                _tmpLastReviewAt = _tmpLastReviewAt2;
                            }
/* 660 */                   if (_stmt.isNull(_columnIndexOfFirstReviewedAt)) {
/* 661 */                       _tmpFirstReviewedAt = null;
                            } else {
/* 663 */                       Long _tmpFirstReviewedAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfFirstReviewedAt));
                                _tmpFirstReviewedAt = _tmpFirstReviewedAt2;
                            }
/* 666 */                   long _tmpRevision = _stmt.getLong(_columnIndexOfRevision);
/* 667 */                   ScheduleEntity _item = new ScheduleEntity(_tmpCardId, _tmpPhase, _tmpStep, _tmpStability, _tmpDifficulty, _tmpDueAt, _tmpLastReviewAt, _tmpFirstReviewedAt, _tmpRevision);
/* 668 */                   _result.add(_item);
                            _columnIndexOfCardId = _columnIndexOfCardId;
                        }
/* 673 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 677 */       public Object schedules(Continuation<? super List<ScheduleEntity>> continuation) {
/* 678 */           final String _sql = "SELECT * FROM schedules ORDER BY cardId";
/* 679 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda13
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.schedules$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 679 */       public static final List schedules$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Integer _tmpStep;
                    Double _tmpStability;
                    Double _tmpDifficulty;
                    Long _tmpLastReviewAt;
                    Long _tmpFirstReviewedAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 680 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 682 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 683 */               int _columnIndexOfPhase = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "phase");
/* 684 */               int _columnIndexOfStep = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "step");
/* 685 */               int _columnIndexOfStability = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "stability");
/* 686 */               int _columnIndexOfDifficulty = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "difficulty");
/* 687 */               int _columnIndexOfDueAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "dueAt");
/* 688 */               int _columnIndexOfLastReviewAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastReviewAt");
/* 689 */               int _columnIndexOfFirstReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "firstReviewedAt");
/* 690 */               int _columnIndexOfRevision = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "revision");
/* 691 */               List _result = new ArrayList();
/* 692 */               while (_stmt.step()) {
/* 695 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 697 */                   String _tmpPhase = _stmt.getText(_columnIndexOfPhase);
/* 699 */                   if (_stmt.isNull(_columnIndexOfStep)) {
/* 700 */                       _tmpStep = null;
                            } else {
                                Integer _tmpStep2 = Integer.valueOf((int) _stmt.getLong(_columnIndexOfStep));
                                _tmpStep = _tmpStep2;
                            }
/* 705 */                   if (_stmt.isNull(_columnIndexOfStability)) {
/* 706 */                       _tmpStability = null;
                            } else {
/* 708 */                       Double _tmpStability2 = Double.valueOf(_stmt.getDouble(_columnIndexOfStability));
                                _tmpStability = _tmpStability2;
                            }
/* 711 */                   if (_stmt.isNull(_columnIndexOfDifficulty)) {
/* 712 */                       _tmpDifficulty = null;
                            } else {
/* 714 */                       Double _tmpDifficulty2 = Double.valueOf(_stmt.getDouble(_columnIndexOfDifficulty));
                                _tmpDifficulty = _tmpDifficulty2;
                            }
/* 717 */                   long _tmpDueAt = _stmt.getLong(_columnIndexOfDueAt);
/* 719 */                   if (_stmt.isNull(_columnIndexOfLastReviewAt)) {
/* 720 */                       _tmpLastReviewAt = null;
                            } else {
/* 722 */                       Long _tmpLastReviewAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfLastReviewAt));
                                _tmpLastReviewAt = _tmpLastReviewAt2;
                            }
/* 725 */                   if (_stmt.isNull(_columnIndexOfFirstReviewedAt)) {
/* 726 */                       _tmpFirstReviewedAt = null;
                            } else {
/* 728 */                       Long _tmpFirstReviewedAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfFirstReviewedAt));
                                _tmpFirstReviewedAt = _tmpFirstReviewedAt2;
                            }
/* 731 */                   long _tmpRevision = _stmt.getLong(_columnIndexOfRevision);
/* 732 */                   ScheduleEntity _item = new ScheduleEntity(_tmpCardId, _tmpPhase, _tmpStep, _tmpStability, _tmpDifficulty, _tmpDueAt, _tmpLastReviewAt, _tmpFirstReviewedAt, _tmpRevision);
/* 733 */                   _result.add(_item);
                            _columnIndexOfCardId = _columnIndexOfCardId;
                        }
/* 738 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 742 */       public Object schedule(final String id, Continuation<? super ScheduleEntity> continuation) {
/* 743 */           final String _sql = "SELECT * FROM schedules WHERE cardId=?";
/* 744 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda20
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.schedule$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 744 */       public static final ScheduleEntity schedule$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    ScheduleEntity _result;
                    Integer _tmpStep;
                    Double _tmpStability;
                    Double _tmpDifficulty;
                    Long _tmpLastReviewAt;
                    Long _tmpFirstReviewedAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 745 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 748 */               _stmt.mo8756bindText(1, $id);
/* 749 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 750 */               int _columnIndexOfPhase = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "phase");
/* 751 */               int _columnIndexOfStep = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "step");
/* 752 */               int _columnIndexOfStability = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "stability");
/* 753 */               int _columnIndexOfDifficulty = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "difficulty");
/* 754 */               int _columnIndexOfDueAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "dueAt");
/* 755 */               int _columnIndexOfLastReviewAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "lastReviewAt");
/* 756 */               int _columnIndexOfFirstReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "firstReviewedAt");
/* 757 */               int _columnIndexOfRevision = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "revision");
/* 759 */               if (_stmt.step()) {
/* 761 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 763 */                   String _tmpPhase = _stmt.getText(_columnIndexOfPhase);
/* 765 */                   if (_stmt.isNull(_columnIndexOfStep)) {
/* 766 */                       _tmpStep = null;
                            } else {
                                Integer _tmpStep2 = Integer.valueOf((int) _stmt.getLong(_columnIndexOfStep));
                                _tmpStep = _tmpStep2;
                            }
/* 771 */                   if (_stmt.isNull(_columnIndexOfStability)) {
/* 772 */                       _tmpStability = null;
                            } else {
/* 774 */                       Double _tmpStability2 = Double.valueOf(_stmt.getDouble(_columnIndexOfStability));
                                _tmpStability = _tmpStability2;
                            }
/* 777 */                   if (_stmt.isNull(_columnIndexOfDifficulty)) {
/* 778 */                       _tmpDifficulty = null;
                            } else {
/* 780 */                       Double _tmpDifficulty2 = Double.valueOf(_stmt.getDouble(_columnIndexOfDifficulty));
                                _tmpDifficulty = _tmpDifficulty2;
                            }
/* 783 */                   long _tmpDueAt = _stmt.getLong(_columnIndexOfDueAt);
/* 785 */                   if (_stmt.isNull(_columnIndexOfLastReviewAt)) {
/* 786 */                       _tmpLastReviewAt = null;
                            } else {
/* 788 */                       Long _tmpLastReviewAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfLastReviewAt));
                                _tmpLastReviewAt = _tmpLastReviewAt2;
                            }
/* 791 */                   if (_stmt.isNull(_columnIndexOfFirstReviewedAt)) {
/* 792 */                       _tmpFirstReviewedAt = null;
                            } else {
/* 794 */                       Long _tmpFirstReviewedAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfFirstReviewedAt));
                                _tmpFirstReviewedAt = _tmpFirstReviewedAt2;
                            }
/* 797 */                   long _tmpRevision = _stmt.getLong(_columnIndexOfRevision);
/* 798 */                   _result = new ScheduleEntity(_tmpCardId, _tmpPhase, _tmpStep, _tmpStability, _tmpDifficulty, _tmpDueAt, _tmpLastReviewAt, _tmpFirstReviewedAt, _tmpRevision);
                        } else {
                            _result = null;
                        }
/* 805 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 809 */       public Flow<List<ReviewLogEntity>> watchLogs() {
/* 810 */           final String _sql = "SELECT * FROM review_logs ORDER BY reviewedAt,id";
/* 811 */           return FlowUtil.createFlow(this.__db, false, new String[]{"review_logs"}, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.watchLogs$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 811 */       public static final List watchLogs$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Long _tmpUndoneAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 812 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 814 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 815 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 816 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 817 */               int _columnIndexOfSessionId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sessionId");
/* 818 */               int _columnIndexOfRating = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "rating");
/* 819 */               int _columnIndexOfReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "reviewedAt");
/* 820 */               int _columnIndexOfDurationMs = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "durationMs");
/* 821 */               int _columnIndexOfBeforeSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "beforeSchedule");
/* 822 */               int _columnIndexOfAfterSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "afterSchedule");
/* 823 */               int _columnIndexOfUndoneAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "undoneAt");
/* 824 */               List _result = new ArrayList();
/* 825 */               while (_stmt.step()) {
/* 828 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 830 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 832 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 834 */                   String _tmpSessionId = _stmt.getText(_columnIndexOfSessionId);
/* 836 */                   int _columnIndexOfId2 = _columnIndexOfId;
                            int _tmpRating = (int) _stmt.getLong(_columnIndexOfRating);
/* 838 */                   long _tmpReviewedAt = _stmt.getLong(_columnIndexOfReviewedAt);
/* 840 */                   long _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs);
/* 842 */                   String _tmpBeforeSchedule = _stmt.getText(_columnIndexOfBeforeSchedule);
/* 844 */                   String _tmpAfterSchedule = _stmt.getText(_columnIndexOfAfterSchedule);
/* 846 */                   if (_stmt.isNull(_columnIndexOfUndoneAt)) {
/* 847 */                       _tmpUndoneAt = null;
                            } else {
/* 849 */                       Long _tmpUndoneAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfUndoneAt));
                                _tmpUndoneAt = _tmpUndoneAt2;
                            }
/* 851 */                   ReviewLogEntity _item = new ReviewLogEntity(_tmpId, _tmpCardId, _tmpDeckId, _tmpSessionId, _tmpRating, _tmpReviewedAt, _tmpDurationMs, _tmpBeforeSchedule, _tmpAfterSchedule, _tmpUndoneAt);
/* 852 */                   _result.add(_item);
                            _columnIndexOfId = _columnIndexOfId2;
                        }
/* 857 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 861 */       public Object logs(Continuation<? super List<ReviewLogEntity>> continuation) {
/* 862 */           final String _sql = "SELECT * FROM review_logs ORDER BY reviewedAt,id";
/* 863 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.logs$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 863 */       public static final List logs$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Long _tmpUndoneAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 864 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 866 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 867 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 868 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 869 */               int _columnIndexOfSessionId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sessionId");
/* 870 */               int _columnIndexOfRating = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "rating");
/* 871 */               int _columnIndexOfReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "reviewedAt");
/* 872 */               int _columnIndexOfDurationMs = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "durationMs");
/* 873 */               int _columnIndexOfBeforeSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "beforeSchedule");
/* 874 */               int _columnIndexOfAfterSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "afterSchedule");
/* 875 */               int _columnIndexOfUndoneAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "undoneAt");
/* 876 */               List _result = new ArrayList();
/* 877 */               while (_stmt.step()) {
/* 880 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 882 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 884 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 886 */                   String _tmpSessionId = _stmt.getText(_columnIndexOfSessionId);
/* 888 */                   int _columnIndexOfId2 = _columnIndexOfId;
                            int _tmpRating = (int) _stmt.getLong(_columnIndexOfRating);
/* 890 */                   long _tmpReviewedAt = _stmt.getLong(_columnIndexOfReviewedAt);
/* 892 */                   long _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs);
/* 894 */                   String _tmpBeforeSchedule = _stmt.getText(_columnIndexOfBeforeSchedule);
/* 896 */                   String _tmpAfterSchedule = _stmt.getText(_columnIndexOfAfterSchedule);
/* 898 */                   if (_stmt.isNull(_columnIndexOfUndoneAt)) {
/* 899 */                       _tmpUndoneAt = null;
                            } else {
/* 901 */                       Long _tmpUndoneAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfUndoneAt));
                                _tmpUndoneAt = _tmpUndoneAt2;
                            }
/* 903 */                   ReviewLogEntity _item = new ReviewLogEntity(_tmpId, _tmpCardId, _tmpDeckId, _tmpSessionId, _tmpRating, _tmpReviewedAt, _tmpDurationMs, _tmpBeforeSchedule, _tmpAfterSchedule, _tmpUndoneAt);
/* 904 */                   _result.add(_item);
                            _columnIndexOfId = _columnIndexOfId2;
                        }
/* 909 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 913 */       public Object log(final String id, Continuation<? super ReviewLogEntity> continuation) {
/* 914 */           final String _sql = "SELECT * FROM review_logs WHERE id=?";
/* 915 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.log$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 915 */       public static final ReviewLogEntity log$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    ReviewLogEntity _result;
                    Long _tmpUndoneAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 916 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 919 */               _stmt.mo8756bindText(1, $id);
/* 920 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 921 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 922 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 923 */               int _columnIndexOfSessionId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sessionId");
/* 924 */               int _columnIndexOfRating = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "rating");
/* 925 */               int _columnIndexOfReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "reviewedAt");
/* 926 */               int _columnIndexOfDurationMs = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "durationMs");
/* 927 */               int _columnIndexOfBeforeSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "beforeSchedule");
/* 928 */               int _columnIndexOfAfterSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "afterSchedule");
/* 929 */               int _columnIndexOfUndoneAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "undoneAt");
/* 931 */               if (_stmt.step()) {
/* 933 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 935 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 937 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 939 */                   String _tmpSessionId = _stmt.getText(_columnIndexOfSessionId);
                            int _tmpRating = (int) _stmt.getLong(_columnIndexOfRating);
/* 943 */                   long _tmpReviewedAt = _stmt.getLong(_columnIndexOfReviewedAt);
/* 945 */                   long _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs);
/* 947 */                   String _tmpBeforeSchedule = _stmt.getText(_columnIndexOfBeforeSchedule);
/* 949 */                   String _tmpAfterSchedule = _stmt.getText(_columnIndexOfAfterSchedule);
/* 951 */                   if (_stmt.isNull(_columnIndexOfUndoneAt)) {
/* 952 */                       _tmpUndoneAt = null;
                            } else {
/* 954 */                       Long _tmpUndoneAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfUndoneAt));
                                _tmpUndoneAt = _tmpUndoneAt2;
                            }
/* 956 */                   _result = new ReviewLogEntity(_tmpId, _tmpCardId, _tmpDeckId, _tmpSessionId, _tmpRating, _tmpReviewedAt, _tmpDurationMs, _tmpBeforeSchedule, _tmpAfterSchedule, _tmpUndoneAt);
                        } else {
                            _result = null;
                        }
/* 963 */               return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 967 */       public Object latestSessionLog(final String sessionId, Continuation<? super ReviewLogEntity> continuation) {
/* 968 */           final String _sql = "SELECT * FROM review_logs WHERE sessionId=? ORDER BY rowid DESC LIMIT 1";
/* 969 */           return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda19
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.latestSessionLog$lambda$0(_sql, sessionId, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 969 */       public static final ReviewLogEntity latestSessionLog$lambda$0(String $_sql, String $sessionId, SQLiteConnection _connection) {
                    ReviewLogEntity _result;
                    Long _tmpUndoneAt;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 970 */           SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 973 */               _stmt.mo8756bindText(1, $sessionId);
/* 974 */               int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 975 */               int _columnIndexOfCardId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "cardId");
/* 976 */               int _columnIndexOfDeckId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "deckId");
/* 977 */               int _columnIndexOfSessionId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "sessionId");
/* 978 */               int _columnIndexOfRating = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "rating");
/* 979 */               int _columnIndexOfReviewedAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "reviewedAt");
/* 980 */               int _columnIndexOfDurationMs = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "durationMs");
/* 981 */               int _columnIndexOfBeforeSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "beforeSchedule");
/* 982 */               int _columnIndexOfAfterSchedule = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "afterSchedule");
/* 983 */               int _columnIndexOfUndoneAt = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "undoneAt");
/* 985 */               if (_stmt.step()) {
/* 987 */                   String _tmpId = _stmt.getText(_columnIndexOfId);
/* 989 */                   String _tmpCardId = _stmt.getText(_columnIndexOfCardId);
/* 991 */                   String _tmpDeckId = _stmt.getText(_columnIndexOfDeckId);
/* 993 */                   String _tmpSessionId = _stmt.getText(_columnIndexOfSessionId);
                            int _tmpRating = (int) _stmt.getLong(_columnIndexOfRating);
/* 997 */                   long _tmpReviewedAt = _stmt.getLong(_columnIndexOfReviewedAt);
/* 999 */                   long _tmpDurationMs = _stmt.getLong(_columnIndexOfDurationMs);
/* 1001 */                  String _tmpBeforeSchedule = _stmt.getText(_columnIndexOfBeforeSchedule);
/* 1003 */                  String _tmpAfterSchedule = _stmt.getText(_columnIndexOfAfterSchedule);
/* 1005 */                  if (_stmt.isNull(_columnIndexOfUndoneAt)) {
/* 1006 */                      _tmpUndoneAt = null;
                            } else {
/* 1008 */                      Long _tmpUndoneAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfUndoneAt));
                                _tmpUndoneAt = _tmpUndoneAt2;
                            }
/* 1010 */                  _result = new ReviewLogEntity(_tmpId, _tmpCardId, _tmpDeckId, _tmpSessionId, _tmpRating, _tmpReviewedAt, _tmpDurationMs, _tmpBeforeSchedule, _tmpAfterSchedule, _tmpUndoneAt);
                        } else {
                            _result = null;
                        }
/* 1017 */              return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 1021 */      public Flow<SettingsEntity> watchSettings() {
/* 1022 */          final String _sql = "SELECT * FROM settings WHERE id=0";
/* 1023 */          return FlowUtil.createFlow(this.__db, false, new String[]{"settings"}, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda22
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.watchSettings$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1023 */      public static final SettingsEntity watchSettings$lambda$0(String $_sql, SQLiteConnection _connection) {
                    SettingsEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 1024 */          SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 1026 */              int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 1027 */              int _columnIndexOfNewCardsPerDay = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "newCardsPerDay");
/* 1028 */              int _columnIndexOfThemeMode = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "themeMode");
/* 1029 */              int _columnIndexOfSchemaVersion = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "schemaVersion");
/* 1031 */              if (_stmt.step()) {
/* 1033 */                  int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
/* 1035 */                  int _tmpNewCardsPerDay = (int) _stmt.getLong(_columnIndexOfNewCardsPerDay);
/* 1037 */                  String _tmpThemeMode = _stmt.getText(_columnIndexOfThemeMode);
/* 1039 */                  int _tmpSchemaVersion = (int) _stmt.getLong(_columnIndexOfSchemaVersion);
/* 1040 */                  _result = new SettingsEntity(_tmpId, _tmpNewCardsPerDay, _tmpThemeMode, _tmpSchemaVersion);
                        } else {
/* 1042 */                  _result = null;
                        }
/* 1047 */              return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 1051 */      public Object settings(Continuation<? super SettingsEntity> continuation) {
/* 1052 */          final String _sql = "SELECT * FROM settings WHERE id=0";
/* 1053 */          return DBUtil.performSuspending(this.__db, true, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.settings$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1053 */      public static final SettingsEntity settings$lambda$0(String $_sql, SQLiteConnection _connection) {
                    SettingsEntity _result;
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 1054 */          SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 1056 */              int _columnIndexOfId = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "id");
/* 1057 */              int _columnIndexOfNewCardsPerDay = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "newCardsPerDay");
/* 1058 */              int _columnIndexOfThemeMode = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "themeMode");
/* 1059 */              int _columnIndexOfSchemaVersion = SQLiteStatementUtil.getColumnIndexOrThrow(_stmt, "schemaVersion");
/* 1061 */              if (_stmt.step()) {
/* 1063 */                  int _tmpId = (int) _stmt.getLong(_columnIndexOfId);
/* 1065 */                  int _tmpNewCardsPerDay = (int) _stmt.getLong(_columnIndexOfNewCardsPerDay);
/* 1067 */                  String _tmpThemeMode = _stmt.getText(_columnIndexOfThemeMode);
/* 1069 */                  int _tmpSchemaVersion = (int) _stmt.getLong(_columnIndexOfSchemaVersion);
/* 1070 */                  _result = new SettingsEntity(_tmpId, _tmpNewCardsPerDay, _tmpThemeMode, _tmpSchemaVersion);
                        } else {
/* 1072 */                  _result = null;
                        }
/* 1077 */              return _result;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 1081 */      public Object deleteDeck(final String id, Continuation<? super Unit> continuation) {
/* 1082 */          final String _sql = "DELETE FROM decks WHERE id=?";
/* 1083 */          Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda27
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.deleteDeck$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1083 */      public static final Unit deleteDeck$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 1084 */          SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 1087 */              _stmt.mo8756bindText(1, $id);
/* 1088 */              _stmt.step();
/* 1092 */              return Unit.INSTANCE;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 1095 */      public Object deleteAllDecks(Continuation<? super Unit> continuation) {
/* 1096 */          final String _sql = "DELETE FROM decks";
/* 1097 */          Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda7
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.deleteAllDecks$lambda$0(_sql, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1097 */      public static final Unit deleteAllDecks$lambda$0(String $_sql, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 1098 */          SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 1100 */              _stmt.step();
/* 1104 */              return Unit.INSTANCE;
                    } finally {
                        _stmt.close();
                    }
                }

                @Override // com.xunji.flashcards.data.XunjiDao
/* 1107 */      public Object deleteCard(final String id, Continuation<? super Unit> continuation) {
/* 1108 */          final String _sql = "DELETE FROM cards WHERE id=?";
/* 1109 */          Object objPerformSuspending = DBUtil.performSuspending(this.__db, false, true, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiDao_Impl.deleteCard$lambda$0(_sql, id, (SQLiteConnection) obj);
                        }
                    }, continuation);
                    return objPerformSuspending == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objPerformSuspending : Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1109 */      public static final Unit deleteCard$lambda$0(String $_sql, String $id, SQLiteConnection _connection) {
                    Intrinsics.checkNotNullParameter(_connection, "_connection");
/* 1110 */          SQLiteStatement _stmt = _connection.prepare($_sql);
                    try {
/* 1113 */              _stmt.mo8756bindText(1, $id);
/* 1114 */              _stmt.step();
/* 1118 */              return Unit.INSTANCE;
                    } finally {
                        _stmt.close();
                    }
                }

/* 1121 */      private final void __fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity(final SQLiteConnection _connection, ArrayMap<String, ScheduleEntity> _map) throws Throwable {
                    Integer _tmpStep;
                    Double _tmpStability;
                    Double _tmpDifficulty;
                    Long _tmpLastReviewAt;
                    Long _tmpFirstReviewedAt;
                    Set<String> setKeySet = _map.keySet();
/* 1123 */          if (setKeySet.isEmpty()) {
/* 1124 */              return;
                    }
/* 1126 */          if (_map.getSize() > 999) {
/* 1122 */              RelationUtil.recursiveFetchArrayMap(_map, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return XunjiDao_Impl.__fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity$lambda$0(this.f$0, _connection, (ArrayMap) obj);
                            }
                        });
/* 1130 */              return;
                    }
                    StringBuilder _stringBuilder = new StringBuilder();
/* 1133 */          _stringBuilder.append("SELECT `cardId`,`phase`,`step`,`stability`,`difficulty`,`dueAt`,`lastReviewAt`,`firstReviewedAt`,`revision` FROM `schedules` WHERE `cardId` IN (");
/* 1134 */          int _inputSize = setKeySet.size();
/* 1135 */          StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
/* 1136 */          _stringBuilder.append(")");
/* 1137 */          String _sql = _stringBuilder.toString();
                    Intrinsics.checkNotNullExpressionValue(_sql, "toString(...)");
/* 1138 */          SQLiteStatement _stmt = _connection.prepare(_sql);
/* 1139 */          int _argIndex = 1;
                    for (String _item : setKeySet) {
/* 1141 */              _stmt.mo8756bindText(_argIndex, _item);
                        _argIndex++;
                    }
                    try {
/* 1145 */              int _itemKeyIndex = SQLiteStatementUtil.getColumnIndex(_stmt, "cardId");
/* 1146 */              if (_itemKeyIndex == -1) {
/* 1206 */                  _stmt.close();
/* 1147 */                  return;
                        }
/* 1155 */              int _columnIndexOfRevision = 6;
/* 1157 */              int _columnIndexOfRevision2 = 8;
/* 1158 */              while (_stmt.step()) {
                            try {
/* 1160 */                      String _tmpKey = _stmt.getText(_itemKeyIndex);
/* 1161 */                      _itemKeyIndex = _itemKeyIndex;
                                if (_map.containsKey(_tmpKey)) {
/* 1164 */                          String _tmpCardId = _stmt.getText(0);
/* 1166 */                          String _tmpPhase = _stmt.getText(1);
/* 1168 */                          if (_stmt.isNull(2)) {
/* 1169 */                              _tmpStep = null;
                                    } else {
/* 1151 */                              Integer _tmpStep2 = Integer.valueOf((int) _stmt.getLong(2));
                                        _tmpStep = _tmpStep2;
                                    }
                                    try {
/* 1174 */                              if (_stmt.isNull(3)) {
/* 1175 */                                  _tmpStability = null;
                                        } else {
/* 1177 */                                  Double _tmpStability2 = Double.valueOf(_stmt.getDouble(3));
                                            _tmpStability = _tmpStability2;
                                        }
/* 1180 */                              if (_stmt.isNull(4)) {
/* 1181 */                                  _tmpDifficulty = null;
                                        } else {
/* 1183 */                                  Double _tmpDifficulty2 = Double.valueOf(_stmt.getDouble(4));
                                            _tmpDifficulty = _tmpDifficulty2;
                                        }
/* 1186 */                              long _tmpDueAt = _stmt.getLong(5);
/* 1188 */                              if (_stmt.isNull(_columnIndexOfRevision)) {
/* 1189 */                                  _tmpLastReviewAt = null;
                                        } else {
/* 1191 */                                  Long _tmpLastReviewAt2 = Long.valueOf(_stmt.getLong(_columnIndexOfRevision));
                                            _tmpLastReviewAt = _tmpLastReviewAt2;
                                        }
/* 1194 */                              if (_stmt.isNull(7)) {
/* 1195 */                                  _tmpFirstReviewedAt = null;
                                        } else {
/* 1197 */                                  Long _tmpFirstReviewedAt2 = Long.valueOf(_stmt.getLong(7));
                                            _tmpFirstReviewedAt = _tmpFirstReviewedAt2;
                                        }
/* 1200 */                              int _columnIndexOfLastReviewAt = _columnIndexOfRevision;
                                        int _columnIndexOfLastReviewAt2 = _columnIndexOfRevision2;
                                        long _tmpRevision = _stmt.getLong(_columnIndexOfLastReviewAt2);
/* 1201 */                              ScheduleEntity _item_1 = new ScheduleEntity(_tmpCardId, _tmpPhase, _tmpStep, _tmpStability, _tmpDifficulty, _tmpDueAt, _tmpLastReviewAt, _tmpFirstReviewedAt, _tmpRevision);
/* 1202 */                              _map.put(_tmpKey, _item_1);
                                        _columnIndexOfRevision2 = _columnIndexOfLastReviewAt2;
                                        _columnIndexOfRevision = _columnIndexOfLastReviewAt;
                                        _stringBuilder = _stringBuilder;
                                    } catch (Throwable th) {
/* 1206 */                              th = th;
                                        _stmt.close();
                                        throw th;
                                    }
                                } else {
/* 1161 */                          int _columnIndexOfLastReviewAt3 = _columnIndexOfRevision;
                                    _columnIndexOfRevision = _columnIndexOfLastReviewAt3;
                                }
                            } catch (Throwable th2) {
/* 1206 */                      th = th2;
                            }
                        }
/* 1206 */              _stmt.close();
                    } catch (Throwable th3) {
                        th = th3;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1127 */      public static final Unit __fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity$lambda$0(XunjiDao_Impl this$0, SQLiteConnection $_connection, ArrayMap _tmpMap) throws Throwable {
                    Intrinsics.checkNotNullParameter(_tmpMap, "_tmpMap");
/* 1128 */          this$0.__fetchRelationshipschedulesAscomXunjiFlashcardsDataScheduleEntity($_connection, _tmpMap);
/* 1129 */          return Unit.INSTANCE;
                }

/* 1210 */      private final void __fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity(final SQLiteConnection _connection, ArrayMap<String, DeckEntity> _map) {
                    Set<String> setKeySet = _map.keySet();
/* 1212 */          if (setKeySet.isEmpty()) {
/* 1213 */              return;
                    }
/* 1215 */          if (_map.getSize() > 999) {
/* 1211 */              RelationUtil.recursiveFetchArrayMap(_map, false, new Function1() { // from class: com.xunji.flashcards.data.XunjiDao_Impl$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return XunjiDao_Impl.__fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity$lambda$0(this.f$0, _connection, (ArrayMap) obj);
                            }
                        });
/* 1219 */              return;
                    }
                    StringBuilder _stringBuilder = new StringBuilder();
/* 1222 */          _stringBuilder.append("SELECT `id`,`name`,`createdAt`,`updatedAt` FROM `decks` WHERE `id` IN (");
/* 1223 */          int _inputSize = setKeySet.size();
/* 1224 */          StringUtil.appendPlaceholders(_stringBuilder, _inputSize);
/* 1225 */          _stringBuilder.append(")");
/* 1226 */          String _sql = _stringBuilder.toString();
                    Intrinsics.checkNotNullExpressionValue(_sql, "toString(...)");
/* 1227 */          SQLiteStatement _stmt = _connection.prepare(_sql);
/* 1228 */          int _argIndex = 1;
                    for (String _item : setKeySet) {
/* 1230 */              _stmt.mo8756bindText(_argIndex, _item);
                        _argIndex++;
                    }
                    try {
/* 1234 */              int _itemKeyIndex = SQLiteStatementUtil.getColumnIndex(_stmt, "id");
/* 1235 */              if (_itemKeyIndex != -1) {
/* 1242 */                  while (_stmt.step()) {
/* 1244 */                      String _tmpKey = _stmt.getText(_itemKeyIndex);
/* 1245 */                      if (_map.containsKey(_tmpKey)) {
/* 1248 */                          String _tmpId = _stmt.getText(0);
/* 1250 */                          String _tmpName = _stmt.getText(1);
/* 1252 */                          long _tmpCreatedAt = _stmt.getLong(2);
/* 1254 */                          long _tmpUpdatedAt = _stmt.getLong(3);
/* 1255 */                          DeckEntity _item_1 = new DeckEntity(_tmpId, _tmpName, _tmpCreatedAt, _tmpUpdatedAt);
/* 1256 */                          _map.put(_tmpKey, _item_1);
                                }
                            }
/* 1260 */                  _stmt.close();
/* 1262 */                  return;
                        }
/* 1260 */              _stmt.close();
                    } catch (Throwable th) {
                        _stmt.close();
                        throw th;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 1216 */      public static final Unit __fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity$lambda$0(XunjiDao_Impl this$0, SQLiteConnection $_connection, ArrayMap _tmpMap) {
                    Intrinsics.checkNotNullParameter(_tmpMap, "_tmpMap");
/* 1217 */          this$0.__fetchRelationshipdecksAscomXunjiFlashcardsDataDeckEntity($_connection, _tmpMap);
/* 1218 */          return Unit.INSTANCE;
                }

                /* JADX INFO: compiled from: XunjiDao_Impl.kt */
                @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0010\u0010\u0004\u001a\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00060\u0005¨\u0006\u0007"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDao_Impl$Companion;", "", "<init>", "()V", "getRequiredConverters", "", "Lkotlin/reflect/KClass;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 1262 */      public static final class Companion {
/* 1263 */          private Companion() {
                    }

/* 1264 */          public final List<KClass<?>> getRequiredConverters() {
/* 1265 */              return CollectionsKt.emptyList();
                    }
                }
            }

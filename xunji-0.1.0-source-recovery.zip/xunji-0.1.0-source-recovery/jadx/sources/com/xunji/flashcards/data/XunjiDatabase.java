            package com.xunji.flashcards.data;

            import android.content.Context;
            import androidx.room.Room;
            import androidx.room.RoomDatabase;
            import androidx.room.migration.Migration;
            import androidx.sqlite.db.SupportSQLiteDatabase;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: XunjiDatabase.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b'\u0018\u0000 \b2\u00020\u0001:\u0001\bB\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H&J\b\u0010\u0006\u001a\u00020\u0007H&¨\u0006\t"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDatabase;", "Landroidx/room/RoomDatabase;", "<init>", "()V", "dao", "Lcom/xunji/flashcards/data/XunjiDao;", "ankiDao", "Lcom/xunji/flashcards/data/AnkiDao;", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */     public abstract class XunjiDatabase extends RoomDatabase {

                /* JADX INFO: renamed from: Companion, reason: from kotlin metadata */
                public static final Companion INSTANCE = new Companion();
                public static final int $stable = 8;
                private static final Migration MIGRATION_1_2 = new Migration() { // from class: com.xunji.flashcards.data.XunjiDatabase$Companion$MIGRATION_1_2$1
                    @Override // androidx.room.migration.Migration
/* 17 */            public void migrate(SupportSQLiteDatabase db) {
                        Intrinsics.checkNotNullParameter(db, "db");
/* 18 */                db.execSQL("CREATE TABLE IF NOT EXISTS `anki_models` (`id` TEXT NOT NULL, `sourceModelId` TEXT NOT NULL, `contentHash` TEXT NOT NULL, `name` TEXT NOT NULL, `kind` INTEGER NOT NULL, `originalStockKind` INTEGER NOT NULL, `fieldNames` TEXT NOT NULL, `templates` TEXT NOT NULL, `css` TEXT NOT NULL, PRIMARY KEY(`id`))");
/* 19 */                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_models_contentHash` ON `anki_models` (`contentHash`)");
/* 20 */                db.execSQL("CREATE TABLE IF NOT EXISTS `anki_notes` (`id` TEXT NOT NULL, `sourceGuid` TEXT NOT NULL, `modelId` TEXT NOT NULL, `fields` TEXT NOT NULL, `tags` TEXT NOT NULL, `mediaNamespace` TEXT NOT NULL, `revision` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`modelId`) REFERENCES `anki_models`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)");
/* 21 */                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_notes_sourceGuid` ON `anki_notes` (`sourceGuid`)");
/* 22 */                db.execSQL("CREATE INDEX IF NOT EXISTS `index_anki_notes_modelId` ON `anki_notes` (`modelId`)");
/* 23 */                db.execSQL("CREATE INDEX IF NOT EXISTS `index_anki_notes_mediaNamespace` ON `anki_notes` (`mediaNamespace`)");
/* 24 */                db.execSQL("CREATE TABLE IF NOT EXISTS `anki_cards` (`cardId` TEXT NOT NULL, `noteId` TEXT NOT NULL, `ordinal` INTEGER NOT NULL, PRIMARY KEY(`cardId`), FOREIGN KEY(`cardId`) REFERENCES `cards`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE, FOREIGN KEY(`noteId`) REFERENCES `anki_notes`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT)");
/* 25 */                db.execSQL("CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_cards_noteId_ordinal` ON `anki_cards` (`noteId`, `ordinal`)");
/* 26 */                db.execSQL("CREATE TABLE IF NOT EXISTS `anki_deck_sources` (`sourceDeckId` TEXT NOT NULL, `originalFullName` TEXT NOT NULL, `localDeckId` TEXT NOT NULL, PRIMARY KEY(`sourceDeckId`, `originalFullName`), FOREIGN KEY(`localDeckId`) REFERENCES `decks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE)");
/* 27 */                db.execSQL("CREATE INDEX IF NOT EXISTS `index_anki_deck_sources_localDeckId` ON `anki_deck_sources` (`localDeckId`)");
/* 28 */                db.execSQL("CREATE TABLE IF NOT EXISTS `anki_media` (`namespace` TEXT NOT NULL, `originalName` TEXT NOT NULL, `sha256` TEXT NOT NULL, `size` INTEGER NOT NULL, `mime` TEXT NOT NULL, PRIMARY KEY(`namespace`, `originalName`))");
/* 29 */                db.execSQL("CREATE INDEX IF NOT EXISTS `index_anki_media_sha256` ON `anki_media` (`sha256`)");
                    }
                };

                public abstract AnkiDao ankiDao();

                public abstract XunjiDao dao();

                /* JADX INFO: compiled from: XunjiDatabase.kt */
                @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u000e\u0010\b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDatabase$Companion;", "", "<init>", "()V", "MIGRATION_1_2", "Landroidx/room/migration/Migration;", "getMIGRATION_1_2", "()Landroidx/room/migration/Migration;", "open", "Lcom/xunji/flashcards/data/XunjiDatabase;", "context", "Landroid/content/Context;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */        public static final class Companion {
/* 14 */            private Companion() {
                    }

/* 15 */            public final Migration getMIGRATION_1_2() {
/* 10 */                return XunjiDatabase.MIGRATION_1_2;
                    }

/* 31 */            public final XunjiDatabase open(Context context) {
                        Intrinsics.checkNotNullParameter(context, "context");
                        return (XunjiDatabase) Room.databaseBuilder(context, XunjiDatabase.class, "xunji.db").addMigrations(getMIGRATION_1_2()).build();
                    }
                }
            }

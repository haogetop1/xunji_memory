            package com.xunji.flashcards.data;

            import androidx.autofill.HintConstants;
            import androidx.room.InvalidationTracker;
            import androidx.room.RoomMasterTable;
            import androidx.room.RoomOpenDelegate;
            import androidx.room.migration.AutoMigrationSpec;
            import androidx.room.migration.Migration;
            import androidx.room.util.DBUtil;
            import androidx.room.util.TableInfo;
            import androidx.sqlite.SQLite;
            import androidx.sqlite.SQLiteConnection;
            import java.util.ArrayList;
            import java.util.LinkedHashMap;
            import java.util.LinkedHashSet;
            import java.util.List;
            import java.util.Map;
            import java.util.Set;
            import kotlin.Lazy;
            import kotlin.LazyKt;
            import kotlin.Metadata;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Reflection;
            import kotlin.reflect.KClass;
            
            /* JADX INFO: compiled from: XunjiDatabase_Impl.kt */
            /* JADX INFO: loaded from: classes12.dex */
            @Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\"\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\t\u001a\u00020\nH\u0014J\b\u0010\u000b\u001a\u00020\fH\u0014J\b\u0010\r\u001a\u00020\u000eH\u0016J\"\u0010\u000f\u001a\u001c\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0011\u0012\u000e\u0012\f\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u00110\u00120\u0010H\u0014J\u0016\u0010\u0013\u001a\u0010\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u00110\u0014H\u0016J*\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00170\u00122\u001a\u0010\u0018\u001a\u0016\u0012\f\u0012\n\u0012\u0006\b\u0001\u0012\u00020\u00150\u0011\u0012\u0004\u0012\u00020\u00150\u0010H\u0016J\b\u0010\u0019\u001a\u00020\u0006H\u0016J\b\u0010\u001a\u001a\u00020\bH\u0016R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/data/XunjiDatabase_Impl;", "Lcom/xunji/flashcards/data/XunjiDatabase;", "<init>", "()V", "_xunjiDao", "Lkotlin/Lazy;", "Lcom/xunji/flashcards/data/XunjiDao;", "_ankiDao", "Lcom/xunji/flashcards/data/AnkiDao;", "createOpenDelegate", "Landroidx/room/RoomOpenDelegate;", "createInvalidationTracker", "Landroidx/room/InvalidationTracker;", "clearAllTables", "", "getRequiredTypeConverterClasses", "", "Lkotlin/reflect/KClass;", "", "getRequiredAutoMigrationSpecClasses", "", "Landroidx/room/migration/AutoMigrationSpec;", "createAutoMigrations", "Landroidx/room/migration/Migration;", "autoMigrationSpecs", "dao", "ankiDao", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 25 */    public final class XunjiDatabase_Impl extends XunjiDatabase {
                public static final int $stable = 8;
                private final Lazy<XunjiDao> _xunjiDao = LazyKt.lazy(new Function0() { // from class: com.xunji.flashcards.data.XunjiDatabase_Impl$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return XunjiDatabase_Impl._xunjiDao$lambda$0(this.f$0);
                    }
                });
                private final Lazy<AnkiDao> _ankiDao = LazyKt.lazy(new Function0() { // from class: com.xunji.flashcards.data.XunjiDatabase_Impl$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function0
                    public final Object invoke() {
                        return XunjiDatabase_Impl._ankiDao$lambda$0(this.f$0);
                    }
                });

                /* JADX INFO: Access modifiers changed from: private */
/* 30 */        public static final XunjiDao_Impl _xunjiDao$lambda$0(XunjiDatabase_Impl this$0) {
/* 31 */            return new XunjiDao_Impl(this$0);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final AnkiDao_Impl _ankiDao$lambda$0(XunjiDatabase_Impl this$0) {
/* 35 */            return new AnkiDao_Impl(this$0);
                }

                /* JADX INFO: Access modifiers changed from: protected */
                @Override // androidx.room.RoomDatabase
/* 38 */        public RoomOpenDelegate createOpenDelegate() {
/* 39 */            RoomOpenDelegate _openDelegate = new RoomOpenDelegate() { // from class: com.xunji.flashcards.data.XunjiDatabase_Impl$createOpenDelegate$_openDelegate$1
                        {
/* 39 */                    super(2, "577a6c2693a0760352be30c3cddbb99a", "0d3249a6fa94b43ced219fb4a70a9667");
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 40 */                public void createAllTables(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
/* 41 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `decks` (`id` TEXT NOT NULL, `name` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`))");
/* 42 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `cards` (`id` TEXT NOT NULL, `deckId` TEXT NOT NULL, `front` TEXT NOT NULL, `back` TEXT NOT NULL, `example` TEXT NOT NULL, `createdAt` INTEGER NOT NULL, `updatedAt` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`deckId`) REFERENCES `decks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
/* 43 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_cards_deckId` ON `cards` (`deckId`)");
/* 44 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `schedules` (`cardId` TEXT NOT NULL, `phase` TEXT NOT NULL, `step` INTEGER, `stability` REAL, `difficulty` REAL, `dueAt` INTEGER NOT NULL, `lastReviewAt` INTEGER, `firstReviewedAt` INTEGER, `revision` INTEGER NOT NULL, PRIMARY KEY(`cardId`), FOREIGN KEY(`cardId`) REFERENCES `cards`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
/* 45 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_schedules_dueAt` ON `schedules` (`dueAt`)");
/* 46 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_schedules_firstReviewedAt` ON `schedules` (`firstReviewedAt`)");
/* 47 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `review_logs` (`id` TEXT NOT NULL, `cardId` TEXT NOT NULL, `deckId` TEXT NOT NULL, `sessionId` TEXT NOT NULL, `rating` INTEGER NOT NULL, `reviewedAt` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, `beforeSchedule` TEXT NOT NULL, `afterSchedule` TEXT NOT NULL, `undoneAt` INTEGER, PRIMARY KEY(`id`), FOREIGN KEY(`cardId`) REFERENCES `cards`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`deckId`) REFERENCES `decks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
/* 48 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_review_logs_cardId` ON `review_logs` (`cardId`)");
/* 49 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_review_logs_deckId` ON `review_logs` (`deckId`)");
/* 50 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_review_logs_sessionId` ON `review_logs` (`sessionId`)");
/* 51 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_review_logs_reviewedAt` ON `review_logs` (`reviewedAt`)");
/* 52 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `settings` (`id` INTEGER NOT NULL, `newCardsPerDay` INTEGER NOT NULL, `themeMode` TEXT NOT NULL, `schemaVersion` INTEGER NOT NULL, PRIMARY KEY(`id`))");
/* 53 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `anki_models` (`id` TEXT NOT NULL, `sourceModelId` TEXT NOT NULL, `contentHash` TEXT NOT NULL, `name` TEXT NOT NULL, `kind` INTEGER NOT NULL, `originalStockKind` INTEGER NOT NULL, `fieldNames` TEXT NOT NULL, `templates` TEXT NOT NULL, `css` TEXT NOT NULL, PRIMARY KEY(`id`))");
/* 54 */                    SQLite.execSQL(connection, "CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_models_contentHash` ON `anki_models` (`contentHash`)");
/* 55 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `anki_notes` (`id` TEXT NOT NULL, `sourceGuid` TEXT NOT NULL, `modelId` TEXT NOT NULL, `fields` TEXT NOT NULL, `tags` TEXT NOT NULL, `mediaNamespace` TEXT NOT NULL, `revision` INTEGER NOT NULL, PRIMARY KEY(`id`), FOREIGN KEY(`modelId`) REFERENCES `anki_models`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )");
/* 56 */                    SQLite.execSQL(connection, "CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_notes_sourceGuid` ON `anki_notes` (`sourceGuid`)");
/* 57 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_anki_notes_modelId` ON `anki_notes` (`modelId`)");
/* 58 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_anki_notes_mediaNamespace` ON `anki_notes` (`mediaNamespace`)");
/* 59 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `anki_cards` (`cardId` TEXT NOT NULL, `noteId` TEXT NOT NULL, `ordinal` INTEGER NOT NULL, PRIMARY KEY(`cardId`), FOREIGN KEY(`cardId`) REFERENCES `cards`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , FOREIGN KEY(`noteId`) REFERENCES `anki_notes`(`id`) ON UPDATE NO ACTION ON DELETE RESTRICT )");
/* 60 */                    SQLite.execSQL(connection, "CREATE UNIQUE INDEX IF NOT EXISTS `index_anki_cards_noteId_ordinal` ON `anki_cards` (`noteId`, `ordinal`)");
/* 61 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `anki_deck_sources` (`sourceDeckId` TEXT NOT NULL, `originalFullName` TEXT NOT NULL, `localDeckId` TEXT NOT NULL, PRIMARY KEY(`sourceDeckId`, `originalFullName`), FOREIGN KEY(`localDeckId`) REFERENCES `decks`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE )");
/* 62 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_anki_deck_sources_localDeckId` ON `anki_deck_sources` (`localDeckId`)");
/* 63 */                    SQLite.execSQL(connection, "CREATE TABLE IF NOT EXISTS `anki_media` (`namespace` TEXT NOT NULL, `originalName` TEXT NOT NULL, `sha256` TEXT NOT NULL, `size` INTEGER NOT NULL, `mime` TEXT NOT NULL, PRIMARY KEY(`namespace`, `originalName`))");
/* 64 */                    SQLite.execSQL(connection, "CREATE INDEX IF NOT EXISTS `index_anki_media_sha256` ON `anki_media` (`sha256`)");
/* 65 */                    SQLite.execSQL(connection, RoomMasterTable.CREATE_QUERY);
/* 66 */                    SQLite.execSQL(connection, "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '577a6c2693a0760352be30c3cddbb99a')");
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 69 */                public void dropAllTables(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
/* 70 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `decks`");
/* 71 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `cards`");
/* 72 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `schedules`");
/* 73 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `review_logs`");
/* 74 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `settings`");
/* 75 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `anki_models`");
/* 76 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `anki_notes`");
/* 77 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `anki_cards`");
/* 78 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `anki_deck_sources`");
/* 79 */                    SQLite.execSQL(connection, "DROP TABLE IF EXISTS `anki_media`");
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 82 */                public void onCreate(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 85 */                public void onOpen(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
/* 86 */                    SQLite.execSQL(connection, "PRAGMA foreign_keys = ON");
/* 27 */                    this.this$0.internalInitInvalidationTracker(connection);
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 90 */                public void onPreMigrate(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
/* 91 */                    DBUtil.dropFtsSyncTriggers(connection);
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 94 */                public void onPostMigrate(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
                        }

                        @Override // androidx.room.RoomOpenDelegate
/* 97 */                public RoomOpenDelegate.ValidationResult onValidateSchema(SQLiteConnection connection) {
                            Intrinsics.checkNotNullParameter(connection, "connection");
/* 98 */                    Map _columnsDecks = new LinkedHashMap();
/* 99 */                    _columnsDecks.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
/* 100 */                   _columnsDecks.put(HintConstants.AUTOFILL_HINT_NAME, new TableInfo.Column(HintConstants.AUTOFILL_HINT_NAME, "TEXT", true, 0, null, 1));
/* 101 */                   _columnsDecks.put("createdAt", new TableInfo.Column("createdAt", "INTEGER", true, 0, null, 1));
/* 102 */                   _columnsDecks.put("updatedAt", new TableInfo.Column("updatedAt", "INTEGER", true, 0, null, 1));
/* 103 */                   Set _foreignKeysDecks = new LinkedHashSet();
/* 104 */                   Set _indicesDecks = new LinkedHashSet();
/* 105 */                   TableInfo _infoDecks = new TableInfo("decks", _columnsDecks, _foreignKeysDecks, _indicesDecks);
/* 106 */                   TableInfo _existingDecks = TableInfo.Companion.read(connection, "decks");
/* 107 */                   if (!_infoDecks.equals(_existingDecks)) {
/* 108 */                       return new RoomOpenDelegate.ValidationResult(false, "decks(com.xunji.flashcards.data.DeckEntity).\n Expected:\n" + _infoDecks + "\n Found:\n" + _existingDecks);
                            }
/* 116 */                   Map _columnsCards = new LinkedHashMap();
/* 117 */                   _columnsCards.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
/* 118 */                   _columnsCards.put("deckId", new TableInfo.Column("deckId", "TEXT", true, 0, null, 1));
/* 119 */                   _columnsCards.put("front", new TableInfo.Column("front", "TEXT", true, 0, null, 1));
/* 120 */                   _columnsCards.put("back", new TableInfo.Column("back", "TEXT", true, 0, null, 1));
/* 121 */                   _columnsCards.put("example", new TableInfo.Column("example", "TEXT", true, 0, null, 1));
/* 122 */                   _columnsCards.put("createdAt", new TableInfo.Column("createdAt", "INTEGER", true, 0, null, 1));
/* 123 */                   _columnsCards.put("updatedAt", new TableInfo.Column("updatedAt", "INTEGER", true, 0, null, 1));
/* 124 */                   Set _foreignKeysCards = new LinkedHashSet();
/* 125 */                   _foreignKeysCards.add(new TableInfo.ForeignKey("decks", "CASCADE", "NO ACTION", CollectionsKt.listOf("deckId"), CollectionsKt.listOf("id")));
/* 126 */                   Set _indicesCards = new LinkedHashSet();
/* 127 */                   _indicesCards.add(new TableInfo.Index("index_cards_deckId", false, CollectionsKt.listOf("deckId"), CollectionsKt.listOf("ASC")));
/* 128 */                   TableInfo _infoCards = new TableInfo("cards", _columnsCards, _foreignKeysCards, _indicesCards);
/* 129 */                   TableInfo _existingCards = TableInfo.Companion.read(connection, "cards");
/* 130 */                   if (!_infoCards.equals(_existingCards)) {
/* 131 */                       return new RoomOpenDelegate.ValidationResult(false, "cards(com.xunji.flashcards.data.CardEntity).\n Expected:\n" + _infoCards + "\n Found:\n" + _existingCards);
                            }
/* 139 */                   Map _columnsSchedules = new LinkedHashMap();
/* 140 */                   _columnsSchedules.put("cardId", new TableInfo.Column("cardId", "TEXT", true, 1, null, 1));
/* 141 */                   _columnsSchedules.put("phase", new TableInfo.Column("phase", "TEXT", true, 0, null, 1));
/* 142 */                   _columnsSchedules.put("step", new TableInfo.Column("step", "INTEGER", false, 0, null, 1));
/* 143 */                   _columnsSchedules.put("stability", new TableInfo.Column("stability", "REAL", false, 0, null, 1));
/* 144 */                   _columnsSchedules.put("difficulty", new TableInfo.Column("difficulty", "REAL", false, 0, null, 1));
/* 145 */                   _columnsSchedules.put("dueAt", new TableInfo.Column("dueAt", "INTEGER", true, 0, null, 1));
/* 146 */                   _columnsSchedules.put("lastReviewAt", new TableInfo.Column("lastReviewAt", "INTEGER", false, 0, null, 1));
/* 147 */                   _columnsSchedules.put("firstReviewedAt", new TableInfo.Column("firstReviewedAt", "INTEGER", false, 0, null, 1));
/* 148 */                   _columnsSchedules.put("revision", new TableInfo.Column("revision", "INTEGER", true, 0, null, 1));
/* 149 */                   Set _foreignKeysSchedules = new LinkedHashSet();
/* 150 */                   _foreignKeysSchedules.add(new TableInfo.ForeignKey("cards", "CASCADE", "NO ACTION", CollectionsKt.listOf("cardId"), CollectionsKt.listOf("id")));
/* 151 */                   Set _indicesSchedules = new LinkedHashSet();
                            _indicesSchedules.add(new TableInfo.Index("index_schedules_dueAt", false, CollectionsKt.listOf("dueAt"), CollectionsKt.listOf("ASC")));
/* 153 */                   _indicesSchedules.add(new TableInfo.Index("index_schedules_firstReviewedAt", false, CollectionsKt.listOf("firstReviewedAt"), CollectionsKt.listOf("ASC")));
/* 154 */                   TableInfo _infoSchedules = new TableInfo("schedules", _columnsSchedules, _foreignKeysSchedules, _indicesSchedules);
/* 155 */                   TableInfo _existingSchedules = TableInfo.Companion.read(connection, "schedules");
/* 156 */                   if (!_infoSchedules.equals(_existingSchedules)) {
/* 157 */                       return new RoomOpenDelegate.ValidationResult(false, "schedules(com.xunji.flashcards.data.ScheduleEntity).\n Expected:\n" + _infoSchedules + "\n Found:\n" + _existingSchedules);
                            }
/* 165 */                   Map _columnsReviewLogs = new LinkedHashMap();
/* 166 */                   _columnsReviewLogs.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
/* 167 */                   _columnsReviewLogs.put("cardId", new TableInfo.Column("cardId", "TEXT", true, 0, null, 1));
/* 168 */                   _columnsReviewLogs.put("deckId", new TableInfo.Column("deckId", "TEXT", true, 0, null, 1));
/* 169 */                   _columnsReviewLogs.put("sessionId", new TableInfo.Column("sessionId", "TEXT", true, 0, null, 1));
/* 170 */                   _columnsReviewLogs.put("rating", new TableInfo.Column("rating", "INTEGER", true, 0, null, 1));
/* 171 */                   _columnsReviewLogs.put("reviewedAt", new TableInfo.Column("reviewedAt", "INTEGER", true, 0, null, 1));
/* 172 */                   _columnsReviewLogs.put("durationMs", new TableInfo.Column("durationMs", "INTEGER", true, 0, null, 1));
/* 173 */                   _columnsReviewLogs.put("beforeSchedule", new TableInfo.Column("beforeSchedule", "TEXT", true, 0, null, 1));
/* 174 */                   _columnsReviewLogs.put("afterSchedule", new TableInfo.Column("afterSchedule", "TEXT", true, 0, null, 1));
/* 175 */                   _columnsReviewLogs.put("undoneAt", new TableInfo.Column("undoneAt", "INTEGER", false, 0, null, 1));
/* 176 */                   Set _foreignKeysReviewLogs = new LinkedHashSet();
/* 177 */                   _foreignKeysReviewLogs.add(new TableInfo.ForeignKey("cards", "CASCADE", "NO ACTION", CollectionsKt.listOf("cardId"), CollectionsKt.listOf("id")));
/* 178 */                   _foreignKeysReviewLogs.add(new TableInfo.ForeignKey("decks", "CASCADE", "NO ACTION", CollectionsKt.listOf("deckId"), CollectionsKt.listOf("id")));
/* 179 */                   Set _indicesReviewLogs = new LinkedHashSet();
                            _indicesReviewLogs.add(new TableInfo.Index("index_review_logs_cardId", false, CollectionsKt.listOf("cardId"), CollectionsKt.listOf("ASC")));
/* 181 */                   _indicesReviewLogs.add(new TableInfo.Index("index_review_logs_deckId", false, CollectionsKt.listOf("deckId"), CollectionsKt.listOf("ASC")));
/* 182 */                   _indicesReviewLogs.add(new TableInfo.Index("index_review_logs_sessionId", false, CollectionsKt.listOf("sessionId"), CollectionsKt.listOf("ASC")));
/* 183 */                   _indicesReviewLogs.add(new TableInfo.Index("index_review_logs_reviewedAt", false, CollectionsKt.listOf("reviewedAt"), CollectionsKt.listOf("ASC")));
/* 184 */                   TableInfo _infoReviewLogs = new TableInfo("review_logs", _columnsReviewLogs, _foreignKeysReviewLogs, _indicesReviewLogs);
/* 185 */                   TableInfo _existingReviewLogs = TableInfo.Companion.read(connection, "review_logs");
/* 186 */                   if (!_infoReviewLogs.equals(_existingReviewLogs)) {
/* 187 */                       return new RoomOpenDelegate.ValidationResult(false, "review_logs(com.xunji.flashcards.data.ReviewLogEntity).\n Expected:\n" + _infoReviewLogs + "\n Found:\n" + _existingReviewLogs);
                            }
/* 195 */                   Map _columnsSettings = new LinkedHashMap();
/* 196 */                   _columnsSettings.put("id", new TableInfo.Column("id", "INTEGER", true, 1, null, 1));
/* 197 */                   _columnsSettings.put("newCardsPerDay", new TableInfo.Column("newCardsPerDay", "INTEGER", true, 0, null, 1));
/* 198 */                   _columnsSettings.put("themeMode", new TableInfo.Column("themeMode", "TEXT", true, 0, null, 1));
/* 199 */                   _columnsSettings.put("schemaVersion", new TableInfo.Column("schemaVersion", "INTEGER", true, 0, null, 1));
/* 200 */                   Set _foreignKeysSettings = new LinkedHashSet();
/* 201 */                   Set _indicesSettings = new LinkedHashSet();
/* 202 */                   TableInfo _infoSettings = new TableInfo("settings", _columnsSettings, _foreignKeysSettings, _indicesSettings);
/* 203 */                   TableInfo _existingSettings = TableInfo.Companion.read(connection, "settings");
/* 204 */                   if (!_infoSettings.equals(_existingSettings)) {
/* 205 */                       return new RoomOpenDelegate.ValidationResult(false, "settings(com.xunji.flashcards.data.SettingsEntity).\n Expected:\n" + _infoSettings + "\n Found:\n" + _existingSettings);
                            }
/* 213 */                   Map _columnsAnkiModels = new LinkedHashMap();
/* 214 */                   _columnsAnkiModels.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
/* 215 */                   _columnsAnkiModels.put("sourceModelId", new TableInfo.Column("sourceModelId", "TEXT", true, 0, null, 1));
/* 216 */                   _columnsAnkiModels.put("contentHash", new TableInfo.Column("contentHash", "TEXT", true, 0, null, 1));
/* 217 */                   _columnsAnkiModels.put(HintConstants.AUTOFILL_HINT_NAME, new TableInfo.Column(HintConstants.AUTOFILL_HINT_NAME, "TEXT", true, 0, null, 1));
/* 218 */                   _columnsAnkiModels.put("kind", new TableInfo.Column("kind", "INTEGER", true, 0, null, 1));
/* 219 */                   _columnsAnkiModels.put("originalStockKind", new TableInfo.Column("originalStockKind", "INTEGER", true, 0, null, 1));
/* 220 */                   _columnsAnkiModels.put("fieldNames", new TableInfo.Column("fieldNames", "TEXT", true, 0, null, 1));
/* 221 */                   _columnsAnkiModels.put("templates", new TableInfo.Column("templates", "TEXT", true, 0, null, 1));
/* 222 */                   _columnsAnkiModels.put("css", new TableInfo.Column("css", "TEXT", true, 0, null, 1));
/* 223 */                   Set _foreignKeysAnkiModels = new LinkedHashSet();
/* 224 */                   Set _indicesAnkiModels = new LinkedHashSet();
/* 225 */                   _indicesAnkiModels.add(new TableInfo.Index("index_anki_models_contentHash", true, CollectionsKt.listOf("contentHash"), CollectionsKt.listOf("ASC")));
/* 226 */                   TableInfo _infoAnkiModels = new TableInfo("anki_models", _columnsAnkiModels, _foreignKeysAnkiModels, _indicesAnkiModels);
/* 227 */                   TableInfo _existingAnkiModels = TableInfo.Companion.read(connection, "anki_models");
/* 228 */                   if (!_infoAnkiModels.equals(_existingAnkiModels)) {
/* 229 */                       return new RoomOpenDelegate.ValidationResult(false, "anki_models(com.xunji.flashcards.data.AnkiModelEntity).\n Expected:\n" + _infoAnkiModels + "\n Found:\n" + _existingAnkiModels);
                            }
/* 237 */                   Map _columnsAnkiNotes = new LinkedHashMap();
/* 238 */                   _columnsAnkiNotes.put("id", new TableInfo.Column("id", "TEXT", true, 1, null, 1));
/* 239 */                   _columnsAnkiNotes.put("sourceGuid", new TableInfo.Column("sourceGuid", "TEXT", true, 0, null, 1));
/* 240 */                   _columnsAnkiNotes.put("modelId", new TableInfo.Column("modelId", "TEXT", true, 0, null, 1));
/* 241 */                   _columnsAnkiNotes.put("fields", new TableInfo.Column("fields", "TEXT", true, 0, null, 1));
/* 242 */                   _columnsAnkiNotes.put("tags", new TableInfo.Column("tags", "TEXT", true, 0, null, 1));
/* 243 */                   _columnsAnkiNotes.put("mediaNamespace", new TableInfo.Column("mediaNamespace", "TEXT", true, 0, null, 1));
/* 244 */                   _columnsAnkiNotes.put("revision", new TableInfo.Column("revision", "INTEGER", true, 0, null, 1));
/* 245 */                   Set _foreignKeysAnkiNotes = new LinkedHashSet();
/* 246 */                   _foreignKeysAnkiNotes.add(new TableInfo.ForeignKey("anki_models", "RESTRICT", "NO ACTION", CollectionsKt.listOf("modelId"), CollectionsKt.listOf("id")));
/* 247 */                   Set _indicesAnkiNotes = new LinkedHashSet();
/* 248 */                   _indicesAnkiNotes.add(new TableInfo.Index("index_anki_notes_sourceGuid", true, CollectionsKt.listOf("sourceGuid"), CollectionsKt.listOf("ASC")));
/* 249 */                   _indicesAnkiNotes.add(new TableInfo.Index("index_anki_notes_modelId", false, CollectionsKt.listOf("modelId"), CollectionsKt.listOf("ASC")));
/* 250 */                   _indicesAnkiNotes.add(new TableInfo.Index("index_anki_notes_mediaNamespace", false, CollectionsKt.listOf("mediaNamespace"), CollectionsKt.listOf("ASC")));
/* 251 */                   TableInfo _infoAnkiNotes = new TableInfo("anki_notes", _columnsAnkiNotes, _foreignKeysAnkiNotes, _indicesAnkiNotes);
/* 252 */                   TableInfo _existingAnkiNotes = TableInfo.Companion.read(connection, "anki_notes");
/* 253 */                   if (!_infoAnkiNotes.equals(_existingAnkiNotes)) {
/* 254 */                       return new RoomOpenDelegate.ValidationResult(false, "anki_notes(com.xunji.flashcards.data.AnkiNoteEntity).\n Expected:\n" + _infoAnkiNotes + "\n Found:\n" + _existingAnkiNotes);
                            }
/* 262 */                   Map _columnsAnkiCards = new LinkedHashMap();
/* 263 */                   _columnsAnkiCards.put("cardId", new TableInfo.Column("cardId", "TEXT", true, 1, null, 1));
/* 264 */                   _columnsAnkiCards.put("noteId", new TableInfo.Column("noteId", "TEXT", true, 0, null, 1));
/* 265 */                   _columnsAnkiCards.put("ordinal", new TableInfo.Column("ordinal", "INTEGER", true, 0, null, 1));
/* 266 */                   Set _foreignKeysAnkiCards = new LinkedHashSet();
/* 267 */                   _foreignKeysAnkiCards.add(new TableInfo.ForeignKey("cards", "CASCADE", "NO ACTION", CollectionsKt.listOf("cardId"), CollectionsKt.listOf("id")));
/* 268 */                   _foreignKeysAnkiCards.add(new TableInfo.ForeignKey("anki_notes", "RESTRICT", "NO ACTION", CollectionsKt.listOf("noteId"), CollectionsKt.listOf("id")));
/* 269 */                   Set _indicesAnkiCards = new LinkedHashSet();
/* 270 */                   _indicesAnkiCards.add(new TableInfo.Index("index_anki_cards_noteId_ordinal", true, CollectionsKt.listOf((Object[]) new String[]{"noteId", "ordinal"}), CollectionsKt.listOf((Object[]) new String[]{"ASC", "ASC"})));
/* 271 */                   TableInfo _infoAnkiCards = new TableInfo("anki_cards", _columnsAnkiCards, _foreignKeysAnkiCards, _indicesAnkiCards);
/* 272 */                   TableInfo _existingAnkiCards = TableInfo.Companion.read(connection, "anki_cards");
/* 273 */                   if (!_infoAnkiCards.equals(_existingAnkiCards)) {
/* 274 */                       return new RoomOpenDelegate.ValidationResult(false, "anki_cards(com.xunji.flashcards.data.AnkiCardEntity).\n Expected:\n" + _infoAnkiCards + "\n Found:\n" + _existingAnkiCards);
                            }
/* 282 */                   Map _columnsAnkiDeckSources = new LinkedHashMap();
/* 283 */                   _columnsAnkiDeckSources.put("sourceDeckId", new TableInfo.Column("sourceDeckId", "TEXT", true, 1, null, 1));
/* 284 */                   _columnsAnkiDeckSources.put("originalFullName", new TableInfo.Column("originalFullName", "TEXT", true, 2, null, 1));
/* 285 */                   _columnsAnkiDeckSources.put("localDeckId", new TableInfo.Column("localDeckId", "TEXT", true, 0, null, 1));
/* 286 */                   Set _foreignKeysAnkiDeckSources = new LinkedHashSet();
/* 287 */                   _foreignKeysAnkiDeckSources.add(new TableInfo.ForeignKey("decks", "CASCADE", "NO ACTION", CollectionsKt.listOf("localDeckId"), CollectionsKt.listOf("id")));
/* 288 */                   Set _indicesAnkiDeckSources = new LinkedHashSet();
                            _indicesAnkiDeckSources.add(new TableInfo.Index("index_anki_deck_sources_localDeckId", false, CollectionsKt.listOf("localDeckId"), CollectionsKt.listOf("ASC")));
/* 290 */                   TableInfo _infoAnkiDeckSources = new TableInfo("anki_deck_sources", _columnsAnkiDeckSources, _foreignKeysAnkiDeckSources, _indicesAnkiDeckSources);
/* 291 */                   TableInfo _existingAnkiDeckSources = TableInfo.Companion.read(connection, "anki_deck_sources");
/* 292 */                   if (!_infoAnkiDeckSources.equals(_existingAnkiDeckSources)) {
/* 293 */                       return new RoomOpenDelegate.ValidationResult(false, "anki_deck_sources(com.xunji.flashcards.data.AnkiDeckSourceEntity).\n Expected:\n" + _infoAnkiDeckSources + "\n Found:\n" + _existingAnkiDeckSources);
                            }
/* 301 */                   Map _columnsAnkiMedia = new LinkedHashMap();
/* 302 */                   _columnsAnkiMedia.put("namespace", new TableInfo.Column("namespace", "TEXT", true, 1, null, 1));
/* 303 */                   _columnsAnkiMedia.put("originalName", new TableInfo.Column("originalName", "TEXT", true, 2, null, 1));
/* 304 */                   _columnsAnkiMedia.put("sha256", new TableInfo.Column("sha256", "TEXT", true, 0, null, 1));
/* 305 */                   _columnsAnkiMedia.put("size", new TableInfo.Column("size", "INTEGER", true, 0, null, 1));
/* 306 */                   _columnsAnkiMedia.put("mime", new TableInfo.Column("mime", "TEXT", true, 0, null, 1));
/* 307 */                   Set _foreignKeysAnkiMedia = new LinkedHashSet();
/* 308 */                   Set _indicesAnkiMedia = new LinkedHashSet();
                            _indicesAnkiMedia.add(new TableInfo.Index("index_anki_media_sha256", false, CollectionsKt.listOf("sha256"), CollectionsKt.listOf("ASC")));
/* 310 */                   TableInfo _infoAnkiMedia = new TableInfo("anki_media", _columnsAnkiMedia, _foreignKeysAnkiMedia, _indicesAnkiMedia);
/* 311 */                   TableInfo _existingAnkiMedia = TableInfo.Companion.read(connection, "anki_media");
/* 312 */                   if (!_infoAnkiMedia.equals(_existingAnkiMedia)) {
/* 313 */                       return new RoomOpenDelegate.ValidationResult(false, "anki_media(com.xunji.flashcards.data.AnkiMediaEntity).\n Expected:\n" + _infoAnkiMedia + "\n Found:\n" + _existingAnkiMedia);
                            }
/* 321 */                   return new RoomOpenDelegate.ValidationResult(true, null);
                        }
                    };
/* 324 */           return _openDelegate;
                }

                @Override // androidx.room.RoomDatabase
/* 327 */       protected InvalidationTracker createInvalidationTracker() {
/* 328 */           Map _shadowTablesMap = new LinkedHashMap();
/* 329 */           Map _viewTables = new LinkedHashMap();
/* 330 */           return new InvalidationTracker(this, _shadowTablesMap, _viewTables, "decks", "cards", "schedules", "review_logs", "settings", "anki_models", "anki_notes", "anki_cards", "anki_deck_sources", "anki_media");
                }

                @Override // androidx.room.RoomDatabase
/* 333 */       public void clearAllTables() {
/* 334 */           super.performClear(true, "decks", "cards", "schedules", "review_logs", "settings", "anki_cards", "anki_notes", "anki_models", "anki_deck_sources", "anki_media");
                }

                @Override // androidx.room.RoomDatabase
/* 337 */       protected Map<KClass<?>, List<KClass<?>>> getRequiredTypeConverterClasses() {
/* 338 */           Map _typeConvertersMap = new LinkedHashMap();
/* 339 */           _typeConvertersMap.put(Reflection.getOrCreateKotlinClass(XunjiDao.class), XunjiDao_Impl.INSTANCE.getRequiredConverters());
/* 340 */           _typeConvertersMap.put(Reflection.getOrCreateKotlinClass(AnkiDao.class), AnkiDao_Impl.INSTANCE.getRequiredConverters());
/* 341 */           return _typeConvertersMap;
                }

                @Override // androidx.room.RoomDatabase
/* 344 */       public Set<KClass<? extends AutoMigrationSpec>> getRequiredAutoMigrationSpecClasses() {
/* 345 */           Set _autoMigrationSpecsSet = new LinkedHashSet();
/* 346 */           return _autoMigrationSpecsSet;
                }

                @Override // androidx.room.RoomDatabase
/* 349 */       public List<Migration> createAutoMigrations(Map<KClass<? extends AutoMigrationSpec>, ? extends AutoMigrationSpec> autoMigrationSpecs) {
                    Intrinsics.checkNotNullParameter(autoMigrationSpecs, "autoMigrationSpecs");
/* 350 */           List _autoMigrations = new ArrayList();
/* 351 */           return _autoMigrations;
                }

                @Override // com.xunji.flashcards.data.XunjiDatabase
/* 353 */       public XunjiDao dao() {
/* 354 */           return getValue();
                }

                @Override // com.xunji.flashcards.data.XunjiDatabase
/* 355 */       public AnkiDao ankiDao() {
/* 356 */           return getValue();
                }
            }

            package com.xunji.flashcards.study;

            import com.xunji.core.model.Rating;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ReviewCommands.kt */
            /* JADX INFO: loaded from: classes9.dex */
            @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\u0006\u0010\b\u001a\u00020\t\u0012\u0006\u0010\n\u001a\u00020\u0007¢\u0006\u0004\b\u000b\u0010\fJ\t\u0010\u0016\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0017\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0007HÆ\u0003J\t\u0010\u001a\u001a\u00020\tHÆ\u0003J\t\u0010\u001b\u001a\u00020\u0007HÆ\u0003JE\u0010\u001c\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\t2\b\b\u0002\u0010\n\u001a\u00020\u0007HÆ\u0001J\u0013\u0010\u001d\u001a\u00020\u001e2\b\u0010\u001f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010 \u001a\u00020!HÖ\u0001J\t\u0010\"\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u0012R\u0011\u0010\b\u001a\u00020\t¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u0014R\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0012¨\u0006#"}, d2 = {"Lcom/xunji/flashcards/study/GradeCommand;", "", "operationId", "", "sessionId", "cardId", "expectedRevision", "", "rating", "Lcom/xunji/core/model/Rating;", "durationMs", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLcom/xunji/core/model/Rating;J)V", "getOperationId", "()Ljava/lang/String;", "getSessionId", "getCardId", "getExpectedRevision", "()J", "getRating", "()Lcom/xunji/core/model/Rating;", "getDurationMs", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 3 */     public final /* data */ class GradeCommand {
                public static final int $stable = 0;
                private final String cardId;
                private final long durationMs;
                private final long expectedRevision;
                private final String operationId;
                private final Rating rating;
                private final String sessionId;

                public static /* synthetic */ GradeCommand copy$default(GradeCommand gradeCommand, String str, String str2, String str3, long j, Rating rating, long j2, int i, Object obj) {
                    if ((i & 1) != 0) {
                        str = gradeCommand.operationId;
                    }
                    if ((i & 2) != 0) {
                        str2 = gradeCommand.sessionId;
                    }
                    if ((i & 4) != 0) {
                        str3 = gradeCommand.cardId;
                    }
                    if ((i & 8) != 0) {
                        j = gradeCommand.expectedRevision;
                    }
                    if ((i & 16) != 0) {
                        rating = gradeCommand.rating;
                    }
                    if ((i & 32) != 0) {
                        j2 = gradeCommand.durationMs;
                    }
                    Rating rating2 = rating;
                    long j3 = j;
                    String str4 = str3;
                    return gradeCommand.copy(str, str2, str4, j3, rating2, j2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getOperationId() {
                    return this.operationId;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getSessionId() {
                    return this.sessionId;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getCardId() {
                    return this.cardId;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final long getExpectedRevision() {
                    return this.expectedRevision;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final Rating getRating() {
                    return this.rating;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final long getDurationMs() {
                    return this.durationMs;
                }

                public final GradeCommand copy(String operationId, String sessionId, String cardId, long expectedRevision, Rating rating, long durationMs) {
                    Intrinsics.checkNotNullParameter(operationId, "operationId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(rating, "rating");
                    return new GradeCommand(operationId, sessionId, cardId, expectedRevision, rating, durationMs);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof GradeCommand)) {
                        return false;
                    }
                    GradeCommand gradeCommand = (GradeCommand) other;
                    return Intrinsics.areEqual(this.operationId, gradeCommand.operationId) && Intrinsics.areEqual(this.sessionId, gradeCommand.sessionId) && Intrinsics.areEqual(this.cardId, gradeCommand.cardId) && this.expectedRevision == gradeCommand.expectedRevision && this.rating == gradeCommand.rating && this.durationMs == gradeCommand.durationMs;
                }

                public int hashCode() {
                    return (((((((((this.operationId.hashCode() * 31) + this.sessionId.hashCode()) * 31) + this.cardId.hashCode()) * 31) + Long.hashCode(this.expectedRevision)) * 31) + this.rating.hashCode()) * 31) + Long.hashCode(this.durationMs);
                }

                public String toString() {
                    return "GradeCommand(operationId=" + this.operationId + ", sessionId=" + this.sessionId + ", cardId=" + this.cardId + ", expectedRevision=" + this.expectedRevision + ", rating=" + this.rating + ", durationMs=" + this.durationMs + ")";
                }

/* 4 */         public GradeCommand(String operationId, String sessionId, String cardId, long expectedRevision, Rating rating, long durationMs) {
                    Intrinsics.checkNotNullParameter(operationId, "operationId");
                    Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                    Intrinsics.checkNotNullParameter(cardId, "cardId");
                    Intrinsics.checkNotNullParameter(rating, "rating");
                    this.operationId = operationId;
                    this.sessionId = sessionId;
                    this.cardId = cardId;
                    this.expectedRevision = expectedRevision;
                    this.rating = rating;
                    this.durationMs = durationMs;
                }

/* 4 */         public final String getCardId() {
/* 5 */             return this.cardId;
                }

/* 4 */         public final long getDurationMs() {
/* 5 */             return this.durationMs;
                }

/* 4 */         public final long getExpectedRevision() {
/* 5 */             return this.expectedRevision;
                }

/* 4 */         public final String getOperationId() {
/* 5 */             return this.operationId;
                }

/* 4 */         public final Rating getRating() {
/* 5 */             return this.rating;
                }

/* 4 */         public final String getSessionId() {
/* 5 */             return this.sessionId;
                }
            }

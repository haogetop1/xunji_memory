            package com.xunji.flashcards.study;

            import com.xunji.core.model.ReviewLog;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ReviewCommands.kt */
            /* JADX INFO: loaded from: classes9.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0006\u0002\u0003\u0004\u0005\u0006\u0007\u0082\u0001\u0006\b\t\n\u000b\f\r¨\u0006\u000eÀ\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult;", "", "Recorded", "Duplicate", "MissingCard", "StaleSchedule", "QuotaReached", "InvalidCommand", "Lcom/xunji/flashcards/study/GradeResult$Duplicate;", "Lcom/xunji/flashcards/study/GradeResult$InvalidCommand;", "Lcom/xunji/flashcards/study/GradeResult$MissingCard;", "Lcom/xunji/flashcards/study/GradeResult$QuotaReached;", "Lcom/xunji/flashcards/study/GradeResult$Recorded;", "Lcom/xunji/flashcards/study/GradeResult$StaleSchedule;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 4 */     public interface GradeResult {

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$Recorded;", "Lcom/xunji/flashcards/study/GradeResult;", "log", "Lcom/xunji/core/model/ReviewLog;", "<init>", "(Lcom/xunji/core/model/ReviewLog;)V", "getLog", "()Lcom/xunji/core/model/ReviewLog;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 5 */         public static final /* data */ class Recorded implements GradeResult {
                    public static final int $stable = 8;
                    private final ReviewLog log;

                    public static /* synthetic */ Recorded copy$default(Recorded recorded, ReviewLog reviewLog, int i, Object obj) {
                        if ((i & 1) != 0) {
                            reviewLog = recorded.log;
                        }
                        return recorded.copy(reviewLog);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final ReviewLog getLog() {
                        return this.log;
                    }

                    public final Recorded copy(ReviewLog log) {
                        Intrinsics.checkNotNullParameter(log, "log");
                        return new Recorded(log);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Recorded) && Intrinsics.areEqual(this.log, ((Recorded) other).log);
                    }

                    public int hashCode() {
                        return this.log.hashCode();
                    }

                    public String toString() {
                        return "Recorded(log=" + this.log + ")";
                    }

/* 6 */             public Recorded(ReviewLog log) {
                        Intrinsics.checkNotNullParameter(log, "log");
                        this.log = log;
                    }

/* 6 */             public final ReviewLog getLog() {
/* 7 */                 return this.log;
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$Duplicate;", "Lcom/xunji/flashcards/study/GradeResult;", "log", "Lcom/xunji/core/model/ReviewLog;", "<init>", "(Lcom/xunji/core/model/ReviewLog;)V", "getLog", "()Lcom/xunji/core/model/ReviewLog;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */         public static final /* data */ class Duplicate implements GradeResult {
                    public static final int $stable = 8;
                    private final ReviewLog log;

                    public static /* synthetic */ Duplicate copy$default(Duplicate duplicate, ReviewLog reviewLog, int i, Object obj) {
                        if ((i & 1) != 0) {
                            reviewLog = duplicate.log;
                        }
                        return duplicate.copy(reviewLog);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final ReviewLog getLog() {
                        return this.log;
                    }

                    public final Duplicate copy(ReviewLog log) {
                        Intrinsics.checkNotNullParameter(log, "log");
                        return new Duplicate(log);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Duplicate) && Intrinsics.areEqual(this.log, ((Duplicate) other).log);
                    }

                    public int hashCode() {
                        return this.log.hashCode();
                    }

                    public String toString() {
                        return "Duplicate(log=" + this.log + ")";
                    }

/* 7 */             public Duplicate(ReviewLog log) {
                        Intrinsics.checkNotNullParameter(log, "log");
                        this.log = log;
                    }

/* 7 */             public final ReviewLog getLog() {
/* 8 */                 return this.log;
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$MissingCard;", "Lcom/xunji/flashcards/study/GradeResult;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */         public static final /* data */ class MissingCard implements GradeResult {
                    public static final int $stable = 0;
                    public static final MissingCard INSTANCE = new MissingCard();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof MissingCard)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return -1903082745;
                    }

                    public String toString() {
                        return "MissingCard";
                    }

/* 8 */             private MissingCard() {
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$StaleSchedule;", "Lcom/xunji/flashcards/study/GradeResult;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */         public static final /* data */ class StaleSchedule implements GradeResult {
                    public static final int $stable = 0;
                    public static final StaleSchedule INSTANCE = new StaleSchedule();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof StaleSchedule)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 450195073;
                    }

                    public String toString() {
                        return "StaleSchedule";
                    }

/* 9 */             private StaleSchedule() {
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$QuotaReached;", "Lcom/xunji/flashcards/study/GradeResult;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */         public static final /* data */ class QuotaReached implements GradeResult {
                    public static final int $stable = 0;
                    public static final QuotaReached INSTANCE = new QuotaReached();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof QuotaReached)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 372945001;
                    }

                    public String toString() {
                        return "QuotaReached";
                    }

/* 10 */            private QuotaReached() {
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/study/GradeResult$InvalidCommand;", "Lcom/xunji/flashcards/study/GradeResult;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 10 */        public static final /* data */ class InvalidCommand implements GradeResult {
                    public static final int $stable = 0;
                    public static final InvalidCommand INSTANCE = new InvalidCommand();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof InvalidCommand)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 1373960771;
                    }

                    public String toString() {
                        return "InvalidCommand";
                    }

/* 11 */            private InvalidCommand() {
                    }
                }
            }

            package com.xunji.flashcards.study;

            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            
            /* JADX INFO: compiled from: ReviewActions.kt */
            /* JADX INFO: loaded from: classes9.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J\u0016\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u0005H¦@¢\u0006\u0002\u0010\u0006J\u001e\u0010\u0007\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nH¦@¢\u0006\u0002\u0010\f¨\u0006\rÀ\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/study/ReviewActions;", "", "grade", "Lcom/xunji/flashcards/study/GradeResult;", "command", "Lcom/xunji/flashcards/study/GradeCommand;", "(Lcom/xunji/flashcards/study/GradeCommand;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "undo", "Lcom/xunji/flashcards/study/UndoResult;", "sessionId", "", "logId", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
            public interface ReviewActions {
                Object grade(GradeCommand gradeCommand, Continuation<? super GradeResult> continuation);

                Object undo(String str, String str2, Continuation<? super UndoResult> continuation);
            }

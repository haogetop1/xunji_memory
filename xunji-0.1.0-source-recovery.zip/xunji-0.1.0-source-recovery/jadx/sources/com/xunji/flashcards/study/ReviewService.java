            package com.xunji.flashcards.study;

            import androidx.core.view.MotionEventCompat;
            import androidx.room.RoomDatabaseKt;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.Rating;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.model.ThemeMode;
            import com.xunji.core.scheduling.Scheduler;
            import com.xunji.core.study.NewCardQuota;
            import com.xunji.flashcards.data.CardEntity;
            import com.xunji.flashcards.data.EntityMappersKt;
            import com.xunji.flashcards.data.ReviewLogEntity;
            import com.xunji.flashcards.data.ScheduleEntity;
            import com.xunji.flashcards.data.SettingsEntity;
            import com.xunji.flashcards.data.XunjiDao;
            import com.xunji.flashcards.data.XunjiDatabase;
            import java.time.Clock;
            import java.time.Instant;
            import java.time.ZoneId;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: ReviewService.kt */
            /* JADX INFO: loaded from: classes9.dex */
            @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B1\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\u000e\b\u0002\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\u0016\u0010\r\u001a\u00020\u000e2\u0006\u0010\u000f\u001a\u00020\u0010H\u0096@¢\u0006\u0002\u0010\u0011J\u001e\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00152\u0006\u0010\u0016\u001a\u00020\u0015H\u0096@¢\u0006\u0002\u0010\u0017R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0018"}, d2 = {"Lcom/xunji/flashcards/study/ReviewService;", "Lcom/xunji/flashcards/study/ReviewActions;", "db", "Lcom/xunji/flashcards/data/XunjiDatabase;", "scheduler", "Lcom/xunji/core/scheduling/Scheduler;", "clock", "Ljava/time/Clock;", "zone", "Lkotlin/Function0;", "Ljava/time/ZoneId;", "<init>", "(Lcom/xunji/flashcards/data/XunjiDatabase;Lcom/xunji/core/scheduling/Scheduler;Ljava/time/Clock;Lkotlin/jvm/functions/Function0;)V", "grade", "Lcom/xunji/flashcards/study/GradeResult;", "command", "Lcom/xunji/flashcards/study/GradeCommand;", "(Lcom/xunji/flashcards/study/GradeCommand;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "undo", "Lcom/xunji/flashcards/study/UndoResult;", "sessionId", "", "logId", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */     public final class ReviewService implements ReviewActions {
                public static final int $stable = 8;
                private final Clock clock;
                private final XunjiDatabase db;
                private final Scheduler scheduler;
                private final Function0<ZoneId> zone;

                /* JADX INFO: renamed from: com.xunji.flashcards.study.ReviewService$grade$2, reason: invalid class name */
                /* JADX INFO: compiled from: ReviewService.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/study/GradeResult;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.study.ReviewService$grade$2", f = "ReviewService.kt", i = {0, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 6, 6, 6, 6, 6, 6}, l = {15, 18, 19, 22, 22, 25, 26}, m = "invokeSuspend", n = {"dao", "dao", "dao", "card", "dao", "card", "before", "at", "dao", "card", "before", "at", "dao", "card", "before", "at", "after", "log", "dao", "card", "before", "at", "after", "log"}, s = {"L$0", "L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5", "L$0", "L$1", "L$2", "L$3", "L$4", "L$5"}, v = 1)
/* 10 */        static final class AnonymousClass2 extends SuspendLambda implements Function1<Continuation<? super GradeResult>, Object> {
                    final /* synthetic */ GradeCommand $command;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    Object L$5;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass2(GradeCommand gradeCommand, Continuation<? super AnonymousClass2> continuation) {
                        super(1, continuation);
                        this.$command = gradeCommand;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return ReviewService.this.new AnonymousClass2(this.$command, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super GradeResult> continuation) {
                        return ((AnonymousClass2) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:49:0x0186 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:52:0x018b  */
                    /* JADX WARN: Code duplicated, block: B:54:0x018e  */
                    /* JADX WARN: Code duplicated, block: B:56:0x01a4 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:57:0x01a5  */
                    /* JADX WARN: Code duplicated, block: B:60:0x01ae  */
                    /* JADX WARN: Code duplicated, block: B:76:0x0219 A[LOOP:0: B:74:0x0213->B:76:0x0219, LOOP_END] */
                    /* JADX WARN: Code duplicated, block: B:79:0x0245 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:80:0x0246  */
                    /* JADX WARN: Code duplicated, block: B:83:0x024c  */
                    /* JADX WARN: Code duplicated, block: B:85:0x0252  */
                    /* JADX WARN: Code duplicated, block: B:88:0x0272  */
                    /* JADX WARN: Code duplicated, block: B:90:0x0275  */
                    /* JADX WARN: Code duplicated, block: B:94:0x02f2 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:95:0x02f3  */
                    /* JADX WARN: Code duplicated, block: B:98:0x0329 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:99:0x032a  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 11 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        XunjiDao dao;
                        Object objLog;
                        ReviewLogEntity reviewLogEntity;
                        Object objCard;
                        ReviewLog model;
                        CardEntity card;
                        Object objSchedule;
                        XunjiDao dao2;
                        CardEntity card2;
                        ScheduleEntity scheduleEntity;
                        CardSchedule before;
                        CardSchedule before2;
                        Instant at;
                        Object objSchedules;
                        CardEntity card3;
                        XunjiDao dao3;
                        NewCardQuota newCardQuota;
                        CardSchedule before3;
                        Collection arrayList;
                        Iterator it;
                        ArrayList arrayList2;
                        Object obj;
                        XunjiDao dao4;
                        List<CardSchedule> list;
                        CardSchedule after;
                        Instant at2;
                        ReviewLog log;
                        CardEntity card4;
                        XunjiDao dao5;
                        ReviewLog log2;
                        CardSchedule before4;
                        Instant at3;
                        SettingsEntity settingsEntity;
                        AppSettings appSettings;
                        ReviewLog log3;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 11 */                        dao = ReviewService.this.db.dao();
/* 14 */                        if (!StringsKt.isBlank(this.$command.getOperationId()) && !StringsKt.isBlank(this.$command.getSessionId())) {
                                    long durationMs = this.$command.getDurationMs();
                                    boolean z = false;
                                    if (0 <= durationMs && durationMs < 300001) {
                                        z = true;
                                    }
                                    if (z && this.$command.getExpectedRevision() >= 0) {
                                        this.L$0 = dao;
                                        this.label = 1;
/* 15 */                                objLog = dao.log(this.$command.getOperationId(), this);
                                        if (objLog == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
/* 15 */                                reviewLogEntity = (ReviewLogEntity) objLog;
                                        if (reviewLogEntity == null && (model = EntityMappersKt.toModel(reviewLogEntity)) != null) {
                                            GradeCommand gradeCommand = this.$command;
/* 16 */                                    return (Intrinsics.areEqual(model.getCardId(), gradeCommand.getCardId()) && Intrinsics.areEqual(model.getSessionId(), gradeCommand.getSessionId()) && model.getRating() == gradeCommand.getRating() && model.getDurationMs() == gradeCommand.getDurationMs() && model.getBeforeSchedule().getRevision() == gradeCommand.getExpectedRevision()) ? new GradeResult.Duplicate(model) : GradeResult.InvalidCommand.INSTANCE;
                                        }
                                        this.L$0 = dao;
                                        this.label = 2;
/* 18 */                                objCard = dao.card(this.$command.getCardId(), this);
                                        if (objCard == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
/* 18 */                                card = (CardEntity) objCard;
                                        if (card == null) {
                                            return GradeResult.MissingCard.INSTANCE;
                                        }
                                        this.L$0 = dao;
                                        this.L$1 = card;
                                        this.label = 3;
/* 19 */                                objSchedule = dao.schedule(this.$command.getCardId(), this);
                                        if (objSchedule == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
                                        dao2 = dao;
/* 19 */                                card2 = card;
                                        scheduleEntity = (ScheduleEntity) objSchedule;
                                        if (scheduleEntity != null || (before = EntityMappersKt.toModel(scheduleEntity)) == null) {
/* 19 */                                    return GradeResult.MissingCard.INSTANCE;
                                        }
                                        if (before.getRevision() != this.$command.getExpectedRevision()) {
                                            return GradeResult.StaleSchedule.INSTANCE;
                                        }
/* 11 */                                Instant at4 = ReviewService.this.clock.instant();
/* 22 */                                if (before.getPhase() == Phase.NEW) {
                                            NewCardQuota newCardQuota2 = NewCardQuota.INSTANCE;
                                            this.L$0 = dao2;
                                            this.L$1 = card2;
                                            this.L$2 = before;
                                            this.L$3 = at4;
                                            this.L$4 = newCardQuota2;
                                            this.label = 4;
                                            objSchedules = dao2.schedules(this);
                                            if (objSchedules == coroutine_suspended) {
/* 12 */                                        return coroutine_suspended;
                                            }
                                            card3 = card2;
                                            dao3 = dao2;
/* 22 */                                    newCardQuota = newCardQuota2;
                                            before3 = before;
                                            at = at4;
/* 12 */                                    Iterable iterable = (Iterable) objSchedules;
/* 42 */                                    arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable, 10));
/* 43 */                                    it = iterable.iterator();
                                            while (it.hasNext()) {
/* 44 */                                        arrayList.add(EntityMappersKt.toModel((ScheduleEntity) it.next()));
                                            }
                                            arrayList2 = (List) arrayList;
                                            this.L$0 = dao3;
                                            this.L$1 = card3;
                                            this.L$2 = before3;
                                            this.L$3 = at;
                                            this.L$4 = newCardQuota;
                                            this.L$5 = arrayList2;
                                            this.label = 5;
/* 22 */                                    obj = dao3.settings(this);
                                            if (obj == coroutine_suspended) {
/* 12 */                                        return coroutine_suspended;
                                            }
/* 22 */                                    dao4 = dao3;
                                            list = arrayList2;
                                            settingsEntity = (SettingsEntity) obj;
                                            if (settingsEntity != null || (appSettings = EntityMappersKt.toModel(settingsEntity)) == null) {
                                                appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                            }
                                            Intrinsics.checkNotNull(at);
/* 11 */                                    if (newCardQuota.remaining(list, appSettings, at, (ZoneId) invoke()) == 0) {
                                                return GradeResult.QuotaReached.INSTANCE;
                                            }
                                            before2 = before3;
                                            card2 = card3;
                                            dao2 = dao4;
                                        } else {
                                            before2 = before;
                                            at = at4;
                                        }
/* 11 */                                Scheduler scheduler = ReviewService.this.scheduler;
                                        Rating rating = this.$command.getRating();
                                        Intrinsics.checkNotNull(at);
                                        after = scheduler.review(before2, rating, at);
/* 24 */                                at2 = at;
                                        log = new ReviewLog(this.$command.getOperationId(), card2.getId(), card2.getDeckId(), this.$command.getSessionId(), this.$command.getRating(), at2.toEpochMilli(), this.$command.getDurationMs(), before2, after, null);
                                        this.L$0 = dao2;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(card2);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(before2);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(at2);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                        this.L$5 = log;
                                        this.label = 6;
/* 25 */                                if (dao2.putSchedule(EntityMappersKt.toEntity(after), this) == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
/* 25 */                                card4 = card2;
                                        dao5 = dao2;
                                        log2 = log;
                                        before4 = before2;
                                        at3 = at2;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(dao5);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(card4);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(before4);
                                        this.L$3 = SpillingKt.nullOutSpilledVariable(at3);
                                        this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                        this.L$5 = log2;
                                        this.label = 7;
/* 26 */                                if (dao5.insertLog(EntityMappersKt.toEntity(log2), this) == coroutine_suspended) {
/* 12 */                                    return coroutine_suspended;
                                        }
/* 26 */                                log3 = log2;
/* 27 */                                return new GradeResult.Recorded(log3);
                                    }
                                }
/* 14 */                        return GradeResult.InvalidCommand.INSTANCE;
                            case 1:
                                dao = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objLog = $result;
/* 15 */                        reviewLogEntity = (ReviewLogEntity) objLog;
                                if (reviewLogEntity == null) {
                                    break;
                                }
                                this.L$0 = dao;
                                this.label = 2;
/* 18 */                        objCard = dao.card(this.$command.getCardId(), this);
                                if (objCard == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 18 */                        card = (CardEntity) objCard;
                                if (card == null) {
                                    return GradeResult.MissingCard.INSTANCE;
                                }
                                this.L$0 = dao;
                                this.L$1 = card;
                                this.label = 3;
/* 19 */                        objSchedule = dao.schedule(this.$command.getCardId(), this);
                                if (objSchedule == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
                                dao2 = dao;
/* 19 */                        card2 = card;
                                scheduleEntity = (ScheduleEntity) objSchedule;
                                if (scheduleEntity != null) {
                                    break;
                                }
/* 19 */                        return GradeResult.MissingCard.INSTANCE;
                            case 2:
                                dao = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objCard = $result;
/* 18 */                        card = (CardEntity) objCard;
                                if (card == null) {
                                    return GradeResult.MissingCard.INSTANCE;
                                }
                                this.L$0 = dao;
                                this.L$1 = card;
                                this.label = 3;
/* 19 */                        objSchedule = dao.schedule(this.$command.getCardId(), this);
                                if (objSchedule == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
                                dao2 = dao;
/* 19 */                        card2 = card;
                                scheduleEntity = (ScheduleEntity) objSchedule;
                                if (scheduleEntity != null) {
                                    break;
                                }
/* 19 */                        return GradeResult.MissingCard.INSTANCE;
                            case 3:
                                card2 = (CardEntity) this.L$1;
                                dao2 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objSchedule = $result;
                                scheduleEntity = (ScheduleEntity) objSchedule;
                                if (scheduleEntity != null) {
                                    break;
                                }
/* 19 */                        return GradeResult.MissingCard.INSTANCE;
                            case 4:
                                NewCardQuota newCardQuota3 = (NewCardQuota) this.L$4;
                                Instant at5 = (Instant) this.L$3;
                                CardSchedule before5 = (CardSchedule) this.L$2;
                                CardEntity card5 = (CardEntity) this.L$1;
                                XunjiDao dao6 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                newCardQuota = newCardQuota3;
                                dao3 = dao6;
                                card3 = card5;
                                before3 = before5;
                                at = at5;
                                objSchedules = $result;
/* 12 */                        Iterable iterable2 = (Iterable) objSchedules;
/* 42 */                        arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(iterable2, 10));
/* 43 */                        it = iterable2.iterator();
                                while (it.hasNext()) {
/* 44 */                            arrayList.add(EntityMappersKt.toModel((ScheduleEntity) it.next()));
                                }
                                arrayList2 = (List) arrayList;
                                this.L$0 = dao3;
                                this.L$1 = card3;
                                this.L$2 = before3;
                                this.L$3 = at;
                                this.L$4 = newCardQuota;
                                this.L$5 = arrayList2;
                                this.label = 5;
/* 22 */                        obj = dao3.settings(this);
                                if (obj == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 22 */                        dao4 = dao3;
                                list = arrayList2;
                                settingsEntity = (SettingsEntity) obj;
                                if (settingsEntity != null) {
                                    appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                } else {
                                    appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                }
                                Intrinsics.checkNotNull(at);
/* 11 */                        if (newCardQuota.remaining(list, appSettings, at, (ZoneId) invoke()) == 0) {
                                    return GradeResult.QuotaReached.INSTANCE;
                                }
                                before2 = before3;
                                card2 = card3;
                                dao2 = dao4;
/* 11 */                        Scheduler scheduler2 = ReviewService.this.scheduler;
                                Rating rating2 = this.$command.getRating();
                                Intrinsics.checkNotNull(at);
                                after = scheduler2.review(before2, rating2, at);
/* 24 */                        at2 = at;
                                log = new ReviewLog(this.$command.getOperationId(), card2.getId(), card2.getDeckId(), this.$command.getSessionId(), this.$command.getRating(), at2.toEpochMilli(), this.$command.getDurationMs(), before2, after, null);
                                this.L$0 = dao2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(card2);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(before2);
                                this.L$3 = SpillingKt.nullOutSpilledVariable(at2);
                                this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                this.L$5 = log;
                                this.label = 6;
/* 25 */                        if (dao2.putSchedule(EntityMappersKt.toEntity(after), this) == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 25 */                        card4 = card2;
                                dao5 = dao2;
                                log2 = log;
                                before4 = before2;
                                at3 = at2;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(dao5);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(card4);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(before4);
                                this.L$3 = SpillingKt.nullOutSpilledVariable(at3);
                                this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                this.L$5 = log2;
                                this.label = 7;
/* 26 */                        if (dao5.insertLog(EntityMappersKt.toEntity(log2), this) == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 26 */                        log3 = log2;
/* 27 */                        return new GradeResult.Recorded(log3);
                            case 5:
                                list = (List) this.L$5;
                                newCardQuota = (NewCardQuota) this.L$4;
                                at = (Instant) this.L$3;
                                before3 = (CardSchedule) this.L$2;
                                card3 = (CardEntity) this.L$1;
                                XunjiDao dao7 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                dao4 = dao7;
                                obj = $result;
                                settingsEntity = (SettingsEntity) obj;
                                if (settingsEntity != null) {
                                    appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                } else {
                                    appSettings = new AppSettings(0, (ThemeMode) null, 0, 7);
                                }
                                Intrinsics.checkNotNull(at);
/* 11 */                        if (newCardQuota.remaining(list, appSettings, at, (ZoneId) invoke()) == 0) {
                                    return GradeResult.QuotaReached.INSTANCE;
                                }
                                before2 = before3;
                                card2 = card3;
                                dao2 = dao4;
/* 11 */                        Scheduler scheduler3 = ReviewService.this.scheduler;
                                Rating rating3 = this.$command.getRating();
                                Intrinsics.checkNotNull(at);
                                after = scheduler3.review(before2, rating3, at);
/* 24 */                        at2 = at;
                                log = new ReviewLog(this.$command.getOperationId(), card2.getId(), card2.getDeckId(), this.$command.getSessionId(), this.$command.getRating(), at2.toEpochMilli(), this.$command.getDurationMs(), before2, after, null);
                                this.L$0 = dao2;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(card2);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(before2);
                                this.L$3 = SpillingKt.nullOutSpilledVariable(at2);
                                this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                this.L$5 = log;
                                this.label = 6;
/* 25 */                        if (dao2.putSchedule(EntityMappersKt.toEntity(after), this) == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 25 */                        card4 = card2;
                                dao5 = dao2;
                                log2 = log;
                                before4 = before2;
                                at3 = at2;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(dao5);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(card4);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(before4);
                                this.L$3 = SpillingKt.nullOutSpilledVariable(at3);
                                this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                this.L$5 = log2;
                                this.label = 7;
/* 26 */                        if (dao5.insertLog(EntityMappersKt.toEntity(log2), this) == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 26 */                        log3 = log2;
/* 27 */                        return new GradeResult.Recorded(log3);
                            case 6:
                                log2 = (ReviewLog) this.L$5;
                                CardSchedule after2 = (CardSchedule) this.L$4;
                                Instant at6 = (Instant) this.L$3;
                                CardSchedule before6 = (CardSchedule) this.L$2;
                                CardEntity card6 = (CardEntity) this.L$1;
                                XunjiDao dao8 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                after = after2;
                                at3 = at6;
                                before4 = before6;
                                card4 = card6;
                                dao5 = dao8;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(dao5);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(card4);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(before4);
                                this.L$3 = SpillingKt.nullOutSpilledVariable(at3);
                                this.L$4 = SpillingKt.nullOutSpilledVariable(after);
                                this.L$5 = log2;
                                this.label = 7;
/* 26 */                        if (dao5.insertLog(EntityMappersKt.toEntity(log2), this) == coroutine_suspended) {
/* 12 */                            return coroutine_suspended;
                                }
/* 26 */                        log3 = log2;
/* 27 */                        return new GradeResult.Recorded(log3);
                            case 7:
                                log3 = (ReviewLog) this.L$5;
                                ResultKt.throwOnFailure($result);
/* 27 */                        return new GradeResult.Recorded(log3);
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 10 */        public ReviewService(XunjiDatabase db, Scheduler scheduler, Clock clock, Function0<? extends ZoneId> zone) {
                    Intrinsics.checkNotNullParameter(db, "db");
                    Intrinsics.checkNotNullParameter(scheduler, "scheduler");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    Intrinsics.checkNotNullParameter(zone, "zone");
                    this.db = db;
                    this.scheduler = scheduler;
                    this.clock = clock;
                    this.zone = zone;
                }

                /* JADX WARN: Illegal instructions before constructor call */
/* 10 */        public /* synthetic */ ReviewService(XunjiDatabase xunjiDatabase, Scheduler scheduler, Clock clock, Function0 function0, int i, DefaultConstructorMarker defaultConstructorMarker) {
/* 11 */            if ((i & 4) != 0) {
                        clock = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clock, "systemUTC(...)");
                    }
                    this(xunjiDatabase, scheduler, clock, (i & 8) != 0 ? new Function0() { // from class: com.xunji.flashcards.study.ReviewService$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
/* 11 */                    return ZoneId.systemDefault();
                        }
                    } : function0);
                }

                @Override // com.xunji.flashcards.study.ReviewActions
/* 11 */        public Object grade(GradeCommand command, Continuation<? super GradeResult> continuation) {
/* 12 */            return RoomDatabaseKt.withTransaction(this.db, new AnonymousClass2(command, null), continuation);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.study.ReviewService$undo$2, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewService.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/study/UndoResult;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.study.ReviewService$undo$2", f = "ReviewService.kt", i = {0, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3}, l = {31, 33, 36, MotionEventCompat.AXIS_GENERIC_6}, m = "invokeSuspend", n = {"dao", "dao", "log", "dao", "log", "current", "restored", "dao", "log", "current", "restored"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$3", "L$0", "L$1", "L$2", "L$3"}, v = 1)
/* 27 */        static final class C04422 extends SuspendLambda implements Function1<Continuation<? super UndoResult>, Object> {
                    final /* synthetic */ String $logId;
                    final /* synthetic */ String $sessionId;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04422(String str, String str2, Continuation<? super C04422> continuation) {
                        super(1, continuation);
                        this.$sessionId = str;
                        this.$logId = str2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return ReviewService.this.new C04422(this.$sessionId, this.$logId, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super UndoResult> continuation) {
                        return ((C04422) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:42:0x015b A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:43:0x015c  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 28 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        XunjiDao dao;
                        Object objLatestSessionLog;
                        ReviewLogEntity reviewLogEntity;
                        ReviewLog log;
                        Object objSchedule;
                        XunjiDao dao2;
                        ReviewLog log2;
                        ScheduleEntity scheduleEntity;
                        CardSchedule current;
                        ReviewLog log3;
                        CardSchedule restored;
                        XunjiDao dao3;
                        CardSchedule current2;
                        CardSchedule restored2;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 11 */                        dao = ReviewService.this.db.dao();
                                this.L$0 = dao;
                                this.label = 1;
/* 31 */                        objLatestSessionLog = dao.latestSessionLog(this.$sessionId, this);
                                if (objLatestSessionLog == coroutine_suspended) {
/* 29 */                            return coroutine_suspended;
                                }
/* 31 */                        reviewLogEntity = (ReviewLogEntity) objLatestSessionLog;
                                if (reviewLogEntity != null || (log = EntityMappersKt.toModel(reviewLogEntity)) == null) {
/* 31 */                            return UndoResult.Unavailable.INSTANCE;
                                }
/* 32 */                        if (!Intrinsics.areEqual(log.getId(), this.$logId) || log.getUndoneAt() != null) {
/* 32 */                            return UndoResult.Unavailable.INSTANCE;
                                }
                                this.L$0 = dao;
                                this.L$1 = log;
                                this.label = 2;
/* 33 */                        objSchedule = dao.schedule(log.getCardId(), this);
                                if (objSchedule == coroutine_suspended) {
/* 29 */                            return coroutine_suspended;
                                }
                                dao2 = dao;
/* 33 */                        log2 = log;
                                scheduleEntity = (ScheduleEntity) objSchedule;
                                if (scheduleEntity != null || (current = EntityMappersKt.toModel(scheduleEntity)) == null) {
/* 33 */                            return UndoResult.Unavailable.INSTANCE;
                                }
                                if (current.getRevision() != log2.getAfterSchedule().getRevision()) {
                                    return UndoResult.Unavailable.INSTANCE;
                                }
/* 35 */                        CardSchedule restored3 = CardSchedule.copy$default(log2.getBeforeSchedule(), null, null, null, null, null, 0L, null, null, current.getRevision() + 1, 255, null);
                                this.L$0 = dao2;
                                this.L$1 = log2;
                                this.L$2 = SpillingKt.nullOutSpilledVariable(current);
                                this.L$3 = restored3;
                                this.label = 3;
/* 36 */                        if (dao2.putSchedule(EntityMappersKt.toEntity(restored3), this) == coroutine_suspended) {
/* 29 */                            return coroutine_suspended;
                                }
                                log3 = log2;
/* 36 */                        restored = restored3;
                                dao3 = dao2;
                                current2 = current;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(dao3);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(log3);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                this.L$3 = restored;
                                this.label = 4;
/* 11 */                        if (dao3.updateLog(EntityMappersKt.toEntity(ReviewLog.copy$default(log3, null, null, null, null, null, 0L, 0L, null, null, Boxing.boxLong(ReviewService.this.clock.millis()), 511, null)), this) == coroutine_suspended) {
/* 29 */                            return coroutine_suspended;
                                }
/* 37 */                        restored2 = restored;
/* 38 */                        return new UndoResult.Restored(restored2);
                            case 1:
                                dao = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objLatestSessionLog = $result;
/* 31 */                        reviewLogEntity = (ReviewLogEntity) objLatestSessionLog;
                                if (reviewLogEntity != null) {
                                    break;
                                }
/* 31 */                        return UndoResult.Unavailable.INSTANCE;
                            case 2:
                                log2 = (ReviewLog) this.L$1;
                                dao2 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                objSchedule = $result;
                                scheduleEntity = (ScheduleEntity) objSchedule;
                                if (scheduleEntity != null) {
                                    break;
                                }
/* 33 */                        return UndoResult.Unavailable.INSTANCE;
                            case 3:
                                restored = (CardSchedule) this.L$3;
                                current2 = (CardSchedule) this.L$2;
                                ReviewLog log4 = (ReviewLog) this.L$1;
                                XunjiDao dao4 = (XunjiDao) this.L$0;
                                ResultKt.throwOnFailure($result);
                                log3 = log4;
                                dao3 = dao4;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(dao3);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(log3);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(current2);
                                this.L$3 = restored;
                                this.label = 4;
/* 11 */                        if (dao3.updateLog(EntityMappersKt.toEntity(ReviewLog.copy$default(log3, null, null, null, null, null, 0L, 0L, null, null, Boxing.boxLong(ReviewService.this.clock.millis()), 511, null)), this) == coroutine_suspended) {
/* 29 */                            return coroutine_suspended;
                                }
/* 37 */                        restored2 = restored;
/* 38 */                        return new UndoResult.Restored(restored2);
                            case 4:
                                restored2 = (CardSchedule) this.L$3;
                                ResultKt.throwOnFailure($result);
/* 38 */                        return new UndoResult.Restored(restored2);
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // com.xunji.flashcards.study.ReviewActions
/* 28 */        public Object undo(String sessionId, String logId, Continuation<? super UndoResult> continuation) {
/* 29 */            return RoomDatabaseKt.withTransaction(this.db, new C04422(sessionId, logId, null), continuation);
                }
            }

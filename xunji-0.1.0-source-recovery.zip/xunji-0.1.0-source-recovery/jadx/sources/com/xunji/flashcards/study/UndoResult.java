            package com.xunji.flashcards.study;

            import com.xunji.core.model.CardSchedule;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ReviewCommands.kt */
            /* JADX INFO: loaded from: classes9.dex */
            @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0002\u0002\u0003\u0082\u0001\u0002\u0004\u0005¨\u0006\u0006À\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/study/UndoResult;", "", "Restored", "Unavailable", "Lcom/xunji/flashcards/study/UndoResult$Restored;", "Lcom/xunji/flashcards/study/UndoResult$Unavailable;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public interface UndoResult {

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/flashcards/study/UndoResult$Restored;", "Lcom/xunji/flashcards/study/UndoResult;", "schedule", "Lcom/xunji/core/model/CardSchedule;", "<init>", "(Lcom/xunji/core/model/CardSchedule;)V", "getSchedule", "()Lcom/xunji/core/model/CardSchedule;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */        public static final /* data */ class Restored implements UndoResult {
                    public static final int $stable = 8;
                    private final CardSchedule schedule;

                    public static /* synthetic */ Restored copy$default(Restored restored, CardSchedule cardSchedule, int i, Object obj) {
                        if ((i & 1) != 0) {
                            cardSchedule = restored.schedule;
                        }
                        return restored.copy(cardSchedule);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final CardSchedule getSchedule() {
                        return this.schedule;
                    }

                    public final Restored copy(CardSchedule schedule) {
                        Intrinsics.checkNotNullParameter(schedule, "schedule");
                        return new Restored(schedule);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Restored) && Intrinsics.areEqual(this.schedule, ((Restored) other).schedule);
                    }

                    public int hashCode() {
                        return this.schedule.hashCode();
                    }

                    public String toString() {
                        return "Restored(schedule=" + this.schedule + ")";
                    }

/* 14 */            public Restored(CardSchedule schedule) {
                        Intrinsics.checkNotNullParameter(schedule, "schedule");
                        this.schedule = schedule;
                    }

/* 14 */            public final CardSchedule getSchedule() {
/* 15 */                return this.schedule;
                    }
                }

                /* JADX INFO: compiled from: ReviewCommands.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/study/UndoResult$Unavailable;", "Lcom/xunji/flashcards/study/UndoResult;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 14 */        public static final /* data */ class Unavailable implements UndoResult {
                    public static final int $stable = 0;
                    public static final Unavailable INSTANCE = new Unavailable();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Unavailable)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 546324696;
                    }

                    public String toString() {
                        return "Unavailable";
                    }

/* 15 */            private Unavailable() {
                    }
                }
            }

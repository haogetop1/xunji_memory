            package com.xunji.flashcards.ui;

            import androidx.core.app.NotificationCompat;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.flashcards.anki.AnkiImportReport;
            import com.xunji.flashcards.anki.ImportResult;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u001f\b\u0081\b\u0018\u00002\u00020\u0001Ba\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u0006\u0012\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b\u0012\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\f\u0012\b\b\u0002\u0010\r\u001a\u00020\u000e\u0012\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\u0010\u0010\u0011J\t\u0010 \u001a\u00020\u0003HÆ\u0003J\t\u0010!\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\"\u001a\u0004\u0018\u00010\u0006HÆ\u0003J\u000b\u0010#\u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010$\u001a\u0004\u0018\u00010\nHÆ\u0003J\u000b\u0010%\u001a\u0004\u0018\u00010\fHÆ\u0003J\t\u0010&\u001a\u00020\u000eHÆ\u0003J\u000b\u0010'\u001a\u0004\u0018\u00010\nHÆ\u0003Jc\u0010(\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\n\b\u0002\u0010\u0005\u001a\u0004\u0018\u00010\u00062\n\b\u0002\u0010\u0007\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\t\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\f2\b\b\u0002\u0010\r\u001a\u00020\u000e2\n\b\u0002\u0010\u000f\u001a\u0004\u0018\u00010\nHÆ\u0001J\u0013\u0010)\u001a\u00020\u00032\b\u0010*\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010+\u001a\u00020\u000eHÖ\u0001J\t\u0010,\u001a\u00020\fHÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0013R\u0013\u0010\u0005\u001a\u0004\u0018\u00010\u0006¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0013\u0010\u0007\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0013\u0010\t\u001a\u0004\u0018\u00010\n¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001aR\u0013\u0010\u000b\u001a\u0004\u0018\u00010\f¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u001cR\u0011\u0010\r\u001a\u00020\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001eR\u0013\u0010\u000f\u001a\u0004\u0018\u00010\n¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001a¨\u0006-"}, d2 = {"Lcom/xunji/flashcards/ui/AnkiImportUiState;", "", "busy", "", "committing", NotificationCompat.CATEGORY_PROGRESS, "Lcom/xunji/core/anki/ImportProgress;", "preview", "Lcom/xunji/flashcards/anki/AnkiImportReport;", "result", "Lcom/xunji/flashcards/anki/ImportResult;", "error", "", "page", "", "previousCompleted", "<init>", "(ZZLcom/xunji/core/anki/ImportProgress;Lcom/xunji/flashcards/anki/AnkiImportReport;Lcom/xunji/flashcards/anki/ImportResult;Ljava/lang/String;ILcom/xunji/flashcards/anki/ImportResult;)V", "getBusy", "()Z", "getCommitting", "getProgress", "()Lcom/xunji/core/anki/ImportProgress;", "getPreview", "()Lcom/xunji/flashcards/anki/AnkiImportReport;", "getResult", "()Lcom/xunji/flashcards/anki/ImportResult;", "getError", "()Ljava/lang/String;", "getPage", "()I", "getPreviousCompleted", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 18 */    public final /* data */ class AnkiImportUiState {
                public static final int $stable = 8;
                private final boolean busy;
                private final boolean committing;
                private final String error;
                private final int page;
                private final AnkiImportReport preview;
                private final ImportResult previousCompleted;
                private final ImportProgress progress;
                private final ImportResult result;

                public AnkiImportUiState() {
                    this(false, false, null, null, null, null, 0, null, 255);
                }

                public static /* synthetic */ AnkiImportUiState copy$default(AnkiImportUiState ankiImportUiState, boolean z, boolean z2, ImportProgress importProgress, AnkiImportReport ankiImportReport, ImportResult importResult, String str, int i, ImportResult importResult2, int i2, Object obj) {
                    if ((i2 & 1) != 0) {
                        z = ankiImportUiState.busy;
                    }
                    if ((i2 & 2) != 0) {
                        z2 = ankiImportUiState.committing;
                    }
                    if ((i2 & 4) != 0) {
                        importProgress = ankiImportUiState.progress;
                    }
                    if ((i2 & 8) != 0) {
                        ankiImportReport = ankiImportUiState.preview;
                    }
                    if ((i2 & 16) != 0) {
                        importResult = ankiImportUiState.result;
                    }
                    if ((i2 & 32) != 0) {
                        str = ankiImportUiState.error;
                    }
                    if ((i2 & 64) != 0) {
                        i = ankiImportUiState.page;
                    }
                    if ((i2 & 128) != 0) {
                        importResult2 = ankiImportUiState.previousCompleted;
                    }
                    int i3 = i;
                    ImportResult importResult3 = importResult2;
                    ImportResult importResult4 = importResult;
                    String str2 = str;
                    return ankiImportUiState.copy(z, z2, importProgress, ankiImportReport, importResult4, str2, i3, importResult3);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final boolean getBusy() {
                    return this.busy;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final boolean getCommitting() {
                    return this.committing;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final ImportProgress getProgress() {
                    return this.progress;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final AnkiImportReport getPreview() {
                    return this.preview;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final ImportResult getResult() {
                    return this.result;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final String getError() {
                    return this.error;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final int getPage() {
                    return this.page;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final ImportResult getPreviousCompleted() {
                    return this.previousCompleted;
                }

                public final AnkiImportUiState copy(boolean busy, boolean committing, ImportProgress progress, AnkiImportReport preview, ImportResult result, String error, int page, ImportResult previousCompleted) {
                    return new AnkiImportUiState(busy, committing, progress, preview, result, error, page, previousCompleted);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof AnkiImportUiState)) {
                        return false;
                    }
                    AnkiImportUiState ankiImportUiState = (AnkiImportUiState) other;
                    return this.busy == ankiImportUiState.busy && this.committing == ankiImportUiState.committing && Intrinsics.areEqual(this.progress, ankiImportUiState.progress) && Intrinsics.areEqual(this.preview, ankiImportUiState.preview) && Intrinsics.areEqual(this.result, ankiImportUiState.result) && Intrinsics.areEqual(this.error, ankiImportUiState.error) && this.page == ankiImportUiState.page && Intrinsics.areEqual(this.previousCompleted, ankiImportUiState.previousCompleted);
                }

                public int hashCode() {
                    return (((((((((((((Boolean.hashCode(this.busy) * 31) + Boolean.hashCode(this.committing)) * 31) + (this.progress == null ? 0 : this.progress.hashCode())) * 31) + (this.preview == null ? 0 : this.preview.hashCode())) * 31) + (this.result == null ? 0 : this.result.hashCode())) * 31) + (this.error == null ? 0 : this.error.hashCode())) * 31) + Integer.hashCode(this.page)) * 31) + (this.previousCompleted != null ? this.previousCompleted.hashCode() : 0);
                }

                public String toString() {
                    return "AnkiImportUiState(busy=" + this.busy + ", committing=" + this.committing + ", progress=" + this.progress + ", preview=" + this.preview + ", result=" + this.result + ", error=" + this.error + ", page=" + this.page + ", previousCompleted=" + this.previousCompleted + ")";
                }

/* 19 */        public AnkiImportUiState(boolean busy, boolean committing, ImportProgress progress, AnkiImportReport preview, ImportResult result, String error, int page, ImportResult previousCompleted) {
/* 21 */            this.busy = busy;
                    this.committing = committing;
                    this.progress = progress;
/* 22 */            this.preview = preview;
                    this.result = result;
/* 23 */            this.error = error;
                    this.page = page;
                    this.previousCompleted = previousCompleted;
                }

/* 20 */        public final boolean getBusy() {
/* 21 */            return this.busy;
                }

/* 20 */        public final boolean getCommitting() {
/* 21 */            return this.committing;
                }

/* 20 */        public final ImportProgress getProgress() {
/* 21 */            return this.progress;
                }

/* 21 */        public final AnkiImportReport getPreview() {
/* 22 */            return this.preview;
                }

/* 21 */        public final ImportResult getResult() {
/* 22 */            return this.result;
                }

/* 22 */        public final String getError() {
/* 23 */            return this.error;
                }

/* 22 */        public final int getPage() {
/* 23 */            return this.page;
                }

/* 22 */        public final ImportResult getPreviousCompleted() {
/* 23 */            return this.previousCompleted;
                }
            }

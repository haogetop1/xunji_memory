            package com.xunji.flashcards.ui;

            import android.net.Uri;
            import androidx.core.app.NotificationCompat;
            import androidx.core.view.MotionEventCompat;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelKt;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.flashcards.anki.AnkiImportReport;
            import com.xunji.flashcards.anki.AnkiImportService;
            import com.xunji.flashcards.anki.ImportResult;
            import com.xunji.flashcards.anki.PreparedAnkiImport;
            import java.io.InputStream;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendFunction;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.flow.FlowKt;
            import kotlinx.coroutines.flow.MutableStateFlow;
            import kotlinx.coroutines.flow.StateFlow;
            import kotlinx.coroutines.flow.StateFlowKt;
            import kotlinx.coroutines.scheduling.WorkQueueKt;
            
            /* JADX INFO: compiled from: AnkiImportViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0003\b\u0001\u0018\u00002\u00020\u0001Bg\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\"\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000b\u0012$\b\u0002\u0010\r\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005¢\u0006\u0004\b\u0010\u0010\u0011J\u000e\u0010\u001f\u001a\u00020\f2\u0006\u0010 \u001a\u00020\u0006J\u0006\u0010!\u001a\u00020\fJ\u000e\u0010\"\u001a\u00020\f2\u0006\u0010#\u001a\u00020$J\u0006\u0010%\u001a\u00020\fJ\b\u0010&\u001a\u00020\fH\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R,\u0010\u0004\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\n\u0012\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0012R\u0014\u0010\n\u001a\b\u0012\u0004\u0012\u00020\f0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R,\u0010\r\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0012R\u0014\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014X\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00150\u0017¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0010\u0010\u001a\u001a\u0004\u0018\u00010\u000eX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u001b\u001a\u0004\u0018\u00010\u001cX\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u001d\u001a\u00020\u001eX\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006'"}, d2 = {"Lcom/xunji/flashcards/ui/AnkiImportViewModel;", "Landroidx/lifecycle/ViewModel;", NotificationCompat.CATEGORY_SERVICE, "Lcom/xunji/flashcards/anki/AnkiImportService;", "open", "Lkotlin/Function2;", "Landroid/net/Uri;", "Lkotlin/coroutines/Continuation;", "Lcom/xunji/flashcards/ui/ImportSource;", "", "imported", "Lkotlin/Function0;", "", "commitImport", "Lcom/xunji/flashcards/anki/PreparedAnkiImport;", "Lcom/xunji/flashcards/anki/ImportResult;", "<init>", "(Lcom/xunji/flashcards/anki/AnkiImportService;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;)V", "Lkotlin/jvm/functions/Function2;", "mutable", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/xunji/flashcards/ui/AnkiImportUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "prepared", "operation", "Lkotlinx/coroutines/Job;", "generation", "", "start", "uri", "confirm", "page", "index", "", "cancel", "onCleared", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 24 */    public final class AnkiImportViewModel extends ViewModel {
                public static final int $stable = 8;
                private final Function2<PreparedAnkiImport, Continuation<? super ImportResult>, Object> commitImport;
                private long generation;
                private final Function0<Unit> imported;
                private final MutableStateFlow<AnkiImportUiState> mutable;
                private final Function2<Uri, Continuation<? super ImportSource>, Object> open;
                private Job operation;
                private PreparedAnkiImport prepared;
                private final AnkiImportService service;
                private final StateFlow<AnkiImportUiState> state;

                /* JADX WARN: Multi-variable type inference failed */
/* 25 */        public AnkiImportViewModel(AnkiImportService service, Function2<? super Uri, ? super Continuation<? super ImportSource>, ? extends Object> open, Function0<Unit> imported, Function2<? super PreparedAnkiImport, ? super Continuation<? super ImportResult>, ? extends Object> commitImport) {
                    Intrinsics.checkNotNullParameter(service, "service");
                    Intrinsics.checkNotNullParameter(open, "open");
                    Intrinsics.checkNotNullParameter(imported, "imported");
                    Intrinsics.checkNotNullParameter(commitImport, "commitImport");
/* 27 */            this.service = service;
/* 28 */            this.open = open;
/* 29 */            this.imported = imported;
/* 30 */            this.commitImport = commitImport;
/* 32 */            this.mutable = StateFlowKt.MutableStateFlow(new AnkiImportUiState(false, false, null, null, null, null, 0, null, 255));
/* 33 */            this.state = FlowKt.asStateFlow(this.mutable);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.AnkiImportViewModel$1, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiImportViewModel.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 28 */        static final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function2<PreparedAnkiImport, Continuation<? super ImportResult>, Object>, SuspendFunction {
                    AnonymousClass1(Object obj) {
                        super(2, obj, AnkiImportService.class, "commit", "commit(Lcom/xunji/flashcards/anki/PreparedAnkiImport;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
                    }

                    @Override // kotlin.jvm.functions.Function2
/* 29 */            public final Object invoke(PreparedAnkiImport p0, Continuation<? super ImportResult> continuation) {
/* 30 */                return ((AnkiImportService) this.receiver).commit(p0, continuation);
                    }
                }

/* 32 */        public final StateFlow<AnkiImportUiState> getState() {
/* 33 */            return this.state;
                }

/* 38 */        public final void start(Uri uri) {
                    Intrinsics.checkNotNullParameter(uri, "uri");
/* 39 */            if (getValue().getBusy()) {
                        return;
                    }
/* 40 */            PreparedAnkiImport preparedAnkiImport = this.prepared;
                    if (preparedAnkiImport != null) {
                        preparedAnkiImport.close();
                    }
                    this.prepared = null;
/* 41 */            this.generation++;
                    long version = this.generation;
/* 42 */            setValue(new AnkiImportUiState(true, false, null, null, null, null, 0, getValue().getPreviousCompleted(), 126));
/* 1 */             this.operation = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04441(uri, version, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.AnkiImportViewModel$start$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.AnkiImportViewModel$start$1", f = "AnkiImportViewModel.kt", i = {1}, l = {MotionEventCompat.AXIS_GENERIC_14, MotionEventCompat.AXIS_GENERIC_15}, m = "invokeSuspend", n = {"source"}, s = {"L$0"}, v = 1)
/* 41 */        static final class C04441 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Uri $uri;
                    final /* synthetic */ long $version;
                    Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04441(Uri uri, long j, Continuation<? super C04441> continuation) {
                        super(2, continuation);
                        this.$uri = uri;
                        this.$version = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return AnkiImportViewModel.this.new C04441(this.$uri, this.$version, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04441) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:22:0x006d A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:23:0x006e  */
                    /* JADX WARN: Code duplicated, block: B:26:0x007d A[Catch: all -> 0x0023, Exception -> 0x0026, CancellationException -> 0x0029, TryCatch #1 {CancellationException -> 0x0029, blocks: (B:7:0x0017, B:24:0x006f, B:26:0x007d, B:27:0x00ab, B:8:0x001d, B:20:0x0042, B:17:0x0030), top: B:49:0x0008, outer: #0 }] */
                    /* JADX WARN: Code duplicated, block: B:27:0x00ab A[Catch: all -> 0x0023, Exception -> 0x0026, CancellationException -> 0x0029, TRY_LEAVE, TryCatch #1 {CancellationException -> 0x0029, blocks: (B:7:0x0017, B:24:0x006f, B:26:0x007d, B:27:0x00ab, B:8:0x001d, B:20:0x0042, B:17:0x0030), top: B:49:0x0008, outer: #0 }] */
                    /* JADX WARN: Code duplicated, block: B:41:0x010b  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 42 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        String strTake;
                        Object objInvoke;
                        Object objPrepare;
                        PreparedAnkiImport preview;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            try {
                                try {
                                    switch (this.label) {
                                        case 0:
/* 43 */                                    ResultKt.throwOnFailure($result);
/* 26 */                                    Function2 function2 = AnkiImportViewModel.this.open;
                                            Uri uri = this.$uri;
                                            this.label = 1;
                                            objInvoke = function2.invoke(uri, this);
                                            if (objInvoke == coroutine_suspended) {
/* 43 */                                        return coroutine_suspended;
                                            }
                                            ImportSource source = (ImportSource) objInvoke;
/* 26 */                                    AnkiImportService ankiImportService = AnkiImportViewModel.this.service;
                                            InputStream stream = source.getStream();
                                            String displayName = source.getDisplayName();
                                            final long j = this.$version;
                                            final AnkiImportViewModel ankiImportViewModel = AnkiImportViewModel.this;
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(source);
                                            this.label = 2;
                                            objPrepare = ankiImportService.prepare(stream, displayName, new Function1() { // from class: com.xunji.flashcards.ui.AnkiImportViewModel$start$1$$ExternalSyntheticLambda0
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj) {
                                                    return AnkiImportViewModel.C04441.invokeSuspend$lambda$0(j, ankiImportViewModel, (ImportProgress) obj);
                                                }
                                            }, this);
                                            if (objPrepare == coroutine_suspended) {
/* 43 */                                        return coroutine_suspended;
                                            }
/* 43 */                                    preview = (PreparedAnkiImport) objPrepare;
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        AnkiImportViewModel.this.prepared = preview;
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, preview.getReport(), null, null, 0, null, 242, null));
                                            } else {
/* 52 */                                        preview.close();
                                            }
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 254, null));
                                            }
/* 59 */                                    return Unit.INSTANCE;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            objInvoke = $result;
                                            ImportSource source2 = (ImportSource) objInvoke;
/* 26 */                                    AnkiImportService ankiImportService2 = AnkiImportViewModel.this.service;
                                            InputStream stream2 = source2.getStream();
                                            String displayName2 = source2.getDisplayName();
                                            final long j2 = this.$version;
                                            final AnkiImportViewModel ankiImportViewModel2 = AnkiImportViewModel.this;
                                            this.L$0 = SpillingKt.nullOutSpilledVariable(source2);
                                            this.label = 2;
                                            objPrepare = ankiImportService2.prepare(stream2, displayName2, new Function1() { // from class: com.xunji.flashcards.ui.AnkiImportViewModel$start$1$$ExternalSyntheticLambda0
                                                @Override // kotlin.jvm.functions.Function1
                                                public final Object invoke(Object obj) {
                                                    return AnkiImportViewModel.C04441.invokeSuspend$lambda$0(j2, ankiImportViewModel2, (ImportProgress) obj);
                                                }
                                            }, this);
                                            if (objPrepare == coroutine_suspended) {
/* 43 */                                        return coroutine_suspended;
                                            }
/* 43 */                                    preview = (PreparedAnkiImport) objPrepare;
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        AnkiImportViewModel.this.prepared = preview;
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, preview.getReport(), null, null, 0, null, 242, null));
                                            } else {
/* 52 */                                        preview.close();
                                            }
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 254, null));
                                            }
/* 59 */                                    return Unit.INSTANCE;
                                        case 2:
                                            ResultKt.throwOnFailure($result);
                                            objPrepare = $result;
/* 43 */                                    preview = (PreparedAnkiImport) objPrepare;
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        AnkiImportViewModel.this.prepared = preview;
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, preview.getReport(), null, null, 0, null, 242, null));
                                            } else {
/* 52 */                                        preview.close();
                                            }
                                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 254, null));
                                            }
/* 59 */                                    return Unit.INSTANCE;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                } catch (CancellationException error) {
/* 53 */                            throw error;
                                }
                            } catch (Exception error2) {
                                if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                            MutableStateFlow mutableStateFlow = AnkiImportViewModel.this.mutable;
                                    String message = error2.getMessage();
                                    if (message == null || (strTake = StringsKt.take(message, 240)) == null) {
                                        strTake = "无法预检此牌组";
                                    }
/* 26 */                            mutableStateFlow.setValue(new AnkiImportUiState(false, false, null, null, null, strTake, 0, ((AnkiImportUiState) getValue()).getPreviousCompleted(), 95));
                                }
                                if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                            setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 254, null));
                                }
                            }
                        } catch (Throwable th) {
                            if (this.$version == AnkiImportViewModel.this.generation) {
/* 26 */                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 254, null));
                            }
                            throw th;
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 46 */            public static final Unit invokeSuspend$lambda$0(long $version, AnkiImportViewModel this$0, ImportProgress progress) {
                        if ($version == this$0.generation) {
/* 26 */                    this$0.mutable.setValue(AnkiImportUiState.copy$default((AnkiImportUiState) this$0.mutable.getValue(), false, false, progress, null, null, null, 0, null, 251, null));
                        }
/* 48 */                return Unit.INSTANCE;
                    }
                }

/* 62 */        public final void confirm() {
/* 63 */            PreparedAnkiImport preview = this.prepared;
/* 64 */            if (preview == null || getValue().getBusy()) {
                        return;
                    }
/* 65 */            long version = this.generation;
/* 63 */            setValue(AnkiImportUiState.copy$default(getValue(), true, true, null, null, null, null, 0, null, 220, null));
/* 63 */            this.operation = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04431(preview, this, version, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.AnkiImportViewModel$confirm$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: AnkiImportViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.AnkiImportViewModel$confirm$1", f = "AnkiImportViewModel.kt", i = {}, l = {70}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 65 */        static final class C04431 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ PreparedAnkiImport $preview;
                    final /* synthetic */ long $version;
                    int label;
                    final /* synthetic */ AnkiImportViewModel this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04431(PreparedAnkiImport preparedAnkiImport, AnkiImportViewModel ankiImportViewModel, long j, Continuation<? super C04431> continuation) {
                        super(2, continuation);
                        this.$preview = preparedAnkiImport;
                        this.this$0 = ankiImportViewModel;
                        this.$version = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04431(this.$preview, this.this$0, this.$version, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04431) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:42:0x0120  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 66 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        String strTake;
                        Object objInvoke;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            try {
                                switch (this.label) {
                                    case 0:
/* 67 */                                ResultKt.throwOnFailure($result);
/* 69 */                                PreparedAnkiImport.confirmCompatible$default(this.$preview, null, 1, null);
/* 26 */                                Function2 function2 = this.this$0.commitImport;
                                        PreparedAnkiImport preparedAnkiImport = this.$preview;
                                        this.label = 1;
                                        objInvoke = function2.invoke(preparedAnkiImport, this);
                                        if (objInvoke == coroutine_suspended) {
/* 67 */                                    return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        objInvoke = $result;
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                                ImportResult result = (ImportResult) objInvoke;
/* 26 */                        if (this.this$0.prepared == this.$preview) {
/* 26 */                            this.this$0.prepared = null;
                                }
                                if (this.$version == this.this$0.generation) {
/* 26 */                            setValue(new AnkiImportUiState(false, false, null, null, result, null, 0, null, 239));
                                } else {
/* 26 */                            setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, result, WorkQueueKt.MASK, null));
                                }
/* 26 */                        invoke();
                                if (this.$version == this.this$0.generation) {
/* 26 */                            setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 252, null));
                                }
                            } catch (CancellationException error) {
/* 75 */                        throw error;
                            } catch (Exception error2) {
/* 26 */                        if (this.this$0.prepared == this.$preview) {
/* 26 */                            this.this$0.prepared = null;
                                }
                                if (this.$version == this.this$0.generation) {
/* 26 */                            MutableStateFlow mutableStateFlow = this.this$0.mutable;
                                    String message = error2.getMessage();
                                    if (message == null || (strTake = StringsKt.take(message, 240)) == null) {
                                        strTake = "导入失败";
                                    }
/* 26 */                            mutableStateFlow.setValue(new AnkiImportUiState(false, false, null, null, null, strTake + "；请重新选择牌组预检", 0, ((AnkiImportUiState) getValue()).getPreviousCompleted(), 95));
                                }
                                if (this.$version == this.this$0.generation) {
/* 26 */                            setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 252, null));
                                }
                            }
/* 82 */                    return Unit.INSTANCE;
                        } catch (Throwable th) {
                            if (this.$version == this.this$0.generation) {
/* 26 */                        setValue(AnkiImportUiState.copy$default((AnkiImportUiState) getValue(), false, false, null, null, null, null, 0, null, 252, null));
                            }
                            throw th;
                        }
                    }
                }

/* 85 */        public final void page(int index) {
                    AnkiImportReport report = getValue().getPreview();
                    if (report == null) {
                        return;
                    }
/* 87 */            int pages = (report.getAffectedCards().size() + 19) / 20;
/* 88 */            boolean z = false;
/* 86 */            if (index >= 0 && index < pages) {
                        z = true;
                    }
                    if (z) {
/* 86 */                setValue(AnkiImportUiState.copy$default(getValue(), false, false, null, null, null, null, index, null, 191, null));
                    }
                }

/* 91 */        public final void cancel() {
                    PreparedAnkiImport preparedAnkiImport;
/* 92 */            this.generation++;
/* 93 */            Job job = this.operation;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
/* 94 */            if (!getValue().getBusy() && (preparedAnkiImport = this.prepared) != null) {
                        preparedAnkiImport.close();
                    }
/* 95 */            this.prepared = null;
/* 96 */            setValue(new AnkiImportUiState(false, false, null, null, null, null, 0, getValue().getPreviousCompleted(), WorkQueueKt.MASK));
                }

                @Override // androidx.lifecycle.ViewModel
/* 98 */        protected void onCleared() {
/* 99 */            cancel();
                    super.onCleared();
                }
            }

            package com.xunji.flashcards.ui;

            import com.xunji.flashcards.anki.RenderedCard;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: UiModels.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b+\b\u0087\b\u0018\u00002\u00020\u0001B±\u0001\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\u0014\b\u0002\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\f\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u0003\u0012\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000f\u0012\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00030\u000f\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0012\u0012\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u0014\u0012\b\b\u0002\u0010\u0015\u001a\u00020\u0007¢\u0006\u0004\b\u0016\u0010\u0017J\t\u0010,\u001a\u00020\u0003HÆ\u0003J\t\u0010-\u001a\u00020\u0003HÆ\u0003J\t\u0010.\u001a\u00020\u0003HÆ\u0003J\t\u0010/\u001a\u00020\u0007HÆ\u0003J\t\u00100\u001a\u00020\u0007HÆ\u0003J\t\u00101\u001a\u00020\u0007HÆ\u0003J\t\u00102\u001a\u00020\u0007HÆ\u0003J\u0015\u00103\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\fHÆ\u0003J\u000b\u00104\u001a\u0004\u0018\u00010\u0003HÆ\u0003J\u0011\u00105\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000fHÆ\u0003J\u000f\u00106\u001a\b\u0012\u0004\u0012\u00020\u00030\u000fHÆ\u0003J\t\u00107\u001a\u00020\u0012HÆ\u0003J\u000b\u00108\u001a\u0004\u0018\u00010\u0014HÆ\u0003J\t\u00109\u001a\u00020\u0007HÆ\u0003J³\u0001\u0010:\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u00072\b\b\u0002\u0010\t\u001a\u00020\u00072\b\b\u0002\u0010\n\u001a\u00020\u00072\u0014\b\u0002\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\f2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u00032\u0010\b\u0002\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000f2\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00030\u000f2\b\b\u0002\u0010\u0011\u001a\u00020\u00122\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u00142\b\b\u0002\u0010\u0015\u001a\u00020\u0007HÆ\u0001J\u0013\u0010;\u001a\u00020\u00072\b\u0010<\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010=\u001a\u00020\u0012HÖ\u0001J\t\u0010>\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0018\u0010\u0019R\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u0019R\u0011\u0010\u0005\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u001b\u0010\u0019R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010\b\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001dR\u0011\u0010\t\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u001f\u0010\u001dR\u0011\u0010\n\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b \u0010\u001dR\u001d\u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\f¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0013\u0010\r\u001a\u0004\u0018\u00010\u0003¢\u0006\b\n\u0000\u001a\u0004\b#\u0010\u0019R\u0019\u0010\u000e\u001a\n\u0012\u0004\u0012\u00020\u0003\u0018\u00010\u000f¢\u0006\b\n\u0000\u001a\u0004\b$\u0010%R\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00030\u000f¢\u0006\b\n\u0000\u001a\u0004\b&\u0010%R\u0011\u0010\u0011\u001a\u00020\u0012¢\u0006\b\n\u0000\u001a\u0004\b'\u0010(R\u0013\u0010\u0013\u001a\u0004\u0018\u00010\u0014¢\u0006\b\n\u0000\u001a\u0004\b)\u0010*R\u0011\u0010\u0015\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b+\u0010\u001d¨\u0006?"}, d2 = {"Lcom/xunji/flashcards/ui/EditorUiState;", "", "front", "", "back", "example", "loading", "", "saving", "saved", "dirty", "errors", "", "error", "ankiFieldNames", "", "ankiFields", "linkedCards", "", "preview", "Lcom/xunji/flashcards/anki/RenderedCard;", "previewing", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZLjava/util/Map;Ljava/lang/String;Ljava/util/List;Ljava/util/List;ILcom/xunji/flashcards/anki/RenderedCard;Z)V", "getFront", "()Ljava/lang/String;", "getBack", "getExample", "getLoading", "()Z", "getSaving", "getSaved", "getDirty", "getErrors", "()Ljava/util/Map;", "getError", "getAnkiFieldNames", "()Ljava/util/List;", "getAnkiFields", "getLinkedCards", "()I", "getPreview", "()Lcom/xunji/flashcards/anki/RenderedCard;", "getPreviewing", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "component10", "component11", "component12", "component13", "component14", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 7 */     public final /* data */ class EditorUiState {
                public static final int $stable = 8;
                private final List<String> ankiFieldNames;
                private final List<String> ankiFields;
                private final String back;
                private final boolean dirty;
                private final String error;
                private final Map<String, String> errors;
                private final String example;
                private final String front;
                private final int linkedCards;
                private final boolean loading;
                private final RenderedCard preview;
                private final boolean previewing;
                private final boolean saved;
                private final boolean saving;

                public EditorUiState() {
                    this(null, null, null, false, false, false, false, null, null, null, null, 0, null, false, 16383);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final String getFront() {
                    return this.front;
                }

                public final List<String> component10() {
                    return this.ankiFieldNames;
                }

                public final List<String> component11() {
                    return this.ankiFields;
                }

                /* JADX INFO: renamed from: component12, reason: from getter */
                public final int getLinkedCards() {
                    return this.linkedCards;
                }

                /* JADX INFO: renamed from: component13, reason: from getter */
                public final RenderedCard getPreview() {
                    return this.preview;
                }

                /* JADX INFO: renamed from: component14, reason: from getter */
                public final boolean getPreviewing() {
                    return this.previewing;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getBack() {
                    return this.back;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final String getExample() {
                    return this.example;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final boolean getLoading() {
                    return this.loading;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final boolean getSaving() {
                    return this.saving;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final boolean getSaved() {
                    return this.saved;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final boolean getDirty() {
                    return this.dirty;
                }

                public final Map<String, String> component8() {
                    return this.errors;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final String getError() {
                    return this.error;
                }

                public final EditorUiState copy(String front, String back, String example, boolean loading, boolean saving, boolean saved, boolean dirty, Map<String, String> errors, String error, List<String> ankiFieldNames, List<String> ankiFields, int linkedCards, RenderedCard preview, boolean previewing) {
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
                    Intrinsics.checkNotNullParameter(errors, "errors");
                    Intrinsics.checkNotNullParameter(ankiFields, "ankiFields");
                    return new EditorUiState(front, back, example, loading, saving, saved, dirty, errors, error, ankiFieldNames, ankiFields, linkedCards, preview, previewing);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof EditorUiState)) {
                        return false;
                    }
                    EditorUiState editorUiState = (EditorUiState) other;
                    return Intrinsics.areEqual(this.front, editorUiState.front) && Intrinsics.areEqual(this.back, editorUiState.back) && Intrinsics.areEqual(this.example, editorUiState.example) && this.loading == editorUiState.loading && this.saving == editorUiState.saving && this.saved == editorUiState.saved && this.dirty == editorUiState.dirty && Intrinsics.areEqual(this.errors, editorUiState.errors) && Intrinsics.areEqual(this.error, editorUiState.error) && Intrinsics.areEqual(this.ankiFieldNames, editorUiState.ankiFieldNames) && Intrinsics.areEqual(this.ankiFields, editorUiState.ankiFields) && this.linkedCards == editorUiState.linkedCards && Intrinsics.areEqual(this.preview, editorUiState.preview) && this.previewing == editorUiState.previewing;
                }

                public int hashCode() {
                    return (((((((((((((((((((((((((this.front.hashCode() * 31) + this.back.hashCode()) * 31) + this.example.hashCode()) * 31) + Boolean.hashCode(this.loading)) * 31) + Boolean.hashCode(this.saving)) * 31) + Boolean.hashCode(this.saved)) * 31) + Boolean.hashCode(this.dirty)) * 31) + this.errors.hashCode()) * 31) + (this.error == null ? 0 : this.error.hashCode())) * 31) + (this.ankiFieldNames == null ? 0 : this.ankiFieldNames.hashCode())) * 31) + this.ankiFields.hashCode()) * 31) + Integer.hashCode(this.linkedCards)) * 31) + (this.preview != null ? this.preview.hashCode() : 0)) * 31) + Boolean.hashCode(this.previewing);
                }

                public String toString() {
                    return "EditorUiState(front=" + this.front + ", back=" + this.back + ", example=" + this.example + ", loading=" + this.loading + ", saving=" + this.saving + ", saved=" + this.saved + ", dirty=" + this.dirty + ", errors=" + this.errors + ", error=" + this.error + ", ankiFieldNames=" + this.ankiFieldNames + ", ankiFields=" + this.ankiFields + ", linkedCards=" + this.linkedCards + ", preview=" + this.preview + ", previewing=" + this.previewing + ")";
                }

/* 8 */         public EditorUiState(String front, String back, String example, boolean loading, boolean saving, boolean saved, boolean dirty, Map<String, String> errors, String error, List<String> list, List<String> ankiFields, int linkedCards, RenderedCard preview, boolean previewing) {
                    Intrinsics.checkNotNullParameter(front, "front");
                    Intrinsics.checkNotNullParameter(back, "back");
                    Intrinsics.checkNotNullParameter(example, "example");
                    Intrinsics.checkNotNullParameter(errors, "errors");
                    Intrinsics.checkNotNullParameter(ankiFields, "ankiFields");
                    this.front = front;
                    this.back = back;
                    this.example = example;
                    this.loading = loading;
                    this.saving = saving;
                    this.saved = saved;
                    this.dirty = dirty;
                    this.errors = errors;
                    this.error = error;
                    this.ankiFieldNames = list;
                    this.ankiFields = ankiFields;
                    this.linkedCards = linkedCards;
                    this.preview = preview;
                    this.previewing = previewing;
                }

/* 8 */         public final List<String> getAnkiFieldNames() {
/* 9 */             return this.ankiFieldNames;
                }

/* 8 */         public final List<String> getAnkiFields() {
/* 9 */             return this.ankiFields;
                }

/* 8 */         public final String getBack() {
/* 9 */             return this.back;
                }

/* 8 */         public final boolean getDirty() {
/* 9 */             return this.dirty;
                }

/* 8 */         public final String getError() {
/* 9 */             return this.error;
                }

/* 8 */         public final Map<String, String> getErrors() {
/* 9 */             return this.errors;
                }

/* 8 */         public final String getExample() {
/* 9 */             return this.example;
                }

/* 8 */         public final String getFront() {
/* 9 */             return this.front;
                }

/* 8 */         public final int getLinkedCards() {
/* 9 */             return this.linkedCards;
                }

/* 8 */         public final boolean getLoading() {
/* 9 */             return this.loading;
                }

/* 8 */         public final RenderedCard getPreview() {
/* 9 */             return this.preview;
                }

/* 8 */         public final boolean getPreviewing() {
/* 9 */             return this.previewing;
                }

/* 8 */         public final boolean getSaved() {
/* 9 */             return this.saved;
                }

/* 8 */         public final boolean getSaving() {
/* 9 */             return this.saving;
                }
            }

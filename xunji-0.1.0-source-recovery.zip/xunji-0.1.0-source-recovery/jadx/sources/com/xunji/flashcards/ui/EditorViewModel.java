            package com.xunji.flashcards.ui;

            import androidx.lifecycle.SavedStateHandle;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelKt;
            import com.xunji.core.anki.AnkiFieldValidationException;
            import com.xunji.core.anki.CardSide;
            import com.xunji.core.anki.RenderIssue;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.validation.FieldValidationException;
            import com.xunji.core.validation.InputValidator;
            import com.xunji.flashcards.anki.RenderedCard;
            import com.xunji.flashcards.data.AnkiNoteContent;
            import com.xunji.flashcards.data.AnkiRepository;
            import com.xunji.flashcards.data.StudyRepository;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.List;
            import java.util.Map;
            import java.util.NoSuchElementException;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.functions.Function5;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.sequences.Sequence;
            import kotlin.sequences.SequencesKt;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.flow.FlowKt;
            import kotlinx.coroutines.flow.MutableStateFlow;
            import kotlinx.coroutines.flow.StateFlow;
            import kotlinx.coroutines.flow.StateFlowKt;
            
            /* JADX INFO: compiled from: EditorViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0010 \n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0007\b\u0007\u0018\u00002\u00020\u0001BÍ\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\b\u0012&\b\u0002\u0010\t\u001a \b\u0001\u0012\u0004\u0012\u00020\u0005\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\n\u00126\b\u0002\u0010\u000e\u001a0\b\u0001\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\u000f\u0012>\b\u0002\u0010\u0013\u001a8\b\u0001\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0011\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\u0014¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010'\u001a\u00020\u00122\u0006\u0010(\u001a\u00020\u001eH\u0002J\u0016\u0010)\u001a\u00020\u00122\u0006\u0010*\u001a\u00020+2\u0006\u0010,\u001a\u00020\u0005J\u000e\u0010-\u001a\u00020\u00122\u0006\u0010.\u001a\u00020\u0015J\u0016\u0010/\u001a\u00020\u00122\u0006\u00100\u001a\u00020\u00052\u0006\u0010,\u001a\u00020\u0005J\u0006\u00101\u001a\u00020\u0012R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u0004\u0018\u00010\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082\u0004¢\u0006\u0002\n\u0000R.\u0010\t\u001a \b\u0001\u0012\u0004\u0012\u00020\u0005\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\nX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0019R>\u0010\u000e\u001a0\b\u0001\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0010\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0011\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00120\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\u000fX\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u001aRF\u0010\u0013\u001a8\b\u0001\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u0015\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00050\u0011\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\u0014X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u001bR\u0014\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001dX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001f\u001a\b\u0012\u0004\u0012\u00020\u001e0 ¢\u0006\b\n\u0000\u001a\u0004\b!\u0010\"R\u0010\u0010#\u001a\u0004\u0018\u00010\fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010$\u001a\u0004\u0018\u00010%X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010&\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000¨\u00062"}, d2 = {"Lcom/xunji/flashcards/ui/EditorViewModel;", "Landroidx/lifecycle/ViewModel;", "repo", "Lcom/xunji/flashcards/data/StudyRepository;", "deckId", "", "cardId", "handle", "Landroidx/lifecycle/SavedStateHandle;", "loadAnki", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "", "saveAnki", "Lkotlin/Function4;", "", "", "", "renderAnki", "Lkotlin/Function5;", "Lcom/xunji/core/anki/CardSide;", "Lcom/xunji/flashcards/anki/RenderedCard;", "<init>", "(Lcom/xunji/flashcards/data/StudyRepository;Ljava/lang/String;Ljava/lang/String;Landroidx/lifecycle/SavedStateHandle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function4;Lkotlin/jvm/functions/Function5;)V", "Lkotlin/jvm/functions/Function2;", "Lkotlin/jvm/functions/Function4;", "Lkotlin/jvm/functions/Function5;", "mutable", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/xunji/flashcards/ui/EditorUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "note", "previewJob", "Lkotlinx/coroutines/Job;", "previewGeneration", "persistDraft", "draft", "updateAnki", "index", "", "value", "preview", "side", "update", "field", "save", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */    public final class EditorViewModel extends ViewModel {
                public static final int $stable = 8;
                private final String cardId;
                private final String deckId;
                private final SavedStateHandle handle;
                private final Function2<String, Continuation<? super AnkiNoteContent>, Object> loadAnki;
                private final MutableStateFlow<EditorUiState> mutable;
                private AnkiNoteContent note;
                private long previewGeneration;
                private Job previewJob;
                private final Function5<AnkiNoteContent, String, CardSide, List<String>, Continuation<? super RenderedCard>, Object> renderAnki;
                private final StudyRepository repo;
                private final Function4<String, Long, List<String>, Continuation<? super Unit>, Object> saveAnki;
                private final StateFlow<EditorUiState> state;

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$1, reason: invalid class name */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\u000e\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "it", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$1", f = "EditorViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 12 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<String, Continuation, Object> {
                    int label;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass1(continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(String str, Continuation continuation) {
                        return ((AnonymousClass1) create(str, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 13 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                return null;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 12 */        public EditorViewModel(StudyRepository repo, String deckId, String cardId, SavedStateHandle handle, Function2<? super String, ? super Continuation<? super AnkiNoteContent>, ? extends Object> loadAnki, Function4<? super String, ? super Long, ? super List<String>, ? super Continuation<? super Unit>, ? extends Object> saveAnki, Function5<? super AnkiNoteContent, ? super String, ? super CardSide, ? super List<String>, ? super Continuation<? super RenderedCard>, ? extends Object> renderAnki) {
                    Intrinsics.checkNotNullParameter(repo, "repo");
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(handle, "handle");
                    Intrinsics.checkNotNullParameter(loadAnki, "loadAnki");
                    Intrinsics.checkNotNullParameter(saveAnki, "saveAnki");
                    Intrinsics.checkNotNullParameter(renderAnki, "renderAnki");
                    this.repo = repo;
                    this.deckId = deckId;
                    this.cardId = cardId;
                    this.handle = handle;
/* 14 */            this.loadAnki = loadAnki;
/* 15 */            this.saveAnki = saveAnki;
/* 16 */            this.renderAnki = renderAnki;
/* 17 */            String str = (String) get("front");
                    String str2 = str == null ? "" : str;
                    String str3 = (String) get("back");
                    String str4 = str3 == null ? "" : str3;
                    String str5 = (String) get("example");
                    String str6 = str5 == null ? "" : str5;
                    Boolean bool = (Boolean) get("dirty");
                    this.mutable = StateFlowKt.MutableStateFlow(new EditorUiState(str2, str4, str6, this.cardId != null, false, false, bool != null ? bool.booleanValue() : false, null, null, null, null, 0, null, false, 16304));
/* 18 */            this.state = FlowKt.asStateFlow(this.mutable);
/* 23 */            if (this.cardId != null) {
/* 1 */                 BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new AnonymousClass4(null), 3, null);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$2, reason: invalid class name */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\u0014\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\u0010\t\n\u0002\u0010 \u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u00042\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00030\u0005H\n"}, d2 = {"<anonymous>", "", "<unused var>", "", "", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$2", f = "EditorViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 13 */        static final class AnonymousClass2 extends SuspendLambda implements Function4<String, Long, List<? extends String>, Continuation<? super Unit>, Object> {
                    int label;

                    AnonymousClass2(Continuation<? super AnonymousClass2> continuation) {
                        super(4, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function4
                    public /* bridge */ /* synthetic */ Object invoke(String str, Long l, List<? extends String> list, Continuation<? super Unit> continuation) {
                        return invoke(str, l.longValue(), (List<String>) list, continuation);
                    }

                    public final Object invoke(String str, long j, List<String> list, Continuation<? super Unit> continuation) {
                        return new AnonymousClass2(continuation).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 14 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                throw new IllegalStateException("Anki editor unavailable".toString());
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$3, reason: invalid class name */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\u0018\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0010 \u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u00042\u0006\u0010\u0002\u001a\u00020\u00052\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u0006H\n"}, d2 = {"<anonymous>", "", "<unused var>", "Lcom/xunji/flashcards/data/AnkiNoteContent;", "", "Lcom/xunji/core/anki/CardSide;", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$3", f = "EditorViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 14 */        static final class AnonymousClass3 extends SuspendLambda implements Function5<AnkiNoteContent, String, CardSide, List<? extends String>, Continuation, Object> {
                    int label;

                    AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
                        super(5, continuation);
                    }

                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                    public final Object invoke2(AnkiNoteContent ankiNoteContent, String str, CardSide cardSide, List<String> list, Continuation continuation) {
                        return new AnonymousClass3(continuation).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.jvm.functions.Function5
                    public /* bridge */ /* synthetic */ Object invoke(AnkiNoteContent ankiNoteContent, String str, CardSide cardSide, List<? extends String> list, Continuation continuation) {
                        return invoke2(ankiNoteContent, str, cardSide, (List<String>) list, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 15 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                return null;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 17 */        public final StateFlow<EditorUiState> getState() {
/* 18 */            return this.state;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$4, reason: invalid class name */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$4", f = "EditorViewModel.kt", i = {1, 1, 1, 2}, l = {25, 30, 36}, m = "invokeSuspend", n = {"imported", "draftRevision", "draft", "imported"}, s = {"L$0", "L$1", "L$2", "L$0"}, v = 1)
/* 21 */        static final class AnonymousClass4 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    int label;

                    AnonymousClass4(Continuation<? super AnonymousClass4> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return EditorViewModel.this.new AnonymousClass4(continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass4) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:23:0x005e A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:25:0x006c A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:27:0x007c  */
                    /* JADX WARN: Code duplicated, block: B:28:0x007d  */
                    /* JADX WARN: Code duplicated, block: B:29:0x007f  */
                    /* JADX WARN: Code duplicated, block: B:31:0x0082 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:33:0x0093 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:34:0x009a  */
                    /* JADX WARN: Code duplicated, block: B:37:0x00c2 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:38:0x00c3  */
                    /* JADX WARN: Code duplicated, block: B:41:0x00e3  */
                    /* JADX WARN: Code duplicated, block: B:43:0x00e6 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:45:0x0139 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:47:0x0145 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:49:0x0152 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:51:0x0170 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:52:0x0171  */
                    /* JADX WARN: Code duplicated, block: B:56:0x0181 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:60:0x01c5 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:63:0x01da A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:66:0x01ef A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x001b, B:53:0x0172, B:54:0x017b, B:56:0x0181, B:58:0x019b, B:60:0x01c5, B:61:0x01c9, B:63:0x01da, B:64:0x01de, B:66:0x01ef, B:67:0x01f3, B:68:0x0220, B:69:0x0227, B:10:0x002e, B:39:0x00c7, B:43:0x00e6, B:45:0x0139, B:46:0x0144, B:11:0x0035, B:21:0x005a, B:23:0x005e, B:25:0x006c, B:31:0x0082, B:33:0x0093, B:35:0x009b, B:47:0x0145, B:48:0x0151, B:49:0x0152, B:18:0x0045), top: B:74:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:76:0x019b A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:77:? A[LOOP:0: B:54:0x017b->B:77:?, LOOP_END, SYNTHETIC] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 22 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objInvoke;
                        AnkiNoteContent imported;
                        Object objCandidates;
                        Long draftRevision;
                        boolean z;
                        ArrayList arrayList;
                        List draft;
                        Object objWithContext;
                        AnkiNoteContent imported2;
                        List names;
                        List fields;
                        EditorViewModel editorViewModel;
                        Flashcard card;
                        String front;
                        String back;
                        String example;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 23 */                            ResultKt.throwOnFailure($result);
/* 13 */                            Function2 function2 = EditorViewModel.this.loadAnki;
/* 13 */                            String str = EditorViewModel.this.cardId;
                                    this.label = 1;
                                    objInvoke = function2.invoke(str, this);
                                    if (objInvoke == coroutine_suspended) {
/* 23 */                                return coroutine_suspended;
                                    }
                                    imported = (AnkiNoteContent) objInvoke;
/* 26 */                            if (imported != null) {
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(imported);
                                        this.label = 3;
/* 13 */                                objCandidates = EditorViewModel.this.repo.candidates(EditorViewModel.this.deckId, this);
                                        if (objCandidates == coroutine_suspended) {
/* 23 */                                    return coroutine_suspended;
                                        }
                                        editorViewModel = EditorViewModel.this;
                                        for (Object obj : (Iterable) objCandidates) {
/* 90 */                                    if (Intrinsics.areEqual(((CardCandidate) obj).getCard().getId(), editorViewModel.cardId)) {
/* 36 */                                        card = ((CardCandidate) obj).getCard();
/* 13 */                                        MutableStateFlow mutableStateFlow = EditorViewModel.this.mutable;
/* 13 */                                        EditorUiState editorUiState = (EditorUiState) getValue();
/* 13 */                                        front = (String) get("front");
                                                if (front == null) {
                                                    front = card.getFront();
                                                }
                                                String str2 = front;
/* 13 */                                        back = (String) get("back");
                                                if (back == null) {
                                                    back = card.getBack();
                                                }
                                                String str3 = back;
/* 13 */                                        example = (String) get("example");
                                                if (example == null) {
                                                    example = card.getExample();
                                                }
                                                mutableStateFlow.setValue(editorUiState.copy((16368 & 1) != 0 ? editorUiState.front : str2, (16368 & 2) != 0 ? editorUiState.back : str3, (16368 & 4) != 0 ? editorUiState.example : example, (16368 & 8) != 0 ? editorUiState.loading : false, (16368 & 16) != 0 ? editorUiState.saving : false, (16368 & 32) != 0 ? editorUiState.saved : false, (16368 & 64) != 0 ? editorUiState.dirty : false, (16368 & 128) != 0 ? editorUiState.errors : null, (16368 & 256) != 0 ? editorUiState.error : null, (16368 & 512) != 0 ? editorUiState.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState.ankiFields : null, (16368 & 2048) != 0 ? editorUiState.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState.preview : null, (16368 & 8192) != 0 ? editorUiState.previewing : false));
/* 13 */                                        EditorViewModel.this.persistDraft((EditorUiState) getValue());
/* 42 */                                        return Unit.INSTANCE;
                                            }
                                        }
/* 91 */                                throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                    }
/* 13 */                            draftRevision = (Long) get("ankiRevision");
/* 28 */                            if (draftRevision != null) {
                                        z = true;
                                    } else if (draftRevision.longValue() == imported.getNote().getRevision()) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
/* 28 */                                throw new IllegalArgumentException("笔记已变更，请关闭旧草稿后重新编辑".toString());
                                    }
/* 13 */                            arrayList = (ArrayList) get("ankiFields");
                                    if (arrayList != null) {
                                        draft = CollectionsKt.toList(arrayList);
                                    } else {
                                        draft = null;
                                    }
                                    this.L$0 = imported;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(draftRevision);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(draft);
                                    this.label = 2;
/* 30 */                            objWithContext = BuildersKt.withContext(Dispatchers.getDefault(), new AnonymousClass2(imported, draft, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 23 */                                return coroutine_suspended;
                                    }
                                    imported2 = imported;
                                    Pair pair = (Pair) objWithContext;
                                    names = (List) pair.component1();
                                    fields = (List) pair.component2();
/* 31 */                            if (!(fields.size() == names.size())) {
/* 31 */                                throw new IllegalArgumentException("Failed requirement.".toString());
                                    }
/* 13 */                            EditorViewModel.this.note = imported2;
/* 13 */                            set("ankiRevision", Boxing.boxLong(imported2.getNote().getRevision()));
/* 13 */                            MutableStateFlow mutableStateFlow2 = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState2 = (EditorUiState) getValue();
                                    mutableStateFlow2.setValue(editorUiState2.copy((16368 & 1) != 0 ? editorUiState2.front : null, (16368 & 2) != 0 ? editorUiState2.back : null, (16368 & 4) != 0 ? editorUiState2.example : null, (16368 & 8) != 0 ? editorUiState2.loading : false, (16368 & 16) != 0 ? editorUiState2.saving : false, (16368 & 32) != 0 ? editorUiState2.saved : false, (16368 & 64) != 0 ? editorUiState2.dirty : false, (16368 & 128) != 0 ? editorUiState2.errors : null, (16368 & 256) != 0 ? editorUiState2.error : null, (16368 & 512) != 0 ? editorUiState2.ankiFieldNames : names, (16368 & 1024) != 0 ? editorUiState2.ankiFields : fields, (16368 & 2048) != 0 ? editorUiState2.linkedCards : imported2.getLinks().size(), (16368 & 4096) != 0 ? editorUiState2.preview : null, (16368 & 8192) != 0 ? editorUiState2.previewing : false));
/* 34 */                            return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    objInvoke = $result;
                                    imported = (AnkiNoteContent) objInvoke;
/* 26 */                            if (imported != null) {
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(imported);
                                        this.label = 3;
/* 13 */                                objCandidates = EditorViewModel.this.repo.candidates(EditorViewModel.this.deckId, this);
                                        if (objCandidates == coroutine_suspended) {
/* 23 */                                    return coroutine_suspended;
                                        }
                                        editorViewModel = EditorViewModel.this;
                                        while (r5.hasNext()) {
/* 90 */                                    if (Intrinsics.areEqual(((CardCandidate) obj).getCard().getId(), editorViewModel.cardId)) {
/* 36 */                                        card = ((CardCandidate) obj).getCard();
/* 13 */                                        MutableStateFlow mutableStateFlow3 = EditorViewModel.this.mutable;
/* 13 */                                        EditorUiState editorUiState3 = (EditorUiState) getValue();
/* 13 */                                        front = (String) get("front");
                                                if (front == null) {
                                                    front = card.getFront();
                                                }
                                                String str4 = front;
/* 13 */                                        back = (String) get("back");
                                                if (back == null) {
                                                    back = card.getBack();
                                                }
                                                String str5 = back;
/* 13 */                                        example = (String) get("example");
                                                if (example == null) {
                                                    example = card.getExample();
                                                }
                                                mutableStateFlow3.setValue(editorUiState3.copy((16368 & 1) != 0 ? editorUiState3.front : str4, (16368 & 2) != 0 ? editorUiState3.back : str5, (16368 & 4) != 0 ? editorUiState3.example : example, (16368 & 8) != 0 ? editorUiState3.loading : false, (16368 & 16) != 0 ? editorUiState3.saving : false, (16368 & 32) != 0 ? editorUiState3.saved : false, (16368 & 64) != 0 ? editorUiState3.dirty : false, (16368 & 128) != 0 ? editorUiState3.errors : null, (16368 & 256) != 0 ? editorUiState3.error : null, (16368 & 512) != 0 ? editorUiState3.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState3.ankiFields : null, (16368 & 2048) != 0 ? editorUiState3.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState3.preview : null, (16368 & 8192) != 0 ? editorUiState3.previewing : false));
/* 13 */                                        EditorViewModel.this.persistDraft((EditorUiState) getValue());
/* 42 */                                        return Unit.INSTANCE;
                                            }
                                        }
/* 91 */                                throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                    }
/* 13 */                            draftRevision = (Long) get("ankiRevision");
/* 28 */                            if (draftRevision != null) {
                                        z = true;
                                    } else if (draftRevision.longValue() == imported.getNote().getRevision()) {
                                        z = true;
                                    } else {
                                        z = false;
                                    }
                                    if (z) {
/* 28 */                                throw new IllegalArgumentException("笔记已变更，请关闭旧草稿后重新编辑".toString());
                                    }
/* 13 */                            arrayList = (ArrayList) get("ankiFields");
                                    if (arrayList != null) {
                                        draft = CollectionsKt.toList(arrayList);
                                    } else {
                                        draft = null;
                                    }
                                    this.L$0 = imported;
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(draftRevision);
                                    this.L$2 = SpillingKt.nullOutSpilledVariable(draft);
                                    this.label = 2;
/* 30 */                            objWithContext = BuildersKt.withContext(Dispatchers.getDefault(), new AnonymousClass2(imported, draft, null), this);
                                    if (objWithContext == coroutine_suspended) {
/* 23 */                                return coroutine_suspended;
                                    }
                                    imported2 = imported;
                                    Pair pair2 = (Pair) objWithContext;
                                    names = (List) pair2.component1();
                                    fields = (List) pair2.component2();
/* 31 */                            if (!(fields.size() == names.size())) {
/* 31 */                                throw new IllegalArgumentException("Failed requirement.".toString());
                                    }
/* 13 */                            EditorViewModel.this.note = imported2;
/* 13 */                            set("ankiRevision", Boxing.boxLong(imported2.getNote().getRevision()));
/* 13 */                            MutableStateFlow mutableStateFlow4 = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState4 = (EditorUiState) getValue();
                                    mutableStateFlow4.setValue(editorUiState4.copy((16368 & 1) != 0 ? editorUiState4.front : null, (16368 & 2) != 0 ? editorUiState4.back : null, (16368 & 4) != 0 ? editorUiState4.example : null, (16368 & 8) != 0 ? editorUiState4.loading : false, (16368 & 16) != 0 ? editorUiState4.saving : false, (16368 & 32) != 0 ? editorUiState4.saved : false, (16368 & 64) != 0 ? editorUiState4.dirty : false, (16368 & 128) != 0 ? editorUiState4.errors : null, (16368 & 256) != 0 ? editorUiState4.error : null, (16368 & 512) != 0 ? editorUiState4.ankiFieldNames : names, (16368 & 1024) != 0 ? editorUiState4.ankiFields : fields, (16368 & 2048) != 0 ? editorUiState4.linkedCards : imported2.getLinks().size(), (16368 & 4096) != 0 ? editorUiState4.preview : null, (16368 & 8192) != 0 ? editorUiState4.previewing : false));
/* 34 */                            return Unit.INSTANCE;
                                case 2:
                                    imported2 = (AnkiNoteContent) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objWithContext = $result;
                                    Pair pair3 = (Pair) objWithContext;
                                    names = (List) pair3.component1();
                                    fields = (List) pair3.component2();
/* 31 */                            if (!(fields.size() == names.size())) {
/* 31 */                                throw new IllegalArgumentException("Failed requirement.".toString());
                                    }
/* 13 */                            EditorViewModel.this.note = imported2;
/* 13 */                            set("ankiRevision", Boxing.boxLong(imported2.getNote().getRevision()));
/* 13 */                            MutableStateFlow mutableStateFlow5 = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState5 = (EditorUiState) getValue();
                                    mutableStateFlow5.setValue(editorUiState5.copy((16368 & 1) != 0 ? editorUiState5.front : null, (16368 & 2) != 0 ? editorUiState5.back : null, (16368 & 4) != 0 ? editorUiState5.example : null, (16368 & 8) != 0 ? editorUiState5.loading : false, (16368 & 16) != 0 ? editorUiState5.saving : false, (16368 & 32) != 0 ? editorUiState5.saved : false, (16368 & 64) != 0 ? editorUiState5.dirty : false, (16368 & 128) != 0 ? editorUiState5.errors : null, (16368 & 256) != 0 ? editorUiState5.error : null, (16368 & 512) != 0 ? editorUiState5.ankiFieldNames : names, (16368 & 1024) != 0 ? editorUiState5.ankiFields : fields, (16368 & 2048) != 0 ? editorUiState5.linkedCards : imported2.getLinks().size(), (16368 & 4096) != 0 ? editorUiState5.preview : null, (16368 & 8192) != 0 ? editorUiState5.previewing : false));
/* 34 */                            return Unit.INSTANCE;
                                case 3:
                                    ResultKt.throwOnFailure($result);
                                    objCandidates = $result;
                                    editorViewModel = EditorViewModel.this;
                                    while (r5.hasNext()) {
/* 90 */                                if (Intrinsics.areEqual(((CardCandidate) obj).getCard().getId(), editorViewModel.cardId)) {
/* 36 */                                    card = ((CardCandidate) obj).getCard();
/* 13 */                                    MutableStateFlow mutableStateFlow6 = EditorViewModel.this.mutable;
/* 13 */                                    EditorUiState editorUiState6 = (EditorUiState) getValue();
/* 13 */                                    front = (String) get("front");
                                            if (front == null) {
                                                front = card.getFront();
                                            }
                                            String str6 = front;
/* 13 */                                    back = (String) get("back");
                                            if (back == null) {
                                                back = card.getBack();
                                            }
                                            String str7 = back;
/* 13 */                                    example = (String) get("example");
                                            if (example == null) {
                                                example = card.getExample();
                                            }
                                            mutableStateFlow6.setValue(editorUiState6.copy((16368 & 1) != 0 ? editorUiState6.front : str6, (16368 & 2) != 0 ? editorUiState6.back : str7, (16368 & 4) != 0 ? editorUiState6.example : example, (16368 & 8) != 0 ? editorUiState6.loading : false, (16368 & 16) != 0 ? editorUiState6.saving : false, (16368 & 32) != 0 ? editorUiState6.saved : false, (16368 & 64) != 0 ? editorUiState6.dirty : false, (16368 & 128) != 0 ? editorUiState6.errors : null, (16368 & 256) != 0 ? editorUiState6.error : null, (16368 & 512) != 0 ? editorUiState6.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState6.ankiFields : null, (16368 & 2048) != 0 ? editorUiState6.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState6.preview : null, (16368 & 8192) != 0 ? editorUiState6.previewing : false));
/* 13 */                                    EditorViewModel.this.persistDraft((EditorUiState) getValue());
/* 42 */                                    return Unit.INSTANCE;
                                        }
                                    }
/* 91 */                            throw new NoSuchElementException("Collection contains no element matching the predicate.");
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 41 */                    throw e;
                        } catch (Exception e2) {
/* 13 */                    MutableStateFlow mutableStateFlow7 = EditorViewModel.this.mutable;
/* 13 */                    EditorUiState editorUiState7 = (EditorUiState) getValue();
                            mutableStateFlow7.setValue(editorUiState7.copy((16368 & 1) != 0 ? editorUiState7.front : null, (16368 & 2) != 0 ? editorUiState7.back : null, (16368 & 4) != 0 ? editorUiState7.example : null, (16368 & 8) != 0 ? editorUiState7.loading : false, (16368 & 16) != 0 ? editorUiState7.saving : false, (16368 & 32) != 0 ? editorUiState7.saved : false, (16368 & 64) != 0 ? editorUiState7.dirty : false, (16368 & 128) != 0 ? editorUiState7.errors : null, (16368 & 256) != 0 ? editorUiState7.error : "卡片无法读取，请返回重试", (16368 & 512) != 0 ? editorUiState7.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState7.ankiFields : null, (16368 & 2048) != 0 ? editorUiState7.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState7.preview : null, (16368 & 8192) != 0 ? editorUiState7.previewing : false));
                        }
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$4$2, reason: invalid class name */
                    /* JADX INFO: compiled from: EditorViewModel.kt */
                    @Metadata(d1 = {"\u0000\u0012\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u001a\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00020\u0001*\u00020\u0004H\n"}, d2 = {"<anonymous>", "Lkotlin/Pair;", "", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$4$2", f = "EditorViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 28 */            static final class AnonymousClass2 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Pair<? extends List<? extends String>, ? extends List<? extends String>>>, Object> {
                        final /* synthetic */ List<String> $draft;
                        final /* synthetic */ AnkiNoteContent $imported;
                        int label;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        AnonymousClass2(AnkiNoteContent ankiNoteContent, List<String> list, Continuation<? super AnonymousClass2> continuation) {
                            super(2, continuation);
                            this.$imported = ankiNoteContent;
                            this.$draft = list;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new AnonymousClass2(this.$imported, this.$draft, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public /* bridge */ /* synthetic */ Object invoke(CoroutineScope coroutineScope, Continuation<? super Pair<? extends List<? extends String>, ? extends List<? extends String>>> continuation) {
                            return invoke2(coroutineScope, (Continuation<? super Pair<? extends List<String>, ? extends List<String>>>) continuation);
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final Object invoke2(CoroutineScope coroutineScope, Continuation<? super Pair<? extends List<String>, ? extends List<String>>> continuation) {
                            return ((AnonymousClass2) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 29 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
                                    List<String> listStrings = AnkiRepository.INSTANCE.strings(this.$imported.getModel().getFieldNames());
                                    List<String> listStrings2 = this.$draft;
                                    if (listStrings2 == null) {
                                        listStrings2 = AnkiRepository.INSTANCE.strings(this.$imported.getNote().getFields());
                                    }
                                    return TuplesKt.to(listStrings, listStrings2);
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 44 */        public final void persistDraft(EditorUiState draft) {
/* 45 */            set("front", draft.getFront());
                    set("back", draft.getBack());
                    set("example", draft.getExample());
                    set("dirty", Boolean.valueOf(draft.getDirty()));
                }

/* 47 */        public final void updateAnki(int index, String value) {
                    Intrinsics.checkNotNullParameter(value, "value");
/* 48 */            EditorUiState s = getValue();
/* 49 */            if (s.getSaving() || s.getLoading() || s.getSaved()) {
/* 49 */                return;
                    }
                    boolean z = false;
                    if (index >= 0 && index < s.getAnkiFields().size()) {
                        z = true;
                    }
                    if (!z) {
/* 49 */                return;
                    }
/* 50 */            this.previewGeneration++;
                    Job job = this.previewJob;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
/* 51 */            List fields = CollectionsKt.toMutableList((Collection) s.getAnkiFields());
/* 51 */            fields.set(index, value);
/* 52 */            setValue(s.copy((16368 & 1) != 0 ? s.front : null, (16368 & 2) != 0 ? s.back : null, (16368 & 4) != 0 ? s.example : null, (16368 & 8) != 0 ? s.loading : false, (16368 & 16) != 0 ? s.saving : false, (16368 & 32) != 0 ? s.saved : false, (16368 & 64) != 0 ? s.dirty : true, (16368 & 128) != 0 ? s.errors : null, (16368 & 256) != 0 ? s.error : null, (16368 & 512) != 0 ? s.ankiFieldNames : null, (16368 & 1024) != 0 ? s.ankiFields : fields, (16368 & 2048) != 0 ? s.linkedCards : 0, (16368 & 4096) != 0 ? s.preview : null, (16368 & 8192) != 0 ? s.previewing : false));
/* 53 */            set("ankiFields", new ArrayList(fields));
                    set("dirty", true);
                }

/* 55 */        public final void preview(CardSide side) {
                    Intrinsics.checkNotNullParameter(side, "side");
/* 56 */            AnkiNoteContent content = this.note;
                    if (content == null) {
                        return;
                    }
/* 57 */            EditorUiState s = getValue();
/* 58 */            if (s.getSaving() || s.getLoading() || s.getSaved()) {
/* 58 */                return;
                    }
/* 59 */            Job job = this.previewJob;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
                    this.previewGeneration++;
                    long token = this.previewGeneration;
/* 60 */            setValue(s.copy((16368 & 1) != 0 ? s.front : null, (16368 & 2) != 0 ? s.back : null, (16368 & 4) != 0 ? s.example : null, (16368 & 8) != 0 ? s.loading : false, (16368 & 16) != 0 ? s.saving : false, (16368 & 32) != 0 ? s.saved : false, (16368 & 64) != 0 ? s.dirty : false, (16368 & 128) != 0 ? s.errors : null, (16368 & 256) != 0 ? s.error : null, (16368 & 512) != 0 ? s.ankiFieldNames : null, (16368 & 1024) != 0 ? s.ankiFields : null, (16368 & 2048) != 0 ? s.linkedCards : 0, (16368 & 4096) != 0 ? s.preview : null, (16368 & 8192) != 0 ? s.previewing : true));
/* 1 */             this.previewJob = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04451(content, side, s, token, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$preview$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$preview$1", f = "EditorViewModel.kt", i = {}, l = {63}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 59 */        static final class C04451 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ AnkiNoteContent $content;
                    final /* synthetic */ EditorUiState $s;
                    final /* synthetic */ CardSide $side;
                    final /* synthetic */ long $token;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04451(AnkiNoteContent ankiNoteContent, CardSide cardSide, EditorUiState editorUiState, long j, Continuation<? super C04451> continuation) {
                        super(2, continuation);
                        this.$content = ankiNoteContent;
                        this.$side = cardSide;
                        this.$s = editorUiState;
                        this.$token = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return EditorViewModel.this.new C04451(this.$content, this.$side, this.$s, this.$token, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04451) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 60 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objInvoke;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 61 */                            ResultKt.throwOnFailure($result);
/* 13 */                            Function5 function5 = EditorViewModel.this.renderAnki;
                                    AnkiNoteContent ankiNoteContent = this.$content;
/* 13 */                            String str = EditorViewModel.this.cardId;
                                    if (str == null) {
/* 63 */                                throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    CardSide cardSide = this.$side;
                                    List<String> ankiFields = this.$s.getAnkiFields();
                                    this.label = 1;
                                    objInvoke = function5.invoke(ankiNoteContent, str, cardSide, ankiFields, this);
                                    if (objInvoke == coroutine_suspended) {
/* 61 */                                return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    objInvoke = $result;
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            RenderedCard rendered = (RenderedCard) objInvoke;
                            if (this.$token == EditorViewModel.this.previewGeneration) {
/* 13 */                        MutableStateFlow mutableStateFlow = EditorViewModel.this.mutable;
/* 13 */                        EditorUiState editorUiState = (EditorUiState) getValue();
                                mutableStateFlow.setValue(editorUiState.copy((16368 & 1) != 0 ? editorUiState.front : null, (16368 & 2) != 0 ? editorUiState.back : null, (16368 & 4) != 0 ? editorUiState.example : null, (16368 & 8) != 0 ? editorUiState.loading : false, (16368 & 16) != 0 ? editorUiState.saving : false, (16368 & 32) != 0 ? editorUiState.saved : false, (16368 & 64) != 0 ? editorUiState.dirty : false, (16368 & 128) != 0 ? editorUiState.errors : null, (16368 & 256) != 0 ? editorUiState.error : null, (16368 & 512) != 0 ? editorUiState.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState.ankiFields : null, (16368 & 2048) != 0 ? editorUiState.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState.preview : rendered, (16368 & 8192) != 0 ? editorUiState.previewing : false));
                            }
                        } catch (CancellationException e) {
/* 65 */                    throw e;
                        } catch (Exception e2) {
                            if (this.$token == EditorViewModel.this.previewGeneration) {
/* 13 */                        MutableStateFlow mutableStateFlow2 = EditorViewModel.this.mutable;
/* 13 */                        EditorUiState editorUiState2 = (EditorUiState) getValue();
                                String message = e2.getMessage();
                                if (message == null) {
                                    message = "";
                                }
                                mutableStateFlow2.setValue(editorUiState2.copy((16368 & 1) != 0 ? editorUiState2.front : null, (16368 & 2) != 0 ? editorUiState2.back : null, (16368 & 4) != 0 ? editorUiState2.example : null, (16368 & 8) != 0 ? editorUiState2.loading : false, (16368 & 16) != 0 ? editorUiState2.saving : false, (16368 & 32) != 0 ? editorUiState2.saved : false, (16368 & 64) != 0 ? editorUiState2.dirty : false, (16368 & 128) != 0 ? editorUiState2.errors : null, (16368 & 256) != 0 ? editorUiState2.error : StringsKt.take("无法预览：" + message, 240), (16368 & 512) != 0 ? editorUiState2.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState2.ankiFields : null, (16368 & 2048) != 0 ? editorUiState2.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState2.preview : null, (16368 & 8192) != 0 ? editorUiState2.previewing : false));
                            }
                        }
/* 68 */                return Unit.INSTANCE;
                    }
                }

/* 70 */        public final void update(String field, String value) {
                    EditorUiState value2;
                    int i;
                    Object obj;
                    String str;
                    boolean z;
                    boolean z2;
                    boolean z3;
                    boolean z4;
                    Map map;
                    String str2;
                    List list;
                    List list2;
                    int i2;
                    RenderedCard renderedCard;
                    boolean z5;
                    String str3;
                    Intrinsics.checkNotNullParameter(field, "field");
                    String value3 = value;
                    Intrinsics.checkNotNullParameter(value3, "value");
/* 71 */            if (getValue().getSaving() || getValue().getLoading() || getValue().getSaved()) {
/* 71 */                return;
                    }
/* 72 */            MutableStateFlow<EditorUiState> mutableStateFlow = this.mutable;
                    if (Intrinsics.areEqual(field, "front")) {
                        value2 = getValue();
                        i = 16382;
                        obj = null;
                        str = null;
                        str3 = null;
                        z = false;
                        z2 = false;
                        z3 = false;
                        z4 = false;
                        map = null;
                        str2 = null;
                        list = null;
                        list2 = null;
                        i2 = 0;
                        renderedCard = null;
                        z5 = false;
                    } else if (Intrinsics.areEqual(field, "back")) {
                        value2 = getValue();
                        i = 16381;
                        obj = null;
                        value3 = null;
                        str3 = null;
                        z = false;
                        z2 = false;
                        z3 = false;
                        z4 = false;
                        map = null;
                        str2 = null;
                        list = null;
                        list2 = null;
                        i2 = 0;
                        renderedCard = null;
                        z5 = false;
                        str = value;
                    } else {
                        value2 = getValue();
                        i = 16379;
                        obj = null;
                        value3 = null;
                        str = null;
                        z = false;
                        z2 = false;
                        z3 = false;
                        z4 = false;
                        map = null;
                        str2 = null;
                        list = null;
                        list2 = null;
                        i2 = 0;
                        renderedCard = null;
                        z5 = false;
                        str3 = value;
                    }
                    EditorUiState editorUiStateCopy = value2.copy((16368 & 1) != 0 ? value2.front : value3, (16368 & 2) != 0 ? value2.back : str, (16368 & 4) != 0 ? value2.example : str3, (16368 & 8) != 0 ? value2.loading : z, (16368 & 16) != 0 ? value2.saving : z2, (16368 & 32) != 0 ? value2.saved : z3, (16368 & 64) != 0 ? value2.dirty : z4, (16368 & 128) != 0 ? value2.errors : map, (16368 & 256) != 0 ? value2.error : str2, (16368 & 512) != 0 ? value2.ankiFieldNames : list, (16368 & 1024) != 0 ? value2.ankiFields : list2, (16368 & 2048) != 0 ? value2.linkedCards : i2, (16368 & 4096) != 0 ? value2.preview : renderedCard, (16368 & 8192) != 0 ? value2.previewing : z5);
                    mutableStateFlow.setValue(editorUiStateCopy.copy((16368 & 1) != 0 ? editorUiStateCopy.front : null, (16368 & 2) != 0 ? editorUiStateCopy.back : null, (16368 & 4) != 0 ? editorUiStateCopy.example : null, (16368 & 8) != 0 ? editorUiStateCopy.loading : false, (16368 & 16) != 0 ? editorUiStateCopy.saving : false, (16368 & 32) != 0 ? editorUiStateCopy.saved : false, (16368 & 64) != 0 ? editorUiStateCopy.dirty : true, (16368 & 128) != 0 ? editorUiStateCopy.errors : MapsKt.emptyMap(), (16368 & 256) != 0 ? editorUiStateCopy.error : null, (16368 & 512) != 0 ? editorUiStateCopy.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiStateCopy.ankiFields : null, (16368 & 2048) != 0 ? editorUiStateCopy.linkedCards : 0, (16368 & 4096) != 0 ? editorUiStateCopy.preview : null, (16368 & 8192) != 0 ? editorUiStateCopy.previewing : false));
/* 73 */            persistDraft(getValue());
                }

/* 75 */        public final void save() {
/* 76 */            EditorUiState s = getValue();
                    if (s.getSaving() || s.getSaved() || s.getLoading()) {
/* 76 */                return;
                    }
/* 77 */            if (this.note == null) {
                        try {
                            InputValidator.INSTANCE.cardContent(s.getFront(), s.getBack(), s.getExample());
                        } catch (FieldValidationException e) {
/* 76 */                    MutableStateFlow<EditorUiState> mutableStateFlow = this.mutable;
                            String field = e.getField();
                            String message = e.getMessage();
                            if (message == null) {
                                message = "";
                            }
                            mutableStateFlow.setValue(s.copy((16368 & 1) != 0 ? s.front : null, (16368 & 2) != 0 ? s.back : null, (16368 & 4) != 0 ? s.example : null, (16368 & 8) != 0 ? s.loading : false, (16368 & 16) != 0 ? s.saving : false, (16368 & 32) != 0 ? s.saved : false, (16368 & 64) != 0 ? s.dirty : false, (16368 & 128) != 0 ? s.errors : MapsKt.mapOf(TuplesKt.to(field, message)), (16368 & 256) != 0 ? s.error : null, (16368 & 512) != 0 ? s.ankiFieldNames : null, (16368 & 1024) != 0 ? s.ankiFields : null, (16368 & 2048) != 0 ? s.linkedCards : 0, (16368 & 4096) != 0 ? s.preview : null, (16368 & 8192) != 0 ? s.previewing : false));
                            return;
                        }
                    }
/* 76 */            this.previewGeneration++;
/* 76 */            Job job = this.previewJob;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
/* 79 */            setValue(s.copy((16368 & 1) != 0 ? s.front : null, (16368 & 2) != 0 ? s.back : null, (16368 & 4) != 0 ? s.example : null, (16368 & 8) != 0 ? s.loading : false, (16368 & 16) != 0 ? s.saving : true, (16368 & 32) != 0 ? s.saved : false, (16368 & 64) != 0 ? s.dirty : false, (16368 & 128) != 0 ? s.errors : MapsKt.emptyMap(), (16368 & 256) != 0 ? s.error : null, (16368 & 512) != 0 ? s.ankiFieldNames : null, (16368 & 1024) != 0 ? s.ankiFields : null, (16368 & 2048) != 0 ? s.linkedCards : 0, (16368 & 4096) != 0 ? s.preview : null, (16368 & 8192) != 0 ? s.previewing : false));
/* 1 */             BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04461(s, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.EditorViewModel$save$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: EditorViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.EditorViewModel$save$1", f = "EditorViewModel.kt", i = {0, 1}, l = {81, 81}, m = "invokeSuspend", n = {"content", "content"}, s = {"L$0", "L$0"}, v = 1)
/* 78 */        static final class C04461 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ EditorUiState $s;
                    Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04461(EditorUiState editorUiState, Continuation<? super C04461> continuation) {
                        super(2, continuation);
                        this.$s = editorUiState;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return EditorViewModel.this.new C04461(this.$s, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04461) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 79 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 13 */                            AnkiNoteContent content = EditorViewModel.this.note;
                                    if (content != null) {
/* 13 */                                Function4 function4 = EditorViewModel.this.saveAnki;
                                        String id = content.getNote().getId();
                                        Long lBoxLong = Boxing.boxLong(content.getNote().getRevision());
                                        List<String> ankiFields = this.$s.getAnkiFields();
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(content);
                                        this.label = 1;
                                        if (function4.invoke(id, lBoxLong, ankiFields, this) == coroutine_suspended) {
/* 80 */                                    return coroutine_suspended;
                                        }
                                        Unit unit = Unit.INSTANCE;
                                    } else {
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(content);
                                        this.label = 2;
/* 13 */                                if (EditorViewModel.this.repo.saveCard(EditorViewModel.this.cardId, EditorViewModel.this.deckId, this.$s.getFront(), this.$s.getBack(), this.$s.getExample(), this) == coroutine_suspended) {
/* 80 */                                    return coroutine_suspended;
                                        }
                                    }
/* 13 */                            set("dirty", Boxing.boxBoolean(false));
/* 13 */                            MutableStateFlow mutableStateFlow = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState = (EditorUiState) getValue();
                                    mutableStateFlow.setValue(editorUiState.copy((16368 & 1) != 0 ? editorUiState.front : null, (16368 & 2) != 0 ? editorUiState.back : null, (16368 & 4) != 0 ? editorUiState.example : null, (16368 & 8) != 0 ? editorUiState.loading : false, (16368 & 16) != 0 ? editorUiState.saving : false, (16368 & 32) != 0 ? editorUiState.saved : true, (16368 & 64) != 0 ? editorUiState.dirty : false, (16368 & 128) != 0 ? editorUiState.errors : null, (16368 & 256) != 0 ? editorUiState.error : null, (16368 & 512) != 0 ? editorUiState.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState.ankiFields : null, (16368 & 2048) != 0 ? editorUiState.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState.preview : null, (16368 & 8192) != 0 ? editorUiState.previewing : false));
/* 85 */                            return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    Unit unit2 = Unit.INSTANCE;
/* 13 */                            set("dirty", Boxing.boxBoolean(false));
/* 13 */                            MutableStateFlow mutableStateFlow2 = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState2 = (EditorUiState) getValue();
                                    mutableStateFlow2.setValue(editorUiState2.copy((16368 & 1) != 0 ? editorUiState2.front : null, (16368 & 2) != 0 ? editorUiState2.back : null, (16368 & 4) != 0 ? editorUiState2.example : null, (16368 & 8) != 0 ? editorUiState2.loading : false, (16368 & 16) != 0 ? editorUiState2.saving : false, (16368 & 32) != 0 ? editorUiState2.saved : true, (16368 & 64) != 0 ? editorUiState2.dirty : false, (16368 & 128) != 0 ? editorUiState2.errors : null, (16368 & 256) != 0 ? editorUiState2.error : null, (16368 & 512) != 0 ? editorUiState2.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState2.ankiFields : null, (16368 & 2048) != 0 ? editorUiState2.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState2.preview : null, (16368 & 8192) != 0 ? editorUiState2.previewing : false));
/* 85 */                            return Unit.INSTANCE;
                                case 2:
                                    ResultKt.throwOnFailure($result);
/* 13 */                            set("dirty", Boxing.boxBoolean(false));
/* 13 */                            MutableStateFlow mutableStateFlow3 = EditorViewModel.this.mutable;
/* 13 */                            EditorUiState editorUiState3 = (EditorUiState) getValue();
                                    mutableStateFlow3.setValue(editorUiState3.copy((16368 & 1) != 0 ? editorUiState3.front : null, (16368 & 2) != 0 ? editorUiState3.back : null, (16368 & 4) != 0 ? editorUiState3.example : null, (16368 & 8) != 0 ? editorUiState3.loading : false, (16368 & 16) != 0 ? editorUiState3.saving : false, (16368 & 32) != 0 ? editorUiState3.saved : true, (16368 & 64) != 0 ? editorUiState3.dirty : false, (16368 & 128) != 0 ? editorUiState3.errors : null, (16368 & 256) != 0 ? editorUiState3.error : null, (16368 & 512) != 0 ? editorUiState3.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState3.ankiFields : null, (16368 & 2048) != 0 ? editorUiState3.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState3.preview : null, (16368 & 8192) != 0 ? editorUiState3.previewing : false));
/* 85 */                            return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (AnkiFieldValidationException e) {
/* 13 */                    MutableStateFlow mutableStateFlow4 = EditorViewModel.this.mutable;
/* 13 */                    EditorUiState editorUiState4 = (EditorUiState) getValue();
                            mutableStateFlow4.setValue(editorUiState4.copy((16368 & 1) != 0 ? editorUiState4.front : null, (16368 & 2) != 0 ? editorUiState4.back : null, (16368 & 4) != 0 ? editorUiState4.example : null, (16368 & 8) != 0 ? editorUiState4.loading : false, (16368 & 16) != 0 ? editorUiState4.saving : false, (16368 & 32) != 0 ? editorUiState4.saved : false, (16368 & 64) != 0 ? editorUiState4.dirty : false, (16368 & 128) != 0 ? editorUiState4.errors : null, (16368 & 256) != 0 ? editorUiState4.error : StringsKt.take("同笔记卡片校验失败：" + SequencesKt.joinToString$default(SequencesKt.take(SequencesKt.distinct(SequencesKt.flatMap(CollectionsKt.asSequence(e.getIssuesByCardId().values()), new Function1() { // from class: com.xunji.flashcards.ui.EditorViewModel$save$1$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return EditorViewModel.C04461.invokeSuspend$lambda$0((List) obj);
                                }
                            })), 4), "；", null, null, 0, null, new Function1() { // from class: com.xunji.flashcards.ui.EditorViewModel$save$1$$ExternalSyntheticLambda1
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return EditorViewModel.C04461.invokeSuspend$lambda$1((RenderIssue) obj);
                                }
                            }, 30, null), 240), (16368 & 512) != 0 ? editorUiState4.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState4.ankiFields : null, (16368 & 2048) != 0 ? editorUiState4.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState4.preview : null, (16368 & 8192) != 0 ? editorUiState4.previewing : false));
                        } catch (CancellationException e2) {
                            throw e2;
                        } catch (Exception e3) {
/* 13 */                    MutableStateFlow mutableStateFlow5 = EditorViewModel.this.mutable;
/* 13 */                    EditorUiState editorUiState5 = (EditorUiState) getValue();
                            String message = e3.getMessage();
                            if (message == null) {
                                message = "";
                            }
                            mutableStateFlow5.setValue(editorUiState5.copy((16368 & 1) != 0 ? editorUiState5.front : null, (16368 & 2) != 0 ? editorUiState5.back : null, (16368 & 4) != 0 ? editorUiState5.example : null, (16368 & 8) != 0 ? editorUiState5.loading : false, (16368 & 16) != 0 ? editorUiState5.saving : false, (16368 & 32) != 0 ? editorUiState5.saved : false, (16368 & 64) != 0 ? editorUiState5.dirty : false, (16368 & 128) != 0 ? editorUiState5.errors : null, (16368 & 256) != 0 ? editorUiState5.error : StringsKt.take("保存未完成，请检查字段或重新打开卡片：" + message, 240), (16368 & 512) != 0 ? editorUiState5.ankiFieldNames : null, (16368 & 1024) != 0 ? editorUiState5.ankiFields : null, (16368 & 2048) != 0 ? editorUiState5.linkedCards : 0, (16368 & 4096) != 0 ? editorUiState5.preview : null, (16368 & 8192) != 0 ? editorUiState5.previewing : false));
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 82 */            public static final Sequence invokeSuspend$lambda$0(List it) {
/* 83 */                return CollectionsKt.asSequence(it);
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 82 */            public static final CharSequence invokeSuspend$lambda$1(RenderIssue it) {
/* 83 */                return StringsKt.take(it.getDetail(), 160);
                    }
                }
            }

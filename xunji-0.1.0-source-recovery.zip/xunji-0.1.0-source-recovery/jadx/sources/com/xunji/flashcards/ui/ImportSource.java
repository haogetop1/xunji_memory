            package com.xunji.flashcards.ui;

            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0081\b\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\f\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\r\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u001f\u0010\u000e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010\u000f\u001a\u00020\u00102\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001J\t\u0010\u0014\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\b\u0010\tR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000b¨\u0006\u0015"}, d2 = {"Lcom/xunji/flashcards/ui/ImportSource;", "", "stream", "Ljava/io/InputStream;", "displayName", "", "<init>", "(Ljava/io/InputStream;Ljava/lang/String;)V", "getStream", "()Ljava/io/InputStream;", "getDisplayName", "()Ljava/lang/String;", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 17 */    public final /* data */ class ImportSource {
                public static final int $stable = 8;
                private final String displayName;
                private final InputStream stream;

                public static /* synthetic */ ImportSource copy$default(ImportSource importSource, InputStream inputStream, String str, int i, Object obj) {
                    if ((i & 1) != 0) {
                        inputStream = importSource.stream;
                    }
                    if ((i & 2) != 0) {
                        str = importSource.displayName;
                    }
                    return importSource.copy(inputStream, str);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final InputStream getStream() {
                    return this.stream;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getDisplayName() {
                    return this.displayName;
                }

                public final ImportSource copy(InputStream stream, String displayName) {
                    Intrinsics.checkNotNullParameter(stream, "stream");
                    return new ImportSource(stream, displayName);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof ImportSource)) {
                        return false;
                    }
                    ImportSource importSource = (ImportSource) other;
                    return Intrinsics.areEqual(this.stream, importSource.stream) && Intrinsics.areEqual(this.displayName, importSource.displayName);
                }

                public int hashCode() {
                    return (this.stream.hashCode() * 31) + (this.displayName == null ? 0 : this.displayName.hashCode());
                }

                public String toString() {
                    return "ImportSource(stream=" + this.stream + ", displayName=" + this.displayName + ")";
                }

/* 18 */        public ImportSource(InputStream stream, String displayName) {
                    Intrinsics.checkNotNullParameter(stream, "stream");
                    this.stream = stream;
                    this.displayName = displayName;
                }

/* 18 */        public final String getDisplayName() {
/* 19 */            return this.displayName;
                }

/* 18 */        public final InputStream getStream() {
/* 19 */            return this.stream;
                }
            }

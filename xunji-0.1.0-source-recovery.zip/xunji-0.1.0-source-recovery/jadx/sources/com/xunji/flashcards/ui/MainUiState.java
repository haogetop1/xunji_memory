            package com.xunji.flashcards.ui;

            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.DeckSummary;
            import com.xunji.core.stats.StatisticsSummary;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: UiModels.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b \b\u0087\b\u0018\u00002\u00020\u0001Bq\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\n\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n\u0012\b\b\u0002\u0010\f\u001a\u00020\n\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u0010\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0012¢\u0006\u0004\b\u0013\u0010\u0014J\t\u0010$\u001a\u00020\u0003HÆ\u0003J\u000f\u0010%\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005HÆ\u0003J\u000f\u0010&\u001a\b\u0012\u0004\u0012\u00020\b0\u0005HÆ\u0003J\t\u0010'\u001a\u00020\nHÆ\u0003J\t\u0010(\u001a\u00020\nHÆ\u0003J\t\u0010)\u001a\u00020\nHÆ\u0003J\u000b\u0010*\u001a\u0004\u0018\u00010\u000eHÆ\u0003J\t\u0010+\u001a\u00020\u0010HÆ\u0003J\u000b\u0010,\u001a\u0004\u0018\u00010\u0012HÆ\u0003Js\u0010-\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\u000e\b\u0002\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00052\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u00052\b\b\u0002\u0010\t\u001a\u00020\n2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\n2\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\u000e2\b\b\u0002\u0010\u000f\u001a\u00020\u00102\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0012HÆ\u0001J\u0013\u0010.\u001a\u00020\u00032\b\u0010/\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u00100\u001a\u00020\nHÖ\u0001J\t\u00101\u001a\u00020\u0012HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u0016R\u0017\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0017\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u0018R\u0011\u0010\t\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001a\u0010\u001bR\u0011\u0010\u000b\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001c\u0010\u001bR\u0011\u0010\f\u001a\u00020\n¢\u0006\b\n\u0000\u001a\u0004\b\u001d\u0010\u001bR\u0013\u0010\r\u001a\u0004\u0018\u00010\u000e¢\u0006\b\n\u0000\u001a\u0004\b\u001e\u0010\u001fR\u0011\u0010\u000f\u001a\u00020\u0010¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0013\u0010\u0011\u001a\u0004\u0018\u00010\u0012¢\u0006\b\n\u0000\u001a\u0004\b\"\u0010#¨\u00062"}, d2 = {"Lcom/xunji/flashcards/ui/MainUiState;", "", "loading", "", "decks", "", "Lcom/xunji/core/model/DeckSummary;", "cards", "Lcom/xunji/core/model/CardCandidate;", "due", "", "availableNew", "learnedNew", "statistics", "Lcom/xunji/core/stats/StatisticsSummary;", "settings", "Lcom/xunji/core/model/AppSettings;", "error", "", "<init>", "(ZLjava/util/List;Ljava/util/List;IIILcom/xunji/core/stats/StatisticsSummary;Lcom/xunji/core/model/AppSettings;Ljava/lang/String;)V", "getLoading", "()Z", "getDecks", "()Ljava/util/List;", "getCards", "getDue", "()I", "getAvailableNew", "getLearnedNew", "getStatistics", "()Lcom/xunji/core/stats/StatisticsSummary;", "getSettings", "()Lcom/xunji/core/model/AppSettings;", "getError", "()Ljava/lang/String;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "component9", "copy", "equals", "other", "hashCode", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 6 */     public final /* data */ class MainUiState {
                public static final int $stable = 8;
                private final int availableNew;
                private final List<CardCandidate> cards;
                private final List<DeckSummary> decks;
                private final int due;
                private final String error;
                private final int learnedNew;
                private final boolean loading;
                private final AppSettings settings;
                private final StatisticsSummary statistics;

                public MainUiState() {
                    this(false, null, null, 0, 0, 0, null, null, null, 511);
                }

                /* JADX WARN: Multi-variable type inference failed */
                public static /* synthetic */ MainUiState copy$default(MainUiState mainUiState, boolean z, List list, List list2, int i, int i2, int i3, StatisticsSummary statisticsSummary, AppSettings appSettings, String str, int i4, Object obj) {
                    if ((i4 & 1) != 0) {
                        z = mainUiState.loading;
                    }
                    if ((i4 & 2) != 0) {
                        list = mainUiState.decks;
                    }
                    if ((i4 & 4) != 0) {
                        list2 = mainUiState.cards;
                    }
                    if ((i4 & 8) != 0) {
                        i = mainUiState.due;
                    }
                    if ((i4 & 16) != 0) {
                        i2 = mainUiState.availableNew;
                    }
                    if ((i4 & 32) != 0) {
                        i3 = mainUiState.learnedNew;
                    }
                    if ((i4 & 64) != 0) {
                        statisticsSummary = mainUiState.statistics;
                    }
                    if ((i4 & 128) != 0) {
                        appSettings = mainUiState.settings;
                    }
                    if ((i4 & 256) != 0) {
                        str = mainUiState.error;
                    }
                    AppSettings appSettings2 = appSettings;
                    String str2 = str;
                    int i5 = i3;
                    StatisticsSummary statisticsSummary2 = statisticsSummary;
                    int i6 = i2;
                    List list3 = list2;
                    return mainUiState.copy(z, list, list3, i, i6, i5, statisticsSummary2, appSettings2, str2);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final boolean getLoading() {
                    return this.loading;
                }

                public final List<DeckSummary> component2() {
                    return this.decks;
                }

                public final List<CardCandidate> component3() {
                    return this.cards;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final int getDue() {
                    return this.due;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final int getAvailableNew() {
                    return this.availableNew;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final int getLearnedNew() {
                    return this.learnedNew;
                }

                /* JADX INFO: renamed from: component7, reason: from getter */
                public final StatisticsSummary getStatistics() {
                    return this.statistics;
                }

                /* JADX INFO: renamed from: component8, reason: from getter */
                public final AppSettings getSettings() {
                    return this.settings;
                }

                /* JADX INFO: renamed from: component9, reason: from getter */
                public final String getError() {
                    return this.error;
                }

                public final MainUiState copy(boolean loading, List<DeckSummary> decks, List<CardCandidate> cards, int due, int availableNew, int learnedNew, StatisticsSummary statistics, AppSettings settings, String error) {
                    Intrinsics.checkNotNullParameter(decks, "decks");
                    Intrinsics.checkNotNullParameter(cards, "cards");
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    return new MainUiState(loading, decks, cards, due, availableNew, learnedNew, statistics, settings, error);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof MainUiState)) {
                        return false;
                    }
                    MainUiState mainUiState = (MainUiState) other;
                    return this.loading == mainUiState.loading && Intrinsics.areEqual(this.decks, mainUiState.decks) && Intrinsics.areEqual(this.cards, mainUiState.cards) && this.due == mainUiState.due && this.availableNew == mainUiState.availableNew && this.learnedNew == mainUiState.learnedNew && Intrinsics.areEqual(this.statistics, mainUiState.statistics) && Intrinsics.areEqual(this.settings, mainUiState.settings) && Intrinsics.areEqual(this.error, mainUiState.error);
                }

                public int hashCode() {
                    return (((((((((((((((Boolean.hashCode(this.loading) * 31) + this.decks.hashCode()) * 31) + this.cards.hashCode()) * 31) + Integer.hashCode(this.due)) * 31) + Integer.hashCode(this.availableNew)) * 31) + Integer.hashCode(this.learnedNew)) * 31) + (this.statistics == null ? 0 : this.statistics.hashCode())) * 31) + this.settings.hashCode()) * 31) + (this.error != null ? this.error.hashCode() : 0);
                }

                public String toString() {
                    return "MainUiState(loading=" + this.loading + ", decks=" + this.decks + ", cards=" + this.cards + ", due=" + this.due + ", availableNew=" + this.availableNew + ", learnedNew=" + this.learnedNew + ", statistics=" + this.statistics + ", settings=" + this.settings + ", error=" + this.error + ")";
                }

/* 7 */         public MainUiState(boolean loading, List<DeckSummary> decks, List<CardCandidate> cards, int due, int availableNew, int learnedNew, StatisticsSummary statistics, AppSettings settings, String error) {
                    Intrinsics.checkNotNullParameter(decks, "decks");
                    Intrinsics.checkNotNullParameter(cards, "cards");
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    this.loading = loading;
                    this.decks = decks;
                    this.cards = cards;
                    this.due = due;
                    this.availableNew = availableNew;
                    this.learnedNew = learnedNew;
                    this.statistics = statistics;
                    this.settings = settings;
                    this.error = error;
                }

/* 7 */         public final int getAvailableNew() {
/* 8 */             return this.availableNew;
                }

/* 7 */         public final List<CardCandidate> getCards() {
/* 8 */             return this.cards;
                }

/* 7 */         public final List<DeckSummary> getDecks() {
/* 8 */             return this.decks;
                }

/* 7 */         public final int getDue() {
/* 8 */             return this.due;
                }

/* 7 */         public final String getError() {
/* 8 */             return this.error;
                }

/* 7 */         public final int getLearnedNew() {
/* 8 */             return this.learnedNew;
                }

/* 7 */         public final boolean getLoading() {
/* 8 */             return this.loading;
                }

/* 7 */         public final AppSettings getSettings() {
/* 8 */             return this.settings;
                }

/* 7 */         public final StatisticsSummary getStatistics() {
/* 8 */             return this.statistics;
                }
            }

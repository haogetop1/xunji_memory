            package com.xunji.flashcards.ui;

            import androidx.autofill.HintConstants;
            import androidx.core.view.MotionEventCompat;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelKt;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.Deck;
            import com.xunji.core.model.DeckSummary;
            import com.xunji.core.model.Phase;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.stats.StudyStatistics;
            import com.xunji.core.study.NewCardQuota;
            import com.xunji.core.time.DayBounds;
            import com.xunji.core.time.LocalDay;
            import com.xunji.flashcards.data.StudyRepository;
            import java.time.Clock;
            import java.time.Instant;
            import java.time.ZoneId;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.LinkedHashMap;
            import java.util.List;
            import java.util.Map;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.Pair;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function6;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.flow.Flow;
            import kotlinx.coroutines.flow.FlowCollector;
            import kotlinx.coroutines.flow.FlowKt;
            import kotlinx.coroutines.flow.MutableStateFlow;
            import kotlinx.coroutines.flow.StateFlow;
            import kotlinx.coroutines.flow.StateFlowKt;
            
            /* JADX INFO: compiled from: MainViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\b\b\u0007\u0018\u00002\u00020\u0001B\u0019\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0005¢\u0006\u0004\b\u0006\u0010\u0007J\u0006\u0010\u0018\u001a\u00020\u0019J\u001a\u0010\u001a\u001a\u00020\u00192\b\b\u0002\u0010\u001b\u001a\u00020\u00112\b\b\u0002\u0010\u001c\u001a\u00020\u0013J\u0016\u0010\u001d\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u001eH\u0086@¢\u0006\u0002\u0010 J\u001e\u0010!\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u001e2\u0006\u0010\u001f\u001a\u00020\u001eH\u0086@¢\u0006\u0002\u0010#J\u0016\u0010$\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u001eH\u0086@¢\u0006\u0002\u0010 J\u0016\u0010%\u001a\u00020\u00192\u0006\u0010\"\u001a\u00020\u001eH\u0086@¢\u0006\u0002\u0010 R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\f¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR0\u0010\u000f\u001a$\u0012 \u0012\u001e\u0012\f\u0012\n \u0012*\u0004\u0018\u00010\u00110\u0011\u0012\f\u0012\n \u0012*\u0004\u0018\u00010\u00130\u00130\u00100\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006&"}, d2 = {"Lcom/xunji/flashcards/ui/MainViewModel;", "Landroidx/lifecycle/ViewModel;", "repo", "Lcom/xunji/flashcards/data/StudyRepository;", "clock", "Ljava/time/Clock;", "<init>", "(Lcom/xunji/flashcards/data/StudyRepository;Ljava/time/Clock;)V", "mutable", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/xunji/flashcards/ui/MainUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "moment", "Lkotlin/Pair;", "Ljava/time/Instant;", "kotlin.jvm.PlatformType", "Ljava/time/ZoneId;", "observation", "Lkotlinx/coroutines/Job;", "observationVersion", "", "retryObservation", "", "refresh", "at", "zone", "createDeck", "", HintConstants.AUTOFILL_HINT_NAME, "(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "renameDeck", "id", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "deleteDeck", "deleteCard", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */    public final class MainViewModel extends ViewModel {
                public static final int $stable = 8;
                private final Clock clock;
                private final MutableStateFlow<Pair<Instant, ZoneId>> moment;
                private final MutableStateFlow<MainUiState> mutable;
                private Job observation;
                private long observationVersion;
                private final StudyRepository repo;
                private final StateFlow<MainUiState> state;

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.MainViewModel$createDeck$1, reason: invalid class name */
                /* JADX INFO: compiled from: MainViewModel.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.MainViewModel", f = "MainViewModel.kt", i = {0}, l = {MotionEventCompat.AXIS_GENERIC_12}, m = "createDeck", n = {HintConstants.AUTOFILL_HINT_NAME}, s = {"L$0"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
                        return MainViewModel.this.createDeck(null, this);
                    }
                }

/* 13 */        public MainViewModel(StudyRepository repo, Clock clock) {
                    Intrinsics.checkNotNullParameter(repo, "repo");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    this.repo = repo;
                    this.clock = clock;
/* 15 */            this.mutable = StateFlowKt.MutableStateFlow(new MainUiState(false, null, null, 0, 0, 0, null, null, null, 511));
/* 16 */            this.state = FlowKt.asStateFlow(this.mutable);
/* 17 */            this.moment = StateFlowKt.MutableStateFlow(TuplesKt.to(this.clock.instant(), ZoneId.systemDefault()));
/* 20 */            retryObservation();
                }

                /* JADX WARN: Illegal instructions before constructor call */
/* 13 */        public /* synthetic */ MainViewModel(StudyRepository studyRepository, Clock clock, int i, DefaultConstructorMarker defaultConstructorMarker) {
/* 14 */            if ((i & 2) != 0) {
                        clock = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clock, "systemUTC(...)");
                    }
                    this(studyRepository, clock);
                }

/* 15 */        public final StateFlow<MainUiState> getState() {
/* 16 */            return this.state;
                }

/* 21 */        public final void retryObservation() {
/* 22 */            this.observationVersion++;
/* 22 */            long version = this.observationVersion;
/* 23 */            Job job = this.observation;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
/* 22 */            setValue(MainUiState.copy$default(getValue(), true, null, null, 0, 0, 0, null, null, null, 254, null));
/* 22 */            this.observation = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04471(version, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.MainViewModel$retryObservation$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: MainViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.MainViewModel$retryObservation$1", f = "MainViewModel.kt", i = {}, l = {36}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 23 */        static final class C04471 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ long $version;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04471(long j, Continuation<? super C04471> continuation) {
                        super(2, continuation);
                        this.$version = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return MainViewModel.this.new C04471(this.$version, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04471) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 24 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 25 */                            ResultKt.throwOnFailure($result);
/* 36 */                            Flow flowFlowOn = FlowKt.flowOn(FlowKt.combine(MainViewModel.this.repo.observeDecks(), MainViewModel.this.repo.observeAllCards(), MainViewModel.this.repo.observeLogs(), MainViewModel.this.repo.observeSettings(), MainViewModel.this.moment, new C01001(null)), Dispatchers.getDefault());
                                    final long j = this.$version;
                                    final MainViewModel mainViewModel = MainViewModel.this;
                                    this.label = 1;
                                    if (flowFlowOn.collect(new FlowCollector() { // from class: com.xunji.flashcards.ui.MainViewModel.retryObservation.1.2
/* 35 */                                public final Object emit(MainUiState it, Continuation<? super Unit> continuation) {
                                            if (j == mainViewModel.observationVersion) {
/* 14 */                                        setValue(it);
                                            }
                                            return Unit.INSTANCE;
                                        }

                                        @Override // kotlinx.coroutines.flow.FlowCollector
/* 35 */                                public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
/* 36 */                                    return emit((MainUiState) value, (Continuation<? super Unit>) $completion);
                                        }
                                    }, this) == coroutine_suspended) {
/* 25 */                                return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 37 */                    throw e;
                        } catch (Exception e2) {
                            if (this.$version == MainViewModel.this.observationVersion) {
/* 14 */                        setValue(MainUiState.copy$default((MainUiState) getValue(), false, null, null, 0, 0, 0, null, null, "无法读取数据，请重试；已有数据会保留", 254, null));
                            }
                        }
/* 40 */                return Unit.INSTANCE;
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.ui.MainViewModel$retryObservation$1$1, reason: invalid class name and collision with other inner class name */
                    /* JADX INFO: compiled from: MainViewModel.kt */
                    @Metadata(d1 = {"\u00002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00040\u00032\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00060\u00032\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\b0\u00032\u0006\u0010\t\u001a\u00020\n2\"\u0010\u000b\u001a\u001e\u0012\f\u0012\n \u000e*\u0004\u0018\u00010\r0\r\u0012\f\u0012\n \u000e*\u0004\u0018\u00010\u000f0\u000f0\fH\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/ui/MainUiState;", "decks", "", "Lcom/xunji/core/model/Deck;", "cards", "Lcom/xunji/core/model/CardCandidate;", "logs", "Lcom/xunji/core/model/ReviewLog;", "settings", "Lcom/xunji/core/model/AppSettings;", "time", "Lkotlin/Pair;", "Ljava/time/Instant;", "kotlin.jvm.PlatformType", "Ljava/time/ZoneId;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.ui.MainViewModel$retryObservation$1$1", f = "MainViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 25 */            static final class C01001 extends SuspendLambda implements Function6<List<? extends Deck>, List<? extends CardCandidate>, List<? extends ReviewLog>, AppSettings, Pair<? extends Instant, ? extends ZoneId>, Continuation<? super MainUiState>, Object> {
                        /* synthetic */ Object L$0;
                        /* synthetic */ Object L$1;
                        /* synthetic */ Object L$2;
                        /* synthetic */ Object L$3;
                        /* synthetic */ Object L$4;
                        int label;

                        C01001(Continuation<? super C01001> continuation) {
                            super(6, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function6
                        public /* bridge */ /* synthetic */ Object invoke(List<? extends Deck> list, List<? extends CardCandidate> list2, List<? extends ReviewLog> list3, AppSettings appSettings, Pair<? extends Instant, ? extends ZoneId> pair, Continuation<? super MainUiState> continuation) {
                            return invoke2((List<Deck>) list, (List<CardCandidate>) list2, (List<ReviewLog>) list3, appSettings, (Pair<Instant, ? extends ZoneId>) pair, continuation);
                        }

                        /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
                        public final Object invoke2(List<Deck> list, List<CardCandidate> list2, List<ReviewLog> list3, AppSettings appSettings, Pair<Instant, ? extends ZoneId> pair, Continuation<? super MainUiState> continuation) {
                            C01001 c01001 = new C01001(continuation);
                            c01001.L$0 = list;
                            c01001.L$1 = list2;
                            c01001.L$2 = list3;
                            c01001.L$3 = appSettings;
                            c01001.L$4 = pair;
                            return c01001.invokeSuspend(Unit.INSTANCE);
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 26 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            int i;
                            int learned;
                            boolean z;
                            boolean z2;
                            int i2;
                            int i3;
                            ArrayList arrayList;
                            Object obj;
                            List decks = (List) this.L$0;
                            List<CardCandidate> cards = (List) this.L$1;
                            List<ReviewLog> list = (List) this.L$2;
                            AppSettings settings = (AppSettings) this.L$3;
                            Pair time = (Pair) this.L$4;
                            IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 28 */                            Instant at = (Instant) time.component1();
                                    ZoneId zone = (ZoneId) time.component2();
/* 29 */                            LocalDay localDay = LocalDay.INSTANCE;
                                    Intrinsics.checkNotNull(at);
                                    Intrinsics.checkNotNull(zone);
                                    DayBounds day = localDay.bounds(at, zone);
/* 30 */                            List list2 = cards;
                                    int i4 = 1;
/* 49 */                            if ((list2 instanceof Collection) && list2.isEmpty()) {
                                        learned = 0;
                                        i = 0;
                                    } else {
/* 50 */                                int i5 = 0;
/* 51 */                                Iterator it = list2.iterator();
                                        while (it.hasNext()) {
/* 30 */                                    Long firstReviewedAt = ((CardCandidate) it.next()).getSchedule().getFirstReviewedAt();
                                            if (firstReviewedAt != null) {
                                                long jLongValue = firstReviewedAt.longValue();
                                                boolean z3 = jLongValue >= day.getStart() && jLongValue < day.getEndExclusive();
                                                z = false;
                                                if (z3) {
                                                    z2 = true;
                                                }
/* 51 */                                        if (!z2 && (i5 = i5 + 1) < 0) {
                                                    CollectionsKt.throwCountOverflow();
                                                }
                                            } else {
                                                z = false;
                                            }
                                            z2 = z;
/* 51 */                                    if (!z2) {
                                            }
                                        }
/* 53 */                                i = 0;
                                        learned = i5;
                                    }
/* 31 */                            NewCardQuota newCardQuota = NewCardQuota.INSTANCE;
                                    List list3 = cards;
/* 54 */                            Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list3, 10));
/* 55 */                            Iterator it2 = list3.iterator();
                                    while (it2.hasNext()) {
/* 56 */                                arrayList2.add(((CardCandidate) it2.next()).getSchedule());
/* 31 */                                i4 = i4;
                                    }
/* 57 */                            int i6 = i4;
/* 31 */                            int remaining = newCardQuota.remaining((List) arrayList2, settings, at, zone);
/* 33 */                            Map counts = new LinkedHashMap();
                                    for (CardCandidate cardCandidate : cards) {
/* 34 */                                String deckId = cardCandidate.getCard().getDeckId();
                                        List decks2 = decks;
/* 59 */                                Object obj2 = counts.get(deckId);
/* 60 */                                if (obj2 == null) {
                                            obj = new int[3];
/* 62 */                                    counts.put(deckId, obj);
                                        } else {
                                            obj = obj2;
                                        }
/* 34 */                                int[] iArr = (int[]) obj;
                                        iArr[i] = iArr[i] + 1;
                                        if (invokeSuspend$due(at, cardCandidate)) {
                                            iArr[i6] = iArr[i6] + 1;
                                        }
                                        if (cardCandidate.getSchedule().getPhase() == Phase.NEW) {
                                            iArr[2] = iArr[2] + 1;
                                        }
                                        decks = decks2;
                                        cards = cards;
                                    }
                                    List cards2 = cards;
/* 35 */                            List list4 = decks;
                                    int i7 = 0;
/* 67 */                            Collection arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list4, 10));
                                    Iterable<Deck> iterable = list4;
                                    for (Deck deck : iterable) {
/* 35 */                                Iterable iterable2 = list4;
                                        int[] iArr2 = (int[]) counts.get(deck.getId());
                                        if (iArr2 == null) {
                                            iArr2 = new int[3];
                                        }
                                        int[] iArr3 = iArr2;
/* 69 */                                arrayList3.add(new DeckSummary(deck, iArr3[i], iArr3[i6], iArr3[2]));
                                        i7 = i7;
                                        list4 = iterable2;
                                        counts = counts;
                                        iterable = iterable;
                                    }
                                    ArrayList arrayList4 = (List) arrayList3;
/* 35 */                            List list5 = cards2;
/* 71 */                            if ((list5 instanceof Collection) && list5.isEmpty()) {
                                        i2 = i;
                                    } else {
/* 72 */                                i2 = 0;
/* 73 */                                Iterator it3 = list5.iterator();
                                        while (it3.hasNext()) {
/* 73 */                                    if (invokeSuspend$due(at, (CardCandidate) it3.next()) && (i2 = i2 + 1) < 0) {
                                                CollectionsKt.throwCountOverflow();
                                            }
                                        }
                                    }
/* 35 */                            List list6 = cards2;
/* 71 */                            if ((list6 instanceof Collection) && list6.isEmpty()) {
                                        arrayList = arrayList4;
                                        i3 = i;
                                    } else {
/* 72 */                                i3 = 0;
/* 73 */                                Iterator it4 = list6.iterator();
                                        while (it4.hasNext()) {
                                            arrayList4 = arrayList4;
                                            list6 = list6;
/* 73 */                                    if ((((CardCandidate) it4.next()).getSchedule().getPhase() == Phase.NEW ? i6 : i) != 0) {
                                                i3++;
                                                if (i3 < 0) {
                                                    CollectionsKt.throwCountOverflow();
                                                }
                                            }
                                        }
/* 74 */                                arrayList = arrayList4;
                                    }
/* 35 */                            return new MainUiState(false, arrayList, cards2, i2, Math.min(remaining, i3), learned, StudyStatistics.INSTANCE.summarize(list, at, zone), settings, null, 256);
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }

/* 31 */                private static final boolean invokeSuspend$due(Instant at, CardCandidate c) {
                            return c.getSchedule().getPhase() != Phase.NEW && c.getSchedule().getDueAt() <= at.toEpochMilli();
                        }
                    }
                }

/* 41 */        public static /* synthetic */ void refresh$default(MainViewModel mainViewModel, Instant instant, ZoneId zoneId, int i, Object obj) {
/* 42 */            if ((i & 1) != 0) {
                        instant = mainViewModel.clock.instant();
                        Intrinsics.checkNotNullExpressionValue(instant, "instant(...)");
                    }
                    if ((i & 2) != 0) {
                        zoneId = ZoneId.systemDefault();
                        Intrinsics.checkNotNullExpressionValue(zoneId, "systemDefault(...)");
                    }
                    mainViewModel.refresh(instant, zoneId);
                }

/* 41 */        public final void refresh(Instant at, ZoneId zone) {
                    Intrinsics.checkNotNullParameter(at, "at");
                    Intrinsics.checkNotNullParameter(zone, "zone");
/* 42 */            setValue(TuplesKt.to(at, zone));
                }

                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 42 */        public final Object createDeck(String name, Continuation<? super String> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    Object objCreateDeck;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            StudyRepository studyRepository = this.repo;
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(name);
                            anonymousClass1.label = 1;
                            objCreateDeck = studyRepository.createDeck(name, anonymousClass1);
                            if (objCreateDeck == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            objCreateDeck = $result;
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return ((Deck) objCreateDeck).getId();
                }

/* 43 */        public final Object renameDeck(String id, String name, Continuation<? super Unit> continuation) {
/* 44 */            Object objRenameDeck = this.repo.renameDeck(id, name, continuation);
                    return objRenameDeck == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objRenameDeck : Unit.INSTANCE;
                }

/* 44 */        public final Object deleteDeck(String id, Continuation<? super Unit> continuation) {
/* 45 */            Object objDeleteDeck = this.repo.deleteDeck(id, continuation);
                    return objDeleteDeck == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objDeleteDeck : Unit.INSTANCE;
                }

/* 45 */        public final Object deleteCard(String id, Continuation<? super Unit> continuation) {
/* 46 */            Object objDeleteCard = this.repo.deleteCard(id, continuation);
                    return objDeleteCard == IntrinsicsKt.getCOROUTINE_SUSPENDED() ? objDeleteCard : Unit.INSTANCE;
                }
            }

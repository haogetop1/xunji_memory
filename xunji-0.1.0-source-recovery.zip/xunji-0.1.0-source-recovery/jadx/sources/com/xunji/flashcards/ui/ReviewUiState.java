            package com.xunji.flashcards.ui;

            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Rating;
            import com.xunji.flashcards.anki.RenderedCard;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: UiModels.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u0001:\u0006\u0002\u0003\u0004\u0005\u0006\u0007\u0082\u0001\u0006\b\t\n\u000b\f\r¨\u0006\u000eÀ\u0006\u0003"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState;", "", "Loading", "Question", "Answer", "Submitting", "Complete", "Failure", "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "Lcom/xunji/flashcards/ui/ReviewUiState$Complete;", "Lcom/xunji/flashcards/ui/ReviewUiState$Failure;", "Lcom/xunji/flashcards/ui/ReviewUiState$Loading;", "Lcom/xunji/flashcards/ui/ReviewUiState$Question;", "Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 8 */     public interface ReviewUiState {

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\bÇ\n\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0004\u001a\u00020\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÖ\u0003J\t\u0010\b\u001a\u00020\tHÖ\u0001J\t\u0010\n\u001a\u00020\u000bHÖ\u0001¨\u0006\f"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Loading;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "<init>", "()V", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */         public static final /* data */ class Loading implements ReviewUiState {
                    public static final int $stable = 0;
                    public static final Loading INSTANCE = new Loading();

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Loading)) {
                            return false;
                        }
                        return true;
                    }

                    public int hashCode() {
                        return 784332585;
                    }

                    public String toString() {
                        return "Loading";
                    }

/* 10 */            private Loading() {
                    }
                }

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B#\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\u0004\b\b\u0010\tJ\t\u0010\u0010\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0011\u001a\u00020\u0005HÆ\u0003J\u000b\u0010\u0012\u001a\u0004\u0018\u00010\u0007HÆ\u0003J)\u0010\u0013\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0007HÆ\u0001J\u0013\u0010\u0014\u001a\u00020\u00152\b\u0010\u0016\u001a\u0004\u0018\u00010\u0017HÖ\u0003J\t\u0010\u0018\u001a\u00020\u0019HÖ\u0001J\t\u0010\u001a\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\f\u0010\rR\u0013\u0010\u0006\u001a\u0004\u0018\u00010\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u001b"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Question;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "candidate", "Lcom/xunji/core/model/CardCandidate;", "sessionId", "", "rendered", "Lcom/xunji/flashcards/anki/RenderedCard;", "<init>", "(Lcom/xunji/core/model/CardCandidate;Ljava/lang/String;Lcom/xunji/flashcards/anki/RenderedCard;)V", "getCandidate", "()Lcom/xunji/core/model/CardCandidate;", "getSessionId", "()Ljava/lang/String;", "getRendered", "()Lcom/xunji/flashcards/anki/RenderedCard;", "component1", "component2", "component3", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 10 */        public static final /* data */ class Question implements ReviewUiState {
                    public static final int $stable = 8;
                    private final CardCandidate candidate;
                    private final RenderedCard rendered;
                    private final String sessionId;

                    public static /* synthetic */ Question copy$default(Question question, CardCandidate cardCandidate, String str, RenderedCard renderedCard, int i, Object obj) {
                        if ((i & 1) != 0) {
                            cardCandidate = question.candidate;
                        }
                        if ((i & 2) != 0) {
                            str = question.sessionId;
                        }
                        if ((i & 4) != 0) {
                            renderedCard = question.rendered;
                        }
                        return question.copy(cardCandidate, str, renderedCard);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final CardCandidate getCandidate() {
                        return this.candidate;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final String getSessionId() {
                        return this.sessionId;
                    }

                    /* JADX INFO: renamed from: component3, reason: from getter */
                    public final RenderedCard getRendered() {
                        return this.rendered;
                    }

                    public final Question copy(CardCandidate candidate, String sessionId, RenderedCard rendered) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                        return new Question(candidate, sessionId, rendered);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Question)) {
                            return false;
                        }
                        Question question = (Question) other;
                        return Intrinsics.areEqual(this.candidate, question.candidate) && Intrinsics.areEqual(this.sessionId, question.sessionId) && Intrinsics.areEqual(this.rendered, question.rendered);
                    }

                    public int hashCode() {
                        return (((this.candidate.hashCode() * 31) + this.sessionId.hashCode()) * 31) + (this.rendered == null ? 0 : this.rendered.hashCode());
                    }

                    public String toString() {
                        return "Question(candidate=" + this.candidate + ", sessionId=" + this.sessionId + ", rendered=" + this.rendered + ")";
                    }

/* 11 */            public Question(CardCandidate candidate, String sessionId, RenderedCard rendered) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                        this.candidate = candidate;
                        this.sessionId = sessionId;
                        this.rendered = rendered;
                    }

/* 11 */            public final CardCandidate getCandidate() {
/* 12 */                return this.candidate;
                    }

/* 11 */            public final RenderedCard getRendered() {
/* 12 */                return this.rendered;
                    }

/* 11 */            public final String getSessionId() {
/* 12 */                return this.sessionId;
                    }
                }

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0015\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BO\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\b\u0012\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\u0004\b\u000e\u0010\u000fJ\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÆ\u0003J\u0015\u0010\u001d\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007HÆ\u0003J\u000b\u0010\u001e\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u001f\u001a\u0004\u0018\u00010\bHÆ\u0003J\u000b\u0010 \u001a\u0004\u0018\u00010\rHÆ\u0003JW\u0010!\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u0014\b\u0002\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\b2\n\b\u0002\u0010\f\u001a\u0004\u0018\u00010\rHÆ\u0001J\u0013\u0010\"\u001a\u00020#2\b\u0010$\u001a\u0004\u0018\u00010%HÖ\u0003J\t\u0010&\u001a\u00020'HÖ\u0001J\t\u0010(\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u001d\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\t0\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0013R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\b¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0018R\u0013\u0010\f\u001a\u0004\u0018\u00010\r¢\u0006\b\n\u0000\u001a\u0004\b\u0019\u0010\u001a¨\u0006)"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "candidate", "Lcom/xunji/core/model/CardCandidate;", "sessionId", "", "preview", "", "Lcom/xunji/core/model/Rating;", "Lcom/xunji/core/model/CardSchedule;", "error", "retryRating", "rendered", "Lcom/xunji/flashcards/anki/RenderedCard;", "<init>", "(Lcom/xunji/core/model/CardCandidate;Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;Lcom/xunji/core/model/Rating;Lcom/xunji/flashcards/anki/RenderedCard;)V", "getCandidate", "()Lcom/xunji/core/model/CardCandidate;", "getSessionId", "()Ljava/lang/String;", "getPreview", "()Ljava/util/Map;", "getError", "getRetryRating", "()Lcom/xunji/core/model/Rating;", "getRendered", "()Lcom/xunji/flashcards/anki/RenderedCard;", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 11 */        public static final /* data */ class Answer implements ReviewUiState {
                    public static final int $stable = 8;
                    private final CardCandidate candidate;
                    private final String error;
                    private final Map<Rating, CardSchedule> preview;
                    private final RenderedCard rendered;
                    private final Rating retryRating;
                    private final String sessionId;

                    /* JADX WARN: Multi-variable type inference failed */
                    public static /* synthetic */ Answer copy$default(Answer answer, CardCandidate cardCandidate, String str, Map map, String str2, Rating rating, RenderedCard renderedCard, int i, Object obj) {
                        if ((i & 1) != 0) {
                            cardCandidate = answer.candidate;
                        }
                        if ((i & 2) != 0) {
                            str = answer.sessionId;
                        }
                        if ((i & 4) != 0) {
                            map = answer.preview;
                        }
                        if ((i & 8) != 0) {
                            str2 = answer.error;
                        }
                        if ((i & 16) != 0) {
                            rating = answer.retryRating;
                        }
                        if ((i & 32) != 0) {
                            renderedCard = answer.rendered;
                        }
                        Rating rating2 = rating;
                        RenderedCard renderedCard2 = renderedCard;
                        return answer.copy(cardCandidate, str, map, str2, rating2, renderedCard2);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final CardCandidate getCandidate() {
                        return this.candidate;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final String getSessionId() {
                        return this.sessionId;
                    }

                    public final Map<Rating, CardSchedule> component3() {
                        return this.preview;
                    }

                    /* JADX INFO: renamed from: component4, reason: from getter */
                    public final String getError() {
                        return this.error;
                    }

                    /* JADX INFO: renamed from: component5, reason: from getter */
                    public final Rating getRetryRating() {
                        return this.retryRating;
                    }

                    /* JADX INFO: renamed from: component6, reason: from getter */
                    public final RenderedCard getRendered() {
                        return this.rendered;
                    }

                    public final Answer copy(CardCandidate candidate, String sessionId, Map<Rating, CardSchedule> preview, String error, Rating retryRating, RenderedCard rendered) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                        Intrinsics.checkNotNullParameter(preview, "preview");
                        return new Answer(candidate, sessionId, preview, error, retryRating, rendered);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Answer)) {
                            return false;
                        }
                        Answer answer = (Answer) other;
                        return Intrinsics.areEqual(this.candidate, answer.candidate) && Intrinsics.areEqual(this.sessionId, answer.sessionId) && Intrinsics.areEqual(this.preview, answer.preview) && Intrinsics.areEqual(this.error, answer.error) && this.retryRating == answer.retryRating && Intrinsics.areEqual(this.rendered, answer.rendered);
                    }

                    public int hashCode() {
                        return (((((((((this.candidate.hashCode() * 31) + this.sessionId.hashCode()) * 31) + this.preview.hashCode()) * 31) + (this.error == null ? 0 : this.error.hashCode())) * 31) + (this.retryRating == null ? 0 : this.retryRating.hashCode())) * 31) + (this.rendered != null ? this.rendered.hashCode() : 0);
                    }

                    public String toString() {
                        return "Answer(candidate=" + this.candidate + ", sessionId=" + this.sessionId + ", preview=" + this.preview + ", error=" + this.error + ", retryRating=" + this.retryRating + ", rendered=" + this.rendered + ")";
                    }

/* 12 */            public Answer(CardCandidate candidate, String sessionId, Map<Rating, CardSchedule> preview, String error, Rating retryRating, RenderedCard rendered) {
                        Intrinsics.checkNotNullParameter(candidate, "candidate");
                        Intrinsics.checkNotNullParameter(sessionId, "sessionId");
                        Intrinsics.checkNotNullParameter(preview, "preview");
                        this.candidate = candidate;
                        this.sessionId = sessionId;
                        this.preview = preview;
                        this.error = error;
                        this.retryRating = retryRating;
                        this.rendered = rendered;
                    }

/* 12 */            public final CardCandidate getCandidate() {
/* 13 */                return this.candidate;
                    }

/* 12 */            public final String getError() {
/* 13 */                return this.error;
                    }

/* 12 */            public final Map<Rating, CardSchedule> getPreview() {
/* 13 */                return this.preview;
                    }

/* 12 */            public final RenderedCard getRendered() {
/* 13 */                return this.rendered;
                    }

/* 12 */            public final Rating getRetryRating() {
/* 13 */                return this.retryRating;
                    }

/* 12 */            public final String getSessionId() {
/* 13 */                return this.sessionId;
                    }
                }

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0012"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "answer", "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "<init>", "(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V", "getAnswer", "()Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 12 */        public static final /* data */ class Submitting implements ReviewUiState {
                    public static final int $stable = 8;
                    private final Answer answer;

                    public static /* synthetic */ Submitting copy$default(Submitting submitting, Answer answer, int i, Object obj) {
                        if ((i & 1) != 0) {
                            answer = submitting.answer;
                        }
                        return submitting.copy(answer);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final Answer getAnswer() {
                        return this.answer;
                    }

                    public final Submitting copy(Answer answer) {
                        Intrinsics.checkNotNullParameter(answer, "answer");
                        return new Submitting(answer);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Submitting) && Intrinsics.areEqual(this.answer, ((Submitting) other).answer);
                    }

                    public int hashCode() {
                        return this.answer.hashCode();
                    }

                    public String toString() {
                        return "Submitting(answer=" + this.answer + ")";
                    }

/* 13 */            public Submitting(Answer answer) {
                        Intrinsics.checkNotNullParameter(answer, "answer");
                        this.answer = answer;
                    }

/* 13 */            public final Answer getAnswer() {
/* 14 */                return this.answer;
                    }
                }

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0013\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\b\u0087\b\u0018\u00002\u00020\u0001B)\u0012\b\u0010\u0002\u001a\u0004\u0018\u00010\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0003¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\u0012\u001a\u0004\u0018\u00010\u0003HÆ\u0003¢\u0006\u0002\u0010\u000bJ\t\u0010\u0013\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0014\u001a\u00020\u0005HÆ\u0003J\t\u0010\u0015\u001a\u00020\u0003HÆ\u0003J8\u0010\u0016\u001a\u00020\u00002\n\b\u0002\u0010\u0002\u001a\u0004\u0018\u00010\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0007\u001a\u00020\u0003HÆ\u0001¢\u0006\u0002\u0010\u0017J\u0013\u0010\u0018\u001a\u00020\u00192\b\u0010\u001a\u001a\u0004\u0018\u00010\u001bHÖ\u0003J\t\u0010\u001c\u001a\u00020\u0005HÖ\u0001J\t\u0010\u001d\u001a\u00020\u001eHÖ\u0001R\u0015\u0010\u0002\u001a\u0004\u0018\u00010\u0003¢\u0006\n\n\u0002\u0010\f\u001a\u0004\b\n\u0010\u000bR\u0011\u0010\u0004\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\r\u0010\u000eR\u0011\u0010\u0006\u001a\u00020\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u000f\u0010\u000eR\u0011\u0010\u0007\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011¨\u0006\u001f"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Complete;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "nextDueAt", "", "scoreCount", "", "distinctCards", "durationMs", "<init>", "(Ljava/lang/Long;IIJ)V", "getNextDueAt", "()Ljava/lang/Long;", "Ljava/lang/Long;", "getScoreCount", "()I", "getDistinctCards", "getDurationMs", "()J", "component1", "component2", "component3", "component4", "copy", "(Ljava/lang/Long;IIJ)Lcom/xunji/flashcards/ui/ReviewUiState$Complete;", "equals", "", "other", "", "hashCode", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */        public static final /* data */ class Complete implements ReviewUiState {
                    public static final int $stable = 0;
                    private final int distinctCards;
                    private final long durationMs;
                    private final Long nextDueAt;
                    private final int scoreCount;

                    public static /* synthetic */ Complete copy$default(Complete complete, Long l, int i, int i2, long j, int i3, Object obj) {
                        if ((i3 & 1) != 0) {
                            l = complete.nextDueAt;
                        }
                        if ((i3 & 2) != 0) {
                            i = complete.scoreCount;
                        }
                        if ((i3 & 4) != 0) {
                            i2 = complete.distinctCards;
                        }
                        if ((i3 & 8) != 0) {
                            j = complete.durationMs;
                        }
                        int i4 = i2;
                        return complete.copy(l, i, i4, j);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final Long getNextDueAt() {
                        return this.nextDueAt;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final int getScoreCount() {
                        return this.scoreCount;
                    }

                    /* JADX INFO: renamed from: component3, reason: from getter */
                    public final int getDistinctCards() {
                        return this.distinctCards;
                    }

                    /* JADX INFO: renamed from: component4, reason: from getter */
                    public final long getDurationMs() {
                        return this.durationMs;
                    }

                    public final Complete copy(Long nextDueAt, int scoreCount, int distinctCards, long durationMs) {
                        return new Complete(nextDueAt, scoreCount, distinctCards, durationMs);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Complete)) {
                            return false;
                        }
                        Complete complete = (Complete) other;
                        return Intrinsics.areEqual(this.nextDueAt, complete.nextDueAt) && this.scoreCount == complete.scoreCount && this.distinctCards == complete.distinctCards && this.durationMs == complete.durationMs;
                    }

                    public int hashCode() {
                        return ((((((this.nextDueAt == null ? 0 : this.nextDueAt.hashCode()) * 31) + Integer.hashCode(this.scoreCount)) * 31) + Integer.hashCode(this.distinctCards)) * 31) + Long.hashCode(this.durationMs);
                    }

                    public String toString() {
                        return "Complete(nextDueAt=" + this.nextDueAt + ", scoreCount=" + this.scoreCount + ", distinctCards=" + this.distinctCards + ", durationMs=" + this.durationMs + ")";
                    }

/* 14 */            public Complete(Long nextDueAt, int scoreCount, int distinctCards, long durationMs) {
                        this.nextDueAt = nextDueAt;
                        this.scoreCount = scoreCount;
                        this.distinctCards = distinctCards;
                        this.durationMs = durationMs;
                    }

/* 14 */            public final int getDistinctCards() {
/* 15 */                return this.distinctCards;
                    }

/* 14 */            public final long getDurationMs() {
/* 15 */                return this.durationMs;
                    }

/* 14 */            public final Long getNextDueAt() {
/* 15 */                return this.nextDueAt;
                    }

/* 14 */            public final int getScoreCount() {
/* 15 */                return this.scoreCount;
                    }
                }

                /* JADX INFO: compiled from: UiModels.kt */
                @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\rHÖ\u0003J\t\u0010\u000e\u001a\u00020\u000fHÖ\u0001J\t\u0010\u0010\u001a\u00020\u0003HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0011"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewUiState$Failure;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "message", "", "<init>", "(Ljava/lang/String;)V", "getMessage", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 14 */        public static final /* data */ class Failure implements ReviewUiState {
                    public static final int $stable = 0;
                    private final String message;

                    public static /* synthetic */ Failure copy$default(Failure failure, String str, int i, Object obj) {
                        if ((i & 1) != 0) {
                            str = failure.message;
                        }
                        return failure.copy(str);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final String getMessage() {
                        return this.message;
                    }

                    public final Failure copy(String message) {
                        Intrinsics.checkNotNullParameter(message, "message");
                        return new Failure(message);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        return (other instanceof Failure) && Intrinsics.areEqual(this.message, ((Failure) other).message);
                    }

                    public int hashCode() {
                        return this.message.hashCode();
                    }

                    public String toString() {
                        return "Failure(message=" + this.message + ")";
                    }

/* 15 */            public Failure(String message) {
                        Intrinsics.checkNotNullParameter(message, "message");
                        this.message = message;
                    }

/* 15 */            public final String getMessage() {
/* 16 */                return this.message;
                    }
                }
            }

            package com.xunji.flashcards.ui;

            import android.os.SystemClock;
            import androidx.compose.material.MenuKt;
            import androidx.core.view.MotionEventCompat;
            import androidx.lifecycle.SavedStateHandle;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelKt;
            import com.xunji.core.anki.CardSide;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Flashcard;
            import com.xunji.core.model.Rating;
            import com.xunji.core.model.ReviewLog;
            import com.xunji.core.scheduling.Scheduler;
            import com.xunji.core.study.NewCardQuota;
            import com.xunji.core.study.QueueDecision;
            import com.xunji.core.study.QueuePlanner;
            import com.xunji.core.study.SessionTimer;
            import com.xunji.flashcards.anki.RenderedCard;
            import com.xunji.flashcards.data.StudyRepository;
            import com.xunji.flashcards.study.GradeCommand;
            import com.xunji.flashcards.study.GradeResult;
            import com.xunji.flashcards.study.ReviewActions;
            import com.xunji.flashcards.study.UndoResult;
            import java.time.Clock;
            import java.time.Instant;
            import java.time.ZoneId;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import java.util.Map;
            import java.util.UUID;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.ContinuationImpl;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.flow.Flow;
            import kotlinx.coroutines.flow.FlowKt;
            import kotlinx.coroutines.flow.MutableStateFlow;
            import kotlinx.coroutines.flow.StateFlow;
            import kotlinx.coroutines.flow.StateFlowKt;
            import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
            
            /* JADX INFO: compiled from: ReviewViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000¶\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0007\u0018\u00002\u00020\u0001:\u0001TB\u0081\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\b\b\u0002\u0010\b\u001a\u00020\t\u0012\b\b\u0002\u0010\n\u001a\u00020\u000b\u0012\u000e\b\u0002\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\r\u0012\u000e\b\u0002\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\r\u0012,\b\u0002\u0010\u0011\u001a&\b\u0001\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0014\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012¢\u0006\u0004\b\u0018\u0010\u0019J\u0010\u00108\u001a\u00020#2\u0006\u00109\u001a\u00020:H\u0002J\b\u0010;\u001a\u00020<H\u0002J\u0010\u0010=\u001a\u00020<2\b\u0010)\u001a\u0004\u0018\u00010\u0013J1\u0010>\u001a\u00020<2\"\u0010?\u001a\u001e\b\u0001\u0012\u0004\u0012\u00020:\u0012\n\u0012\b\u0012\u0004\u0012\u00020<0\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00170@H\u0002¢\u0006\u0002\u0010AJ\u001e\u0010B\u001a\u00020<2\u0006\u0010C\u001a\u00020-2\u0006\u00109\u001a\u00020:H\u0082@¢\u0006\u0002\u0010DJ\u0016\u0010E\u001a\u00020F2\u0006\u0010C\u001a\u00020-H\u0082@¢\u0006\u0002\u0010GJ\u0016\u0010H\u001a\u00020<2\u0006\u00109\u001a\u00020:H\u0082@¢\u0006\u0002\u0010IJ\b\u0010J\u001a\u00020<H\u0002J\u0006\u0010K\u001a\u00020<J\u0006\u0010L\u001a\u00020<J\u000e\u0010M\u001a\u00020<2\u0006\u0010N\u001a\u00020OJ\u0006\u0010P\u001a\u00020<J\u000e\u0010Q\u001a\u00020<2\u0006\u0010*\u001a\u00020#J\b\u0010R\u001a\u00020<H\u0014J\u0006\u0010S\u001a\u00020<R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00100\rX\u0082\u0004¢\u0006\u0002\n\u0000R4\u0010\u0011\u001a&\b\u0001\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u0014\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00170\u0012X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u001aR\u0014\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001f¢\u0006\b\n\u0000\u001a\u0004\b \u0010!R\u0014\u0010\"\u001a\b\u0012\u0004\u0012\u00020#0\u001cX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010$\u001a\b\u0012\u0004\u0012\u00020#0\u001f¢\u0006\b\n\u0000\u001a\u0004\b%\u0010!R\u000e\u0010&\u001a\u00020'X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010(\u001a\u00020\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010)\u001a\u0004\u0018\u00010\u0013X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010*\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010+\u001a\u00020#X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010,\u001a\u0004\u0018\u00010-X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010.\u001a\u0004\u0018\u00010/X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00100\u001a\u0004\u0018\u000101X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00102\u001a\u0004\u0018\u000103X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u00104\u001a\u0004\u0018\u000103X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00105\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00106\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u00107\u001a\u00020\u0010X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006U"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewViewModel;", "Landroidx/lifecycle/ViewModel;", "repository", "Lcom/xunji/flashcards/data/StudyRepository;", "actions", "Lcom/xunji/flashcards/study/ReviewActions;", "scheduler", "Lcom/xunji/core/scheduling/Scheduler;", "handle", "Landroidx/lifecycle/SavedStateHandle;", "clock", "Ljava/time/Clock;", "zone", "Lkotlin/Function0;", "Ljava/time/ZoneId;", "monotonic", "", "present", "Lkotlin/Function3;", "", "Lcom/xunji/core/anki/CardSide;", "Lkotlin/coroutines/Continuation;", "Lcom/xunji/flashcards/anki/RenderedCard;", "", "<init>", "(Lcom/xunji/flashcards/data/StudyRepository;Lcom/xunji/flashcards/study/ReviewActions;Lcom/xunji/core/scheduling/Scheduler;Landroidx/lifecycle/SavedStateHandle;Ljava/time/Clock;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function3;)V", "Lkotlin/jvm/functions/Function3;", "mutable", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/xunji/flashcards/ui/ReviewUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "undoable", "", "canUndo", "getCanUndo", "timer", "Lcom/xunji/core/study/SessionTimer;", "sessionId", "deckId", "active", "foreground", "current", "Lcom/xunji/core/model/CardCandidate;", "pending", "Lcom/xunji/flashcards/study/GradeCommand;", "lastLog", "Lcom/xunji/core/model/ReviewLog;", "job", "Lkotlinx/coroutines/Job;", "refreshJob", "generation", "operation", "refreshSequence", "valid", "token", "Lcom/xunji/flashcards/ui/ReviewViewModel$Token;", "invalidateRefresh", "", "start", "launchOperation", "block", "Lkotlin/Function2;", "(Lkotlin/jvm/functions/Function2;)V", "showQuestion", "candidate", "(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewViewModel$Token;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "answer", "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "(Lcom/xunji/core/model/CardCandidate;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "next", "(Lcom/xunji/flashcards/ui/ReviewViewModel$Token;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "loadNext", "refresh", "reveal", "grade", "rating", "Lcom/xunji/core/model/Rating;", "undo", "setForeground", "onCleared", "finish", "Token", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 13 */    public final class ReviewViewModel extends ViewModel {
                public static final int $stable = 8;
                private final ReviewActions actions;
                private boolean active;
                private final StateFlow<Boolean> canUndo;
                private final Clock clock;
                private CardCandidate current;
                private String deckId;
                private boolean foreground;
                private long generation;
                private final SavedStateHandle handle;
                private Job job;
                private ReviewLog lastLog;
                private final Function0<Long> monotonic;
                private final MutableStateFlow<ReviewUiState> mutable;
                private long operation;
                private GradeCommand pending;
                private final Function3<String, CardSide, Continuation<? super RenderedCard>, Object> present;
                private Job refreshJob;
                private long refreshSequence;
                private final StudyRepository repository;
                private final Scheduler scheduler;
                private String sessionId;
                private final StateFlow<ReviewUiState> state;
                private final SessionTimer timer;
                private final MutableStateFlow<Boolean> undoable;
                private final Function0<ZoneId> zone;

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$answer$1, reason: invalid class name */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel", f = "ReviewViewModel.kt", i = {0}, l = {57}, m = "answer", n = {"candidate"}, s = {"L$0"}, v = 1)
                static final class AnonymousClass1 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;
                    /* synthetic */ Object result;

                    AnonymousClass1(Continuation<? super AnonymousClass1> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 16 */                return ReviewViewModel.this.answer(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$next$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel", f = "ReviewViewModel.kt", i = {0, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4}, l = {LockFreeTaskQueueCore.FROZEN_SHIFT, 62, 64, 68, 70}, m = "next", n = {"token", "token", "candidates", "token", "candidates", "schedules", "token", "candidates", "schedules", "settings", "decision", "remaining", "token", "candidates", "schedules", "settings", "decision", "remaining"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0", "L$0", "L$1", "L$2", "L$3", "L$4", "I$0"}, v = 1)
                static final class C04511 extends ContinuationImpl {
                    int I$0;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    Object L$4;
                    int label;
                    /* synthetic */ Object result;

                    C04511(Continuation<? super C04511> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 16 */                return ReviewViewModel.this.next(null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$showQuestion$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel", f = "ReviewViewModel.kt", i = {0, 0}, l = {51}, m = "showQuestion", n = {"candidate", "token"}, s = {"L$0", "L$1"}, v = 1)
                static final class C04541 extends ContinuationImpl {
                    Object L$0;
                    Object L$1;
                    int label;
                    /* synthetic */ Object result;

                    C04541(Continuation<? super C04541> continuation) {
                        super(continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) {
                        this.result = obj;
                        this.label |= Integer.MIN_VALUE;
/* 16 */                return ReviewViewModel.this.showQuestion(null, null, this);
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$3, reason: invalid class name */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0010\u000e\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0002\u001a\u00020\u0004H\n"}, d2 = {"<anonymous>", "", "<unused var>", "", "Lcom/xunji/core/anki/CardSide;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$3", f = "ReviewViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 14 */        static final class AnonymousClass3 extends SuspendLambda implements Function3<String, CardSide, Continuation, Object> {
                    int label;

                    AnonymousClass3(Continuation<? super AnonymousClass3> continuation) {
                        super(3, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(String str, CardSide cardSide, Continuation continuation) {
                        return new AnonymousClass3(continuation).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 15 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                return null;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX WARN: Multi-variable type inference failed */
/* 15 */        public ReviewViewModel(StudyRepository repository, ReviewActions actions, Scheduler scheduler, SavedStateHandle handle, Clock clock, Function0<? extends ZoneId> zone, Function0<Long> monotonic, Function3<? super String, ? super CardSide, ? super Continuation<? super RenderedCard>, ? extends Object> present) {
                    Intrinsics.checkNotNullParameter(repository, "repository");
                    Intrinsics.checkNotNullParameter(actions, "actions");
                    Intrinsics.checkNotNullParameter(scheduler, "scheduler");
                    Intrinsics.checkNotNullParameter(handle, "handle");
                    Intrinsics.checkNotNullParameter(clock, "clock");
                    Intrinsics.checkNotNullParameter(zone, "zone");
                    Intrinsics.checkNotNullParameter(monotonic, "monotonic");
                    Intrinsics.checkNotNullParameter(present, "present");
                    this.repository = repository;
                    this.actions = actions;
                    this.scheduler = scheduler;
                    this.handle = handle;
                    this.clock = clock;
                    this.zone = zone;
                    this.monotonic = monotonic;
                    this.present = present;
/* 17 */            this.mutable = StateFlowKt.MutableStateFlow(ReviewUiState.Loading.INSTANCE);
/* 18 */            this.state = FlowKt.asStateFlow(this.mutable);
/* 19 */            this.undoable = StateFlowKt.MutableStateFlow(false);
/* 20 */            this.canUndo = FlowKt.asStateFlow(this.undoable);
/* 21 */            this.timer = new SessionTimer();
/* 22 */            this.sessionId = "";
/* 25 */            this.foreground = true;
                }

                /* JADX WARN: Illegal instructions before constructor call */
/* 15 */        public /* synthetic */ ReviewViewModel(StudyRepository studyRepository, ReviewActions reviewActions, Scheduler scheduler, SavedStateHandle savedStateHandle, Clock clock, Function0 function0, Function0 function1, Function3 function3, int i, DefaultConstructorMarker defaultConstructorMarker) {
                    Clock clock2;
/* 16 */            SavedStateHandle savedStateHandle2 = (i & 8) != 0 ? new SavedStateHandle() : savedStateHandle;
/* 16 */            if ((i & 16) != 0) {
                        Clock clockSystemUTC = Clock.systemUTC();
                        Intrinsics.checkNotNullExpressionValue(clockSystemUTC, "systemUTC(...)");
                        clock2 = clockSystemUTC;
                    } else {
                        clock2 = clock;
                    }
/* 16 */            this(studyRepository, reviewActions, scheduler, savedStateHandle2, clock2, (i & 32) != 0 ? new Function0() { // from class: com.xunji.flashcards.ui.ReviewViewModel$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
/* 16 */                    return ZoneId.systemDefault();
                        }
                    } : function0, (i & 64) != 0 ? new Function0() { // from class: com.xunji.flashcards.ui.ReviewViewModel$$ExternalSyntheticLambda1
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
/* 16 */                    return Long.valueOf(SystemClock.elapsedRealtime());
                        }
                    } : function1, (i & 128) != 0 ? new AnonymousClass3(null) : function3);
                }

/* 17 */        public final StateFlow<ReviewUiState> getState() {
/* 18 */            return this.state;
                }

/* 19 */        public final StateFlow<Boolean> getCanUndo() {
/* 20 */            return this.canUndo;
                }

                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\b\u0082\b\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\t\u0010\n\u001a\u00020\u0003HÆ\u0003J\t\u0010\u000b\u001a\u00020\u0003HÆ\u0003J\u001d\u0010\f\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\r\u001a\u00020\u000e2\b\u0010\u000f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\u0010\u001a\u00020\u0011HÖ\u0001J\t\u0010\u0012\u001a\u00020\u0013HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u0007\u0010\bR\u0011\u0010\u0004\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\t\u0010\b¨\u0006\u0014"}, d2 = {"Lcom/xunji/flashcards/ui/ReviewViewModel$Token;", "", "generation", "", "operation", "<init>", "(JJ)V", "getGeneration", "()J", "getOperation", "component1", "component2", "copy", "equals", "", "other", "hashCode", "", "toString", "", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 32 */        private static final /* data */ class Token {
                    private final long generation;
                    private final long operation;

                    public static /* synthetic */ Token copy$default(Token token, long j, long j2, int i, Object obj) {
                        if ((i & 1) != 0) {
                            j = token.generation;
                        }
                        if ((i & 2) != 0) {
                            j2 = token.operation;
                        }
                        return token.copy(j, j2);
                    }

                    /* JADX INFO: renamed from: component1, reason: from getter */
                    public final long getGeneration() {
                        return this.generation;
                    }

                    /* JADX INFO: renamed from: component2, reason: from getter */
                    public final long getOperation() {
                        return this.operation;
                    }

                    public final Token copy(long generation, long operation) {
                        return new Token(generation, operation);
                    }

                    public boolean equals(Object other) {
                        if (this == other) {
                            return true;
                        }
                        if (!(other instanceof Token)) {
                            return false;
                        }
                        Token token = (Token) other;
                        return this.generation == token.generation && this.operation == token.operation;
                    }

                    public int hashCode() {
                        return (Long.hashCode(this.generation) * 31) + Long.hashCode(this.operation);
                    }

                    public String toString() {
                        return "Token(generation=" + this.generation + ", operation=" + this.operation + ")";
                    }

/* 33 */            public Token(long generation, long operation) {
                        this.generation = generation;
                        this.operation = operation;
                    }

/* 33 */            public final long getGeneration() {
/* 34 */                return this.generation;
                    }

/* 33 */            public final long getOperation() {
/* 34 */                return this.operation;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public final boolean valid(Token token) {
                    return this.active && token.getGeneration() == this.generation && token.getOperation() == this.operation;
                }

/* 35 */        private final void invalidateRefresh() {
/* 36 */            this.refreshSequence++;
                    Job job = this.refreshJob;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
                    this.refreshJob = null;
                }

/* 37 */        public final void start(String deckId) {
/* 38 */            if (this.active && Intrinsics.areEqual(this.deckId, deckId)) {
                        return;
                    }
/* 39 */            finish();
                    this.active = true;
                    this.deckId = deckId;
                    String string = UUID.randomUUID().toString();
                    Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                    this.sessionId = string;
                    set("sessionId", this.sessionId);
                    loadNext();
                }

/* 41 */        private final void launchOperation(Function2<? super Token, ? super Continuation<? super Unit>, ? extends Object> block) {
/* 42 */            invalidateRefresh();
                    Job job = this.job;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
                    long j = this.generation;
                    this.operation++;
/* 43 */            Token token = new Token(j, this.operation);
/* 1 */             this.job = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04491(block, token, this, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$launchOperation$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$launchOperation$1", f = "ReviewViewModel.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_14}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 42 */        static final class C04491 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Function2<Token, Continuation<? super Unit>, Object> $block;
                    final /* synthetic */ Token $token;
                    int label;
                    final /* synthetic */ ReviewViewModel this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    C04491(Function2<? super Token, ? super Continuation<? super Unit>, ? extends Object> function2, Token token, ReviewViewModel reviewViewModel, Continuation<? super C04491> continuation) {
                        super(2, continuation);
                        this.$block = function2;
                        this.$token = token;
                        this.this$0 = reviewViewModel;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04491(this.$block, this.$token, this.this$0, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04491) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 43 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 44 */                            ResultKt.throwOnFailure($result);
/* 45 */                            Function2<Token, Continuation<? super Unit>, Object> function2 = this.$block;
                                    Token token = this.$token;
                                    this.label = 1;
                                    if (function2.invoke(token, this) == coroutine_suspended) {
/* 44 */                                return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 45 */                    throw e;
                        } catch (Exception e2) {
/* 16 */                    if (this.this$0.valid(this.$token)) {
/* 16 */                        setValue(new ReviewUiState.Failure("暂时无法读取卡片，请重试"));
                            }
                        }
/* 48 */                return Unit.INSTANCE;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:7:0x0014  */
/* 49 */        public final Object showQuestion(CardCandidate candidate, Token token, Continuation<? super Unit> continuation) throws Throwable {
                    C04541 c04541;
                    Object objInvoke;
                    if (continuation instanceof C04541) {
                        c04541 = (C04541) continuation;
                        if ((c04541.label & Integer.MIN_VALUE) != 0) {
                            c04541.label -= Integer.MIN_VALUE;
                        } else {
                            c04541 = new C04541(continuation);
                        }
                    } else {
                        c04541 = new C04541(continuation);
                    }
                    Object $result = c04541.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04541.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 51 */                    Function3<String, CardSide, Continuation<? super RenderedCard>, Object> function3 = this.present;
                            String id = candidate.getCard().getId();
                            CardSide cardSide = CardSide.QUESTION;
                            c04541.L$0 = candidate;
                            c04541.L$1 = token;
                            c04541.label = 1;
                            objInvoke = function3.invoke(id, cardSide, c04541);
                            if (objInvoke == coroutine_suspended) {
/* 50 */                        return coroutine_suspended;
                            }
                            break;
                        case 1:
                            token = (Token) c04541.L$1;
                            candidate = (CardCandidate) c04541.L$0;
                            ResultKt.throwOnFailure($result);
                            objInvoke = $result;
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    RenderedCard rendered = (RenderedCard) objInvoke;
/* 52 */            if (!valid(token)) {
                        return Unit.INSTANCE;
                    }
/* 53 */            this.current = candidate;
                    this.pending = null;
                    this.timer.reset();
                    if (this.foreground) {
                        this.timer.resume(invoke().longValue());
                    }
/* 54 */            set("cardId", candidate.getCard().getId());
                    set("revealed", Boxing.boxBoolean(false));
/* 55 */            setValue(new ReviewUiState.Question(candidate, this.sessionId, rendered));
/* 56 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
/* 56 */        public final Object answer(CardCandidate candidate, Continuation<? super ReviewUiState.Answer> continuation) throws Throwable {
                    AnonymousClass1 anonymousClass1;
                    Map<Rating, CardSchedule> map;
                    Object obj;
                    CardCandidate cardCandidate;
                    String str;
                    if (continuation instanceof AnonymousClass1) {
                        anonymousClass1 = (AnonymousClass1) continuation;
                        if ((anonymousClass1.label & Integer.MIN_VALUE) != 0) {
                            anonymousClass1.label -= Integer.MIN_VALUE;
                        } else {
                            anonymousClass1 = new AnonymousClass1(continuation);
                        }
                    } else {
                        anonymousClass1 = new AnonymousClass1(continuation);
                    }
                    Object $result = anonymousClass1.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (anonymousClass1.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            String str2 = this.sessionId;
                            Scheduler scheduler = this.scheduler;
                            CardSchedule schedule = candidate.getSchedule();
                            Instant instant = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant, "instant(...)");
                            Map<Rating, CardSchedule> mapPreview = scheduler.preview(schedule, instant);
                            Function3<String, CardSide, Continuation<? super RenderedCard>, Object> function3 = this.present;
                            String id = candidate.getCard().getId();
                            CardSide cardSide = CardSide.ANSWER;
                            anonymousClass1.L$0 = SpillingKt.nullOutSpilledVariable(candidate);
                            anonymousClass1.L$1 = candidate;
                            anonymousClass1.L$2 = str2;
                            anonymousClass1.L$3 = mapPreview;
                            anonymousClass1.label = 1;
                            Object objInvoke = function3.invoke(id, cardSide, anonymousClass1);
                            if (objInvoke == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            map = mapPreview;
                            obj = objInvoke;
                            cardCandidate = candidate;
                            str = str2;
                            break;
                        case 1:
                            Map<Rating, CardSchedule> map2 = (Map) anonymousClass1.L$3;
                            String str3 = (String) anonymousClass1.L$2;
                            CardCandidate cardCandidate2 = (CardCandidate) anonymousClass1.L$1;
                            ResultKt.throwOnFailure($result);
                            map = map2;
                            cardCandidate = cardCandidate2;
                            obj = $result;
                            str = str3;
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return new ReviewUiState.Answer(cardCandidate, str, map, null, null, (RenderedCard) obj, 24);
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:27:0x00ba  */
                /* JADX WARN: Code duplicated, block: B:29:0x00bd  */
                /* JADX WARN: Code duplicated, block: B:31:0x00d0 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:32:0x00d1  */
                /* JADX WARN: Code duplicated, block: B:35:0x00de  */
                /* JADX WARN: Code duplicated, block: B:37:0x00e1  */
                /* JADX WARN: Code duplicated, block: B:39:0x00f6 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:40:0x00f7  */
                /* JADX WARN: Code duplicated, block: B:43:0x0101  */
                /* JADX WARN: Code duplicated, block: B:45:0x0104  */
                /* JADX WARN: Code duplicated, block: B:47:0x0130  */
                /* JADX WARN: Code duplicated, block: B:49:0x0160 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:50:0x0161  */
                /* JADX WARN: Code duplicated, block: B:53:0x016a  */
                /* JADX WARN: Code duplicated, block: B:55:0x0191 A[RETURN] */
                /* JADX WARN: Code duplicated, block: B:56:0x0192  */
                /* JADX WARN: Code duplicated, block: B:60:0x01ae  */
                /* JADX WARN: Code duplicated, block: B:62:0x01c6  */
                /* JADX WARN: Code duplicated, block: B:66:0x01d0  */
                /* JADX WARN: Code duplicated, block: B:70:0x01e6  */
                /* JADX WARN: Code duplicated, block: B:72:0x01e9  */
                /* JADX WARN: Code duplicated, block: B:74:0x0204  */
                /* JADX WARN: Code duplicated, block: B:75:0x0208  */
                /* JADX WARN: Code duplicated, block: B:77:0x020b  */
                /* JADX WARN: Code duplicated, block: B:7:0x0018  */
                /* JADX WARN: Code duplicated, block: B:81:0x0236 A[LOOP:1: B:79:0x0230->B:81:0x0236, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:85:0x0268 A[LOOP:2: B:83:0x0262->B:85:0x0268, LOOP_END] */
                /* JADX WARN: Code duplicated, block: B:88:0x01d9 A[SYNTHETIC] */
                /* JADX WARN: Code duplicated, block: B:90:0x01d3 A[SYNTHETIC] */
                /* JADX WARN: Instruction removed from duplicated block: B:72:0x01e9, please report this as an issue */
/* 57 */        public final Object next(Token token, Continuation<? super Unit> continuation) throws Throwable {
                    C04511 c04511;
                    Object obj;
                    Token token2;
                    List<CardCandidate> list;
                    Object objFirst;
                    Token token3;
                    List<CardCandidate> list2;
                    List<CardSchedule> list3;
                    Object objFirst2;
                    Token token4;
                    AppSettings settings;
                    int remaining;
                    QueueDecision decision;
                    Object objFirst3;
                    QueueDecision decision2;
                    CardCandidate candidate;
                    Collection arrayList;
                    Iterator it;
                    boolean z;
                    List logs;
                    QueueDecision.Waiting waiting;
                    Collection arrayList2;
                    Iterator it2;
                    Iterator it3;
                    long durationMs;
                    Object next;
                    ReviewLog reviewLog;
                    if (continuation instanceof C04511) {
                        c04511 = (C04511) continuation;
                        if ((c04511.label & Integer.MIN_VALUE) != 0) {
                            c04511.label -= Integer.MIN_VALUE;
                        } else {
                            c04511 = new C04511(continuation);
                        }
                    } else {
                        c04511 = new C04511(continuation);
                    }
                    Object $result = c04511.result;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (c04511.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 59 */                    if (!valid(token)) {
                                return Unit.INSTANCE;
                            }
/* 60 */                    StudyRepository studyRepository = this.repository;
                            String str = this.deckId;
                            c04511.L$0 = token;
                            c04511.label = 1;
                            Object objCandidates = studyRepository.candidates(str, c04511);
                            if (objCandidates == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
/* 60 */                    obj = objCandidates;
                            token2 = token;
/* 58 */                    list = (List) obj;
/* 61 */                    if (!valid(token2)) {
                                return Unit.INSTANCE;
                            }
/* 62 */                    Flow<List<CardSchedule>> flowObserveSchedules = this.repository.observeSchedules();
                            c04511.L$0 = token2;
                            c04511.L$1 = list;
                            c04511.label = 2;
                            objFirst = FlowKt.first(flowObserveSchedules, c04511);
                            if (objFirst == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            token3 = token2;
/* 62 */                    list2 = list;
/* 58 */                    list3 = (List) objFirst;
/* 63 */                    if (!valid(token3)) {
                                return Unit.INSTANCE;
                            }
/* 64 */                    Flow<AppSettings> flowObserveSettings = this.repository.observeSettings();
                            c04511.L$0 = token3;
                            c04511.L$1 = list2;
                            c04511.L$2 = list3;
                            c04511.label = 3;
                            objFirst2 = FlowKt.first(flowObserveSettings, c04511);
                            if (objFirst2 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
/* 64 */                    token4 = token3;
/* 58 */                    settings = (AppSettings) objFirst2;
/* 65 */                    if (!valid(token4)) {
                                return Unit.INSTANCE;
                            }
/* 66 */                    NewCardQuota newCardQuota = NewCardQuota.INSTANCE;
                            Instant instant = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant, "instant(...)");
                            remaining = newCardQuota.remaining(list3, settings, instant, invoke());
/* 67 */                    QueuePlanner queuePlanner = QueuePlanner.INSTANCE;
                            Instant instant2 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant2, "instant(...)");
                            decision = queuePlanner.next(list2, remaining, instant2);
/* 68 */                    if (decision instanceof QueueDecision.Ready) {
                                candidate = ((QueueDecision.Ready) decision).getCandidate();
                                c04511.L$0 = SpillingKt.nullOutSpilledVariable(token4);
                                c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                                c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                                c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                                c04511.L$4 = SpillingKt.nullOutSpilledVariable(decision);
                                c04511.I$0 = remaining;
                                c04511.label = 4;
                                if (showQuestion(candidate, token4, c04511) == coroutine_suspended) {
/* 58 */                            return coroutine_suspended;
                                }
/* 76 */                        return Unit.INSTANCE;
                            }
/* 70 */                    Flow<List<ReviewLog>> flowObserveLogs = this.repository.observeLogs();
                            c04511.L$0 = token4;
                            c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                            c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                            c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                            c04511.L$4 = decision;
                            c04511.I$0 = remaining;
                            c04511.label = 5;
                            objFirst3 = FlowKt.first(flowObserveLogs, c04511);
                            if (objFirst3 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            decision2 = decision;
/* 159 */                   arrayList = new ArrayList();
/* 160 */                   it = ((Iterable) objFirst3).iterator();
                            while (true) {
                                z = false;
                                if (!it.hasNext()) {
                                    logs = (List) arrayList;
/* 71 */                            if (!valid(token4)) {
                                        return Unit.INSTANCE;
                                    }
/* 72 */                            this.current = null;
/* 72 */                            this.pending = null;
                                    this.timer.reset();
                                    set("revealed", Boxing.boxBoolean(false));
/* 73 */                            MutableStateFlow<ReviewUiState> mutableStateFlow = this.mutable;
                                    if (decision2 instanceof QueueDecision.Waiting) {
                                        waiting = (QueueDecision.Waiting) decision2;
                                    } else {
/* 72 */                                waiting = null;
                                    }
                                    Long lBoxLong = waiting != null ? Boxing.boxLong(waiting.getNextDueAt()) : null;
                                    int size = logs.size();
                                    List list4 = logs;
/* 162 */                           arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list4, 10));
/* 163 */                           it2 = list4.iterator();
                                    while (it2.hasNext()) {
/* 164 */                               arrayList2.add(((ReviewLog) it2.next()).getCardId());
                                    }
/* 73 */                            int size2 = CollectionsKt.toSet((List) arrayList2).size();
                                    it3 = logs.iterator();
                                    durationMs = 0;
                                    while (it3.hasNext()) {
/* 73 */                                durationMs += ((ReviewLog) it3.next()).getDurationMs();
                                    }
                                    mutableStateFlow.setValue(new ReviewUiState.Complete(lBoxLong, size, size2, durationMs));
/* 76 */                            return Unit.INSTANCE;
                                }
                                next = it.next();
                                reviewLog = (ReviewLog) next;
                                C04511 c04512 = c04511;
/* 70 */                        if (Intrinsics.areEqual(reviewLog.getSessionId(), this.sessionId) && reviewLog.getUndoneAt() == null) {
                                    z = true;
                                }
/* 160 */                       if (z) {
                                    arrayList.add(next);
                                }
                                c04511 = c04512;
                            }
                            break;
                        case 1:
                            token2 = (Token) c04511.L$0;
                            ResultKt.throwOnFailure($result);
                            obj = $result;
/* 58 */                    list = (List) obj;
/* 61 */                    if (!valid(token2)) {
                                return Unit.INSTANCE;
                            }
/* 62 */                    Flow<List<CardSchedule>> flowObserveSchedules2 = this.repository.observeSchedules();
                            c04511.L$0 = token2;
                            c04511.L$1 = list;
                            c04511.label = 2;
                            objFirst = FlowKt.first(flowObserveSchedules2, c04511);
                            if (objFirst == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            token3 = token2;
/* 62 */                    list2 = list;
/* 58 */                    list3 = (List) objFirst;
/* 63 */                    if (!valid(token3)) {
                                return Unit.INSTANCE;
                            }
/* 64 */                    Flow<AppSettings> flowObserveSettings2 = this.repository.observeSettings();
                            c04511.L$0 = token3;
                            c04511.L$1 = list2;
                            c04511.L$2 = list3;
                            c04511.label = 3;
                            objFirst2 = FlowKt.first(flowObserveSettings2, c04511);
                            if (objFirst2 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
/* 64 */                    token4 = token3;
/* 58 */                    settings = (AppSettings) objFirst2;
/* 65 */                    if (!valid(token4)) {
                                return Unit.INSTANCE;
                            }
/* 66 */                    NewCardQuota newCardQuota2 = NewCardQuota.INSTANCE;
                            Instant instant3 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant3, "instant(...)");
                            remaining = newCardQuota2.remaining(list3, settings, instant3, invoke());
/* 67 */                    QueuePlanner queuePlanner2 = QueuePlanner.INSTANCE;
                            Instant instant4 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant4, "instant(...)");
                            decision = queuePlanner2.next(list2, remaining, instant4);
/* 68 */                    if (decision instanceof QueueDecision.Ready) {
                                candidate = ((QueueDecision.Ready) decision).getCandidate();
                                c04511.L$0 = SpillingKt.nullOutSpilledVariable(token4);
                                c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                                c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                                c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                                c04511.L$4 = SpillingKt.nullOutSpilledVariable(decision);
                                c04511.I$0 = remaining;
                                c04511.label = 4;
                                if (showQuestion(candidate, token4, c04511) == coroutine_suspended) {
/* 58 */                            return coroutine_suspended;
                                }
/* 76 */                        return Unit.INSTANCE;
                            }
/* 70 */                    Flow<List<ReviewLog>> flowObserveLogs2 = this.repository.observeLogs();
                            c04511.L$0 = token4;
                            c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                            c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                            c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                            c04511.L$4 = decision;
                            c04511.I$0 = remaining;
                            c04511.label = 5;
                            objFirst3 = FlowKt.first(flowObserveLogs2, c04511);
                            if (objFirst3 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            decision2 = decision;
/* 159 */                   arrayList = new ArrayList();
/* 160 */                   it = ((Iterable) objFirst3).iterator();
                            while (true) {
                                z = false;
                                if (!it.hasNext()) {
                                    logs = (List) arrayList;
/* 71 */                            if (!valid(token4)) {
                                        return Unit.INSTANCE;
                                    }
/* 72 */                            this.current = null;
/* 72 */                            this.pending = null;
                                    this.timer.reset();
                                    set("revealed", Boxing.boxBoolean(false));
/* 73 */                            MutableStateFlow<ReviewUiState> mutableStateFlow2 = this.mutable;
                                    if (decision2 instanceof QueueDecision.Waiting) {
                                        waiting = (QueueDecision.Waiting) decision2;
                                    } else {
/* 72 */                                waiting = null;
                                    }
                                    Long lBoxLong2 = waiting != null ? Boxing.boxLong(waiting.getNextDueAt()) : null;
                                    int size3 = logs.size();
                                    List list5 = logs;
/* 162 */                           arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list5, 10));
/* 163 */                           it2 = list5.iterator();
                                    while (it2.hasNext()) {
/* 164 */                               arrayList2.add(((ReviewLog) it2.next()).getCardId());
                                    }
/* 73 */                            int size4 = CollectionsKt.toSet((List) arrayList2).size();
                                    it3 = logs.iterator();
                                    durationMs = 0;
                                    while (it3.hasNext()) {
/* 73 */                                durationMs += ((ReviewLog) it3.next()).getDurationMs();
                                    }
                                    mutableStateFlow2.setValue(new ReviewUiState.Complete(lBoxLong2, size3, size4, durationMs));
/* 76 */                            return Unit.INSTANCE;
                                }
                                next = it.next();
                                reviewLog = (ReviewLog) next;
                                C04511 c04513 = c04511;
/* 70 */                        if (Intrinsics.areEqual(reviewLog.getSessionId(), this.sessionId)) {
                                    z = true;
                                }
/* 160 */                       if (z) {
                                    arrayList.add(next);
                                }
                                c04511 = c04513;
                            }
                            break;
                        case 2:
                            list2 = (List) c04511.L$1;
                            token3 = (Token) c04511.L$0;
                            ResultKt.throwOnFailure($result);
                            objFirst = $result;
/* 58 */                    list3 = (List) objFirst;
/* 63 */                    if (!valid(token3)) {
                                return Unit.INSTANCE;
                            }
/* 64 */                    Flow<AppSettings> flowObserveSettings3 = this.repository.observeSettings();
                            c04511.L$0 = token3;
                            c04511.L$1 = list2;
                            c04511.L$2 = list3;
                            c04511.label = 3;
                            objFirst2 = FlowKt.first(flowObserveSettings3, c04511);
                            if (objFirst2 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
/* 64 */                    token4 = token3;
/* 58 */                    settings = (AppSettings) objFirst2;
/* 65 */                    if (!valid(token4)) {
                                return Unit.INSTANCE;
                            }
/* 66 */                    NewCardQuota newCardQuota3 = NewCardQuota.INSTANCE;
                            Instant instant5 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant5, "instant(...)");
                            remaining = newCardQuota3.remaining(list3, settings, instant5, invoke());
/* 67 */                    QueuePlanner queuePlanner3 = QueuePlanner.INSTANCE;
                            Instant instant6 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant6, "instant(...)");
                            decision = queuePlanner3.next(list2, remaining, instant6);
/* 68 */                    if (decision instanceof QueueDecision.Ready) {
                                candidate = ((QueueDecision.Ready) decision).getCandidate();
                                c04511.L$0 = SpillingKt.nullOutSpilledVariable(token4);
                                c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                                c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                                c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                                c04511.L$4 = SpillingKt.nullOutSpilledVariable(decision);
                                c04511.I$0 = remaining;
                                c04511.label = 4;
                                if (showQuestion(candidate, token4, c04511) == coroutine_suspended) {
/* 58 */                            return coroutine_suspended;
                                }
/* 76 */                        return Unit.INSTANCE;
                            }
/* 70 */                    Flow<List<ReviewLog>> flowObserveLogs3 = this.repository.observeLogs();
                            c04511.L$0 = token4;
                            c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                            c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                            c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                            c04511.L$4 = decision;
                            c04511.I$0 = remaining;
                            c04511.label = 5;
                            objFirst3 = FlowKt.first(flowObserveLogs3, c04511);
                            if (objFirst3 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            decision2 = decision;
/* 159 */                   arrayList = new ArrayList();
/* 160 */                   it = ((Iterable) objFirst3).iterator();
                            while (true) {
                                z = false;
                                if (!it.hasNext()) {
                                    logs = (List) arrayList;
/* 71 */                            if (!valid(token4)) {
                                        return Unit.INSTANCE;
                                    }
/* 72 */                            this.current = null;
/* 72 */                            this.pending = null;
                                    this.timer.reset();
                                    set("revealed", Boxing.boxBoolean(false));
/* 73 */                            MutableStateFlow<ReviewUiState> mutableStateFlow3 = this.mutable;
                                    if (decision2 instanceof QueueDecision.Waiting) {
                                        waiting = (QueueDecision.Waiting) decision2;
                                    } else {
/* 72 */                                waiting = null;
                                    }
                                    Long lBoxLong3 = waiting != null ? Boxing.boxLong(waiting.getNextDueAt()) : null;
                                    int size5 = logs.size();
                                    List list6 = logs;
/* 162 */                           arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list6, 10));
/* 163 */                           it2 = list6.iterator();
                                    while (it2.hasNext()) {
/* 164 */                               arrayList2.add(((ReviewLog) it2.next()).getCardId());
                                    }
/* 73 */                            int size6 = CollectionsKt.toSet((List) arrayList2).size();
                                    it3 = logs.iterator();
                                    durationMs = 0;
                                    while (it3.hasNext()) {
/* 73 */                                durationMs += ((ReviewLog) it3.next()).getDurationMs();
                                    }
                                    mutableStateFlow3.setValue(new ReviewUiState.Complete(lBoxLong3, size5, size6, durationMs));
/* 76 */                            return Unit.INSTANCE;
                                }
                                next = it.next();
                                reviewLog = (ReviewLog) next;
                                C04511 c04514 = c04511;
/* 70 */                        if (Intrinsics.areEqual(reviewLog.getSessionId(), this.sessionId)) {
                                    z = true;
                                }
/* 160 */                       if (z) {
                                    arrayList.add(next);
                                }
                                c04511 = c04514;
                            }
                            break;
                        case 3:
                            List<CardSchedule> list7 = (List) c04511.L$2;
                            List<CardCandidate> list8 = (List) c04511.L$1;
                            Token token5 = (Token) c04511.L$0;
                            ResultKt.throwOnFailure($result);
                            objFirst2 = $result;
                            token4 = token5;
                            list3 = list7;
                            list2 = list8;
/* 58 */                    settings = (AppSettings) objFirst2;
/* 65 */                    if (!valid(token4)) {
                                return Unit.INSTANCE;
                            }
/* 66 */                    NewCardQuota newCardQuota4 = NewCardQuota.INSTANCE;
                            Instant instant7 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant7, "instant(...)");
                            remaining = newCardQuota4.remaining(list3, settings, instant7, invoke());
/* 67 */                    QueuePlanner queuePlanner4 = QueuePlanner.INSTANCE;
                            Instant instant8 = this.clock.instant();
                            Intrinsics.checkNotNullExpressionValue(instant8, "instant(...)");
                            decision = queuePlanner4.next(list2, remaining, instant8);
/* 68 */                    if (decision instanceof QueueDecision.Ready) {
                                candidate = ((QueueDecision.Ready) decision).getCandidate();
                                c04511.L$0 = SpillingKt.nullOutSpilledVariable(token4);
                                c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                                c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                                c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                                c04511.L$4 = SpillingKt.nullOutSpilledVariable(decision);
                                c04511.I$0 = remaining;
                                c04511.label = 4;
                                if (showQuestion(candidate, token4, c04511) == coroutine_suspended) {
/* 58 */                            return coroutine_suspended;
                                }
/* 76 */                        return Unit.INSTANCE;
                            }
/* 70 */                    Flow<List<ReviewLog>> flowObserveLogs4 = this.repository.observeLogs();
                            c04511.L$0 = token4;
                            c04511.L$1 = SpillingKt.nullOutSpilledVariable(list2);
                            c04511.L$2 = SpillingKt.nullOutSpilledVariable(list3);
                            c04511.L$3 = SpillingKt.nullOutSpilledVariable(settings);
                            c04511.L$4 = decision;
                            c04511.I$0 = remaining;
                            c04511.label = 5;
                            objFirst3 = FlowKt.first(flowObserveLogs4, c04511);
                            if (objFirst3 == coroutine_suspended) {
/* 58 */                        return coroutine_suspended;
                            }
                            decision2 = decision;
/* 159 */                   arrayList = new ArrayList();
/* 160 */                   it = ((Iterable) objFirst3).iterator();
                            while (true) {
                                z = false;
                                if (!it.hasNext()) {
                                    logs = (List) arrayList;
/* 71 */                            if (!valid(token4)) {
                                        return Unit.INSTANCE;
                                    }
/* 72 */                            this.current = null;
/* 72 */                            this.pending = null;
                                    this.timer.reset();
                                    set("revealed", Boxing.boxBoolean(false));
/* 73 */                            MutableStateFlow<ReviewUiState> mutableStateFlow4 = this.mutable;
                                    if (decision2 instanceof QueueDecision.Waiting) {
                                        waiting = (QueueDecision.Waiting) decision2;
                                    } else {
/* 72 */                                waiting = null;
                                    }
                                    Long lBoxLong4 = waiting != null ? Boxing.boxLong(waiting.getNextDueAt()) : null;
                                    int size7 = logs.size();
                                    List list9 = logs;
/* 162 */                           arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list9, 10));
/* 163 */                           it2 = list9.iterator();
                                    while (it2.hasNext()) {
/* 164 */                               arrayList2.add(((ReviewLog) it2.next()).getCardId());
                                    }
/* 73 */                            int size8 = CollectionsKt.toSet((List) arrayList2).size();
                                    it3 = logs.iterator();
                                    durationMs = 0;
                                    while (it3.hasNext()) {
/* 73 */                                durationMs += ((ReviewLog) it3.next()).getDurationMs();
                                    }
                                    mutableStateFlow4.setValue(new ReviewUiState.Complete(lBoxLong4, size7, size8, durationMs));
/* 76 */                            return Unit.INSTANCE;
                                }
                                next = it.next();
                                reviewLog = (ReviewLog) next;
                                C04511 c04515 = c04511;
/* 70 */                        if (Intrinsics.areEqual(reviewLog.getSessionId(), this.sessionId)) {
                                    z = true;
                                }
/* 160 */                       if (z) {
                                    arrayList.add(next);
                                }
                                c04511 = c04515;
                            }
                            break;
                        case 4:
                            int remaining2 = c04511.I$0;
                            ResultKt.throwOnFailure($result);
/* 76 */                    return Unit.INSTANCE;
                        case 5:
                            int i = c04511.I$0;
                            decision2 = (QueueDecision) c04511.L$4;
                            token4 = (Token) c04511.L$0;
                            ResultKt.throwOnFailure($result);
                            objFirst3 = $result;
/* 159 */                   arrayList = new ArrayList();
/* 160 */                   it = ((Iterable) objFirst3).iterator();
                            while (true) {
                                z = false;
                                if (!it.hasNext()) {
                                    logs = (List) arrayList;
/* 71 */                            if (!valid(token4)) {
                                        return Unit.INSTANCE;
                                    }
/* 72 */                            this.current = null;
/* 72 */                            this.pending = null;
                                    this.timer.reset();
                                    set("revealed", Boxing.boxBoolean(false));
/* 73 */                            MutableStateFlow<ReviewUiState> mutableStateFlow5 = this.mutable;
                                    if (decision2 instanceof QueueDecision.Waiting) {
                                        waiting = (QueueDecision.Waiting) decision2;
                                    } else {
/* 72 */                                waiting = null;
                                    }
                                    Long lBoxLong5 = waiting != null ? Boxing.boxLong(waiting.getNextDueAt()) : null;
                                    int size9 = logs.size();
                                    List list10 = logs;
/* 162 */                           arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list10, 10));
/* 163 */                           it2 = list10.iterator();
                                    while (it2.hasNext()) {
/* 164 */                               arrayList2.add(((ReviewLog) it2.next()).getCardId());
                                    }
/* 73 */                            int size10 = CollectionsKt.toSet((List) arrayList2).size();
                                    it3 = logs.iterator();
                                    durationMs = 0;
                                    while (it3.hasNext()) {
/* 73 */                                durationMs += ((ReviewLog) it3.next()).getDurationMs();
                                    }
                                    mutableStateFlow5.setValue(new ReviewUiState.Complete(lBoxLong5, size9, size10, durationMs));
/* 76 */                            return Unit.INSTANCE;
                                }
                                next = it.next();
                                reviewLog = (ReviewLog) next;
                                C04511 c04516 = c04511;
/* 70 */                        if (Intrinsics.areEqual(reviewLog.getSessionId(), this.sessionId)) {
                                    z = true;
                                }
/* 160 */                       if (z) {
                                    arrayList.add(next);
                                }
                                c04511 = c04516;
                            }
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$loadNext$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "it", "Lcom/xunji/flashcards/ui/ReviewViewModel$Token;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$loadNext$1", f = "ReviewViewModel.kt", i = {0}, l = {77}, m = "invokeSuspend", n = {"it"}, s = {"L$0"}, v = 1)
/* 75 */        static final class C04501 extends SuspendLambda implements Function2<Token, Continuation<? super Unit>, Object> {
                    /* synthetic */ Object L$0;
                    int label;

                    C04501(Continuation<? super C04501> continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04501 c04501 = ReviewViewModel.this.new C04501(continuation);
                        c04501.L$0 = obj;
                        return c04501;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Token token, Continuation<? super Unit> continuation) {
                        return ((C04501) create(token, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 76 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Token it = (Token) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = SpillingKt.nullOutSpilledVariable(it);
                                this.label = 1;
/* 16 */                        if (ReviewViewModel.this.next(it, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        return Unit.INSTANCE;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 76 */        public final void loadNext() {
/* 77 */            if (this.active) {
                        setValue(ReviewUiState.Loading.INSTANCE);
                        launchOperation(new C04501(null));
                    }
                }

/* 78 */        public final void refresh() {
/* 79 */            if (!this.active || (getValue() instanceof ReviewUiState.Submitting)) {
                        return;
                    }
                    if (getValue() instanceof ReviewUiState.Loading) {
                        return;
                    }
/* 80 */            CardCandidate old = this.current;
/* 81 */            if (old == null || (getValue() instanceof ReviewUiState.Failure)) {
                        loadNext();
                        return;
                    }
/* 82 */            invalidateRefresh();
/* 83 */            long sequence = this.refreshSequence;
/* 84 */            Token token = new Token(this.generation, this.operation);
/* 85 */            String selectedDeck = this.deckId;
/* 1 */             this.refreshJob = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04521(selectedDeck, old, token, sequence, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$refresh$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$refresh$1", f = "ReviewViewModel.kt", i = {1, 1, 2, 2}, l = {89, 94, 94}, m = "invokeSuspend", n = {"candidate", "shown", "candidate", "shown"}, s = {"L$0", "L$1", "L$0", "L$1"}, v = 1)
/* 85 */        static final class C04521 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ CardCandidate $old;
                    final /* synthetic */ String $selectedDeck;
                    final /* synthetic */ long $sequence;
                    final /* synthetic */ Token $token;
                    Object L$0;
                    Object L$1;
                    Object L$2;
                    Object L$3;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04521(String str, CardCandidate cardCandidate, Token token, long j, Continuation<? super C04521> continuation) {
                        super(2, continuation);
                        this.$selectedDeck = str;
                        this.$old = cardCandidate;
                        this.$token = token;
                        this.$sequence = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return ReviewViewModel.this.new C04521(this.$selectedDeck, this.$old, this.$token, this.$sequence, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04521) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:24:0x0068 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:29:0x009c  */
                    /* JADX WARN: Code duplicated, block: B:35:0x00b2 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:37:0x00b5 A[DONT_INVERT] */
                    /* JADX WARN: Code duplicated, block: B:38:0x00b7 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:39:0x00be A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:41:0x00ce A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:43:0x00e0 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:44:0x00e1  */
                    /* JADX WARN: Code duplicated, block: B:46:0x0101 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:48:0x0105 A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:50:0x012c A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:51:0x012d  */
                    /* JADX WARN: Code duplicated, block: B:55:0x014b A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:61:0x016a A[Catch: Exception -> 0x003b, CancellationException -> 0x003e, TRY_LEAVE, TryCatch #2 {CancellationException -> 0x003e, Exception -> 0x003b, blocks: (B:7:0x0022, B:52:0x012f, B:53:0x013d, B:55:0x014b, B:58:0x0158, B:59:0x0167, B:10:0x0030, B:45:0x00e2, B:11:0x0036, B:21:0x0059, B:22:0x0062, B:24:0x0068, B:26:0x0086, B:33:0x00a1, B:35:0x00b2, B:38:0x00b7, B:39:0x00be, B:41:0x00ce, B:46:0x0101, B:48:0x0105, B:61:0x016a, B:18:0x0045), top: B:69:0x0007 }] */
                    /* JADX WARN: Code duplicated, block: B:70:0x00a0 A[SYNTHETIC] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 86 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objCandidates;
                        CardCandidate cardCandidate;
                        Iterator it;
                        Object next;
                        CardCandidate candidate;
                        ReviewUiState shown;
                        String str;
                        Object objInvoke;
                        String str2;
                        CardCandidate candidate2;
                        Object objAnswer;
                        ReviewUiState shown2;
                        CardCandidate cardCandidate2;
                        boolean z;
                        ReviewUiState shown3;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 87 */                            ResultKt.throwOnFailure($result);
                                    this.label = 1;
/* 16 */                            objCandidates = ReviewViewModel.this.repository.candidates(this.$selectedDeck, this);
                                    if (objCandidates == coroutine_suspended) {
/* 87 */                                return coroutine_suspended;
                                    }
                                    cardCandidate = this.$old;
/* 159 */                           it = ((Iterable) objCandidates).iterator();
/* 159 */                           do {
                                        if (it.hasNext()) {
                                            next = it.next();
                                            cardCandidate2 = (CardCandidate) next;
/* 89 */                                    if (Intrinsics.areEqual(cardCandidate2.getCard().getId(), cardCandidate.getCard().getId()) || cardCandidate2.getSchedule().getRevision() != cardCandidate.getSchedule().getRevision()) {
                                                z = false;
                                            } else {
                                                z = true;
                                            }
                                        } else {
/* 160 */                                   next = null;
                                        }
/* 89 */                                candidate = (CardCandidate) next;
/* 16 */                                if (!ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
                                            return Unit.INSTANCE;
                                        }
/* 91 */                                if (candidate == null) {
/* 16 */                                    shown = (ReviewUiState) getValue();
/* 94 */                                    if (shown instanceof ReviewUiState.Answer) {
                                                this.L$0 = candidate;
                                                this.L$1 = shown;
                                                this.label = 2;
/* 16 */                                        objAnswer = ReviewViewModel.this.answer(candidate, this);
                                                if (objAnswer == coroutine_suspended) {
/* 87 */                                            return coroutine_suspended;
                                                }
/* 94 */                                        shown2 = shown;
                                                shown3 = ReviewUiState.Answer.copy$default((ReviewUiState.Answer) objAnswer, null, null, null, ((ReviewUiState.Answer) shown2).getError(), ((ReviewUiState.Answer) shown2).getRetryRating(), null, 39, null);
/* 16 */                                        if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old) && getValue() == shown2) {
/* 16 */                                            ReviewViewModel.this.current = candidate;
/* 16 */                                            setValue(shown3);
                                                }
/* 95 */                                        return Unit.INSTANCE;
                                            }
                                            if (shown instanceof ReviewUiState.Question) {
/* 94 */                                        return Unit.INSTANCE;
                                            }
/* 16 */                                    str = ReviewViewModel.this.sessionId;
/* 16 */                                    Function3 function3 = ReviewViewModel.this.present;
                                            String id = candidate.getCard().getId();
                                            CardSide cardSide = CardSide.QUESTION;
                                            this.L$0 = candidate;
                                            this.L$1 = shown;
                                            this.L$2 = candidate;
                                            this.L$3 = str;
                                            this.label = 3;
                                            objInvoke = function3.invoke(id, cardSide, this);
                                            if (objInvoke == coroutine_suspended) {
/* 87 */                                        return coroutine_suspended;
                                            }
/* 94 */                                    str2 = str;
                                            candidate2 = candidate;
                                            ReviewUiState question = new ReviewUiState.Question(candidate, str2, (RenderedCard) objInvoke);
                                            ReviewUiState reviewUiState = shown;
                                            shown3 = question;
                                            shown2 = reviewUiState;
                                            candidate = candidate2;
/* 16 */                                    if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                        ReviewViewModel.this.current = candidate;
/* 16 */                                        setValue(shown3);
                                            }
/* 95 */                                    return Unit.INSTANCE;
                                        }
/* 16 */                                ReviewViewModel.this.loadNext();
/* 101 */                               return Unit.INSTANCE;
/* 159 */                           } while (!z);
/* 89 */                            candidate = (CardCandidate) next;
/* 16 */                            if (!ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
                                        return Unit.INSTANCE;
                                    }
/* 91 */                            if (candidate == null) {
/* 16 */                                shown = (ReviewUiState) getValue();
/* 94 */                                if (shown instanceof ReviewUiState.Answer) {
                                            this.L$0 = candidate;
                                            this.L$1 = shown;
                                            this.label = 2;
/* 16 */                                    objAnswer = ReviewViewModel.this.answer(candidate, this);
                                            if (objAnswer == coroutine_suspended) {
/* 87 */                                        return coroutine_suspended;
                                            }
/* 94 */                                    shown2 = shown;
                                            shown3 = ReviewUiState.Answer.copy$default((ReviewUiState.Answer) objAnswer, null, null, null, ((ReviewUiState.Answer) shown2).getError(), ((ReviewUiState.Answer) shown2).getRetryRating(), null, 39, null);
/* 16 */                                    if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                        ReviewViewModel.this.current = candidate;
/* 16 */                                        setValue(shown3);
                                            }
/* 95 */                                    return Unit.INSTANCE;
                                        }
                                        if (shown instanceof ReviewUiState.Question) {
/* 94 */                                    return Unit.INSTANCE;
                                        }
/* 16 */                                str = ReviewViewModel.this.sessionId;
/* 16 */                                Function3 function4 = ReviewViewModel.this.present;
                                        String id2 = candidate.getCard().getId();
                                        CardSide cardSide2 = CardSide.QUESTION;
                                        this.L$0 = candidate;
                                        this.L$1 = shown;
                                        this.L$2 = candidate;
                                        this.L$3 = str;
                                        this.label = 3;
                                        objInvoke = function4.invoke(id2, cardSide2, this);
                                        if (objInvoke == coroutine_suspended) {
/* 87 */                                    return coroutine_suspended;
                                        }
/* 94 */                                str2 = str;
                                        candidate2 = candidate;
                                        ReviewUiState question2 = new ReviewUiState.Question(candidate, str2, (RenderedCard) objInvoke);
                                        ReviewUiState reviewUiState2 = shown;
                                        shown3 = question2;
                                        shown2 = reviewUiState2;
                                        candidate = candidate2;
/* 16 */                                if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                    ReviewViewModel.this.current = candidate;
/* 16 */                                    setValue(shown3);
                                        }
/* 95 */                                return Unit.INSTANCE;
                                    }
/* 16 */                            ReviewViewModel.this.loadNext();
/* 101 */                           return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    objCandidates = $result;
                                    cardCandidate = this.$old;
/* 159 */                           it = ((Iterable) objCandidates).iterator();
/* 159 */                           do {
                                        if (it.hasNext()) {
                                            next = it.next();
                                            cardCandidate2 = (CardCandidate) next;
/* 89 */                                    if (Intrinsics.areEqual(cardCandidate2.getCard().getId(), cardCandidate.getCard().getId())) {
                                                z = false;
                                            } else {
                                                z = false;
                                            }
                                        } else {
/* 160 */                                   next = null;
                                        }
/* 89 */                                candidate = (CardCandidate) next;
/* 16 */                                if (!ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
                                            return Unit.INSTANCE;
                                        }
/* 91 */                                if (candidate == null) {
/* 16 */                                    shown = (ReviewUiState) getValue();
/* 94 */                                    if (shown instanceof ReviewUiState.Answer) {
                                                this.L$0 = candidate;
                                                this.L$1 = shown;
                                                this.label = 2;
/* 16 */                                        objAnswer = ReviewViewModel.this.answer(candidate, this);
                                                if (objAnswer == coroutine_suspended) {
/* 87 */                                            return coroutine_suspended;
                                                }
/* 94 */                                        shown2 = shown;
                                                shown3 = ReviewUiState.Answer.copy$default((ReviewUiState.Answer) objAnswer, null, null, null, ((ReviewUiState.Answer) shown2).getError(), ((ReviewUiState.Answer) shown2).getRetryRating(), null, 39, null);
/* 16 */                                        if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                            ReviewViewModel.this.current = candidate;
/* 16 */                                            setValue(shown3);
                                                }
/* 95 */                                        return Unit.INSTANCE;
                                            }
                                            if (shown instanceof ReviewUiState.Question) {
/* 94 */                                        return Unit.INSTANCE;
                                            }
/* 16 */                                    str = ReviewViewModel.this.sessionId;
/* 16 */                                    Function3 function5 = ReviewViewModel.this.present;
                                            String id3 = candidate.getCard().getId();
                                            CardSide cardSide3 = CardSide.QUESTION;
                                            this.L$0 = candidate;
                                            this.L$1 = shown;
                                            this.L$2 = candidate;
                                            this.L$3 = str;
                                            this.label = 3;
                                            objInvoke = function5.invoke(id3, cardSide3, this);
                                            if (objInvoke == coroutine_suspended) {
/* 87 */                                        return coroutine_suspended;
                                            }
/* 94 */                                    str2 = str;
                                            candidate2 = candidate;
                                            ReviewUiState question3 = new ReviewUiState.Question(candidate, str2, (RenderedCard) objInvoke);
                                            ReviewUiState reviewUiState3 = shown;
                                            shown3 = question3;
                                            shown2 = reviewUiState3;
                                            candidate = candidate2;
/* 16 */                                    if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                        ReviewViewModel.this.current = candidate;
/* 16 */                                        setValue(shown3);
                                            }
/* 95 */                                    return Unit.INSTANCE;
                                        }
/* 16 */                                ReviewViewModel.this.loadNext();
/* 101 */                               return Unit.INSTANCE;
/* 159 */                           } while (!z);
/* 89 */                            candidate = (CardCandidate) next;
/* 16 */                            if (!ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
                                        return Unit.INSTANCE;
                                    }
/* 91 */                            if (candidate == null) {
/* 16 */                                shown = (ReviewUiState) getValue();
/* 94 */                                if (shown instanceof ReviewUiState.Answer) {
                                            this.L$0 = candidate;
                                            this.L$1 = shown;
                                            this.label = 2;
/* 16 */                                    objAnswer = ReviewViewModel.this.answer(candidate, this);
                                            if (objAnswer == coroutine_suspended) {
/* 87 */                                        return coroutine_suspended;
                                            }
/* 94 */                                    shown2 = shown;
                                            shown3 = ReviewUiState.Answer.copy$default((ReviewUiState.Answer) objAnswer, null, null, null, ((ReviewUiState.Answer) shown2).getError(), ((ReviewUiState.Answer) shown2).getRetryRating(), null, 39, null);
/* 16 */                                    if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                        ReviewViewModel.this.current = candidate;
/* 16 */                                        setValue(shown3);
                                            }
/* 95 */                                    return Unit.INSTANCE;
                                        }
                                        if (shown instanceof ReviewUiState.Question) {
/* 94 */                                    return Unit.INSTANCE;
                                        }
/* 16 */                                str = ReviewViewModel.this.sessionId;
/* 16 */                                Function3 function6 = ReviewViewModel.this.present;
                                        String id4 = candidate.getCard().getId();
                                        CardSide cardSide4 = CardSide.QUESTION;
                                        this.L$0 = candidate;
                                        this.L$1 = shown;
                                        this.L$2 = candidate;
                                        this.L$3 = str;
                                        this.label = 3;
                                        objInvoke = function6.invoke(id4, cardSide4, this);
                                        if (objInvoke == coroutine_suspended) {
/* 87 */                                    return coroutine_suspended;
                                        }
/* 94 */                                str2 = str;
                                        candidate2 = candidate;
                                        ReviewUiState question4 = new ReviewUiState.Question(candidate, str2, (RenderedCard) objInvoke);
                                        ReviewUiState reviewUiState4 = shown;
                                        shown3 = question4;
                                        shown2 = reviewUiState4;
                                        candidate = candidate2;
/* 16 */                                if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                    ReviewViewModel.this.current = candidate;
/* 16 */                                    setValue(shown3);
                                        }
/* 95 */                                return Unit.INSTANCE;
                                    }
/* 16 */                            ReviewViewModel.this.loadNext();
/* 101 */                           return Unit.INSTANCE;
                                case 2:
                                    shown2 = (ReviewUiState) this.L$1;
                                    candidate = (CardCandidate) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objAnswer = $result;
                                    shown3 = ReviewUiState.Answer.copy$default((ReviewUiState.Answer) objAnswer, null, null, null, ((ReviewUiState.Answer) shown2).getError(), ((ReviewUiState.Answer) shown2).getRetryRating(), null, 39, null);
/* 16 */                            if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                ReviewViewModel.this.current = candidate;
/* 16 */                                setValue(shown3);
/* 101 */                               return Unit.INSTANCE;
                                    }
/* 95 */                            return Unit.INSTANCE;
                                case 3:
                                    str2 = (String) this.L$3;
                                    candidate = (CardCandidate) this.L$2;
                                    shown = (ReviewUiState) this.L$1;
                                    candidate2 = (CardCandidate) this.L$0;
                                    ResultKt.throwOnFailure($result);
                                    objInvoke = $result;
                                    ReviewUiState question5 = new ReviewUiState.Question(candidate, str2, (RenderedCard) objInvoke);
                                    ReviewUiState reviewUiState5 = shown;
                                    shown3 = question5;
                                    shown2 = reviewUiState5;
                                    candidate = candidate2;
/* 16 */                            if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                                ReviewViewModel.this.current = candidate;
/* 16 */                                setValue(shown3);
/* 101 */                               return Unit.INSTANCE;
                                    }
/* 95 */                            return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 98 */                    throw e;
                        } catch (Exception e2) {
/* 16 */                    if (ReviewViewModel.refresh$stillCurrent(ReviewViewModel.this, this.$token, this.$sequence, this.$old)) {
/* 16 */                        setValue(new ReviewUiState.Failure("暂时无法读取卡片，请重试"));
                            }
                        }
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 85 */        public static final boolean refresh$stillCurrent(ReviewViewModel this$0, Token token, long sequence, CardCandidate old) {
                    Flashcard card;
/* 86 */            if (this$0.valid(token) && sequence == this$0.refreshSequence) {
                        CardCandidate cardCandidate = this$0.current;
                        if (Intrinsics.areEqual((cardCandidate == null || (card = cardCandidate.getCard()) == null) ? null : card.getId(), old.getCard().getId())) {
                            return true;
                        }
                    }
                    return false;
                }

/* 103 */       public final void reveal() {
/* 104 */           ReviewUiState value = getValue();
                    ReviewUiState.Question question = value instanceof ReviewUiState.Question ? (ReviewUiState.Question) value : null;
                    if (question == null) {
                        return;
                    }
/* 105 */           invalidateRefresh();
/* 106 */           setValue(ReviewUiState.Loading.INSTANCE);
/* 107 */           launchOperation(new C04531(question, null));
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$reveal$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "token", "Lcom/xunji/flashcards/ui/ReviewViewModel$Token;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$reveal$1", f = "ReviewViewModel.kt", i = {0}, l = {108}, m = "invokeSuspend", n = {"token"}, s = {"L$0"}, v = 1)
/* 105 */       static final class C04531 extends SuspendLambda implements Function2<Token, Continuation<? super Unit>, Object> {
                    final /* synthetic */ ReviewUiState.Question $question;
                    /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04531(ReviewUiState.Question question, Continuation<? super C04531> continuation) {
                        super(2, continuation);
                        this.$question = question;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04531 c04531 = ReviewViewModel.this.new C04531(this.$question, continuation);
                        c04531.L$0 = obj;
                        return c04531;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Token token, Continuation<? super Unit> continuation) {
                        return ((C04531) create(token, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 106 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objAnswer;
                        Token token = (Token) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = token;
                                this.label = 1;
/* 16 */                        objAnswer = ReviewViewModel.this.answer(this.$question.getCandidate(), this);
                                if (objAnswer == coroutine_suspended) {
/* 107 */                           return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                objAnswer = $result;
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        ReviewUiState.Answer shown = (ReviewUiState.Answer) objAnswer;
/* 16 */                if (ReviewViewModel.this.valid(token)) {
/* 16 */                    setValue(shown);
/* 16 */                    set("revealed", Boxing.boxBoolean(true));
                        }
/* 110 */               return Unit.INSTANCE;
                    }
                }

/* 112 */       public final void grade(Rating rating) {
                    Rating rating2;
                    GradeCommand command;
                    Intrinsics.checkNotNullParameter(rating, "rating");
/* 113 */           if (this.active) {
/* 114 */               ReviewUiState value = getValue();
                        ReviewUiState.Answer answer = value instanceof ReviewUiState.Answer ? (ReviewUiState.Answer) value : null;
                        if (answer == null) {
                            return;
                        }
                        ReviewUiState.Answer shown = answer;
/* 115 */               if (this.pending != null) {
                            GradeCommand gradeCommand = this.pending;
                            Intrinsics.checkNotNull(gradeCommand);
                            if (gradeCommand.getRating() != rating) {
                                return;
                            }
                        }
/* 116 */               GradeCommand gradeCommand2 = this.pending;
                        if (gradeCommand2 == null) {
                            String string = UUID.randomUUID().toString();
                            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
                            rating2 = rating;
                            GradeCommand gradeCommand3 = new GradeCommand(string, this.sessionId, shown.getCandidate().getCard().getId(), shown.getCandidate().getSchedule().getRevision(), rating2, this.timer.elapsedMs(invoke().longValue()));
/* 116 */                   this.pending = gradeCommand3;
                            command = gradeCommand3;
                        } else {
                            rating2 = rating;
                            command = gradeCommand2;
                        }
/* 117 */               this.timer.pause(invoke().longValue());
                        setValue(new ReviewUiState.Submitting(shown));
/* 118 */               launchOperation(new C04481(command, shown, rating2, null));
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$grade$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "token", "Lcom/xunji/flashcards/ui/ReviewViewModel$Token;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$grade$1", f = "ReviewViewModel.kt", i = {0, 1, 1, 2, 2, 3, 3}, l = {MenuKt.InTransitionDuration, 123, 124, 125}, m = "invokeSuspend", n = {"token", "token", "result", "token", "result", "token", "result"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$0", "L$1"}, v = 1)
/* 116 */       static final class C04481 extends SuspendLambda implements Function2<Token, Continuation<? super Unit>, Object> {
                    final /* synthetic */ GradeCommand $command;
                    final /* synthetic */ Rating $rating;
                    final /* synthetic */ ReviewUiState.Answer $shown;
                    /* synthetic */ Object L$0;
                    Object L$1;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04481(GradeCommand gradeCommand, ReviewUiState.Answer answer, Rating rating, Continuation<? super C04481> continuation) {
                        super(2, continuation);
                        this.$command = gradeCommand;
                        this.$shown = answer;
                        this.$rating = rating;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04481 c04481 = ReviewViewModel.this.new C04481(this.$command, this.$shown, this.$rating, continuation);
                        c04481.L$0 = obj;
                        return c04481;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Token token, Continuation<? super Unit> continuation) {
                        return ((C04481) create(token, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:26:0x0060 A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:28:0x0063 A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:30:0x0068 A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:32:0x0097 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:33:0x0098  */
                    /* JADX WARN: Code duplicated, block: B:35:0x009b A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:37:0x009f A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:39:0x00be  */
                    /* JADX WARN: Code duplicated, block: B:40:0x00bf  */
                    /* JADX WARN: Code duplicated, block: B:43:0x00dd A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:44:0x00de  */
                    /* JADX WARN: Code duplicated, block: B:46:0x00e1 A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:58:0x0123 A[Catch: Exception -> 0x0036, CancellationException -> 0x0039, TRY_LEAVE, TryCatch #2 {CancellationException -> 0x0039, Exception -> 0x0036, blocks: (B:7:0x001b, B:10:0x0024, B:13:0x002d, B:14:0x0031, B:24:0x0056, B:26:0x0060, B:28:0x0063, B:30:0x0068, B:35:0x009b, B:37:0x009f, B:41:0x00c0, B:46:0x00e1, B:48:0x00e9, B:50:0x00f1, B:53:0x00fa, B:55:0x0102, B:56:0x011d, B:57:0x0122, B:58:0x0123, B:21:0x0040), top: B:69:0x000c }] */
                    /* JADX WARN: Code duplicated, block: B:60:0x0139 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:61:0x013a  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 117 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objGrade;
                        GradeResult result;
                        Token token = (Token) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        boolean z = true;
                        try {
                            switch (this.label) {
                                case 0:
/* 118 */                           ResultKt.throwOnFailure($result);
                                    this.L$0 = token;
                                    this.label = 1;
/* 16 */                            objGrade = ReviewViewModel.this.actions.grade(this.$command, this);
                                    if (objGrade == coroutine_suspended) {
/* 118 */                               return coroutine_suspended;
                                    }
                                    result = (GradeResult) objGrade;
/* 16 */                            if (!ReviewViewModel.this.valid(token)) {
                                        return Unit.INSTANCE;
                                    }
/* 123 */                           if (result instanceof GradeResult.Recorded) {
/* 16 */                                ReviewViewModel.this.lastLog = ((GradeResult.Recorded) result).getLog();
/* 16 */                                setValue(Boxing.boxBoolean(true));
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 2;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else if (result instanceof GradeResult.Duplicate) {
/* 16 */                                ReviewViewModel.this.lastLog = ((GradeResult.Duplicate) result).getLog();
/* 16 */                                MutableStateFlow mutableStateFlow = ReviewViewModel.this.undoable;
                                        if (((GradeResult.Duplicate) result).getLog().getUndoneAt() == null) {
                                            z = false;
                                        }
                                        mutableStateFlow.setValue(Boxing.boxBoolean(z));
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 3;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else if (!Intrinsics.areEqual(result, GradeResult.MissingCard.INSTANCE) || Intrinsics.areEqual(result, GradeResult.StaleSchedule.INSTANCE) || Intrinsics.areEqual(result, GradeResult.QuotaReached.INSTANCE)) {
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 4;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else {
/* 126 */                               if (!Intrinsics.areEqual(result, GradeResult.InvalidCommand.INSTANCE)) {
/* 122 */                                   throw new NoWhenBranchMatchedException();
                                        }
/* 16 */                                setValue(ReviewUiState.Answer.copy$default(this.$shown, null, null, null, "无法记录此评分，请刷新卡片", this.$rating, null, 39, null));
                                    }
/* 131 */                           return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    objGrade = $result;
                                    result = (GradeResult) objGrade;
/* 16 */                            if (!ReviewViewModel.this.valid(token)) {
                                        return Unit.INSTANCE;
                                    }
/* 123 */                           if (result instanceof GradeResult.Recorded) {
/* 16 */                                ReviewViewModel.this.lastLog = ((GradeResult.Recorded) result).getLog();
/* 16 */                                setValue(Boxing.boxBoolean(true));
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 2;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else if (result instanceof GradeResult.Duplicate) {
/* 16 */                                ReviewViewModel.this.lastLog = ((GradeResult.Duplicate) result).getLog();
/* 16 */                                MutableStateFlow mutableStateFlow2 = ReviewViewModel.this.undoable;
                                        if (((GradeResult.Duplicate) result).getLog().getUndoneAt() == null) {
                                            z = false;
                                        }
                                        mutableStateFlow2.setValue(Boxing.boxBoolean(z));
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 3;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else if (Intrinsics.areEqual(result, GradeResult.MissingCard.INSTANCE)) {
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 4;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    } else {
                                        this.L$0 = token;
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.label = 4;
/* 16 */                                if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 118 */                                   return coroutine_suspended;
                                        }
                                    }
/* 131 */                           return Unit.INSTANCE;
                                case 2:
                                    ResultKt.throwOnFailure($result);
/* 131 */                           return Unit.INSTANCE;
                                case 3:
                                    ResultKt.throwOnFailure($result);
/* 131 */                           return Unit.INSTANCE;
                                case 4:
                                    ResultKt.throwOnFailure($result);
/* 131 */                           return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 128 */                   throw e;
                        } catch (Exception e2) {
/* 16 */                    if (ReviewViewModel.this.valid(token)) {
/* 16 */                        setValue(ReviewUiState.Answer.copy$default(this.$shown, null, null, null, "记录未完成，请重试", this.$rating, null, 39, null));
                            }
                        }
                    }
                }

/* 133 */       public final void undo() {
                    ReviewLog log;
/* 134 */           if (this.active && getValue().booleanValue() && !(getValue() instanceof ReviewUiState.Submitting)) {
                        if ((getValue() instanceof ReviewUiState.Loading) || (log = this.lastLog) == null) {
                            return;
                        }
/* 136 */               setValue(false);
                        setValue(ReviewUiState.Loading.INSTANCE);
/* 137 */               String selectedSession = this.sessionId;
                        String selectedDeck = this.deckId;
/* 138 */               launchOperation(new C04551(selectedSession, log, selectedDeck, null));
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.ReviewViewModel$undo$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: ReviewViewModel.kt */
                @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "token", "Lcom/xunji/flashcards/ui/ReviewViewModel$Token;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.ReviewViewModel$undo$1", f = "ReviewViewModel.kt", i = {0, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4}, l = {139, 143, 143, 143, 144}, m = "invokeSuspend", n = {"token", "token", "result", "token", "result", "c", "token", "result", "c", "token", "result"}, s = {"L$0", "L$0", "L$1", "L$0", "L$1", "L$2", "L$0", "L$1", "L$2", "L$0", "L$1"}, v = 1)
/* 136 */       static final class C04551 extends SuspendLambda implements Function2<Token, Continuation<? super Unit>, Object> {
                    final /* synthetic */ ReviewLog $log;
                    final /* synthetic */ String $selectedDeck;
                    final /* synthetic */ String $selectedSession;
                    /* synthetic */ Object L$0;
                    Object L$1;
                    Object L$2;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04551(String str, ReviewLog reviewLog, String str2, Continuation<? super C04551> continuation) {
                        super(2, continuation);
                        this.$selectedSession = str;
                        this.$log = reviewLog;
                        this.$selectedDeck = str2;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        C04551 c04551 = ReviewViewModel.this.new C04551(this.$selectedSession, this.$log, this.$selectedDeck, continuation);
                        c04551.L$0 = obj;
                        return c04551;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Token token, Continuation<? super Unit> continuation) {
                        return ((C04551) create(token, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:15:0x0064  */
                    /* JADX WARN: Code duplicated, block: B:17:0x0067  */
                    /* JADX WARN: Code duplicated, block: B:19:0x0071  */
                    /* JADX WARN: Code duplicated, block: B:21:0x008d A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:25:0x009d  */
                    /* JADX WARN: Code duplicated, block: B:31:0x00c4  */
                    /* JADX WARN: Code duplicated, block: B:33:0x00c7  */
                    /* JADX WARN: Code duplicated, block: B:35:0x00e0  */
                    /* JADX WARN: Code duplicated, block: B:37:0x00e9 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:40:0x00ec  */
                    /* JADX WARN: Code duplicated, block: B:42:0x00f5 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:43:0x00f6  */
                    /* JADX WARN: Code duplicated, block: B:45:0x00fe  */
                    /* JADX WARN: Code duplicated, block: B:47:0x0118 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:48:0x0119  */
                    /* JADX WARN: Code duplicated, block: B:52:0x011e  */
                    /* JADX WARN: Code duplicated, block: B:55:0x00b7 A[SYNTHETIC] */
                    /* JADX WARN: Code duplicated, block: B:56:? A[LOOP:0: B:23:0x0097->B:56:?, LOOP_END, SYNTHETIC] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 137 */           public final Object invokeSuspend(Object $result) throws Throwable {
                        Object objUndo;
                        UndoResult result;
                        UndoResult result2;
                        Object objCandidates;
                        ReviewLog reviewLog;
                        CardCandidate c;
                        ReviewViewModel reviewViewModel;
                        C04551 c04551;
                        Token token = (Token) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        Object obj = null;
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.L$0 = token;
                                this.label = 1;
/* 16 */                        objUndo = ReviewViewModel.this.actions.undo(this.$selectedSession, this.$log.getId(), this);
                                if (objUndo == coroutine_suspended) {
/* 138 */                           return coroutine_suspended;
                                }
                                result = (UndoResult) objUndo;
/* 16 */                        if (!ReviewViewModel.this.valid(token)) {
                                    return Unit.INSTANCE;
                                }
/* 16 */                        ReviewViewModel.this.lastLog = null;
/* 143 */                       if (result instanceof UndoResult.Restored) {
/* 144 */                           if (Intrinsics.areEqual(result, UndoResult.Unavailable.INSTANCE)) {
/* 142 */                               throw new NoWhenBranchMatchedException();
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                    this.label = 5;
/* 16 */                            if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
/* 144 */                           result2 = result;
/* 146 */                           return Unit.INSTANCE;
                                }
                                this.L$0 = token;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                this.label = 2;
/* 16 */                        objCandidates = ReviewViewModel.this.repository.candidates(this.$selectedDeck, this);
                                if (objCandidates == coroutine_suspended) {
/* 138 */                           return coroutine_suspended;
                                }
                                reviewLog = this.$log;
                                for (Object obj2 : (Iterable) objCandidates) {
/* 159 */                           if (Intrinsics.areEqual(((CardCandidate) obj2).getCard().getId(), reviewLog.getCardId())) {
                                        obj = obj2;
/* 143 */                               c = (CardCandidate) obj;
/* 16 */                                if (!ReviewViewModel.this.valid(token)) {
                                            return Unit.INSTANCE;
                                        }
                                        reviewViewModel = ReviewViewModel.this;
                                        c04551 = this;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                        if (c != null) {
                                            this.label = 3;
/* 16 */                                    if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        } else {
                                            this.label = 4;
/* 16 */                                    if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        }
/* 146 */                               return Unit.INSTANCE;
                                    }
                                }
/* 143 */                       c = (CardCandidate) obj;
/* 16 */                        if (!ReviewViewModel.this.valid(token)) {
                                    return Unit.INSTANCE;
                                }
                                reviewViewModel = ReviewViewModel.this;
                                c04551 = this;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                if (c != null) {
                                    this.label = 3;
/* 16 */                            if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                } else {
                                    this.label = 4;
/* 16 */                            if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                }
/* 146 */                       return Unit.INSTANCE;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                objUndo = $result;
                                result = (UndoResult) objUndo;
/* 16 */                        if (!ReviewViewModel.this.valid(token)) {
                                    return Unit.INSTANCE;
                                }
/* 16 */                        ReviewViewModel.this.lastLog = null;
/* 143 */                       if (result instanceof UndoResult.Restored) {
/* 144 */                           if (Intrinsics.areEqual(result, UndoResult.Unavailable.INSTANCE)) {
/* 142 */                               throw new NoWhenBranchMatchedException();
                                    }
                                    this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                    this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                    this.label = 5;
/* 16 */                            if (ReviewViewModel.this.next(token, this) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
/* 144 */                           result2 = result;
/* 146 */                           return Unit.INSTANCE;
                                }
                                this.L$0 = token;
                                this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                this.label = 2;
/* 16 */                        objCandidates = ReviewViewModel.this.repository.candidates(this.$selectedDeck, this);
                                if (objCandidates == coroutine_suspended) {
/* 138 */                           return coroutine_suspended;
                                }
                                reviewLog = this.$log;
                                while (r7.hasNext()) {
/* 159 */                           if (Intrinsics.areEqual(((CardCandidate) obj2).getCard().getId(), reviewLog.getCardId())) {
                                        obj = obj2;
/* 143 */                               c = (CardCandidate) obj;
/* 16 */                                if (!ReviewViewModel.this.valid(token)) {
                                            return Unit.INSTANCE;
                                        }
                                        reviewViewModel = ReviewViewModel.this;
                                        c04551 = this;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                        if (c != null) {
                                            this.label = 3;
/* 16 */                                    if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        } else {
                                            this.label = 4;
/* 16 */                                    if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        }
/* 146 */                               return Unit.INSTANCE;
                                    }
                                }
/* 143 */                       c = (CardCandidate) obj;
/* 16 */                        if (!ReviewViewModel.this.valid(token)) {
                                    return Unit.INSTANCE;
                                }
                                reviewViewModel = ReviewViewModel.this;
                                c04551 = this;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                if (c != null) {
                                    this.label = 3;
/* 16 */                            if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                } else {
                                    this.label = 4;
/* 16 */                            if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                }
/* 146 */                       return Unit.INSTANCE;
                            case 2:
                                result = (UndoResult) this.L$1;
                                ResultKt.throwOnFailure($result);
                                objCandidates = $result;
                                reviewLog = this.$log;
                                while (r7.hasNext()) {
/* 159 */                           if (Intrinsics.areEqual(((CardCandidate) obj2).getCard().getId(), reviewLog.getCardId())) {
                                        obj = obj2;
/* 143 */                               c = (CardCandidate) obj;
/* 16 */                                if (!ReviewViewModel.this.valid(token)) {
                                            return Unit.INSTANCE;
                                        }
                                        reviewViewModel = ReviewViewModel.this;
                                        c04551 = this;
                                        this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                        this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                        this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                        if (c != null) {
                                            this.label = 3;
/* 16 */                                    if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        } else {
                                            this.label = 4;
/* 16 */                                    if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                                       return coroutine_suspended;
                                            }
                                        }
/* 146 */                               return Unit.INSTANCE;
                                    }
                                }
/* 143 */                       c = (CardCandidate) obj;
/* 16 */                        if (!ReviewViewModel.this.valid(token)) {
                                    return Unit.INSTANCE;
                                }
                                reviewViewModel = ReviewViewModel.this;
                                c04551 = this;
                                this.L$0 = SpillingKt.nullOutSpilledVariable(token);
                                this.L$1 = SpillingKt.nullOutSpilledVariable(result);
                                this.L$2 = SpillingKt.nullOutSpilledVariable(c);
                                if (c != null) {
                                    this.label = 3;
/* 16 */                            if (reviewViewModel.showQuestion(c, token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                } else {
                                    this.label = 4;
/* 16 */                            if (reviewViewModel.next(token, c04551) == coroutine_suspended) {
/* 138 */                               return coroutine_suspended;
                                    }
                                }
/* 146 */                       return Unit.INSTANCE;
                            case 3:
                            case 4:
                                ResultKt.throwOnFailure($result);
/* 146 */                       return Unit.INSTANCE;
                            case 5:
                                result2 = (UndoResult) this.L$1;
                                ResultKt.throwOnFailure($result);
/* 146 */                       return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 148 */       public final void setForeground(boolean active) {
/* 149 */           this.foreground = active;
/* 150 */           if (!active) {
                        this.timer.pause(invoke().longValue());
                    } else if (this.active) {
                        if (this.pending == null) {
                            this.timer.resume(invoke().longValue());
                        }
                        refresh();
                    }
                }

                @Override // androidx.lifecycle.ViewModel
/* 151 */       protected void onCleared() {
/* 152 */           finish();
                    super.onCleared();
                }

/* 153 */       public final void finish() {
/* 154 */           this.generation++;
                    this.operation++;
                    this.active = false;
                    invalidateRefresh();
                    Job job = this.job;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
                    this.job = null;
                    this.current = null;
                    this.pending = null;
                    this.lastLog = null;
                    setValue(false);
                    this.timer.reset();
                    set("revealed", false);
/* 155 */           setValue(new ReviewUiState.Complete(null, 0, 0, 0L));
                }
            }

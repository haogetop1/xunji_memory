            package com.xunji.flashcards.ui;

            import com.xunji.core.model.AppSettings;
            import com.xunji.flashcards.backup.PreparedBackup;
            import kotlin.Metadata;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: UiModels.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BK\u0012\b\b\u0002\u0010\u0002\u001a\u00020\u0003\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0005\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0007\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t\u0012\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u0005\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\f\u0010\rJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u0019\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0007HÆ\u0003J\u000b\u0010\u001b\u001a\u0004\u0018\u00010\tHÆ\u0003J\u000b\u0010\u001c\u001a\u0004\u0018\u00010\u0005HÆ\u0003J\u000b\u0010\u001d\u001a\u0004\u0018\u00010\u0005HÆ\u0003JM\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u00072\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\t2\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u00052\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\u0005HÆ\u0001J\u0013\u0010\u001f\u001a\u00020\u00072\b\u0010 \u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010!\u001a\u00020\"HÖ\u0001J\t\u0010#\u001a\u00020\u0005HÖ\u0001R\u0011\u0010\u0002\u001a\u00020\u0003¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0013\u0010\u0004\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u0011R\u0011\u0010\u0006\u001a\u00020\u0007¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0013\u0010\b\u001a\u0004\u0018\u00010\t¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u0015R\u0013\u0010\n\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0011R\u0013\u0010\u000b\u001a\u0004\u0018\u00010\u0005¢\u0006\b\n\u0000\u001a\u0004\b\u0017\u0010\u0011¨\u0006$"}, d2 = {"Lcom/xunji/flashcards/ui/SettingsUiState;", "", "settings", "Lcom/xunji/core/model/AppSettings;", "initializationError", "", "busy", "", "prepared", "Lcom/xunji/flashcards/backup/PreparedBackup;", "message", "error", "<init>", "(Lcom/xunji/core/model/AppSettings;Ljava/lang/String;ZLcom/xunji/flashcards/backup/PreparedBackup;Ljava/lang/String;Ljava/lang/String;)V", "getSettings", "()Lcom/xunji/core/model/AppSettings;", "getInitializationError", "()Ljava/lang/String;", "getBusy", "()Z", "getPrepared", "()Lcom/xunji/flashcards/backup/PreparedBackup;", "getMessage", "getError", "component1", "component2", "component3", "component4", "component5", "component6", "copy", "equals", "other", "hashCode", "", "toString", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final /* data */ class SettingsUiState {
                public static final int $stable = 8;
                private final boolean busy;
                private final String error;
                private final String initializationError;
                private final String message;
                private final PreparedBackup prepared;
                private final AppSettings settings;

                public SettingsUiState() {
                    this(null, null, false, null, null, null, 63);
                }

                public static /* synthetic */ SettingsUiState copy$default(SettingsUiState settingsUiState, AppSettings appSettings, String str, boolean z, PreparedBackup preparedBackup, String str2, String str3, int i, Object obj) {
                    if ((i & 1) != 0) {
                        appSettings = settingsUiState.settings;
                    }
                    if ((i & 2) != 0) {
                        str = settingsUiState.initializationError;
                    }
                    if ((i & 4) != 0) {
                        z = settingsUiState.busy;
                    }
                    if ((i & 8) != 0) {
                        preparedBackup = settingsUiState.prepared;
                    }
                    if ((i & 16) != 0) {
                        str2 = settingsUiState.message;
                    }
                    if ((i & 32) != 0) {
                        str3 = settingsUiState.error;
                    }
                    String str4 = str2;
                    String str5 = str3;
                    return settingsUiState.copy(appSettings, str, z, preparedBackup, str4, str5);
                }

                /* JADX INFO: renamed from: component1, reason: from getter */
                public final AppSettings getSettings() {
                    return this.settings;
                }

                /* JADX INFO: renamed from: component2, reason: from getter */
                public final String getInitializationError() {
                    return this.initializationError;
                }

                /* JADX INFO: renamed from: component3, reason: from getter */
                public final boolean getBusy() {
                    return this.busy;
                }

                /* JADX INFO: renamed from: component4, reason: from getter */
                public final PreparedBackup getPrepared() {
                    return this.prepared;
                }

                /* JADX INFO: renamed from: component5, reason: from getter */
                public final String getMessage() {
                    return this.message;
                }

                /* JADX INFO: renamed from: component6, reason: from getter */
                public final String getError() {
                    return this.error;
                }

                public final SettingsUiState copy(AppSettings settings, String initializationError, boolean busy, PreparedBackup prepared, String message, String error) {
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    return new SettingsUiState(settings, initializationError, busy, prepared, message, error);
                }

                public boolean equals(Object other) {
                    if (this == other) {
                        return true;
                    }
                    if (!(other instanceof SettingsUiState)) {
                        return false;
                    }
                    SettingsUiState settingsUiState = (SettingsUiState) other;
                    return Intrinsics.areEqual(this.settings, settingsUiState.settings) && Intrinsics.areEqual(this.initializationError, settingsUiState.initializationError) && this.busy == settingsUiState.busy && Intrinsics.areEqual(this.prepared, settingsUiState.prepared) && Intrinsics.areEqual(this.message, settingsUiState.message) && Intrinsics.areEqual(this.error, settingsUiState.error);
                }

                public int hashCode() {
                    return (((((((((this.settings.hashCode() * 31) + (this.initializationError == null ? 0 : this.initializationError.hashCode())) * 31) + Boolean.hashCode(this.busy)) * 31) + (this.prepared == null ? 0 : this.prepared.hashCode())) * 31) + (this.message == null ? 0 : this.message.hashCode())) * 31) + (this.error != null ? this.error.hashCode() : 0);
                }

                public String toString() {
                    return "SettingsUiState(settings=" + this.settings + ", initializationError=" + this.initializationError + ", busy=" + this.busy + ", prepared=" + this.prepared + ", message=" + this.message + ", error=" + this.error + ")";
                }

/* 17 */        public SettingsUiState(AppSettings settings, String initializationError, boolean busy, PreparedBackup prepared, String message, String error) {
                    Intrinsics.checkNotNullParameter(settings, "settings");
                    this.settings = settings;
                    this.initializationError = initializationError;
                    this.busy = busy;
                    this.prepared = prepared;
                    this.message = message;
                    this.error = error;
                }

/* 17 */        public final boolean getBusy() {
/* 18 */            return this.busy;
                }

/* 17 */        public final String getError() {
/* 18 */            return this.error;
                }

/* 17 */        public final String getInitializationError() {
/* 18 */            return this.initializationError;
                }

/* 17 */        public final String getMessage() {
/* 18 */            return this.message;
                }

/* 17 */        public final PreparedBackup getPrepared() {
/* 18 */            return this.prepared;
                }

/* 17 */        public final AppSettings getSettings() {
/* 18 */            return this.settings;
                }
            }

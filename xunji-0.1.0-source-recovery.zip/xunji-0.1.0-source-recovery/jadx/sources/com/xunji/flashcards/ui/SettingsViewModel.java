            package com.xunji.flashcards.ui;

            import android.net.Uri;
            import android.util.Log;
            import androidx.core.view.MotionEventCompat;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelKt;
            import com.xunji.core.model.AppSettings;
            import com.xunji.flashcards.backup.BackupService;
            import com.xunji.flashcards.backup.FileGateway;
            import com.xunji.flashcards.backup.PreparedBackup;
            import com.xunji.flashcards.data.StudyRepository;
            import java.io.Closeable;
            import java.io.InputStream;
            import java.io.OutputStream;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.CoroutineScopeKt;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            import kotlinx.coroutines.flow.Flow;
            import kotlinx.coroutines.flow.FlowCollector;
            import kotlinx.coroutines.flow.FlowKt;
            import kotlinx.coroutines.flow.MutableStateFlow;
            import kotlinx.coroutines.flow.StateFlow;
            import kotlinx.coroutines.flow.StateFlowKt;
            
            /* JADX INFO: compiled from: SettingsViewModel.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000n\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u00002\u00020\u0001B-\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0005\u0012\u0006\u0010\u0006\u001a\u00020\u0007\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\t¢\u0006\u0004\b\u000b\u0010\fJ\u0006\u0010\u0018\u001a\u00020\nJ5\u0010\u0019\u001a\u00020\n2\b\b\u0002\u0010\u001a\u001a\u00020\u001b2\u001c\u0010\u001c\u001a\u0018\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\u001e\u0012\u0006\u0012\u0004\u0018\u00010\u001f0\u001dH\u0002¢\u0006\u0002\u0010 J\u000e\u0010!\u001a\u00020\n2\u0006\u0010\"\u001a\u00020#J\u000e\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020&J\u0006\u0010'\u001a\u00020\nJ\u0006\u0010(\u001a\u00020\nJ\u000e\u0010)\u001a\u00020\n2\u0006\u0010%\u001a\u00020&J\b\u0010*\u001a\u00020\nH\u0014R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\b\u001a\b\u0012\u0004\u0012\u00020\n0\tX\u0082\u0004¢\u0006\u0002\n\u0000R\u0014\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u000f0\u000eX\u0082\u0004¢\u0006\u0002\n\u0000R\u0017\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u000f0\u0011¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u0013R\u0010\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0016\u001a\u00020\u0017X\u0082\u000e¢\u0006\u0002\n\u0000¨\u0006+"}, d2 = {"Lcom/xunji/flashcards/ui/SettingsViewModel;", "Landroidx/lifecycle/ViewModel;", "repo", "Lcom/xunji/flashcards/data/StudyRepository;", "backup", "Lcom/xunji/flashcards/backup/BackupService;", "files", "Lcom/xunji/flashcards/backup/FileGateway;", "restored", "Lkotlin/Function0;", "", "<init>", "(Lcom/xunji/flashcards/data/StudyRepository;Lcom/xunji/flashcards/backup/BackupService;Lcom/xunji/flashcards/backup/FileGateway;Lkotlin/jvm/functions/Function0;)V", "mutable", "Lkotlinx/coroutines/flow/MutableStateFlow;", "Lcom/xunji/flashcards/ui/SettingsUiState;", "state", "Lkotlinx/coroutines/flow/StateFlow;", "getState", "()Lkotlinx/coroutines/flow/StateFlow;", "observation", "Lkotlinx/coroutines/Job;", "observationVersion", "", "retryObservation", "operation", "exporting", "", "block", "Lkotlin/Function1;", "Lkotlin/coroutines/Continuation;", "", "(ZLkotlin/jvm/functions/Function1;)V", "saveSettings", "settings", "Lcom/xunji/core/model/AppSettings;", "prepareRestore", "uri", "Landroid/net/Uri;", "confirmRestore", "cancelRestore", "export", "onCleared", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 9 */     public final class SettingsViewModel extends ViewModel {
                public static final int $stable = 8;
                private final BackupService backup;
                private final FileGateway files;
                private final MutableStateFlow<SettingsUiState> mutable;
                private Job observation;
                private long observationVersion;
                private final StudyRepository repo;
                private final Function0<Unit> restored;
                private final StateFlow<SettingsUiState> state;

/* 10 */        public SettingsViewModel(StudyRepository repo, BackupService backup, FileGateway files, Function0<Unit> restored) {
                    Intrinsics.checkNotNullParameter(repo, "repo");
                    Intrinsics.checkNotNullParameter(backup, "backup");
                    Intrinsics.checkNotNullParameter(files, "files");
                    Intrinsics.checkNotNullParameter(restored, "restored");
                    this.repo = repo;
                    this.backup = backup;
                    this.files = files;
                    this.restored = restored;
/* 12 */            this.mutable = StateFlowKt.MutableStateFlow(new SettingsUiState(null, null, false, null, null, null, 63));
/* 13 */            this.state = FlowKt.asStateFlow(this.mutable);
/* 16 */            retryObservation();
                }

/* 12 */        public final StateFlow<SettingsUiState> getState() {
/* 13 */            return this.state;
                }

/* 17 */        public final void retryObservation() {
/* 18 */            this.observationVersion++;
                    long version = this.observationVersion;
/* 19 */            Job job = this.observation;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
/* 20 */            setValue(SettingsUiState.copy$default(getValue(), null, null, false, null, null, null, 61, null));
/* 1 */             this.observation = BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04611(version, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$retryObservation$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$retryObservation$1", f = "SettingsViewModel.kt", i = {}, l = {22}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 19 */        static final class C04611 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ long $version;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04611(long j, Continuation<? super C04611> continuation) {
                        super(2, continuation);
                        this.$version = j;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return SettingsViewModel.this.new C04611(this.$version, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04611) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 20 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            switch (this.label) {
                                case 0:
/* 21 */                            ResultKt.throwOnFailure($result);
/* 11 */                            Flow<AppSettings> flowObserveSettings = SettingsViewModel.this.repo.observeSettings();
                                    final long j = this.$version;
                                    final SettingsViewModel settingsViewModel = SettingsViewModel.this;
                                    this.label = 1;
                                    if (flowObserveSettings.collect(new FlowCollector() { // from class: com.xunji.flashcards.ui.SettingsViewModel.retryObservation.1.1
/* 21 */                                public final Object emit(AppSettings settings, Continuation<? super Unit> continuation) {
                                            if (j == settingsViewModel.observationVersion) {
/* 11 */                                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), settings, null, false, null, null, null, 60, null));
                                            }
                                            return Unit.INSTANCE;
                                        }

                                        @Override // kotlinx.coroutines.flow.FlowCollector
/* 21 */                                public /* bridge */ /* synthetic */ Object emit(Object value, Continuation $completion) {
/* 22 */                                    return emit((AppSettings) value, (Continuation<? super Unit>) $completion);
                                        }
                                    }, this) == coroutine_suspended) {
/* 21 */                                return coroutine_suspended;
                                    }
                                    break;
                                case 1:
                                    ResultKt.throwOnFailure($result);
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (CancellationException e) {
/* 23 */                    throw e;
                        } catch (Exception e2) {
                            if (this.$version == SettingsViewModel.this.observationVersion) {
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, "无法读取学习设置，请重试；已有数据会保留", false, null, null, null, 61, null));
                            }
                        }
/* 26 */                return Unit.INSTANCE;
                    }
                }

/* 27 */        static /* synthetic */ void operation$default(SettingsViewModel settingsViewModel, boolean z, Function1 function1, int i, Object obj) {
/* 28 */            if ((i & 1) != 0) {
                        z = false;
                    }
                    settingsViewModel.operation(z, function1);
                }

/* 28 */        private final void operation(boolean exporting, Function1<? super Continuation<? super Unit>, ? extends Object> block) {
/* 29 */            if (getValue().getBusy()) {
                        return;
                    }
/* 30 */            setValue(SettingsUiState.copy$default(getValue(), null, null, true, null, null, null, 11, null));
/* 1 */             BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), null, null, new C04591(block, exporting, this, null), 3, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$operation$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$operation$1", f = "SettingsViewModel.kt", i = {}, l = {32}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 29 */        static final class C04591 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ Function1<Continuation<? super Unit>, Object> $block;
                    final /* synthetic */ boolean $exporting;
                    int label;
                    final /* synthetic */ SettingsViewModel this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    /* JADX WARN: Multi-variable type inference failed */
                    C04591(Function1<? super Continuation<? super Unit>, ? extends Object> function1, boolean z, SettingsViewModel settingsViewModel, Continuation<? super C04591> continuation) {
                        super(2, continuation);
                        this.$block = function1;
                        this.$exporting = z;
                        this.this$0 = settingsViewModel;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04591(this.$block, this.$exporting, this.this$0, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04591) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:34:0x00a1  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 30 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        String str;
                        String strTake;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        try {
                            try {
                                try {
                                    switch (this.label) {
                                        case 0:
/* 31 */                                    ResultKt.throwOnFailure($result);
/* 32 */                                    Function1<Continuation<? super Unit>, Object> function1 = this.$block;
                                            this.label = 1;
                                            if (function1.invoke(this) == coroutine_suspended) {
/* 31 */                                        return coroutine_suspended;
                                            }
                                            break;
                                        case 1:
                                            ResultKt.throwOnFailure($result);
                                            break;
                                        default:
                                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                    }
                                } catch (Exception e) {
/* 33 */                            String explanation = this.$exporting ? "导出未完成，目标文件可能不完整，请重试" : "操作未完成，请检查文件或重试";
/* 34 */                            String message = e.getMessage();
                                    String detail = null;
/* 34 */                            if (message != null && (strTake = StringsKt.take(message, 240)) != null && !StringsKt.isBlank(strTake)) {
                                        detail = strTake;
                                    }
/* 11 */                            MutableStateFlow mutableStateFlow = this.this$0.mutable;
/* 11 */                            SettingsUiState settingsUiState = (SettingsUiState) getValue();
                                    if (detail != null) {
/* 51 */                                str = "：" + detail;
                                        if (str == null) {
                                            str = "";
                                        }
                                    } else {
                                        str = "";
                                    }
                                    mutableStateFlow.setValue(SettingsUiState.copy$default(settingsUiState, null, null, false, null, null, explanation + str, 15, null));
                                }
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, null, null, 59, null));
/* 38 */                        return Unit.INSTANCE;
                            } catch (CancellationException e2) {
/* 32 */                        throw e2;
                            }
                        } catch (Throwable th) {
/* 11 */                    setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, null, null, 59, null));
                            throw th;
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$prepareRestore$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$prepareRestore$1", f = "SettingsViewModel.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_10, MotionEventCompat.AXIS_GENERIC_10, MotionEventCompat.AXIS_GENERIC_10}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 38 */        static final class C04601 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ Uri $uri;
                    Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04601(Uri uri, Continuation<? super C04601> continuation) {
                        super(1, continuation);
                        this.$uri = uri;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return SettingsViewModel.this.new C04601(this.$uri, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04601) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$prepareRestore$1$1, reason: invalid class name and collision with other inner class name */
                    /* JADX INFO: compiled from: SettingsViewModel.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$prepareRestore$1$1", f = "SettingsViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 39 */            static final class C01021 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                        int label;
                        final /* synthetic */ SettingsViewModel this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        C01021(SettingsViewModel settingsViewModel, Continuation<? super C01021> continuation) {
                            super(2, continuation);
                            this.this$0 = settingsViewModel;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new C01021(this.this$0, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                            return ((C01021) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 40 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 11 */                            PreparedBackup prepared = ((SettingsUiState) getValue()).getPrepared();
                                    if (prepared == null) {
                                        return null;
                                    }
                                    prepared.close();
                                    return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        }
                    }

                    /* JADX WARN: Code duplicated, block: B:14:0x0083 A[RETURN] */
                    /* JADX WARN: Code duplicated, block: B:17:0x0094 A[RETURN] */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 40 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        BackupService backupService;
                        Object obj;
                        Object objPrepare;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
                                if (BuildersKt.withContext(Dispatchers.getIO(), new C01021(SettingsViewModel.this, null), this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, null, null, 55, null));
/* 11 */                        backupService = SettingsViewModel.this.backup;
                                this.L$0 = backupService;
                                this.label = 2;
/* 11 */                        obj = SettingsViewModel.this.files.read(this.$uri, this);
                                if (obj == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                this.L$0 = null;
                                this.label = 3;
                                objPrepare = backupService.prepare((InputStream) obj, this);
                                if (objPrepare == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                PreparedBackup prepared = (PreparedBackup) objPrepare;
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, prepared, null, null, 55, null));
                                return Unit.INSTANCE;
                            case 1:
                                ResultKt.throwOnFailure($result);
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, null, null, 55, null));
/* 11 */                        backupService = SettingsViewModel.this.backup;
                                this.L$0 = backupService;
                                this.label = 2;
/* 11 */                        obj = SettingsViewModel.this.files.read(this.$uri, this);
                                if (obj == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                this.L$0 = null;
                                this.label = 3;
                                objPrepare = backupService.prepare((InputStream) obj, this);
                                if (objPrepare == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                PreparedBackup prepared2 = (PreparedBackup) objPrepare;
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, prepared2, null, null, 55, null));
                                return Unit.INSTANCE;
                            case 2:
                                backupService = (BackupService) this.L$0;
                                ResultKt.throwOnFailure($result);
                                obj = $result;
                                this.L$0 = null;
                                this.label = 3;
                                objPrepare = backupService.prepare((InputStream) obj, this);
                                if (objPrepare == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                PreparedBackup prepared3 = (PreparedBackup) objPrepare;
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, prepared3, null, null, 55, null));
                                return Unit.INSTANCE;
                            case 3:
                                ResultKt.throwOnFailure($result);
                                objPrepare = $result;
                                PreparedBackup prepared4 = (PreparedBackup) objPrepare;
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, prepared4, null, null, 55, null));
                                return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$saveSettings$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$saveSettings$1", f = "SettingsViewModel.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_9}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 38 */        static final class C04621 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ AppSettings $settings;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04621(AppSettings appSettings, Continuation<? super C04621> continuation) {
                        super(1, continuation);
                        this.$settings = appSettings;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return SettingsViewModel.this.new C04621(this.$settings, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04621) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 39 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
/* 11 */                        if (SettingsViewModel.this.repo.saveSettings(this.$settings, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 11 */                setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, "设置已保存", null, 47, null));
                        return Unit.INSTANCE;
                    }
                }

/* 39 */        public final void saveSettings(AppSettings settings) {
                    Intrinsics.checkNotNullParameter(settings, "settings");
/* 40 */            operation$default(this, false, new C04621(settings, null), 1, null);
                }

/* 40 */        public final void prepareRestore(Uri uri) {
                    Intrinsics.checkNotNullParameter(uri, "uri");
/* 41 */            operation$default(this, false, new C04601(uri, null), 1, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$confirmRestore$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$confirmRestore$1", f = "SettingsViewModel.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_13}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 42 */        static final class C04561 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ PreparedBackup $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04561(PreparedBackup preparedBackup, Continuation<? super C04561> continuation) {
                        super(1, continuation);
                        this.$prepared = preparedBackup;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return SettingsViewModel.this.new C04561(this.$prepared, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04561) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 43 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 11 */                        setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, null, null, 55, null));
                                this.label = 1;
/* 11 */                        if (SettingsViewModel.this.backup.replace(this.$prepared, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 11 */                invoke();
/* 11 */                setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, "备份已恢复", null, 39, null));
                        return Unit.INSTANCE;
                    }
                }

/* 42 */        public final void confirmRestore() {
/* 43 */            PreparedBackup prepared = getValue().getPrepared();
                    if (prepared == null) {
                        return;
                    }
/* 44 */            operation$default(this, false, new C04561(prepared, null), 1, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$cancelRestore$1, reason: invalid class name */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$cancelRestore$1", f = "SettingsViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 44 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ PreparedBackup $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(PreparedBackup preparedBackup, Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedBackup;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass1(this.$prepared, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 45 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
                                    PreparedBackup preparedBackup = this.$prepared;
                                    if (preparedBackup != null) {
                                        preparedBackup.close();
                                    }
                                    break;
                                } catch (Exception e) {
                                    Log.w("BackupService", "Backup staging cleanup will retry on startup", e);
                                }
                                return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$export$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\u0006\n\u0000\n\u0002\u0010\u0002\u0010\u0000\u001a\u00020\u0001H\n"}, d2 = {"<anonymous>", ""}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$export$1", f = "SettingsViewModel.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_16}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 44 */        static final class C04571 extends SuspendLambda implements Function1<Continuation<? super Unit>, Object> {
                    final /* synthetic */ Uri $uri;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04571(Uri uri, Continuation<? super C04571> continuation) {
                        super(1, continuation);
                        this.$uri = uri;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Continuation<?> continuation) {
                        return SettingsViewModel.this.new C04571(this.$uri, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function1
                    public final Object invoke(Continuation<? super Unit> continuation) {
                        return ((C04571) create(continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$export$1$1, reason: invalid class name and collision with other inner class name */
                    /* JADX INFO: compiled from: SettingsViewModel.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$export$1$1", f = "SettingsViewModel.kt", i = {1, 1}, l = {MotionEventCompat.AXIS_GENERIC_16, MotionEventCompat.AXIS_GENERIC_16}, m = "invokeSuspend", n = {"it\\1", "$i$a$-use-SettingsViewModel$export$1$1$1\\1\\47\\0"}, s = {"L$1", "I$0"}, v = 1)
/* 45 */            static final class C01011 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                        final /* synthetic */ Uri $uri;
                        int I$0;
                        Object L$0;
                        Object L$1;
                        int label;
                        final /* synthetic */ SettingsViewModel this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        C01011(SettingsViewModel settingsViewModel, Uri uri, Continuation<? super C01011> continuation) {
                            super(2, continuation);
                            this.this$0 = settingsViewModel;
                            this.$uri = uri;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new C01011(this.this$0, this.$uri, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                            return ((C01011) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Code duplicated, block: B:18:0x005a A[RETURN] */
                        /* JADX WARN: Code duplicated, block: B:19:0x005b  */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 46 */                public final Object invokeSuspend(Object $result) throws Throwable {
                            Object objWrite;
                            Closeable closeable;
                            OutputStream outputStream;
                            BackupService backupService;
                            OutputStream outputStream2;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            try {
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        this.label = 1;
/* 11 */                                objWrite = this.this$0.files.write(this.$uri, this);
                                        if (objWrite == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        closeable = (Closeable) objWrite;
                                        outputStream = (OutputStream) closeable;
/* 11 */                                backupService = this.this$0.backup;
                                        this.L$0 = closeable;
                                        this.L$1 = outputStream;
/* 51 */                                this.I$0 = 0;
                                        this.label = 2;
                                        if (backupService.export(outputStream, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        outputStream2 = outputStream;
                                        outputStream2.flush();
                                        Unit unit = Unit.INSTANCE;
                                        CloseableKt.closeFinally(closeable, null);
                                        return Unit.INSTANCE;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        objWrite = $result;
                                        closeable = (Closeable) objWrite;
                                        outputStream = (OutputStream) closeable;
/* 11 */                                backupService = this.this$0.backup;
                                        this.L$0 = closeable;
                                        this.L$1 = outputStream;
/* 51 */                                this.I$0 = 0;
                                        this.label = 2;
                                        if (backupService.export(outputStream, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        outputStream2 = outputStream;
                                        outputStream2.flush();
                                        Unit unit2 = Unit.INSTANCE;
                                        CloseableKt.closeFinally(closeable, null);
                                        return Unit.INSTANCE;
                                    case 2:
                                        int i = this.I$0;
                                        outputStream2 = (OutputStream) this.L$1;
                                        closeable = (Closeable) this.L$0;
                                        ResultKt.throwOnFailure($result);
                                        outputStream2.flush();
                                        Unit unit3 = Unit.INSTANCE;
                                        CloseableKt.closeFinally(closeable, null);
                                        return Unit.INSTANCE;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
                            } catch (Throwable th) {
                                try {
                                    throw th;
                                } catch (Throwable th2) {
                                    CloseableKt.closeFinally(closeable, th);
                                    throw th2;
                                }
                            }
                        }
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 46 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                this.label = 1;
                                if (BuildersKt.withContext(Dispatchers.getIO(), new C01011(SettingsViewModel.this, this.$uri, null), this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
/* 11 */                setValue(SettingsUiState.copy$default((SettingsUiState) getValue(), null, null, false, null, "备份已导出", null, 47, null));
                        return Unit.INSTANCE;
                    }
                }

/* 45 */        public final void cancelRestore() {
/* 46 */            if (getValue().getBusy()) {
                        return;
                    }
                    PreparedBackup prepared = getValue().getPrepared();
                    setValue(SettingsUiState.copy$default(getValue(), null, null, false, null, null, null, 55, null));
/* 1 */             BuildersKt__Builders_commonKt.launch$default(ViewModelKt.getViewModelScope(this), Dispatchers.getIO(), null, new AnonymousClass1(prepared, null), 2, null);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.SettingsViewModel$onCleared$1, reason: invalid class name and case insensitive filesystem */
                /* JADX INFO: compiled from: SettingsViewModel.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.SettingsViewModel$onCleared$1", f = "SettingsViewModel.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 46 */        static final class C04581 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ PreparedBackup $prepared;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    C04581(PreparedBackup preparedBackup, Continuation<? super C04581> continuation) {
                        super(2, continuation);
                        this.$prepared = preparedBackup;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new C04581(this.$prepared, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((C04581) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 47 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                try {
                                    PreparedBackup preparedBackup = this.$prepared;
                                    if (preparedBackup != null) {
                                        preparedBackup.close();
                                    }
                                    break;
                                } catch (Exception e) {
                                }
                                return Unit.INSTANCE;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

/* 46 */        public final void export(Uri uri) {
                    Intrinsics.checkNotNullParameter(uri, "uri");
/* 47 */            operation(true, new C04571(uri, null));
                }

                @Override // androidx.lifecycle.ViewModel
/* 47 */        protected void onCleared() {
/* 48 */            PreparedBackup prepared = getValue().getPrepared();
/* 1 */             BuildersKt__Builders_commonKt.launch$default(CoroutineScopeKt.CoroutineScope(Dispatchers.getIO()), null, null, new C04581(prepared, null), 3, null);
                    super.onCleared();
                }
            }

            package com.xunji.flashcards.ui;

            import androidx.lifecycle.Lifecycle;
            import androidx.lifecycle.LifecycleOwner;
            import androidx.lifecycle.RepeatOnLifecycleKt;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.CoroutineScopeKt;
            import kotlinx.coroutines.DelayKt;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$2$1", f = "XunjiApp.kt", i = {}, l = {65}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 62 */    final class XunjiAppKt$XunjiApp$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ MainViewModel $main;
                final /* synthetic */ LifecycleOwner $owner;
                final /* synthetic */ ReviewViewModel $review;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                XunjiAppKt$XunjiApp$2$1(LifecycleOwner lifecycleOwner, MainViewModel mainViewModel, ReviewViewModel reviewViewModel, Continuation<? super XunjiAppKt$XunjiApp$2$1> continuation) {
                    super(2, continuation);
                    this.$owner = lifecycleOwner;
                    this.$main = mainViewModel;
                    this.$review = reviewViewModel;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new XunjiAppKt$XunjiApp$2$1(this.$owner, this.$main, this.$review, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((XunjiAppKt$XunjiApp$2$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$2$1$1, reason: invalid class name */
                /* JADX INFO: compiled from: XunjiApp.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$2$1$1", f = "XunjiApp.kt", i = {0}, l = {65}, m = "invokeSuspend", n = {"$this$repeatOnLifecycle"}, s = {"L$0"}, v = 1)
/* 63 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ MainViewModel $main;
                    final /* synthetic */ ReviewViewModel $review;
                    private /* synthetic */ Object L$0;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(MainViewModel mainViewModel, ReviewViewModel reviewViewModel, Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                        this.$main = mainViewModel;
                        this.$review = reviewViewModel;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        AnonymousClass1 anonymousClass1 = new AnonymousClass1(this.$main, this.$review, continuation);
                        anonymousClass1.L$0 = obj;
                        return anonymousClass1;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 64 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        CoroutineScope $this$repeatOnLifecycle = (CoroutineScope) this.L$0;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
                                break;
                            case 1:
                                ResultKt.throwOnFailure($result);
                                break;
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                        while (CoroutineScopeKt.isActive($this$repeatOnLifecycle)) {
                            MainViewModel.refresh$default(this.$main, null, null, 3, null);
                            this.$review.refresh();
                            this.L$0 = $this$repeatOnLifecycle;
                            this.label = 1;
                            if (DelayKt.delay(60000L, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                        }
                        return Unit.INSTANCE;
                    }
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 64 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.label = 1;
                            if (RepeatOnLifecycleKt.repeatOnLifecycle(getLifecycle(), Lifecycle.State.RESUMED, new AnonymousClass1(this.$main, this.$review, null), this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            break;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            break;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }

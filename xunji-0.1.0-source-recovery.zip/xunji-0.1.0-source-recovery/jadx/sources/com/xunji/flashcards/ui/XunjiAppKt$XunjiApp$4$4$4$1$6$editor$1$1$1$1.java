            package com.xunji.flashcards.ui;

            import com.xunji.flashcards.data.AnkiNoteContent;
            import com.xunji.flashcards.data.AnkiRepository;
            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.SuspendFunction;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 94 */    final /* synthetic */ class XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$1 extends FunctionReferenceImpl implements Function2<String, Continuation<? super AnkiNoteContent>, Object>, SuspendFunction {
                XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$1(Object obj) {
                    super(2, obj, AnkiRepository.class, "noteForCard", "noteForCard(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
                }

                @Override // kotlin.jvm.functions.Function2
/* 95 */        public final Object invoke(String p0, Continuation<? super AnkiNoteContent> continuation) {
/* 96 */            return ((AnkiRepository) this.receiver).noteForCard(p0, continuation);
                }
            }

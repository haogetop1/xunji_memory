            package com.xunji.flashcards.ui;

            import com.xunji.flashcards.data.AnkiRepository;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.SuspendFunction;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 94 */    final /* synthetic */ class XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$2 extends FunctionReferenceImpl implements Function4<String, Long, List<? extends String>, Continuation<? super Unit>, Object>, SuspendFunction {
                XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$2(Object obj) {
                    super(4, obj, AnkiRepository.class, "updateFields", "updateFields(Ljava/lang/String;JLjava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
                }

                @Override // kotlin.jvm.functions.Function4
/* 95 */        public /* bridge */ /* synthetic */ Object invoke(String str, Long l, List<? extends String> list, Continuation<? super Unit> continuation) {
/* 96 */            return invoke(str, l.longValue(), (List<String>) list, continuation);
                }

/* 95 */        public final Object invoke(String p0, long p1, List<String> list, Continuation<? super Unit> continuation) {
/* 96 */            return ((AnkiRepository) this.receiver).updateFields(p0, p1, list, continuation);
                }
            }

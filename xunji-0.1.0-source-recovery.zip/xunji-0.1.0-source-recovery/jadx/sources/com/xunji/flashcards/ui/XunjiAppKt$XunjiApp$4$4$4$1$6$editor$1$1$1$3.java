            package com.xunji.flashcards.ui;

            import com.xunji.core.anki.CardSide;
            import com.xunji.flashcards.anki.AnkiCardPresenter;
            import com.xunji.flashcards.anki.RenderedCard;
            import com.xunji.flashcards.data.AnkiNoteContent;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.SuspendFunction;
            import kotlin.jvm.functions.Function5;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 94 */    final /* synthetic */ class XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$3 extends FunctionReferenceImpl implements Function5<AnkiNoteContent, String, CardSide, List<? extends String>, Continuation<? super RenderedCard>, Object>, SuspendFunction {
                XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$3(Object obj) {
                    super(5, obj, AnkiCardPresenter.class, "preview", "preview(Lcom/xunji/flashcards/data/AnkiNoteContent;Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Ljava/util/List;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 95 */        public final Object invoke2(AnkiNoteContent p0, String p1, CardSide p2, List<String> list, Continuation<? super RenderedCard> continuation) {
/* 96 */            return ((AnkiCardPresenter) this.receiver).preview(p0, p1, p2, list, continuation);
                }

                @Override // kotlin.jvm.functions.Function5
/* 95 */        public /* bridge */ /* synthetic */ Object invoke(AnkiNoteContent ankiNoteContent, String str, CardSide cardSide, List<? extends String> list, Continuation<? super RenderedCard> continuation) {
/* 96 */            return invoke2(ankiNoteContent, str, cardSide, (List<String>) list, continuation);
                }
            }

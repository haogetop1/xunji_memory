            package com.xunji.flashcards.ui;

            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$4$4$4$1$7$1$1", f = "XunjiApp.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 100 */   final class XunjiAppKt$XunjiApp$4$4$4$1$7$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ String $id;
                final /* synthetic */ ReviewViewModel $review;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                XunjiAppKt$XunjiApp$4$4$4$1$7$1$1(ReviewViewModel reviewViewModel, String str, Continuation<? super XunjiAppKt$XunjiApp$4$4$4$1$7$1$1> continuation) {
                    super(2, continuation);
                    this.$review = reviewViewModel;
                    this.$id = str;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new XunjiAppKt$XunjiApp$4$4$4$1$7$1$1(this.$review, this.$id, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((XunjiAppKt$XunjiApp$4$4$4$1$7$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 101 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.$review.start(this.$id);
                            return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

            package com.xunji.flashcards.ui;

            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 105 */   final /* synthetic */ class XunjiAppKt$XunjiApp$4$4$4$1$7$4$1 extends FunctionReferenceImpl implements Function0<Unit> {
                XunjiAppKt$XunjiApp$4$4$4$1$7$4$1(Object obj) {
                    super(0, obj, ReviewViewModel.class, "reveal", "reveal()V", 0);
                }

                @Override // kotlin.jvm.functions.Function0
/* 106 */       public /* bridge */ /* synthetic */ Unit invoke() {
/* 107 */           invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 106 */       public final void invoke2() {
/* 107 */           ((ReviewViewModel) this.receiver).reveal();
                }
            }

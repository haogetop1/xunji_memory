            package com.xunji.flashcards.ui;

            import com.xunji.core.model.Rating;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 105 */   final /* synthetic */ class XunjiAppKt$XunjiApp$4$4$4$1$7$5$1 extends FunctionReferenceImpl implements Function1<Rating, Unit> {
                XunjiAppKt$XunjiApp$4$4$4$1$7$5$1(Object obj) {
                    super(1, obj, ReviewViewModel.class, "grade", "grade(Lcom/xunji/core/model/Rating;)V", 0);
                }

                @Override // kotlin.jvm.functions.Function1
/* 106 */       public /* bridge */ /* synthetic */ Unit invoke(Rating rating) {
/* 107 */           invoke2(rating);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 106 */       public final void invoke2(Rating p0) {
                    Intrinsics.checkNotNullParameter(p0, "p0");
/* 107 */           ((ReviewViewModel) this.receiver).grade(p0);
                }
            }

            package com.xunji.flashcards.ui;

            import com.xunji.flashcards.AppContainer;
            import com.xunji.flashcards.anki.CardMedia;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "Ljava/io/InputStream;", "it", "Lcom/xunji/flashcards/anki/CardMedia;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$4$4$4$1$7$8$1", f = "XunjiApp.kt", i = {0}, l = {107}, m = "invokeSuspend", n = {"it"}, s = {"L$0"}, v = 1)
/* 105 */   final class XunjiAppKt$XunjiApp$4$4$4$1$7$8$1 extends SuspendLambda implements Function2<CardMedia, Continuation<? super InputStream>, Object> {
                final /* synthetic */ AppContainer $container;
                /* synthetic */ Object L$0;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                XunjiAppKt$XunjiApp$4$4$4$1$7$8$1(AppContainer appContainer, Continuation<? super XunjiAppKt$XunjiApp$4$4$4$1$7$8$1> continuation) {
                    super(2, continuation);
                    this.$container = appContainer;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    XunjiAppKt$XunjiApp$4$4$4$1$7$8$1 xunjiAppKt$XunjiApp$4$4$4$1$7$8$1 = new XunjiAppKt$XunjiApp$4$4$4$1$7$8$1(this.$container, continuation);
                    xunjiAppKt$XunjiApp$4$4$4$1$7$8$1.L$0 = obj;
                    return xunjiAppKt$XunjiApp$4$4$4$1$7$8$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CardMedia cardMedia, Continuation<? super InputStream> continuation) {
                    return ((XunjiAppKt$XunjiApp$4$4$4$1$7$8$1) create(cardMedia, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 106 */       public final Object invokeSuspend(Object $result) throws Throwable {
                    CardMedia it = (CardMedia) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.L$0 = SpillingKt.nullOutSpilledVariable(it);
                            this.label = 1;
                            Object objOpen = this.$container.getMediaStore().open(it.getNamespace(), it.getName(), this);
                            return objOpen == coroutine_suspended ? coroutine_suspended : objOpen;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            return $result;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

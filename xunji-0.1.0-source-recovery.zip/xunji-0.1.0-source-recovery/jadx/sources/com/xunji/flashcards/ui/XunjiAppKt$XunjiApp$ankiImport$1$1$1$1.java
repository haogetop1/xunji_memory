            package com.xunji.flashcards.ui;

            import android.content.ContentResolver;
            import android.database.Cursor;
            import android.net.Uri;
            import java.io.IOException;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.Boxing;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SpillingKt;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/ui/ImportSource;", "uri", "Landroid/net/Uri;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$ankiImport$1$1$1$1", f = "XunjiApp.kt", i = {0}, l = {49}, m = "invokeSuspend", n = {"uri"}, s = {"L$0"}, v = 1)
/* 46 */    final class XunjiAppKt$XunjiApp$ankiImport$1$1$1$1 extends SuspendLambda implements Function2<Uri, Continuation<? super ImportSource>, Object> {
                final /* synthetic */ ContentResolver $resolver;
                /* synthetic */ Object L$0;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                XunjiAppKt$XunjiApp$ankiImport$1$1$1$1(ContentResolver contentResolver, Continuation<? super XunjiAppKt$XunjiApp$ankiImport$1$1$1$1> continuation) {
                    super(2, continuation);
                    this.$resolver = contentResolver;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    XunjiAppKt$XunjiApp$ankiImport$1$1$1$1 xunjiAppKt$XunjiApp$ankiImport$1$1$1$1 = new XunjiAppKt$XunjiApp$ankiImport$1$1$1$1(this.$resolver, continuation);
                    xunjiAppKt$XunjiApp$ankiImport$1$1$1$1.L$0 = obj;
                    return xunjiAppKt$XunjiApp$ankiImport$1$1$1$1;
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(Uri uri, Continuation<? super ImportSource> continuation) {
                    return ((XunjiAppKt$XunjiApp$ankiImport$1$1$1$1) create(uri, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$ankiImport$1$1$1$1$1, reason: invalid class name */
                /* JADX INFO: compiled from: XunjiApp.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Lcom/xunji/flashcards/ui/ImportSource;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$ankiImport$1$1$1$1$1", f = "XunjiApp.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 47 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super ImportSource>, Object> {
                    final /* synthetic */ ContentResolver $resolver;
                    final /* synthetic */ Uri $uri;
                    int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(ContentResolver contentResolver, Uri uri, Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                        this.$resolver = contentResolver;
                        this.$uri = uri;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass1(this.$resolver, this.$uri, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super ImportSource> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:21:0x005a  */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 48 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        String string;
                        IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
                                ResultKt.throwOnFailure($result);
/* 50 */                        Cursor cursorQuery = this.$resolver.query(this.$uri, new String[]{"_display_name"}, null, null, null);
                                String name = null;
                                if (cursorQuery != null) {
                                    Cursor cursor = cursorQuery;
                                    try {
                                        Cursor cursor2 = cursor;
/* 51 */                                if (cursor2.moveToFirst()) {
                                            Integer numBoxInt = Boxing.boxInt(cursor2.getColumnIndex("_display_name"));
/* 51 */                                    if (!(numBoxInt.intValue() >= 0)) {
                                                numBoxInt = null;
                                            }
                                            if (numBoxInt != null) {
/* 51 */                                        string = cursor2.getString(numBoxInt.intValue());
                                            } else {
                                                string = null;
                                            }
                                        } else {
                                            string = null;
                                        }
/* 50 */                                CloseableKt.closeFinally(cursor, null);
                                        name = string;
                                        break;
                                    } catch (Throwable th) {
                                        try {
                                            throw th;
                                        } catch (Throwable th2) {
                                            CloseableKt.closeFinally(cursor, th);
                                            throw th2;
                                        }
                                    }
                                }
                                InputStream inputStreamOpenInputStream = this.$resolver.openInputStream(this.$uri);
                                if (inputStreamOpenInputStream != null) {
/* 53 */                            return new ImportSource(inputStreamOpenInputStream, name);
                                }
                                throw new IOException("无法读取所选文件");
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 48 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Uri uri = (Uri) this.L$0;
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            this.L$0 = SpillingKt.nullOutSpilledVariable(uri);
                            this.label = 1;
                            Object objWithContext = BuildersKt.withContext(Dispatchers.getIO(), new AnonymousClass1(this.$resolver, uri, null), this);
                            return objWithContext == coroutine_suspended ? coroutine_suspended : objWithContext;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            return $result;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

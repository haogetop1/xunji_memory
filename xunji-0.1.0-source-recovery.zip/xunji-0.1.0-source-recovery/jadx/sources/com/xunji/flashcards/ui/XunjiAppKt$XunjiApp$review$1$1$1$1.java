            package com.xunji.flashcards.ui;

            import com.xunji.core.anki.CardSide;
            import com.xunji.flashcards.anki.AnkiCardPresenter;
            import com.xunji.flashcards.anki.RenderedCard;
            import kotlin.Metadata;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.jvm.internal.SuspendFunction;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 44 */    final /* synthetic */ class XunjiAppKt$XunjiApp$review$1$1$1$1 extends FunctionReferenceImpl implements Function3<String, CardSide, Continuation<? super RenderedCard>, Object>, SuspendFunction {
                XunjiAppKt$XunjiApp$review$1$1$1$1(Object obj) {
                    super(3, obj, AnkiCardPresenter.class, "present", "present(Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
                }

                @Override // kotlin.jvm.functions.Function3
/* 45 */        public final Object invoke(String p0, CardSide p1, Continuation<? super RenderedCard> continuation) {
/* 46 */            return ((AnkiCardPresenter) this.receiver).present(p0, p1, continuation);
                }
            }

            package com.xunji.flashcards.ui;

            import android.app.Activity;
            import android.content.ContentResolver;
            import android.content.Context;
            import android.content.ContextWrapper;
            import android.net.Uri;
            import android.os.Bundle;
            import android.view.Window;
            import androidx.activity.compose.ActivityResultRegistryKt;
            import androidx.activity.compose.BackHandlerKt;
            import androidx.activity.compose.ManagedActivityResultLauncher;
            import androidx.activity.result.contract.ActivityResultContracts;
            import androidx.compose.animation.AnimatedContentScope;
            import androidx.compose.animation.AnimatedContentTransitionScope;
            import androidx.compose.animation.EnterExitTransitionKt;
            import androidx.compose.animation.EnterTransition;
            import androidx.compose.animation.ExitTransition;
            import androidx.compose.animation.core.AnimationSpecKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.SpacerKt;
            import androidx.compose.foundation.layout.WindowInsetsPadding_androidKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.NavigationBarItemColors;
            import androidx.compose.material3.NavigationBarItemDefaults;
            import androidx.compose.material3.NavigationBarKt;
            import androidx.compose.material3.ScaffoldKt;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.DisposableEffectResult;
            import androidx.compose.runtime.DisposableEffectScope;
            import androidx.compose.runtime.EffectsKt;
            import androidx.compose.runtime.ProvidableCompositionLocal;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.State;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.graphics.Color;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.unit.Dp;
            import androidx.core.view.WindowCompat;
            import androidx.core.view.WindowInsetsControllerCompat;
            import androidx.lifecycle.HasDefaultViewModelProviderFactory;
            import androidx.lifecycle.Lifecycle;
            import androidx.lifecycle.LifecycleEventObserver;
            import androidx.lifecycle.LifecycleOwner;
            import androidx.lifecycle.SavedStateHandleSupport;
            import androidx.lifecycle.ViewModel;
            import androidx.lifecycle.ViewModelProvider;
            import androidx.lifecycle.ViewModelStoreOwner;
            import androidx.lifecycle.compose.FlowExtKt;
            import androidx.lifecycle.compose.LocalLifecycleOwnerKt;
            import androidx.lifecycle.viewmodel.CreationExtras;
            import androidx.lifecycle.viewmodel.InitializerViewModelFactoryBuilder;
            import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner;
            import androidx.lifecycle.viewmodel.compose.ViewModelKt;
            import androidx.navigation.NamedNavArgumentKt;
            import androidx.navigation.NavArgumentBuilder;
            import androidx.navigation.NavBackStackEntry;
            import androidx.navigation.NavController;
            import androidx.navigation.NavDestination;
            import androidx.navigation.NavGraphBuilder;
            import androidx.navigation.NavHostController;
            import androidx.navigation.NavOptions;
            import androidx.navigation.NavOptionsBuilder;
            import androidx.navigation.NavType;
            import androidx.navigation.Navigator;
            import androidx.navigation.PopUpToBuilder;
            import androidx.navigation.compose.NavGraphBuilderKt;
            import androidx.navigation.compose.NavHostControllerKt;
            import androidx.navigation.compose.NavHostKt;
            import com.xunji.core.model.ThemeMode;
            import com.xunji.flashcards.AppContainer;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import com.xunji.flashcards.ui.screens.AnkiImportScreenKt;
            import com.xunji.flashcards.ui.screens.CardEditorScreenKt;
            import com.xunji.flashcards.ui.screens.DeckDetailScreenKt;
            import com.xunji.flashcards.ui.screens.DecksScreenKt;
            import com.xunji.flashcards.ui.screens.ReviewScreenKt;
            import com.xunji.flashcards.ui.screens.SettingsScreenKt;
            import com.xunji.flashcards.ui.screens.StatisticsScreenKt;
            import com.xunji.flashcards.ui.screens.TodayScreenKt;
            import com.xunji.flashcards.ui.theme.ThemeKt;
            import java.time.LocalDate;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Triple;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.CoroutineContext;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Reflection;
            import kotlin.reflect.KClass;
            import kotlin.reflect.KFunction;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: XunjiApp.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000P\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\u001a\u000e\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\u0002\u001a\f\u0010\u0003\u001a\u00020\u0004*\u00020\u0005H\u0000\u001a\u0014\u0010\u0006\u001a\u00020\u0004*\u00020\u00052\u0006\u0010\u0007\u001a\u00020\bH\u0000\u001a\u0015\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u000bH\u0007¢\u0006\u0002\u0010\f¨\u0006\r²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u0084\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u0084\u0002²\u0006\n\u0010\u0012\u001a\u00020\u0013X\u008a\u0084\u0002²\u0006\f\u0010\u0014\u001a\u0004\u0018\u00010\u0015X\u008a\u0084\u0002²\u0006\n\u0010\u0016\u001a\u00020\u0017X\u008a\u0084\u0002²\u0006\n\u0010\u0018\u001a\u00020\u0019X\u008a\u0084\u0002²\u0006\n\u0010\u001a\u001a\u00020\u001bX\u008a\u0084\u0002"}, d2 = {"activity", "Landroid/app/Activity;", "Landroid/content/Context;", "finishAnkiImport", "", "Landroidx/navigation/NavController;", "navigateRoot", "destination", "", "XunjiApp", "container", "Lcom/xunji/flashcards/AppContainer;", "(Lcom/xunji/flashcards/AppContainer;Landroidx/compose/runtime/Composer;I)V", "app_debug", "state", "Lcom/xunji/flashcards/ui/MainUiState;", "settingsState", "Lcom/xunji/flashcards/ui/SettingsUiState;", "importState", "Lcom/xunji/flashcards/ui/AnkiImportUiState;", "entry", "Landroidx/navigation/NavBackStackEntry;", "editorState", "Lcom/xunji/flashcards/ui/EditorUiState;", "reviewState", "Lcom/xunji/flashcards/ui/ReviewUiState;", "undoable", ""}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 32 */    public final class XunjiAppKt {

                /* JADX INFO: compiled from: XunjiApp.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[Lifecycle.Event.values().length];
                        try {
                            iArr[Lifecycle.Event.ON_RESUME.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[Lifecycle.Event.ON_PAUSE.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit XunjiApp$lambda$15(AppContainer appContainer, int i, Composer composer, int i2) {
                    XunjiApp(appContainer, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 33 */        public static final Activity activity(Context $this$activity) {
/* 34 */            if ($this$activity instanceof Activity) {
                        return (Activity) $this$activity;
                    }
                    if (!($this$activity instanceof ContextWrapper)) {
                        return null;
                    }
                    Context baseContext = ((ContextWrapper) $this$activity).getBaseContext();
                    Intrinsics.checkNotNullExpressionValue(baseContext, "getBaseContext(...)");
                    return activity(baseContext);
                }

/* 35 */        public static final void finishAnkiImport(NavController $this$finishAnkiImport) {
                    Intrinsics.checkNotNullParameter($this$finishAnkiImport, "<this>");
/* 36 */            $this$finishAnkiImport.navigate("Decks", new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda8
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiAppKt.finishAnkiImport$lambda$0((NavOptionsBuilder) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit finishAnkiImport$lambda$0(NavOptionsBuilder navigate) {
                    Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
/* 36 */            NavOptionsBuilder.popUpTo$default(navigate, "Today", (Function1) null, 2, (Object) null);
                    navigate.setLaunchSingleTop(true);
                    return Unit.INSTANCE;
                }

/* 39 */        public static final void navigateRoot(NavController $this$navigateRoot, final String destination) {
                    Intrinsics.checkNotNullParameter($this$navigateRoot, "<this>");
                    Intrinsics.checkNotNullParameter(destination, "destination");
/* 40 */            $this$navigateRoot.navigate(destination, new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda54
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiAppKt.navigateRoot$lambda$0(destination, (NavOptionsBuilder) obj);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit navigateRoot$lambda$0(String $destination, NavOptionsBuilder navigate) {
                    Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
/* 40 */            navigate.popUpTo("Today", new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda31
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiAppKt.navigateRoot$lambda$0$0((PopUpToBuilder) obj);
                        }
                    });
                    navigate.setLaunchSingleTop(true);
                    navigate.setRestoreState(true ^ Intrinsics.areEqual($destination, "Today"));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit navigateRoot$lambda$0$0(PopUpToBuilder popUpTo) {
                    Intrinsics.checkNotNullParameter(popUpTo, "$this$popUpTo");
/* 40 */            popUpTo.setSaveState(true);
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:114:0x0514  */
                /* JADX WARN: Code duplicated, block: B:121:0x052c  */
                /* JADX WARN: Code duplicated, block: B:124:0x0535  */
                /* JADX WARN: Code duplicated, block: B:126:0x0560  */
                /* JADX WARN: Code duplicated, block: B:130:0x056c  */
                /* JADX WARN: Code duplicated, block: B:133:0x0587  */
                /* JADX WARN: Code duplicated, block: B:136:0x05ec  */
/* 41 */        public static final void XunjiApp(AppContainer container, Composer $composer, final int $changed) {
                    Composer $composer2;
                    ManagedActivityResultLauncher restore;
                    String[] ankiTypes;
                    boolean focused;
                    boolean unavailable;
                    String[] ankiTypes2;
                    boolean zChanged;
                    Object objRememberedValue;
                    NavDestination destination;
                    String route;
                    final AppContainer container2 = container;
                    Intrinsics.checkNotNullParameter(container2, "container");
/* 42 */            Composer $composer3 = $composer.startRestartGroup(-172089300);
                    ComposerKt.sourceInformation($composer3, "C(XunjiApp)N(container)42@1851L7,44@1958L85,44@1940L104,45@2091L190,45@2073L209,46@2333L157,46@2315L176,47@2546L484,47@2528L503,55@3057L29,55@3123L29,56@3190L29,57@3229L23,57@3270L30,58@3379L7,59@3412L304,59@3388L328,64@3740L132,64@3718L154,65@3978L42,65@3885L135,66@4108L50,66@4034L124,67@4249L96,67@4175L170,74@4927L4616,74@4890L4653:XunjiApp.kt#thuf8k");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= ($changed & 8) == 0 ? $composer3.changed(container2) : $composer3.changedInstance(container2) ? 4 : 2;
                    }
                    int $dirty2 = $dirty;
                    if ($composer3.shouldExecute(($dirty2 & 3) != 2, $dirty2 & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 42 */                    ComposerKt.traceEventStart(-172089300, $dirty2, -1, "com.xunji.flashcards.ui.XunjiApp (XunjiApp.kt:41)");
                        }
/* 43 */                ProvidableCompositionLocal<Context> localContext = AndroidCompositionLocals_androidKt.getLocalContext();
/* 118 */               ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                        Object objConsume = $composer3.consume(localContext);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 43 */                final Context context = (Context) objConsume;
/* 44 */                final ContentResolver resolver = context.getApplicationContext().getContentResolver();
/* 45 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125912833, "CC(remember):XunjiApp.kt#9igjgp");
/* 119 */               Object objRememberedValue2 = $composer3.rememberedValue();
/* 120 */               if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 122 */                   InitializerViewModelFactoryBuilder initializerViewModelFactoryBuilder = new InitializerViewModelFactoryBuilder();
/* 123 */                   initializerViewModelFactoryBuilder.addInitializer(Reflection.getOrCreateKotlinClass(MainViewModel.class), new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda32
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return XunjiAppKt.XunjiApp$lambda$0$0$0(container2, (CreationExtras) obj);
                                }
                            });
/* 122 */                   Object objBuild = initializerViewModelFactoryBuilder.build();
/* 125 */                   $composer3.updateRememberedValue(objBuild);
/* 126 */                   objRememberedValue2 = objBuild;
                        }
/* 45 */                ViewModelProvider.Factory factory = (ViewModelProvider.Factory) objRememberedValue2;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 128 */               ComposerKt.sourceInformationMarkerStart($composer3, 1729797275, "CC(viewModel)P(3,2,1)56@2573L7,67@2980L63:ViewModel.kt#3tja67");
/* 129 */               ViewModelStoreOwner current = LocalViewModelStoreOwner.INSTANCE.getCurrent($composer3, 6);
                        if (current == null) {
/* 129 */                   throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                        }
/* 132 */               ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(MainViewModel.class), current, (String) null, factory, current instanceof HasDefaultViewModelProviderFactory ? ((HasDefaultViewModelProviderFactory) current).getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE, $composer3, ((0 << 3) & 896) | ((0 << 3) & 112) | ((0 << 3) & 7168) | ((0 << 3) & 57344), 0);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 45 */                final MainViewModel main = (MainViewModel) viewModel;
/* 46 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125917194, "CC(remember):XunjiApp.kt#9igjgp");
/* 139 */               Object objRememberedValue3 = $composer3.rememberedValue();
/* 140 */               if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
/* 142 */                   InitializerViewModelFactoryBuilder initializerViewModelFactoryBuilder2 = new InitializerViewModelFactoryBuilder();
/* 143 */                   initializerViewModelFactoryBuilder2.addInitializer(Reflection.getOrCreateKotlinClass(ReviewViewModel.class), new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda35
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return XunjiAppKt.XunjiApp$lambda$1$0$0(container2, (CreationExtras) obj);
                                }
                            });
/* 142 */                   Object objBuild2 = initializerViewModelFactoryBuilder2.build();
/* 145 */                   $composer3.updateRememberedValue(objBuild2);
/* 146 */                   objRememberedValue3 = objBuild2;
                        }
/* 46 */                ViewModelProvider.Factory factory2 = (ViewModelProvider.Factory) objRememberedValue3;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 148 */               ComposerKt.sourceInformationMarkerStart($composer3, 1729797275, "CC(viewModel)P(3,2,1)56@2573L7,67@2980L63:ViewModel.kt#3tja67");
/* 149 */               ViewModelStoreOwner current2 = LocalViewModelStoreOwner.INSTANCE.getCurrent($composer3, 6);
                        if (current2 == null) {
/* 149 */                   throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                        }
/* 152 */               ViewModel viewModel2 = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(ReviewViewModel.class), current2, (String) null, factory2, current2 instanceof HasDefaultViewModelProviderFactory ? ((HasDefaultViewModelProviderFactory) current2).getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE, $composer3, ((0 << 3) & 112) | ((0 << 3) & 896) | ((0 << 3) & 7168) | ((0 << 3) & 57344), 0);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 46 */                final ReviewViewModel review = (ReviewViewModel) viewModel2;
/* 47 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125924905, "CC(remember):XunjiApp.kt#9igjgp");
/* 159 */               Object objRememberedValue4 = $composer3.rememberedValue();
/* 160 */               if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
/* 162 */                   InitializerViewModelFactoryBuilder initializerViewModelFactoryBuilder3 = new InitializerViewModelFactoryBuilder();
/* 163 */                   initializerViewModelFactoryBuilder3.addInitializer(Reflection.getOrCreateKotlinClass(SettingsViewModel.class), new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda36
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return XunjiAppKt.XunjiApp$lambda$2$0$0(container2, review, main, (CreationExtras) obj);
                                }
                            });
/* 162 */                   Object objBuild3 = initializerViewModelFactoryBuilder3.build();
/* 165 */                   $composer3.updateRememberedValue(objBuild3);
/* 166 */                   objRememberedValue4 = objBuild3;
                        }
/* 47 */                ViewModelProvider.Factory factory3 = (ViewModelProvider.Factory) objRememberedValue4;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 168 */               ComposerKt.sourceInformationMarkerStart($composer3, 1729797275, "CC(viewModel)P(3,2,1)56@2573L7,67@2980L63:ViewModel.kt#3tja67");
/* 169 */               ViewModelStoreOwner current3 = LocalViewModelStoreOwner.INSTANCE.getCurrent($composer3, 6);
                        if (current3 == null) {
/* 169 */                   throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                        }
/* 172 */               ViewModel viewModel3 = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(SettingsViewModel.class), current3, (String) null, factory3, current3 instanceof HasDefaultViewModelProviderFactory ? ((HasDefaultViewModelProviderFactory) current3).getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE, $composer3, ((0 << 3) & 112) | ((0 << 3) & 896) | ((0 << 3) & 7168) | ((0 << 3) & 57344), 0);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 47 */                final SettingsViewModel settings = (SettingsViewModel) viewModel3;
/* 48 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125932048, "CC(remember):XunjiApp.kt#9igjgp");
/* 179 */               Object objRememberedValue5 = $composer3.rememberedValue();
/* 180 */               if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
/* 182 */                   InitializerViewModelFactoryBuilder initializerViewModelFactoryBuilder4 = new InitializerViewModelFactoryBuilder();
/* 183 */                   initializerViewModelFactoryBuilder4.addInitializer(Reflection.getOrCreateKotlinClass(AnkiImportViewModel.class), new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda37
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return XunjiAppKt.XunjiApp$lambda$3$0$0(container2, resolver, main, (CreationExtras) obj);
                                }
                            });
/* 182 */                   Object objBuild4 = initializerViewModelFactoryBuilder4.build();
/* 185 */                   $composer3.updateRememberedValue(objBuild4);
/* 186 */                   objRememberedValue5 = objBuild4;
                        }
/* 48 */                ViewModelProvider.Factory factory4 = (ViewModelProvider.Factory) objRememberedValue5;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 188 */               ComposerKt.sourceInformationMarkerStart($composer3, 1729797275, "CC(viewModel)P(3,2,1)56@2573L7,67@2980L63:ViewModel.kt#3tja67");
/* 189 */               ViewModelStoreOwner current4 = LocalViewModelStoreOwner.INSTANCE.getCurrent($composer3, 6);
                        if (current4 == null) {
/* 189 */                   throw new IllegalStateException("No ViewModelStoreOwner was provided via LocalViewModelStoreOwner".toString());
                        }
/* 192 */               ViewModel viewModel4 = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(AnkiImportViewModel.class), current4, (String) null, factory4, current4 instanceof HasDefaultViewModelProviderFactory ? ((HasDefaultViewModelProviderFactory) current4).getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE, $composer3, ((0 << 3) & 112) | ((0 << 3) & 896) | ((0 << 3) & 7168) | ((0 << 3) & 57344), 0);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 48 */                final AnkiImportViewModel ankiImport = (AnkiImportViewModel) viewModel4;
/* 56 */                final State state$delegate = FlowExtKt.collectAsStateWithLifecycle(main.getState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer3, 0, 7);
                        final State settingsState$delegate = FlowExtKt.collectAsStateWithLifecycle(settings.getState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer3, 0, 7);
/* 57 */                final State importState$delegate = FlowExtKt.collectAsStateWithLifecycle(ankiImport.getState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer3, 0, 7);
/* 58 */                final NavHostController nav = NavHostControllerKt.rememberNavController(new Navigator[0], $composer3, 0);
                        NavBackStackEntry navBackStackEntryXunjiApp$lambda$7 = XunjiApp$lambda$7(NavHostControllerKt.currentBackStackEntryAsState(nav, $composer3, 0));
                        final String route2 = (navBackStackEntryXunjiApp$lambda$7 == null || (destination = navBackStackEntryXunjiApp$lambda$7.getDestination()) == null || (route = destination.getRoute()) == null) ? "Today" : route;
/* 59 */                ProvidableCompositionLocal<LifecycleOwner> localLifecycleOwner = LocalLifecycleOwnerKt.getLocalLifecycleOwner();
                        ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                        Object objConsume2 = $composer3.consume(localLifecycleOwner);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 59 */                final LifecycleOwner owner = (LifecycleOwner) objConsume2;
/* 60 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125959580, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance = $composer3.changedInstance(main) | $composer3.changedInstance(review) | $composer3.changedInstance(owner);
                        Object objRememberedValue6 = $composer3.rememberedValue();
/* 201 */               if (zChangedInstance || objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                            objRememberedValue6 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda38
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return XunjiAppKt.XunjiApp$lambda$8$0(owner, main, review, (DisposableEffectScope) obj);
                                }
                            };
/* 203 */                   $composer3.updateRememberedValue(objRememberedValue6);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 60 */                EffectsKt.DisposableEffect(owner, (Function1<? super DisposableEffectScope, ? extends DisposableEffectResult>) objRememberedValue6, $composer3, 0);
/* 65 */                ComposerKt.sourceInformationMarkerStart($composer3, 2125969904, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance2 = $composer3.changedInstance(owner) | $composer3.changedInstance(main) | $composer3.changedInstance(review);
/* 206 */               Object objRememberedValue7 = $composer3.rememberedValue();
/* 207 */               if (zChangedInstance2 || objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                            Object obj = (Function2) new XunjiAppKt$XunjiApp$2$1(owner, main, review, null);
/* 209 */                   $composer3.updateRememberedValue(obj);
/* 210 */                   objRememberedValue7 = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 65 */                EffectsKt.LaunchedEffect(owner, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) objRememberedValue7, $composer3, 0);
/* 66 */                ActivityResultContracts.CreateDocument createDocument = new ActivityResultContracts.CreateDocument("application/zip");
                        ComposerKt.sourceInformationMarkerStart($composer3, 2125977430, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance3 = $composer3.changedInstance(settings);
                        Object objRememberedValue8 = $composer3.rememberedValue();
/* 213 */               if (zChangedInstance3 || objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                            objRememberedValue8 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda39
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return XunjiAppKt.XunjiApp$lambda$10$0(settings, (Uri) obj2);
                                }
                            };
/* 215 */                   $composer3.updateRememberedValue(objRememberedValue8);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 66 */                final ManagedActivityResultLauncher export = ActivityResultRegistryKt.rememberLauncherForActivityResult(createDocument, (Function1) objRememberedValue8, $composer3, 0);
/* 67 */                ActivityResultContracts.OpenDocument openDocument = new ActivityResultContracts.OpenDocument();
                        ComposerKt.sourceInformationMarkerStart($composer3, 2125981598, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance4 = $composer3.changedInstance(settings);
                        Object objRememberedValue9 = $composer3.rememberedValue();
/* 219 */               if (zChangedInstance4 || objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
                            objRememberedValue9 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda40
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return XunjiAppKt.XunjiApp$lambda$11$0(settings, (Uri) obj2);
                                }
                            };
/* 221 */                   $composer3.updateRememberedValue(objRememberedValue9);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 67 */                ManagedActivityResultLauncher restore2 = ActivityResultRegistryKt.rememberLauncherForActivityResult(openDocument, (Function1) objRememberedValue9, $composer3, 0);
/* 68 */                ActivityResultContracts.OpenDocument openDocument2 = new ActivityResultContracts.OpenDocument();
                        ComposerKt.sourceInformationMarkerStart($composer3, 2125986156, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance5 = $composer3.changedInstance(ankiImport) | $composer3.changedInstance(nav);
                        Object objRememberedValue10 = $composer3.rememberedValue();
/* 225 */               if (zChangedInstance5) {
/* 225 */                   restore = restore2;
                        } else {
                            restore = restore2;
                            if (objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 68 */                    final ManagedActivityResultLauncher ankiPicker = ActivityResultRegistryKt.rememberLauncherForActivityResult(openDocument2, (Function1) objRememberedValue10, $composer3, 0);
/* 69 */                    ankiTypes = new String[]{"application/zip", "application/octet-stream", "application/x-anki", "application/x-anki-apkg", "application/x-anki-package", "application/x-zip-compressed", "*/*"};
/* 70 */                    final boolean root = CollectionsKt.listOf((Object[]) new String[]{"Today", "Decks", "Statistics"}).contains(route2);
/* 71 */                    if (!StringsKt.startsWith$default(route2, "Editor", false, 2, (Object) null) || StringsKt.startsWith$default(route2, "Review", false, 2, (Object) null)) {
                                focused = true;
                            } else {
                                focused = false;
                            }
/* 72 */                    if (XunjiApp$lambda$4(state$delegate).getError() == null || XunjiApp$lambda$5(settingsState$delegate).getInitializationError() != null) {
                                unavailable = true;
                            } else {
                                unavailable = false;
                            }
/* 74 */                    if (Intrinsics.areEqual(route2, "AnkiImport")) {
                                $composer3.startReplaceGroup(2126005702);
                                ComposerKt.sourceInformation($composer3, "73@4874L14,73@4862L26");
                                ComposerKt.sourceInformationMarkerStart($composer3, 2126006074, "CC(remember):XunjiApp.kt#9igjgp");
                                zChanged = $composer3.changed(importState$delegate) | $composer3.changedInstance(ankiImport) | $composer3.changedInstance(nav);
                                objRememberedValue = $composer3.rememberedValue();
/* 231 */                       if (zChanged) {
/* 231 */                           ankiTypes2 = ankiTypes;
                                } else {
                                    ankiTypes2 = ankiTypes;
                                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                    }
                                    ComposerKt.sourceInformationMarkerEnd($composer3);
/* 74 */                            BackHandlerKt.BackHandler(false, (Function0) objRememberedValue, $composer3, 0, 1);
                                }
                                objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda42
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return XunjiAppKt.XunjiApp$lambda$13$0(ankiImport, nav, importState$delegate);
                                    }
                                };
/* 233 */                       $composer3.updateRememberedValue(objRememberedValue);
                                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 74 */                        BackHandlerKt.BackHandler(false, (Function0) objRememberedValue, $composer3, 0, 1);
                            } else {
                                ankiTypes2 = ankiTypes;
                                $composer3.startReplaceGroup(1476842422);
                            }
                            $composer3.endReplaceGroup();
/* 75 */                    ThemeMode themeMode = XunjiApp$lambda$4(state$delegate).getSettings().getThemeMode();
                            final boolean focused2 = focused;
                            container2 = container;
                            final boolean unavailable2 = unavailable;
                            final String[] ankiTypes3 = ankiTypes2;
                            final ManagedActivityResultLauncher restore3 = restore;
/* 218 */                   Function2 function2 = new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda43
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj2, Object obj3) {
                                    return XunjiAppKt.XunjiApp$lambda$14(context, focused2, unavailable2, root, route2, importState$delegate, ankiImport, nav, state$delegate, main, container2, review, settingsState$delegate, settings, export, restore3, ankiPicker, ankiTypes3, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            };
                            $composer2 = $composer3;
                            ThemeKt.XunjiTheme(themeMode, ComposableLambdaKt.rememberComposableLambda(-40945197, true, function2, $composer2, 54), $composer2, 48, 0);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                        objRememberedValue10 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda41
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return XunjiAppKt.XunjiApp$lambda$12$0(ankiImport, nav, (Uri) obj2);
                            }
                        };
/* 227 */               $composer3.updateRememberedValue(objRememberedValue10);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 68 */                final ManagedActivityResultLauncher ankiPicker2 = ActivityResultRegistryKt.rememberLauncherForActivityResult(openDocument2, (Function1) objRememberedValue10, $composer3, 0);
/* 69 */                ankiTypes = new String[]{"application/zip", "application/octet-stream", "application/x-anki", "application/x-anki-apkg", "application/x-anki-package", "application/x-zip-compressed", "*/*"};
/* 70 */                final boolean root2 = CollectionsKt.listOf((Object[]) new String[]{"Today", "Decks", "Statistics"}).contains(route2);
/* 71 */                if (StringsKt.startsWith$default(route2, "Editor", false, 2, (Object) null)) {
                            focused = true;
                        } else {
                            focused = true;
                        }
/* 72 */                if (XunjiApp$lambda$4(state$delegate).getError() == null) {
                            unavailable = true;
                        } else {
                            unavailable = true;
                        }
/* 74 */                if (Intrinsics.areEqual(route2, "AnkiImport")) {
                            $composer3.startReplaceGroup(2126005702);
                            ComposerKt.sourceInformation($composer3, "73@4874L14,73@4862L26");
                            ComposerKt.sourceInformationMarkerStart($composer3, 2126006074, "CC(remember):XunjiApp.kt#9igjgp");
                            zChanged = $composer3.changed(importState$delegate) | $composer3.changedInstance(ankiImport) | $composer3.changedInstance(nav);
                            objRememberedValue = $composer3.rememberedValue();
/* 231 */                   if (zChanged) {
                                ankiTypes2 = ankiTypes;
                                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                }
                                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 74 */                        BackHandlerKt.BackHandler(false, (Function0) objRememberedValue, $composer3, 0, 1);
                            } else {
/* 231 */                       ankiTypes2 = ankiTypes;
                            }
                            objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda42
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return XunjiAppKt.XunjiApp$lambda$13$0(ankiImport, nav, importState$delegate);
                                }
                            };
/* 233 */                   $composer3.updateRememberedValue(objRememberedValue);
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 74 */                    BackHandlerKt.BackHandler(false, (Function0) objRememberedValue, $composer3, 0, 1);
                        } else {
                            ankiTypes2 = ankiTypes;
                            $composer3.startReplaceGroup(1476842422);
                        }
                        $composer3.endReplaceGroup();
/* 75 */                ThemeMode themeMode2 = XunjiApp$lambda$4(state$delegate).getSettings().getThemeMode();
                        final boolean focused3 = focused;
                        container2 = container;
                        final boolean unavailable3 = unavailable;
                        final String[] ankiTypes4 = ankiTypes2;
                        final ManagedActivityResultLauncher restore4 = restore;
/* 218 */               Function2 function3 = new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda43
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiAppKt.XunjiApp$lambda$14(context, focused3, unavailable3, root2, route2, importState$delegate, ankiImport, nav, state$delegate, main, container2, review, settingsState$delegate, settings, export, restore4, ankiPicker2, ankiTypes4, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        };
                        $composer2 = $composer3;
                        ThemeKt.XunjiTheme(themeMode2, ComposableLambdaKt.rememberComposableLambda(-40945197, true, function3, $composer2, 54), $composer2, 48, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 42 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
/* 116 */           ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda34
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiAppKt.XunjiApp$lambda$15(container2, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 44 */        public static final MainViewModel XunjiApp$lambda$0$0$0(AppContainer $container, CreationExtras initializer) {
                    Intrinsics.checkNotNullParameter(initializer, "$this$initializer");
/* 45 */            return new MainViewModel($container.getRepository(), null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 45 */        public static final ReviewViewModel XunjiApp$lambda$1$0$0(AppContainer $container, CreationExtras initializer) {
                    Intrinsics.checkNotNullParameter(initializer, "$this$initializer");
/* 46 */            return new ReviewViewModel($container.getRepository(), $container.getReview(), $container.getScheduler(), SavedStateHandleSupport.createSavedStateHandle(initializer), null, null, null, new XunjiAppKt$XunjiApp$review$1$1$1$1($container.getAnkiPresenter()), 112, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 46 */        public static final SettingsViewModel XunjiApp$lambda$2$0$0(AppContainer $container, final ReviewViewModel $review, final MainViewModel $main, CreationExtras initializer) {
                    Intrinsics.checkNotNullParameter(initializer, "$this$initializer");
/* 47 */            return new SettingsViewModel($container.getRepository(), $container.getBackup(), $container.getFiles(), new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return XunjiAppKt.XunjiApp$lambda$2$0$0$0($review, $main);
                        }
                    });
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 46 */        public static final Unit XunjiApp$lambda$2$0$0$0(ReviewViewModel $review, MainViewModel $main) {
/* 47 */            $review.finish();
                    MainViewModel.refresh$default($main, null, null, 3, null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 48 */        public static final AnkiImportViewModel XunjiApp$lambda$3$0$0(AppContainer $container, ContentResolver $resolver, final MainViewModel $main, CreationExtras initializer) {
                    Intrinsics.checkNotNullParameter(initializer, "$this$initializer");
/* 49 */            return new AnkiImportViewModel($container.getAnkiImport(), new XunjiAppKt$XunjiApp$ankiImport$1$1$1$1($resolver, null), new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda30
                        @Override // kotlin.jvm.functions.Function0
                        public final Object invoke() {
                            return XunjiAppKt.XunjiApp$lambda$3$0$0$0($main);
                        }
                    }, null, 8);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 53 */        public static final Unit XunjiApp$lambda$3$0$0$0(MainViewModel $main) {
/* 54 */            MainViewModel.refresh$default($main, null, null, 3, null);
                    return Unit.INSTANCE;
                }

/* 55 */        private static final MainUiState XunjiApp$lambda$4(State<MainUiState> state) {
/* 236 */           return (MainUiState) state.getValue();
                }

/* 55 */        private static final SettingsUiState XunjiApp$lambda$5(State<SettingsUiState> state) {
/* 236 */           return (SettingsUiState) state.getValue();
                }

/* 56 */        private static final AnkiImportUiState XunjiApp$lambda$6(State<AnkiImportUiState> state) {
/* 237 */           return (AnkiImportUiState) state.getValue();
                }

/* 57 */        private static final NavBackStackEntry XunjiApp$lambda$7(State<NavBackStackEntry> state) {
/* 238 */           return (NavBackStackEntry) state.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 60 */        public static final DisposableEffectResult XunjiApp$lambda$8$0(final LifecycleOwner $owner, final MainViewModel $main, final ReviewViewModel $review, DisposableEffectScope DisposableEffect) {
                    Intrinsics.checkNotNullParameter(DisposableEffect, "$this$DisposableEffect");
/* 61 */            final LifecycleEventObserver observer = new LifecycleEventObserver() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda33
                        @Override // androidx.lifecycle.LifecycleEventObserver
                        public final void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                            XunjiAppKt.XunjiApp$lambda$8$0$0($main, $review, lifecycleOwner, event);
                        }
                    };
/* 62 */            $owner.getLifecycle().addObserver(observer);
/* 239 */           return new DisposableEffectResult() { // from class: com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$lambda$8$0$$inlined$onDispose$1
                        @Override // androidx.compose.runtime.DisposableEffectResult
/* 67 */                public void dispose() {
/* 70 */                    getLifecycle().removeObserver(observer);
                        }
                    };
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 60 */        public static final void XunjiApp$lambda$8$0$0(MainViewModel $main, ReviewViewModel $review, LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                    boolean z;
                    Intrinsics.checkNotNullParameter(lifecycleOwner, "<unused var>");
                    Intrinsics.checkNotNullParameter(event, "event");
                    switch (WhenMappings.$EnumSwitchMapping$0[event.ordinal()]) {
                        case 1:
                            MainViewModel.refresh$default($main, null, null, 3, null);
                            z = true;
                            break;
                        case 2:
                            z = false;
                            break;
                        default:
                            return;
                    }
                    $review.setForeground(z);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 65 */        public static final Unit XunjiApp$lambda$10$0(SettingsViewModel $settings, Uri uri) {
/* 66 */            if (uri != null) {
                        $settings.export(uri);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 66 */        public static final Unit XunjiApp$lambda$11$0(SettingsViewModel $settings, Uri uri) {
/* 67 */            if (uri != null) {
                        $settings.prepareRestore(uri);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 67 */        public static final Unit XunjiApp$lambda$12$0(AnkiImportViewModel $ankiImport, NavHostController $nav, Uri uri) {
/* 68 */            if (uri != null) {
                        $ankiImport.start(uri);
                        $nav.navigate("AnkiImport", new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return XunjiAppKt.XunjiApp$lambda$12$0$0((NavOptionsBuilder) obj);
                            }
                        });
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 67 */        public static final Unit XunjiApp$lambda$12$0$0(NavOptionsBuilder navigate) {
                    Intrinsics.checkNotNullParameter(navigate, "$this$navigate");
/* 68 */            navigate.setLaunchSingleTop(true);
                    return Unit.INSTANCE;
                }

/* 72 */        private static final void XunjiApp$exitImport(AnkiImportViewModel ankiImport, NavHostController nav, State<AnkiImportUiState> state) {
/* 73 */            boolean busy = XunjiApp$lambda$6(state).getBusy();
                    ankiImport.cancel();
                    if (busy) {
                        return;
                    }
                    nav.popBackStack();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 73 */        public static final Unit XunjiApp$lambda$13$0(AnkiImportViewModel $ankiImport, NavHostController $nav, State $importState$delegate) {
/* 74 */            XunjiApp$exitImport($ankiImport, $nav, $importState$delegate);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 75 */        public static final Unit XunjiApp$lambda$14(final Context $context, final boolean $focused, final boolean $unavailable, final boolean $root, final String $route, final State $importState$delegate, final AnkiImportViewModel $ankiImport, final NavHostController $nav, final State $state$delegate, final MainViewModel $main, final AppContainer $container, final ReviewViewModel $review, final State $settingsState$delegate, final SettingsViewModel $settings, final ManagedActivityResultLauncher $export, final ManagedActivityResultLauncher $restore, final ManagedActivityResultLauncher $ankiPicker, final String[] $ankiTypes, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C75@4954L11,76@4998L187,76@4987L198,77@5226L11,77@5256L689,81@5956L635,83@6593L2947,77@5188L4352:XunjiApp.kt#thuf8k");
                    if (!$composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
/* 75 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-40945197, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous> (XunjiApp.kt:75)");
                        }
                        final boolean dark = Color.m5666getRedimpl(MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getBackground()) < 0.3f;
/* 77 */                ComposerKt.sourceInformationMarkerStart($composer, -693626194, "CC(remember):XunjiApp.kt#9igjgp");
                        boolean zChangedInstance = $composer.changedInstance($context) | $composer.changed(dark);
/* 244 */               Object objRememberedValue = $composer.rememberedValue();
/* 245 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 77 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda44
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return XunjiAppKt.XunjiApp$lambda$14$0$0($context, dark);
                                }
                            };
/* 247 */                   $composer.updateRememberedValue(obj);
/* 248 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 77 */                EffectsKt.SideEffect((Function0) objRememberedValue, $composer, 0);
/* 78 */                ScaffoldKt.m3201ScaffoldTvnljyQ(null, ComposableLambdaKt.rememberComposableLambda(1165226903, true, new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda51
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiAppKt.XunjiApp$lambda$14$1($focused, $unavailable, $root, $route, $importState$delegate, $ankiImport, $nav, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), ComposableLambdaKt.rememberComposableLambda(-282779944, true, new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda52
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiAppKt.XunjiApp$lambda$14$2($root, $unavailable, $route, $nav, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), null, null, 0, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getBackground(), 0L, null, ComposableLambdaKt.rememberComposableLambda(-438975454, true, new Function3() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda53
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                return XunjiAppKt.XunjiApp$lambda$14$3($unavailable, $nav, $focused, $state$delegate, $main, $container, $review, $context, $settingsState$delegate, $settings, $export, $restore, $ankiPicker, $ankiTypes, $importState$delegate, $ankiImport, (PaddingValues) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }, $composer, 54), $composer, 805306800, 441);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 115 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 76 */        public static final Unit XunjiApp$lambda$14$0$0(Context $context, boolean $dark) {
                    Window window;
/* 77 */            Activity activity = activity($context);
                    if (activity != null && (window = activity.getWindow()) != null) {
/* 77 */                WindowInsetsControllerCompat insetsController = WindowCompat.getInsetsController(window, window.getDecorView());
/* 77 */                insetsController.setAppearanceLightStatusBars(!$dark);
                        insetsController.setAppearanceLightNavigationBars(!$dark);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:30:0x0185  */
                /* JADX WARN: Code duplicated, block: B:31:0x021b  */
                /* JADX WARN: Code duplicated, block: B:33:0x0254  */
                /* JADX WARN: Code duplicated, block: B:37:0x0260  */
                /* JADX WARN: Code duplicated, block: B:41:0x0290  */
                /* JADX WARN: Code duplicated, block: B:42:0x0293  */
                /* JADX WARN: Code duplicated, block: B:44:0x0299  */
                /* JADX WARN: Code duplicated, block: B:45:0x029c  */
                /* JADX WARN: Code duplicated, block: B:59:0x0346  */
/* 77 */        public static final Unit XunjiApp$lambda$14$1(boolean $focused, boolean $unavailable, boolean $root, final String $route, final State $importState$delegate, final AnkiImportViewModel $ankiImport, final NavHostController $nav, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    int i;
                    RowScope rowScope;
                    Composer composer;
                    boolean zChanged;
                    Object objRememberedValue;
                    RowScope rowScope2;
                    String str;
                    ComposerKt.sourceInformation($composer, "C:XunjiApp.kt#thuf8k");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1165226903, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous> (XunjiApp.kt:77)");
                        }
/* 78 */                if ($focused || $unavailable) {
                            $composer.startReplaceGroup(1343766059);
                        } else {
                            $composer.startReplaceGroup(-1203408856);
                            ComposerKt.sourceInformation($composer, "77@5286L657");
/* 78 */                    Modifier modifierM841paddingVpY3zN4 = PaddingKt.m841paddingVpY3zN4(WindowInsetsPadding_androidKt.statusBarsPadding(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null)), Dp.m8404constructorimpl(10), Dp.m8404constructorimpl(6));
                            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 252 */                   ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 257 */                   MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer, ((384 >> 3) & 14) | ((384 >> 3) & 112));
/* 262 */                   ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 263 */                   int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 264 */                   CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 265 */                   Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM841paddingVpY3zN4);
/* 267 */                   Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 261 */                   int i2 = ((((384 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 269 */                   if (!($composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 270 */                   $composer.startReusableNode();
/* 271 */                   if ($composer.getInserting()) {
/* 272 */                       function0 = constructor;
                                $composer.createNode(function0);
                            } else {
/* 274 */                       function0 = constructor;
                                $composer.useNode();
                            }
/* 276 */                   Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 277 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 278 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 279 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 281 */                   if (composerM4979constructorimpl.getInserting()) {
                                i = iHashCode;
                            } else {
                                i = iHashCode;
/* 280 */                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(i))) {
                                }
/* 286 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 288 */                       int i3 = (i2 >> 6) & 14;
/* 259 */                       ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                int i4 = ((384 >> 6) & 112) | 6;
                                rowScope = RowScopeInstance.INSTANCE;
                                composer = $composer;
                                ComposerKt.sourceInformationMarkerStart(composer, -2011689609, "C:XunjiApp.kt#thuf8k");
                                if ($root) {
                                    composer.startReplaceGroup(-2011692524);
                                    ComposerKt.sourceInformation(composer, "78@5416L29,78@5446L6,78@5453L29,78@5513L10,78@5483L81");
/* 268 */                           SpacerKt.Spacer(SizeKt.m897width3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(12)), composer, 6);
                                    XunjiComponentsKt.Mark(null, composer, 0, 1);
/* 79 */                            SpacerKt.Spacer(SizeKt.m897width3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(12)), composer, 6);
                                    TextKt.m3584TextNvy7gAk("循记", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 6, 0, 131068);
                                    composer.endReplaceGroup();
                                } else {
                                    composer.startReplaceGroup(-2011529898);
                                    ComposerKt.sourceInformation(composer, "79@5600L61,79@5577L97,79@5768L10,79@5675L144");
                                    ComposerKt.sourceInformationMarkerStart(composer, 1320585875, "CC(remember):XunjiApp.kt#9igjgp");
                                    zChanged = composer.changed($route) | composer.changed($importState$delegate) | composer.changedInstance($ankiImport) | composer.changedInstance($nav);
                                    objRememberedValue = composer.rememberedValue();
/* 291 */                           if (zChanged) {
/* 291 */                               rowScope2 = rowScope;
                                    } else {
                                        rowScope2 = rowScope;
                                        if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                        }
/* 290 */                               ComposerKt.sourceInformationMarkerEnd(composer);
/* 290 */                               XunjiComponentsKt.IconAction("back", "返回", (Function0) objRememberedValue, "page-back", false, composer, 3126, 16);
/* 290 */                               composer = composer;
                                        if (Intrinsics.areEqual($route, "Settings")) {
                                            str = "设置";
                                        } else if (Intrinsics.areEqual($route, "AnkiImport")) {
                                            str = "导入 Anki 牌组";
                                        } else {
                                            str = "牌组";
                                        }
                                        TextKt.m3584TextNvy7gAk(str, RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 0, 0, 131068);
                                        composer.endReplaceGroup();
                                    }
                                    objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda55
                                        @Override // kotlin.jvm.functions.Function0
                                        public final Object invoke() {
                                            return XunjiAppKt.XunjiApp$lambda$14$1$0$0$0($route, $nav, $ankiImport, $importState$delegate);
                                        }
                                    };
/* 293 */                           composer.updateRememberedValue(objRememberedValue);
/* 290 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 290 */                           XunjiComponentsKt.IconAction("back", "返回", (Function0) objRememberedValue, "page-back", false, composer, 3126, 16);
/* 290 */                           composer = composer;
                                    if (Intrinsics.areEqual($route, "Settings")) {
                                        str = "设置";
                                    } else if (Intrinsics.areEqual($route, "AnkiImport")) {
                                        str = "导入 Anki 牌组";
                                    } else {
                                        str = "牌组";
                                    }
                                    TextKt.m3584TextNvy7gAk(str, RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 0, 0, 131068);
                                    composer.endReplaceGroup();
                                }
/* 81 */                        if (!Intrinsics.areEqual($route, "Settings") || Intrinsics.areEqual($route, "AnkiImport")) {
                                    composer.startReplaceGroup(-2017068916);
                                } else {
                                    composer.startReplaceGroup(1320594492);
                                    ComposerKt.sourceInformation(composer, "80@5896L26,80@5869L70");
                                    ComposerKt.sourceInformationMarkerStart(composer, 1320595312, "CC(remember):XunjiApp.kt#9igjgp");
                                    boolean zChangedInstance = composer.changedInstance($nav);
                                    Composer composer2 = composer;
/* 296 */                           Object objRememberedValue2 = composer2.rememberedValue();
/* 297 */                           if (zChangedInstance || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 81 */                                Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda1
                                            @Override // kotlin.jvm.functions.Function0
                                            public final Object invoke() {
                                                return XunjiAppKt.XunjiApp$lambda$14$1$0$1$0($nav);
                                            }
                                        };
/* 299 */                               composer2.updateRememberedValue(obj);
/* 300 */                               objRememberedValue2 = obj;
                                    }
                                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 81 */                            XunjiComponentsKt.IconAction("settings", "设置", (Function0) objRememberedValue2, "open-settings", false, composer, 3126, 16);
                                }
                                composer.endReplaceGroup();
/* 79 */                        ComposerKt.sourceInformationMarkerEnd(composer);
/* 259 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 302 */                       $composer.endNode();
/* 268 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 262 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 252 */                       ComposerKt.sourceInformationMarkerEnd($composer);
                            }
/* 280 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(i));
/* 283 */                   composerM4979constructorimpl.apply(Integer.valueOf(i), setCompositeKeyHash);
/* 286 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 288 */                   int i5 = (i2 >> 6) & 14;
/* 259 */                   ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            int i6 = ((384 >> 6) & 112) | 6;
                            rowScope = RowScopeInstance.INSTANCE;
                            composer = $composer;
                            ComposerKt.sourceInformationMarkerStart(composer, -2011689609, "C:XunjiApp.kt#thuf8k");
                            if ($root) {
                                composer.startReplaceGroup(-2011692524);
                                ComposerKt.sourceInformation(composer, "78@5416L29,78@5446L6,78@5453L29,78@5513L10,78@5483L81");
/* 268 */                       SpacerKt.Spacer(SizeKt.m897width3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(12)), composer, 6);
                                XunjiComponentsKt.Mark(null, composer, 0, 1);
/* 79 */                        SpacerKt.Spacer(SizeKt.m897width3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(12)), composer, 6);
                                TextKt.m3584TextNvy7gAk("循记", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 6, 0, 131068);
                                composer.endReplaceGroup();
                            } else {
                                composer.startReplaceGroup(-2011529898);
                                ComposerKt.sourceInformation(composer, "79@5600L61,79@5577L97,79@5768L10,79@5675L144");
                                ComposerKt.sourceInformationMarkerStart(composer, 1320585875, "CC(remember):XunjiApp.kt#9igjgp");
                                zChanged = composer.changed($route) | composer.changed($importState$delegate) | composer.changedInstance($ankiImport) | composer.changedInstance($nav);
                                objRememberedValue = composer.rememberedValue();
/* 291 */                       if (zChanged) {
                                    rowScope2 = rowScope;
                                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                    }
/* 290 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 290 */                           XunjiComponentsKt.IconAction("back", "返回", (Function0) objRememberedValue, "page-back", false, composer, 3126, 16);
/* 290 */                           composer = composer;
                                    if (Intrinsics.areEqual($route, "Settings")) {
                                        str = "设置";
                                    } else if (Intrinsics.areEqual($route, "AnkiImport")) {
                                        str = "导入 Anki 牌组";
                                    } else {
                                        str = "牌组";
                                    }
                                    TextKt.m3584TextNvy7gAk(str, RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 0, 0, 131068);
                                    composer.endReplaceGroup();
                                } else {
/* 291 */                           rowScope2 = rowScope;
                                }
                                objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda55
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return XunjiAppKt.XunjiApp$lambda$14$1$0$0$0($route, $nav, $ankiImport, $importState$delegate);
                                    }
                                };
/* 293 */                       composer.updateRememberedValue(objRememberedValue);
/* 290 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 290 */                       XunjiComponentsKt.IconAction("back", "返回", (Function0) objRememberedValue, "page-back", false, composer, 3126, 16);
/* 290 */                       composer = composer;
                                if (Intrinsics.areEqual($route, "Settings")) {
                                    str = "设置";
                                } else if (Intrinsics.areEqual($route, "AnkiImport")) {
                                    str = "导入 Anki 牌组";
                                } else {
                                    str = "牌组";
                                }
                                TextKt.m3584TextNvy7gAk(str, RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 0, 0, 131068);
                                composer.endReplaceGroup();
                            }
/* 81 */                    if (Intrinsics.areEqual($route, "Settings")) {
                                composer.startReplaceGroup(-2017068916);
                            } else {
                                composer.startReplaceGroup(-2017068916);
                            }
                            composer.endReplaceGroup();
/* 79 */                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 259 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 302 */                   $composer.endNode();
/* 268 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 262 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 252 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                        }
                        $composer.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 82 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 79 */        public static final Unit XunjiApp$lambda$14$1$0$0$0(String $route, NavHostController $nav, AnkiImportViewModel $ankiImport, State $importState$delegate) {
/* 80 */            if (Intrinsics.areEqual($route, "AnkiImport")) {
                        XunjiApp$exitImport($ankiImport, $nav, $importState$delegate);
                    } else {
                        $nav.popBackStack();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 80 */        public static final Unit XunjiApp$lambda$14$1$0$1$0(NavHostController $nav) {
/* 81 */            NavController.navigate$default((NavController) $nav, "Settings", (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 81 */        public static final Unit XunjiApp$lambda$14$2(boolean $root, boolean $unavailable, final String $route, final NavHostController $nav, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C:XunjiApp.kt#thuf8k");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-282779944, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous> (XunjiApp.kt:81)");
                        }
/* 82 */                if (!$root || $unavailable) {
                            $composer.startReplaceGroup(-1872353590);
                        } else {
                            $composer.startReplaceGroup(-1168585097);
                            ComposerKt.sourceInformation($composer, "81@6025L11,81@6069L520,81@5982L607");
/* 82 */                    NavigationBarKt.m3020NavigationBarHsRjFd4(null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getBackground(), 0L, Dp.m8404constructorimpl(0), null, ComposableLambdaKt.rememberComposableLambda(-65279334, true, new Function3() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda26
                                @Override // kotlin.jvm.functions.Function3
                                public final Object invoke(Object obj, Object obj2, Object obj3) {
                                    return XunjiAppKt.XunjiApp$lambda$14$2$0($route, $nav, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            }, $composer, 54), $composer, 199680, 21);
                        }
                        $composer.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 84 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 82 */        public static final Unit XunjiApp$lambda$14$2$0(final String $route, final NavHostController $nav, RowScope NavigationBar, Composer $composer, int $changed) {
                    Composer composer = $composer;
                    Intrinsics.checkNotNullParameter(NavigationBar, "$this$NavigationBar");
                    ComposerKt.sourceInformation(composer, "C*82@6553L11,82@6517L65,82@6264L31,82@6301L123,82@6431L13,82@6210L373:XunjiApp.kt#thuf8k");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= composer.changed(NavigationBar) ? 4 : 2;
                    }
                    boolean z = true;
                    if (composer.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-65279334, $dirty, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:82)");
                        }
                        for (Triple triple : CollectionsKt.listOf((Object[]) new Triple[]{new Triple("Today", "今日", "today"), new Triple("Decks", "牌组", "decks"), new Triple("Statistics", "记录", "stats")})) {
                            final String str = (String) triple.component1();
                            final String str2 = (String) triple.component2();
                            final String str3 = (String) triple.component3();
/* 83 */                    boolean zAreEqual = Intrinsics.areEqual($route, str);
                            Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "nav-" + str3);
                            int $dirty2 = $dirty;
                            NavigationBarItemColors navigationBarItemColorsM3015colors69fazGs = NavigationBarItemDefaults.INSTANCE.m3015colors69fazGs(0L, 0L, MaterialTheme.INSTANCE.getColorScheme(composer, MaterialTheme.$stable).getPrimaryContainer(), 0L, 0L, 0L, 0L, $composer, NavigationBarItemDefaults.$stable << 21, 123);
                            ComposerKt.sourceInformationMarkerStart($composer, -2014741930, "CC(remember):XunjiApp.kt#9igjgp");
                            boolean zChangedInstance = $composer.changedInstance($nav) | $composer.changed(str);
/* 308 */                   Object objRememberedValue = $composer.rememberedValue();
/* 309 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 83 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda13
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return XunjiAppKt.XunjiApp$lambda$14$2$0$0$0$0($nav, str);
                                    }
                                };
/* 311 */                       $composer.updateRememberedValue(obj);
/* 312 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 83 */                    NavigationBarKt.NavigationBarItem(NavigationBar, zAreEqual, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(1824777970, true, new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda14
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj2, Object obj3) {
                                    return XunjiAppKt.XunjiApp$lambda$14$2$0$0$1(str3, $route, str, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            }, $composer, 54), modifierTestTag, false, ComposableLambdaKt.rememberComposableLambda(-738602187, true, new Function2() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda15
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj2, Object obj3) {
                                    return XunjiAppKt.XunjiApp$lambda$14$2$0$0$2(str2, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            }, $composer, 54), false, navigationBarItemColorsM3015colors69fazGs, null, $composer, ($dirty2 & 14) | 1575936, 336);
/* 307 */                   composer = $composer;
                            $dirty = $dirty2;
                            z = true;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 84 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 82 */        public static final Unit XunjiApp$lambda$14$2$0$0$0$0(NavHostController $nav, String $destination) {
/* 83 */            navigateRoot($nav, $destination);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 82 */        public static final Unit XunjiApp$lambda$14$2$0$0$1(String $icon, String $route, String $destination, Composer $composer, int $changed) {
                    long onSurfaceVariant;
                    ComposerKt.sourceInformation($composer, "C82@6302L121:XunjiApp.kt#thuf8k");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1824777970, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:82)");
                        }
/* 83 */                if (Intrinsics.areEqual($route, $destination)) {
                            $composer.startReplaceGroup(1264974521);
                            ComposerKt.sourceInformation($composer, "82@6355L11");
                            onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary();
                        } else {
                            $composer.startReplaceGroup(1264975778);
                            ComposerKt.sourceInformation($composer, "82@6394L11");
                            onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurfaceVariant();
                        }
                        $composer.endReplaceGroup();
                        XunjiComponentsKt.m8967GlyphFNF3uiM($icon, null, onSurfaceVariant, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 82 */        public static final Unit XunjiApp$lambda$14$2$0$0$2(String $label, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C82@6432L11:XunjiApp.kt#thuf8k");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-738602187, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:82)");
                        }
/* 83 */                TextKt.m3584TextNvy7gAk($label, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 84 */        public static final Unit XunjiApp$lambda$14$3(boolean $unavailable, final NavHostController $nav, boolean $focused, final State $state$delegate, final MainViewModel $main, final AppContainer $container, final ReviewViewModel $review, final Context $context, final State $settingsState$delegate, final SettingsViewModel $settings, final ManagedActivityResultLauncher $export, final ManagedActivityResultLauncher $restore, final ManagedActivityResultLauncher $ankiPicker, final String[] $ankiTypes, final State $importState$delegate, final AnkiImportViewModel $ankiImport, PaddingValues padding, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    int i;
                    String initializationError;
                    boolean zChangedInstance;
                    Object objRememberedValue;
                    Intrinsics.checkNotNullParameter(padding, "padding");
                    ComposerKt.sourceInformation($composer, "CN(padding):XunjiApp.kt#thuf8k");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer.changed(padding) ? 4 : 2;
                    }
                    if ($composer.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-438975454, $dirty, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous> (XunjiApp.kt:84)");
                        }
                        if ($unavailable) {
                            $composer.startReplaceGroup(657705020);
                            ComposerKt.sourceInformation($composer, "85@6630L249");
/* 86 */                    Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(PaddingKt.padding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), padding), Dp.m8404constructorimpl(22));
                            Alignment center = Alignment.INSTANCE.getCenter();
/* 316 */                   ComposerKt.sourceInformationMarkerStart($composer, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 320 */                   MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
/* 325 */                   ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 326 */                   int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 327 */                   CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
                            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 330 */                   Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 324 */                   int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 332 */                   if (!($composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 333 */                   $composer.startReusableNode();
/* 334 */                   if ($composer.getInserting()) {
/* 335 */                       function0 = constructor;
                                $composer.createNode(function0);
                            } else {
/* 337 */                       function0 = constructor;
                                $composer.useNode();
                            }
/* 339 */                   Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 340 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 341 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 342 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 344 */                   if (composerM4979constructorimpl.getInserting()) {
                                i = 48;
                            } else {
                                i = 48;
/* 328 */                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                }
/* 349 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 351 */                       int i3 = (i2 >> 6) & 14;
/* 322 */                       ComposerKt.sourceInformationMarkerStart($composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                                BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                                int i4 = ((i >> 6) & 112) | 6;
                                ComposerKt.sourceInformationMarkerStart($composer, -54225324, "C86@6819L53,86@6731L142:XunjiApp.kt#thuf8k");
                                initializationError = XunjiApp$lambda$5($settingsState$delegate).getInitializationError();
                                if (initializationError == null && (initializationError = XunjiApp$lambda$4($state$delegate).getError()) == null) {
                                    initializationError = "";
                                }
                                String str = initializationError;
/* 85 */                        ComposerKt.sourceInformationMarkerStart($composer, -971577802, "CC(remember):XunjiApp.kt#9igjgp");
                                zChangedInstance = $composer.changedInstance($main) | $composer.changedInstance($settings);
                                objRememberedValue = $composer.rememberedValue();
/* 353 */                       if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                    objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda47
                                        @Override // kotlin.jvm.functions.Function0
                                        public final Object invoke() {
                                            return XunjiAppKt.XunjiApp$lambda$14$3$0$0$0($main, $settings);
                                        }
                                    };
/* 355 */                           $composer.updateRememberedValue(objRememberedValue);
                                }
                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 87 */                        XunjiComponentsKt.EmptyState("暂时无法读取数据", str, "重新读取", (Function0) objRememberedValue, $composer, 390, 0);
                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 322 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 358 */                       $composer.endNode();
/* 331 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 325 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 316 */                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 85 */                        $composer.endReplaceGroup();
                            }
/* 343 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 346 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 349 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 351 */                   int i5 = (i2 >> 6) & 14;
/* 322 */                   ComposerKt.sourceInformationMarkerStart($composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                            int i6 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -54225324, "C86@6819L53,86@6731L142:XunjiApp.kt#thuf8k");
                            initializationError = XunjiApp$lambda$5($settingsState$delegate).getInitializationError();
                            if (initializationError == null) {
                                initializationError = "";
                            }
                            String str2 = initializationError;
/* 85 */                    ComposerKt.sourceInformationMarkerStart($composer, -971577802, "CC(remember):XunjiApp.kt#9igjgp");
                            zChangedInstance = $composer.changedInstance($main) | $composer.changedInstance($settings);
                            objRememberedValue = $composer.rememberedValue();
/* 353 */                   if (!zChangedInstance) {
                            }
                            objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda47
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return XunjiAppKt.XunjiApp$lambda$14$3$0$0$0($main, $settings);
                                }
                            };
/* 355 */                   $composer.updateRememberedValue(objRememberedValue);
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 87 */                    XunjiComponentsKt.EmptyState("暂时无法读取数据", str2, "重新读取", (Function0) objRememberedValue, $composer, 390, 0);
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 322 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 358 */                   $composer.endNode();
/* 331 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 325 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 316 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 85 */                    $composer.endReplaceGroup();
                        } else {
                            $composer.startReplaceGroup(-948604136);
                            ComposerKt.sourceInformation($composer, "88@7062L20,88@7098L21,88@7121L2415,88@6890L2646");
                            Modifier modifierPadding = PaddingKt.padding(Modifier.INSTANCE, padding);
                            Modifier.Companion companionNavigationBarsPadding = Modifier.INSTANCE;
                            if ($focused) {
                                companionNavigationBarsPadding = WindowInsetsPadding_androidKt.navigationBarsPadding(WindowInsetsPadding_androidKt.statusBarsPadding(companionNavigationBarsPadding));
                            }
                            Modifier modifierThen = modifierPadding.then(companionNavigationBarsPadding);
/* 85 */                    ComposerKt.sourceInformationMarkerStart($composer, -948601258, "CC(remember):XunjiApp.kt#9igjgp");
/* 362 */                   Object objRememberedValue2 = $composer.rememberedValue();
/* 363 */                   if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                Object obj = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda48
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj2) {
                                        return XunjiAppKt.XunjiApp$lambda$14$3$1$0((AnimatedContentTransitionScope) obj2);
                                    }
                                };
/* 365 */                       $composer.updateRememberedValue(obj);
/* 366 */                       objRememberedValue2 = obj;
                            }
/* 89 */                    Function1 function1 = (Function1) objRememberedValue2;
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 85 */                    ComposerKt.sourceInformationMarkerStart($composer, -948600105, "CC(remember):XunjiApp.kt#9igjgp");
/* 362 */                   Object objRememberedValue3 = $composer.rememberedValue();
/* 363 */                   if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                                Object obj2 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda49
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj3) {
                                        return XunjiAppKt.XunjiApp$lambda$14$3$2$0((AnimatedContentTransitionScope) obj3);
                                    }
                                };
/* 365 */                       $composer.updateRememberedValue(obj2);
/* 366 */                       objRememberedValue3 = obj2;
                            }
/* 89 */                    Function1 function2 = (Function1) objRememberedValue3;
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 85 */                    ComposerKt.sourceInformationMarkerStart($composer, -948596975, "CC(remember):XunjiApp.kt#9igjgp");
                            boolean zChanged = $composer.changed($state$delegate) | $composer.changedInstance($nav) | $composer.changedInstance($main) | $composer.changedInstance($container) | $composer.changedInstance($review) | $composer.changedInstance($context) | $composer.changed($settingsState$delegate) | $composer.changedInstance($settings) | $composer.changedInstance($export) | $composer.changedInstance($restore) | $composer.changedInstance($ankiPicker) | $composer.changedInstance($ankiTypes) | $composer.changed($importState$delegate) | $composer.changedInstance($ankiImport);
/* 362 */                   Object objRememberedValue4 = $composer.rememberedValue();
/* 363 */                   if (zChanged || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
/* 89 */                        Object obj3 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda50
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj4) {
                                        return XunjiAppKt.XunjiApp$lambda$14$3$3$0($nav, $state$delegate, $main, $container, $review, $context, $settings, $export, $restore, $ankiPicker, $ankiTypes, $settingsState$delegate, $ankiImport, $importState$delegate, (NavGraphBuilder) obj4);
                                    }
                                };
/* 365 */                       $composer.updateRememberedValue(obj3);
/* 366 */                       objRememberedValue4 = obj3;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 89 */                    NavHostKt.NavHost($nav, "Today", modifierThen, null, null, function1, function2, null, null, null, (Function1) objRememberedValue4, $composer, 1769520, 0, 920);
                            $composer.endReplaceGroup();
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 114 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 86 */        public static final Unit XunjiApp$lambda$14$3$0$0$0(MainViewModel $main, SettingsViewModel $settings) {
/* 87 */            $main.retryObservation();
                    $settings.retryObservation();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 88 */        public static final EnterTransition XunjiApp$lambda$14$3$1$0(AnimatedContentTransitionScope NavHost) {
                    Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
/* 89 */            return EnterExitTransitionKt.fadeIn$default(AnimationSpecKt.tween$default(200, 0, null, 6, null), 0.0f, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 88 */        public static final ExitTransition XunjiApp$lambda$14$3$2$0(AnimatedContentTransitionScope NavHost) {
                    Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
/* 89 */            return EnterExitTransitionKt.fadeOut$default(AnimationSpecKt.tween$default(180, 0, null, 6, null), 0.0f, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final Unit XunjiApp$lambda$14$3$3$0(final NavHostController $nav, final State $state$delegate, final MainViewModel $main, final AppContainer $container, final ReviewViewModel $review, final Context $context, final SettingsViewModel $settings, final ManagedActivityResultLauncher $export, final ManagedActivityResultLauncher $restore, final ManagedActivityResultLauncher $ankiPicker, final String[] $ankiTypes, final State $settingsState$delegate, final AnkiImportViewModel $ankiImport, final State $importState$delegate, NavGraphBuilder NavHost) {
                    Intrinsics.checkNotNullParameter(NavHost, "$this$NavHost");
/* 90 */            NavGraphBuilderKt.composable$default(NavHost, "Today", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(1618316091, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda16
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$0($nav, $state$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 91 */            NavGraphBuilderKt.composable$default(NavHost, "Decks", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(587860644, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$1($main, $nav, $state$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 92 */            NavGraphBuilderKt.composable$default(NavHost, "Statistics", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(837961923, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda18
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$2($state$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 93 */            NavGraphBuilderKt.composable$default(NavHost, "DeckDetail/{deckId}", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(1088063202, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda19
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$3($main, $nav, $state$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 94 */            NavGraphBuilderKt.composable$default(NavHost, "Editor/{deckId}?cardId={cardId}", CollectionsKt.listOf(NamedNavArgumentKt.navArgument("cardId", new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda20
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$4((NavArgumentBuilder) obj);
                        }
                    })), (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(1338164481, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda21
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$5($container, $nav, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 252, (Object) null);
/* 100 */           NavGraphBuilderKt.composable$default(NavHost, "Review/{deckId}", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(1588265760, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda23
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$6($review, $context, $nav, $container, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 109 */           NavGraphBuilderKt.composable$default(NavHost, "Settings", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(1838367039, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda24
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$7($settings, $export, $restore, $ankiPicker, $ankiTypes, $settingsState$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 110 */           NavGraphBuilderKt.composable$default(NavHost, "AnkiImport", (List) null, (List) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, (Function1) null, ComposableLambdaKt.composableLambdaInstance(2088468318, true, new Function4() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda25
                        @Override // kotlin.jvm.functions.Function4
                        public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                            return XunjiAppKt.XunjiApp$lambda$14$3$3$0$8($ankiImport, $ankiPicker, $ankiTypes, $nav, $importState$delegate, (AnimatedContentScope) obj, (NavBackStackEntry) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                        }
                    }), 254, (Object) null);
/* 113 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final Unit XunjiApp$lambda$14$3$3$0$0(final NavHostController $nav, State $state$delegate, AnimatedContentScope composable, NavBackStackEntry it, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(it, "it");
                    ComposerKt.sourceInformation($composer, "CN(it)89@7167L28,89@7196L27,89@7149L75:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(1618316091, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:89)");
                    }
/* 90 */            MainUiState mainUiStateXunjiApp$lambda$4 = XunjiApp$lambda$4($state$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, 423602967, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance = $composer.changedInstance($nav);
/* 368 */           Object objRememberedValue = $composer.rememberedValue();
/* 369 */           if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 90 */                Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$0$0$0($nav);
                            }
                        };
/* 371 */               $composer.updateRememberedValue(obj);
/* 372 */               objRememberedValue = obj;
                    }
/* 90 */            Function0 function0 = (Function0) objRememberedValue;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 423603894, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance2 = $composer.changedInstance($nav);
/* 368 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 369 */           if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 90 */                Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda7
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$0$1$0($nav);
                            }
                        };
/* 371 */               $composer.updateRememberedValue(obj2);
/* 372 */               objRememberedValue2 = obj2;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 90 */            TodayScreenKt.TodayScreen(mainUiStateXunjiApp$lambda$4, function0, (Function0) objRememberedValue2, $composer, MainUiState.$stable);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final Unit XunjiApp$lambda$14$3$3$0$0$0$0(NavHostController $nav) {
/* 90 */            NavController.navigate$default((NavController) $nav, "Review/all", (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final Unit XunjiApp$lambda$14$3$3$0$0$1$0(NavHostController $nav) {
/* 90 */            navigateRoot($nav, "Decks");
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 90 */        public static final Unit XunjiApp$lambda$14$3$3$0$1(MainViewModel $main, final NavHostController $nav, State $state$delegate, AnimatedContentScope composable, NavBackStackEntry it, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(it, "it");
                    ComposerKt.sourceInformation($composer, "CN(it)90@7277L32,90@7253L56:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(587860644, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:90)");
                    }
/* 91 */            MainUiState mainUiStateXunjiApp$lambda$4 = XunjiApp$lambda$4($state$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, -2001603324, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance = $composer.changedInstance($nav);
/* 374 */           Object objRememberedValue = $composer.rememberedValue();
/* 375 */           if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 91 */                Object obj = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda27
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$1$0$0($nav, (String) obj2);
                            }
                        };
/* 377 */               $composer.updateRememberedValue(obj);
/* 378 */               objRememberedValue = obj;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 91 */            DecksScreenKt.DecksScreen(mainUiStateXunjiApp$lambda$4, $main, (Function1) objRememberedValue, $composer, MainUiState.$stable | (MainViewModel.$stable << 3));
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 90 */        public static final Unit XunjiApp$lambda$14$3$3$0$1$0$0(NavHostController $nav, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 91 */            NavController.navigate$default((NavController) $nav, "DeckDetail/" + it, (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 91 */        public static final Unit XunjiApp$lambda$14$3$3$0$2(State $state$delegate, AnimatedContentScope composable, NavBackStackEntry it, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(it, "it");
                    ComposerKt.sourceInformation($composer, "CN(it)91@7343L23:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(837961923, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:91)");
                    }
/* 92 */            StatisticsScreenKt.StatisticsScreen(XunjiApp$lambda$4($state$delegate), $composer, MainUiState.$stable);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 92 */        public static final Unit XunjiApp$lambda$14$3$3$0$3(MainViewModel $main, final NavHostController $nav, State $state$delegate, AnimatedContentScope composable, NavBackStackEntry backStack, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(backStack, "backStack");
                    ComposerKt.sourceInformation($composer, "CN(backStack)92@7502L72,92@7575L28,92@7471L133:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(1088063202, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:92)");
                    }
/* 93 */            Bundle arguments = backStack.getArguments();
                    Intrinsics.checkNotNull(arguments);
                    final String id = arguments.getString("deckId");
                    Intrinsics.checkNotNull(id);
                    MainUiState mainUiStateXunjiApp$lambda$4 = XunjiApp$lambda$4($state$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, 1951687306, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance = $composer.changedInstance($nav) | $composer.changed(id);
/* 380 */           Object objRememberedValue = $composer.rememberedValue();
/* 381 */           if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 93 */                Object obj = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda45
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj2) {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$3$0$0($nav, id, (String) obj2);
                            }
                        };
/* 383 */               $composer.updateRememberedValue(obj);
/* 384 */               objRememberedValue = obj;
                    }
/* 93 */            Function1 function1 = (Function1) objRememberedValue;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 1951689598, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance2 = $composer.changedInstance($nav) | $composer.changed(id);
/* 380 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 381 */           if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 93 */                Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda46
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$3$1$0($nav, id);
                            }
                        };
/* 383 */               $composer.updateRememberedValue(obj2);
/* 384 */               objRememberedValue2 = obj2;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 93 */            DeckDetailScreenKt.DeckDetailScreen(id, mainUiStateXunjiApp$lambda$4, $main, function1, (Function0) objRememberedValue2, $composer, (MainUiState.$stable << 3) | (MainViewModel.$stable << 6));
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 92 */        public static final Unit XunjiApp$lambda$14$3$3$0$3$0$0(NavHostController $nav, String $id, String card) {
/* 93 */            NavController.navigate$default((NavController) $nav, "Editor/" + $id + (card != null ? "?cardId=" + card : ""), (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 92 */        public static final Unit XunjiApp$lambda$14$3$3$0$3$1$0(NavHostController $nav, String $id) {
/* 93 */            NavController.navigate$default((NavController) $nav, "Review/" + $id, (NavOptions) null, (Navigator.Extras) null, 6, (Object) null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 93 */        public static final Unit XunjiApp$lambda$14$3$3$0$4(NavArgumentBuilder navArgument) {
                    Intrinsics.checkNotNullParameter(navArgument, "$this$navArgument");
/* 94 */            navArgument.setType(NavType.StringType);
                    navArgument.setNullable(true);
                    navArgument.setDefaultValue(null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:34:0x0173  */
                /* JADX WARN: Code duplicated, block: B:37:0x019d  */
/* 94 */        public static final Unit XunjiApp$lambda$14$3$3$0$5(final AppContainer $container, final NavHostController $nav, AnimatedContentScope composable, NavBackStackEntry backStack, Composer $composer, int $changed) {
                    EditorViewModel editor;
                    boolean zChangedInstance;
                    Object objRememberedValue;
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(backStack, "backStack");
                    ComposerKt.sourceInformation($composer, "CN(backStack)95@7962L245,95@7914L294,96@8246L29,97@8340L49,97@8391L20,97@8281L130:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(1338164481, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:94)");
                    }
/* 95 */            Bundle arguments = backStack.getArguments();
                    Intrinsics.checkNotNull(arguments);
                    final String deckId = arguments.getString("deckId");
                    Intrinsics.checkNotNull(deckId);
                    Bundle arguments2 = backStack.getArguments();
                    Intrinsics.checkNotNull(arguments2);
                    final String cardId = arguments2.getString("cardId");
/* 96 */            NavBackStackEntry navBackStackEntry = backStack;
                    ComposerKt.sourceInformationMarkerStart($composer, 1780851606, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChanged = $composer.changed(deckId) | $composer.changed(cardId);
/* 386 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 387 */           if (zChanged || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 389 */               InitializerViewModelFactoryBuilder initializerViewModelFactoryBuilder = new InitializerViewModelFactoryBuilder();
/* 390 */               initializerViewModelFactoryBuilder.addInitializer(Reflection.getOrCreateKotlinClass(EditorViewModel.class), new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda28
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj) {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$5$0$0$0($container, deckId, cardId, (CreationExtras) obj);
                            }
                        });
/* 389 */               Object objBuild = initializerViewModelFactoryBuilder.build();
/* 392 */               $composer.updateRememberedValue(objBuild);
/* 393 */               objRememberedValue2 = objBuild;
                    }
/* 96 */            ViewModelProvider.Factory factory = (ViewModelProvider.Factory) objRememberedValue2;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    int i = ($changed >> 3) & 14;
/* 395 */           ComposerKt.sourceInformationMarkerStart($composer, 1729797275, "CC(viewModel)P(3,2,1)56@2573L7,67@2980L63:ViewModel.kt#3tja67");
/* 396 */           ViewModel viewModel = ViewModelKt.viewModel((KClass<ViewModel>) Reflection.getOrCreateKotlinClass(EditorViewModel.class), navBackStackEntry, (String) null, factory, navBackStackEntry instanceof HasDefaultViewModelProviderFactory ? navBackStackEntry.getDefaultViewModelCreationExtras() : CreationExtras.Empty.INSTANCE, $composer, ((i << 3) & 112) | ((i << 3) & 896) | ((i << 3) & 7168) | ((i << 3) & 57344), 0);
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 96 */            EditorViewModel editor2 = (EditorViewModel) viewModel;
/* 97 */            State editorState$delegate = FlowExtKt.collectAsStateWithLifecycle(editor2.getState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer, 0, 7);
/* 98 */            EditorUiState editorUiStateXunjiApp$lambda$14$3$3$0$5$1 = XunjiApp$lambda$14$3$3$0$5$1(editorState$delegate);
                    boolean z = cardId != null;
                    ComposerKt.sourceInformationMarkerStart($composer, 1780863506, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance2 = $composer.changedInstance($container);
/* 403 */           Object objRememberedValue3 = $composer.rememberedValue();
/* 404 */           if (!zChangedInstance2) {
                        editor = editor2;
                        if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        }
/* 98 */                Function2 function2 = (Function2) objRememberedValue3;
                        ComposerKt.sourceInformationMarkerEnd($composer);
                        ComposerKt.sourceInformationMarkerStart($composer, 1780865109, "CC(remember):XunjiApp.kt#9igjgp");
                        zChangedInstance = $composer.changedInstance($nav);
/* 403 */               objRememberedValue = $composer.rememberedValue();
/* 404 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 98 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda29
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return XunjiAppKt.XunjiApp$lambda$14$3$3$0$5$3$0($nav);
                                }
                            };
/* 406 */                   $composer.updateRememberedValue(obj);
/* 407 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 98 */                CardEditorScreenKt.CardEditorScreen(editorUiStateXunjiApp$lambda$14$3$3$0$5$1, editor, z, function2, (Function0) objRememberedValue, $composer, EditorUiState.$stable | (EditorViewModel.$stable << 3), 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 99 */                return Unit.INSTANCE;
                    }
/* 404 */           editor = editor2;
                    Object obj2 = (Function2) new XunjiAppKt$XunjiApp$4$4$4$1$6$1$1($container, null);
/* 406 */           $composer.updateRememberedValue(obj2);
/* 407 */           objRememberedValue3 = obj2;
/* 98 */            Function2 function3 = (Function2) objRememberedValue3;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 1780865109, "CC(remember):XunjiApp.kt#9igjgp");
                    zChangedInstance = $composer.changedInstance($nav);
/* 403 */           objRememberedValue = $composer.rememberedValue();
/* 404 */           if (zChangedInstance) {
/* 98 */                Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda29
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$5$3$0($nav);
                            }
                        };
/* 406 */               $composer.updateRememberedValue(obj3);
/* 407 */               objRememberedValue = obj3;
                    } else {
/* 98 */                Object obj4 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda29
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$5$3$0($nav);
                            }
                        };
/* 406 */               $composer.updateRememberedValue(obj4);
/* 407 */               objRememberedValue = obj4;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 98 */            CardEditorScreenKt.CardEditorScreen(editorUiStateXunjiApp$lambda$14$3$3$0$5$1, editor, z, function3, (Function0) objRememberedValue, $composer, EditorUiState.$stable | (EditorViewModel.$stable << 3), 0);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
/* 99 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 95 */        public static final EditorViewModel XunjiApp$lambda$14$3$3$0$5$0$0$0(AppContainer $container, String $deckId, String $cardId, CreationExtras initializer) {
                    Intrinsics.checkNotNullParameter(initializer, "$this$initializer");
/* 96 */            return new EditorViewModel($container.getRepository(), $deckId, $cardId, SavedStateHandleSupport.createSavedStateHandle(initializer), new XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$1($container.getAnkiRepository()), new XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$2($container.getAnkiRepository()), new XunjiAppKt$XunjiApp$4$4$4$1$6$editor$1$1$1$3($container.getAnkiPresenter()));
                }

/* 96 */        private static final EditorUiState XunjiApp$lambda$14$3$3$0$5$1(State<EditorUiState> state) {
/* 409 */           return (EditorUiState) state.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 97 */        public static final Unit XunjiApp$lambda$14$3$3$0$5$3$0(NavHostController $nav) {
/* 98 */            $nav.popBackStack();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:75:0x027d  */
                /* JADX WARN: Code duplicated, block: B:78:0x02a7  */
/* 100 */       public static final Unit XunjiApp$lambda$14$3$3$0$6(final ReviewViewModel $review, final Context $context, final NavHostController $nav, AppContainer $container, AnimatedContentScope composable, NavBackStackEntry backStack, Composer $composer, int $changed) {
                    ReviewUiState reviewUiState;
                    boolean zChangedInstance;
                    XunjiAppKt$XunjiApp$4$4$4$1$7$7$1 xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue;
                    boolean zChangedInstance2;
                    Object objRememberedValue;
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(backStack, "backStack");
                    ComposerKt.sourceInformation($composer, "CN(backStack)101@8569L18,101@8550L37,102@8616L83,102@8593L106,103@8737L29,103@8798L29,104@8842L41,105@8901L52,105@8889L64,106@8993L14,106@9008L13,106@9022L12,106@9035L15,106@9066L49,106@8959L157:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(1588265760, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:100)");
                    }
/* 101 */           Bundle arguments = backStack.getArguments();
                    Intrinsics.checkNotNull(arguments);
                    String string = arguments.getString("deckId");
                    Intrinsics.checkNotNull(string);
/* 101 */           if (Intrinsics.areEqual(string, "all")) {
                        string = null;
                    }
                    String id = string;
/* 102 */           ComposerKt.sourceInformationMarkerStart($composer, 1610009042, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance3 = $composer.changedInstance($review) | $composer.changed(id);
/* 410 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 411 */           if (zChangedInstance3 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                        Object obj = (Function2) new XunjiAppKt$XunjiApp$4$4$4$1$7$1$1($review, id, null);
/* 413 */               $composer.updateRememberedValue(obj);
/* 414 */               objRememberedValue2 = obj;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 102 */           EffectsKt.LaunchedEffect(id, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) objRememberedValue2, $composer, 0);
/* 103 */           Unit unit = Unit.INSTANCE;
                    ComposerKt.sourceInformationMarkerStart($composer, 1610010611, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance4 = $composer.changedInstance($context) | $composer.changedInstance($review);
/* 416 */           Object objRememberedValue3 = $composer.rememberedValue();
/* 417 */           if (zChangedInstance4 || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                        Object obj2 = new Function1() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function1
                            public final Object invoke(Object obj3) {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$6$2$0($context, $review, (DisposableEffectScope) obj3);
                            }
                        };
/* 419 */               $composer.updateRememberedValue(obj2);
/* 420 */               objRememberedValue3 = obj2;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 103 */           EffectsKt.DisposableEffect(unit, (Function1<? super DisposableEffectScope, ? extends DisposableEffectResult>) objRememberedValue3, $composer, 6);
/* 104 */           final State reviewState$delegate = FlowExtKt.collectAsStateWithLifecycle($review.getState(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer, 0, 7);
                    State undoable$delegate = FlowExtKt.collectAsStateWithLifecycle($review.getCanUndo(), (LifecycleOwner) null, (Lifecycle.State) null, (CoroutineContext) null, $composer, 0, 7);
/* 105 */           ComposerKt.sourceInformationMarkerStart($composer, 1610017801, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance5 = $composer.changedInstance($review) | $composer.changedInstance($nav);
/* 422 */           Object objRememberedValue4 = $composer.rememberedValue();
/* 423 */           if (zChangedInstance5 || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
/* 105 */               Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$6$5$0($review, $nav);
                            }
                        };
/* 425 */               $composer.updateRememberedValue(obj3);
/* 426 */               objRememberedValue4 = obj3;
                    }
/* 105 */           final Function0 exit = (Function0) objRememberedValue4;
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 106 */           ComposerKt.sourceInformationMarkerStart($composer, 1610019700, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChanged = $composer.changed(reviewState$delegate) | $composer.changed(exit);
/* 428 */           Object objRememberedValue5 = $composer.rememberedValue();
/* 429 */           if (zChanged || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                        Object obj4 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$6$6$0(exit, reviewState$delegate);
                            }
                        };
/* 431 */               $composer.updateRememberedValue(obj4);
/* 432 */               objRememberedValue5 = obj4;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 106 */           BackHandlerKt.BackHandler(false, (Function0) objRememberedValue5, $composer, 0, 1);
/* 107 */           ReviewUiState reviewUiStateXunjiApp$lambda$14$3$3$0$6$3 = XunjiApp$lambda$14$3$3$0$6$3(reviewState$delegate);
                    boolean zXunjiApp$lambda$14$3$3$0$6$4 = XunjiApp$lambda$14$3$3$0$6$4(undoable$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, 1610022606, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance6 = $composer.changedInstance($review);
/* 434 */           Object objRememberedValue6 = $composer.rememberedValue();
/* 435 */           if (zChangedInstance6 || objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                        Object obj5 = (KFunction) new XunjiAppKt$XunjiApp$4$4$4$1$7$4$1($review);
/* 437 */               $composer.updateRememberedValue(obj5);
/* 438 */               objRememberedValue6 = obj5;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */           Function0 function0 = (Function0) ((KFunction) objRememberedValue6);
                    ComposerKt.sourceInformationMarkerStart($composer, 1610023085, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance7 = $composer.changedInstance($review);
                    XunjiAppKt$XunjiApp$4$4$4$1$7$5$1 xunjiAppKt$XunjiApp$4$4$4$1$7$5$1RememberedValue = $composer.rememberedValue();
/* 435 */           if (zChangedInstance7 || xunjiAppKt$XunjiApp$4$4$4$1$7$5$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                        xunjiAppKt$XunjiApp$4$4$4$1$7$5$1RememberedValue = new XunjiAppKt$XunjiApp$4$4$4$1$7$5$1($review);
/* 437 */               $composer.updateRememberedValue(xunjiAppKt$XunjiApp$4$4$4$1$7$5$1RememberedValue);
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */           Function1 function1 = (Function1) ((KFunction) xunjiAppKt$XunjiApp$4$4$4$1$7$5$1RememberedValue);
                    ComposerKt.sourceInformationMarkerStart($composer, 1610023532, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance8 = $composer.changedInstance($review);
                    XunjiAppKt$XunjiApp$4$4$4$1$7$6$1 xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue = $composer.rememberedValue();
/* 435 */           if (!zChangedInstance8) {
                        reviewUiState = reviewUiStateXunjiApp$lambda$14$3$3$0$6$3;
                        if (xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */               Function0 function2 = (Function0) ((KFunction) xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue);
                        ComposerKt.sourceInformationMarkerStart($composer, 1610023951, "CC(remember):XunjiApp.kt#9igjgp");
                        zChangedInstance = $composer.changedInstance($review);
                        xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue = $composer.rememberedValue();
/* 435 */               if (!zChangedInstance || xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                            xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue = new XunjiAppKt$XunjiApp$4$4$4$1$7$7$1($review);
/* 437 */                   $composer.updateRememberedValue(xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */               Function0 function3 = (Function0) ((KFunction) xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue);
                        ComposerKt.sourceInformationMarkerStart($composer, 1610024977, "CC(remember):XunjiApp.kt#9igjgp");
                        zChangedInstance2 = $composer.changedInstance($container);
/* 434 */               objRememberedValue = $composer.rememberedValue();
/* 435 */               if (zChangedInstance2 || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj6 = (Function2) new XunjiAppKt$XunjiApp$4$4$4$1$7$8$1($container, null);
/* 437 */                   $composer.updateRememberedValue(obj6);
/* 438 */                   objRememberedValue = obj6;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 434 */               ReviewScreenKt.ReviewScreen(reviewUiState, zXunjiApp$lambda$14$3$3$0$6$4, function0, function1, function2, function3, exit, (Function2) objRememberedValue, $composer, 0, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 108 */               return Unit.INSTANCE;
                    }
/* 435 */           reviewUiState = reviewUiStateXunjiApp$lambda$14$3$3$0$6$3;
                    xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue = new XunjiAppKt$XunjiApp$4$4$4$1$7$6$1($review);
/* 437 */           $composer.updateRememberedValue(xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue);
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */           Function0 function4 = (Function0) ((KFunction) xunjiAppKt$XunjiApp$4$4$4$1$7$6$1RememberedValue);
                    ComposerKt.sourceInformationMarkerStart($composer, 1610023951, "CC(remember):XunjiApp.kt#9igjgp");
                    zChangedInstance = $composer.changedInstance($review);
                    xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue = $composer.rememberedValue();
/* 435 */           if (!zChangedInstance) {
                    }
                    xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue = new XunjiAppKt$XunjiApp$4$4$4$1$7$7$1($review);
/* 437 */           $composer.updateRememberedValue(xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue);
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 107 */           Function0 function5 = (Function0) ((KFunction) xunjiAppKt$XunjiApp$4$4$4$1$7$7$1RememberedValue);
                    ComposerKt.sourceInformationMarkerStart($composer, 1610024977, "CC(remember):XunjiApp.kt#9igjgp");
                    zChangedInstance2 = $composer.changedInstance($container);
/* 434 */           objRememberedValue = $composer.rememberedValue();
/* 435 */           if (zChangedInstance2) {
                        Object obj7 = (Function2) new XunjiAppKt$XunjiApp$4$4$4$1$7$8$1($container, null);
/* 437 */               $composer.updateRememberedValue(obj7);
/* 438 */               objRememberedValue = obj7;
                    } else {
                        Object obj8 = (Function2) new XunjiAppKt$XunjiApp$4$4$4$1$7$8$1($container, null);
/* 437 */               $composer.updateRememberedValue(obj8);
/* 438 */               objRememberedValue = obj8;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 434 */           ReviewScreenKt.ReviewScreen(reviewUiState, zXunjiApp$lambda$14$3$3$0$6$4, function0, function1, function4, function5, exit, (Function2) objRememberedValue, $composer, 0, 0);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
/* 108 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 102 */       public static final DisposableEffectResult XunjiApp$lambda$14$3$3$0$6$2$0(final Context $context, final ReviewViewModel $review, DisposableEffectScope DisposableEffect) {
                    Intrinsics.checkNotNullParameter(DisposableEffect, "$this$DisposableEffect");
/* 440 */           return new DisposableEffectResult() { // from class: com.xunji.flashcards.ui.XunjiAppKt$XunjiApp$lambda$14$3$3$0$6$2$0$$inlined$onDispose$1
                        @Override // androidx.compose.runtime.DisposableEffectResult
/* 67 */                public void dispose() {
/* 1 */                     Activity activity = XunjiAppKt.activity($context);
                            boolean z = false;
                            if (activity != null && activity.isChangingConfigurations()) {
                                z = true;
                            }
                            if (!z) {
                                $review.finish();
                            }
                        }
                    };
                }

/* 103 */       private static final ReviewUiState XunjiApp$lambda$14$3$3$0$6$3(State<? extends ReviewUiState> state) {
/* 445 */           return (ReviewUiState) state.getValue();
                }

/* 103 */       private static final boolean XunjiApp$lambda$14$3$3$0$6$4(State<Boolean> state) {
/* 445 */           return ((Boolean) state.getValue()).booleanValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 104 */       public static final Unit XunjiApp$lambda$14$3$3$0$6$5$0(ReviewViewModel $review, NavHostController $nav) {
/* 105 */           $review.finish();
                    $nav.popBackStack();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 105 */       public static final Unit XunjiApp$lambda$14$3$3$0$6$6$0(Function0 $exit, State $reviewState$delegate) {
/* 106 */           if (!(XunjiApp$lambda$14$3$3$0$6$3($reviewState$delegate) instanceof ReviewUiState.Submitting)) {
                        $exit.invoke();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final Unit XunjiApp$lambda$14$3$3$0$7(SettingsViewModel $settings, final ManagedActivityResultLauncher $export, final ManagedActivityResultLauncher $restore, final ManagedActivityResultLauncher $ankiPicker, final String[] $ankiTypes, State $settingsState$delegate, AnimatedContentScope composable, NavBackStackEntry it, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(it, "it");
                    ComposerKt.sourceInformation($composer, "CN(it)108@9189L50,108@9240L99,108@9340L30,108@9151L220:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(1838367039, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:108)");
                    }
/* 109 */           SettingsUiState settingsUiStateXunjiApp$lambda$5 = XunjiApp$lambda$5($settingsState$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, 1439167121, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance = $composer.changedInstance($export);
/* 446 */           Object objRememberedValue = $composer.rememberedValue();
/* 447 */           if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$7$0$0($export);
                            }
                        };
/* 449 */               $composer.updateRememberedValue(obj);
/* 450 */               objRememberedValue = obj;
                    }
/* 109 */           Function0 function0 = (Function0) objRememberedValue;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 1439168802, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance2 = $composer.changedInstance($restore);
/* 446 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 447 */           if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 109 */               Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$7$1$0($restore);
                            }
                        };
/* 449 */               $composer.updateRememberedValue(obj2);
/* 450 */               objRememberedValue2 = obj2;
                    }
/* 109 */           Function0 function1 = (Function0) objRememberedValue2;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 1439171933, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance3 = $composer.changedInstance($ankiPicker) | $composer.changedInstance($ankiTypes);
/* 446 */           Object objRememberedValue3 = $composer.rememberedValue();
/* 447 */           if (zChangedInstance3 || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
/* 109 */               Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda5
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$7$2$0($ankiPicker, $ankiTypes);
                            }
                        };
/* 449 */               $composer.updateRememberedValue(obj3);
/* 450 */               objRememberedValue3 = obj3;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 109 */           SettingsScreenKt.SettingsScreen(settingsUiStateXunjiApp$lambda$5, $settings, function0, function1, (Function0) objRememberedValue3, $composer, SettingsUiState.$stable | (SettingsViewModel.$stable << 3));
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final Unit XunjiApp$lambda$14$3$3$0$7$0$0(ManagedActivityResultLauncher $export) {
                    $export.launch("循记-" + LocalDate.now() + ".xunji.zip");
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final Unit XunjiApp$lambda$14$3$3$0$7$1$0(ManagedActivityResultLauncher $restore) {
/* 109 */           $restore.launch(new String[]{"application/zip", "application/json", "text/*", "application/octet-stream"});
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final Unit XunjiApp$lambda$14$3$3$0$7$2$0(ManagedActivityResultLauncher $ankiPicker, String[] $ankiTypes) {
/* 109 */           $ankiPicker.launch($ankiTypes);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 110 */       public static final Unit XunjiApp$lambda$14$3$3$0$8(final AnkiImportViewModel $ankiImport, final ManagedActivityResultLauncher $ankiPicker, final String[] $ankiTypes, final NavHostController $nav, State $importState$delegate, AnimatedContentScope composable, NavBackStackEntry it, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(composable, "$this$composable");
                    Intrinsics.checkNotNullParameter(it, "it");
                    ComposerKt.sourceInformation($composer, "CN(it)110@9449L30,110@9480L44,110@9409L116:XunjiApp.kt#thuf8k");
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventStart(2088468318, $changed, -1, "com.xunji.flashcards.ui.XunjiApp.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (XunjiApp.kt:110)");
                    }
/* 111 */           AnkiImportUiState ankiImportUiStateXunjiApp$lambda$6 = XunjiApp$lambda$6($importState$delegate);
                    ComposerKt.sourceInformationMarkerStart($composer, 1268327900, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance = $composer.changedInstance($ankiPicker) | $composer.changedInstance($ankiTypes);
/* 452 */           Object objRememberedValue = $composer.rememberedValue();
/* 453 */           if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$8$0$0($ankiPicker, $ankiTypes);
                            }
                        };
/* 455 */               $composer.updateRememberedValue(obj);
/* 456 */               objRememberedValue = obj;
                    }
/* 111 */           Function0 function0 = (Function0) objRememberedValue;
                    ComposerKt.sourceInformationMarkerEnd($composer);
                    ComposerKt.sourceInformationMarkerStart($composer, 1268328906, "CC(remember):XunjiApp.kt#9igjgp");
                    boolean zChangedInstance2 = $composer.changedInstance($ankiImport) | $composer.changedInstance($nav);
/* 452 */           Object objRememberedValue2 = $composer.rememberedValue();
/* 453 */           if (zChangedInstance2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 111 */               Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.XunjiAppKt$$ExternalSyntheticLambda22
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return XunjiAppKt.XunjiApp$lambda$14$3$3$0$8$1$0($ankiImport, $nav);
                            }
                        };
/* 455 */               $composer.updateRememberedValue(obj2);
/* 456 */               objRememberedValue2 = obj2;
                    }
                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 111 */           AnkiImportScreenKt.AnkiImportScreen(ankiImportUiStateXunjiApp$lambda$6, $ankiImport, function0, (Function0) objRememberedValue2, $composer, (AnkiImportViewModel.$stable << 3) | AnkiImportUiState.$stable);
                    if (ComposerKt.isTraceInProgress()) {
                        ComposerKt.traceEventEnd();
                    }
/* 112 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 110 */       public static final Unit XunjiApp$lambda$14$3$3$0$8$0$0(ManagedActivityResultLauncher $ankiPicker, String[] $ankiTypes) {
/* 111 */           $ankiPicker.launch($ankiTypes);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 110 */       public static final Unit XunjiApp$lambda$14$3$3$0$8$1$0(AnkiImportViewModel $ankiImport, NavHostController $nav) {
/* 111 */           $ankiImport.cancel();
                    finishAnkiImport($nav);
                    return Unit.INSTANCE;
                }
            }

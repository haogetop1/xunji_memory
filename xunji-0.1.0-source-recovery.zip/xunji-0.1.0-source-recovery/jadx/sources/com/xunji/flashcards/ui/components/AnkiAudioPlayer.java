            package com.xunji.flashcards.ui.components;

            import android.media.MediaPlayer;
            import androidx.core.app.NotificationCompat;
            import com.xunji.flashcards.anki.CardMedia;
            import java.io.Closeable;
            import java.io.FileInputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.Result;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.io.CloseableKt;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.jvm.internal.Ref;
            import kotlinx.coroutines.BuildersKt;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            import kotlinx.coroutines.Dispatchers;
            import kotlinx.coroutines.Job;
            
            /* JADX INFO: compiled from: AnkiCardContent.kt */
            /* JADX INFO: loaded from: classes11.dex */
            @Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u0001\u0018\u00002\u00020\u0001BI\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012$\u0010\u0004\u001a \b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000b¢\u0006\u0004\b\u000e\u0010\u000fJ\u000e\u0010\u001b\u001a\u00020\r2\u0006\u0010\u001c\u001a\u00020\u0006J\b\u0010\u001d\u001a\u00020\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004¢\u0006\u0002\n\u0000R.\u0010\u0004\u001a \b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\u0010R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\f\u0012\u0004\u0012\u00020\r0\u000bX\u0082\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e¢\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e¢\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0017\u001a\u00020\u00188@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0019\u0010\u001a¨\u0006\u001e"}, d2 = {"Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;", "Ljava/io/Closeable;", "scope", "Lkotlinx/coroutines/CoroutineScope;", "open", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/CardMedia;", "Lkotlin/coroutines/Continuation;", "Ljava/io/InputStream;", "", NotificationCompat.CATEGORY_STATUS, "Lkotlin/Function1;", "", "", "<init>", "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V", "Lkotlin/jvm/functions/Function2;", "player", "Landroid/media/MediaPlayer;", "job", "Lkotlinx/coroutines/Job;", "generation", "", "hasPlayer", "", "getHasPlayer$app_debug", "()Z", "play", "media", "close", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 46 */    public final class AnkiAudioPlayer implements Closeable {
                public static final int $stable = 8;
                private long generation;
                private Job job;
                private final Function2<CardMedia, Continuation<? super InputStream>, Object> open;
                private MediaPlayer player;
                private final CoroutineScope scope;
                private final Function1<String, Unit> status;

                /* JADX WARN: Multi-variable type inference failed */
/* 47 */        public AnkiAudioPlayer(CoroutineScope scope, Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> open, Function1<? super String, Unit> status) {
                    Intrinsics.checkNotNullParameter(scope, "scope");
                    Intrinsics.checkNotNullParameter(open, "open");
                    Intrinsics.checkNotNullParameter(status, "status");
                    this.scope = scope;
                    this.open = open;
                    this.status = status;
                }

/* 51 */        public final boolean getHasPlayer$app_debug() {
                    return this.player != null;
                }

                /* JADX INFO: renamed from: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1, reason: invalid class name */
                /* JADX INFO: compiled from: AnkiCardContent.kt */
                @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                @DebugMetadata(c = "com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1", f = "AnkiCardContent.kt", i = {0}, l = {59}, m = "invokeSuspend", n = {"opened"}, s = {"L$0"}, v = 1)
/* 53 */        static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    final /* synthetic */ CardMedia $media;
                    final /* synthetic */ long $token;
                    Object L$0;
                    int label;
                    final /* synthetic */ AnkiAudioPlayer this$0;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    AnonymousClass1(long j, AnkiAudioPlayer ankiAudioPlayer, CardMedia cardMedia, Continuation<? super AnonymousClass1> continuation) {
                        super(2, continuation);
                        this.$token = j;
                        this.this$0 = ankiAudioPlayer;
                        this.$media = cardMedia;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                        return new AnonymousClass1(this.$token, this.this$0, this.$media, continuation);
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARN: Code duplicated, block: B:19:0x004c A[Catch: all -> 0x001a, TRY_LEAVE, TryCatch #3 {all -> 0x001a, blocks: (B:7:0x0016, B:17:0x0048, B:19:0x004c, B:23:0x0060, B:34:0x00a5, B:44:0x00bd, B:45:0x00c0, B:46:0x00c1, B:47:0x00cc, B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9, B:42:0x00bb), top: B:63:0x0016, inners: #2, #4 }] */
                    /* JADX WARN: Code duplicated, block: B:22:0x005e A[Catch: all -> 0x00ba, TRY_LEAVE, TryCatch #2 {all -> 0x00ba, blocks: (B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9), top: B:62:0x0052, outer: #3 }] */
                    /* JADX WARN: Code duplicated, block: B:26:0x0069 A[Catch: Exception -> 0x00db, CancellationException -> 0x00fb, TRY_LEAVE, TryCatch #6 {CancellationException -> 0x00fb, Exception -> 0x00db, blocks: (B:24:0x0063, B:26:0x0069, B:35:0x00a8, B:37:0x00ae, B:50:0x00d1, B:52:0x00d7, B:53:0x00da, B:12:0x0021), top: B:68:0x0021 }] */
                    /* JADX WARN: Code duplicated, block: B:28:0x006d A[Catch: all -> 0x00ba, TRY_ENTER, TryCatch #2 {all -> 0x00ba, blocks: (B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9), top: B:62:0x0052, outer: #3 }] */
                    /* JADX WARN: Code duplicated, block: B:30:0x0071 A[Catch: all -> 0x00ba, TryCatch #2 {all -> 0x00ba, blocks: (B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9), top: B:62:0x0052, outer: #3 }] */
                    /* JADX WARN: Code duplicated, block: B:31:0x0075  */
                    /* JADX WARN: Code duplicated, block: B:33:0x0078 A[Catch: all -> 0x00ba, TRY_LEAVE, TryCatch #2 {all -> 0x00ba, blocks: (B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9), top: B:62:0x0052, outer: #3 }] */
                    /* JADX WARN: Code duplicated, block: B:37:0x00ae A[Catch: Exception -> 0x00db, CancellationException -> 0x00fb, TRY_LEAVE, TryCatch #6 {CancellationException -> 0x00fb, Exception -> 0x00db, blocks: (B:24:0x0063, B:26:0x0069, B:35:0x00a8, B:37:0x00ae, B:50:0x00d1, B:52:0x00d7, B:53:0x00da, B:12:0x0021), top: B:68:0x0021 }] */
                    /* JADX WARN: Code duplicated, block: B:39:0x00b2 A[Catch: all -> 0x00ba, TRY_ENTER, TryCatch #2 {all -> 0x00ba, blocks: (B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9), top: B:62:0x0052, outer: #3 }] */
                    /* JADX WARN: Code duplicated, block: B:46:0x00c1 A[Catch: all -> 0x001a, TryCatch #3 {all -> 0x001a, blocks: (B:7:0x0016, B:17:0x0048, B:19:0x004c, B:23:0x0060, B:34:0x00a5, B:44:0x00bd, B:45:0x00c0, B:46:0x00c1, B:47:0x00cc, B:20:0x0052, B:22:0x005e, B:28:0x006d, B:30:0x0071, B:33:0x0078, B:39:0x00b2, B:40:0x00b9, B:42:0x00bb), top: B:63:0x0016, inners: #2, #4 }] */
                    /* JADX WARN: Code duplicated, block: B:52:0x00d7 A[Catch: Exception -> 0x00db, CancellationException -> 0x00fb, TryCatch #6 {CancellationException -> 0x00fb, Exception -> 0x00db, blocks: (B:24:0x0063, B:26:0x0069, B:35:0x00a8, B:37:0x00ae, B:50:0x00d1, B:52:0x00d7, B:53:0x00da, B:12:0x0021), top: B:68:0x0021 }] */
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 54 */            public final Object invokeSuspend(Object $result) throws Throwable {
                        Throwable th;
                        Ref.ObjectRef opened;
                        InputStream inputStream;
                        T t;
                        Closeable closeable;
                        final long j;
                        final AnkiAudioPlayer ankiAudioPlayer;
                        InputStream inputStream2;
                        FileInputStream fileInputStream;
                        InputStream inputStream3;
                        InputStream inputStream4;
                        Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        switch (this.label) {
                            case 0:
/* 55 */                        ResultKt.throwOnFailure($result);
                                try {
/* 57 */                            Ref.ObjectRef opened2 = new Ref.ObjectRef();
                                    try {
                                        this.L$0 = opened2;
                                        this.label = 1;
/* 59 */                                if (BuildersKt.withContext(Dispatchers.getIO(), new C01041(opened2, this.this$0, this.$media, null), this) == coroutine_suspended) {
/* 55 */                                    return coroutine_suspended;
                                        }
/* 59 */                                opened = opened2;
/* 60 */                                t = opened.element;
                                        if (t != 0) {
                                            throw new IllegalArgumentException("Required value was null.".toString());
                                        }
                                        closeable = (Closeable) t;
                                        j = this.$token;
                                        ankiAudioPlayer = this.this$0;
                                        try {
                                            inputStream2 = (InputStream) closeable;
                                            if (j != ankiAudioPlayer.generation) {
                                                Unit unit = Unit.INSTANCE;
/* 60 */                                        CloseableKt.closeFinally(closeable, null);
/* 72 */                                        inputStream4 = (InputStream) opened.element;
                                                if (inputStream4 != null) {
                                                    inputStream4.close();
                                                }
                                                return unit;
                                            }
/* 62 */                                    if (inputStream2 instanceof FileInputStream) {
                                                fileInputStream = (FileInputStream) inputStream2;
                                            } else {
                                                fileInputStream = null;
                                            }
                                            if (fileInputStream != null) {
/* 62 */                                        throw new IOException("无法读取本地音频");
                                            }
/* 63 */                                    MediaPlayer mediaPlayer = new MediaPlayer();
/* 48 */                                    ankiAudioPlayer.player = mediaPlayer;
/* 64 */                                    mediaPlayer.setDataSource(fileInputStream.getFD());
/* 65 */                                    mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda0
                                                @Override // android.media.MediaPlayer.OnPreparedListener
                                                public final void onPrepared(MediaPlayer mediaPlayer2) {
                                                    AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$0(j, ankiAudioPlayer, mediaPlayer2);
                                                }
                                            });
/* 68 */                                    mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1
                                                @Override // android.media.MediaPlayer.OnCompletionListener
                                                public final void onCompletion(MediaPlayer mediaPlayer2) {
                                                    AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$1(j, ankiAudioPlayer, mediaPlayer2);
                                                }
                                            });
/* 69 */                                    mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2
                                                @Override // android.media.MediaPlayer.OnErrorListener
                                                public final boolean onError(MediaPlayer mediaPlayer2, int i, int i2) {
                                                    return AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$2(j, ankiAudioPlayer, mediaPlayer2, i, i2);
                                                }
                                            });
/* 70 */                                    mediaPlayer.prepareAsync();
                                            Unit unit2 = Unit.INSTANCE;
/* 60 */                                    CloseableKt.closeFinally(closeable, null);
/* 72 */                                    inputStream3 = (InputStream) opened.element;
                                            if (inputStream3 != null) {
                                                inputStream3.close();
                                            }
/* 74 */                                    return Unit.INSTANCE;
                                        } catch (Throwable th2) {
                                            try {
                                                throw th2;
                                            } catch (Throwable th3) {
                                                CloseableKt.closeFinally(closeable, th2);
                                                throw th3;
                                            }
                                        }
                                    } catch (Throwable th4) {
                                        th = th4;
                                        opened = opened2;
                                        inputStream = (InputStream) opened.element;
                                        if (inputStream != null) {
                                            inputStream.close();
                                        }
                                        throw th;
                                    }
                                } catch (CancellationException e) {
                                    throw e;
                                } catch (Exception e2) {
                                    if (this.$token == this.this$0.generation) {
                                        this.this$0.close();
/* 48 */                                invoke("此设备无法读取或播放该音频");
                                    }
                                }
                                break;
                            case 1:
                                opened = (Ref.ObjectRef) this.L$0;
                                try {
                                    ResultKt.throwOnFailure($result);
/* 60 */                            t = opened.element;
                                    if (t != 0) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    closeable = (Closeable) t;
                                    j = this.$token;
                                    ankiAudioPlayer = this.this$0;
                                    inputStream2 = (InputStream) closeable;
                                    if (j != ankiAudioPlayer.generation) {
                                        Unit unit3 = Unit.INSTANCE;
/* 60 */                                CloseableKt.closeFinally(closeable, null);
/* 72 */                                inputStream4 = (InputStream) opened.element;
                                        if (inputStream4 != null) {
                                            inputStream4.close();
                                        }
                                        return unit3;
                                    }
/* 62 */                            if (inputStream2 instanceof FileInputStream) {
                                        fileInputStream = (FileInputStream) inputStream2;
                                    } else {
                                        fileInputStream = null;
                                    }
                                    if (fileInputStream != null) {
/* 62 */                                throw new IOException("无法读取本地音频");
                                    }
/* 63 */                            MediaPlayer mediaPlayer2 = new MediaPlayer();
/* 48 */                            ankiAudioPlayer.player = mediaPlayer2;
/* 64 */                            mediaPlayer2.setDataSource(fileInputStream.getFD());
/* 65 */                            mediaPlayer2.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda0
                                        @Override // android.media.MediaPlayer.OnPreparedListener
                                        public final void onPrepared(MediaPlayer mediaPlayer3) {
                                            AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$0(j, ankiAudioPlayer, mediaPlayer3);
                                        }
                                    });
/* 68 */                            mediaPlayer2.setOnCompletionListener(new MediaPlayer.OnCompletionListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1
                                        @Override // android.media.MediaPlayer.OnCompletionListener
                                        public final void onCompletion(MediaPlayer mediaPlayer3) {
                                            AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$1(j, ankiAudioPlayer, mediaPlayer3);
                                        }
                                    });
/* 69 */                            mediaPlayer2.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2
                                        @Override // android.media.MediaPlayer.OnErrorListener
                                        public final boolean onError(MediaPlayer mediaPlayer3, int i, int i2) {
                                            return AnkiAudioPlayer.AnonymousClass1.invokeSuspend$lambda$0$2(j, ankiAudioPlayer, mediaPlayer3, i, i2);
                                        }
                                    });
/* 70 */                            mediaPlayer2.prepareAsync();
                                    Unit unit4 = Unit.INSTANCE;
/* 60 */                            CloseableKt.closeFinally(closeable, null);
/* 72 */                            inputStream3 = (InputStream) opened.element;
                                    if (inputStream3 != null) {
                                        inputStream3.close();
                                    }
/* 74 */                            return Unit.INSTANCE;
                                } catch (Throwable th5) {
/* 72 */                            th = th5;
                                    inputStream = (InputStream) opened.element;
                                    if (inputStream != null) {
                                        inputStream.close();
                                    }
                                    throw th;
                                }
                            default:
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                        }
                    }

                    /* JADX INFO: renamed from: com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$1, reason: invalid class name and collision with other inner class name */
                    /* JADX INFO: compiled from: AnkiCardContent.kt */
                    @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
                    @DebugMetadata(c = "com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$1", f = "AnkiCardContent.kt", i = {}, l = {59}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 57 */            static final class C01041 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                        final /* synthetic */ CardMedia $media;
                        final /* synthetic */ Ref.ObjectRef<InputStream> $opened;
                        Object L$0;
                        int label;
                        final /* synthetic */ AnkiAudioPlayer this$0;

                        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                        C01041(Ref.ObjectRef<InputStream> objectRef, AnkiAudioPlayer ankiAudioPlayer, CardMedia cardMedia, Continuation<? super C01041> continuation) {
                            super(2, continuation);
                            this.$opened = objectRef;
                            this.this$0 = ankiAudioPlayer;
                            this.$media = cardMedia;
                        }

                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                        public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                            return new C01041(this.$opened, this.this$0, this.$media, continuation);
                        }

                        @Override // kotlin.jvm.functions.Function2
                        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                            return ((C01041) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                        }

                        /* JADX WARN: Multi-variable type inference failed */
                        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 58 */                public final Object invokeSuspend(Object obj) throws Throwable {
                            Object objInvoke;
                            Ref.ObjectRef<InputStream> objectRef;
                            T t;
                            Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure(obj);
                                    Ref.ObjectRef<InputStream> objectRef2 = this.$opened;
/* 48 */                            Function2 function2 = this.this$0.open;
                                    CardMedia cardMedia = this.$media;
                                    this.L$0 = objectRef2;
                                    this.label = 1;
                                    objInvoke = function2.invoke(cardMedia, this);
                                    if (objInvoke == coroutine_suspended) {
                                        return coroutine_suspended;
                                    }
                                    objectRef = objectRef2;
                                    break;
                                case 1:
                                    objectRef = (Ref.ObjectRef) this.L$0;
                                    ResultKt.throwOnFailure(obj);
                                    t = obj;
                                    break;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            if (t == 0) {
                                t = objInvoke;
                                throw new IllegalArgumentException("音频文件缺失".toString());
                            }
                            t = objInvoke;
                            objectRef.element = t;
                            return Unit.INSTANCE;
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 65 */            public static final void invokeSuspend$lambda$0$0(long $token, AnkiAudioPlayer this$0, MediaPlayer ready) {
/* 48 */                if ($token == this$0.generation && this$0.player == ready) {
                            try {
                                ready.start();
/* 48 */                        this$0.status.invoke("正在播放");
                            } catch (Exception e) {
                                this$0.close();
/* 48 */                        this$0.status.invoke("此设备无法解码或播放该音频");
                            }
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 67 */            public static final void invokeSuspend$lambda$0$1(long $token, AnkiAudioPlayer this$0, MediaPlayer it) {
                        if ($token == this$0.generation) {
                            this$0.close();
/* 48 */                    this$0.status.invoke("播放完成");
                        }
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 68 */            public static final boolean invokeSuspend$lambda$0$2(long $token, AnkiAudioPlayer this$0, MediaPlayer mediaPlayer, int i, int i2) {
                        if ($token != this$0.generation) {
                            return true;
                        }
                        this$0.close();
/* 48 */                this$0.status.invoke("此设备无法解码或播放该音频");
                        return true;
                    }
                }

/* 53 */        public final void play(CardMedia media) {
                    Intrinsics.checkNotNullParameter(media, "media");
/* 54 */            close();
                    long token = this.generation;
                    invoke("正在准备音频…");
/* 1 */             this.job = BuildersKt__Builders_commonKt.launch$default(this.scope, null, null, new AnonymousClass1(token, this, media, null), 3, null);
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 75 */        public void close() {
/* 76 */            this.generation++;
                    Job job = this.job;
                    if (job != null) {
                        Job.DefaultImpls.cancel$default(job, (CancellationException) null, 1, (Object) null);
                    }
                    this.job = null;
                    MediaPlayer mediaPlayer = this.player;
                    if (mediaPlayer != null) {
/* 76 */                mediaPlayer.setOnPreparedListener(null);
                        mediaPlayer.setOnCompletionListener(null);
                        mediaPlayer.setOnErrorListener(null);
                        try {
                            Result.Companion companion = Result.INSTANCE;
                            AnkiAudioPlayer ankiAudioPlayer = this;
/* 76 */                    mediaPlayer.stop();
                            Result.m9077constructorimpl(Unit.INSTANCE);
                        } catch (Throwable th) {
                            Result.Companion companion2 = Result.INSTANCE;
                            Result.m9077constructorimpl(ResultKt.createFailure(th));
                        }
                        mediaPlayer.release();
                    }
                    this.player = null;
                }
            }

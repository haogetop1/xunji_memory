            package com.xunji.flashcards.ui.components;

            import android.content.Context;
            import android.webkit.WebView;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.DisposableEffectResult;
            import androidx.compose.runtime.DisposableEffectScope;
            import androidx.compose.runtime.MutableState;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.ui.Modifier;
            import androidx.lifecycle.Lifecycle;
            import androidx.lifecycle.LifecycleEventObserver;
            import androidx.lifecycle.LifecycleOwner;
            import com.xunji.flashcards.anki.CardMedia;
            import com.xunji.flashcards.anki.RenderedCard;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiCardContent.kt */
            /* JADX INFO: loaded from: classes11.dex */
            @Metadata(d1 = {"\u00006\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\u001aE\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032$\u0010\u0004\u001a \b\u0001\u0012\u0004\u0012\u00020\u0006\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u00052\b\b\u0002\u0010\n\u001a\u00020\u000bH\u0007¢\u0006\u0002\u0010\f¨\u0006\r²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u008e\u0002"}, d2 = {"AnkiCardContent", "", "card", "Lcom/xunji/flashcards/anki/RenderedCard;", "openMedia", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/CardMedia;", "Lkotlin/coroutines/Continuation;", "Ljava/io/InputStream;", "", "modifier", "Landroidx/compose/ui/Modifier;", "(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "app_debug", "audioStatus", "", "foreground", ""}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 77 */    public final class AnkiCardContentKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit AnkiCardContent$lambda$9(RenderedCard renderedCard, Function2 function2, Modifier modifier, int i, int i2, Composer composer, int i3) {
                    AnkiCardContent(renderedCard, function2, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /*  JADX ERROR: Type inference failed
                    jadx.core.utils.exceptions.JadxOverflowException: Type inference error: updates count limit reached with updateSeq = 23371. Try increasing type updates limit count.
                    	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
                    	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
                    	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
                    	at jadx.core.dex.visitors.typeinference.TypeInferenceVisitor.visit(TypeInferenceVisitor.java:79)
                    */
/* 78 */        public static final void AnkiCardContent(com.xunji.flashcards.anki.RenderedCard r83, kotlin.jvm.functions.Function2<? super com.xunji.flashcards.anki.CardMedia, ? super kotlin.coroutines.Continuation<? super java.io.InputStream>, ? extends java.lang.Object> r84, androidx.compose.ui.Modifier r85, androidx.compose.runtime.Composer r86, int r87, int r88) {
                    /*
                        Method dump skipped, instruction units count: 2337
                        To view this dump change 'Code comments level' option to 'DEBUG'
                    */
                    throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.ui.components.AnkiCardContentKt.AnkiCardContent(com.xunji.flashcards.anki.RenderedCard, kotlin.jvm.functions.Function2, androidx.compose.ui.Modifier, androidx.compose.runtime.Composer, int, int):void");
                }

/* 85 */        private static final String AnkiCardContent$lambda$1(MutableState<String> mutableState) {
/* 282 */           return mutableState.getValue();
                }

/* 86 */        private static final boolean AnkiCardContent$lambda$4(MutableState<Boolean> mutableState) {
/* 285 */           return mutableState.getValue().booleanValue();
                }

/* 86 */        private static final void AnkiCardContent$lambda$5(MutableState<Boolean> mutableState, boolean z) {
/* 286 */           mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 87 */        public static final Unit AnkiCardContent$lambda$6$0(MutableState $audioStatus$delegate, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 283 */           $audioStatus$delegate.setValue(it);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final DisposableEffectResult AnkiCardContent$lambda$7$0(final LifecycleOwner $owner, final AnkiAudioPlayer $audio, final MutableState $foreground$delegate, final MutableState $audioStatus$delegate, DisposableEffectScope DisposableEffect) {
                    Intrinsics.checkNotNullParameter(DisposableEffect, "$this$DisposableEffect");
/* 90 */            final LifecycleEventObserver observer = new LifecycleEventObserver() { // from class: com.xunji.flashcards.ui.components.AnkiCardContentKt$$ExternalSyntheticLambda0
                        @Override // androidx.lifecycle.LifecycleEventObserver
                        public final void onStateChanged(LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                            AnkiCardContentKt.AnkiCardContent$lambda$7$0$0($audio, $foreground$delegate, $audioStatus$delegate, lifecycleOwner, event);
                        }
                    };
/* 91 */            $owner.getLifecycle().addObserver(observer);
/* 288 */           return new DisposableEffectResult() { // from class: com.xunji.flashcards.ui.components.AnkiCardContentKt$AnkiCardContent$lambda$7$0$$inlined$onDispose$1
                        @Override // androidx.compose.runtime.DisposableEffectResult
/* 67 */                public void dispose() {
/* 70 */                    getLifecycle().removeObserver(observer);
                            $audio.close();
                        }
                    };
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 89 */        public static final void AnkiCardContent$lambda$7$0$0(AnkiAudioPlayer $audio, MutableState $foreground$delegate, MutableState $audioStatus$delegate, LifecycleOwner lifecycleOwner, Lifecycle.Event event) {
                    Intrinsics.checkNotNullParameter(lifecycleOwner, "<unused var>");
                    Intrinsics.checkNotNullParameter(event, "event");
/* 90 */            if (event == Lifecycle.Event.ON_RESUME) {
                        AnkiCardContent$lambda$5($foreground$delegate, true);
                    } else if (event == Lifecycle.Event.ON_PAUSE || event == Lifecycle.Event.ON_DESTROY) {
                        AnkiCardContent$lambda$5($foreground$delegate, false);
                        $audio.close();
/* 283 */               $audioStatus$delegate.setValue("");
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 107 */       public static final Unit AnkiCardContent$lambda$8$2$0(WebView $web, int $zoom) {
/* 108 */           $web.getSettings().setTextZoom($zoom);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 108 */       public static final DisposableEffectResult AnkiCardContent$lambda$8$3$0(final AnkiWebSession $session, final WebView $web, DisposableEffectScope DisposableEffect) {
                    Intrinsics.checkNotNullParameter(DisposableEffect, "$this$DisposableEffect");
/* 293 */           return new DisposableEffectResult() { // from class: com.xunji.flashcards.ui.components.AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1
                        @Override // androidx.compose.runtime.DisposableEffectResult
/* 67 */                public void dispose() {
/* 70 */                    $session.close();
                            $web.stopLoading();
                            $web.onPause();
                            $web.removeAllViews();
                            $web.destroy();
                        }
                    };
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 109 */       public static final WebView AnkiCardContent$lambda$8$4$0(WebView $web, Context it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 110 */           return $web;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 111 */       public static final Unit AnkiCardContent$lambda$8$5$0$0$0(AnkiAudioPlayer $audio, CardMedia $media) {
/* 112 */           $audio.play($media);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 111 */       public static final Unit AnkiCardContent$lambda$8$5$0$1(int $index, CardMedia $media, RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C111@7728L39:AnkiCardContent.kt#8ao140");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1337670609, $changed, -1, "com.xunji.flashcards.ui.components.AnkiCardContent.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiCardContent.kt:111)");
                        }
/* 112 */               TextKt.m3584TextNvy7gAk("播放音频 " + ($index + 1) + " · " + $media.getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

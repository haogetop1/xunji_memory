            package com.xunji.flashcards.ui.components;

            import androidx.core.view.MotionEventCompat;
            import com.xunji.flashcards.anki.CardMedia;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: AnkiCardContent.kt */
            /* JADX INFO: loaded from: classes11.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "Ljava/io/InputStream;", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.components.AnkiWebSession$response$input$1", f = "AnkiCardContent.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_7}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 36 */    final class AnkiWebSession$response$input$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super InputStream>, Object> {
                final /* synthetic */ CardMedia $media;
                int label;
                final /* synthetic */ AnkiWebSession this$0;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                AnkiWebSession$response$input$1(AnkiWebSession ankiWebSession, CardMedia cardMedia, Continuation<? super AnkiWebSession$response$input$1> continuation) {
                    super(2, continuation);
                    this.this$0 = ankiWebSession;
                    this.$media = cardMedia;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new AnkiWebSession$response$input$1(this.this$0, this.$media, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super InputStream> continuation) {
                    return ((AnkiWebSession$response$input$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 37 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
/* 24 */                    Function2 function2 = this.this$0.open;
                            CardMedia cardMedia = this.$media;
                            if (cardMedia == null) {
                                throw new IllegalArgumentException("Required value was null.".toString());
                            }
                            this.label = 1;
                            Object objInvoke = function2.invoke(cardMedia, this);
                            return objInvoke == coroutine_suspended ? coroutine_suspended : objInvoke;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            return $result;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

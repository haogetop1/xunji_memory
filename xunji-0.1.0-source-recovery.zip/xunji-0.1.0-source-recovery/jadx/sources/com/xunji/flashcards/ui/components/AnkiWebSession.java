            package com.xunji.flashcards.ui.components;

            import android.webkit.WebResourceRequest;
            import android.webkit.WebResourceResponse;
            import android.webkit.WebView;
            import android.webkit.WebViewClient;
            import com.xunji.flashcards.anki.CardMedia;
            import com.xunji.flashcards.anki.RenderedCard;
            import java.io.ByteArrayInputStream;
            import java.io.Closeable;
            import java.io.FilterInputStream;
            import java.io.IOException;
            import java.io.InputStream;
            import java.util.LinkedHashSet;
            import java.util.Set;
            import kotlin.Deprecated;
            import kotlin.Metadata;
            import kotlin.Result;
            import kotlin.ResultKt;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.Charsets;
            import kotlinx.coroutines.BuildersKt__BuildersKt;
            
            /* JADX INFO: compiled from: AnkiCardContent.kt */
            /* JADX INFO: loaded from: classes11.dex */
            @Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010#\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\b\u0001\u0018\u0000  2\u00020\u00012\u00020\u0002:\u0001 B5\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012$\u0010\u0005\u001a \b\u0001\u0012\u0004\u0012\u00020\u0007\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\t0\b\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0006¢\u0006\u0004\b\u000b\u0010\fJ\u001c\u0010\u0012\u001a\u00020\u000f2\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u001c\u0010\u0012\u001a\u00020\u000f2\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\b\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0017J\u001c\u0010\u0019\u001a\u00020\u001a2\b\u0010\u0013\u001a\u0004\u0018\u00010\u00142\b\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u001f\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00182\b\b\u0002\u0010\u001c\u001a\u00020\u0018H\u0000¢\u0006\u0002\b\u001dJ\b\u0010\u001e\u001a\u00020\u001fH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004¢\u0006\u0002\n\u0000R.\u0010\u0005\u001a \b\u0001\u0012\u0004\u0012\u00020\u0007\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\t0\b\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0006X\u0082\u0004¢\u0006\u0004\n\u0002\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e¢\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\t0\u0011X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006!"}, d2 = {"Lcom/xunji/flashcards/ui/components/AnkiWebSession;", "Landroid/webkit/WebViewClient;", "Ljava/io/Closeable;", "card", "Lcom/xunji/flashcards/anki/RenderedCard;", "open", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/CardMedia;", "Lkotlin/coroutines/Continuation;", "Ljava/io/InputStream;", "", "<init>", "(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;)V", "Lkotlin/jvm/functions/Function2;", "closed", "", "streams", "", "shouldOverrideUrlLoading", "view", "Landroid/webkit/WebView;", "request", "Landroid/webkit/WebResourceRequest;", "url", "", "shouldInterceptRequest", "Landroid/webkit/WebResourceResponse;", "response", "method", "response$app_debug", "close", "", "Companion", "app_debug"}, k = 1, mv = {2, 2, 0}, xi = 48)
/* 22 */    public final class AnkiWebSession extends WebViewClient implements Closeable {
                public static final String DOCUMENT_URL = "https://anki.xunji.invalid/card.html";
                private final RenderedCard card;
                private boolean closed;
                private final Function2<CardMedia, Continuation<? super InputStream>, Object> open;
                private final Set<InputStream> streams;
                public static final int $stable = 8;

                /* JADX WARN: Multi-variable type inference failed */
/* 23 */        public AnkiWebSession(RenderedCard card, Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> open) {
                    Intrinsics.checkNotNullParameter(card, "card");
                    Intrinsics.checkNotNullParameter(open, "open");
                    this.card = card;
                    this.open = open;
/* 27 */            this.streams = new LinkedHashSet();
                }

                @Override // android.webkit.WebViewClient
/* 27 */        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
/* 28 */            return true;
                }

                @Override // android.webkit.WebViewClient
                @Deprecated(message = "Required for older WebView implementations")
/* 29 */        public boolean shouldOverrideUrlLoading(WebView view, String url) {
/* 30 */            return true;
                }

                @Override // android.webkit.WebViewClient
/* 30 */        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    String method;
/* 31 */            String strValueOf = String.valueOf(request != null ? request.getUrl() : null);
                    if (request == null || (method = request.getMethod()) == null) {
                        method = "";
                    }
                    return response$app_debug(strValueOf, method);
                }

/* 31 */        public static /* synthetic */ WebResourceResponse response$app_debug$default(AnkiWebSession ankiWebSession, String str, String str2, int i, Object obj) {
/* 32 */            if ((i & 2) != 0) {
                        str2 = "GET";
                    }
                    return ankiWebSession.response$app_debug(str, str2);
                }

/* 32 */        private static final WebResourceResponse response$denied() {
/* 33 */            return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", MapsKt.emptyMap(), new ByteArrayInputStream(new byte[0]));
                }

/* 33 */        public final WebResourceResponse response$app_debug(String url, String method) {
                    ByteArrayInputStream byteArrayInputStream;
                    String mime;
                    Intrinsics.checkNotNullParameter(url, "url");
                    Intrinsics.checkNotNullParameter(method, "method");
                    synchronized (this) {
/* 34 */                if (!this.closed && Intrinsics.areEqual(method, "GET")) {
                            CardMedia media = this.card.getMedia().get(url);
/* 35 */                    boolean document = Intrinsics.areEqual(url, DOCUMENT_URL);
/* 36 */                    if (!document && media == null) {
                                return response$denied();
                            }
                            if (document) {
                                byte[] bytes = this.card.getHtml().getBytes(Charsets.UTF_8);
                                Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
                                byteArrayInputStream = new ByteArrayInputStream(bytes);
                            } else {
                                try {
/* 1 */                             byteArrayInputStream = (InputStream) BuildersKt__BuildersKt.runBlocking$default(null, new AnkiWebSession$response$input$1(this, media, null), 1, null);
                                } catch (Exception e) {
                                    byteArrayInputStream = null;
                                }
                                if (byteArrayInputStream == null) {
                                    return response$denied();
                                }
                            }
/* 37 */                    final InputStream input = byteArrayInputStream;
/* 39 */                    FilterInputStream filterInputStream = new FilterInputStream(input) { // from class: com.xunji.flashcards.ui.components.AnkiWebSession$response$tracked$1
                                @Override // java.io.FilterInputStream, java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
/* 39 */                        public void close() throws IOException {
/* 40 */                            AnkiWebSession ankiWebSession = this;
                                    AnkiWebSession ankiWebSession2 = this;
                                    synchronized (ankiWebSession) {
/* 24 */                                ankiWebSession2.streams.remove(this);
                                    }
                                    super.close();
                                }
                            };
                            synchronized (this) {
/* 42 */                        if (this.closed) {
                                    try {
                                        Result.Companion companion = Result.INSTANCE;
                                        AnkiWebSession ankiWebSession = this;
/* 42 */                                input.close();
                                        Result.m9077constructorimpl(Unit.INSTANCE);
                                    } catch (Throwable th) {
                                        Result.Companion companion2 = Result.INSTANCE;
                                        Result.m9077constructorimpl(ResultKt.createFailure(th));
                                    }
                                    return response$denied();
                                }
                                this.streams.add(filterInputStream);
                                Unit unit = Unit.INSTANCE;
                                if (document) {
                                    mime = "text/html";
                                } else {
                                    if (media == null) {
                                        throw new IllegalArgumentException("Required value was null.".toString());
                                    }
                                    mime = media.getMime();
                                }
/* 43 */                        return new WebResourceResponse(mime, document ? "UTF-8" : null, 200, "OK", MapsKt.mapOf(TuplesKt.to("Cache-Control", "no-store"), TuplesKt.to("X-Content-Type-Options", "nosniff")), filterInputStream);
                            }
                        }
/* 34 */                return response$denied();
                    }
                }

                @Override // java.io.Closeable, java.lang.AutoCloseable
/* 44 */        public void close() {
                    synchronized (this) {
/* 45 */                this.closed = true;
                        for (InputStream inputStream : CollectionsKt.toList(this.streams)) {
                            try {
/* 45 */                        Result.Companion companion = Result.INSTANCE;
                                AnkiWebSession ankiWebSession = this;
/* 45 */                        inputStream.close();
                                Result.m9077constructorimpl(Unit.INSTANCE);
                            } catch (Throwable th) {
                                Result.Companion companion2 = Result.INSTANCE;
                                Result.m9077constructorimpl(ResultKt.createFailure(th));
                            }
                        }
/* 45 */                this.streams.clear();
                        Unit unit = Unit.INSTANCE;
                    }
                }
            }

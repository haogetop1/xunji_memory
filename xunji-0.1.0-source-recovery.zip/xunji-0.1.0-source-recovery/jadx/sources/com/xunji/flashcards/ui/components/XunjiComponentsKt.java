            package com.xunji.flashcards.ui.components;

            import androidx.compose.foundation.BackgroundKt;
            import androidx.compose.foundation.BorderStrokeKt;
            import androidx.compose.foundation.CanvasKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.IconButtonKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.ProgressIndicatorKt;
            import androidx.compose.material3.SurfaceKt;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.draw.ClipKt;
            import androidx.compose.ui.geometry.CornerRadius;
            import androidx.compose.ui.geometry.Offset;
            import androidx.compose.ui.geometry.Size;
            import androidx.compose.ui.graphics.AndroidPath_androidKt;
            import androidx.compose.ui.graphics.Path;
            import androidx.compose.ui.graphics.StrokeCap;
            import androidx.compose.ui.graphics.StrokeJoin;
            import androidx.compose.ui.graphics.drawscope.DrawScope;
            import androidx.compose.ui.graphics.drawscope.Stroke;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.semantics.LiveRegionMode;
            import androidx.compose.ui.semantics.SemanticsModifierKt;
            import androidx.compose.ui.semantics.SemanticsPropertiesKt;
            import androidx.compose.ui.semantics.SemanticsPropertyReceiver;
            import androidx.compose.ui.text.TextStyle;
            import androidx.compose.ui.text.font.FontWeight;
            import androidx.compose.ui.unit.Dp;
            import java.time.Instant;
            import java.time.ZoneId;
            import java.time.format.DateTimeFormatter;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: XunjiComponents.kt */
            /* JADX INFO: loaded from: classes11.dex */
            @Metadata(d1 = {"\u0000H\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\t\n\u0002\b\u0006\u001a+\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u0006\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\b\u0010\t\u001a?\u0010\n\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\u00032\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00010\r2\b\b\u0002\u0010\u000e\u001a\u00020\u00032\b\b\u0002\u0010\u000f\u001a\u00020\u0010H\u0007¢\u0006\u0002\u0010\u0011\u001a\u0017\u0010\u0012\u001a\u00020\u00012\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u0010\u0013\u001a\u0015\u0010\u0014\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0016\u001a5\u0010\u0017\u001a\u00020\u00012\b\b\u0002\u0010\u0004\u001a\u00020\u00052\u001c\u0010\u0018\u001a\u0018\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u00010\u0019¢\u0006\u0002\b\u001b¢\u0006\u0002\b\u001cH\u0007¢\u0006\u0002\u0010\u001d\u001aA\u0010\u001e\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00032\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00010\r2\b\b\u0002\u0010\u0004\u001a\u00020\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u00102\b\b\u0002\u0010\u000e\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u001f\u001a\u001f\u0010 \u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00032\b\b\u0002\u0010!\u001a\u00020\u0010H\u0007¢\u0006\u0002\u0010\"\u001a9\u0010#\u001a\u00020\u00012\u0006\u0010$\u001a\u00020\u00032\u0006\u0010%\u001a\u00020\u00032\n\b\u0002\u0010&\u001a\u0004\u0018\u00010\u00032\u000e\b\u0002\u0010'\u001a\b\u0012\u0004\u0012\u00020\u00010\rH\u0007¢\u0006\u0002\u0010(\u001a\r\u0010)\u001a\u00020\u0001H\u0007¢\u0006\u0002\u0010*\u001a!\u0010+\u001a\u00020\u00012\u0006\u0010$\u001a\u00020\u00032\n\b\u0002\u0010,\u001a\u0004\u0018\u00010\u0003H\u0007¢\u0006\u0002\u0010-\u001a'\u0010.\u001a\u00020\u00012\u0006\u0010/\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u0005H\u0007¢\u0006\u0002\u00100\u001a\u0016\u00101\u001a\u00020\u00032\u0006\u00102\u001a\u0002032\u0006\u00104\u001a\u000203\u001a\u000e\u00105\u001a\u00020\u00032\u0006\u00106\u001a\u000203\u001a\u000e\u00107\u001a\u00020\u00032\u0006\u00108\u001a\u000203¨\u00069"}, d2 = {"Glyph", "", "kind", "", "modifier", "Landroidx/compose/ui/Modifier;", "color", "Landroidx/compose/ui/graphics/Color;", "Glyph-FNF3uiM", "(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V", "IconAction", "label", "onClick", "Lkotlin/Function0;", "tag", "enabled", "", "(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V", "Mark", "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "Eyebrow", "text", "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V", "Paper", "content", "Lkotlin/Function1;", "Landroidx/compose/foundation/layout/ColumnScope;", "Landroidx/compose/runtime/Composable;", "Lkotlin/ExtensionFunctionType;", "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V", "PrimaryButton", "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V", "Notice", "error", "(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V", "EmptyState", "title", "description", "action", "onAction", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "Busy", "(Landroidx/compose/runtime/Composer;I)V", "SectionTitle", "subtitle", "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V", "Metric", "value", "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V", "intervalLabel", "dueAt", "", "now", "localTime", "timestamp", "durationLabel", "ms", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 18 */    public final class XunjiComponentsKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Busy$lambda$1(int i, Composer composer, int i2) {
                    Busy(composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit EmptyState$lambda$2(String str, String str2, String str3, Function0 function0, int i, int i2, Composer composer, int i3) {
                    EmptyState(str, str2, str3, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Eyebrow$lambda$0(String str, int i, Composer composer, int i2) {
                    Eyebrow(str, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Glyph_FNF3uiM$lambda$1(String str, Modifier modifier, long j, int i, int i2, Composer composer, int i3) {
                    m8967GlyphFNF3uiM(str, modifier, j, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit IconAction$lambda$2(String str, String str2, Function0 function0, String str3, boolean z, int i, int i2, Composer composer, int i3) {
                    IconAction(str, str2, function0, str3, z, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Mark$lambda$1(Modifier modifier, int i, int i2, Composer composer, int i3) {
                    Mark(modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Metric$lambda$1(String str, String str2, Modifier modifier, int i, int i2, Composer composer, int i3) {
                    Metric(str, str2, modifier, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Notice$lambda$1(String str, boolean z, int i, int i2, Composer composer, int i3) {
                    Notice(str, z, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit Paper$lambda$1(Modifier modifier, Function3 function3, int i, int i2, Composer composer, int i3) {
                    Paper(modifier, function3, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit PrimaryButton$lambda$1(String str, Function0 function0, Modifier modifier, boolean z, String str2, int i, int i2, Composer composer, int i3) {
                    PrimaryButton(str, function0, modifier, z, str2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit SectionTitle$lambda$1(String str, String str2, int i, int i2, Composer composer, int i3) {
                    SectionTitle(str, str2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: Glyph-FNF3uiM, reason: not valid java name */
/* 19 */        public static final void m8967GlyphFNF3uiM(final String kind, Modifier modifier, long j, Composer $composer, final int $changed, final int i) {
                    Modifier modifier2;
                    final long onSurface;
                    final Modifier modifier3;
                    final long j2;
                    Modifier.Companion modifier4;
                    Intrinsics.checkNotNullParameter(kind, "kind");
/* 20 */            Composer $composer2 = $composer.startRestartGroup(-97659243);
                    ComposerKt.sourceInformation($composer2, "C(Glyph)N(kind,modifier,color:c#ui.graphics.Color)20@811L1654,20@782L1683:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(kind) ? 4 : 2;
                    }
                    int i2 = i & 2;
                    if (i2 != 0) {
                        $dirty |= 48;
                        modifier2 = modifier;
                    } else if (($changed & 48) == 0) {
                        modifier2 = modifier;
                        $dirty |= $composer2.changed(modifier2) ? 32 : 16;
                    } else {
                        modifier2 = modifier;
                    }
                    if (($changed & 384) == 0) {
                        if ((i & 4) == 0) {
                            onSurface = j;
                            int i3 = $composer2.changed(onSurface) ? 256 : 128;
                            $dirty |= i3;
                        } else {
                            onSurface = j;
                        }
                        $dirty |= i3;
                    } else {
                        onSurface = j;
                    }
                    if ($composer2.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
                        $composer2.startDefaults();
                        ComposerKt.sourceInformation($composer2, "19@756L11");
                        if (($changed & 1) == 0 || $composer2.getDefaultsInvalid()) {
                            modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                            if ((i & 4) != 0) {
                                onSurface = MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getOnSurface();
                                $dirty &= -897;
                            }
                        } else {
                            $composer2.skipToGroupEnd();
                            if ((i & 4) != 0) {
                                $dirty &= -897;
                            }
                            modifier4 = modifier2;
                        }
                        $composer2.endDefaults();
                        if (ComposerKt.isTraceInProgress()) {
/* 20 */                    ComposerKt.traceEventStart(-97659243, $dirty, -1, "com.xunji.flashcards.ui.components.Glyph (XunjiComponents.kt:19)");
                        }
/* 21 */                Modifier modifierM892size3ABfNKs = SizeKt.m892size3ABfNKs(modifier4, Dp.m8404constructorimpl(24));
                        ComposerKt.sourceInformationMarkerStart($composer2, 638753803, "CC(remember):XunjiComponents.kt#9igjgp");
                        boolean z = (((($dirty & 896) ^ 384) > 256 && $composer2.changed(onSurface)) || ($dirty & 384) == 256) | (($dirty & 14) == 4);
/* 73 */                Object objRememberedValue = $composer2.rememberedValue();
/* 74 */                if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 21 */                    Object obj = new Function1() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return XunjiComponentsKt.Glyph_FNF3uiM$lambda$0$0(kind, onSurface, (DrawScope) obj2);
                                }
                            };
/* 76 */                    $composer2.updateRememberedValue(obj);
/* 77 */                    objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 21 */                CanvasKt.Canvas(modifierM892size3ABfNKs, (Function1) objRememberedValue, $composer2, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                        modifier3 = modifier4;
                        j2 = onSurface;
                    } else {
/* 20 */                $composer2.skipToGroupEnd();
                        modifier3 = modifier2;
                        j2 = onSurface;
                    }
/* 38 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiComponentsKt.Glyph_FNF3uiM$lambda$1(kind, modifier3, j2, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
                /* JADX WARN: Code duplicated, block: B:47:0x030f A[PHI: r4 r5 r6
                  0x030f: PHI (r4v13 'w' float) = 
                  (r4v5 'w' float)
                  (r4v6 'w' float)
                  (r4v7 'w' float)
                  (r4v8 'w' float)
                  (r4v9 'w' float)
                  (r4v10 'w' float)
                  (r4v14 'w' float)
                 binds: [B:46:0x030d, B:42:0x02e1, B:38:0x02b3, B:34:0x0259, B:30:0x0224, B:26:0x01f4, B:18:0x011c] A[DONT_GENERATE, DONT_INLINE]
                  0x030f: PHI (r5v18 'h' float) = 
                  (r5v9 'h' float)
                  (r5v10 'h' float)
                  (r5v11 'h' float)
                  (r5v12 'h' float)
                  (r5v13 'h' float)
                  (r5v14 'h' float)
                  (r5v19 'h' float)
                 binds: [B:46:0x030d, B:42:0x02e1, B:38:0x02b3, B:34:0x0259, B:30:0x0224, B:26:0x01f4, B:18:0x011c] A[DONT_GENERATE, DONT_INLINE]
                  0x030f: PHI (r6v18 'stroke' androidx.compose.ui.graphics.drawscope.Stroke) = 
                  (r6v9 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v10 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v11 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v12 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v13 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v14 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r6v19 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                 binds: [B:46:0x030d, B:42:0x02e1, B:38:0x02b3, B:34:0x0259, B:30:0x0224, B:26:0x01f4, B:18:0x011c] A[DONT_GENERATE, DONT_INLINE]] */
                /* JADX WARN: Code duplicated, block: B:49:0x0375 A[PHI: r13 r14 r15
                  0x0375: PHI (r13v1 's' float) = (r13v0 's' float), (r13v6 's' float), (r13v7 's' float), (r13v0 's' float), (r13v0 's' float) binds: [B:3:0x006a, B:23:0x0159, B:47:0x030f, B:14:0x00e0, B:6:0x0075] A[DONT_GENERATE, DONT_INLINE]
                  0x0375: PHI (r14v1 'h' float) = (r14v0 'h' float), (r14v7 'h' float), (r14v8 'h' float), (r14v0 'h' float), (r14v0 'h' float) binds: [B:3:0x006a, B:23:0x0159, B:47:0x030f, B:14:0x00e0, B:6:0x0075] A[DONT_GENERATE, DONT_INLINE]
                  0x0375: PHI (r15v1 'stroke' androidx.compose.ui.graphics.drawscope.Stroke) = 
                  (r15v0 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r15v3 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r15v4 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r15v0 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                  (r15v0 'stroke' androidx.compose.ui.graphics.drawscope.Stroke)
                 binds: [B:3:0x006a, B:23:0x0159, B:47:0x030f, B:14:0x00e0, B:6:0x0075] A[DONT_GENERATE, DONT_INLINE]] */
/* 21 */        public static final Unit Glyph_FNF3uiM$lambda$0$0(String $kind, long j, DrawScope Canvas) {
                    float w;
                    float h;
                    Stroke stroke;
                    Intrinsics.checkNotNullParameter(Canvas, "$this$Canvas");
/* 268 */           float s = Float.intBitsToFloat((int) (Canvas.mo6239getSizeNHjbRc() >> 32));
/* 268 */           float h2 = Float.intBitsToFloat((int) (Canvas.mo6239getSizeNHjbRc() & 4294967295L));
/* 22 */            Stroke stroke2 = new Stroke(Canvas.mo427toPx0680j_4(Dp.m8404constructorimpl((float) 1.8d)), 0.0f, StrokeCap.INSTANCE.m6031getRoundKaPHkGw(), StrokeJoin.INSTANCE.m6042getRoundLxFBmk8(), null, 18);
                    switch ($kind.hashCode()) {
                        case -1335458389:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("delete")) {
/* 32 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.2f, 0.3f, 0.8f, 0.3f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.35f, 0.15f, 0.65f, 0.15f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.28f, 0.3f, 0.33f, 0.85f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.33f, 0.85f, 0.67f, 0.85f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.67f, 0.85f, 0.72f, 0.3f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.43f, 0.45f, 0.43f, 0.7f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.57f, 0.45f, 0.57f, 0.7f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p = AndroidPath_androidKt.Path();
/* 35 */                        p.moveTo(s * 0.23f, h2 * 0.8f);
                                p.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 96417:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("add")) {
/* 26 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.5f, 0.18f, 0.5f, 0.82f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.18f, 0.5f, 0.82f, 0.5f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p2 = AndroidPath_androidKt.Path();
/* 35 */                        p2.moveTo(s * 0.23f, h2 * 0.8f);
                                p2.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p2.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p2, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 3015911:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("back")) {
/* 25 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.7f, 0.2f, 0.35f, 0.5f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.35f, 0.5f, 0.7f, 0.8f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p3 = AndroidPath_androidKt.Path();
/* 35 */                        p3.moveTo(s * 0.23f, h2 * 0.8f);
                                p3.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p3.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p3, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 3108362:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("edit")) {
/* 31 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.25f, 0.7f, 0.7f, 0.25f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.7f, 0.25f, 0.8f, 0.35f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.8f, 0.35f, 0.35f, 0.8f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.35f, 0.8f, 0.2f, 0.83f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.2f, 0.83f, 0.25f, 0.7f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p4 = AndroidPath_androidKt.Path();
/* 35 */                        p4.moveTo(s * 0.23f, h2 * 0.8f);
                                p4.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p4.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p4, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 93090825:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("arrow")) {
/* 34 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.15f, 0.5f, 0.85f, 0.5f);
/* 34 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.6f, 0.25f, 0.85f, 0.5f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.85f, 0.5f, 0.6f, 0.75f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p5 = AndroidPath_androidKt.Path();
/* 35 */                        p5.moveTo(s * 0.23f, h2 * 0.8f);
                                p5.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p5.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p5, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 94627080:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("check")) {
/* 33 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.2f, 0.5f, 0.42f, 0.72f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.42f, 0.72f, 0.8f, 0.28f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p6 = AndroidPath_androidKt.Path();
/* 35 */                        p6.moveTo(s * 0.23f, h2 * 0.8f);
                                p6.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p6.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p6, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 95459562:
                            if ($kind.equals("decks")) {
/* 272 */                       long jM5408constructorimpl = Offset.m5408constructorimpl((((long) Float.floatToRawIntBits(s * 0.12f)) << 32) | (((long) Float.floatToRawIntBits(h2 * 0.23f)) & 4294967295L));
/* 276 */                       long jM5476constructorimpl = Size.m5476constructorimpl((((long) Float.floatToRawIntBits(s * 0.65f)) << 32) | (((long) Float.floatToRawIntBits(h2 * 0.65f)) & 4294967295L));
/* 28 */                        float f = s * 0.1f;
/* 28 */                        DrawScope.m6235drawRoundRectuAw5IA$default(Canvas, j, jM5408constructorimpl, jM5476constructorimpl, CornerRadius.m5370constructorimpl((((long) Float.floatToRawIntBits(f)) << 32) | (((long) Float.floatToRawIntBits(f)) & 4294967295L)), stroke2, 0.0f, null, 0, 224, null);
/* 24 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.3f, 0.12f, 0.85f, 0.12f);
/* 24 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.88f, 0.15f, 0.88f, 0.65f);
                            } else {
/* 24 */                        s = s;
                                h2 = h2;
                                stroke2 = stroke2;
/* 35 */                        Path p7 = AndroidPath_androidKt.Path();
/* 35 */                        p7.moveTo(s * 0.23f, h2 * 0.8f);
                                p7.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p7.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p7, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 109757599:
/* 24 */                    w = s;
                            h = h2;
                            stroke = stroke2;
                            if ($kind.equals("stats")) {
/* 29 */                        Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.2f, 0.82f, 0.2f, 0.52f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.5f, 0.82f, 0.5f, 0.2f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w, h, stroke, 0.8f, 0.82f, 0.8f, 0.4f);
                            } else {
                                s = w;
                                h2 = h;
                                stroke2 = stroke;
/* 35 */                        Path p8 = AndroidPath_androidKt.Path();
/* 35 */                        p8.moveTo(s * 0.23f, h2 * 0.8f);
                                p8.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p8.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p8, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 110534465:
/* 24 */                    if ($kind.equals("today")) {
/* 27 */                        DrawScope.m6220drawCircleVaOC9Bg$default(Canvas, j, s * 0.32f, 0L, 0.0f, stroke2, null, 0, 108, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.5f, 0.3f, 0.5f, 0.5f);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.5f, 0.5f, 0.66f, 0.58f);
                            } else {
/* 35 */                        Path p9 = AndroidPath_androidKt.Path();
/* 35 */                        p9.moveTo(s * 0.23f, h2 * 0.8f);
                                p9.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p9.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p9, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        case 1434631203:
                            if ($kind.equals("settings")) {
/* 30 */                        DrawScope.m6220drawCircleVaOC9Bg$default(Canvas, j, s * 0.31f, 0L, 0.0f, stroke2, null, 0, 108, null);
                                DrawScope.m6220drawCircleVaOC9Bg$default(Canvas, j, s * 0.1f, 0L, 0.0f, stroke2, null, 0, 108, null);
                                for (int i = 0; i < 8; i++) {
                                    double a = (((double) i) * 3.141592653589793d) / ((double) 4);
                                    float c = (float) Math.cos(a);
                                    float s2 = (float) Math.sin(a);
                                    float w2 = s;
                                    Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, w2, h2, stroke2, (c * 0.32f) + 0.5f, (s2 * 0.32f) + 0.5f, (c * 0.43f) + 0.5f, (0.43f * s2) + 0.5f);
                                    s = w2;
                                }
                            } else {
/* 35 */                        Path p10 = AndroidPath_androidKt.Path();
/* 35 */                        p10.moveTo(s * 0.23f, h2 * 0.8f);
                                p10.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                                p10.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                                DrawScope.m6229drawPathLG529CI$default(Canvas, p10, j, 0.0f, stroke2, null, 0, 52, null);
                                Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            }
                            break;
                        default:
/* 35 */                    Path p11 = AndroidPath_androidKt.Path();
/* 35 */                    p11.moveTo(s * 0.23f, h2 * 0.8f);
                            p11.cubicTo(s * 0.1f, 0.25f * h2, s * 0.8f, 0.18f * h2, 0.82f * s, 0.16f * h2);
                            p11.cubicTo(0.86f * s, 0.7f * h2, 0.44f * s, 0.85f * h2, s * 0.23f, h2 * 0.8f);
                            DrawScope.m6229drawPathLG529CI$default(Canvas, p11, j, 0.0f, stroke2, null, 0, 52, null);
                            Glyph_FNF3uiM$lambda$0$0$line(Canvas, j, s, h2, stroke2, 0.24f, 0.8f, 0.67f, 0.38f);
                            break;
                    }
/* 37 */            return Unit.INSTANCE;
                }

/* 22 */        private static final void Glyph_FNF3uiM$lambda$0$0$line(DrawScope $this_Canvas, long j, float w, float h, Stroke stroke, float x1, float y1, float x2, float y2) {
/* 23 */            DrawScope.m6225drawLineNGM6Ib0$default($this_Canvas, j, Offset.m5408constructorimpl((((long) Float.floatToRawIntBits(x1 * w)) << 32) | (((long) Float.floatToRawIntBits(y1 * h)) & 4294967295L)), Offset.m5408constructorimpl((((long) Float.floatToRawIntBits(x2 * w)) << 32) | (((long) Float.floatToRawIntBits(y2 * h)) & 4294967295L)), stroke.getWidth(), StrokeCap.INSTANCE.m6031getRoundKaPHkGw(), null, 0.0f, null, 0, 480, null);
                }

/* 38 */        public static final void IconAction(final String kind, final String label, final Function0<Unit> onClick, String tag, boolean enabled, Composer $composer, final int $changed, final int i) {
                    String str;
                    final boolean enabled2;
                    final String tag2;
                    final boolean enabled3;
                    Intrinsics.checkNotNullParameter(kind, "kind");
                    Intrinsics.checkNotNullParameter(label, "label");
                    Intrinsics.checkNotNullParameter(onClick, "onClick");
/* 39 */            Composer $composer2 = $composer.startRestartGroup(-446375998);
                    ComposerKt.sourceInformation($composer2, "C(IconAction)N(kind,label,onClick,tag,enabled)39@2699L28,39@2729L107,39@2576L260:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(kind) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changed(label) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer2.changedInstance(onClick) ? 256 : 128;
                    }
                    int i2 = i & 8;
                    if (i2 != 0) {
                        $dirty |= 3072;
                        str = tag;
                    } else if (($changed & 3072) == 0) {
                        str = tag;
                        $dirty |= $composer2.changed(str) ? 2048 : 1024;
                    } else {
                        str = tag;
                    }
                    int i3 = i & 16;
                    if (i3 != 0) {
                        $dirty |= 24576;
                        enabled2 = enabled;
                    } else if (($changed & 24576) == 0) {
                        enabled2 = enabled;
                        $dirty |= $composer2.changed(enabled2) ? 16384 : 8192;
                    } else {
                        enabled2 = enabled;
                    }
                    int $dirty2 = $dirty;
                    if ($composer2.shouldExecute(($dirty2 & 9363) != 9362, $dirty2 & 1)) {
                        String tag3 = i2 != 0 ? "" : str;
                        if (i3 != 0) {
                            enabled2 = true;
                        }
                        if (ComposerKt.isTraceInProgress()) {
/* 39 */                    ComposerKt.traceEventStart(-446375998, $dirty2, -1, "com.xunji.flashcards.ui.components.IconAction (XunjiComponents.kt:38)");
                        }
/* 40 */                Modifier modifierTestTag = TestTagKt.testTag(SizeKt.m896sizeInqDBjuR0$default(Modifier.INSTANCE, Dp.m8404constructorimpl(48), Dp.m8404constructorimpl(48), 0.0f, 0.0f, 12, null), tag3);
                        ComposerKt.sourceInformationMarkerStart($composer2, 529402558, "CC(remember):XunjiComponents.kt#9igjgp");
                        boolean z = ($dirty2 & 112) == 32;
/* 80 */                Object objRememberedValue = $composer2.rememberedValue();
/* 81 */                if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 40 */                    Object obj = new Function1() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda11
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return XunjiComponentsKt.IconAction$lambda$0$0(label, (SemanticsPropertyReceiver) obj2);
                                }
                            };
/* 83 */                    $composer2.updateRememberedValue(obj);
/* 84 */                    objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                        String tag4 = tag3;
                        enabled3 = enabled2;
/* 40 */                IconButtonKt.IconButton(onClick, SemanticsModifierKt.semantics$default(modifierTestTag, false, (Function1) objRememberedValue, 1, null), enabled3, null, null, null, ComposableLambdaKt.rememberComposableLambda(2049806304, true, new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiComponentsKt.IconAction$lambda$1(kind, enabled2, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer2, 54), $composer2, (($dirty2 >> 6) & 14) | 1572864 | (($dirty2 >> 6) & 896), 56);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 41 */                tag2 = tag4;
                    } else {
/* 39 */                $composer2.skipToGroupEnd();
                        tag2 = str;
                        enabled3 = enabled2;
                    }
/* 41 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda13
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiComponentsKt.IconAction$lambda$2(kind, label, onClick, tag2, enabled3, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit IconAction$lambda$0$0(String $label, SemanticsPropertyReceiver semantics) {
                    Intrinsics.checkNotNullParameter(semantics, "$this$semantics");
/* 40 */            SemanticsPropertiesKt.setContentDescription(semantics, $label);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit IconAction$lambda$1(String $kind, boolean $enabled, Composer $composer, int $changed) {
                    long outline;
                    ComposerKt.sourceInformation($composer, "C39@2731L103:XunjiComponents.kt#8ao140");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2049806304, $changed, -1, "com.xunji.flashcards.ui.components.IconAction.<anonymous> (XunjiComponents.kt:39)");
                        }
/* 40 */                if ($enabled) {
                            $composer.startReplaceGroup(-1526128919);
                            ComposerKt.sourceInformation($composer, "39@2773L11");
                            outline = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnSurface();
                        } else {
                            $composer.startReplaceGroup(-1526127609);
                            ComposerKt.sourceInformation($composer, "39@2814L11");
                            outline = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOutline();
                        }
                        $composer.endReplaceGroup();
                        m8967GlyphFNF3uiM($kind, null, outline, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:42:0x01c0  */
/* 41 */        public static final void Mark(Modifier modifier, Composer $composer, final int $changed, final int i) {
                    final Modifier modifier2;
                    Composer $composer2;
                    Function0<ComposeUiNode> function0;
                    Modifier modifier3;
                    Composer $composer3 = $composer.startRestartGroup(1328119386);
                    ComposerKt.sourceInformation($composer3, "C(Mark)N(modifier)42@2973L11,42@2891L197:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    int i2 = i & 1;
                    if (i2 != 0) {
                        $dirty |= 6;
                        modifier2 = modifier;
                    } else if (($changed & 6) == 0) {
                        modifier2 = modifier;
                        $dirty |= $composer3.changed(modifier2) ? 4 : 2;
                    } else {
                        modifier2 = modifier;
                    }
                    if ($composer3.shouldExecute(($dirty & 3) != 2, $dirty & 1)) {
                        Modifier.Companion modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1328119386, $dirty, -1, "com.xunji.flashcards.ui.components.Mark (XunjiComponents.kt:41)");
                        }
/* 43 */                Modifier modifierM265backgroundbw27NRU$default = BackgroundKt.m265backgroundbw27NRU$default(ClipKt.clip(SizeKt.m892size3ABfNKs(modifier4, Dp.m8404constructorimpl(40)), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(14))), MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getPrimary(), null, 2, null);
                        Alignment center = Alignment.INSTANCE.getCenter();
/* 87 */                ComposerKt.sourceInformationMarkerStart($composer3, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 91 */                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
/* 96 */                ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 97 */                int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 98 */                CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
/* 92 */                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifierM265backgroundbw27NRU$default);
/* 101 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                        $composer2 = $composer3;
/* 95 */                int i3 = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 103 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 104 */               $composer3.startReusableNode();
/* 105 */               if ($composer3.getInserting()) {
/* 106 */                   function0 = constructor;
                            $composer3.createNode(function0);
                        } else {
/* 108 */                   function0 = constructor;
                            $composer3.useNode();
                        }
/* 110 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer3);
/* 111 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 112 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 113 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 115 */               if (composerM4979constructorimpl.getInserting()) {
                            modifier3 = modifier4;
                        } else {
                            modifier3 = modifier4;
/* 99 */                    if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 120 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 122 */                   int i4 = (i3 >> 6) & 14;
/* 93 */                    ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i5 = ((48 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer3, -90078196, "C42@3064L11,42@3031L55:XunjiComponents.kt#8ao140");
                            m8967GlyphFNF3uiM("leaf", null, MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getOnPrimary(), $composer3, 6, 2);
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 93 */                    ComposerKt.sourceInformationMarkerEnd($composer3);
/* 123 */                   $composer3.endNode();
/* 102 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 96 */                    ComposerKt.sourceInformationMarkerEnd($composer3);
/* 87 */                    ComposerKt.sourceInformationMarkerEnd($composer3);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 44 */                    modifier2 = modifier3;
                        }
/* 114 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 117 */               composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 120 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 122 */               int i6 = (i3 >> 6) & 14;
/* 93 */                ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i7 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, -90078196, "C42@3064L11,42@3031L55:XunjiComponents.kt#8ao140");
                        m8967GlyphFNF3uiM("leaf", null, MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getOnPrimary(), $composer3, 6, 2);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 93 */                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 123 */               $composer3.endNode();
/* 102 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 96 */                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 87 */                ComposerKt.sourceInformationMarkerEnd($composer3);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 44 */                modifier2 = modifier3;
                    } else {
/* 42 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
/* 44 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
/* 42 */                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Mark$lambda$1(modifier2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

/* 44 */        public static final void Eyebrow(final String text, Composer $composer, final int $changed) {
                    Composer $composer2;
                    Intrinsics.checkNotNullParameter(text, "text");
/* 45 */            Composer $composer3 = $composer.startRestartGroup(1145422548);
                    ComposerKt.sourceInformation($composer3, "C(Eyebrow)N(text)44@3160L10,44@3203L11,44@3130L102:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer3.changed(text) ? 4 : 2;
                    }
                    if ($composer3.shouldExecute(($dirty & 3) != 2, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 45 */                    ComposerKt.traceEventStart(1145422548, $dirty, -1, "com.xunji.flashcards.ui.components.Eyebrow (XunjiComponents.kt:44)");
                        }
                        $composer2 = $composer3;
                        TextKt.m3584TextNvy7gAk(text, null, MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getOnSurfaceVariant(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer3, MaterialTheme.$stable).getLabelMedium(), $composer2, $dirty & 14, 0, 131066);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Eyebrow$lambda$0(text, $changed, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

/* 45 */        public static final void Paper(Modifier modifier, final Function3<? super ColumnScope, ? super Composer, ? super Integer, Unit> content, Composer $composer, final int $changed, final int i) {
                    Modifier modifier2;
                    final Modifier modifier3;
                    Intrinsics.checkNotNullParameter(content, "content");
/* 46 */            Composer $composer2 = $composer.startRestartGroup(-1616263017);
                    ComposerKt.sourceInformation($composer2, "C(Paper)N(modifier,content)46@3398L11,46@3457L11,46@3486L99,46@3329L256:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    int i2 = i & 1;
                    if (i2 != 0) {
                        $dirty |= 6;
                        modifier2 = modifier;
                    } else if (($changed & 6) == 0) {
                        modifier2 = modifier;
                        $dirty |= $composer2.changed(modifier2) ? 4 : 2;
                    } else {
                        modifier2 = modifier;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(content) ? 32 : 16;
                    }
                    if ($composer2.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
                        Modifier.Companion modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                        if (ComposerKt.isTraceInProgress()) {
/* 46 */                    ComposerKt.traceEventStart(-1616263017, $dirty, -1, "com.xunji.flashcards.ui.components.Paper (XunjiComponents.kt:45)");
                        }
                        int i3 = ($dirty & 14) | 12582912;
                        modifier3 = modifier4;
/* 47 */                SurfaceKt.m3412SurfaceT9BRK9s(modifier3, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(24)), MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getSurface(), 0L, 0.0f, 0.0f, BorderStrokeKt.m295BorderStrokecXLIe8U(Dp.m8404constructorimpl(1), MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getOutlineVariant()), ComposableLambdaKt.rememberComposableLambda(-614467364, true, new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Paper$lambda$0(content, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, $composer2, 54), $composer2, i3, 56);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2.skipToGroupEnd();
                        modifier3 = modifier2;
                    }
/* 48 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda17
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Paper$lambda$1(modifier3, content, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 46 */        public static final Unit Paper$lambda$0(Function3 $content, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C46@3488L95:XunjiComponents.kt#8ao140");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-614467364, $changed, -1, "com.xunji.flashcards.ui.components.Paper.<anonymous> (XunjiComponents.kt:46)");
                        }
/* 47 */                Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(22));
/* 47 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(16));
/* 284 */               ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 288 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
/* 293 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 294 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 295 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 296 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 298 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 292 */               int i = ((((54 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 300 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 301 */               $composer.startReusableNode();
/* 302 */               if ($composer.getInserting()) {
/* 303 */                   $composer.createNode(constructor);
                        } else {
/* 305 */                   $composer.useNode();
                        }
/* 307 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 308 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 309 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 310 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 312 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 311 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 314 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 317 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 319 */               int i2 = (i >> 6) & 14;
/* 290 */               ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        $content.invoke(ColumnScopeInstance.INSTANCE, $composer, Integer.valueOf(((54 >> 6) & 112) | 6));
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 320 */               $composer.endNode();
/* 299 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 293 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 284 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

/* 48 */        public static final void PrimaryButton(final String text, final Function0<Unit> onClick, Modifier modifier, boolean enabled, String tag, Composer $composer, final int $changed, final int i) {
                    Modifier modifier2;
                    boolean enabled2;
                    String str;
                    final Modifier modifier3;
                    final boolean enabled3;
                    final String tag2;
                    Intrinsics.checkNotNullParameter(text, "text");
                    Intrinsics.checkNotNullParameter(onClick, "onClick");
/* 49 */            Composer $composer2 = $composer.startRestartGroup(539657811);
                    ComposerKt.sourceInformation($composer2, "C(PrimaryButton)N(text,onClick,modifier,enabled,tag)49@3876L56,49@3713L219:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(text) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(onClick) ? 32 : 16;
                    }
                    int i2 = i & 4;
                    if (i2 != 0) {
                        $dirty |= 384;
                        modifier2 = modifier;
                    } else if (($changed & 384) == 0) {
                        modifier2 = modifier;
                        $dirty |= $composer2.changed(modifier2) ? 256 : 128;
                    } else {
                        modifier2 = modifier;
                    }
                    int i3 = i & 8;
                    if (i3 != 0) {
                        $dirty |= 3072;
                        enabled2 = enabled;
                    } else if (($changed & 3072) == 0) {
                        enabled2 = enabled;
                        $dirty |= $composer2.changed(enabled2) ? 2048 : 1024;
                    } else {
                        enabled2 = enabled;
                    }
                    int i4 = i & 16;
                    if (i4 != 0) {
                        $dirty |= 24576;
                        str = tag;
                    } else if (($changed & 24576) == 0) {
                        str = tag;
                        $dirty |= $composer2.changed(str) ? 16384 : 8192;
                    } else {
                        str = tag;
                    }
                    int $dirty2 = $dirty;
                    if ($composer2.shouldExecute(($dirty2 & 9363) != 9362, $dirty2 & 1)) {
                        Modifier.Companion modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                        if (i3 != 0) {
                            enabled2 = true;
                        }
                        String tag3 = i4 != 0 ? "" : str;
                        if (ComposerKt.isTraceInProgress()) {
/* 49 */                    ComposerKt.traceEventStart(539657811, $dirty2, -1, "com.xunji.flashcards.ui.components.PrimaryButton (XunjiComponents.kt:48)");
                        }
                        String tag4 = tag3;
                        Modifier modifier5 = modifier4;
                        enabled3 = enabled2;
/* 50 */                ButtonKt.Button(onClick, TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(modifier4, 0.0f, 1, null), Dp.m8404constructorimpl(56), 0.0f, 2, null), tag3), enabled3, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(18)), null, null, null, PaddingKt.m834PaddingValuesYgX7TsA(Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(15)), null, ComposableLambdaKt.rememberComposableLambda(-60214173, true, new Function3() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda14
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return XunjiComponentsKt.PrimaryButton$lambda$0(text, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer2, 54), $composer2, (($dirty2 >> 3) & 14) | 817889280 | (($dirty2 >> 3) & 896), 368);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 51 */                tag2 = tag4;
                        modifier3 = modifier5;
                    } else {
/* 49 */                $composer2.skipToGroupEnd();
                        modifier3 = modifier2;
                        enabled3 = enabled2;
                        tag2 = str;
                    }
/* 51 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.PrimaryButton$lambda$1(text, onClick, modifier3, enabled3, tag2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit PrimaryButton$lambda$0(String $text, RowScope Button, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Button, "$this$Button");
                    ComposerKt.sourceInformation($composer, "C49@3908L10,49@3878L52:XunjiComponents.kt#8ao140");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-60214173, $changed, -1, "com.xunji.flashcards.ui.components.PrimaryButton.<anonymous> (XunjiComponents.kt:49)");
                        }
/* 50 */                TextKt.m3584TextNvy7gAk($text, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getLabelLarge(), $composer, 0, 0, 131070);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

/* 51 */        public static final void Notice(final String text, boolean error, Composer $composer, final int $changed, final int i) {
                    final boolean error2;
                    Composer $composer2;
                    long onSurfaceVariant;
                    Intrinsics.checkNotNullParameter(text, "text");
/* 52 */            Composer $composer3 = $composer.startRestartGroup(1719383493);
                    ComposerKt.sourceInformation($composer3, "C(Notice)N(text,error)52@4024L10,52@4169L36,52@3994L212:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer3.changed(text) ? 4 : 2;
                    }
                    int i2 = i & 2;
                    if (i2 != 0) {
                        $dirty |= 48;
                        error2 = error;
                    } else if (($changed & 48) == 0) {
                        error2 = error;
                        $dirty |= $composer3.changed(error2) ? 32 : 16;
                    } else {
                        error2 = error;
                    }
                    if (!$composer3.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
/* 52 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    } else {
                        boolean error3 = i2 != 0 ? false : error2;
                        if (ComposerKt.isTraceInProgress()) {
/* 52 */                    ComposerKt.traceEventStart(1719383493, $dirty, -1, "com.xunji.flashcards.ui.components.Notice (XunjiComponents.kt:51)");
                        }
/* 53 */                TextStyle bodyMedium = MaterialTheme.INSTANCE.getTypography($composer3, MaterialTheme.$stable).getBodyMedium();
                        if (error3) {
                            $composer3.startReplaceGroup(-1234867702);
                            ComposerKt.sourceInformation($composer3, "52@4075L11");
                            onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getError();
                        } else {
                            $composer3.startReplaceGroup(-1234866507);
                            ComposerKt.sourceInformation($composer3, "52@4112L11");
                            onSurfaceVariant = MaterialTheme.INSTANCE.getColorScheme($composer3, MaterialTheme.$stable).getOnSurfaceVariant();
                        }
                        $composer3.endReplaceGroup();
                        Modifier.Companion companion = Modifier.INSTANCE;
                        ComposerKt.sourceInformationMarkerStart($composer3, -1234865047, "CC(remember):XunjiComponents.kt#9igjgp");
/* 129 */               Object objRememberedValue = $composer3.rememberedValue();
/* 130 */               if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj = new Function1() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda3
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return XunjiComponentsKt.Notice$lambda$0$0((SemanticsPropertyReceiver) obj2);
                                }
                            };
/* 132 */                   $composer3.updateRememberedValue(obj);
/* 133 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                        $composer2 = $composer3;
/* 53 */                TextKt.m3584TextNvy7gAk(text, SemanticsModifierKt.semantics$default(companion, false, (Function1) objRememberedValue, 1, null), onSurfaceVariant, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, bodyMedium, $composer2, $dirty & 14, 0, 131064);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 54 */                error2 = error3;
                    }
/* 54 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiComponentsKt.Notice$lambda$1(text, error2, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 52 */        public static final Unit Notice$lambda$0$0(SemanticsPropertyReceiver semantics) {
                    Intrinsics.checkNotNullParameter(semantics, "$this$semantics");
/* 53 */            SemanticsPropertiesKt.m7603setLiveRegionhR3wRGc(semantics, LiveRegionMode.INSTANCE.m7577getPolite0phEisY());
                    return Unit.INSTANCE;
                }

/* 54 */        public static final void EmptyState(final String title, final String description, String action, Function0<Unit> function0, Composer $composer, final int $changed, final int i) {
                    String str;
                    final Function0<Unit> function1;
                    final String action2;
                    final Function0<Unit> function2;
                    Intrinsics.checkNotNullParameter(title, "title");
                    Intrinsics.checkNotNullParameter(description, "description");
/* 55 */            Composer $composer2 = $composer.startRestartGroup(-1497281943);
                    ComposerKt.sourceInformation($composer2, "C(EmptyState)N(title,description,action,onAction)54@4306L2,55@4344L355,55@4313L386:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(title) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changed(description) ? 32 : 16;
                    }
                    int i2 = i & 4;
                    if (i2 != 0) {
                        $dirty |= 384;
                        str = action;
                    } else if (($changed & 384) == 0) {
                        str = action;
                        $dirty |= $composer2.changed(str) ? 256 : 128;
                    } else {
                        str = action;
                    }
                    int i3 = i & 8;
                    if (i3 != 0) {
                        $dirty |= 3072;
                        function1 = function0;
                    } else if (($changed & 3072) == 0) {
                        function1 = function0;
                        $dirty |= $composer2.changedInstance(function1) ? 2048 : 1024;
                    } else {
                        function1 = function0;
                    }
                    int $dirty2 = $dirty;
                    if (!$composer2.shouldExecute(($dirty2 & 1171) != 1170, $dirty2 & 1)) {
/* 55 */                $composer2.skipToGroupEnd();
                        action2 = str;
                        function2 = function1;
                    } else {
                        action2 = i2 != 0 ? null : str;
                        if (i3 != 0) {
                            ComposerKt.sourceInformationMarkerStart($composer2, -73900341, "CC(remember):XunjiComponents.kt#9igjgp");
/* 135 */                   Object objRememberedValue = $composer2.rememberedValue();
/* 136 */                   if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                Object obj = new Function0() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda18
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
/* 55 */                                return Unit.INSTANCE;
                                    }
                                };
/* 138 */                       $composer2.updateRememberedValue(obj);
/* 139 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 55 */                    function1 = (Function0) objRememberedValue;
                        }
                        if (ComposerKt.isTraceInProgress()) {
/* 55 */                    ComposerKt.traceEventStart(-1497281943, $dirty2, -1, "com.xunji.flashcards.ui.components.EmptyState (XunjiComponents.kt:54)");
                        }
/* 56 */                Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(1541628313, true, new Function3() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                return XunjiComponentsKt.EmptyState$lambda$1(title, description, action2, function1, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }, $composer2, 54), $composer2, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 61 */                function2 = function1;
                    }
/* 61 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return XunjiComponentsKt.EmptyState$lambda$2(title, description, action2, function2, $changed, i, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 56 */        public static final Unit EmptyState$lambda$1(String $title, String $description, String $action, Function0 $onAction, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C56@4430L11,56@4348L219,57@4601L10,57@4570L57,57@4628L19:XunjiComponents.kt#8ao140");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1541628313, $changed, -1, "com.xunji.flashcards.ui.components.EmptyState.<anonymous> (XunjiComponents.kt:56)");
                        }
/* 57 */                Modifier modifierM265backgroundbw27NRU$default = BackgroundKt.m265backgroundbw27NRU$default(ClipKt.clip(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(64)), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(22))), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimaryContainer(), null, 2, null);
                        Alignment center = Alignment.INSTANCE.getCenter();
/* 325 */               ComposerKt.sourceInformationMarkerStart($composer, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 329 */               MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
/* 334 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 335 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 336 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 337 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM265backgroundbw27NRU$default);
/* 339 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 333 */               int i = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 341 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 342 */               $composer.startReusableNode();
/* 343 */               if ($composer.getInserting()) {
/* 344 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 346 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 348 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 349 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 350 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 351 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 353 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 352 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 355 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 358 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 360 */               int i2 = (i >> 6) & 14;
/* 331 */               ComposerKt.sourceInformationMarkerStart($composer, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                        int i3 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -1461213620, "C56@4545L11,56@4497L68:XunjiComponents.kt#8ao140");
/* 57 */                m8967GlyphFNF3uiM("leaf", SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(32)), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), $composer, 54, 0);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 331 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 361 */               $composer.endNode();
/* 340 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 334 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 325 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 58 */                TextKt.m3584TextNvy7gAk($title, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getHeadlineMedium(), $composer, 0, 0, 131070);
                        Notice($description, false, $composer, 0, 2);
/* 59 */                if ($action != null) {
                            $composer.startReplaceGroup(-258897993);
                            ComposerKt.sourceInformation($composer, "58@4666L30");
                            PrimaryButton($action, $onAction, null, false, null, $composer, 0, 28);
                        } else {
                            $composer.startReplaceGroup(559466217);
                        }
                        $composer.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 60 */            return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:28:0x0177  */
/* 61 */        public static final void Busy(Composer $composer, final int $changed) {
                    Composer $composer2;
                    int i;
                    Composer $composer3 = $composer.startRestartGroup(876982327);
                    ComposerKt.sourceInformation($composer3, "C(Busy)61@4727L130:XunjiComponents.kt#8ao140");
/* 62 */            if ($composer3.shouldExecute($changed != 0, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 62 */                    ComposerKt.traceEventStart(876982327, $changed, -1, "com.xunji.flashcards.ui.components.Busy (XunjiComponents.kt:61)");
                        }
                        Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Alignment center = Alignment.INSTANCE.getCenter();
/* 141 */               ComposerKt.sourceInformationMarkerStart($composer3, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 145 */               MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
/* 150 */               ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 151 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 152 */               CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
/* 153 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifierFillMaxSize$default);
/* 155 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 149 */               int i2 = ((((54 << 3) & 112) << 6) & 896) | 6;
                        $composer2 = $composer3;
                        ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 157 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 158 */               $composer3.startReusableNode();
/* 159 */               if ($composer3.getInserting()) {
/* 160 */                   $composer3.createNode(constructor);
                        } else {
/* 162 */                   $composer3.useNode();
                        }
/* 164 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer3);
/* 165 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 166 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 167 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 169 */               if (composerM4979constructorimpl.getInserting()) {
                            i = iHashCode;
                        } else {
                            i = iHashCode;
/* 168 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(i))) {
                            }
/* 174 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 176 */                   int i3 = (i2 >> 6) & 14;
/* 147 */                   ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i4 = ((54 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer3, 85132326, "C61@4791L64:XunjiComponents.kt#8ao140");
/* 62 */                    ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(32)), 0L, Dp.m8404constructorimpl(3), 0L, 0, 0.0f, $composer3, 390, 58);
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 147 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 178 */                   $composer3.endNode();
/* 156 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 150 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 141 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 168 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(i));
/* 171 */               composerM4979constructorimpl.apply(Integer.valueOf(i), setCompositeKeyHash);
/* 174 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 176 */               int i5 = (i2 >> 6) & 14;
/* 147 */               ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                        int i6 = ((54 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, 85132326, "C61@4791L64:XunjiComponents.kt#8ao140");
/* 62 */                ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(32)), 0L, Dp.m8404constructorimpl(3), 0L, 0, 0.0f, $composer3, 390, 58);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 147 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 178 */               $composer3.endNode();
/* 156 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 150 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 141 */               ComposerKt.sourceInformationMarkerEnd($composer3);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 62 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
/* 62 */                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda5
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Busy$lambda$1($changed, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

/* 62 */        public static final void SectionTitle(String title, String subtitle, Composer $composer, final int $changed, final int i) {
                    String str;
                    Composer $composer2;
                    final String subtitle2;
                    final String title2 = title;
                    Intrinsics.checkNotNullParameter(title2, "title");
/* 63 */            Composer $composer3 = $composer.startRestartGroup(-1109360613);
                    ComposerKt.sourceInformation($composer3, "C(SectionTitle)N(title,subtitle)62@4927L150:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer3.changed(title2) ? 4 : 2;
                    }
                    int i2 = i & 2;
                    if (i2 != 0) {
                        $dirty |= 48;
                        str = subtitle;
                    } else if (($changed & 48) == 0) {
                        str = subtitle;
                        $dirty |= $composer3.changed(str) ? 32 : 16;
                    } else {
                        str = subtitle;
                    }
                    if ($composer3.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
                        String subtitle3 = i2 != 0 ? null : str;
                        if (ComposerKt.isTraceInProgress()) {
/* 63 */                    ComposerKt.traceEventStart(-1109360613, $dirty, -1, "com.xunji.flashcards.ui.components.SectionTitle (XunjiComponents.kt:62)");
                        }
/* 63 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(5));
/* 183 */               ComposerKt.sourceInformationMarkerStart($composer3, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 184 */               Modifier modifier = Modifier.INSTANCE;
/* 189 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer3, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 194 */               ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 195 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 196 */               CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
/* 197 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifier);
/* 199 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 190 */               int i3 = ((((48 << 3) & 112) << 6) & 896) | 6;
/* 200 */               ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 201 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 202 */               $composer3.startReusableNode();
/* 203 */               if ($composer3.getInserting()) {
/* 204 */                   $composer3.createNode(constructor);
                        } else {
/* 206 */                   $composer3.useNode();
                        }
/* 208 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer3);
/* 209 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 210 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 211 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 213 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 212 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 215 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 218 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 220 */               int i4 = (i3 >> 6) & 14;
/* 191 */               ComposerKt.sourceInformationMarkerStart($composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                        int i5 = ((48 >> 6) & 112) | 6;
/* 63 */                ComposerKt.sourceInformationMarkerStart($composer3, -1968643773, "C62@5015L10,62@4984L56:XunjiComponents.kt#8ao140");
                        int $dirty2 = $dirty;
                        $composer2 = $composer3;
                        title2 = title;
                        TextKt.m3584TextNvy7gAk(title2, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer3, MaterialTheme.$stable).getHeadlineLarge(), $composer3, $dirty & 14, 0, 131070);
                        subtitle2 = subtitle3;
                        if (subtitle2 != null) {
                            $composer3.startReplaceGroup(2014707669);
                            ComposerKt.sourceInformation($composer3, "62@5059L16");
                            Notice(subtitle2, false, $composer3, ($dirty2 >> 3) & 14, 2);
                        } else {
                            $composer3.startReplaceGroup(-1973591715);
                        }
                        $composer3.endReplaceGroup();
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 191 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 221 */               $composer3.endNode();
/* 200 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 194 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 183 */               ComposerKt.sourceInformationMarkerEnd($composer3);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 63 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                        subtitle2 = str;
                    }
                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.SectionTitle$lambda$1(title2, subtitle2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

/* 63 */        public static final void Metric(final String value, String label, Modifier modifier, Composer $composer, final int $changed, final int i) {
                    Modifier modifier2;
                    final String str;
                    Composer $composer2;
                    final Modifier modifier3;
                    Intrinsics.checkNotNullParameter(value, "value");
                    Intrinsics.checkNotNullParameter(label, "label");
/* 64 */            Composer $composer3 = $composer.startRestartGroup(79046135);
                    ComposerKt.sourceInformation($composer3, "C(Metric)N(value,label,modifier)63@5159L165:XunjiComponents.kt#8ao140");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer3.changed(value) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer3.changed(label) ? 32 : 16;
                    }
                    int i2 = i & 4;
                    if (i2 != 0) {
                        $dirty |= 384;
                        modifier2 = modifier;
                    } else if (($changed & 384) == 0) {
                        modifier2 = modifier;
                        $dirty |= $composer3.changed(modifier2) ? 256 : 128;
                    } else {
                        modifier2 = modifier;
                    }
                    if ($composer3.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
                        Modifier modifier4 = i2 != 0 ? Modifier.INSTANCE : modifier2;
                        if (ComposerKt.isTraceInProgress()) {
/* 64 */                    ComposerKt.traceEventStart(79046135, $dirty, -1, "com.xunji.flashcards.ui.components.Metric (XunjiComponents.kt:63)");
                        }
/* 64 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(5));
                        int i3 = (($dirty >> 6) & 14) | 48;
/* 226 */               ComposerKt.sourceInformationMarkerStart($composer3, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 230 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer3, ((i3 >> 3) & 14) | ((i3 >> 3) & 112));
/* 235 */               ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 236 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 237 */               CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
/* 238 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifier4);
/* 240 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 231 */               int i4 = ((((i3 << 3) & 112) << 6) & 896) | 6;
/* 241 */               ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 242 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 243 */               $composer3.startReusableNode();
/* 244 */               if ($composer3.getInserting()) {
/* 245 */                   $composer3.createNode(constructor);
                        } else {
/* 247 */                   $composer3.useNode();
                        }
/* 249 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer3);
/* 250 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 251 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 252 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 254 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 253 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 256 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 259 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 261 */               int i5 = (i4 >> 6) & 14;
/* 232 */               ComposerKt.sourceInformationMarkerStart($composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                        int i6 = ((i3 >> 6) & 112) | 6;
/* 64 */                ComposerKt.sourceInformationMarkerStart($composer3, -1288195595, "C63@5256L10,63@5225L83,63@5309L13:XunjiComponents.kt#8ao140");
                        $composer2 = $composer3;
                        TextKt.m3584TextNvy7gAk(value, null, 0L, null, 0L, null, FontWeight.INSTANCE.getBold(), null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer3, MaterialTheme.$stable).getHeadlineLarge(), $composer3, ($dirty & 14) | 1572864, 0, 131006);
                        str = label;
                        Notice(str, false, $composer3, ($dirty >> 3) & 14, 2);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 232 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 262 */               $composer3.endNode();
/* 241 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 235 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 226 */               ComposerKt.sourceInformationMarkerEnd($composer3);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 64 */                modifier3 = modifier4;
                    } else {
                        str = label;
                        $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                        modifier3 = modifier2;
                    }
                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.components.XunjiComponentsKt$$ExternalSyntheticLambda7
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return XunjiComponentsKt.Metric$lambda$1(value, str, modifier3, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }

/* 65 */        public static final String intervalLabel(long dueAt, long now) {
                    StringBuilder sbAppend;
                    String str;
/* 66 */            long minutes = RangesKt.coerceAtLeast(RangesKt.coerceAtLeast(dueAt - now, 0L) / ((long) 60000), 1L);
                    if (minutes < 60) {
                        sbAppend = new StringBuilder().append(minutes);
                        str = " 分钟";
                    } else if (minutes < 1440) {
                        sbAppend = new StringBuilder().append(minutes / ((long) 60));
                        str = " 小时";
                    } else {
                        sbAppend = new StringBuilder().append(minutes / ((long) 1440));
                        str = " 天";
                    }
                    return sbAppend.append(str).toString();
                }

/* 68 */        public static final String localTime(long timestamp) {
/* 69 */            String str = Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("M月d日 HH:mm"));
                    Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                    return str;
                }

/* 69 */        public static final String durationLabel(long ms) {
                    StringBuilder sbAppend;
                    String str;
                    if (ms < 60000) {
                        sbAppend = new StringBuilder().append(ms / ((long) 1000));
                        str = " 秒";
                    } else {
                        sbAppend = new StringBuilder().append(ms / ((long) 60000));
                        str = " 分钟";
                    }
                    return sbAppend.append(str).toString();
                }
            }

            package com.xunji.flashcards.ui.screens;

            import com.xunji.flashcards.ui.AnkiImportViewModel;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: AnkiImportScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 63 */    final /* synthetic */ class AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3$1 extends FunctionReferenceImpl implements Function0<Unit> {
                AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3$1(Object obj) {
                    super(0, obj, AnkiImportViewModel.class, "confirm", "confirm()V", 0);
                }

                @Override // kotlin.jvm.functions.Function0
/* 64 */        public /* bridge */ /* synthetic */ Unit invoke() {
/* 65 */            invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 64 */        public final void invoke2() {
/* 65 */            ((AnkiImportViewModel) this.receiver).confirm();
                }
            }

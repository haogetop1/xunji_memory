            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.ProgressIndicatorKt;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.anki.ImportIssue;
            import com.xunji.core.anki.ImportProgress;
            import com.xunji.core.anki.ImportStage;
            import com.xunji.flashcards.anki.AnkiImportReport;
            import com.xunji.flashcards.anki.ImportPreviewCard;
            import com.xunji.flashcards.anki.ImportResult;
            import com.xunji.flashcards.ui.AnkiImportUiState;
            import com.xunji.flashcards.ui.AnkiImportViewModel;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Comparator;
            import java.util.Iterator;
            import java.util.List;
            import java.util.Map;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.comparisons.ComparisonsKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.reflect.KFunction;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: AnkiImportScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a9\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0001¢\u0006\u0002\u0010\t¨\u0006\n"}, d2 = {"AnkiImportScreen", "", "state", "Lcom/xunji/flashcards/ui/AnkiImportUiState;", "viewModel", "Lcom/xunji/flashcards/ui/AnkiImportViewModel;", "onChoose", "Lkotlin/Function0;", "onDone", "(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 15 */    public final class AnkiImportScreenKt {

                /* JADX INFO: compiled from: AnkiImportScreen.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[ImportStage.values().length];
                        try {
                            iArr[ImportStage.PACKAGE.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[ImportStage.METADATA.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[ImportStage.DATABASE.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        try {
                            iArr[ImportStage.MEDIA.ordinal()] = 4;
                        } catch (NoSuchFieldError e4) {
                        }
                        try {
                            iArr[ImportStage.READY.ordinal()] = 5;
                        } catch (NoSuchFieldError e5) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit AnkiImportScreen$lambda$1(AnkiImportUiState ankiImportUiState, AnkiImportViewModel ankiImportViewModel, Function0 function0, Function0 function1, int i, Composer composer, int i2) {
                    AnkiImportScreen(ankiImportUiState, ankiImportViewModel, function0, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 16 */        public static final void AnkiImportScreen(final AnkiImportUiState state, final AnkiImportViewModel viewModel, final Function0<Unit> onChoose, final Function0<Unit> onDone, Composer $composer, final int $changed) {
                    Composer $composer2;
                    Object obj;
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(viewModel, "viewModel");
                    Intrinsics.checkNotNullParameter(onChoose, "onChoose");
                    Intrinsics.checkNotNullParameter(onDone, "onDone");
/* 17 */            Composer $composer3 = $composer.startRestartGroup(1747171854);
                    ComposerKt.sourceInformation($composer3, "C(AnkiImportScreen)N(state,viewModel,onChoose,onDone)26@1152L4808,22@945L5015:AnkiImportScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer3.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer3.changedInstance(viewModel) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer3.changedInstance(onChoose) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        $dirty |= $composer3.changedInstance(onDone) ? 2048 : 1024;
                    }
                    int $dirty2 = $dirty;
                    if ($composer3.shouldExecute(($dirty2 & 1171) != 1170, $dirty2 & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 17 */                    ComposerKt.traceEventStart(1747171854, $dirty2, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen (AnkiImportScreen.kt:16)");
                        }
/* 18 */                final AnkiImportReport report = state.getPreview();
/* 19 */                List<ImportPreviewCard> affectedCards = report != null ? report.getAffectedCards() : null;
                        if (affectedCards == null) {
                            affectedCards = CollectionsKt.emptyList();
                        }
/* 20 */                final int pages = ((affectedCards.size() + 20) - 1) / 20;
/* 22 */                List<ImportPreviewCard> listPage = report != null ? report.page(state.getPage(), 20, true) : null;
                        if (listPage == null) {
                            listPage = CollectionsKt.emptyList();
                        }
/* 19 */                Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), "anki-import-screen");
/* 25 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 26 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(18));
/* 27 */                ComposerKt.sourceInformationMarkerStart($composer3, -300037674, "CC(remember):AnkiImportScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer3.changedInstance(state) | $composer3.changedInstance(report) | (($dirty2 & 896) == 256) | $composer3.changedInstance(viewModel) | $composer3.changedInstance(affectedCards) | $composer3.changedInstance(listPage) | $composer3.changed(pages) | (($dirty2 & 7168) == 2048);
/* 112 */               Object objRememberedValue = $composer3.rememberedValue();
/* 113 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            final List<ImportPreviewCard> list = listPage;
                            final List<ImportPreviewCard> list2 = affectedCards;
/* 27 */                    obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0(state, report, list2, list, pages, onChoose, viewModel, onDone, (LazyListScope) obj2);
                                }
                            };
/* 115 */                   $composer3.updateRememberedValue(obj);
                        } else {
                            obj = objRememberedValue;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
                        $composer2 = $composer3;
/* 27 */                LazyDslKt.LazyColumn(modifierTestTag, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) obj, $composer2, 24966, 490);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 17 */                $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
/* 108 */           ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$1(state, viewModel, onChoose, onDone, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 27 */        public static final Unit AnkiImportScreen$lambda$0$0(final AnkiImportUiState $state, final AnkiImportReport $report, final List $affected, final List $pageCards, final int $pages, final Function0 $onChoose, final AnkiImportViewModel $viewModel, final Function0 $onDone, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 28 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$697298713$app_debug(), 3, null);
/* 29 */            final ImportResult previousCompleted = $state.getPreviousCompleted();
                    if (previousCompleted != null) {
/* 29 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-146208056, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda17
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$0$0(previousCompleted, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 32 */            if (!$state.getBusy() && $report == null && $state.getResult() == null && $state.getError() == null) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1534909150, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$1($onChoose, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 35 */            if ($state.getBusy()) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1607774727, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$2($state, $viewModel, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 54 */            final String error = $state.getError();
                    if (error != null) {
/* 54 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(549260450, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$3$0(error, $onChoose, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 57 */            if ($report != null && !$state.getBusy()) {
/* 58 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1173811046, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$4($report, $affected, $viewModel, $onChoose, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
/* 70 */                if (!$affected.isEmpty()) {
/* 71 */                    LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-944809045, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda5
                                @Override // kotlin.jvm.functions.Function3
                                public final Object invoke(Object obj, Object obj2, Object obj3) {
                                    return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$5($report, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            }), 3, null);
/* 79 */                    LazyListScope.items$default(LazyColumn, $pageCards.size(), null, null, ComposableLambdaKt.composableLambdaInstance(-979870590, true, new Function4() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda6
                                @Override // kotlin.jvm.functions.Function4
                                public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                                    return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$6($pageCards, (LazyItemScope) obj, ((Integer) obj2).intValue(), (Composer) obj3, ((Integer) obj4).intValue());
                                }
                            }), 6, null);
/* 87 */                    if ($pages > 1) {
                                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(544535984, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda7
                                    @Override // kotlin.jvm.functions.Function3
                                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                                        return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$7($state, $pages, $viewModel, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                    }
                                }), 3, null);
                            }
                        }
                    }
/* 98 */            final ImportResult result = $state.getResult();
                    if (result != null) {
/* 98 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(527879376, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$8$0(result, $onDone, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 107 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 29 */        public static final Unit AnkiImportScreen$lambda$0$0$0$0(ImportResult $previous, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C29@1294L51:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-146208056, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:29)");
                        }
                        XunjiComponentsKt.Notice("上一份牌组已完成导入：新增 " + $previous.getAddedCards() + " 张卡片。", false, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 29 */                $composer.skipToGroupEnd();
                    }
/* 31 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 32 */        public static final Unit AnkiImportScreen$lambda$0$0$1(Function0 $onChoose, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C32@1467L58:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1534909150, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:32)");
                        }
/* 33 */                XunjiComponentsKt.EmptyState("选择牌组文件", "选择 .apkg 文件开始预检。", "选择文件", $onChoose, $composer, 438, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 34 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit AnkiImportScreen$lambda$0$0$2(final AnkiImportUiState $state, final AnkiImportViewModel $viewModel, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C35@1610L1019,35@1579L1050:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 35 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1607774727, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:35)");
                        }
/* 36 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(191697111, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$2$0($state, $viewModel, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 53 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:28:0x0186  */
                /* JADX WARN: Code duplicated, block: B:29:0x0189  */
                /* JADX WARN: Code duplicated, block: B:32:0x01e3  */
                /* JADX WARN: Code duplicated, block: B:34:0x01ee  */
                /* JADX WARN: Code duplicated, block: B:36:0x0209  */
                /* JADX WARN: Code duplicated, block: B:38:0x020f  */
                /* JADX WARN: Code duplicated, block: B:39:0x0212  */
                /* JADX WARN: Code duplicated, block: B:40:0x0215  */
                /* JADX WARN: Code duplicated, block: B:41:0x0218  */
                /* JADX WARN: Code duplicated, block: B:42:0x021b  */
                /* JADX WARN: Code duplicated, block: B:45:0x0228  */
                /* JADX WARN: Code duplicated, block: B:47:0x0245  */
                /* JADX WARN: Code duplicated, block: B:55:0x0288  */
                /* JADX WARN: Code duplicated, block: B:58:0x02d5  */
/* 36 */        public static final Unit AnkiImportScreen$lambda$0$0$2$0(AnkiImportUiState $state, AnkiImportViewModel $viewModel, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    int i;
                    String str;
                    ImportProgress progress;
                    String str2;
                    Long total;
                    String str3;
                    boolean zChangedInstance;
                    Object objRememberedValue;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C36@1628L327,50@2512L17,50@2497L118:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(191697111, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:36)");
                        }
/* 37 */                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 37 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(14));
/* 120 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 121 */               Modifier modifier = Modifier.INSTANCE;
/* 126 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, centerVertically, $composer, ((432 >> 3) & 14) | ((432 >> 3) & 112));
/* 131 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 132 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 133 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 136 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 130 */               int i2 = ((((432 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 138 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 139 */               $composer.startReusableNode();
/* 140 */               if ($composer.getInserting()) {
/* 141 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 143 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 145 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 146 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 147 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 148 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 150 */               if (composerM4979constructorimpl.getInserting()) {
                            i = 432;
                        } else {
                            i = 432;
/* 149 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 155 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 157 */                   int i3 = (i2 >> 6) & 14;
/* 128 */                   ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                            int i4 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -1482324430, "C37@1755L67,38@1914L10,38@1843L94:AnkiImportScreen.kt#i35lj1");
/* 38 */                    ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(28)), 0L, Dp.m8404constructorimpl(3), 0L, 0, 0.0f, $composer, 390, 58);
                            if ($state.getCommitting()) {
                                str = "正在导入…";
                            } else {
                                str = "正在预检…";
                            }
/* 39 */                    TextKt.m3584TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 0, 0, 131070);
/* 38 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 128 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 159 */                   $composer.endNode();
/* 137 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 131 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 120 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 41 */                    progress = $state.getProgress();
                            if (progress == null) {
                                $composer.startReplaceGroup(-1457479650);
                            } else {
                                $composer.startReplaceGroup(-1457479649);
                                ComposerKt.sourceInformation($composer, "*48@2379L83");
                                switch (WhenMappings.$EnumSwitchMapping$0[progress.getStage().ordinal()]) {
                                    case 1:
/* 43 */                                str2 = "读取文件";
                                        break;
                                    case 2:
/* 44 */                                str2 = "检查包结构";
                                        break;
                                    case 3:
/* 45 */                                str2 = "检查卡片数据";
                                        break;
                                    case 4:
/* 46 */                                str2 = "检查媒体";
                                        break;
                                    case 5:
/* 47 */                                str2 = "检查模板与兼容性";
                                        break;
                                    default:
                                        throw new NoWhenBranchMatchedException();
                                }
/* 49 */                        long completed = progress.getCompleted();
                                total = progress.getTotal();
                                if (total != null) {
/* 49 */                            str3 = " / " + total.longValue();
                                    if (str3 == null) {
                                        str3 = "";
                                    }
                                } else {
                                    str3 = "";
                                }
                                XunjiComponentsKt.Notice(str2 + " · " + completed + str3, false, $composer, 0, 2);
                            }
                            $composer.endReplaceGroup();
/* 51 */                    ComposerKt.sourceInformationMarkerStart($composer, -462641176, "CC(remember):AnkiImportScreen.kt#9igjgp");
                            zChangedInstance = $composer.changedInstance($viewModel);
/* 163 */                   objRememberedValue = $composer.rememberedValue();
/* 164 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 51 */                        Object obj = (KFunction) new AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3$1($viewModel);
/* 166 */                       $composer.updateRememberedValue(obj);
/* 167 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 51 */                    ButtonKt.OutlinedButton((Function0) ((KFunction) objRememberedValue), TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(48), 0.0f, 2, null), "anki-cancel"), false, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$600549193$app_debug(), $composer, 805306416, 508);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 149 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 152 */               composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 155 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 157 */               int i5 = (i2 >> 6) & 14;
/* 128 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                        int i6 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -1482324430, "C37@1755L67,38@1914L10,38@1843L94:AnkiImportScreen.kt#i35lj1");
/* 38 */                ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(28)), 0L, Dp.m8404constructorimpl(3), 0L, 0, 0.0f, $composer, 390, 58);
                        if ($state.getCommitting()) {
                            str = "正在导入…";
                        } else {
                            str = "正在预检…";
                        }
/* 39 */                TextKt.m3584TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 0, 0, 131070);
/* 38 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 128 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 159 */               $composer.endNode();
/* 137 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 131 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 120 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 41 */                progress = $state.getProgress();
                        if (progress == null) {
                            $composer.startReplaceGroup(-1457479650);
                        } else {
                            $composer.startReplaceGroup(-1457479649);
                            ComposerKt.sourceInformation($composer, "*48@2379L83");
                            switch (WhenMappings.$EnumSwitchMapping$0[progress.getStage().ordinal()]) {
                                case 1:
/* 43 */                            str2 = "读取文件";
                                    break;
                                case 2:
/* 44 */                            str2 = "检查包结构";
                                    break;
                                case 3:
/* 45 */                            str2 = "检查卡片数据";
                                    break;
                                case 4:
/* 46 */                            str2 = "检查媒体";
                                    break;
                                case 5:
/* 47 */                            str2 = "检查模板与兼容性";
                                    break;
                                default:
                                    throw new NoWhenBranchMatchedException();
                            }
/* 49 */                    long completed2 = progress.getCompleted();
                            total = progress.getTotal();
                            if (total != null) {
/* 49 */                        str3 = " / " + total.longValue();
                                if (str3 == null) {
                                    str3 = "";
                                }
                            } else {
                                str3 = "";
                            }
                            XunjiComponentsKt.Notice(str2 + " · " + completed2 + str3, false, $composer, 0, 2);
                        }
                        $composer.endReplaceGroup();
/* 51 */                ComposerKt.sourceInformationMarkerStart($composer, -462641176, "CC(remember):AnkiImportScreen.kt#9igjgp");
                        zChangedInstance = $composer.changedInstance($viewModel);
/* 163 */               objRememberedValue = $composer.rememberedValue();
/* 164 */               if (zChangedInstance) {
/* 51 */                    Object obj2 = (KFunction) new AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3$1($viewModel);
/* 166 */                   $composer.updateRememberedValue(obj2);
/* 167 */                   objRememberedValue = obj2;
                        } else {
/* 51 */                    Object obj3 = (KFunction) new AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3$1($viewModel);
/* 166 */                   $composer.updateRememberedValue(obj3);
/* 167 */                   objRememberedValue = obj3;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 51 */                ButtonKt.OutlinedButton((Function0) ((KFunction) objRememberedValue), TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(48), 0.0f, 2, null), "anki-cancel"), false, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$600549193$app_debug(), $composer, 805306416, 508);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 36 */                $composer.skipToGroupEnd();
                    }
/* 52 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 54 */        public static final Unit AnkiImportScreen$lambda$0$0$3$0(String $error, Function0 $onChoose, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C54@2695L46:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(549260450, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:54)");
                        }
/* 55 */                XunjiComponentsKt.EmptyState("导入未完成", $error, "重新选择文件", $onChoose, $composer, 390, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 56 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 58 */        public static final Unit AnkiImportScreen$lambda$0$0$4(final AnkiImportReport $report, final List $affected, final AnkiImportViewModel $viewModel, final Function0 $onChoose, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C58@2865L863,58@2834L894:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 58 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1173811046, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:58)");
                        }
/* 59 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-242266570, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$4$0($report, $affected, $viewModel, $onChoose, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 69 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 59 */        public static final Unit AnkiImportScreen$lambda$0$0$4$0(AnkiImportReport $report, List $affected, AnkiImportViewModel $viewModel, Function0 $onChoose, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C59@2922L10,59@2887L57,60@2965L130,66@3591L119:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-242266570, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:59)");
                        }
/* 60 */                TextKt.m3584TextNvy7gAk("预检结果", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        TextKt.m3584TextNvy7gAk("源卡 " + $report.getTotalCards() + " 张 · 可导入 " + $report.getCompatibleCards() + " 张 · 已存在 " + $report.getDuplicateCards() + " 张 · 跳过 " + $report.getSkippedCards() + " 张", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if ($affected.isEmpty()) {
/* 62 */                    $composer.startReplaceGroup(-1821172660);
                        } else {
/* 62 */                    $composer.startReplaceGroup(-889930748);
/* 62 */                    ComposerKt.sourceInformation($composer, "61@3143L142");
                            List list = $affected;
/* 170 */                   Collection arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
/* 171 */                   Iterator it = list.iterator();
                            while (it.hasNext()) {
/* 172 */                       arrayList.add(((ImportPreviewCard) it.next()).getGuid());
                            }
/* 62 */                    int size = CollectionsKt.distinct((List) arrayList).size();
                            List list2 = $affected;
/* 170 */                   Collection arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list2, 10));
/* 171 */                   Iterator it2 = list2.iterator();
                            while (it2.hasNext()) {
/* 172 */                       arrayList2.add(((ImportPreviewCard) it2.next()).getDeckName());
                            }
/* 62 */                    XunjiComponentsKt.Notice("受影响：" + size + " 条笔记、" + CollectionsKt.distinct((List) arrayList2).size() + " 个牌组、" + $affected.size() + " 张卡片。下方列出原因。", false, $composer, 0, 2);
                        }
/* 62 */                $composer.endReplaceGroup();
/* 63 */                if ($report.getCompatibleCards() > 0) {
/* 62 */                    $composer.startReplaceGroup(-1817854017);
/* 62 */                    ComposerKt.sourceInformation($composer, "63@3364L38,64@3480L18,64@3427L94");
/* 62 */                    XunjiComponentsKt.Notice("确认后仅添加兼容的新卡；已有笔记字段和复习进度保持原样。", false, $composer, 6, 2);
                            String str = "确认导入 " + $report.getCompatibleCards() + " 张兼容卡";
/* 62 */                    ComposerKt.sourceInformationMarkerStart($composer, -889920088, "CC(remember):AnkiImportScreen.kt#9igjgp");
/* 62 */                    boolean zChangedInstance = $composer.changedInstance($viewModel);
/* 174 */                   Object objRememberedValue = $composer.rememberedValue();
/* 175 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 65 */                        Object obj = (KFunction) new AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3$1($viewModel);
/* 177 */                       $composer.updateRememberedValue(obj);
/* 178 */                       objRememberedValue = obj;
                            }
/* 62 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 62 */                    XunjiComponentsKt.PrimaryButton(str, (Function0) ((KFunction) objRememberedValue), null, false, "anki-confirm", $composer, 24576, 12);
/* 63 */                    $composer.endReplaceGroup();
                        } else {
/* 62 */                    $composer.startReplaceGroup(-889917877);
/* 62 */                    ComposerKt.sourceInformation($composer, "65@3549L21");
/* 62 */                    XunjiComponentsKt.Notice("没有可新增的兼容卡片。", false, $composer, 6, 2);
/* 62 */                    $composer.endReplaceGroup();
                        }
/* 62 */                ButtonKt.OutlinedButton($onChoose, TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(48), 0.0f, 2, null), "anki-choose-again"), false, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$166585512$app_debug(), $composer, 805306416, 508);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 68 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 71 */        public static final Unit AnkiImportScreen$lambda$0$0$5(final AnkiImportReport $report, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C71@3858L295,71@3827L326:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 71 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-944809045, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:71)");
                        }
/* 72 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-927238533, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$5$0($report, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 78 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 72 */        public static final Unit AnkiImportScreen$lambda$0$0$5$0(AnkiImportReport $report, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C72@3922L10,72@3884L60,*74@4079L26:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 72 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-927238533, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:72)");
                        }
/* 73 */                TextKt.m3584TextNvy7gAk("需要注意的问题", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        for (Map.Entry entry : CollectionsKt.sortedWith($report.getReasons().entrySet(), new Comparator() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$AnkiImportScreen$lambda$0$0$5$0$$inlined$sortedByDescending$1
                            @Override // java.util.Comparator
/* 120 */                   public final int compare(T t, T t2) {
/* 121 */                       return ComparisonsKt.compareValues((Integer) ((Map.Entry) t2).getValue(), (Integer) ((Map.Entry) t).getValue());
                            }
                        })) {
/* 74 */                    XunjiComponentsKt.Notice(((String) entry.getKey()) + " · " + ((Number) entry.getValue()).intValue() + " 张", false, $composer, 0, 2);
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 77 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 79 */        public static final Unit AnkiImportScreen$lambda$0$0$6(List $pageCards, LazyItemScope items, int index, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(items, "$this$items");
                    ComposerKt.sourceInformation($composer, "CN(index)80@4320L352,80@4289L383:AnkiImportScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 48) == 0) {
                        $dirty |= $composer.changed(index) ? 32 : 16;
                    }
                    if (!$composer.shouldExecute(($dirty & 145) != 144, $dirty & 1)) {
/* 79 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-979870590, $dirty, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:79)");
                        }
/* 80 */                final ImportPreviewCard card = (ImportPreviewCard) $pageCards.get(index);
/* 81 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-629502126, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda14
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$6$0(card, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 86 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 81 */        public static final Unit AnkiImportScreen$lambda$0$0$6$0(ImportPreviewCard $card, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C81@4407L10,81@4346L84,82@4455L83,*83@4594L54:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 81 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-629502126, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:81)");
                        }
/* 82 */                String deckName = $card.getDeckName();
                        if (StringsKt.isBlank(deckName)) {
                            deckName = "未知牌组";
                        }
                        TextKt.m3584TextNvy7gAk(deckName, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 0, 0, 131070);
/* 83 */                XunjiComponentsKt.Notice("源卡 " + $card.getSourceCardId() + " · 笔记 " + StringsKt.take($card.getGuid(), 80) + " · 模板序号 " + $card.getOrdinal(), false, $composer, 0, 2);
                        for (ImportIssue importIssue : $card.getIssues()) {
/* 83 */                    XunjiComponentsKt.Notice(importIssue.getCode() + ": " + importIssue.getDetail(), true, $composer, 48, 0);
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 85 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:55:0x0343  */
                /* JADX WARN: Code duplicated, block: B:56:0x0346  */
                /* JADX WARN: Code duplicated, block: B:67:0x03e0  */
/* 87 */        public static final Unit AnkiImportScreen$lambda$0$0$7(final AnkiImportUiState $state, int $pages, final AnkiImportViewModel $viewModel, LazyItemScope item, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Function0<ComposeUiNode> function1;
                    Composer composer;
                    boolean z;
                    boolean zChangedInstance;
                    Object objRememberedValue;
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C87@4749L601:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(544535984, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:87)");
                        }
/* 88 */                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 186 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 187 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
/* 192 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 193 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 194 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 195 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
/* 197 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 191 */               int i = ((((438 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 199 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 200 */               $composer.startReusableNode();
/* 201 */               if ($composer.getInserting()) {
/* 202 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 204 */                   function0 = constructor;
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 207 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 208 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 209 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 211 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 210 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 213 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 216 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 218 */               int i2 = (i >> 6) & 14;
/* 189 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i3 = ((438 >> 6) & 112) | 6;
/* 89 */                ComposerKt.sourceInformationMarkerStart($composer, 239700237, "C88@4902L34,89@4961L367:AnkiImportScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk(($state.getPage() + 1) + " / " + $pages, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 220 */               Modifier modifier = Modifier.INSTANCE;
/* 90 */                MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), Alignment.INSTANCE.getTop(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 90 */                int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 232 */               CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
/* 90 */                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifier);
/* 235 */               Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 229 */               int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 237 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 238 */               $composer.startReusableNode();
/* 239 */               if ($composer.getInserting()) {
/* 240 */                   function1 = constructor2;
/* 90 */                    $composer.createNode(function1);
                        } else {
/* 242 */                   function1 = constructor2;
/* 90 */                    $composer.useNode();
                        }
/* 244 */               Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer);
/* 245 */               Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 246 */               Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 247 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 249 */               if (composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 248 */                   composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 251 */                   composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
                        }
/* 254 */               Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 256 */               int i5 = (i4 >> 6) & 14;
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                        int i6 = ((0 >> 6) & 112) | 6;
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, -710443128, "C90@5006L34,90@4995L135,91@5170L34,91@5159L143:AnkiImportScreen.kt#i35lj1");
                        boolean z2 = $state.getPage() > 0;
                        Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "anki-prev-page");
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer, -715654102, "CC(remember):AnkiImportScreen.kt#9igjgp");
/* 90 */                boolean zChangedInstance2 = $composer.changedInstance($viewModel) | $composer.changedInstance($state);
/* 90 */                Object objRememberedValue2 = $composer.rememberedValue();
/* 258 */               if (zChangedInstance2) {
/* 258 */                   composer = $composer;
                        } else {
/* 90 */                    composer = $composer;
                            if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 91 */                    ButtonKt.TextButton((Function0) objRememberedValue2, modifierTestTag, z2, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$1775359435$app_debug(), composer, 805306416, 504);
/* 92 */                    Composer composer2 = composer;
                            if ($state.getPage() + 1 < $pages) {
                                z = true;
                            } else {
                                z = false;
                            }
                            Modifier modifierTestTag2 = TestTagKt.testTag(Modifier.INSTANCE, "anki-next-page");
                            ComposerKt.sourceInformationMarkerStart(composer2, -715648854, "CC(remember):AnkiImportScreen.kt#9igjgp");
                            zChangedInstance = composer2.changedInstance($viewModel) | composer2.changedInstance($state);
                            objRememberedValue = composer2.rememberedValue();
/* 264 */                   if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda11
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$7$0$0$1$0($viewModel, $state);
                                    }
                                };
/* 266 */                       composer2.updateRememberedValue(objRememberedValue);
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer2);
/* 92 */                    ButtonKt.TextButton((Function0) objRememberedValue, modifierTestTag2, z, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$50309940$app_debug(), composer2, 805306416, 504);
/* 91 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 227 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 269 */                   $composer.endNode();
/* 236 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 230 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 219 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 89 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 189 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 273 */                   $composer.endNode();
/* 198 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 192 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 186 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                        objRememberedValue2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$7$0$0$0$0($viewModel, $state);
                            }
                        };
/* 260 */               $composer.updateRememberedValue(objRememberedValue2);
                        ComposerKt.sourceInformationMarkerEnd(composer);
/* 91 */                ButtonKt.TextButton((Function0) objRememberedValue2, modifierTestTag, z2, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$1775359435$app_debug(), composer, 805306416, 504);
/* 92 */                Composer composer3 = composer;
                        if ($state.getPage() + 1 < $pages) {
                            z = true;
                        } else {
                            z = false;
                        }
                        Modifier modifierTestTag3 = TestTagKt.testTag(Modifier.INSTANCE, "anki-next-page");
                        ComposerKt.sourceInformationMarkerStart(composer3, -715648854, "CC(remember):AnkiImportScreen.kt#9igjgp");
                        zChangedInstance = composer3.changedInstance($viewModel) | composer3.changedInstance($state);
                        objRememberedValue = composer3.rememberedValue();
/* 264 */               if (!zChangedInstance) {
                        }
                        objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$7$0$0$1$0($viewModel, $state);
                            }
                        };
/* 266 */               composer3.updateRememberedValue(objRememberedValue);
                        ComposerKt.sourceInformationMarkerEnd(composer3);
/* 92 */                ButtonKt.TextButton((Function0) objRememberedValue, modifierTestTag3, z, null, null, null, null, null, null, ComposableSingletons$AnkiImportScreenKt.INSTANCE.getLambda$50309940$app_debug(), composer3, 805306416, 504);
/* 91 */                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 227 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 269 */               $composer.endNode();
/* 236 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 230 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 219 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 89 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 189 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 273 */               $composer.endNode();
/* 198 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 192 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 186 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 87 */                $composer.skipToGroupEnd();
                    }
/* 95 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 90 */        public static final Unit AnkiImportScreen$lambda$0$0$7$0$0$0$0(AnkiImportViewModel $viewModel, AnkiImportUiState $state) {
/* 91 */            $viewModel.page($state.getPage() - 1);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 91 */        public static final Unit AnkiImportScreen$lambda$0$0$7$0$0$1$0(AnkiImportViewModel $viewModel, AnkiImportUiState $state) {
/* 92 */            $viewModel.page($state.getPage() + 1);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 98 */        public static final Unit AnkiImportScreen$lambda$0$0$8$0(final ImportResult $result, final Function0 $onDone, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C98@5481L461,98@5450L492:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 98 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(527879376, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:98)");
                        }
/* 99 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(464857088, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.AnkiImportScreenKt$$ExternalSyntheticLambda13
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return AnkiImportScreenKt.AnkiImportScreen$lambda$0$0$8$0$0($result, $onDone, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 106 */           return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 99 */        public static final Unit AnkiImportScreen$lambda$0$0$8$0$0(ImportResult $result, Function0 $onDone, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C99@5534L10,99@5499L57,100@5573L86,101@5676L69,103@5880L48:AnkiImportScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 99 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(464857088, $changed, -1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:99)");
                        }
/* 100 */               TextKt.m3584TextNvy7gAk("导入完成", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        TextKt.m3584TextNvy7gAk("新增 " + $result.getAddedDecks() + " 个牌组、" + $result.getAddedNotes() + " 条笔记、" + $result.getAddedCards() + " 张卡片。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
/* 102 */               XunjiComponentsKt.Notice("已存在 " + $result.getDuplicateCards() + " 张；跳过 " + $result.getSkippedCards() + " 张。", false, $composer, 0, 2);
/* 103 */               if (!$result.getReasons().isEmpty()) {
/* 102 */                   $composer.startReplaceGroup(1583274317);
/* 102 */                   ComposerKt.sourceInformation($composer, "*102@5837L24");
                            for (Map.Entry<String, Integer> entry : $result.getReasons().entrySet()) {
/* 102 */                       XunjiComponentsKt.Notice(entry.getKey() + " · " + entry.getValue().intValue(), false, $composer, 0, 2);
                            }
                        } else {
/* 102 */                   $composer.startReplaceGroup(1577508162);
                        }
/* 102 */               $composer.endReplaceGroup();
/* 102 */               XunjiComponentsKt.PrimaryButton("返回牌组", $onDone, null, false, "anki-done", $composer, 24582, 12);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 105 */           return Unit.INSTANCE;
                }
            }

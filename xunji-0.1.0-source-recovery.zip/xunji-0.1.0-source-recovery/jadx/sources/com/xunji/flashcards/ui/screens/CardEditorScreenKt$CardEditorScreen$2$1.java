            package com.xunji.flashcards.ui.screens;

            import com.xunji.flashcards.ui.EditorUiState;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: CardEditorScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.screens.CardEditorScreenKt$CardEditorScreen$2$1", f = "CardEditorScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 26 */    final class CardEditorScreenKt$CardEditorScreen$2$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ Function0<Unit> $onExit;
                final /* synthetic */ EditorUiState $state;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                CardEditorScreenKt$CardEditorScreen$2$1(EditorUiState editorUiState, Function0<Unit> function0, Continuation<? super CardEditorScreenKt$CardEditorScreen$2$1> continuation) {
                    super(2, continuation);
                    this.$state = editorUiState;
                    this.$onExit = function0;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new CardEditorScreenKt$CardEditorScreen$2$1(this.$state, this.$onExit, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((CardEditorScreenKt$CardEditorScreen$2$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 27 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            if (this.$state.getSaved()) {
                                invoke();
                            }
                            return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

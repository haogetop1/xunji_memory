            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.relocation.BringIntoViewRequester;
            import androidx.compose.runtime.MonotonicFrameClockKt;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: CardEditorScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.screens.CardEditorScreenKt$EditorField$1$1", f = "CardEditorScreen.kt", i = {}, l = {58, 58}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 56 */    final class CardEditorScreenKt$EditorField$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ String $error;
                final /* synthetic */ BringIntoViewRequester $errorView;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                CardEditorScreenKt$EditorField$1$1(String str, BringIntoViewRequester bringIntoViewRequester, Continuation<? super CardEditorScreenKt$EditorField$1$1> continuation) {
                    super(2, continuation);
                    this.$error = str;
                    this.$errorView = bringIntoViewRequester;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new CardEditorScreenKt$EditorField$1$1(this.$error, this.$errorView, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((CardEditorScreenKt$EditorField$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 57 */        public static final Unit invokeSuspend$lambda$0(long it) {
/* 58 */            return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:15:0x0041 A[RETURN] */
                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 57 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            if (this.$error != null) {
                                this.label = 1;
                                if (MonotonicFrameClockKt.withFrameNanos(new Function1() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$EditorField$1$1$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj) {
                                        return CardEditorScreenKt$EditorField$1$1.invokeSuspend$lambda$0(((Long) obj).longValue());
                                    }
                                }, this) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                                this.label = 2;
                                if (BringIntoViewRequester.bringIntoView$default(this.$errorView, null, this, 1, null) == coroutine_suspended) {
                                    return coroutine_suspended;
                                }
                            }
                            return Unit.INSTANCE;
                        case 1:
                            ResultKt.throwOnFailure($result);
                            this.label = 2;
                            if (BringIntoViewRequester.bringIntoView$default(this.$errorView, null, this, 1, null) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                            return Unit.INSTANCE;
                        case 2:
                            ResultKt.throwOnFailure($result);
                            return Unit.INSTANCE;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

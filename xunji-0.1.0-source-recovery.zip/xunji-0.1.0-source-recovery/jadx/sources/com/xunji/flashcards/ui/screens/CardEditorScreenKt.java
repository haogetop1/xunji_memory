            package com.xunji.flashcards.ui.screens;

            import androidx.activity.compose.BackHandlerKt;
            import androidx.compose.foundation.ScrollKt;
            import androidx.compose.foundation.interaction.MutableInteractionSource;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.WindowInsets;
            import androidx.compose.foundation.layout.WindowInsetsPadding_androidKt;
            import androidx.compose.foundation.layout.WindowInsets_androidKt;
            import androidx.compose.foundation.relocation.BringIntoViewRequester;
            import androidx.compose.foundation.relocation.BringIntoViewRequesterKt;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.foundation.text.KeyboardActions;
            import androidx.compose.foundation.text.KeyboardOptions;
            import androidx.compose.material3.AndroidAlertDialog_androidKt;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.OutlinedTextFieldKt;
            import androidx.compose.material3.ProgressIndicatorKt;
            import androidx.compose.material3.TextFieldColors;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.EffectsKt;
            import androidx.compose.runtime.MutableState;
            import androidx.compose.runtime.ProvidableCompositionLocal;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.runtime.saveable.RememberSaveableKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.focus.FocusManager;
            import androidx.compose.ui.graphics.Shape;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.CompositionLocalsKt;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.text.TextStyle;
            import androidx.compose.ui.text.input.VisualTransformation;
            import androidx.compose.ui.unit.Density;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.anki.CardSide;
            import com.xunji.flashcards.anki.CardMedia;
            import com.xunji.flashcards.anki.RenderedCard;
            import com.xunji.flashcards.ui.EditorUiState;
            import com.xunji.flashcards.ui.EditorViewModel;
            import com.xunji.flashcards.ui.components.AnkiCardContentKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: CardEditorScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000H\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u001a[\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072&\b\u0002\u0010\b\u001a \b\u0001\u0012\u0004\u0012\u00020\n\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\f0\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\t2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00020\u00010\u000fH\u0007¢\u0006\u0002\u0010\u0010\u001aS\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00132\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00010\u00172\b\u0010\u0018\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0019\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u0007H\u0003¢\u0006\u0002\u0010\u001b¨\u0006\u001c²\u0006\n\u0010\u001d\u001a\u00020\u0007X\u008a\u008e\u0002"}, d2 = {"CardEditorScreen", "", "state", "Lcom/xunji/flashcards/ui/EditorUiState;", "viewModel", "Lcom/xunji/flashcards/ui/EditorViewModel;", "editing", "", "openMedia", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/CardMedia;", "Lkotlin/coroutines/Continuation;", "Ljava/io/InputStream;", "", "onExit", "Lkotlin/Function0;", "(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V", "EditorField", "label", "", "placeholder", "value", "onChange", "Lkotlin/Function1;", "error", "tag", "enabled", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V", "app_debug", "discard"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 21 */    public final class CardEditorScreenKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit CardEditorScreen$lambda$10(EditorUiState editorUiState, EditorViewModel editorViewModel, boolean z, Function2 function2, Function0 function0, int i, int i2, Composer composer, int i3) {
                    CardEditorScreen(editorUiState, editorViewModel, z, function2, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit CardEditorScreen$lambda$6$1(EditorUiState editorUiState, EditorViewModel editorViewModel, boolean z, Function2 function2, Function0 function0, int i, int i2, Composer composer, int i3) {
                    CardEditorScreen(editorUiState, editorViewModel, z, function2, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit EditorField$lambda$3(String str, String str2, String str3, Function1 function1, String str4, String str5, boolean z, int i, Composer composer, int i2) {
                    EditorField(str, str2, str3, function1, str4, str5, z, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:196:0x0915  */
                /* JADX WARN: Code duplicated, block: B:199:0x094b  */
                /* JADX WARN: Code duplicated, block: B:203:0x0957  */
                /* JADX WARN: Code duplicated, block: B:207:0x0974  */
                /* JADX WARN: Code duplicated, block: B:210:0x097d  */
                /* JADX WARN: Code duplicated, block: B:213:0x09b7  */
                /* JADX WARN: Code duplicated, block: B:214:0x09d8  */
                /* JADX WARN: Code duplicated, block: B:217:0x09e7  */
                /* JADX WARN: Code duplicated, block: B:218:0x09f1  */
                /* JADX WARN: Code duplicated, block: B:281:0x0d3b  */
                /* JADX WARN: Code duplicated, block: B:284:0x0d7b  */
                /* JADX WARN: Code duplicated, block: B:290:0x0da3  */
                /* JADX WARN: Code duplicated, block: B:292:0x0e10  */
                /* JADX WARN: Code duplicated, block: B:295:0x0e24  */
                /* JADX WARN: Code duplicated, block: B:62:0x00f6  */
/* 22 */        public static final void CardEditorScreen(final EditorUiState state, final EditorViewModel viewModel, final boolean editing, Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function2, final Function0<Unit> onExit, Composer $composer, final int $changed, final int i) {
                    Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function3;
                    Composer $composer2;
                    final Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function4;
                    Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function5;
                    int $dirty;
                    Function0<ComposeUiNode> function0;
                    Function0<ComposeUiNode> function1;
                    Function0<ComposeUiNode> function6;
                    Composer composer;
                    Function0<ComposeUiNode> function7;
                    Composer composer2;
                    boolean z;
                    boolean zChanged;
                    Object objRememberedValue;
                    Function0<ComposeUiNode> function8;
                    Composer composer3;
                    boolean z2;
                    Composer composer4;
                    boolean zChangedInstance;
                    Object objRememberedValue2;
                    Composer composer5;
                    boolean z3;
                    RenderedCard preview;
                    int i2;
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(viewModel, "viewModel");
                    Intrinsics.checkNotNullParameter(onExit, "onExit");
/* 23 */            Composer $composer3 = $composer.startRestartGroup(1807790529);
                    ComposerKt.sourceInformation($composer3, "C(CardEditorScreen)N(state,viewModel,editing,openMedia,onExit)23@1082L7,24@1123L25,24@1106L42,25@1166L71,26@1239L31,27@1300L27,27@1272L55,28@1329L1937:CardEditorScreen.kt#i35lj1");
                    int currentMarker = $composer3.getCurrentMarker();
                    int $dirty2 = $changed;
                    if (($changed & 6) == 0) {
                        $dirty2 |= $composer3.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty2 |= $composer3.changedInstance(viewModel) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty2 |= $composer3.changed(editing) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        if ((i & 8) == 0) {
                            function3 = function2;
                            int i3 = $composer3.changedInstance(function3) ? 2048 : 1024;
                            $dirty2 |= i3;
                        } else {
                            function3 = function2;
                        }
                        $dirty2 |= i3;
                    } else {
                        function3 = function2;
                    }
                    if (($changed & 24576) == 0) {
                        $dirty2 |= $composer3.changedInstance(onExit) ? 16384 : 8192;
                    }
                    if ($composer3.shouldExecute(($dirty2 & 9363) != 9362, $dirty2 & 1)) {
                        $composer3.startDefaults();
                        ComposerKt.sourceInformation($composer3, "22@1027L6");
                        if (($changed & 1) != 0 && !$composer3.getDefaultsInvalid()) {
                            $composer3.skipToGroupEnd();
                            if ((i & 8) != 0) {
                                function5 = function3;
                                $dirty = $dirty2 & (-7169);
                            } else {
                                function5 = function3;
                                $dirty = $dirty2;
                            }
                        } else if ((i & 8) != 0) {
                            ComposerKt.sourceInformationMarkerStart($composer3, 2119914855, "CC(remember):CardEditorScreen.kt#9igjgp");
/* 65 */                    Object objRememberedValue3 = $composer3.rememberedValue();
/* 66 */                    if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
/* 23 */                        Object obj = (Function2) new CardEditorScreenKt$CardEditorScreen$1$1(null);
/* 68 */                        $composer3.updateRememberedValue(obj);
/* 69 */                        objRememberedValue3 = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 23 */                    function5 = (Function2) objRememberedValue3;
                            $dirty = $dirty2 & (-7169);
                        } else {
                            function5 = function3;
                            $dirty = $dirty2;
                        }
                        $composer3.endDefaults();
                        if (ComposerKt.isTraceInProgress()) {
/* 23 */                    ComposerKt.traceEventStart(1807790529, $dirty, -1, "com.xunji.flashcards.ui.screens.CardEditorScreen (CardEditorScreen.kt:22)");
                        }
/* 24 */                ProvidableCompositionLocal<FocusManager> localFocusManager = CompositionLocalsKt.getLocalFocusManager();
/* 71 */                ComposerKt.sourceInformationMarkerStart($composer3, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                        Object objConsume = $composer3.consume(localFocusManager);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 24 */                final FocusManager focus = (FocusManager) objConsume;
                        Object[] objArr = new Object[0];
/* 25 */                ComposerKt.sourceInformationMarkerStart($composer3, 2119917946, "CC(remember):CardEditorScreen.kt#9igjgp");
/* 72 */                Object objRememberedValue4 = $composer3.rememberedValue();
/* 73 */                if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                            Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda11
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$1$0();
                                }
                            };
/* 75 */                    $composer3.updateRememberedValue(obj2);
/* 76 */                    objRememberedValue4 = obj2;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 25 */                final MutableState discard$delegate = (MutableState) RememberSaveableKt.rememberSaveable(objArr, (Function0) objRememberedValue4, $composer3, 48);
/* 26 */                ComposerKt.sourceInformationMarkerStart($composer3, 2119919368, "CC(remember):CardEditorScreen.kt#9igjgp");
                        boolean zChangedInstance2 = $composer3.changedInstance(state) | $composer3.changed(discard$delegate) | (($dirty & 57344) == 16384);
                        Object objRememberedValue5 = $composer3.rememberedValue();
/* 79 */                if (zChangedInstance2 || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                            Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda16
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$4$0(state, onExit, discard$delegate);
                                }
                            };
/* 81 */                    $composer3.updateRememberedValue(obj3);
/* 82 */                    objRememberedValue5 = obj3;
                        }
/* 26 */                Function0 requestExit = (Function0) objRememberedValue5;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 27 */                BackHandlerKt.BackHandler(false, requestExit, $composer3, 0, 1);
/* 28 */                Boolean boolValueOf = Boolean.valueOf(state.getSaved());
                        ComposerKt.sourceInformationMarkerStart($composer3, 2119923612, "CC(remember):CardEditorScreen.kt#9igjgp");
/* 78 */                boolean zChangedInstance3 = $composer3.changedInstance(state) | (($dirty & 57344) == 16384);
                        CardEditorScreenKt$CardEditorScreen$2$1 cardEditorScreenKt$CardEditorScreen$2$1RememberedValue = $composer3.rememberedValue();
/* 85 */                if (zChangedInstance3 || cardEditorScreenKt$CardEditorScreen$2$1RememberedValue == Composer.INSTANCE.getEmpty()) {
                            cardEditorScreenKt$CardEditorScreen$2$1RememberedValue = new CardEditorScreenKt$CardEditorScreen$2$1(state, onExit, null);
/* 87 */                    $composer3.updateRememberedValue(cardEditorScreenKt$CardEditorScreen$2$1RememberedValue);
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 28 */                EffectsKt.LaunchedEffect(boolValueOf, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) cardEditorScreenKt$CardEditorScreen$2$1RememberedValue, $composer3, 0);
/* 29 */                Modifier modifierImePadding = WindowInsetsPadding_androidKt.imePadding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null));
/* 90 */                ComposerKt.sourceInformationMarkerStart($composer3, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 95 */                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer3, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 101 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 102 */               CompositionLocalMap currentCompositionLocalMap = $composer3.getCurrentCompositionLocalMap();
/* 103 */               int $dirty3 = $dirty;
                        Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer3, modifierImePadding);
/* 105 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 99 */                int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 107 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 108 */               $composer3.startReusableNode();
/* 109 */               if ($composer3.getInserting()) {
/* 110 */                   function0 = constructor;
                            $composer3.createNode(function0);
                        } else {
/* 112 */                   function0 = constructor;
                            $composer3.useNode();
                        }
                        Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer3);
/* 115 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 116 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 117 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 119 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 118 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 121 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 124 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 126 */               int i5 = (i4 >> 6) & 14;
/* 97 */                ComposerKt.sourceInformationMarkerStart($composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        int i6 = ((0 >> 6) & 112) | 6;
                        ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
/* 30 */                $composer3.startReplaceGroup(763540430);
                        ComposerKt.sourceInformation($composer3, "C29@1377L239,31@1696L21,31@1654L1411,49@3068L195:CardEditorScreen.kt#i35lj1");
/* 30 */                Modifier modifierM841paddingVpY3zN4 = PaddingKt.m841paddingVpY3zN4(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(10), Dp.m8404constructorimpl(6));
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                        ComposerKt.sourceInformationMarkerStart($composer3, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 133 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer3, ((390 >> 3) & 14) | ((390 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 139 */               int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
                        CompositionLocalMap currentCompositionLocalMap2 = $composer3.getCurrentCompositionLocalMap();
/* 134 */               Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer3, modifierM841paddingVpY3zN4);
/* 143 */               Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
                        int i7 = ((((390 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 145 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 146 */               $composer3.startReusableNode();
/* 147 */               if ($composer3.getInserting()) {
/* 148 */                   function1 = constructor2;
                            $composer3.createNode(function1);
                        } else {
/* 150 */                   function1 = constructor2;
                            $composer3.useNode();
                        }
                        Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer3);
/* 153 */               Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 154 */               Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 155 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 157 */               if (composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 156 */                   composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 159 */                   composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
                        }
/* 162 */               Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 164 */               int i8 = (i7 >> 6) & 14;
/* 135 */               ComposerKt.sourceInformationMarkerStart($composer3, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i9 = ((390 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer3, -1482987813, "C29@1473L63,29@1592L10,29@1537L77:CardEditorScreen.kt#i35lj1");
/* 84 */                XunjiComponentsKt.IconAction("back", "返回", requestExit, "editor-exit", !state.getSaving(), $composer3, 3126, 0);
                        TextKt.m3584TextNvy7gAk(editing ? "编辑卡片" : "新建卡片", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer3, MaterialTheme.$stable).getTitleLarge(), $composer3, 0, 0, 131070);
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 135 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 165 */               $composer3.endNode();
/* 144 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 138 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 128 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 31 */                if (state.getLoading()) {
                            $composer3.startReplaceGroup(763739356);
                            ComposerKt.sourceInformation($composer3, "30@1637L6");
                            XunjiComponentsKt.Busy($composer3, 0);
                            $composer3.endToMarker(currentMarker);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 53 */                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer3.endRestartGroup();
                            if (scopeUpdateScopeEndRestartGroup != null) {
                                final Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function9 = function5;
                                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda17
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj4, Object obj5) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$1(state, viewModel, editing, function9, onExit, $changed, i, (Composer) obj4, ((Integer) obj5).intValue());
                                    }
                                });
/* 31 */                        return;
                            }
/* 31 */                    return;
                        }
                        $composer3.startReplaceGroup(762114987);
                        $composer3.endReplaceGroup();
/* 32 */                Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(ScrollKt.verticalScroll$default(ColumnScope.weight$default(columnScope, Modifier.INSTANCE, 1.0f, false, 2, null), ScrollKt.rememberScrollState(0, $composer3, 0, 1), false, null, false, 14, null), Dp.m8404constructorimpl(22));
/* 32 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(20));
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 169 */               MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer3, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 169 */               int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 169 */               CompositionLocalMap currentCompositionLocalMap3 = $composer3.getCurrentCompositionLocalMap();
/* 169 */               Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer3, modifierM840padding3ABfNKs);
/* 184 */               Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
                        int i10 = ((((48 << 3) & 112) << 6) & 896) | 6;
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 186 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 187 */               $composer3.startReusableNode();
/* 188 */               if ($composer3.getInserting()) {
/* 189 */                   function6 = constructor3;
/* 169 */                   $composer3.createNode(function6);
                        } else {
/* 191 */                   function6 = constructor3;
/* 169 */                   $composer3.useNode();
                        }
/* 169 */               Composer composerM4979constructorimpl3 = Updater.m4979constructorimpl($composer3);
/* 194 */               Updater.m4986setimpl(composerM4979constructorimpl3, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 195 */               Updater.m4986setimpl(composerM4979constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 196 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 198 */               if (composerM4979constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
/* 197 */                   composerM4979constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
/* 200 */                   composerM4979constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
                        }
/* 203 */               Updater.m4986setimpl(composerM4979constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 205 */               int i11 = (i10 >> 6) & 14;
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                        int i12 = ((48 >> 6) & 112) | 6;
/* 169 */               Composer composer6 = $composer3;
                        ComposerKt.sourceInformationMarkerStart(composer6, -874671683, "C:CardEditorScreen.kt#i35lj1");
                        if (state.getAnkiFieldNames() != null) {
                            composer6.startReplaceGroup(-874657610);
                            ComposerKt.sourceInformation(composer6, "33@1825L81,35@2108L295");
                            XunjiComponentsKt.Notice("同一笔记的 " + state.getLinkedCards() + " 张已保存卡片会联动更新。字段含 HTML 或媒体引用时请编辑源码；这里不会自动转换排版。", false, composer6, 0, 2);
                            composer6.startReplaceGroup(1772903608);
                            ComposerKt.sourceInformation(composer6, "*34@2029L32,34@1963L138");
/* 35 */                    Iterable ankiFieldNames = state.getAnkiFieldNames();
                            int i13 = 0;
/* 206 */                   final int i14 = 0;
                            for (Object obj4 : ankiFieldNames) {
                                int i15 = i14 + 1;
                                if (i14 < 0) {
                                    CollectionsKt.throwIndexOverflow();
                                }
                                String str = (String) obj4;
/* 35 */                        Iterable iterable = ankiFieldNames;
                                String str2 = state.getAnkiFields().get(i14);
                                ComposerKt.sourceInformationMarkerStart(composer6, 916436878, "CC(remember):CardEditorScreen.kt#9igjgp");
                                boolean zChangedInstance4 = $composer3.changedInstance(viewModel) | $composer3.changed(i14);
                                Composer composer7 = composer6;
                                Object objRememberedValue6 = composer7.rememberedValue();
/* 209 */                       if (zChangedInstance4) {
/* 209 */                           i2 = i13;
                                } else {
                                    i2 = i13;
                                    if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                                    }
                                    ComposerKt.sourceInformationMarkerEnd(composer6);
                                    Composer composer8 = composer6;
/* 35 */                            EditorField(str, "保留原 HTML / [sound:文件名]", str2, (Function1) objRememberedValue6, null, "anki-field-" + i14, !state.getSaving(), composer8, 24624);
                                    ankiFieldNames = iterable;
/* 207 */                           composer6 = composer8;
                                    i14 = i15;
                                    i13 = i2;
                                }
                                objRememberedValue6 = new Function1() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda18
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj5) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$2$0$0$0(viewModel, i14, (String) obj5);
                                    }
                                };
/* 211 */                       composer7.updateRememberedValue(objRememberedValue6);
                                ComposerKt.sourceInformationMarkerEnd(composer6);
                                Composer composer9 = composer6;
/* 35 */                        EditorField(str, "保留原 HTML / [sound:文件名]", str2, (Function1) objRememberedValue6, null, "anki-field-" + i14, !state.getSaving(), composer9, 24624);
                                ankiFieldNames = iterable;
/* 207 */                       composer6 = composer9;
                                i14 = i15;
                                i13 = i2;
                            }
                            composer = composer6;
                            composer.endReplaceGroup();
/* 36 */                    Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
                            ComposerKt.sourceInformationMarkerStart(composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 217 */                   Modifier modifier = Modifier.INSTANCE;
/* 216 */                   MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                            ComposerKt.sourceInformationMarkerStart(composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 228 */                   int iHashCode4 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer, 0));
                            CompositionLocalMap currentCompositionLocalMap4 = composer.getCurrentCompositionLocalMap();
/* 223 */                   Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier(composer, modifier);
/* 232 */                   Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
/* 226 */                   int i16 = ((((48 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 234 */                   if (!(composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 235 */                   composer.startReusableNode();
/* 236 */                   if (composer.getInserting()) {
/* 237 */                       function8 = constructor4;
                                composer.createNode(function8);
                            } else {
/* 239 */                       function8 = constructor4;
                                composer.useNode();
                            }
/* 241 */                   Composer composerM4979constructorimpl4 = Updater.m4979constructorimpl(composer);
/* 242 */                   Updater.m4986setimpl(composerM4979constructorimpl4, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 243 */                   Updater.m4986setimpl(composerM4979constructorimpl4, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 244 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 246 */                   if (composerM4979constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl4.rememberedValue(), Integer.valueOf(iHashCode4))) {
/* 245 */                       composerM4979constructorimpl4.updateRememberedValue(Integer.valueOf(iHashCode4));
/* 248 */                       composerM4979constructorimpl4.apply(Integer.valueOf(iHashCode4), setCompositeKeyHash4);
                            }
/* 251 */                   Updater.m4986setimpl(composerM4979constructorimpl4, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
/* 253 */                   int i17 = (i16 >> 6) & 14;
/* 241 */                   ComposerKt.sourceInformationMarkerStart(composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
/* 216 */                   int i18 = ((48 >> 6) & 112) | 6;
/* 241 */                   ComposerKt.sourceInformationMarkerStart(composer, -1675273325, "C36@2184L38,36@2169L112,37@2302L36,37@2287L110:CardEditorScreen.kt#i35lj1");
/* 241 */                   ComposerKt.sourceInformationMarkerStart(composer, -1023872110, "CC(remember):CardEditorScreen.kt#9igjgp");
                            boolean zChangedInstance5 = $composer3.changedInstance(viewModel);
/* 241 */                   Object objRememberedValue7 = composer.rememberedValue();
/* 255 */                   if (zChangedInstance5) {
/* 255 */                       composer3 = composer;
                            } else {
/* 241 */                       composer3 = composer;
                                if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
                                }
/* 37 */                        Function0 function10 = (Function0) objRememberedValue7;
                                ComposerKt.sourceInformationMarkerEnd(composer3);
                                if (!state.getSaving() || state.getPreviewing()) {
                                    z2 = false;
                                } else {
                                    z2 = true;
                                }
                                ButtonKt.OutlinedButton(function10, null, z2, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$1652162462$app_debug(), composer3, 805306368, 506);
/* 38 */                        composer4 = composer3;
                                ComposerKt.sourceInformationMarkerStart(composer4, -1023868336, "CC(remember):CardEditorScreen.kt#9igjgp");
                                zChangedInstance = $composer3.changedInstance(viewModel);
                                objRememberedValue2 = composer4.rememberedValue();
/* 261 */                       if (zChangedInstance) {
/* 261 */                           composer5 = composer4;
                                } else {
                                    composer5 = composer4;
                                    if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                    }
/* 38 */                            Function0 function11 = (Function0) objRememberedValue2;
                                    ComposerKt.sourceInformationMarkerEnd(composer5);
                                    if (!state.getSaving() || state.getPreviewing()) {
                                        z3 = false;
                                    } else {
                                        z3 = true;
                                    }
                                    ButtonKt.OutlinedButton(function11, null, z3, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$232184213$app_debug(), composer5, 805306368, 506);
/* 37 */                            ComposerKt.sourceInformationMarkerEnd(composer5);
/* 224 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 266 */                           composer.endNode();
/* 233 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 227 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 216 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 40 */                            if (state.getPreviewing()) {
                                        composer.startReplaceGroup(1772919336);
                                        ComposerKt.sourceInformation(composer, "39@2428L27");
                                        ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(null, 0L, 0.0f, 0L, 0, 0.0f, composer, 0, 63);
                                    } else {
                                        composer.startReplaceGroup(-876485835);
                                    }
                                    composer.endReplaceGroup();
/* 41 */                            preview = state.getPreview();
                                    if (preview == null) {
                                        composer.startReplaceGroup(-874027350);
                                        composer.endReplaceGroup();
                                    } else {
                                        composer.startReplaceGroup(-874027349);
                                        ComposerKt.sourceInformation(composer, "*40@2480L68");
/* 41 */                                AnkiCardContentKt.AnkiCardContent(preview, function5, SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(400)), composer, (($dirty3 >> 6) & 112) | 384, 0);
                                        Unit unit = Unit.INSTANCE;
                                        composer.endReplaceGroup();
                                        Unit unit2 = Unit.INSTANCE;
                                    }
/* 33 */                            composer.endReplaceGroup();
                                }
                                objRememberedValue2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda2
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$2$1$1$0(viewModel);
                                    }
                                };
/* 263 */                       composer4.updateRememberedValue(objRememberedValue2);
/* 38 */                        Function0 function12 = (Function0) objRememberedValue2;
                                ComposerKt.sourceInformationMarkerEnd(composer5);
                                if (state.getSaving()) {
                                    z3 = false;
                                } else {
                                    z3 = false;
                                }
                                ButtonKt.OutlinedButton(function12, null, z3, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$232184213$app_debug(), composer5, 805306368, 506);
/* 37 */                        ComposerKt.sourceInformationMarkerEnd(composer5);
/* 224 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 266 */                       composer.endNode();
/* 233 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 227 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 216 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 40 */                        if (state.getPreviewing()) {
                                    composer.startReplaceGroup(1772919336);
                                    ComposerKt.sourceInformation(composer, "39@2428L27");
                                    ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(null, 0L, 0.0f, 0L, 0, 0.0f, composer, 0, 63);
                                } else {
                                    composer.startReplaceGroup(-876485835);
                                }
                                composer.endReplaceGroup();
/* 41 */                        preview = state.getPreview();
                                if (preview == null) {
                                    composer.startReplaceGroup(-874027350);
                                    composer.endReplaceGroup();
                                } else {
                                    composer.startReplaceGroup(-874027349);
                                    ComposerKt.sourceInformation(composer, "*40@2480L68");
/* 41 */                            AnkiCardContentKt.AnkiCardContent(preview, function5, SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(400)), composer, (($dirty3 >> 6) & 112) | 384, 0);
                                    Unit unit3 = Unit.INSTANCE;
                                    composer.endReplaceGroup();
                                    Unit unit4 = Unit.INSTANCE;
                                }
/* 33 */                        composer.endReplaceGroup();
                            }
                            objRememberedValue7 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda1
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$6$2$1$0$0(viewModel);
                                }
                            };
/* 257 */                   composer.updateRememberedValue(objRememberedValue7);
/* 37 */                    Function0 function13 = (Function0) objRememberedValue7;
                            ComposerKt.sourceInformationMarkerEnd(composer3);
                            if (state.getSaving()) {
                                z2 = false;
                            } else {
                                z2 = false;
                            }
                            ButtonKt.OutlinedButton(function13, null, z2, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$1652162462$app_debug(), composer3, 805306368, 506);
/* 38 */                    composer4 = composer3;
                            ComposerKt.sourceInformationMarkerStart(composer4, -1023868336, "CC(remember):CardEditorScreen.kt#9igjgp");
                            zChangedInstance = $composer3.changedInstance(viewModel);
                            objRememberedValue2 = composer4.rememberedValue();
/* 261 */                   if (zChangedInstance) {
                                composer5 = composer4;
                                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                }
/* 38 */                        Function0 function14 = (Function0) objRememberedValue2;
                                ComposerKt.sourceInformationMarkerEnd(composer5);
                                if (state.getSaving()) {
                                    z3 = false;
                                } else {
                                    z3 = false;
                                }
                                ButtonKt.OutlinedButton(function14, null, z3, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$232184213$app_debug(), composer5, 805306368, 506);
/* 37 */                        ComposerKt.sourceInformationMarkerEnd(composer5);
/* 224 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 266 */                       composer.endNode();
/* 233 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 227 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 216 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 40 */                        if (state.getPreviewing()) {
                                    composer.startReplaceGroup(1772919336);
                                    ComposerKt.sourceInformation(composer, "39@2428L27");
                                    ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(null, 0L, 0.0f, 0L, 0, 0.0f, composer, 0, 63);
                                } else {
                                    composer.startReplaceGroup(-876485835);
                                }
                                composer.endReplaceGroup();
/* 41 */                        preview = state.getPreview();
                                if (preview == null) {
                                    composer.startReplaceGroup(-874027350);
                                    composer.endReplaceGroup();
                                } else {
                                    composer.startReplaceGroup(-874027349);
                                    ComposerKt.sourceInformation(composer, "*40@2480L68");
/* 41 */                            AnkiCardContentKt.AnkiCardContent(preview, function5, SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(400)), composer, (($dirty3 >> 6) & 112) | 384, 0);
                                    Unit unit5 = Unit.INSTANCE;
                                    composer.endReplaceGroup();
                                    Unit unit6 = Unit.INSTANCE;
                                }
/* 33 */                        composer.endReplaceGroup();
                            } else {
/* 261 */                       composer5 = composer4;
                            }
                            objRememberedValue2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda2
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$6$2$1$1$0(viewModel);
                                }
                            };
/* 263 */                   composer4.updateRememberedValue(objRememberedValue2);
/* 38 */                    Function0 function15 = (Function0) objRememberedValue2;
                            ComposerKt.sourceInformationMarkerEnd(composer5);
                            if (state.getSaving()) {
                                z3 = false;
                            } else {
                                z3 = false;
                            }
                            ButtonKt.OutlinedButton(function15, null, z3, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$232184213$app_debug(), composer5, 805306368, 506);
/* 37 */                    ComposerKt.sourceInformationMarkerEnd(composer5);
/* 224 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 266 */                   composer.endNode();
/* 233 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 227 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 216 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 40 */                    if (state.getPreviewing()) {
                                composer.startReplaceGroup(1772919336);
                                ComposerKt.sourceInformation(composer, "39@2428L27");
                                ProgressIndicatorKt.m3159CircularProgressIndicator4lLiAd8(null, 0L, 0.0f, 0L, 0, 0.0f, composer, 0, 63);
                            } else {
                                composer.startReplaceGroup(-876485835);
                            }
                            composer.endReplaceGroup();
/* 41 */                    preview = state.getPreview();
                            if (preview == null) {
                                composer.startReplaceGroup(-874027350);
                                composer.endReplaceGroup();
                            } else {
                                composer.startReplaceGroup(-874027349);
                                ComposerKt.sourceInformation(composer, "*40@2480L68");
/* 41 */                        AnkiCardContentKt.AnkiCardContent(preview, function5, SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(400)), composer, (($dirty3 >> 6) & 112) | 384, 0);
                                Unit unit7 = Unit.INSTANCE;
                                composer.endReplaceGroup();
                                Unit unit8 = Unit.INSTANCE;
                            }
/* 33 */                    composer.endReplaceGroup();
                        } else {
/* 42 */                    composer = composer6;
                            composer.startReplaceGroup(-873931311);
                            ComposerKt.sourceInformation(composer, "42@2565L26,43@2647L30,43@2595L134,44@2786L29,44@2733L132,45@2919L32,45@2869L138");
/* 106 */                   XunjiComponentsKt.Notice("让问题简单一点，让答案清楚一点。", false, composer, 6, 2);
/* 44 */                    String front = state.getFront();
                            ComposerKt.sourceInformationMarkerStart(composer, 1772926347, "CC(remember):CardEditorScreen.kt#9igjgp");
                            boolean zChangedInstance6 = $composer3.changedInstance(viewModel);
/* 272 */                   Object objRememberedValue8 = composer.rememberedValue();
/* 273 */                   if (zChangedInstance6 || objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                                Object obj5 = new Function1() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda3
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj6) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$2$3$0(viewModel, (String) obj6);
                                    }
                                };
/* 275 */                       composer.updateRememberedValue(obj5);
/* 276 */                       objRememberedValue8 = obj5;
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 44 */                    EditorField("正面 · 问题或词汇", "例如：resilient", front, (Function1) objRememberedValue8, state.getErrors().get("front"), "editor-front", !state.getSaving(), composer, 196662);
/* 45 */                    String back = state.getBack();
                            ComposerKt.sourceInformationMarkerStart(composer, 1772930794, "CC(remember):CardEditorScreen.kt#9igjgp");
                            boolean zChangedInstance7 = $composer3.changedInstance(viewModel);
/* 278 */                   Object objRememberedValue9 = composer.rememberedValue();
/* 279 */                   if (zChangedInstance7 || objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
                                Object obj6 = new Function1() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda4
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj7) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$2$4$0(viewModel, (String) obj7);
                                    }
                                };
/* 281 */                       composer.updateRememberedValue(obj6);
/* 282 */                       objRememberedValue9 = obj6;
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 45 */                    EditorField("背面 · 答案或释义", "例如：有韧性的；能迅速恢复的", back, (Function1) objRememberedValue9, state.getErrors().get("back"), "editor-back", !state.getSaving(), composer, 196662);
/* 46 */                    String example = state.getExample();
                            ComposerKt.sourceInformationMarkerStart(composer, 1772935053, "CC(remember):CardEditorScreen.kt#9igjgp");
                            boolean zChangedInstance8 = $composer3.changedInstance(viewModel);
/* 284 */                   Object objRememberedValue10 = composer.rememberedValue();
/* 285 */                   if (zChangedInstance8 || objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
                                Object obj7 = new Function1() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda5
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj8) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$6$2$5$0(viewModel, (String) obj8);
                                    }
                                };
/* 287 */                       composer.updateRememberedValue(obj7);
/* 288 */                       objRememberedValue10 = obj7;
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 46 */                    EditorField("例句 · 可选", "给这个知识点一个上下文", example, (Function1) objRememberedValue10, state.getErrors().get("example"), "editor-example", !state.getSaving(), composer, 196662);
/* 42 */                    composer.endReplaceGroup();
                            Unit unit9 = Unit.INSTANCE;
                        }
/* 48 */                if (state.getError() != null) {
                            composer.startReplaceGroup(1772938821);
                            ComposerKt.sourceInformation(composer, "47@3037L24");
                            XunjiComponentsKt.Notice(state.getError(), true, composer, 48, 0);
                        } else {
                            composer.startReplaceGroup(-876485835);
                        }
                        composer.endReplaceGroup();
/* 33 */                ComposerKt.sourceInformationMarkerEnd(composer);
/* 176 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 290 */               $composer3.endNode();
/* 185 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 179 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 170 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 50 */                Modifier modifierM843paddingqDBjuR0 = PaddingKt.m843paddingqDBjuR0(Modifier.INSTANCE, Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(12), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(20));
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 297 */               MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 169 */               int iHashCode5 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer3, 0));
/* 307 */               CompositionLocalMap currentCompositionLocalMap5 = $composer3.getCurrentCompositionLocalMap();
/* 169 */               Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier($composer3, modifierM843paddingqDBjuR0);
/* 310 */               Function0<ComposeUiNode> constructor5 = ComposeUiNode.INSTANCE.getConstructor();
/* 304 */               int i19 = ((((6 << 3) & 112) << 6) & 896) | 6;
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 312 */               if (!($composer3.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 313 */               $composer3.startReusableNode();
/* 314 */               if ($composer3.getInserting()) {
/* 315 */                   function7 = constructor5;
/* 169 */                   $composer3.createNode(function7);
                        } else {
/* 317 */                   function7 = constructor5;
/* 169 */                   $composer3.useNode();
                        }
/* 319 */               Composer composerM4979constructorimpl5 = Updater.m4979constructorimpl($composer3);
/* 320 */               Updater.m4986setimpl(composerM4979constructorimpl5, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 321 */               Updater.m4986setimpl(composerM4979constructorimpl5, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 322 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 324 */               if (composerM4979constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl5.rememberedValue(), Integer.valueOf(iHashCode5))) {
/* 323 */                   composerM4979constructorimpl5.updateRememberedValue(Integer.valueOf(iHashCode5));
/* 326 */                   composerM4979constructorimpl5.apply(Integer.valueOf(iHashCode5), setCompositeKeyHash5);
                        }
/* 329 */               Updater.m4986setimpl(composerM4979constructorimpl5, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
/* 331 */               int i20 = (i19 >> 6) & 14;
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                        BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
/* 305 */               int i21 = ((6 >> 6) & 112) | 6;
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, -22436906, "C49@3167L37,49@3117L144:CardEditorScreen.kt#i35lj1");
                        String str3 = state.getSaving() ? "正在保存…" : "保存卡片";
/* 169 */               ComposerKt.sourceInformationMarkerStart($composer3, 276372386, "CC(remember):CardEditorScreen.kt#9igjgp");
                        boolean zChangedInstance9 = $composer3.changedInstance(focus) | $composer3.changedInstance(viewModel);
/* 169 */               Object objRememberedValue11 = $composer3.rememberedValue();
/* 333 */               if (zChangedInstance9) {
/* 333 */                   composer2 = $composer3;
                        } else {
/* 169 */                   composer2 = $composer3;
                            if (objRememberedValue11 == Composer.INSTANCE.getEmpty()) {
                            }
/* 50 */                    Function0 function16 = (Function0) objRememberedValue11;
                            ComposerKt.sourceInformationMarkerEnd(composer2);
                            if (!state.getSaving() || state.getLoading()) {
                                z = false;
                            } else {
                                z = true;
                            }
                            XunjiComponentsKt.PrimaryButton(str3, function16, null, z, "save-card", composer2, 24576, 4);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
/* 302 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 338 */                   $composer3.endNode();
/* 311 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 305 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 295 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 169 */                   $composer3.endReplaceGroup();
/* 97 */                    ComposerKt.sourceInformationMarkerEnd($composer3);
/* 342 */                   $composer3.endNode();
/* 106 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 100 */                   ComposerKt.sourceInformationMarkerEnd($composer3);
/* 90 */                    ComposerKt.sourceInformationMarkerEnd($composer3);
/* 52 */                    if (CardEditorScreen$lambda$2(discard$delegate)) {
                                $composer3.startReplaceGroup(2119987179);
                                ComposerKt.sourceInformation($composer3, "51@3308L15,51@3393L91,51@3499L45,51@3279L266");
                                ComposerKt.sourceInformationMarkerStart($composer3, 2119987856, "CC(remember):CardEditorScreen.kt#9igjgp");
                                zChanged = $composer3.changed(discard$delegate);
/* 346 */                       objRememberedValue = $composer3.rememberedValue();
/* 347 */                       if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 52 */                            Object obj8 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda12
                                        @Override // kotlin.jvm.functions.Function0
                                        public final Object invoke() {
                                            return CardEditorScreenKt.CardEditorScreen$lambda$7$0(discard$delegate);
                                        }
                                    };
/* 349 */                           $composer3.updateRememberedValue(obj8);
/* 350 */                           objRememberedValue = obj8;
                                }
                                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 52 */                        AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0((Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(-1449560044, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda13
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj9, Object obj10) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$8(discard$delegate, onExit, (Composer) obj9, ((Integer) obj10).intValue());
                                    }
                                }, $composer3, 54), null, ComposableLambdaKt.rememberComposableLambda(-977220398, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda14
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj9, Object obj10) {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$9(discard$delegate, (Composer) obj9, ((Integer) obj10).intValue());
                                    }
                                }, $composer3, 54), null, ComposableSingletons$CardEditorScreenKt.INSTANCE.m8991getLambda$504880752$app_debug(), ComposableSingletons$CardEditorScreenKt.INSTANCE.m8990getLambda$268710929$app_debug(), null, 0L, 0L, 0L, 0L, 0.0f, null, $composer3, 1772592, 0, 16276);
                                $composer2 = $composer3;
                            } else {
                                $composer2 = $composer3;
                                $composer2.startReplaceGroup(1291831105);
                            }
                            $composer2.endReplaceGroup();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 53 */                    function4 = function5;
                        }
                        objRememberedValue11 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return CardEditorScreenKt.CardEditorScreen$lambda$6$3$0$0(focus, viewModel);
                            }
                        };
/* 335 */               $composer3.updateRememberedValue(objRememberedValue11);
/* 50 */                Function0 function17 = (Function0) objRememberedValue11;
                        ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (state.getSaving()) {
                            z = false;
                        } else {
                            z = false;
                        }
                        XunjiComponentsKt.PrimaryButton(str3, function17, null, z, "save-card", composer2, 24576, 4);
                        ComposerKt.sourceInformationMarkerEnd(composer2);
/* 302 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 338 */               $composer3.endNode();
/* 311 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 305 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 295 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 169 */               $composer3.endReplaceGroup();
/* 97 */                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 342 */               $composer3.endNode();
/* 106 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 100 */               ComposerKt.sourceInformationMarkerEnd($composer3);
/* 90 */                ComposerKt.sourceInformationMarkerEnd($composer3);
/* 52 */                if (CardEditorScreen$lambda$2(discard$delegate)) {
                            $composer3.startReplaceGroup(2119987179);
                            ComposerKt.sourceInformation($composer3, "51@3308L15,51@3393L91,51@3499L45,51@3279L266");
                            ComposerKt.sourceInformationMarkerStart($composer3, 2119987856, "CC(remember):CardEditorScreen.kt#9igjgp");
                            zChanged = $composer3.changed(discard$delegate);
/* 346 */                   objRememberedValue = $composer3.rememberedValue();
/* 347 */                   if (zChanged) {
/* 52 */                        Object obj9 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda12
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$7$0(discard$delegate);
                                    }
                                };
/* 349 */                       $composer3.updateRememberedValue(obj9);
/* 350 */                       objRememberedValue = obj9;
                            } else {
/* 52 */                        Object obj10 = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda12
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return CardEditorScreenKt.CardEditorScreen$lambda$7$0(discard$delegate);
                                    }
                                };
/* 349 */                       $composer3.updateRememberedValue(obj10);
/* 350 */                       objRememberedValue = obj10;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer3);
/* 52 */                    AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0((Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(-1449560044, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda13
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj11, Object obj12) {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$8(discard$delegate, onExit, (Composer) obj11, ((Integer) obj12).intValue());
                                }
                            }, $composer3, 54), null, ComposableLambdaKt.rememberComposableLambda(-977220398, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda14
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj11, Object obj12) {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$9(discard$delegate, (Composer) obj11, ((Integer) obj12).intValue());
                                }
                            }, $composer3, 54), null, ComposableSingletons$CardEditorScreenKt.INSTANCE.m8991getLambda$504880752$app_debug(), ComposableSingletons$CardEditorScreenKt.INSTANCE.m8990getLambda$268710929$app_debug(), null, 0L, 0L, 0L, 0L, 0.0f, null, $composer3, 1772592, 0, 16276);
                            $composer2 = $composer3;
                        } else {
                            $composer2 = $composer3;
                            $composer2.startReplaceGroup(1291831105);
                        }
                        $composer2.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
/* 53 */                function4 = function5;
                    } else {
                        $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                        function4 = function3;
                    }
/* 53 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup2 = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup2 != null) {
                        scopeUpdateScopeEndRestartGroup2.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj11, Object obj12) {
                                return CardEditorScreenKt.CardEditorScreen$lambda$10(state, viewModel, editing, function4, onExit, $changed, i, (Composer) obj11, ((Integer) obj12).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 24 */        public static final MutableState CardEditorScreen$lambda$1$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                }

/* 24 */        private static final boolean CardEditorScreen$lambda$2(MutableState<Boolean> mutableState) {
/* 409 */           return mutableState.getValue().booleanValue();
                }

/* 24 */        private static final void CardEditorScreen$lambda$3(MutableState<Boolean> mutableState, boolean z) {
/* 410 */           mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 25 */        public static final Unit CardEditorScreen$lambda$4$0(EditorUiState $state, Function0 $onExit, MutableState $discard$delegate) {
/* 26 */            if (!$state.getSaving()) {
                        if ($state.getDirty()) {
                            CardEditorScreen$lambda$3($discard$delegate, true);
                        } else {
                            $onExit.invoke();
                        }
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final Unit CardEditorScreen$lambda$6$2$0$0$0(EditorViewModel $viewModel, int $index, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 35 */            $viewModel.updateAnki($index, it);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 36 */        public static final Unit CardEditorScreen$lambda$6$2$1$0$0(EditorViewModel $viewModel) {
/* 37 */            $viewModel.preview(CardSide.QUESTION);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 37 */        public static final Unit CardEditorScreen$lambda$6$2$1$1$0(EditorViewModel $viewModel) {
/* 38 */            $viewModel.preview(CardSide.ANSWER);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 43 */        public static final Unit CardEditorScreen$lambda$6$2$3$0(EditorViewModel $viewModel, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 44 */            $viewModel.update("front", it);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 44 */        public static final Unit CardEditorScreen$lambda$6$2$4$0(EditorViewModel $viewModel, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 45 */            $viewModel.update("back", it);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 45 */        public static final Unit CardEditorScreen$lambda$6$2$5$0(EditorViewModel $viewModel, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 46 */            $viewModel.update("example", it);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit CardEditorScreen$lambda$6$3$0$0(FocusManager $focus, EditorViewModel $viewModel) {
/* 50 */            FocusManager.clearFocus$default($focus, false, 1, null);
                    $viewModel.save();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit CardEditorScreen$lambda$7$0(MutableState $discard$delegate) {
/* 52 */            CardEditorScreen$lambda$3($discard$delegate, false);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit CardEditorScreen$lambda$8(final MutableState $discard$delegate, final Function0 $onExit, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C51@3405L24,51@3394L89:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1449560044, $changed, -1, "com.xunji.flashcards.ui.screens.CardEditorScreen.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                ComposerKt.sourceInformationMarkerStart($composer, -1457797972, "CC(remember):CardEditorScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($discard$delegate) | $composer.changed($onExit);
/* 412 */               Object objRememberedValue = $composer.rememberedValue();
/* 413 */               if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 52 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda0
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$8$0$0($onExit, $discard$delegate);
                                }
                            };
/* 415 */                   $composer.updateRememberedValue(obj);
/* 416 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 52 */                ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$274740599$app_debug(), $composer, 805306368, 510);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit CardEditorScreen$lambda$8$0$0(Function0 $onExit, MutableState $discard$delegate) {
/* 52 */            CardEditorScreen$lambda$3($discard$delegate, false);
                    $onExit.invoke();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit CardEditorScreen$lambda$9(final MutableState $discard$delegate, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C51@3511L15,51@3500L42:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-977220398, $changed, -1, "com.xunji.flashcards.ui.screens.CardEditorScreen.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                ComposerKt.sourceInformationMarkerStart($composer, 1489035745, "CC(remember):CardEditorScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($discard$delegate);
/* 412 */               Object objRememberedValue = $composer.rememberedValue();
/* 413 */               if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 52 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda10
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return CardEditorScreenKt.CardEditorScreen$lambda$9$0$0($discard$delegate);
                                }
                            };
/* 415 */                   $composer.updateRememberedValue(obj);
/* 416 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 52 */                ButtonKt.TextButton((Function0) objRememberedValue, null, false, null, null, null, null, null, null, ComposableSingletons$CardEditorScreenKt.INSTANCE.getLambda$747080245$app_debug(), $composer, 805306368, 510);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit CardEditorScreen$lambda$9$0$0(MutableState $discard$delegate) {
/* 52 */            CardEditorScreen$lambda$3($discard$delegate, false);
                    return Unit.INSTANCE;
                }

/* 53 */        private static final void EditorField(final String label, final String placeholder, final String value, final Function1<? super String, Unit> function1, final String error, final String tag, final boolean enabled, Composer $composer, final int $changed) {
                    String str;
                    Function0<ComposeUiNode> function0;
                    Composer $composer2 = $composer.startRestartGroup(-1564156395);
                    ComposerKt.sourceInformation($composer2, "C(EditorField)N(label,placeholder,value,onChange,error,tag,enabled)54@3712L37,55@3783L3,55@3810L7,57@3941L63,57@3904L100,58@4006L408:CardEditorScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        str = label;
                        $dirty |= $composer2.changed(str) ? 4 : 2;
                    } else {
                        str = label;
                    }
                    if (($changed & 48) == 0) {
/* 54 */                $dirty |= $composer2.changed(placeholder) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer2.changed(value) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        $dirty |= $composer2.changedInstance(function1) ? 2048 : 1024;
                    }
                    if (($changed & 24576) == 0) {
                        $dirty |= $composer2.changed(error) ? 16384 : 8192;
                    }
                    if ((196608 & $changed) == 0) {
                        $dirty |= $composer2.changed(tag) ? 131072 : 65536;
                    }
                    if ((1572864 & $changed) == 0) {
                        $dirty |= $composer2.changed(enabled) ? 1048576 : 524288;
                    }
                    if ($composer2.shouldExecute((599187 & $dirty) != 599186, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1564156395, $dirty, -1, "com.xunji.flashcards.ui.screens.EditorField (CardEditorScreen.kt:53)");
                        }
/* 55 */                ComposerKt.sourceInformationMarkerStart($composer2, 84262650, "CC(remember):CardEditorScreen.kt#9igjgp");
/* 352 */               Object objRememberedValue = $composer2.rememberedValue();
/* 353 */               if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 55 */                    Object objBringIntoViewRequester = BringIntoViewRequesterKt.BringIntoViewRequester();
/* 355 */                   $composer2.updateRememberedValue(objBringIntoViewRequester);
/* 356 */                   objRememberedValue = objBringIntoViewRequester;
                        }
/* 55 */                final BringIntoViewRequester errorView = (BringIntoViewRequester) objRememberedValue;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 56 */                WindowInsets ime = WindowInsets_androidKt.getIme(WindowInsets.INSTANCE, $composer2, 6);
                        ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
                        int $dirty2 = $dirty;
                        ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                        Object objConsume = $composer2.consume(localDensity);
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 56 */                int keyboardHeight = ime.getBottom((Density) objConsume);
/* 58 */                Integer numValueOf = Integer.valueOf(keyboardHeight);
                        ComposerKt.sourceInformationMarkerStart($composer2, 84270004, "CC(remember):CardEditorScreen.kt#9igjgp");
                        boolean zChangedInstance = (($dirty2 & 57344) == 16384) | $composer2.changedInstance(errorView);
/* 359 */               Object objRememberedValue2 = $composer2.rememberedValue();
/* 360 */               if (zChangedInstance || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                            Object obj = (Function2) new CardEditorScreenKt$EditorField$1$1(error, errorView, null);
/* 362 */                   $composer2.updateRememberedValue(obj);
/* 363 */                   objRememberedValue2 = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 58 */                EffectsKt.LaunchedEffect(error, numValueOf, (Function2) objRememberedValue2, $composer2, ($dirty2 >> 12) & 14);
/* 59 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(10));
/* 366 */               ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 367 */               Modifier modifier = Modifier.INSTANCE;
/* 372 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 377 */               ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 378 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 379 */               CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
/* 380 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifier);
/* 382 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
                        int i = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 384 */               if (!($composer2.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 385 */               $composer2.startReusableNode();
/* 386 */               if ($composer2.getInserting()) {
/* 387 */                   function0 = constructor;
                            $composer2.createNode(function0);
                        } else {
/* 389 */                   function0 = constructor;
                            $composer2.useNode();
                        }
/* 391 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer2);
/* 392 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 393 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 394 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 396 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 395 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 398 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 401 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 403 */               int i2 = (i >> 6) & 14;
/* 374 */               ComposerKt.sourceInformationMarkerStart($composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                        int i3 = ((48 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer2, -512447349, "C59@4097L10,59@4066L54,60@4214L19,60@4339L71,60@4123L288:CardEditorScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getTitleMedium(), $composer2, $dirty2 & 14, 0, 131070);
/* 61 */                OutlinedTextFieldKt.OutlinedTextField(value, function1, TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), tag), enabled, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableLambdaKt.rememberComposableLambda(2126300998, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda7
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return CardEditorScreenKt.EditorField$lambda$2$0(placeholder, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer2, 54), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableLambdaKt.rememberComposableLambda(100820760, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return CardEditorScreenKt.EditorField$lambda$2$1(error, errorView, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer2, 54), error != null, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, false, 8, 3, (MutableInteractionSource) null, (Shape) RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(18)), (TextFieldColors) null, $composer2, (($dirty2 >> 6) & 14) | 12582912 | (($dirty2 >> 6) & 112) | (($dirty2 >> 9) & 7168), 905970048, 0, 5492592);
/* 60 */                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 374 */               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 405 */               $composer2.endNode();
/* 383 */               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 377 */               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 366 */               ComposerKt.sourceInformationMarkerEnd($composer2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2.skipToGroupEnd();
                    }
/* 63 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
/* 54 */                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.CardEditorScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return CardEditorScreenKt.EditorField$lambda$3(label, placeholder, value, function1, error, tag, enabled, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 60 */        public static final Unit EditorField$lambda$2$0(String $placeholder, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C60@4215L17:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2126300998, $changed, -1, "com.xunji.flashcards.ui.screens.EditorField.<anonymous>.<anonymous> (CardEditorScreen.kt:60)");
                        }
/* 61 */                TextKt.m3584TextNvy7gAk($placeholder, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 60 */        public static final Unit EditorField$lambda$2$1(String $error, BringIntoViewRequester $errorView, Composer $composer, int $changed) {
                    Composer composer = $composer;
                    ComposerKt.sourceInformation(composer, "C:CardEditorScreen.kt#i35lj1");
                    if (composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(100820760, $changed, -1, "com.xunji.flashcards.ui.screens.EditorField.<anonymous>.<anonymous> (CardEditorScreen.kt:60)");
                        }
/* 61 */                if ($error != null) {
                            composer.startReplaceGroup(-1895496882);
                            ComposerKt.sourceInformation(composer, "60@4355L54");
                            TextKt.m3584TextNvy7gAk($error, BringIntoViewRequesterKt.bringIntoViewRequester(Modifier.INSTANCE, $errorView), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer, 0, 0, 262140);
                            composer = composer;
                        } else {
                            composer.startReplaceGroup(1364815978);
                        }
                        composer.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

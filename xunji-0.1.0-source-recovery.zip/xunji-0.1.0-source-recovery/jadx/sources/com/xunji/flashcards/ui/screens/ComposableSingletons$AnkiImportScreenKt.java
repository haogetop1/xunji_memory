            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: AnkiImportScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 26 */    public final class ComposableSingletons$AnkiImportScreenKt {
                public static final ComposableSingletons$AnkiImportScreenKt INSTANCE = new ComposableSingletons$AnkiImportScreenKt();
                private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$697298713 = ComposableLambdaKt.composableLambdaInstance(697298713, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$AnkiImportScreenKt.lambda_697298713$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$600549193 = ComposableLambdaKt.composableLambdaInstance(600549193, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$AnkiImportScreenKt.lambda_600549193$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$166585512 = ComposableLambdaKt.composableLambdaInstance(166585512, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$AnkiImportScreenKt.lambda_166585512$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$1775359435 = ComposableLambdaKt.composableLambdaInstance(1775359435, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$AnkiImportScreenKt.lambda_1775359435$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$50309940 = ComposableLambdaKt.composableLambdaInstance(50309940, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$AnkiImportScreenKt.lambda_50309940$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$166585512$app_debug() {
                    return lambda$166585512;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$1775359435$app_debug() {
                    return lambda$1775359435;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$50309940$app_debug() {
                    return lambda$50309940;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$600549193$app_debug() {
                    return lambda$600549193;
                }

                public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$697298713$app_debug() {
                    return lambda$697298713;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 27 */        public static final Unit lambda_697298713$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C27@1169L52:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(697298713, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt.lambda$697298713.<anonymous> (AnkiImportScreen.kt:27)");
                        }
/* 28 */                XunjiComponentsKt.SectionTitle("导入 Anki 牌组", "先检查卡片和媒体，再决定是否导入兼容的内容。", $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 50 */        public static final Unit lambda_600549193$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C50@2603L10:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(600549193, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt.lambda$600549193.<anonymous> (AnkiImportScreen.kt:50)");
                        }
/* 51 */                TextKt.m3584TextNvy7gAk("取消", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 66 */        public static final Unit lambda_166585512$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C66@3694L14:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(166585512, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt.lambda$166585512.<anonymous> (AnkiImportScreen.kt:66)");
                        }
/* 67 */                TextKt.m3584TextNvy7gAk("选择其他文件", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 90 */        public static final Unit lambda_1775359435$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C90@5117L11:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1775359435, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt.lambda$1775359435.<anonymous> (AnkiImportScreen.kt:90)");
                        }
/* 91 */                TextKt.m3584TextNvy7gAk("上一页", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 91 */        public static final Unit lambda_50309940$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C91@5289L11:AnkiImportScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(50309940, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$AnkiImportScreenKt.lambda$50309940.<anonymous> (AnkiImportScreen.kt:91)");
                        }
/* 92 */                TextKt.m3584TextNvy7gAk("下一页", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: CardEditorScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 35 */    public final class ComposableSingletons$CardEditorScreenKt {
                public static final ComposableSingletons$CardEditorScreenKt INSTANCE = new ComposableSingletons$CardEditorScreenKt();
                private static Function3<RowScope, Composer, Integer, Unit> lambda$1652162462 = ComposableLambdaKt.composableLambdaInstance(1652162462, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$CardEditorScreenKt.lambda_1652162462$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$232184213 = ComposableLambdaKt.composableLambdaInstance(232184213, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$CardEditorScreenKt.lambda_232184213$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$274740599 = ComposableLambdaKt.composableLambdaInstance(274740599, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$CardEditorScreenKt.lambda_274740599$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$747080245 = ComposableLambdaKt.composableLambdaInstance(747080245, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$CardEditorScreenKt.lambda_747080245$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-504880752, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f56lambda$504880752 = ComposableLambdaKt.composableLambdaInstance(-504880752, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$CardEditorScreenKt.lambda__504880752$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-268710929, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f55lambda$268710929 = ComposableLambdaKt.composableLambdaInstance(-268710929, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$CardEditorScreenKt.lambda__268710929$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-268710929$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m8990getLambda$268710929$app_debug() {
                    return f55lambda$268710929;
                }

                /* JADX INFO: renamed from: getLambda$-504880752$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m8991getLambda$504880752$app_debug() {
                    return f56lambda$504880752;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$1652162462$app_debug() {
                    return lambda$1652162462;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$232184213$app_debug() {
                    return lambda$232184213;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$274740599$app_debug() {
                    return lambda$274740599;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$747080245$app_debug() {
                    return lambda$747080245;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 36 */        public static final Unit lambda_1652162462$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C36@2268L12:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1652162462, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$1652162462.<anonymous> (CardEditorScreen.kt:36)");
                        }
/* 37 */                TextKt.m3584TextNvy7gAk("预览正面", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 37 */        public static final Unit lambda_232184213$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C37@2384L12:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(232184213, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$232184213.<anonymous> (CardEditorScreen.kt:37)");
                        }
/* 38 */                TextKt.m3584TextNvy7gAk("预览背面", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit lambda_274740599$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C51@3464L11,51@3432L50:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(274740599, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$274740599.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                TextKt.m3584TextNvy7gAk("放弃修改", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getError(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262138);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit lambda_747080245$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C51@3529L12:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(747080245, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$747080245.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                TextKt.m3584TextNvy7gAk("继续编辑", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit lambda__268710929$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C51@3356L21:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-268710929, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$-268710929.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                TextKt.m3584TextNvy7gAk("当前内容还没有保存到卡片。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 51 */        public static final Unit lambda__504880752$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C51@3331L17:CardEditorScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-504880752, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$CardEditorScreenKt.lambda$-504880752.<anonymous> (CardEditorScreen.kt:51)");
                        }
/* 52 */                TextKt.m3584TextNvy7gAk("放弃未保存的修改？", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

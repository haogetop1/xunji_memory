            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: DeckDetailScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 38 */    public final class ComposableSingletons$DeckDetailScreenKt {
                public static final ComposableSingletons$DeckDetailScreenKt INSTANCE = new ComposableSingletons$DeckDetailScreenKt();

                /* JADX INFO: renamed from: lambda$-1805515944, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f57lambda$1805515944 = ComposableLambdaKt.composableLambdaInstance(-1805515944, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DeckDetailScreenKt.lambda__1805515944$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$986353046 = ComposableLambdaKt.composableLambdaInstance(986353046, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DeckDetailScreenKt.lambda_986353046$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function2<Composer, Integer, Unit> lambda$1923386033 = ComposableLambdaKt.composableLambdaInstance(1923386033, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$DeckDetailScreenKt.lambda_1923386033$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-1805515944$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m8992getLambda$1805515944$app_debug() {
                    return f57lambda$1805515944;
                }

                public final Function2<Composer, Integer, Unit> getLambda$1923386033$app_debug() {
                    return lambda$1923386033;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$986353046$app_debug() {
                    return lambda$986353046;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit lambda_1923386033$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C39@2640L13:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1923386033, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt.lambda$1923386033.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                TextKt.m3584TextNvy7gAk("删除卡片？", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit lambda_986353046$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C39@3096L10:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(986353046, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt.lambda$986353046.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                TextKt.m3584TextNvy7gAk("取消", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit lambda__1805515944$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C39@3013L11,39@2981L50:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1805515944, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DeckDetailScreenKt.lambda$-1805515944.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                TextKt.m3584TextNvy7gAk("确认删除", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getError(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262138);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

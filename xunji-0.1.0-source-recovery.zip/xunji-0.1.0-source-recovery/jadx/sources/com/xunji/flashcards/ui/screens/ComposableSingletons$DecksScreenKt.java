            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: DecksScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 19 */    public final class ComposableSingletons$DecksScreenKt {
                public static final ComposableSingletons$DecksScreenKt INSTANCE = new ComposableSingletons$DecksScreenKt();

                /* JADX INFO: renamed from: lambda$-1648141507, reason: not valid java name */
                private static Function3<LazyItemScope, Composer, Integer, Unit> f60lambda$1648141507 = ComposableLambdaKt.composableLambdaInstance(-1648141507, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DecksScreenKt.lambda__1648141507$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1537266567, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f59lambda$1537266567 = ComposableLambdaKt.composableLambdaInstance(-1537266567, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DecksScreenKt.lambda__1537266567$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-2114441585, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f61lambda$2114441585 = ComposableLambdaKt.composableLambdaInstance(-2114441585, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$DecksScreenKt.lambda__2114441585$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$128235104 = ComposableLambdaKt.composableLambdaInstance(128235104, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DecksScreenKt.lambda_128235104$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<RowScope, Composer, Integer, Unit> lambda$554789602 = ComposableLambdaKt.composableLambdaInstance(554789602, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$DecksScreenKt.lambda_554789602$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1023886681, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f58lambda$1023886681 = ComposableLambdaKt.composableLambdaInstance(-1023886681, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$DecksScreenKt.lambda__1023886681$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-1023886681$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m8993getLambda$1023886681$app_debug() {
                    return f58lambda$1023886681;
                }

                /* JADX INFO: renamed from: getLambda$-1537266567$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m8994getLambda$1537266567$app_debug() {
                    return f59lambda$1537266567;
                }

                /* JADX INFO: renamed from: getLambda$-1648141507$app_debug, reason: not valid java name */
                public final Function3<LazyItemScope, Composer, Integer, Unit> m8995getLambda$1648141507$app_debug() {
                    return f60lambda$1648141507;
                }

                /* JADX INFO: renamed from: getLambda$-2114441585$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m8996getLambda$2114441585$app_debug() {
                    return f61lambda$2114441585;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$128235104$app_debug() {
                    return lambda$128235104;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$554789602$app_debug() {
                    return lambda$554789602;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 20 */        public static final Unit lambda__1648141507$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C20@1437L6:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1648141507, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$-1648141507.<anonymous> (DecksScreen.kt:20)");
                        }
/* 21 */                XunjiComponentsKt.Busy($composer, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final Unit lambda__1537266567$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C34@3280L10:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1537266567, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$-1537266567.<anonymous> (DecksScreen.kt:34)");
                        }
/* 35 */                TextKt.m3584TextNvy7gAk("取消", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final Unit lambda__2114441585$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C34@2621L12:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-2114441585, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$-2114441585.<anonymous> (DecksScreen.kt:34)");
                        }
/* 35 */                TextKt.m3584TextNvy7gAk("牌组名称", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit lambda_128235104$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C35@3748L11,35@3716L50:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(128235104, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$128235104.<anonymous> (DecksScreen.kt:35)");
                        }
/* 36 */                TextKt.m3584TextNvy7gAk("确认删除", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getError(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262138);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit lambda_554789602$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C35@3831L10:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(554789602, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$554789602.<anonymous> (DecksScreen.kt:35)");
                        }
/* 36 */                TextKt.m3584TextNvy7gAk("取消", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit lambda__1023886681$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C35@3377L13:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1023886681, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$DecksScreenKt.lambda$-1023886681.<anonymous> (DecksScreen.kt:35)");
                        }
/* 36 */                TextKt.m3584TextNvy7gAk("删除牌组？", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

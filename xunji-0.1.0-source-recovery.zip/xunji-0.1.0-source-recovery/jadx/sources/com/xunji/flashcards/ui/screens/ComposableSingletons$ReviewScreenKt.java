            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: ReviewScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 25 */    public final class ComposableSingletons$ReviewScreenKt {
                public static final ComposableSingletons$ReviewScreenKt INSTANCE = new ComposableSingletons$ReviewScreenKt();
                private static Function3<RowScope, Composer, Integer, Unit> lambda$1943808554 = ComposableLambdaKt.composableLambdaInstance(1943808554, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$ReviewScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$ReviewScreenKt.lambda_1943808554$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-964842, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f62lambda$964842 = ComposableLambdaKt.composableLambdaInstance(-964842, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$ReviewScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$ReviewScreenKt.lambda__964842$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-964842$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m8997getLambda$964842$app_debug() {
                    return f62lambda$964842;
                }

                public final Function3<RowScope, Composer, Integer, Unit> getLambda$1943808554$app_debug() {
                    return lambda$1943808554;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 26 */        public static final Unit lambda_1943808554$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C26@1336L10:ReviewScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1943808554, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$ReviewScreenKt.lambda$1943808554.<anonymous> (ReviewScreen.kt:26)");
                        }
/* 27 */                TextKt.m3584TextNvy7gAk("撤销", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 36 */        public static final Unit lambda__964842$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C36@2463L14:ReviewScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-964842, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$ReviewScreenKt.lambda$-964842.<anonymous> (ReviewScreen.kt:36)");
                        }
/* 37 */                TextKt.m3584TextNvy7gAk("检查到期卡片", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

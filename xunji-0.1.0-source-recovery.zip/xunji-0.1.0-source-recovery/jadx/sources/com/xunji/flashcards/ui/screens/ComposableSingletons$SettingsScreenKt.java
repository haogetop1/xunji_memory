            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.SpacerKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: SettingsScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 22 */    public final class ComposableSingletons$SettingsScreenKt {
                public static final ComposableSingletons$SettingsScreenKt INSTANCE = new ComposableSingletons$SettingsScreenKt();

                /* JADX INFO: renamed from: lambda$-1037137569, reason: not valid java name */
                private static Function3<LazyItemScope, Composer, Integer, Unit> f63lambda$1037137569 = ComposableLambdaKt.composableLambdaInstance(-1037137569, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$SettingsScreenKt.lambda__1037137569$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1235225230, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f65lambda$1235225230 = ComposableLambdaKt.composableLambdaInstance(-1235225230, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$SettingsScreenKt.lambda__1235225230$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });
                private static Function2<Composer, Integer, Unit> lambda$164190816 = ComposableLambdaKt.composableLambdaInstance(164190816, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$SettingsScreenKt.lambda_164190816$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-492772856, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f67lambda$492772856 = ComposableLambdaKt.composableLambdaInstance(-492772856, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda3
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$SettingsScreenKt.lambda__492772856$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-920042585, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f69lambda$920042585 = ComposableLambdaKt.composableLambdaInstance(-920042585, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda4
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$SettingsScreenKt.lambda__920042585$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1105703420, reason: not valid java name */
                private static Function3<LazyItemScope, Composer, Integer, Unit> f64lambda$1105703420 = ComposableLambdaKt.composableLambdaInstance(-1105703420, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda5
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$SettingsScreenKt.lambda__1105703420$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-607905248, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f68lambda$607905248 = ComposableLambdaKt.composableLambdaInstance(-607905248, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda6
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$SettingsScreenKt.lambda__607905248$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1951197723, reason: not valid java name */
                private static Function2<Composer, Integer, Unit> f66lambda$1951197723 = ComposableLambdaKt.composableLambdaInstance(-1951197723, false, new Function2() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt$$ExternalSyntheticLambda7
                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(Object obj, Object obj2) {
                        return ComposableSingletons$SettingsScreenKt.lambda__1951197723$lambda$0((Composer) obj, ((Integer) obj2).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-1037137569$app_debug, reason: not valid java name */
                public final Function3<LazyItemScope, Composer, Integer, Unit> m9003getLambda$1037137569$app_debug() {
                    return f63lambda$1037137569;
                }

                /* JADX INFO: renamed from: getLambda$-1105703420$app_debug, reason: not valid java name */
                public final Function3<LazyItemScope, Composer, Integer, Unit> m9004getLambda$1105703420$app_debug() {
                    return f64lambda$1105703420;
                }

                /* JADX INFO: renamed from: getLambda$-1235225230$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m9005getLambda$1235225230$app_debug() {
                    return f65lambda$1235225230;
                }

                /* JADX INFO: renamed from: getLambda$-1951197723$app_debug, reason: not valid java name */
                public final Function2<Composer, Integer, Unit> m9006getLambda$1951197723$app_debug() {
                    return f66lambda$1951197723;
                }

                /* JADX INFO: renamed from: getLambda$-492772856$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m9007getLambda$492772856$app_debug() {
                    return f67lambda$492772856;
                }

                /* JADX INFO: renamed from: getLambda$-607905248$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m9008getLambda$607905248$app_debug() {
                    return f68lambda$607905248;
                }

                /* JADX INFO: renamed from: getLambda$-920042585$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m9009getLambda$920042585$app_debug() {
                    return f69lambda$920042585;
                }

                public final Function2<Composer, Integer, Unit> getLambda$164190816$app_debug() {
                    return lambda$164190816;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 23 */        public static final Unit lambda__1037137569$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C23@1232L38:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1037137569, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-1037137569.<anonymous> (SettingsScreen.kt:23)");
                        }
/* 24 */                XunjiComponentsKt.SectionTitle("按你的节奏", "让工具适合你，而不是催促你。", $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 28 */        public static final Unit lambda_164190816$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C28@1611L9:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(164190816, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$164190816.<anonymous> (SettingsScreen.kt:28)");
                        }
/* 29 */                TextKt.m3584TextNvy7gAk("张", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 28 */        public static final Unit lambda__1235225230$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C28@1587L14:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1235225230, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-1235225230.<anonymous> (SettingsScreen.kt:28)");
                        }
/* 29 */                TextKt.m3584TextNvy7gAk("每日新卡上限", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 38 */        public static final Unit lambda__492772856$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C38@3126L13:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-492772856, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-492772856.<anonymous> (SettingsScreen.kt:38)");
                        }
/* 39 */                TextKt.m3584TextNvy7gAk("从备份恢复", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 44 */        public static final Unit lambda__920042585$lambda$0(RowScope OutlinedButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(OutlinedButton, "$this$OutlinedButton");
                    ComposerKt.sourceInformation($composer, "C44@3515L18:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-920042585, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-920042585.<anonymous> (SettingsScreen.kt:44)");
                        }
/* 45 */                TextKt.m3584TextNvy7gAk("导入 Anki 牌组", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 46 */        public static final Unit lambda__1105703420$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C46@3551L19,46@3571L29,46@3601L40:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1105703420, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-1105703420.<anonymous> (SettingsScreen.kt:46)");
                        }
/* 47 */                XunjiComponentsKt.Eyebrow("循记 0.1.0", $composer, 6);
/* 47 */                SpacerKt.Spacer(SizeKt.m878height3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(8)), $composer, 6);
                        XunjiComponentsKt.Notice("独立、离线、本地保存。\n给知识一点时间，也给自己一点空间。", false, $composer, 6, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit lambda__1951197723$lambda$0(Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C49@3756L17:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1951197723, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-1951197723.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                TextKt.m3584TextNvy7gAk("替换当前全部数据？", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit lambda__607905248$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C49@4335L10:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-607905248, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$SettingsScreenKt.lambda$-607905248.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                TextKt.m3584TextNvy7gAk("取消", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: StatisticsScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 17 */    public final class ComposableSingletons$StatisticsScreenKt {
                public static final ComposableSingletons$StatisticsScreenKt INSTANCE = new ComposableSingletons$StatisticsScreenKt();
                private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$1383379216 = ComposableLambdaKt.composableLambdaInstance(1383379216, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$StatisticsScreenKt.lambda_1383379216$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$253803925 = ComposableLambdaKt.composableLambdaInstance(253803925, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$StatisticsScreenKt.lambda_253803925$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1104460487, reason: not valid java name */
                private static Function3<LazyItemScope, Composer, Integer, Unit> f70lambda$1104460487 = ComposableLambdaKt.composableLambdaInstance(-1104460487, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$StatisticsScreenKt.lambda__1104460487$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-1104460487$app_debug, reason: not valid java name */
                public final Function3<LazyItemScope, Composer, Integer, Unit> m9011getLambda$1104460487$app_debug() {
                    return f70lambda$1104460487;
                }

                public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$1383379216$app_debug() {
                    return lambda$1383379216;
                }

                public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$253803925$app_debug() {
                    return lambda$253803925;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 18 */        public static final Unit lambda_1383379216$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C18@770L36:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1383379216, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt.lambda$1383379216.<anonymous> (StatisticsScreen.kt:18)");
                        }
/* 19 */                XunjiComponentsKt.SectionTitle("留下的足迹", "每次认真回忆，都在积累。", $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final Unit lambda_253803925$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C19@883L43:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(253803925, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt.lambda$253803925.<anonymous> (StatisticsScreen.kt:19)");
                        }
/* 20 */                XunjiComponentsKt.EmptyState("还没有学习记录", "完成一次评分后，在这里看看你走过的路。", null, null, $composer, 54, 12);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final Unit lambda__1104460487$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C34@2930L54:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1104460487, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$StatisticsScreenKt.lambda$-1104460487.<anonymous> (StatisticsScreen.kt:34)");
                        }
/* 35 */                XunjiComponentsKt.Notice("忘记比例 =「忘记」评分 ÷ 有效评分总数。它帮助你了解复习感受；被撤销的评分不会计入。", false, $composer, 6, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.SpacerKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.time.LocalDate;
            import java.time.format.DateTimeFormatter;
            import java.util.Locale;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: TodayScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 19 */    public final class ComposableSingletons$TodayScreenKt {
                public static final ComposableSingletons$TodayScreenKt INSTANCE = new ComposableSingletons$TodayScreenKt();

                /* JADX INFO: renamed from: lambda$-2076728066, reason: not valid java name */
                private static Function3<LazyItemScope, Composer, Integer, Unit> f72lambda$2076728066 = ComposableLambdaKt.composableLambdaInstance(-2076728066, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt$$ExternalSyntheticLambda0
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$TodayScreenKt.lambda__2076728066$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: lambda$-1573877077, reason: not valid java name */
                private static Function3<RowScope, Composer, Integer, Unit> f71lambda$1573877077 = ComposableLambdaKt.composableLambdaInstance(-1573877077, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt$$ExternalSyntheticLambda1
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$TodayScreenKt.lambda__1573877077$lambda$0((RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });
                private static Function3<LazyItemScope, Composer, Integer, Unit> lambda$1071045318 = ComposableLambdaKt.composableLambdaInstance(1071045318, false, new Function3() { // from class: com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt$$ExternalSyntheticLambda2
                    @Override // kotlin.jvm.functions.Function3
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        return ComposableSingletons$TodayScreenKt.lambda_1071045318$lambda$0((LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                    }
                });

                /* JADX INFO: renamed from: getLambda$-1573877077$app_debug, reason: not valid java name */
                public final Function3<RowScope, Composer, Integer, Unit> m9012getLambda$1573877077$app_debug() {
                    return f71lambda$1573877077;
                }

                /* JADX INFO: renamed from: getLambda$-2076728066$app_debug, reason: not valid java name */
                public final Function3<LazyItemScope, Composer, Integer, Unit> m9013getLambda$2076728066$app_debug() {
                    return f72lambda$2076728066;
                }

                public final Function3<LazyItemScope, Composer, Integer, Unit> getLambda$1071045318$app_debug() {
                    return lambda$1071045318;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 20 */        public static final Unit lambda__2076728066$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C20@878L100,20@979L30,20@1010L42:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-2076728066, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt.lambda$-2076728066.<anonymous> (TodayScreen.kt:20)");
                        }
/* 21 */                String str = LocalDate.now().format(DateTimeFormatter.ofPattern("M月d日 · EEEE", Locale.CHINESE));
                        Intrinsics.checkNotNullExpressionValue(str, "format(...)");
                        XunjiComponentsKt.Eyebrow(str, $composer, 0);
/* 21 */                SpacerKt.Spacer(SizeKt.m878height3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(10)), $composer, 6);
                        XunjiComponentsKt.SectionTitle("每一点，都算数。", "按自己的节奏，让记忆慢慢生长。", $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 37 */        public static final Unit lambda__1573877077$lambda$0(RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C37@3215L12:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1573877077, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt.lambda$-1573877077.<anonymous> (TodayScreen.kt:37)");
                        }
/* 38 */                TextKt.m3584TextNvy7gAk("全部牌组", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 40 */        public static final Unit lambda_1071045318$lambda$0(LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C40@3656L31:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1071045318, $changed, -1, "com.xunji.flashcards.ui.screens.ComposableSingletons$TodayScreenKt.lambda$1071045318.<anonymous> (TodayScreen.kt:40)");
                        }
/* 41 */                XunjiComponentsKt.Notice("偶尔停一天也没关系。你的卡片会在这里等你。", false, $composer, 6, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

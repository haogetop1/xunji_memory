            package com.xunji.flashcards.ui.screens;

            import androidx.compose.runtime.MutableState;
            import androidx.core.view.MotionEventCompat;
            import com.xunji.flashcards.ui.MainViewModel;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: DeckDetailScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$6$1$1$1", f = "DeckDetailScreen.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_9}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 38 */    final class DeckDetailScreenKt$DeckDetailScreen$6$1$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ MutableState<Boolean> $busy$delegate;
                final /* synthetic */ MutableState<String> $deleting$delegate;
                final /* synthetic */ MutableState<String> $error$delegate;
                final /* synthetic */ MainViewModel $viewModel;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                DeckDetailScreenKt$DeckDetailScreen$6$1$1$1(MainViewModel mainViewModel, MutableState<String> mutableState, MutableState<String> mutableState2, MutableState<Boolean> mutableState3, Continuation<? super DeckDetailScreenKt$DeckDetailScreen$6$1$1$1> continuation) {
                    super(2, continuation);
                    this.$viewModel = mainViewModel;
                    this.$deleting$delegate = mutableState;
                    this.$error$delegate = mutableState2;
                    this.$busy$delegate = mutableState3;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new DeckDetailScreenKt$DeckDetailScreen$6$1$1$1(this.$viewModel, this.$deleting$delegate, this.$error$delegate, this.$busy$delegate, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((DeckDetailScreenKt$DeckDetailScreen$6$1$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 39 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    try {
                        try {
                            try {
                                switch (this.label) {
                                    case 0:
                                        ResultKt.throwOnFailure($result);
                                        MainViewModel mainViewModel = this.$viewModel;
/* 1 */                                 String strDeckDetailScreen$lambda$3 = DeckDetailScreenKt.DeckDetailScreen$lambda$3(this.$deleting$delegate);
                                        Intrinsics.checkNotNull(strDeckDetailScreen$lambda$3);
                                        this.label = 1;
                                        if (mainViewModel.deleteCard(strDeckDetailScreen$lambda$3, this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        break;
                                    case 1:
                                        ResultKt.throwOnFailure($result);
                                        break;
                                    default:
                                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                                }
/* 118 */                       setValue(null);
                            } catch (Exception e) {
/* 118 */                       setValue("删除未完成，请重试");
                            }
/* 1 */                     DeckDetailScreenKt.DeckDetailScreen$lambda$10(this.$busy$delegate, false);
                            return Unit.INSTANCE;
                        } catch (CancellationException e2) {
                            throw e2;
                        }
                    } catch (Throwable th) {
/* 1 */                 DeckDetailScreenKt.DeckDetailScreen$lambda$10(this.$busy$delegate, false);
                        throw th;
                    }
                }
            }

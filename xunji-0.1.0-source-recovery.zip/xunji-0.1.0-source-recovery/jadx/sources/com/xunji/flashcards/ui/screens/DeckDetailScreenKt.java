            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.ClickableKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.material3.AndroidAlertDialog_androidKt;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.EffectsKt;
            import androidx.compose.runtime.MutableState;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.runtime.saveable.RememberSaveableKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.text.style.TextOverflow;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.DeckSummary;
            import com.xunji.core.model.Phase;
            import com.xunji.flashcards.ui.MainUiState;
            import com.xunji.flashcards.ui.MainViewModel;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.util.ArrayList;
            import java.util.Collection;
            import java.util.Iterator;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Unit;
            import kotlin.coroutines.EmptyCoroutineContext;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: DeckDetailScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000,\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\u001aI\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0014\u0010\b\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00010\u000bH\u0007¢\u0006\u0002\u0010\f¨\u0006\r²\u0006\f\u0010\u000e\u001a\u0004\u0018\u00010\u0003X\u008a\u008e\u0002²\u0006\f\u0010\u000f\u001a\u0004\u0018\u00010\u0003X\u008a\u008e\u0002²\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u008e\u0002"}, d2 = {"DeckDetailScreen", "", "deckId", "", "state", "Lcom/xunji/flashcards/ui/MainUiState;", "viewModel", "Lcom/xunji/flashcards/ui/MainViewModel;", "onEdit", "Lkotlin/Function1;", "onReview", "Lkotlin/Function0;", "(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_debug", "deleting", "error", "busy", ""}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 15 */    public final class DeckDetailScreenKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit DeckDetailScreen$lambda$11(String str, MainUiState mainUiState, MainViewModel mainViewModel, Function1 function1, Function0 function0, int i, Composer composer, int i2) {
                    DeckDetailScreen(str, mainUiState, mainViewModel, function1, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit DeckDetailScreen$lambda$13(String str, MainUiState mainUiState, MainViewModel mainViewModel, Function1 function1, Function0 function0, int i, Composer composer, int i2) {
                    DeckDetailScreen(str, mainUiState, mainViewModel, function1, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit DeckDetailScreen$lambda$19(String str, MainUiState mainUiState, MainViewModel mainViewModel, Function1 function1, Function0 function0, int i, Composer composer, int i2) {
                    DeckDetailScreen(str, mainUiState, mainViewModel, function1, function0, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 16 */        public static final void DeckDetailScreen(final String deckId, final MainUiState state, final MainViewModel viewModel, final Function1<? super String, Unit> onEdit, final Function0<Unit> onReview, Composer $composer, final int $changed) {
                    Object next;
                    MutableState error$delegate;
                    Object obj;
                    final MutableState deleting$delegate;
                    Function0<ComposeUiNode> function0;
                    Intrinsics.checkNotNullParameter(deckId, "deckId");
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(viewModel, "viewModel");
                    Intrinsics.checkNotNullParameter(onEdit, "onEdit");
                    Intrinsics.checkNotNullParameter(onReview, "onReview");
/* 17 */            Composer $composer2 = $composer.startRestartGroup(-397629270);
                    ComposerKt.sourceInformation($composer2, "C(DeckDetailScreen)N(deckId,state,viewModel,onEdit,onReview)18@831L33,18@814L50,18@878L42,18@933L34,18@978L24,21@1273L1285,21@1136L1422:DeckDetailScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(deckId) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(state) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer2.changedInstance(viewModel) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        $dirty |= $composer2.changedInstance(onEdit) ? 2048 : 1024;
                    }
                    if (($changed & 24576) == 0) {
                        $dirty |= $composer2.changedInstance(onReview) ? 16384 : 8192;
                    }
                    int $dirty2 = $dirty;
                    if ($composer2.shouldExecute(($dirty2 & 9363) != 9362, $dirty2 & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 17 */                    ComposerKt.traceEventStart(-397629270, $dirty2, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen (DeckDetailScreen.kt:16)");
                        }
/* 43 */                Iterator it = state.getDecks().iterator();
/* 43 */                do {
                            if (!it.hasNext()) {
/* 44 */                        next = null;
                                break;
                            }
                            next = it.next();
/* 43 */                } while (!Intrinsics.areEqual(((DeckSummary) next).getDeck().getId(), deckId));
/* 18 */                final DeckSummary deck = (DeckSummary) next;
                        Iterable cards = state.getCards();
/* 45 */                Collection arrayList = new ArrayList();
                        for (Object obj2 : cards) {
/* 46 */                    if (Intrinsics.areEqual(((CardCandidate) obj2).getCard().getDeckId(), deckId)) {
                                arrayList.add(obj2);
                            }
                        }
                        final List cards2 = (List) arrayList;
                        Object[] objArr = new Object[0];
/* 19 */                ComposerKt.sourceInformationMarkerStart($composer2, 130369483, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        Object objRememberedValue = $composer2.rememberedValue();
/* 49 */                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda16
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$2$0();
                                }
                            };
/* 51 */                    $composer2.updateRememberedValue(obj3);
/* 52 */                    objRememberedValue = obj3;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 19 */                final MutableState deleting$delegate2 = (MutableState) RememberSaveableKt.rememberSaveable(objArr, (Function0) objRememberedValue, $composer2, 48);
                        ComposerKt.sourceInformationMarkerStart($composer2, 130370996, "CC(remember):DeckDetailScreen.kt#9igjgp");
/* 48 */                Object objRememberedValue2 = $composer2.rememberedValue();
/* 49 */                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 1 */                     MutableState mutableStateMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
/* 51 */                    $composer2.updateRememberedValue(mutableStateMutableStateOf$default);
/* 52 */                    objRememberedValue2 = mutableStateMutableStateOf$default;
                        }
/* 19 */                final MutableState error$delegate2 = (MutableState) objRememberedValue2;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                        ComposerKt.sourceInformationMarkerStart($composer2, 130372748, "CC(remember):DeckDetailScreen.kt#9igjgp");
/* 48 */                Object objRememberedValue3 = $composer2.rememberedValue();
/* 49 */                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
/* 1 */                     Object objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
/* 51 */                    $composer2.updateRememberedValue(objMutableStateOf$default);
/* 52 */                    objRememberedValue3 = objMutableStateOf$default;
                        }
/* 19 */                final MutableState busy$delegate = (MutableState) objRememberedValue3;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 54 */                ComposerKt.sourceInformationMarkerStart($composer2, 773894976, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp");
/* 60 */                ComposerKt.sourceInformationMarkerStart($composer2, 683737348, "CC(remember):Effects.kt#9igjgp");
                        Object objRememberedValue4 = $composer2.rememberedValue();
/* 49 */                if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
/* 59 */                    objRememberedValue4 = EffectsKt.createCompositionCoroutineScope(EmptyCoroutineContext.INSTANCE, $composer2);
/* 51 */                    $composer2.updateRememberedValue(objRememberedValue4);
                        }
/* 60 */                final CoroutineScope scope = (CoroutineScope) objRememberedValue4;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 54 */                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 20 */                if (state.getLoading()) {
                            $composer2.startReplaceGroup(-253325399);
                            ComposerKt.sourceInformation($composer2, "19@1022L6");
/* 48 */                    XunjiComponentsKt.Busy($composer2, 0);
                            $composer2.endReplaceGroup();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 41 */                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                            if (scopeUpdateScopeEndRestartGroup != null) {
                                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda17
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj4, Object obj5) {
                                        return DeckDetailScreenKt.DeckDetailScreen$lambda$11(deckId, state, viewModel, onEdit, onReview, $changed, (Composer) obj4, ((Integer) obj5).intValue());
                                    }
                                });
/* 20 */                        return;
                            }
/* 20 */                    return;
                        }
                        $composer2.startReplaceGroup(-254339688);
                        $composer2.endReplaceGroup();
/* 21 */                if (deck == null) {
                            $composer2.startReplaceGroup(-253292570);
                            ComposerKt.sourceInformation($composer2, "20@1054L71");
/* 21 */                    Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(22));
/* 63 */                    ComposerKt.sourceInformationMarkerStart($composer2, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 68 */                    MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
                            ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 74 */                    int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 75 */                    CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
                            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifierM840padding3ABfNKs);
/* 78 */                    Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 72 */                    int i = ((((6 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 80 */                    if (!($composer2.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 81 */                    $composer2.startReusableNode();
/* 82 */                    if ($composer2.getInserting()) {
/* 83 */                        function0 = constructor;
                                $composer2.createNode(function0);
                            } else {
/* 85 */                        function0 = constructor;
                                $composer2.useNode();
                            }
/* 87 */                    Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer2);
/* 88 */                    Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 89 */                    Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 90 */                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 92 */                    if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 91 */                        composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 94 */                        composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                            }
/* 97 */                    Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 99 */                    int i2 = (i >> 6) & 14;
/* 70 */                    ComposerKt.sourceInformationMarkerStart($composer2, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                            BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                            int i3 = ((6 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer2, -459279973, "C20@1085L38:DeckDetailScreen.kt#i35lj1");
                            XunjiComponentsKt.EmptyState("牌组已不存在", "请返回牌组列表，选择其它内容。", null, null, $composer2, 54, 12);
                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 70 */                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 100 */                   $composer2.endNode();
/* 79 */                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 73 */                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 63 */                    ComposerKt.sourceInformationMarkerEnd($composer2);
                            $composer2.endReplaceGroup();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 41 */                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup2 = $composer2.endRestartGroup();
                            if (scopeUpdateScopeEndRestartGroup2 != null) {
                                scopeUpdateScopeEndRestartGroup2.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda1
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj4, Object obj5) {
                                        return DeckDetailScreenKt.DeckDetailScreen$lambda$13(deckId, state, viewModel, onEdit, onReview, $changed, (Composer) obj4, ((Integer) obj5).intValue());
                                    }
                                });
/* 21 */                        return;
                            }
/* 21 */                    return;
                        }
                        $composer2.startReplaceGroup(-254339688);
                        $composer2.endReplaceGroup();
/* 22 */                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 22 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 22 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(16));
                        ComposerKt.sourceInformationMarkerStart($composer2, 130384879, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        boolean zChangedInstance = (($dirty2 & 7168) == 2048) | $composer2.changedInstance(deck) | $composer2.changedInstance(cards2) | ((57344 & $dirty2) == 16384) | $composer2.changed(deleting$delegate2);
/* 105 */               Object objRememberedValue5 = $composer2.rememberedValue();
/* 106 */               if (zChangedInstance || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
                            error$delegate = error$delegate2;
                            obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda2
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj4) {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0(cards2, deck, onReview, onEdit, deleting$delegate2, error$delegate2, (LazyListScope) obj4);
                                }
                            };
                            deleting$delegate = deleting$delegate2;
/* 108 */                   $composer2.updateRememberedValue(obj);
                        } else {
                            error$delegate = error$delegate2;
                            obj = objRememberedValue5;
                            deleting$delegate = deleting$delegate2;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 22 */                LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) obj, $composer2, 24966, 490);
/* 40 */                if (DeckDetailScreen$lambda$3(deleting$delegate) != null) {
                            $composer2.startReplaceGroup(130425887);
                            ComposerKt.sourceInformation($composer2, "39@2607L24,39@2755L280,39@3050L60,39@2661L79,39@2578L533");
                            ComposerKt.sourceInformationMarkerStart($composer2, 130426306, "CC(remember):DeckDetailScreen.kt#9igjgp");
                            boolean zChanged = $composer2.changed(deleting$delegate);
/* 111 */                   Object objRememberedValue6 = $composer2.rememberedValue();
/* 112 */                   if (zChanged || objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
/* 40 */                        Object obj4 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda3
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DeckDetailScreenKt.DeckDetailScreen$lambda$15$0(busy$delegate, deleting$delegate);
                                    }
                                };
/* 114 */                       $composer2.updateRememberedValue(obj4);
/* 115 */                       objRememberedValue6 = obj4;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            final MutableState deleting$delegate3 = deleting$delegate;
                            final MutableState error$delegate3 = error$delegate;
/* 19 */                    AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0((Function0) objRememberedValue6, ComposableLambdaKt.rememberComposableLambda(634615349, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda4
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$16(scope, viewModel, deleting$delegate3, busy$delegate, error$delegate3, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, ComposableLambdaKt.rememberComposableLambda(-868482957, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda5
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$17(deleting$delegate3, busy$delegate, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, ComposableSingletons$DeckDetailScreenKt.INSTANCE.getLambda$1923386033$app_debug(), ComposableLambdaKt.rememberComposableLambda(1171836880, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda6
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$18(error$delegate3, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, 0L, 0L, 0L, 0L, 0.0f, null, $composer2, 1772592, 0, 16276);
                            $composer2 = $composer2;
                        } else {
                            $composer2.startReplaceGroup(-254339688);
                        }
                        $composer2.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2.skipToGroupEnd();
                    }
/* 41 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup3 = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup3 != null) {
                        scopeUpdateScopeEndRestartGroup3.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda7
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj5, Object obj6) {
                                return DeckDetailScreenKt.DeckDetailScreen$lambda$19(deckId, state, viewModel, onEdit, onReview, $changed, (Composer) obj5, ((Integer) obj6).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 18 */        public static final void DeckDetailScreen$lambda$10(MutableState<Boolean> mutableState, boolean z) {
/* 118 */           mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 18 */        public static final MutableState DeckDetailScreen$lambda$2$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 18 */        public static final String DeckDetailScreen$lambda$3(MutableState<String> mutableState) {
/* 117 */           return mutableState.getValue();
                }

/* 18 */        private static final String DeckDetailScreen$lambda$6(MutableState<String> mutableState) {
/* 117 */           return mutableState.getValue();
                }

/* 18 */        private static final boolean DeckDetailScreen$lambda$9(MutableState<Boolean> mutableState) {
/* 117 */           return mutableState.getValue().booleanValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 22 */        public static final Unit DeckDetailScreen$lambda$14$0(final List $cards, final DeckSummary $deck, final Function0 $onReview, final Function1 $onEdit, final MutableState $deleting$delegate, final MutableState $error$delegate, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 23 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-495961921, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda0
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$0($deck, $cards, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 24 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1298507446, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda9
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$1($onReview, $cards, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 25 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-706983433, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda10
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$2($onEdit, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 26 */            if ($cards.isEmpty()) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-313113126, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$3($onEdit, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 27 */            final Function1 function1 = new Function1() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda12
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$4((CardCandidate) obj);
                        }
                    };
/* 123 */           final Function1 function2 = new Function1() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1
                        @Override // kotlin.jvm.functions.Function1
/* 170 */               public /* bridge */ /* synthetic */ Object invoke(Object p1) {
/* 171 */                   return invoke((CardCandidate) p1);
                        }

                        @Override // kotlin.jvm.functions.Function1
/* 170 */               public final Void invoke(CardCandidate cardCandidate) {
/* 171 */                   return null;
                        }
                    };
/* 126 */           LazyColumn.items($cards.size(), new Function1<Integer, Object>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$2
                        @Override // kotlin.jvm.functions.Function1
/* 173 */               public /* bridge */ /* synthetic */ Object invoke(Integer num) {
/* 174 */                   return invoke(num.intValue());
                        }

/* 175 */               public final Object invoke(int index) {
/* 176 */                   return invoke($cards.get(index));
                        }
                    }, new Function1<Integer, Object>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$3
                        @Override // kotlin.jvm.functions.Function1
/* 173 */               public /* bridge */ /* synthetic */ Object invoke(Integer num) {
/* 174 */                   return invoke(num.intValue());
                        }

/* 176 */               public final Object invoke(int index) {
/* 177 */                   return invoke($cards.get(index));
                        }
                    }, ComposableLambdaKt.composableLambdaInstance(802480018, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$4
                        @Override // kotlin.jvm.functions.Function4
/* 177 */               public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
/* 178 */                   invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                            return Unit.INSTANCE;
                        }

/* 178 */               public final void invoke(LazyItemScope $this$items, int it, Composer $composer, int $changed) {
                            ComposerKt.sourceInformation($composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                            int $dirty = $changed;
                            if (($changed & 6) == 0) {
                                $dirty |= $composer.changed($this$items) ? 4 : 2;
                            }
                            if (($changed & 48) == 0) {
                                $dirty |= $composer.changed(it) ? 32 : 16;
                            }
                            if (!$composer.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
/* 178 */                       $composer.skipToGroupEnd();
/* 180 */                       return;
                            }
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(802480018, $dirty, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                            }
                            int i = $dirty & 14;
/* 179 */                   final CardCandidate cardCandidate = (CardCandidate) $cards.get(it);
/* 181 */                   $composer.startReplaceGroup(-2123575058);
                            ComposerKt.sourceInformation($composer, "CN(candidate)*27@1878L29,27@1909L642,27@1838L713:DeckDetailScreen.kt#i35lj1");
                            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                            ComposerKt.sourceInformationMarkerStart($composer, -1869617143, "CC(remember):DeckDetailScreen.kt#9igjgp");
                            boolean zChanged = $composer.changed($onEdit) | $composer.changedInstance(cardCandidate);
/* 182 */                   Object objRememberedValue = $composer.rememberedValue();
/* 183 */                   if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                final Function1 function3 = $onEdit;
/* 181 */                       Object obj = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1
                                    @Override // kotlin.jvm.functions.Function0
/* 27 */                            public /* bridge */ /* synthetic */ Unit invoke() {
/* 28 */                                invoke2();
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 27 */                            public final void invoke2() {
/* 28 */                                invoke(cardCandidate.getCard().getId());
                                    }
                                };
/* 185 */                       $composer.updateRememberedValue(obj);
/* 186 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 181 */                   Modifier modifierM306clickableoSLSa3U$default = ClickableKt.m306clickableoSLSa3U$default(modifierFillMaxWidth$default, false, null, null, null, (Function0) objRememberedValue, 15, null);
                            final MutableState mutableState = $deleting$delegate;
                            final MutableState mutableState2 = $error$delegate;
                            XunjiComponentsKt.Paper(modifierM306clickableoSLSa3U$default, ComposableLambdaKt.rememberComposableLambda(1333309148, true, new Function3<ColumnScope, Composer, Integer, Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2

                                /* JADX INFO: compiled from: DeckDetailScreen.kt */
                                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                                public static final /* synthetic */ class WhenMappings {
                                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                                    static {
                                        int[] iArr = new int[Phase.values().length];
                                        try {
                                            iArr[Phase.NEW.ordinal()] = 1;
                                        } catch (NoSuchFieldError e) {
                                        }
                                        try {
                                            iArr[Phase.LEARNING.ordinal()] = 2;
                                        } catch (NoSuchFieldError e2) {
                                        }
                                        try {
                                            iArr[Phase.RELEARNING.ordinal()] = 3;
                                        } catch (NoSuchFieldError e3) {
                                        }
                                        try {
                                            iArr[Phase.REVIEW.ordinal()] = 4;
                                        } catch (NoSuchFieldError e4) {
                                        }
                                        $EnumSwitchMapping$0 = iArr;
                                    }
                                }

                                @Override // kotlin.jvm.functions.Function3
/* 27 */                        public /* bridge */ /* synthetic */ Unit invoke(ColumnScope columnScope, Composer composer, Integer num) {
/* 28 */                            invoke(columnScope, composer, num.intValue());
                                    return Unit.INSTANCE;
                                }

                                /* JADX WARN: Code duplicated, block: B:28:0x01f3  */
                                /* JADX WARN: Code duplicated, block: B:31:0x01ff  */
                                /* JADX WARN: Code duplicated, block: B:32:0x0205  */
                                /* JADX WARN: Code duplicated, block: B:35:0x0236  */
                                /* JADX WARN: Code duplicated, block: B:38:0x0249  */
                                /* JADX WARN: Code duplicated, block: B:39:0x024c  */
                                /* JADX WARN: Code duplicated, block: B:43:0x02f2  */
                                /* JADX WARN: Code duplicated, block: B:45:0x02f8  */
                                /* JADX WARN: Code duplicated, block: B:46:0x02fb  */
                                /* JADX WARN: Code duplicated, block: B:47:0x02fe  */
                                /* JADX WARN: Code duplicated, block: B:50:0x030e  */
                                /* JADX WARN: Code duplicated, block: B:51:0x0313  */
                                /* JADX WARN: Code duplicated, block: B:54:0x037b  */
                                /* JADX WARN: Code duplicated, block: B:58:0x0387  */
                                /* JADX WARN: Code duplicated, block: B:61:0x03ce  */
                                /* JADX WARN: Code duplicated, block: B:64:? A[RETURN, SYNTHETIC] */
/* 28 */                        public final void invoke(ColumnScope Paper, Composer $composer2, int $changed2) {
                                    Function0<ComposeUiNode> function0;
                                    int i2;
                                    int iHashCode;
                                    Function0<ComposeUiNode> constructor;
                                    Function0<ComposeUiNode> function4;
                                    Composer composerM4979constructorimpl;
                                    Composer composer;
                                    String str;
                                    String str2;
                                    boolean zChanged2;
                                    Object objRememberedValue2;
                                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                                    ComposerKt.sourceInformation($composer2, "C28@1915L631:DeckDetailScreen.kt#i35lj1");
                                    if (!$composer2.shouldExecute(($changed2 & 17) != 16, $changed2 & 1)) {
/* 28 */                                $composer2.skipToGroupEnd();
/* 37 */                                return;
                                    }
                                    if (ComposerKt.isTraceInProgress()) {
                                        ComposerKt.traceEventStart(1333309148, $changed2, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:28)");
                                    }
/* 29 */                            Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 29 */                            Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(12));
                                    final MutableState<String> mutableState3 = mutableState;
                                    final CardCandidate cardCandidate2 = cardCandidate;
                                    final MutableState<String> mutableState4 = mutableState2;
/* 44 */                            ComposerKt.sourceInformationMarkerStart($composer2, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 45 */                            Modifier modifier = Modifier.INSTANCE;
/* 50 */                            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, centerVertically, $composer2, ((432 >> 3) & 14) | ((432 >> 3) & 112));
/* 55 */                            ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 56 */                            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 57 */                            CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
/* 58 */                            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifier);
/* 60 */                            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 54 */                            int i3 = ((((432 << 3) & 112) << 6) & 896) | 6;
                                    ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 62 */                            if (!($composer2.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 63 */                            $composer2.startReusableNode();
/* 64 */                            if ($composer2.getInserting()) {
/* 65 */                                function0 = constructor2;
                                        $composer2.createNode(function0);
                                    } else {
/* 67 */                                function0 = constructor2;
                                        $composer2.useNode();
                                    }
                                    Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer2);
/* 70 */                            Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 71 */                            Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 72 */                            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 74 */                            if (!composerM4979constructorimpl2.getInserting()) {
                                        i2 = iHashCode2;
/* 73 */                                if (!Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(i2))) {
                                        }
/* 79 */                                Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 81 */                                int i4 = (i3 >> 6) & 14;
/* 52 */                                ComposerKt.sourceInformationMarkerStart($composer2, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                        int i5 = ((432 >> 6) & 112) | 6;
                                        RowScope rowScope = RowScopeInstance.INSTANCE;
                                        ComposerKt.sourceInformationMarkerStart($composer2, -765840411, "C29@2022L445,34@2500L39,34@2473L67:DeckDetailScreen.kt#i35lj1");
                                        Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
/* 30 */                                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
                                        ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 83 */                                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                                        ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 93 */                                iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 94 */                                CompositionLocalMap currentCompositionLocalMap2 = $composer2.getCurrentCompositionLocalMap();
/* 88 */                                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer2, modifierWeight$default);
/* 97 */                                constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 91 */                                int i6 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                        ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 99 */                                if (!($composer2.getApplier() instanceof Applier)) {
                                            ComposablesKt.invalidApplier();
                                        }
/* 100 */                               $composer2.startReusableNode();
/* 101 */                               if ($composer2.getInserting()) {
/* 102 */                                   function4 = constructor;
                                            $composer2.createNode(function4);
                                        } else {
/* 104 */                                   function4 = constructor;
                                            $composer2.useNode();
                                        }
/* 106 */                               composerM4979constructorimpl = Updater.m4979constructorimpl($composer2);
/* 107 */                               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 108 */                               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 109 */                               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 111 */                               if (!composerM4979constructorimpl.getInserting()) {
                                            composer = $composer2;
/* 95 */                                    if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                            }
/* 116 */                                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 118 */                                   int i7 = (i6 >> 6) & 14;
                                            Composer composer2 = composer;
/* 89 */                                    ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
/* 83 */                                    int i8 = ((48 >> 6) & 112) | 6;
                                            ComposerKt.sourceInformationMarkerStart(composer2, -2097824770, "C30@2151L10,30@2105L111,32@2349L111:DeckDetailScreen.kt#i35lj1");
                                            TextKt.m3584TextNvy7gAk(cardCandidate2.getCard().getFront(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.Companion.m8312getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, 0, 24960, 110590);
                                            switch (WhenMappings.$EnumSwitchMapping$0[cardCandidate2.getSchedule().getPhase().ordinal()]) {
                                                case 1:
                                                    str = "新卡";
                                                    break;
                                                case 2:
                                                case 3:
                                                    str = "学习中";
                                                    break;
                                                case 4:
                                                    str = "已学习";
                                                    break;
                                                default:
                                                    throw new NoWhenBranchMatchedException();
                                            }
/* 33 */                                    if (cardCandidate2.getSchedule().getPhase() == Phase.NEW) {
                                                str2 = " · 尚未开始";
                                            } else {
                                                str2 = " · " + XunjiComponentsKt.localTime(cardCandidate2.getSchedule().getDueAt());
                                            }
                                            XunjiComponentsKt.Notice(str + str2, false, composer2, 0, 2);
/* 31 */                                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 89 */                                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 119 */                                   composer.endNode();
/* 98 */                                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 92 */                                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 83 */                                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 35 */                                    ComposerKt.sourceInformationMarkerStart($composer2, -578879041, "CC(remember):DeckDetailScreen.kt#9igjgp");
                                            zChanged2 = $composer2.changed(mutableState3) | $composer2.changedInstance(cardCandidate2);
/* 123 */                                   objRememberedValue2 = $composer2.rememberedValue();
/* 124 */                                   if (!zChanged2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                                Object obj2 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                                    @Override // kotlin.jvm.functions.Function0
/* 34 */                                            public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                                invoke2();
                                                        return Unit.INSTANCE;
                                                    }

                                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                            public final void invoke2() {
/* 118 */                                               setValue(cardCandidate2.getCard().getId());
/* 118 */                                               setValue(null);
                                                    }
                                                };
/* 126 */                                       $composer2.updateRememberedValue(obj2);
/* 127 */                                       objRememberedValue2 = obj2;
                                            }
                                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 35 */                                    XunjiComponentsKt.IconAction("delete", "删除卡片", (Function0) objRememberedValue2, null, false, $composer2, 54, 24);
/* 30 */                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 52 */                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 129 */                                   $composer2.endNode();
/* 61 */                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 55 */                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 44 */                                    ComposerKt.sourceInformationMarkerEnd($composer2);
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventEnd();
                                            }
                                        }
                                        composer = $composer2;
/* 110 */                               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 113 */                               composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash2);
/* 116 */                               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 118 */                               int i9 = (i6 >> 6) & 14;
                                        Composer composer3 = composer;
/* 89 */                                ComposerKt.sourceInformationMarkerStart(composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
/* 83 */                                int i10 = ((48 >> 6) & 112) | 6;
                                        ComposerKt.sourceInformationMarkerStart(composer3, -2097824770, "C30@2151L10,30@2105L111,32@2349L111:DeckDetailScreen.kt#i35lj1");
                                        TextKt.m3584TextNvy7gAk(cardCandidate2.getCard().getFront(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.Companion.m8312getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getTitleMedium(), composer3, 0, 24960, 110590);
                                        switch (WhenMappings.$EnumSwitchMapping$0[cardCandidate2.getSchedule().getPhase().ordinal()]) {
                                            case 1:
                                                str = "新卡";
                                                break;
                                            case 2:
                                            case 3:
                                                str = "学习中";
                                                break;
                                            case 4:
                                                str = "已学习";
                                                break;
                                            default:
                                                throw new NoWhenBranchMatchedException();
                                        }
/* 33 */                                if (cardCandidate2.getSchedule().getPhase() == Phase.NEW) {
                                            str2 = " · 尚未开始";
                                        } else {
                                            str2 = " · " + XunjiComponentsKt.localTime(cardCandidate2.getSchedule().getDueAt());
                                        }
                                        XunjiComponentsKt.Notice(str + str2, false, composer3, 0, 2);
/* 31 */                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 89 */                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 119 */                               composer.endNode();
/* 98 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 92 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 83 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 35 */                                ComposerKt.sourceInformationMarkerStart($composer2, -578879041, "CC(remember):DeckDetailScreen.kt#9igjgp");
                                        zChanged2 = $composer2.changed(mutableState3) | $composer2.changedInstance(cardCandidate2);
/* 123 */                               objRememberedValue2 = $composer2.rememberedValue();
/* 124 */                               if (!zChanged2) {
                                            Object obj3 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                                @Override // kotlin.jvm.functions.Function0
/* 34 */                                        public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                            invoke2();
                                                    return Unit.INSTANCE;
                                                }

                                                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                        public final void invoke2() {
/* 118 */                                           setValue(cardCandidate2.getCard().getId());
/* 118 */                                           setValue(null);
                                                }
                                            };
/* 126 */                                   $composer2.updateRememberedValue(obj3);
/* 127 */                                   objRememberedValue2 = obj3;
                                        } else {
                                            Object obj4 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                                @Override // kotlin.jvm.functions.Function0
/* 34 */                                        public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                            invoke2();
                                                    return Unit.INSTANCE;
                                                }

                                                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                        public final void invoke2() {
/* 118 */                                           setValue(cardCandidate2.getCard().getId());
/* 118 */                                           setValue(null);
                                                }
                                            };
/* 126 */                                   $composer2.updateRememberedValue(obj4);
/* 127 */                                   objRememberedValue2 = obj4;
                                        }
                                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 35 */                                XunjiComponentsKt.IconAction("delete", "删除卡片", (Function0) objRememberedValue2, null, false, $composer2, 54, 24);
/* 30 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 52 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 129 */                               $composer2.endNode();
/* 61 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 55 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 44 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventEnd();
                                        }
                                    }
                                    i2 = iHashCode2;
/* 73 */                            composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(i2));
/* 76 */                            composerM4979constructorimpl2.apply(Integer.valueOf(i2), setCompositeKeyHash);
/* 79 */                            Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 81 */                            int i11 = (i3 >> 6) & 14;
/* 52 */                            ComposerKt.sourceInformationMarkerStart($composer2, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                    int i12 = ((432 >> 6) & 112) | 6;
                                    RowScope rowScope2 = RowScopeInstance.INSTANCE;
                                    ComposerKt.sourceInformationMarkerStart($composer2, -765840411, "C29@2022L445,34@2500L39,34@2473L67:DeckDetailScreen.kt#i35lj1");
                                    Modifier modifierWeight$default2 = RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null);
/* 30 */                            Arrangement.Vertical verticalM699spacedBy0680j_5 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
                                    ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 83 */                            MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_5, Alignment.INSTANCE.getStart(), $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                                    ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 93 */                            iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 94 */                            CompositionLocalMap currentCompositionLocalMap3 = $composer2.getCurrentCompositionLocalMap();
/* 88 */                            Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer2, modifierWeight$default2);
/* 97 */                            constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 91 */                            int i13 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                    ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 99 */                            if (!($composer2.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 100 */                           $composer2.startReusableNode();
/* 101 */                           if ($composer2.getInserting()) {
/* 102 */                               function4 = constructor;
                                        $composer2.createNode(function4);
                                    } else {
/* 104 */                               function4 = constructor;
                                        $composer2.useNode();
                                    }
/* 106 */                           composerM4979constructorimpl = Updater.m4979constructorimpl($composer2);
/* 107 */                           Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 108 */                           Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 109 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 111 */                           if (!composerM4979constructorimpl.getInserting()) {
                                        composer = $composer2;
/* 95 */                                if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                        }
/* 116 */                               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 118 */                               int i14 = (i13 >> 6) & 14;
                                        Composer composer4 = composer;
/* 89 */                                ComposerKt.sourceInformationMarkerStart(composer4, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                        ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
/* 83 */                                int i15 = ((48 >> 6) & 112) | 6;
                                        ComposerKt.sourceInformationMarkerStart(composer4, -2097824770, "C30@2151L10,30@2105L111,32@2349L111:DeckDetailScreen.kt#i35lj1");
                                        TextKt.m3584TextNvy7gAk(cardCandidate2.getCard().getFront(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.Companion.m8312getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer4, MaterialTheme.$stable).getTitleMedium(), composer4, 0, 24960, 110590);
                                        switch (WhenMappings.$EnumSwitchMapping$0[cardCandidate2.getSchedule().getPhase().ordinal()]) {
                                            case 1:
                                                str = "新卡";
                                                break;
                                            case 2:
                                            case 3:
                                                str = "学习中";
                                                break;
                                            case 4:
                                                str = "已学习";
                                                break;
                                            default:
                                                throw new NoWhenBranchMatchedException();
                                        }
/* 33 */                                if (cardCandidate2.getSchedule().getPhase() == Phase.NEW) {
                                            str2 = " · 尚未开始";
                                        } else {
                                            str2 = " · " + XunjiComponentsKt.localTime(cardCandidate2.getSchedule().getDueAt());
                                        }
                                        XunjiComponentsKt.Notice(str + str2, false, composer4, 0, 2);
/* 31 */                                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 89 */                                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 119 */                               composer.endNode();
/* 98 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 92 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 83 */                                ComposerKt.sourceInformationMarkerEnd(composer);
/* 35 */                                ComposerKt.sourceInformationMarkerStart($composer2, -578879041, "CC(remember):DeckDetailScreen.kt#9igjgp");
                                        zChanged2 = $composer2.changed(mutableState3) | $composer2.changedInstance(cardCandidate2);
/* 123 */                               objRememberedValue2 = $composer2.rememberedValue();
/* 124 */                               if (!zChanged2) {
                                            Object obj5 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                                @Override // kotlin.jvm.functions.Function0
/* 34 */                                        public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                            invoke2();
                                                    return Unit.INSTANCE;
                                                }

                                                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                        public final void invoke2() {
/* 118 */                                           setValue(cardCandidate2.getCard().getId());
/* 118 */                                           setValue(null);
                                                }
                                            };
/* 126 */                                   $composer2.updateRememberedValue(obj5);
/* 127 */                                   objRememberedValue2 = obj5;
                                        } else {
                                            Object obj6 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                                @Override // kotlin.jvm.functions.Function0
/* 34 */                                        public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                            invoke2();
                                                    return Unit.INSTANCE;
                                                }

                                                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                        public final void invoke2() {
/* 118 */                                           setValue(cardCandidate2.getCard().getId());
/* 118 */                                           setValue(null);
                                                }
                                            };
/* 126 */                                   $composer2.updateRememberedValue(obj6);
/* 127 */                                   objRememberedValue2 = obj6;
                                        }
                                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 35 */                                XunjiComponentsKt.IconAction("delete", "删除卡片", (Function0) objRememberedValue2, null, false, $composer2, 54, 24);
/* 30 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 52 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 129 */                               $composer2.endNode();
/* 61 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 55 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 44 */                                ComposerKt.sourceInformationMarkerEnd($composer2);
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventEnd();
                                        }
                                    }
                                    composer = $composer2;
/* 110 */                           composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 113 */                           composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash3);
/* 116 */                           Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 118 */                           int i16 = (i13 >> 6) & 14;
                                    Composer composer5 = composer;
/* 89 */                            ComposerKt.sourceInformationMarkerStart(composer5, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                    ColumnScopeInstance columnScopeInstance4 = ColumnScopeInstance.INSTANCE;
/* 83 */                            int i17 = ((48 >> 6) & 112) | 6;
                                    ComposerKt.sourceInformationMarkerStart(composer5, -2097824770, "C30@2151L10,30@2105L111,32@2349L111:DeckDetailScreen.kt#i35lj1");
                                    TextKt.m3584TextNvy7gAk(cardCandidate2.getCard().getFront(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, TextOverflow.Companion.m8312getEllipsisgIe3tQ8(), false, 2, 0, null, MaterialTheme.INSTANCE.getTypography(composer5, MaterialTheme.$stable).getTitleMedium(), composer5, 0, 24960, 110590);
                                    switch (WhenMappings.$EnumSwitchMapping$0[cardCandidate2.getSchedule().getPhase().ordinal()]) {
                                        case 1:
                                            str = "新卡";
                                            break;
                                        case 2:
                                        case 3:
                                            str = "学习中";
                                            break;
                                        case 4:
                                            str = "已学习";
                                            break;
                                        default:
                                            throw new NoWhenBranchMatchedException();
                                    }
/* 33 */                            if (cardCandidate2.getSchedule().getPhase() == Phase.NEW) {
                                        str2 = " · 尚未开始";
                                    } else {
                                        str2 = " · " + XunjiComponentsKt.localTime(cardCandidate2.getSchedule().getDueAt());
                                    }
                                    XunjiComponentsKt.Notice(str + str2, false, composer5, 0, 2);
/* 31 */                            ComposerKt.sourceInformationMarkerEnd(composer5);
/* 89 */                            ComposerKt.sourceInformationMarkerEnd(composer5);
/* 119 */                           composer.endNode();
/* 98 */                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 92 */                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 83 */                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 35 */                            ComposerKt.sourceInformationMarkerStart($composer2, -578879041, "CC(remember):DeckDetailScreen.kt#9igjgp");
                                    zChanged2 = $composer2.changed(mutableState3) | $composer2.changedInstance(cardCandidate2);
/* 123 */                           objRememberedValue2 = $composer2.rememberedValue();
/* 124 */                           if (!zChanged2) {
                                        Object obj7 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                            @Override // kotlin.jvm.functions.Function0
/* 34 */                                    public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                        invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                    public final void invoke2() {
/* 118 */                                       setValue(cardCandidate2.getCard().getId());
/* 118 */                                       setValue(null);
                                            }
                                        };
/* 126 */                               $composer2.updateRememberedValue(obj7);
/* 127 */                               objRememberedValue2 = obj7;
                                    } else {
                                        Object obj8 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1
                                            @Override // kotlin.jvm.functions.Function0
/* 34 */                                    public /* bridge */ /* synthetic */ Unit invoke() {
/* 35 */                                        invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 34 */                                    public final void invoke2() {
/* 118 */                                       setValue(cardCandidate2.getCard().getId());
/* 118 */                                       setValue(null);
                                            }
                                        };
/* 126 */                               $composer2.updateRememberedValue(obj8);
/* 127 */                               objRememberedValue2 = obj8;
                                    }
                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 35 */                            XunjiComponentsKt.IconAction("delete", "删除卡片", (Function0) objRememberedValue2, null, false, $composer2, 54, 24);
/* 30 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 52 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 129 */                           $composer2.endNode();
/* 61 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 55 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 44 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
                                    if (ComposerKt.isTraceInProgress()) {
                                        ComposerKt.traceEventEnd();
                                    }
                                }
                            }, $composer, 54), $composer, 48, 0);
                            $composer.endReplaceGroup();
/* 179 */                   if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                    }));
/* 39 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 22 */        public static final Unit DeckDetailScreen$lambda$14$0$0(DeckSummary $deck, List $cards, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C22@1284L68:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-495961921, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:22)");
                        }
/* 23 */                XunjiComponentsKt.SectionTitle($deck.getDeck().getName(), $cards.size() + " 张卡片 · " + $deck.getDue() + " 张到期复习", $composer, 0, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 23 */        public static final Unit DeckDetailScreen$lambda$14$0$1(Function0 $onReview, List $cards, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C23@1364L78:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1298507446, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:23)");
                        }
/* 24 */                XunjiComponentsKt.PrimaryButton("复习这个牌组", $onReview, null, !$cards.isEmpty(), "review-start", $composer, 24582, 4);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:36:0x01ed  */
/* 24 */        public static final Unit DeckDetailScreen$lambda$14$0$2(final Function1 $onEdit, LazyItemScope item, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Composer composer;
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C24@1454L230:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-706983433, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:24)");
                        }
/* 25 */                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 133 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 134 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
/* 139 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 140 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 141 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 142 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
/* 144 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 138 */               int i = ((((438 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 146 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 147 */               $composer.startReusableNode();
/* 148 */               if ($composer.getInserting()) {
/* 149 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 151 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 153 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 154 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 155 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 156 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 158 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 157 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 160 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 163 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 165 */               int i2 = (i >> 6) & 14;
/* 136 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i3 = ((438 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -120202945, "C24@1609L10,24@1577L54,24@1656L14,24@1632L50:DeckDetailScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk("所有卡片", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        ComposerKt.sourceInformationMarkerStart($composer, -1666443063, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($onEdit);
                        Object objRememberedValue = $composer.rememberedValue();
/* 167 */               if (zChanged) {
/* 167 */                   composer = $composer;
                        } else {
                            composer = $composer;
                            if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 25 */                    XunjiComponentsKt.IconAction("add", "新增卡片", (Function0) objRememberedValue, "add-card", false, composer, 3126, 16);
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 136 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 172 */                   $composer.endNode();
/* 145 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 139 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 133 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                        objRememberedValue = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function0
                            public final Object invoke() {
                                return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$2$0$0$0($onEdit);
                            }
                        };
/* 169 */               $composer.updateRememberedValue(objRememberedValue);
                        ComposerKt.sourceInformationMarkerEnd(composer);
/* 25 */                XunjiComponentsKt.IconAction("add", "新增卡片", (Function0) objRememberedValue, "add-card", false, composer, 3126, 16);
                        ComposerKt.sourceInformationMarkerEnd(composer);
/* 136 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 172 */               $composer.endNode();
/* 145 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 139 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 133 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 25 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 24 */        public static final Unit DeckDetailScreen$lambda$14$0$2$0$0$0(Function1 $onEdit) {
/* 25 */            $onEdit.invoke(null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 25 */        public static final Unit DeckDetailScreen$lambda$14$0$3(final Function1 $onEdit, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C25@1770L14,25@1715L70:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-313113126, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:25)");
                        }
/* 26 */                ComposerKt.sourceInformationMarkerStart($composer, -254001528, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($onEdit);
/* 176 */               Object objRememberedValue = $composer.rememberedValue();
/* 177 */               if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 26 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda13
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$14$0$3$0$0($onEdit);
                                }
                            };
/* 179 */                   $composer.updateRememberedValue(obj);
/* 180 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 26 */                XunjiComponentsKt.EmptyState("留下一点新知识", "正面写问题，背面写答案。例句让记忆有上下文。", "创建第一张卡", (Function0) objRememberedValue, $composer, 438, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 25 */        public static final Unit DeckDetailScreen$lambda$14$0$3$0$0(Function1 $onEdit) {
/* 26 */            $onEdit.invoke(null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 26 */        public static final Object DeckDetailScreen$lambda$14$0$4(CardCandidate it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 27 */            return it.getCard().getId();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit DeckDetailScreen$lambda$15$0(MutableState $busy$delegate, MutableState $deleting$delegate) {
/* 40 */            if (!DeckDetailScreen$lambda$9($busy$delegate)) {
/* 118 */               $deleting$delegate.setValue(null);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit DeckDetailScreen$lambda$16(final CoroutineScope $scope, final MainViewModel $viewModel, final MutableState $deleting$delegate, final MutableState $busy$delegate, final MutableState $error$delegate, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C39@2768L195,39@2757L276:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(634615349, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                ComposerKt.sourceInformationMarkerStart($composer, -20005032, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer.changedInstance($scope) | $composer.changedInstance($viewModel) | $composer.changed($deleting$delegate);
/* 182 */               Object objRememberedValue = $composer.rememberedValue();
/* 183 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 40 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda15
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$16$0$0($scope, $busy$delegate, $viewModel, $deleting$delegate, $error$delegate);
                                }
                            };
/* 185 */                   $composer.updateRememberedValue(obj);
/* 186 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 40 */                ButtonKt.TextButton((Function0) objRememberedValue, null, true ^ DeckDetailScreen$lambda$9($busy$delegate), null, null, null, null, null, null, ComposableSingletons$DeckDetailScreenKt.INSTANCE.m8992getLambda$1805515944$app_debug(), $composer, 805306368, 506);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit DeckDetailScreen$lambda$16$0$0(CoroutineScope $scope, MutableState $busy$delegate, MainViewModel $viewModel, MutableState $deleting$delegate, MutableState $error$delegate) {
/* 40 */            if (!DeckDetailScreen$lambda$9($busy$delegate)) {
                        DeckDetailScreen$lambda$10($busy$delegate, true);
/* 1 */                 BuildersKt__Builders_commonKt.launch$default($scope, null, null, new DeckDetailScreenKt$DeckDetailScreen$6$1$1$1($viewModel, $deleting$delegate, $error$delegate, $busy$delegate, null), 3, null);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit DeckDetailScreen$lambda$17(final MutableState $deleting$delegate, MutableState $busy$delegate, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C39@3063L15,39@3052L56:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-868482957, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                ComposerKt.sourceInformationMarkerStart($composer, -1388465822, "CC(remember):DeckDetailScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($deleting$delegate);
/* 182 */               Object objRememberedValue = $composer.rememberedValue();
/* 183 */               if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 40 */                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DeckDetailScreenKt$$ExternalSyntheticLambda14
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DeckDetailScreenKt.DeckDetailScreen$lambda$17$0$0($deleting$delegate);
                                }
                            };
/* 185 */                   $composer.updateRememberedValue(obj);
/* 186 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 40 */                ButtonKt.TextButton((Function0) objRememberedValue, null, true ^ DeckDetailScreen$lambda$9($busy$delegate), null, null, null, null, null, null, ComposableSingletons$DeckDetailScreenKt.INSTANCE.getLambda$986353046$app_debug(), $composer, 805306368, 506);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 39 */        public static final Unit DeckDetailScreen$lambda$17$0$0(MutableState $deleting$delegate) {
/* 118 */           $deleting$delegate.setValue(null);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:28:0x016f  */
                /* JADX WARN: Code duplicated, block: B:29:0x018d  */
                /* JADX WARN: Code duplicated, block: B:32:0x01b6  */
/* 39 */        public static final Unit DeckDetailScreen$lambda$18(MutableState $error$delegate, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Composer composer;
                    int i;
                    Composer composer2;
                    ComposerKt.sourceInformation($composer, "C39@2663L75:DeckDetailScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1171836880, $changed, -1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)");
                        }
/* 40 */                ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 189 */               Modifier modifier = Modifier.INSTANCE;
/* 40 */                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
/* 40 */                ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 200 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 201 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 202 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 204 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 198 */               int i2 = ((((0 << 3) & 112) << 6) & 896) | 6;
/* 40 */                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 206 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 207 */               $composer.startReusableNode();
/* 208 */               if ($composer.getInserting()) {
/* 209 */                   function0 = constructor;
/* 40 */                    $composer.createNode(function0);
                        } else {
/* 211 */                   function0 = constructor;
/* 40 */                    $composer.useNode();
                        }
/* 213 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 214 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 215 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 216 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 218 */               if (!composerM4979constructorimpl.getInserting()) {
/* 40 */                    composer = $composer;
                            i = 0;
/* 217 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 223 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 225 */                   int i3 = (i2 >> 6) & 14;
                            composer2 = composer;
/* 196 */                   ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                            int i4 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer2, -1002428247, "C39@2672L28:DeckDetailScreen.kt#i35lj1");
                            TextKt.m3584TextNvy7gAk("这张卡片及其学习记录将被删除，无法撤回。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer2, 6, 0, 262142);
                            if (DeckDetailScreen$lambda$6($error$delegate) != null) {
                                composer2.startReplaceGroup(1214590958);
                                ComposerKt.sourceInformation(composer2, "39@2716L20");
                                String strDeckDetailScreen$lambda$6 = DeckDetailScreen$lambda$6($error$delegate);
                                Intrinsics.checkNotNull(strDeckDetailScreen$lambda$6);
                                XunjiComponentsKt.Notice(strDeckDetailScreen$lambda$6, true, composer2, 48, 0);
                            } else {
                                composer2.startReplaceGroup(-1005081848);
                            }
                            composer2.endReplaceGroup();
                            ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */                   ComposerKt.sourceInformationMarkerEnd(composer2);
/* 226 */                   composer.endNode();
/* 205 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 199 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 188 */                   ComposerKt.sourceInformationMarkerEnd(composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
/* 40 */                    composer = $composer;
                            i = 0;
                        }
/* 217 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 220 */               composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 223 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 225 */               int i5 = (i2 >> 6) & 14;
                        composer2 = composer;
/* 196 */               ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                        int i6 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer2, -1002428247, "C39@2672L28:DeckDetailScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk("这张卡片及其学习记录将被删除，无法撤回。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer2, 6, 0, 262142);
                        if (DeckDetailScreen$lambda$6($error$delegate) != null) {
                            composer2.startReplaceGroup(1214590958);
                            ComposerKt.sourceInformation(composer2, "39@2716L20");
                            String strDeckDetailScreen$lambda$7 = DeckDetailScreen$lambda$6($error$delegate);
                            Intrinsics.checkNotNull(strDeckDetailScreen$lambda$7);
                            XunjiComponentsKt.Notice(strDeckDetailScreen$lambda$7, true, composer2, 48, 0);
                        } else {
                            composer2.startReplaceGroup(-1005081848);
                        }
                        composer2.endReplaceGroup();
                        ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */               ComposerKt.sourceInformationMarkerEnd(composer2);
/* 226 */               composer.endNode();
/* 205 */               ComposerKt.sourceInformationMarkerEnd(composer);
/* 199 */               ComposerKt.sourceInformationMarkerEnd(composer);
/* 188 */               ComposerKt.sourceInformationMarkerEnd(composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 40 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

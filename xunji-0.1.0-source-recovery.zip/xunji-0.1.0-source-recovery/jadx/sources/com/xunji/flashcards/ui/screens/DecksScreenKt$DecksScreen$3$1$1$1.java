            package com.xunji.flashcards.ui.screens;

            import androidx.compose.runtime.MutableState;
            import androidx.core.view.MotionEventCompat;
            import com.xunji.flashcards.ui.MainViewModel;
            import java.util.concurrent.CancellationException;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: DecksScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"}, d2 = {"<anonymous>", "", "Lkotlinx/coroutines/CoroutineScope;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$3$1$1$1", f = "DecksScreen.kt", i = {}, l = {MotionEventCompat.AXIS_GENERIC_4, MotionEventCompat.AXIS_GENERIC_4}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 33 */    final class DecksScreenKt$DecksScreen$3$1$1$1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                final /* synthetic */ MutableState<Boolean> $adding$delegate;
                final /* synthetic */ MutableState<Boolean> $busy$delegate;
                final /* synthetic */ MutableState<String> $editing$delegate;
                final /* synthetic */ MutableState<String> $error$delegate;
                final /* synthetic */ MutableState<String> $name$delegate;
                final /* synthetic */ MainViewModel $viewModel;
                int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                DecksScreenKt$DecksScreen$3$1$1$1(MainViewModel mainViewModel, MutableState<Boolean> mutableState, MutableState<String> mutableState2, MutableState<String> mutableState3, MutableState<String> mutableState4, MutableState<Boolean> mutableState5, Continuation<? super DecksScreenKt$DecksScreen$3$1$1$1> continuation) {
                    super(2, continuation);
                    this.$viewModel = mainViewModel;
                    this.$adding$delegate = mutableState;
                    this.$name$delegate = mutableState2;
                    this.$editing$delegate = mutableState3;
                    this.$error$delegate = mutableState4;
                    this.$busy$delegate = mutableState5;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new DecksScreenKt$DecksScreen$3$1$1$1(this.$viewModel, this.$adding$delegate, this.$name$delegate, this.$editing$delegate, this.$error$delegate, this.$busy$delegate, continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                    return ((DecksScreenKt$DecksScreen$3$1$1$1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 34 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    Object coroutine_suspended = IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    try {
                        try {
                            switch (this.label) {
                                case 0:
                                    ResultKt.throwOnFailure($result);
/* 1 */                             if (DecksScreenKt.DecksScreen$lambda$4(this.$adding$delegate)) {
                                        this.label = 1;
/* 1 */                                 if (this.$viewModel.createDeck(DecksScreenKt.DecksScreen$lambda$10(this.$name$delegate), this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                    } else {
                                        MainViewModel mainViewModel = this.$viewModel;
/* 1 */                                 String strDecksScreen$lambda$1 = DecksScreenKt.DecksScreen$lambda$1(this.$editing$delegate);
                                        Intrinsics.checkNotNull(strDecksScreen$lambda$1);
                                        this.label = 2;
/* 1 */                                 if (mainViewModel.renameDeck(strDecksScreen$lambda$1, DecksScreenKt.DecksScreen$lambda$10(this.$name$delegate), this) == coroutine_suspended) {
                                            return coroutine_suspended;
                                        }
                                        Unit unit = Unit.INSTANCE;
                                    }
/* 1 */                             DecksScreenKt.DecksScreen$lambda$5(this.$adding$delegate, false);
/* 79 */                            setValue(null);
/* 1 */                             DecksScreenKt.DecksScreen$lambda$17(this.$busy$delegate, false);
                                    return Unit.INSTANCE;
                                case 1:
                                    ResultKt.throwOnFailure($result);
/* 1 */                             DecksScreenKt.DecksScreen$lambda$5(this.$adding$delegate, false);
/* 79 */                            setValue(null);
/* 1 */                             DecksScreenKt.DecksScreen$lambda$17(this.$busy$delegate, false);
                                    return Unit.INSTANCE;
                                case 2:
                                    ResultKt.throwOnFailure($result);
                                    Unit unit2 = Unit.INSTANCE;
/* 1 */                             DecksScreenKt.DecksScreen$lambda$5(this.$adding$delegate, false);
/* 79 */                            setValue(null);
/* 1 */                             DecksScreenKt.DecksScreen$lambda$17(this.$busy$delegate, false);
                                    return Unit.INSTANCE;
                                default:
                                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                        } catch (IllegalArgumentException e) {
                            MutableState<String> mutableState = this.$error$delegate;
                            String message = e.getMessage();
                            if (message == null) {
                                message = "请检查名称";
                            }
/* 85 */                    mutableState.setValue(message);
                        } catch (CancellationException e2) {
                            throw e2;
                        } catch (Exception e3) {
/* 85 */                    setValue("保存未完成，请重试");
                        }
                    } catch (Throwable th) {
/* 1 */                 DecksScreenKt.DecksScreen$lambda$17(this.$busy$delegate, false);
                        throw th;
                    }
                }
            }

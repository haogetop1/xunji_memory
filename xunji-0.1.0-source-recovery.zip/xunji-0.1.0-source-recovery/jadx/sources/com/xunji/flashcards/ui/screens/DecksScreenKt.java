            package com.xunji.flashcards.ui.screens;

            import androidx.autofill.HintConstants;
            import androidx.compose.foundation.ClickableKt;
            import androidx.compose.foundation.interaction.MutableInteractionSource;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.foundation.text.KeyboardActions;
            import androidx.compose.foundation.text.KeyboardOptions;
            import androidx.compose.material3.AndroidAlertDialog_androidKt;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.DividerKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.OutlinedTextFieldKt;
            import androidx.compose.material3.TextFieldColors;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.EffectsKt;
            import androidx.compose.runtime.MutableState;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambda;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.runtime.saveable.RememberSaveableKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.graphics.Shape;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.text.TextStyle;
            import androidx.compose.ui.text.input.VisualTransformation;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.model.DeckSummary;
            import com.xunji.flashcards.ui.MainUiState;
            import com.xunji.flashcards.ui.MainViewModel;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.util.List;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.coroutines.EmptyCoroutineContext;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            import kotlinx.coroutines.BuildersKt__Builders_commonKt;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: DecksScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000(\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0004\u001a1\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\t¨\u0006\n²\u0006\f\u0010\u000b\u001a\u0004\u0018\u00010\bX\u008a\u008e\u0002²\u0006\n\u0010\f\u001a\u00020\rX\u008a\u008e\u0002²\u0006\f\u0010\u000e\u001a\u0004\u0018\u00010\bX\u008a\u008e\u0002²\u0006\n\u0010\u000f\u001a\u00020\bX\u008a\u008e\u0002²\u0006\f\u0010\u0010\u001a\u0004\u0018\u00010\bX\u008a\u008e\u0002²\u0006\n\u0010\u0011\u001a\u00020\rX\u008a\u008e\u0002"}, d2 = {"DecksScreen", "", "state", "Lcom/xunji/flashcards/ui/MainUiState;", "viewModel", "Lcom/xunji/flashcards/ui/MainViewModel;", "onDeck", "Lkotlin/Function1;", "", "(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "app_debug", "editing", "adding", "", "deleting", HintConstants.AUTOFILL_HINT_NAME, "error", "busy"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 14 */    public final class DecksScreenKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit DecksScreen$lambda$28(MainUiState mainUiState, MainViewModel mainViewModel, Function1 function1, int i, Composer composer, int i2) {
                    DecksScreen(mainUiState, mainViewModel, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 15 */        public static final void DecksScreen(final MainUiState state, final MainViewModel viewModel, final Function1<? super String, Unit> onDeck, Composer $composer, final int $changed) {
                    final MainViewModel mainViewModel;
                    boolean z;
                    final MutableState adding$delegate;
                    Object obj;
                    final MutableState error$delegate;
                    final MutableState name$delegate;
                    final MutableState busy$delegate;
                    CoroutineScope scope;
                    int i;
                    boolean z2;
                    String str;
                    int i2;
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(viewModel, "viewModel");
                    Intrinsics.checkNotNullParameter(onDeck, "onDeck");
/* 16 */            Composer $composer2 = $composer.startRestartGroup(-1875707283);
                    ComposerKt.sourceInformation($composer2, "C(DecksScreen)N(state,viewModel,onDeck)16@642L33,16@625L50,16@707L25,16@690L42,16@766L33,16@749L50,17@830L22,17@813L39,17@866L42,17@921L34,17@966L24,18@1129L1277,18@992L1414:DecksScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(viewModel) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer2.changedInstance(onDeck) ? 256 : 128;
                    }
                    int $dirty2 = $dirty;
                    if ($composer2.shouldExecute(($dirty2 & 147) != 146, $dirty2 & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 16 */                    ComposerKt.traceEventStart(-1875707283, $dirty2, -1, "com.xunji.flashcards.ui.screens.DecksScreen (DecksScreen.kt:15)");
                        }
                        Object[] objArr = new Object[0];
/* 17 */                ComposerKt.sourceInformationMarkerStart($composer2, 1331569102, "CC(remember):DecksScreen.kt#9igjgp");
/* 39 */                Object objRememberedValue = $composer2.rememberedValue();
/* 40 */                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda24
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DecksScreenKt.DecksScreen$lambda$0$0();
                                }
                            };
/* 42 */                    $composer2.updateRememberedValue(obj2);
/* 43 */                    objRememberedValue = obj2;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 17 */                final MutableState editing$delegate = (MutableState) RememberSaveableKt.rememberSaveable(objArr, (Function0) objRememberedValue, $composer2, 48);
                        Object[] objArr2 = new Object[0];
                        ComposerKt.sourceInformationMarkerStart($composer2, 1331571174, "CC(remember):DecksScreen.kt#9igjgp");
/* 39 */                Object objRememberedValue2 = $composer2.rememberedValue();
/* 40 */                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                            Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda5
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DecksScreenKt.DecksScreen$lambda$3$0();
                                }
                            };
/* 42 */                    $composer2.updateRememberedValue(obj3);
/* 43 */                    objRememberedValue2 = obj3;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 17 */                MutableState adding$delegate2 = (MutableState) RememberSaveableKt.rememberSaveable(objArr2, (Function0) objRememberedValue2, $composer2, 48);
                        Object[] objArr3 = new Object[0];
                        ComposerKt.sourceInformationMarkerStart($composer2, 1331573070, "CC(remember):DecksScreen.kt#9igjgp");
/* 39 */                Object objRememberedValue3 = $composer2.rememberedValue();
/* 40 */                if (objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                            Object obj4 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda6
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DecksScreenKt.DecksScreen$lambda$6$0();
                                }
                            };
/* 42 */                    $composer2.updateRememberedValue(obj4);
/* 43 */                    objRememberedValue3 = obj4;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 17 */                final MutableState deleting$delegate = (MutableState) RememberSaveableKt.rememberSaveable(objArr3, (Function0) objRememberedValue3, $composer2, 48);
                        Object[] objArr4 = new Object[0];
/* 18 */                ComposerKt.sourceInformationMarkerStart($composer2, 1331575107, "CC(remember):DecksScreen.kt#9igjgp");
/* 45 */                Object objRememberedValue4 = $composer2.rememberedValue();
/* 46 */                if (objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
                            Object obj5 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda7
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DecksScreenKt.DecksScreen$lambda$9$0();
                                }
                            };
/* 48 */                    $composer2.updateRememberedValue(obj5);
/* 49 */                    objRememberedValue4 = obj5;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 18 */                final MutableState name$delegate2 = (MutableState) RememberSaveableKt.rememberSaveable(objArr4, (Function0) objRememberedValue4, $composer2, 48);
                        ComposerKt.sourceInformationMarkerStart($composer2, 1331576279, "CC(remember):DecksScreen.kt#9igjgp");
/* 45 */                Object objRememberedValue5 = $composer2.rememberedValue();
/* 46 */                if (objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
/* 1 */                     MutableState mutableStateMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
/* 48 */                    $composer2.updateRememberedValue(mutableStateMutableStateOf$default);
/* 49 */                    objRememberedValue5 = mutableStateMutableStateOf$default;
                        }
/* 18 */                final MutableState error$delegate2 = (MutableState) objRememberedValue5;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
                        ComposerKt.sourceInformationMarkerStart($composer2, 1331578031, "CC(remember):DecksScreen.kt#9igjgp");
/* 45 */                Object objRememberedValue6 = $composer2.rememberedValue();
/* 46 */                if (objRememberedValue6 == Composer.INSTANCE.getEmpty()) {
                            z = false;
/* 1 */                     Object objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
/* 48 */                    $composer2.updateRememberedValue(objMutableStateOf$default);
/* 49 */                    objRememberedValue6 = objMutableStateOf$default;
                        } else {
                            z = false;
                        }
/* 18 */                final MutableState busy$delegate2 = (MutableState) objRememberedValue6;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 51 */                ComposerKt.sourceInformationMarkerStart($composer2, 773894976, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp");
/* 57 */                ComposerKt.sourceInformationMarkerStart($composer2, 683737348, "CC(remember):Effects.kt#9igjgp");
                        Object objRememberedValue7 = $composer2.rememberedValue();
/* 46 */                if (objRememberedValue7 == Composer.INSTANCE.getEmpty()) {
/* 56 */                    objRememberedValue7 = EffectsKt.createCompositionCoroutineScope(EmptyCoroutineContext.INSTANCE, $composer2);
/* 48 */                    $composer2.updateRememberedValue(objRememberedValue7);
                        }
/* 57 */                final CoroutineScope scope2 = (CoroutineScope) objRememberedValue7;
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 51 */                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 19 */                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 19 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 19 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(16));
                        ComposerKt.sourceInformationMarkerStart($composer2, 1331585930, "CC(remember):DecksScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer2.changedInstance(state) | $composer2.changed(adding$delegate2) | $composer2.changed(name$delegate2) | (($dirty2 & 896) == 256 ? true : z) | $composer2.changed(editing$delegate) | $composer2.changed(deleting$delegate);
/* 60 */                Object objRememberedValue8 = $composer2.rememberedValue();
/* 61 */                if (zChangedInstance || objRememberedValue8 == Composer.INSTANCE.getEmpty()) {
                            adding$delegate = adding$delegate2;
                            obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda8
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj6) {
                                    return DecksScreenKt.DecksScreen$lambda$18$0(state, adding$delegate, name$delegate2, error$delegate2, onDeck, editing$delegate, deleting$delegate, (LazyListScope) obj6);
                                }
                            };
                            name$delegate2 = name$delegate2;
                            deleting$delegate = deleting$delegate;
/* 62 */                    error$delegate = error$delegate2;
/* 63 */                    $composer2.updateRememberedValue(obj);
                        } else {
                            error$delegate = error$delegate2;
                            adding$delegate = adding$delegate2;
                            obj = objRememberedValue8;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 19 */                LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) obj, $composer2, 24966, 490);
/* 35 */                $composer2 = $composer2;
                        if (DecksScreen$lambda$4(adding$delegate) || DecksScreen$lambda$1(editing$delegate) != null) {
                            $composer2.startReplaceGroup(1331627305);
                            ComposerKt.sourceInformation($composer2, "34@2464L40,34@2780L427,34@3222L72,34@2511L39,34@2556L209,34@2435L860");
                            ComposerKt.sourceInformationMarkerStart($composer2, 1331627413, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChanged = $composer2.changed(adding$delegate) | $composer2.changed(editing$delegate);
/* 66 */                    Object objRememberedValue9 = $composer2.rememberedValue();
/* 67 */                    if (zChanged || objRememberedValue9 == Composer.INSTANCE.getEmpty()) {
/* 59 */                        Object obj6 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda9
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$19$0(busy$delegate2, adding$delegate, editing$delegate);
                                    }
                                };
/* 69 */                        $composer2.updateRememberedValue(obj6);
/* 70 */                        objRememberedValue9 = obj6;
                            }
/* 35 */                    Function0 function0 = (Function0) objRememberedValue9;
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            MutableState deleting$delegate2 = deleting$delegate;
/* 59 */                    Function2 function2 = new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda10
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj7, Object obj8) {
                                    return DecksScreenKt.DecksScreen$lambda$20(scope2, adding$delegate, viewModel, name$delegate2, editing$delegate, busy$delegate2, error$delegate, (Composer) obj7, ((Integer) obj8).intValue());
                                }
                            };
                            final MutableState name$delegate3 = name$delegate2;
                            name$delegate = error$delegate;
                            final MutableState error$delegate3 = adding$delegate;
/* 59 */                    busy$delegate = busy$delegate2;
                            ComposableLambda composableLambdaRememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(864669562, true, function2, $composer2, 54);
/* 18 */                    scope = scope2;
                            ComposableLambda composableLambdaRememberComposableLambda2 = ComposableLambdaKt.rememberComposableLambda(708689020, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda12
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj7, Object obj8) {
                                    return DecksScreenKt.DecksScreen$lambda$21(error$delegate3, editing$delegate, busy$delegate, (Composer) obj7, ((Integer) obj8).intValue());
                                }
                            }, $composer2, 54);
                            ComposableLambda composableLambdaRememberComposableLambda3 = ComposableLambdaKt.rememberComposableLambda(552708478, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda13
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj7, Object obj8) {
                                    return DecksScreenKt.DecksScreen$lambda$22(error$delegate3, (Composer) obj7, ((Integer) obj8).intValue());
                                }
                            }, $composer2, 54);
                            ComposableLambda composableLambdaRememberComposableLambda4 = ComposableLambdaKt.rememberComposableLambda(474718207, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda14
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj7, Object obj8) {
                                    return DecksScreenKt.DecksScreen$lambda$23(name$delegate3, name$delegate, busy$delegate, (Composer) obj7, ((Integer) obj8).intValue());
                                }
                            }, $composer2, 54);
                            i = 54;
                            z2 = true;
                            deleting$delegate = deleting$delegate2;
                            str = "CC(remember):DecksScreen.kt#9igjgp";
                            i2 = -1671669675;
                            AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0(function0, composableLambdaRememberComposableLambda, null, composableLambdaRememberComposableLambda2, null, composableLambdaRememberComposableLambda3, composableLambdaRememberComposableLambda4, null, 0L, 0L, 0L, 0L, 0.0f, null, $composer2, 1772592, 0, 16276);
                            $composer2 = $composer2;
                            $composer2.endReplaceGroup();
                        } else {
                            $composer2.startReplaceGroup(-1671669675);
                            $composer2.endReplaceGroup();
                            z2 = true;
/* 59 */                    busy$delegate = busy$delegate2;
                            name$delegate = error$delegate;
/* 18 */                    scope = scope2;
                            str = "CC(remember):DecksScreen.kt#9igjgp";
                            i2 = -1671669675;
                            i = 54;
                        }
/* 36 */                if (DecksScreen$lambda$7(deleting$delegate) != null) {
                            $composer2.startReplaceGroup(1331655136);
                            ComposerKt.sourceInformation($composer2, "35@3344L24,35@3490L280,35@3785L60,35@3398L77,35@3315L531");
                            ComposerKt.sourceInformationMarkerStart($composer2, 1331655557, str);
                            boolean zChanged2 = $composer2.changed(deleting$delegate);
                            Composer composer = $composer2;
/* 72 */                    Object objRememberedValue10 = composer.rememberedValue();
/* 73 */                    if (zChanged2 || objRememberedValue10 == Composer.INSTANCE.getEmpty()) {
/* 36 */                        Object obj7 = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda25
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$24$0(busy$delegate, deleting$delegate);
                                    }
                                };
/* 75 */                        composer.updateRememberedValue(obj7);
/* 76 */                        objRememberedValue10 = obj7;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer2);
                            int i3 = i;
                            final MutableState error$delegate4 = name$delegate;
                            mainViewModel = viewModel;
                            final MutableState error$delegate5 = busy$delegate;
                            final CoroutineScope scope3 = scope;
                            Composer $composer3 = $composer2;
/* 36 */                    AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0((Function0) objRememberedValue10, ComposableLambdaKt.rememberComposableLambda(-1876995677, z2, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda1
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj8, Object obj9) {
                                    return DecksScreenKt.DecksScreen$lambda$25(scope3, mainViewModel, deleting$delegate, error$delegate5, error$delegate4, (Composer) obj8, ((Integer) obj9).intValue());
                                }
                            }, $composer2, i3), null, ComposableLambdaKt.rememberComposableLambda(-1450441179, z2, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda2
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj8, Object obj9) {
                                    return DecksScreenKt.DecksScreen$lambda$26(deleting$delegate, error$delegate5, (Composer) obj8, ((Integer) obj9).intValue());
                                }
                            }, $composer2, i3), null, ComposableSingletons$DecksScreenKt.INSTANCE.m8993getLambda$1023886681$app_debug(), ComposableLambdaKt.rememberComposableLambda(1336874216, z2, new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda3
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj8, Object obj9) {
                                    return DecksScreenKt.DecksScreen$lambda$27(error$delegate4, (Composer) obj8, ((Integer) obj9).intValue());
                                }
                            }, $composer2, i3), null, 0L, 0L, 0L, 0L, 0.0f, null, $composer3, 1772592, 0, 16276);
                            $composer2 = $composer3;
                        } else {
                            mainViewModel = viewModel;
                            $composer2.startReplaceGroup(i2);
                        }
                        $composer2.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 16 */                onDeck = onDeck;
                        mainViewModel = viewModel;
                        state = state;
                        $composer2.skipToGroupEnd();
                    }
/* 37 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj8, Object obj9) {
                                return DecksScreenKt.DecksScreen$lambda$28(state, mainViewModel, onDeck, $changed, (Composer) obj8, ((Integer) obj9).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final MutableState DecksScreen$lambda$0$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final String DecksScreen$lambda$1(MutableState<String> mutableState) {
/* 78 */            return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final MutableState DecksScreen$lambda$3$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final boolean DecksScreen$lambda$4(MutableState<Boolean> mutableState) {
/* 78 */            return mutableState.getValue().booleanValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final void DecksScreen$lambda$5(MutableState<Boolean> mutableState, boolean z) {
/* 79 */            mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final MutableState DecksScreen$lambda$6$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(null, null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 16 */        public static final String DecksScreen$lambda$7(MutableState<String> mutableState) {
/* 78 */            return mutableState.getValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 17 */        public static final String DecksScreen$lambda$10(MutableState<String> mutableState) {
/* 81 */            return mutableState.getValue();
                }

/* 17 */        private static final String DecksScreen$lambda$13(MutableState<String> mutableState) {
/* 84 */            return mutableState.getValue();
                }

/* 17 */        private static final boolean DecksScreen$lambda$16(MutableState<Boolean> mutableState) {
/* 87 */            return mutableState.getValue().booleanValue();
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 17 */        public static final void DecksScreen$lambda$17(MutableState<Boolean> mutableState, boolean z) {
/* 88 */            mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 17 */        public static final MutableState DecksScreen$lambda$9$0() {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default("", null, 2, null);
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final Unit DecksScreen$lambda$18$0(final MainUiState $state, final MutableState $adding$delegate, final MutableState $name$delegate, final MutableState $error$delegate, final Function1 $onDeck, final MutableState $editing$delegate, final MutableState $deleting$delegate, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 20 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-2044847240, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda15
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return DecksScreenKt.DecksScreen$lambda$18$0$0($state, $adding$delegate, $name$delegate, $error$delegate, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 21 */            if ($state.getLoading()) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$DecksScreenKt.INSTANCE.m8995getLambda$1648141507$app_debug(), 3, null);
                    }
/* 22 */            if ($state.getDecks().isEmpty() && !$state.getLoading()) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1010439782, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return DecksScreenKt.DecksScreen$lambda$18$0$1($adding$delegate, $name$delegate, $error$delegate, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 23 */            final List<DeckSummary> decks = $state.getDecks();
                    final Function1 function1 = new Function1() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda17
                        @Override // kotlin.jvm.functions.Function1
                        public final Object invoke(Object obj) {
                            return DecksScreenKt.DecksScreen$lambda$18$0$2((DeckSummary) obj);
                        }
                    };
/* 93 */            final Function1 function2 = new Function1() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$1
                        @Override // kotlin.jvm.functions.Function1
/* 170 */               public /* bridge */ /* synthetic */ Object invoke(Object p1) {
/* 171 */                   return invoke((DeckSummary) p1);
                        }

                        @Override // kotlin.jvm.functions.Function1
/* 170 */               public final Void invoke(DeckSummary deckSummary) {
/* 171 */                   return null;
                        }
                    };
/* 96 */            LazyColumn.items(decks.size(), new Function1<Integer, Object>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$2
                        @Override // kotlin.jvm.functions.Function1
/* 173 */               public /* bridge */ /* synthetic */ Object invoke(Integer num) {
/* 174 */                   return invoke(num.intValue());
                        }

/* 175 */               public final Object invoke(int index) {
/* 176 */                   return invoke(decks.get(index));
                        }
                    }, new Function1<Integer, Object>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$3
                        @Override // kotlin.jvm.functions.Function1
/* 173 */               public /* bridge */ /* synthetic */ Object invoke(Integer num) {
/* 174 */                   return invoke(num.intValue());
                        }

/* 176 */               public final Object invoke(int index) {
/* 177 */                   return invoke(decks.get(index));
                        }
                    }, ComposableLambdaKt.composableLambdaInstance(802480018, true, new Function4<LazyItemScope, Integer, Composer, Integer, Unit>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4
                        @Override // kotlin.jvm.functions.Function4
/* 177 */               public /* bridge */ /* synthetic */ Unit invoke(LazyItemScope lazyItemScope, Integer num, Composer composer, Integer num2) {
/* 178 */                   invoke(lazyItemScope, num.intValue(), composer, num2.intValue());
                            return Unit.INSTANCE;
                        }

/* 178 */               public final void invoke(LazyItemScope $this$items, int it, Composer $composer, int $changed) {
                            ComposerKt.sourceInformation($composer, "CN(it)178@8834L22:LazyDsl.kt#428nma");
                            int $dirty = $changed;
                            if (($changed & 6) == 0) {
                                $dirty |= $composer.changed($this$items) ? 4 : 2;
                            }
                            if (($changed & 48) == 0) {
                                $dirty |= $composer.changed(it) ? 32 : 16;
                            }
                            if (!$composer.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
/* 178 */                       $composer.skipToGroupEnd();
/* 180 */                       return;
                            }
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(802480018, $dirty, -1, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)");
                            }
                            int i = $dirty & 14;
/* 179 */                   final DeckSummary deckSummary = (DeckSummary) decks.get(it);
/* 181 */                   $composer.startReplaceGroup(861316943);
                            ComposerKt.sourceInformation($composer, "CN(summary)*23@1684L27,23@1713L686,23@1644L755:DecksScreen.kt#i35lj1");
                            Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                            ComposerKt.sourceInformationMarkerStart($composer, -1496235684, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChanged = $composer.changed($onDeck) | $composer.changedInstance(deckSummary);
/* 182 */                   Object objRememberedValue = $composer.rememberedValue();
/* 183 */                   if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                final Function1 function3 = $onDeck;
/* 181 */                       Object obj = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$1$1$4$1$1
                                    @Override // kotlin.jvm.functions.Function0
/* 23 */                            public /* bridge */ /* synthetic */ Unit invoke() {
/* 24 */                                invoke2();
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 23 */                            public final void invoke2() {
/* 24 */                                invoke(deckSummary.getDeck().getId());
                                    }
                                };
/* 185 */                       $composer.updateRememberedValue(obj);
/* 186 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 181 */                   Modifier modifierM306clickableoSLSa3U$default = ClickableKt.m306clickableoSLSa3U$default(modifierFillMaxWidth$default, false, null, null, null, (Function0) objRememberedValue, 15, null);
                            final MutableState mutableState = $editing$delegate;
                            final MutableState mutableState2 = $name$delegate;
                            final MutableState mutableState3 = $deleting$delegate;
                            final MutableState mutableState4 = $error$delegate;
                            XunjiComponentsKt.Paper(modifierM306clickableoSLSa3U$default, ComposableLambdaKt.rememberComposableLambda(-1057721007, true, new Function3<ColumnScope, Composer, Integer, Unit>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$1$1$4$2
                                @Override // kotlin.jvm.functions.Function3
/* 23 */                        public /* bridge */ /* synthetic */ Unit invoke(ColumnScope columnScope, Composer composer, Integer num) {
/* 24 */                            invoke(columnScope, composer, num.intValue());
                                    return Unit.INSTANCE;
                                }

                                /* JADX WARN: Code duplicated, block: B:73:0x0590  */
                                /* JADX WARN: Code duplicated, block: B:76:? A[RETURN, SYNTHETIC] */
/* 24 */                        public final void invoke(ColumnScope Paper, Composer $composer2, int $changed2) {
                                    Function0<ComposeUiNode> function0;
                                    Function0<ComposeUiNode> function4;
                                    Function0<ComposeUiNode> function5;
                                    DeckSummary deckSummary2;
                                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                                    ComposerKt.sourceInformation($composer2, "C24@1719L440,29@2202L11,29@2164L65,30@2234L160:DecksScreen.kt#i35lj1");
                                    if (!$composer2.shouldExecute(($changed2 & 17) != 16, $changed2 & 1)) {
/* 24 */                                $composer2.skipToGroupEnd();
/* 32 */                                return;
                                    }
                                    if (ComposerKt.isTraceInProgress()) {
                                        ComposerKt.traceEventStart(-1057721007, $changed2, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:24)");
                                    }
/* 25 */                            Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                                    Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 25 */                            Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(12));
                                    final MutableState<String> mutableState5 = mutableState;
                                    final DeckSummary deckSummary3 = deckSummary;
                                    final MutableState<String> mutableState6 = mutableState2;
                                    final MutableState<String> mutableState7 = mutableState3;
                                    final MutableState<String> mutableState8 = mutableState4;
                                    ComposerKt.sourceInformationMarkerStart($composer2, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 41 */                            MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, centerVertically, $composer2, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                                    ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 47 */                            int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 48 */                            CompositionLocalMap currentCompositionLocalMap = $composer2.getCurrentCompositionLocalMap();
/* 49 */                            Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer2, modifierFillMaxWidth$default2);
/* 51 */                            Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 45 */                            int i2 = ((((438 << 3) & 112) << 6) & 896) | 6;
                                    ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 53 */                            if (!($composer2.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 54 */                            $composer2.startReusableNode();
/* 55 */                            if ($composer2.getInserting()) {
/* 56 */                                function0 = constructor;
                                        $composer2.createNode(function0);
                                    } else {
/* 58 */                                function0 = constructor;
                                        $composer2.useNode();
                                    }
/* 60 */                            Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer2);
/* 61 */                            Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 62 */                            Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 63 */                            Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 65 */                            if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 64 */                                composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 67 */                                composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                                    }
/* 70 */                            Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 72 */                            int i3 = (i2 >> 6) & 14;
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                    int i4 = ((438 >> 6) & 112) | 6;
                                    RowScope rowScope = RowScopeInstance.INSTANCE;
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, -1576117249, "C25@1850L6,25@1857L129,26@2018L61,26@1992L88,27@2113L39,27@2086L67:DecksScreen.kt#i35lj1");
/* 60 */                            XunjiComponentsKt.Mark(null, $composer2, 0, 1);
                                    Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 60 */                            MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer2, ((0 >> 3) & 14) | ((0 >> 3) & 112));
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 60 */                            int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 60 */                            CompositionLocalMap currentCompositionLocalMap2 = $composer2.getCurrentCompositionLocalMap();
/* 60 */                            Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer2, modifierWeight$default);
/* 88 */                            Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 82 */                            int i5 = ((((0 << 3) & 112) << 6) & 896) | 6;
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 90 */                            if (!($composer2.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 91 */                            $composer2.startReusableNode();
/* 92 */                            if ($composer2.getInserting()) {
/* 93 */                                function4 = constructor2;
/* 60 */                                $composer2.createNode(function4);
                                    } else {
/* 95 */                                function4 = constructor2;
/* 60 */                                $composer2.useNode();
                                    }
/* 60 */                            Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer2);
/* 98 */                            Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 99 */                            Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 100 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 102 */                           if (composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 101 */                               composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 104 */                               composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
                                    }
/* 107 */                           Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 109 */                           int i6 = (i5 >> 6) & 14;
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                    ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                    int i7 = ((0 >> 6) & 112) | 6;
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, 1062908919, "C25@1930L10,25@1887L66,25@1954L30:DecksScreen.kt#i35lj1");
/* 60 */                            TextKt.m3584TextNvy7gAk(deckSummary3.getDeck().getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer2, MaterialTheme.$stable).getTitleMedium(), $composer2, 0, 0, 131070);
/* 60 */                            XunjiComponentsKt.Notice(deckSummary3.getTotal() + " 张卡片", false, $composer2, 0, 2);
/* 60 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 80 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 110 */                           $composer2.endNode();
/* 89 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 83 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 73 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, -50837358, "CC(remember):DecksScreen.kt#9igjgp");
/* 60 */                            boolean zChanged2 = $composer2.changed(mutableState5) | $composer2.changedInstance(deckSummary3) | $composer2.changed(mutableState6);
/* 114 */                           Object objRememberedValue2 = $composer2.rememberedValue();
/* 115 */                           if (zChanged2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                        Object obj2 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$1$1$4$2$1$2$1
                                            @Override // kotlin.jvm.functions.Function0
/* 26 */                                    public /* bridge */ /* synthetic */ Unit invoke() {
/* 27 */                                        invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 26 */                                    public final void invoke2() {
/* 79 */                                        setValue(deckSummary3.getDeck().getId());
/* 82 */                                        setValue(deckSummary3.getDeck().getName());
/* 85 */                                        setValue(null);
                                            }
                                        };
/* 117 */                               $composer2.updateRememberedValue(obj2);
/* 118 */                               objRememberedValue2 = obj2;
                                    }
/* 60 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 60 */                            XunjiComponentsKt.IconAction("edit", "重命名牌组", (Function0) objRememberedValue2, null, false, $composer2, 54, 24);
/* 60 */                            ComposerKt.sourceInformationMarkerStart($composer2, -50834340, "CC(remember):DecksScreen.kt#9igjgp");
/* 60 */                            boolean zChanged3 = $composer2.changed(mutableState7) | $composer2.changedInstance(deckSummary3);
/* 120 */                           Object objRememberedValue3 = $composer2.rememberedValue();
/* 121 */                           if (zChanged3 || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
/* 28 */                                Object obj3 = (Function0) new Function0<Unit>() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$1$1$4$2$1$3$1
                                            @Override // kotlin.jvm.functions.Function0
/* 27 */                                    public /* bridge */ /* synthetic */ Unit invoke() {
/* 28 */                                        invoke2();
                                                return Unit.INSTANCE;
                                            }

                                            /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 27 */                                    public final void invoke2() {
/* 79 */                                        setValue(deckSummary3.getDeck().getId());
/* 85 */                                        setValue(null);
                                            }
                                        };
/* 123 */                               $composer2.updateRememberedValue(obj3);
/* 124 */                               objRememberedValue3 = obj3;
                                    }
/* 60 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 60 */                            XunjiComponentsKt.IconAction("delete", "删除牌组", (Function0) objRememberedValue3, null, false, $composer2, 54, 24);
/* 26 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 43 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 126 */                           $composer2.endNode();
/* 52 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 46 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 40 */                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 30 */                            DividerKt.m2731HorizontalDivider9IZ8Weo(null, 0.0f, MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getOutlineVariant(), $composer2, 0, 3);
/* 31 */                            Arrangement.Horizontal horizontalM699spacedBy0680j_5 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(20));
                                    DeckSummary deckSummary4 = deckSummary;
/* 131 */                           ComposerKt.sourceInformationMarkerStart($composer2, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 132 */                           Modifier modifier = Modifier.INSTANCE;
/* 137 */                           MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_5, Alignment.INSTANCE.getTop(), $composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 142 */                           ComposerKt.sourceInformationMarkerStart($composer2, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 143 */                           int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer2, 0));
/* 144 */                           CompositionLocalMap currentCompositionLocalMap3 = $composer2.getCurrentCompositionLocalMap();
/* 145 */                           Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer2, modifier);
/* 147 */                           Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
/* 141 */                           int i8 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                    ComposerKt.sourceInformationMarkerStart($composer2, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 149 */                           if (!($composer2.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 150 */                           $composer2.startReusableNode();
/* 151 */                           if ($composer2.getInserting()) {
/* 152 */                               function5 = constructor3;
                                        $composer2.createNode(function5);
                                    } else {
/* 154 */                               function5 = constructor3;
                                        $composer2.useNode();
                                    }
/* 156 */                           Composer composerM4979constructorimpl3 = Updater.m4979constructorimpl($composer2);
/* 157 */                           Updater.m4986setimpl(composerM4979constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 158 */                           Updater.m4986setimpl(composerM4979constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 159 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 161 */                           if (!composerM4979constructorimpl3.getInserting()) {
                                        deckSummary2 = deckSummary4;
/* 160 */                               if (!Intrinsics.areEqual(composerM4979constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                                        }
/* 166 */                               Updater.m4986setimpl(composerM4979constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 168 */                               int i9 = (i8 >> 6) & 14;
/* 139 */                               ComposerKt.sourceInformationMarkerStart($composer2, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                                        int i10 = ((48 >> 6) & 112) | 6;
                                        ComposerKt.sourceInformationMarkerStart($composer2, 1129579666, "C30@2338L11,30@2291L67,30@2359L33:DecksScreen.kt#i35lj1");
                                        TextKt.m3584TextNvy7gAk(deckSummary2.getDue() + " 张待复习", null, MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer2, 0, 0, 262138);
                                        XunjiComponentsKt.Notice(deckSummary2.getNewCards() + " 张新卡", false, $composer2, 0, 2);
                                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 139 */                               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 169 */                               $composer2.endNode();
/* 148 */                               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 142 */                               ComposerKt.sourceInformationMarkerEnd($composer2);
/* 131 */                               ComposerKt.sourceInformationMarkerEnd($composer2);
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventEnd();
                                        }
                                    }
                                    deckSummary2 = deckSummary4;
/* 160 */                           composerM4979constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
/* 163 */                           composerM4979constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
/* 166 */                           Updater.m4986setimpl(composerM4979constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 168 */                           int i11 = (i8 >> 6) & 14;
/* 139 */                           ComposerKt.sourceInformationMarkerStart($composer2, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                    RowScopeInstance rowScopeInstance2 = RowScopeInstance.INSTANCE;
                                    int i12 = ((48 >> 6) & 112) | 6;
                                    ComposerKt.sourceInformationMarkerStart($composer2, 1129579666, "C30@2338L11,30@2291L67,30@2359L33:DecksScreen.kt#i35lj1");
                                    TextKt.m3584TextNvy7gAk(deckSummary2.getDue() + " 张待复习", null, MaterialTheme.INSTANCE.getColorScheme($composer2, MaterialTheme.$stable).getPrimary(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer2, 0, 0, 262138);
                                    XunjiComponentsKt.Notice(deckSummary2.getNewCards() + " 张新卡", false, $composer2, 0, 2);
                                    ComposerKt.sourceInformationMarkerEnd($composer2);
/* 139 */                           ComposerKt.sourceInformationMarkerEnd($composer2);
/* 169 */                           $composer2.endNode();
/* 148 */                           ComposerKt.sourceInformationMarkerEnd($composer2);
/* 142 */                           ComposerKt.sourceInformationMarkerEnd($composer2);
/* 131 */                           ComposerKt.sourceInformationMarkerEnd($composer2);
                                    if (ComposerKt.isTraceInProgress()) {
                                        ComposerKt.traceEventEnd();
                                    }
                                }
                            }, $composer, 54), $composer, 48, 0);
                            $composer.endReplaceGroup();
/* 179 */                   if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
                    }));
/* 34 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final Unit DecksScreen$lambda$18$0$0(MainUiState $state, final MutableState $adding$delegate, final MutableState $name$delegate, final MutableState $error$delegate, LazyItemScope item, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C19@1140L268:DecksScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-2044847240, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:19)");
                        }
/* 20 */                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 103 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 104 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
/* 109 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 110 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 111 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
/* 114 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 108 */               int i = ((((438 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 116 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 117 */               $composer.startReusableNode();
/* 118 */               if ($composer.getInserting()) {
/* 119 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 121 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 123 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 124 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 125 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 126 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 128 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 127 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 130 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 133 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 135 */               int i2 = (i >> 6) & 14;
/* 106 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i3 = ((438 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -1182675200, "C19@1263L72,19@1360L34,19@1336L70:DecksScreen.kt#i35lj1");
/* 115 */               XunjiComponentsKt.SectionTitle("记忆花园", $state.getDecks().size() + " 个牌组 · " + $state.getCards().size() + " 张卡片", $composer, 6, 0);
                        ComposerKt.sourceInformationMarkerStart($composer, -38147818, "CC(remember):DecksScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($adding$delegate) | $composer.changed($name$delegate);
/* 136 */               Object objRememberedValue = $composer.rememberedValue();
/* 137 */               if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda21
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return DecksScreenKt.DecksScreen$lambda$18$0$0$0$0$0($adding$delegate, $name$delegate, $error$delegate);
                                }
                            };
/* 139 */                   $composer.updateRememberedValue(obj);
/* 140 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd(
                        /*  JADX ERROR: Method code generation error
                            jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x01d0: INVOKE (r4v13 ?? I:??[OBJECT, ARRAY]) STATIC call: androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(androidx.compose.runtime.Composer):void A[MD:(androidx.compose.runtime.Composer):void (m)] in method: com.xunji.flashcards.ui.screens.DecksScreenKt.DecksScreen$lambda$18$0$0(com.xunji.flashcards.ui.MainUiState, androidx.compose.runtime.MutableState, androidx.compose.runtime.MutableState, androidx.compose.runtime.MutableState, androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, int):kotlin.Unit, file: classes10.dex
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                            	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                            	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                            	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                            	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                            Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r4v13 ??
                            	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                            */
                        /*
                            Method dump skipped, instruction units count: 522
                            To view this dump change 'Code comments level' option to 'DEBUG'
                        */
                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.ui.screens.DecksScreenKt.DecksScreen$lambda$18$0$0(com.xunji.flashcards.ui.MainUiState, androidx.compose.runtime.MutableState, androidx.compose.runtime.MutableState, androidx.compose.runtime.MutableState, androidx.compose.foundation.lazy.LazyItemScope, androidx.compose.runtime.Composer, int):kotlin.Unit");
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 19 */            public static final Unit DecksScreen$lambda$18$0$0$0$0$0(MutableState $adding$delegate, MutableState $name$delegate, MutableState $error$delegate) {
/* 20 */                DecksScreen$lambda$5($adding$delegate, true);
/* 82 */                $name$delegate.setValue("");
/* 85 */                $error$delegate.setValue(null);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 21 */            public static final Unit DecksScreen$lambda$18$0$1(final MutableState $adding$delegate, final MutableState $name$delegate, final MutableState $error$delegate, LazyItemScope item, Composer $composer, int $changed) {
                        Intrinsics.checkNotNullParameter(item, "$this$item");
                        ComposerKt.sourceInformation($composer, "C21@1550L34,21@1498L87:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(1010439782, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:21)");
                            }
/* 22 */                    ComposerKt.sourceInformationMarkerStart($composer, 370023368, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChanged = $composer.changed($adding$delegate) | $composer.changed($name$delegate);
/* 146 */                   Object objRememberedValue = $composer.rememberedValue();
/* 147 */                   if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 22 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda22
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$18$0$1$0$0($adding$delegate, $name$delegate, $error$delegate);
                                    }
                                };
/* 149 */                       $composer.updateRememberedValue(obj);
/* 150 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 22 */                    XunjiComponentsKt.EmptyState("给记忆一个归处", "将相似的内容放进同一个牌组，复习时更专注。", "新建牌组", (Function0) objRememberedValue, $composer, 438, 0);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 21 */            public static final Unit DecksScreen$lambda$18$0$1$0$0(MutableState $adding$delegate, MutableState $name$delegate, MutableState $error$delegate) {
/* 22 */                DecksScreen$lambda$5($adding$delegate, true);
/* 82 */                $name$delegate.setValue("");
/* 85 */                $error$delegate.setValue(null);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 22 */            public static final Object DecksScreen$lambda$18$0$2(DeckSummary it) {
                        Intrinsics.checkNotNullParameter(it, "it");
/* 23 */                return it.getDeck().getId();
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$19$0(MutableState $busy$delegate, MutableState $adding$delegate, MutableState $editing$delegate) {
/* 35 */                if (!DecksScreen$lambda$16($busy$delegate)) {
                            DecksScreen$lambda$5($adding$delegate, false);
/* 79 */                    $editing$delegate.setValue(null);
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$20(final CoroutineScope $scope, final MutableState $adding$delegate, final MainViewModel $viewModel, final MutableState $name$delegate, final MutableState $editing$delegate, final MutableState $busy$delegate, final MutableState $error$delegate, Composer $composer, int $changed) {
                        ComposerKt.sourceInformation($composer, "C34@2801L315,34@3171L34,34@2782L423:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(864669562, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)");
                            }
/* 35 */                    boolean z = !DecksScreen$lambda$16($busy$delegate);
                            Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "save-deck");
                            ComposerKt.sourceInformationMarkerStart($composer, 2018761941, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChangedInstance = $composer.changedInstance($scope) | $composer.changed($adding$delegate) | $composer.changedInstance($viewModel) | $composer.changed($name$delegate) | $composer.changed($editing$delegate);
/* 152 */                   Object objRememberedValue = $composer.rememberedValue();
/* 153 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 35 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda18
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$20$0$0($scope, $busy$delegate, $viewModel, $adding$delegate, $name$delegate, $editing$delegate, $error$delegate);
                                    }
                                };
/* 155 */                       $composer.updateRememberedValue(obj);
/* 156 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 35 */                    ButtonKt.TextButton((Function0) objRememberedValue, modifierTestTag, z, null, null, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-1381286025, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda19
                                @Override // kotlin.jvm.functions.Function3
                                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                    return DecksScreenKt.DecksScreen$lambda$20$1($busy$delegate, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                                }
                            }, $composer, 54), $composer, 805306416, 504);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$20$0$0(CoroutineScope $scope, MutableState $busy$delegate, MainViewModel $viewModel, MutableState $adding$delegate, MutableState $name$delegate, MutableState $editing$delegate, MutableState $error$delegate) {
/* 35 */                if (!DecksScreen$lambda$16($busy$delegate)) {
                            DecksScreen$lambda$17($busy$delegate, true);
/* 1 */                     BuildersKt__Builders_commonKt.launch$default($scope, null, null, new DecksScreenKt$DecksScreen$3$1$1$1($viewModel, $adding$delegate, $name$delegate, $editing$delegate, $error$delegate, $busy$delegate, null), 3, null);
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$20$1(MutableState $busy$delegate, RowScope TextButton, Composer $composer, int $changed) {
                        Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                        ComposerKt.sourceInformation($composer, "C34@3173L30:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-1381286025, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous> (DecksScreen.kt:34)");
                            }
/* 35 */                    TextKt.m3584TextNvy7gAk(DecksScreen$lambda$16($busy$delegate) ? "保存中…" : "保存", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$21(final MutableState $adding$delegate, final MutableState $editing$delegate, MutableState $busy$delegate, Composer $composer, int $changed) {
                        ComposerKt.sourceInformation($composer, "C34@3235L27,34@3224L68:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(708689020, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)");
                            }
/* 35 */                    ComposerKt.sourceInformationMarkerStart($composer, -1849651401, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChanged = $composer.changed($adding$delegate) | $composer.changed($editing$delegate);
/* 152 */                   Object objRememberedValue = $composer.rememberedValue();
/* 153 */                   if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 35 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda11
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$21$0$0($adding$delegate, $editing$delegate);
                                    }
                                };
/* 155 */                       $composer.updateRememberedValue(obj);
/* 156 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 35 */                    ButtonKt.TextButton((Function0) objRememberedValue, null, true ^ DecksScreen$lambda$16($busy$delegate), null, null, null, null, null, null, ComposableSingletons$DecksScreenKt.INSTANCE.m8994getLambda$1537266567$app_debug(), $composer, 805306368, 506);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$21$0$0(MutableState $adding$delegate, MutableState $editing$delegate) {
/* 35 */                DecksScreen$lambda$5($adding$delegate, false);
/* 79 */                $editing$delegate.setValue(null);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$22(MutableState $adding$delegate, Composer $composer, int $changed) {
                        ComposerKt.sourceInformation($composer, "C34@2513L35:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(552708478, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)");
                            }
/* 35 */                    TextKt.m3584TextNvy7gAk(DecksScreen$lambda$4($adding$delegate) ? "新建牌组" : "重命名牌组", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    /* JADX WARN: Code duplicated, block: B:28:0x014b  */
                    /* JADX WARN: Code duplicated, block: B:29:0x014e  */
                    /* JADX WARN: Code duplicated, block: B:32:0x0179  */
                    /* JADX WARN: Code duplicated, block: B:35:0x0184  */
                    /* JADX WARN: Code duplicated, block: B:36:0x0187  */
                    /* JADX WARN: Code duplicated, block: B:40:0x01df  */
                    /* JADX WARN: Code duplicated, block: B:41:0x01fc  */
                    /* JADX WARN: Code duplicated, block: B:44:0x0223  */
/* 34 */            public static final Unit DecksScreen$lambda$23(final MutableState $name$delegate, MutableState $error$delegate, MutableState $busy$delegate, Composer $composer, int $changed) {
                        Function0<ComposeUiNode> function0;
                        Composer composer;
                        int i;
                        Composer composer2;
                        boolean z;
                        boolean zChanged;
                        Object objRememberedValue;
                        Composer composer3;
                        final MutableState mutableState;
                        Composer composer4;
                        ComposerKt.sourceInformation($composer, "C34@2558L205:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(474718207, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)");
                            }
/* 35 */                    ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 159 */                   Modifier modifier = Modifier.INSTANCE;
/* 35 */                    MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
/* 35 */                    ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 170 */                   int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 171 */                   CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 172 */                   Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 174 */                   Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 168 */                   int i2 = ((((0 << 3) & 112) << 6) & 896) | 6;
/* 35 */                    ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 176 */                   if (!($composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 177 */                   $composer.startReusableNode();
/* 178 */                   if ($composer.getInserting()) {
/* 179 */                       function0 = constructor;
/* 35 */                        $composer.createNode(function0);
                            } else {
/* 181 */                       function0 = constructor;
/* 35 */                        $composer.useNode();
                            }
/* 183 */                   Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 184 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 185 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 186 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 188 */                   if (composerM4979constructorimpl.getInserting()) {
/* 35 */                        composer = $composer;
                                i = 0;
                            } else {
/* 35 */                        composer = $composer;
                                i = 0;
/* 187 */                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                }
/* 193 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 195 */                       int i3 = (i2 >> 6) & 14;
                                composer2 = composer;
/* 166 */                       ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                int i4 = ((i >> 6) & 112) | 6;
                                ComposerKt.sourceInformationMarkerStart(composer2, -187397076, "C34@2590L22,34@2567L158:DecksScreen.kt#i35lj1");
                                String strDecksScreen$lambda$10 = DecksScreen$lambda$10($name$delegate);
                                if (DecksScreen$lambda$13($error$delegate) != null) {
                                    z = true;
                                } else {
                                    z = false;
                                }
                                boolean z2 = !DecksScreen$lambda$16($busy$delegate);
                                Modifier modifierTestTag = TestTagKt.testTag(Modifier.INSTANCE, "deck-name");
                                ComposerKt.sourceInformationMarkerStart(composer2, -2084254485, "CC(remember):DecksScreen.kt#9igjgp");
                                zChanged = composer2.changed($name$delegate);
                                objRememberedValue = composer2.rememberedValue();
/* 153 */                       if (zChanged) {
/* 153 */                           composer3 = composer2;
                                } else {
                                    composer3 = composer2;
                                    if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 157 */                               mutableState = $error$delegate;
                                    }
                                    ComposerKt.sourceInformationMarkerEnd(composer3);
/* 35 */                            OutlinedTextFieldKt.OutlinedTextField(strDecksScreen$lambda$10, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag, z2, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DecksScreenKt.INSTANCE.m8996getLambda$2114441585$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, z, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, (TextFieldColors) null, composer3, 1573248, 12582912, 0, 8249264);
                                    composer4 = composer3;
                                    if (DecksScreen$lambda$13(mutableState) != null) {
                                        composer4.startReplaceGroup(-2084249655);
                                        ComposerKt.sourceInformation(composer4, "34@2741L20");
                                        String strDecksScreen$lambda$13 = DecksScreen$lambda$13(mutableState);
                                        Intrinsics.checkNotNull(strDecksScreen$lambda$13);
                                        XunjiComponentsKt.Notice(strDecksScreen$lambda$13, true, composer4, 48, 0);
                                    } else {
                                        composer4.startReplaceGroup(-189950547);
                                    }
                                    composer4.endReplaceGroup();
                                    ComposerKt.sourceInformationMarkerEnd(composer4);
/* 166 */                           ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */                           composer.endNode();
/* 175 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 169 */                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 158 */                           ComposerKt.sourceInformationMarkerEnd(composer);
                                    if (ComposerKt.isTraceInProgress()) {
                                        ComposerKt.traceEventEnd();
                                    }
                                }
                                mutableState = $error$delegate;
                                objRememberedValue = new Function1() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda23
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj) {
                                        return DecksScreenKt.DecksScreen$lambda$23$0$0$0($name$delegate, mutableState, (String) obj);
                                    }
                                };
/* 155 */                       composer2.updateRememberedValue(objRememberedValue);
                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 35 */                        OutlinedTextFieldKt.OutlinedTextField(strDecksScreen$lambda$10, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag, z2, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DecksScreenKt.INSTANCE.m8996getLambda$2114441585$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, z, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, (TextFieldColors) null, composer3, 1573248, 12582912, 0, 8249264);
                                composer4 = composer3;
                                if (DecksScreen$lambda$13(mutableState) != null) {
                                    composer4.startReplaceGroup(-2084249655);
                                    ComposerKt.sourceInformation(composer4, "34@2741L20");
                                    String strDecksScreen$lambda$14 = DecksScreen$lambda$13(mutableState);
                                    Intrinsics.checkNotNull(strDecksScreen$lambda$14);
                                    XunjiComponentsKt.Notice(strDecksScreen$lambda$14, true, composer4, 48, 0);
                                } else {
                                    composer4.startReplaceGroup(-189950547);
                                }
                                composer4.endReplaceGroup();
                                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 166 */                       ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */                       composer.endNode();
/* 175 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 169 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 158 */                       ComposerKt.sourceInformationMarkerEnd(composer);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                            }
/* 187 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 190 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 193 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 195 */                   int i5 = (i2 >> 6) & 14;
                            composer2 = composer;
/* 166 */                   ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                            int i6 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer2, -187397076, "C34@2590L22,34@2567L158:DecksScreen.kt#i35lj1");
                            String strDecksScreen$lambda$11 = DecksScreen$lambda$10($name$delegate);
                            if (DecksScreen$lambda$13($error$delegate) != null) {
                                z = true;
                            } else {
                                z = false;
                            }
                            boolean z3 = !DecksScreen$lambda$16($busy$delegate);
                            Modifier modifierTestTag2 = TestTagKt.testTag(Modifier.INSTANCE, "deck-name");
                            ComposerKt.sourceInformationMarkerStart(composer2, -2084254485, "CC(remember):DecksScreen.kt#9igjgp");
                            zChanged = composer2.changed($name$delegate);
                            objRememberedValue = composer2.rememberedValue();
/* 153 */                   if (zChanged) {
                                composer3 = composer2;
                                if (objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 157 */                           mutableState = $error$delegate;
                                }
                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 35 */                        OutlinedTextFieldKt.OutlinedTextField(strDecksScreen$lambda$11, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag2, z3, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DecksScreenKt.INSTANCE.m8996getLambda$2114441585$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, z, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, (TextFieldColors) null, composer3, 1573248, 12582912, 0, 8249264);
                                composer4 = composer3;
                                if (DecksScreen$lambda$13(mutableState) != null) {
                                    composer4.startReplaceGroup(-2084249655);
                                    ComposerKt.sourceInformation(composer4, "34@2741L20");
                                    String strDecksScreen$lambda$15 = DecksScreen$lambda$13(mutableState);
                                    Intrinsics.checkNotNull(strDecksScreen$lambda$15);
                                    XunjiComponentsKt.Notice(strDecksScreen$lambda$15, true, composer4, 48, 0);
                                } else {
                                    composer4.startReplaceGroup(-189950547);
                                }
                                composer4.endReplaceGroup();
                                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 166 */                       ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */                       composer.endNode();
/* 175 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 169 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 158 */                       ComposerKt.sourceInformationMarkerEnd(composer);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                            } else {
/* 153 */                       composer3 = composer2;
                            }
                            mutableState = $error$delegate;
                            objRememberedValue = new Function1() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda23
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj) {
                                    return DecksScreenKt.DecksScreen$lambda$23$0$0$0($name$delegate, mutableState, (String) obj);
                                }
                            };
/* 155 */                   composer2.updateRememberedValue(objRememberedValue);
                            ComposerKt.sourceInformationMarkerEnd(composer3);
/* 35 */                    OutlinedTextFieldKt.OutlinedTextField(strDecksScreen$lambda$11, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag2, z3, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$DecksScreenKt.INSTANCE.m8996getLambda$2114441585$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, z, (VisualTransformation) null, (KeyboardOptions) null, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) null, (TextFieldColors) null, composer3, 1573248, 12582912, 0, 8249264);
                            composer4 = composer3;
                            if (DecksScreen$lambda$13(mutableState) != null) {
                                composer4.startReplaceGroup(-2084249655);
                                ComposerKt.sourceInformation(composer4, "34@2741L20");
                                String strDecksScreen$lambda$16 = DecksScreen$lambda$13(mutableState);
                                Intrinsics.checkNotNull(strDecksScreen$lambda$16);
                                XunjiComponentsKt.Notice(strDecksScreen$lambda$16, true, composer4, 48, 0);
                            } else {
                                composer4.startReplaceGroup(-189950547);
                            }
                            composer4.endReplaceGroup();
                            ComposerKt.sourceInformationMarkerEnd(composer4);
/* 166 */                   ComposerKt.sourceInformationMarkerEnd(composer2);
/* 196 */                   composer.endNode();
/* 175 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 169 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 158 */                   ComposerKt.sourceInformationMarkerEnd(composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
/* 35 */                    $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 34 */            public static final Unit DecksScreen$lambda$23$0$0$0(MutableState $name$delegate, MutableState $error$delegate, String it) {
                        Intrinsics.checkNotNullParameter(it, "it");
/* 82 */                $name$delegate.setValue(it);
/* 85 */                $error$delegate.setValue(null);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 35 */            public static final Unit DecksScreen$lambda$24$0(MutableState $busy$delegate, MutableState $deleting$delegate) {
/* 36 */                if (!DecksScreen$lambda$16($busy$delegate)) {
/* 79 */                    $deleting$delegate.setValue(null);
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 35 */            public static final Unit DecksScreen$lambda$25(final CoroutineScope $scope, final MainViewModel $viewModel, final MutableState $deleting$delegate, final MutableState $busy$delegate, final MutableState $error$delegate, Composer $composer, int $changed) {
                        ComposerKt.sourceInformation($composer, "C35@3503L195,35@3492L276:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-1876995677, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)");
                            }
/* 36 */                    ComposerKt.sourceInformationMarkerStart($composer, 93419334, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChangedInstance = $composer.changedInstance($scope) | $composer.changedInstance($viewModel) | $composer.changed($deleting$delegate);
/* 200 */                   Object objRememberedValue = $composer.rememberedValue();
/* 201 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 36 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$25$0$0($scope, $busy$delegate, $viewModel, $deleting$delegate, $error$delegate);
                                    }
                                };
/* 203 */                       $composer.updateRememberedValue(obj);
/* 204 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 36 */                    ButtonKt.TextButton((Function0) objRememberedValue, null, true ^ DecksScreen$lambda$16($busy$delegate), null, null, null, null, null, null, ComposableSingletons$DecksScreenKt.INSTANCE.getLambda$128235104$app_debug(), $composer, 805306368, 506);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 35 */            public static final Unit DecksScreen$lambda$25$0$0(CoroutineScope $scope, MutableState $busy$delegate, MainViewModel $viewModel, MutableState $deleting$delegate, MutableState $error$delegate) {
/* 36 */                if (!DecksScreen$lambda$16($busy$delegate)) {
                            DecksScreen$lambda$17($busy$delegate, true);
/* 1 */                     BuildersKt__Builders_commonKt.launch$default($scope, null, null, new DecksScreenKt$DecksScreen$8$1$1$1($viewModel, $deleting$delegate, $error$delegate, $busy$delegate, null), 3, null);
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 35 */            public static final Unit DecksScreen$lambda$26(final MutableState $deleting$delegate, MutableState $busy$delegate, Composer $composer, int $changed) {
                        ComposerKt.sourceInformation($composer, "C35@3798L15,35@3787L56:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-1450441179, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)");
                            }
/* 36 */                    ComposerKt.sourceInformationMarkerStart($composer, 1990398612, "CC(remember):DecksScreen.kt#9igjgp");
                            boolean zChanged = $composer.changed($deleting$delegate);
/* 200 */                   Object objRememberedValue = $composer.rememberedValue();
/* 201 */                   if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 36 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.DecksScreenKt$$ExternalSyntheticLambda20
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return DecksScreenKt.DecksScreen$lambda$26$0$0($deleting$delegate);
                                    }
                                };
/* 203 */                       $composer.updateRememberedValue(obj);
/* 204 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 36 */                    ButtonKt.TextButton((Function0) objRememberedValue, null, true ^ DecksScreen$lambda$16($busy$delegate), null, null, null, null, null, null, ComposableSingletons$DecksScreenKt.INSTANCE.getLambda$554789602$app_debug(), $composer, 805306368, 506);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
/* 35 */            public static final Unit DecksScreen$lambda$26$0$0(MutableState $deleting$delegate) {
/* 79 */                $deleting$delegate.setValue(null);
                        return Unit.INSTANCE;
                    }

                    /* JADX INFO: Access modifiers changed from: private */
                    /* JADX WARN: Code duplicated, block: B:28:0x016f  */
                    /* JADX WARN: Code duplicated, block: B:29:0x018d  */
                    /* JADX WARN: Code duplicated, block: B:32:0x01b6  */
/* 35 */            public static final Unit DecksScreen$lambda$27(MutableState $error$delegate, Composer $composer, int $changed) {
                        Function0<ComposeUiNode> function0;
                        Composer composer;
                        int i;
                        Composer composer2;
                        ComposerKt.sourceInformation($composer, "C35@3400L73:DecksScreen.kt#i35lj1");
                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(1336874216, $changed, -1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)");
                            }
/* 36 */                    ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 207 */                   Modifier modifier = Modifier.INSTANCE;
/* 36 */                    MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
/* 36 */                    ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 218 */                   int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 219 */                   CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 220 */                   Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 222 */                   Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 216 */                   int i2 = ((((0 << 3) & 112) << 6) & 896) | 6;
/* 36 */                    ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 224 */                   if (!($composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 225 */                   $composer.startReusableNode();
/* 226 */                   if ($composer.getInserting()) {
/* 227 */                       function0 = constructor;
/* 36 */                        $composer.createNode(function0);
                            } else {
/* 229 */                       function0 = constructor;
/* 36 */                        $composer.useNode();
                            }
/* 231 */                   Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 232 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 233 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 234 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 236 */                   if (!composerM4979constructorimpl.getInserting()) {
/* 36 */                        composer = $composer;
                                i = 0;
/* 235 */                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                }
/* 241 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 243 */                       int i3 = (i2 >> 6) & 14;
                                composer2 = composer;
/* 214 */                       ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                int i4 = ((i >> 6) & 112) | 6;
                                ComposerKt.sourceInformationMarkerStart(composer2, 412829735, "C35@3409L26:DecksScreen.kt#i35lj1");
                                TextKt.m3584TextNvy7gAk("将删除全部卡片和学习记录，无法撤回。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer2, 6, 0, 262142);
                                if (DecksScreen$lambda$13($error$delegate) != null) {
                                    composer2.startReplaceGroup(-125228942);
                                    ComposerKt.sourceInformation(composer2, "35@3451L20");
                                    String strDecksScreen$lambda$13 = DecksScreen$lambda$13($error$delegate);
                                    Intrinsics.checkNotNull(strDecksScreen$lambda$13);
                                    XunjiComponentsKt.Notice(strDecksScreen$lambda$13, true, composer2, 48, 0);
                                } else {
                                    composer2.startReplaceGroup(409445092);
                                }
                                composer2.endReplaceGroup();
                                ComposerKt.sourceInformationMarkerEnd(composer2);
/* 214 */                       ComposerKt.sourceInformationMarkerEnd(composer2);
/* 244 */                       composer.endNode();
/* 223 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 217 */                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 206 */                       ComposerKt.sourceInformationMarkerEnd(composer);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                            } else {
/* 36 */                        composer = $composer;
                                i = 0;
                            }
/* 235 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 238 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 241 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 243 */                   int i5 = (i2 >> 6) & 14;
                            composer2 = composer;
/* 214 */                   ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                            int i6 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer2, 412829735, "C35@3409L26:DecksScreen.kt#i35lj1");
                            TextKt.m3584TextNvy7gAk("将删除全部卡片和学习记录，无法撤回。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, composer2, 6, 0, 262142);
                            if (DecksScreen$lambda$13($error$delegate) != null) {
                                composer2.startReplaceGroup(-125228942);
                                ComposerKt.sourceInformation(composer2, "35@3451L20");
                                String strDecksScreen$lambda$14 = DecksScreen$lambda$13($error$delegate);
                                Intrinsics.checkNotNull(strDecksScreen$lambda$14);
                                XunjiComponentsKt.Notice(strDecksScreen$lambda$14, true, composer2, 48, 0);
                            } else {
                                composer2.startReplaceGroup(409445092);
                            }
                            composer2.endReplaceGroup();
                            ComposerKt.sourceInformationMarkerEnd(composer2);
/* 214 */                   ComposerKt.sourceInformationMarkerEnd(composer2);
/* 244 */                   composer.endNode();
/* 223 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 217 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 206 */                   ComposerKt.sourceInformationMarkerEnd(composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
/* 36 */                    $composer.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }
                }

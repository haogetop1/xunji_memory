            package com.xunji.flashcards.ui.screens;

            import com.xunji.flashcards.anki.CardMedia;
            import kotlin.Metadata;
            import kotlin.ResultKt;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.coroutines.intrinsics.IntrinsicsKt;
            import kotlin.coroutines.jvm.internal.DebugMetadata;
            import kotlin.coroutines.jvm.internal.SuspendLambda;
            import kotlin.jvm.functions.Function2;
            
            /* JADX INFO: compiled from: ReviewScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\f\n\u0000\n\u0002\u0010\u0001\n\u0000\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\n"}, d2 = {"<anonymous>", "", "it", "Lcom/xunji/flashcards/anki/CardMedia;"}, k = 3, mv = {2, 2, 0}, xi = 48)
            @DebugMetadata(c = "com.xunji.flashcards.ui.screens.ReviewScreenKt$ReviewScreen$1$1", f = "ReviewScreen.kt", i = {}, l = {}, m = "invokeSuspend", n = {}, s = {}, v = 1)
/* 19 */    final class ReviewScreenKt$ReviewScreen$1$1 extends SuspendLambda implements Function2<CardMedia, Continuation, Object> {
                int label;

                ReviewScreenKt$ReviewScreen$1$1(Continuation<? super ReviewScreenKt$ReviewScreen$1$1> continuation) {
                    super(2, continuation);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                public final Continuation<Unit> create(Object obj, Continuation<?> continuation) {
                    return new ReviewScreenKt$ReviewScreen$1$1(continuation);
                }

                @Override // kotlin.jvm.functions.Function2
                public final Object invoke(CardMedia cardMedia, Continuation continuation) {
                    return ((ReviewScreenKt$ReviewScreen$1$1) create(cardMedia, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
/* 20 */        public final Object invokeSuspend(Object $result) throws Throwable {
                    IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    switch (this.label) {
                        case 0:
                            ResultKt.throwOnFailure($result);
                            return null;
                        default:
                            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                }
            }

            package com.xunji.flashcards.ui.screens;

            import androidx.compose.animation.AnimatedVisibilityKt;
            import androidx.compose.animation.AnimatedVisibilityScope;
            import androidx.compose.animation.EnterExitTransitionKt;
            import androidx.compose.animation.core.AnimationSpecKt;
            import androidx.compose.foundation.BorderStroke;
            import androidx.compose.foundation.BorderStrokeKt;
            import androidx.compose.foundation.ScrollKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.BoxScopeInstance;
            import androidx.compose.foundation.layout.BoxWithConstraintsKt;
            import androidx.compose.foundation.layout.BoxWithConstraintsScope;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.FlowLayoutKt;
            import androidx.compose.foundation.layout.FlowRowScope;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.SpacerKt;
            import androidx.compose.foundation.shape.RoundedCornerShape;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.material3.ButtonColors;
            import androidx.compose.material3.ButtonDefaults;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.DividerKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.SurfaceKt;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.ProvidableCompositionLocal;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.CompositionLocalsKt;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.text.TextStyle;
            import androidx.compose.ui.text.font.FontFamily;
            import androidx.compose.ui.unit.Density;
            import androidx.compose.ui.unit.Dp;
            import androidx.compose.ui.unit.TextUnitKt;
            import com.xunji.core.model.CardCandidate;
            import com.xunji.core.model.CardSchedule;
            import com.xunji.core.model.Rating;
            import com.xunji.flashcards.anki.CardMedia;
            import com.xunji.flashcards.anki.RenderedCard;
            import com.xunji.flashcards.ui.ReviewUiState;
            import com.xunji.flashcards.ui.components.AnkiCardContentKt;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.io.InputStream;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Pair;
            import kotlin.TuplesKt;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.collections.MapsKt;
            import kotlin.coroutines.Continuation;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.text.StringsKt;
            
            /* JADX INFO: compiled from: ReviewScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0091\u0001\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00010\t2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\r\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072&\b\u0002\u0010\u000e\u001a \b\u0001\u0012\u0004\u0012\u00020\u0010\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u000fH\u0007¢\u0006\u0002\u0010\u0014\u001a1\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00052\u0012\u0010\b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00010\tH\u0003¢\u0006\u0002\u0010\u0019¨\u0006\u001a"}, d2 = {"ReviewScreen", "", "state", "Lcom/xunji/flashcards/ui/ReviewUiState;", "canUndo", "", "onReveal", "Lkotlin/Function0;", "onGrade", "Lkotlin/Function1;", "Lcom/xunji/core/model/Rating;", "onUndo", "onRefresh", "onExit", "openMedia", "Lkotlin/Function2;", "Lcom/xunji/flashcards/anki/CardMedia;", "Lkotlin/coroutines/Continuation;", "Ljava/io/InputStream;", "", "(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "RatingGrid", "answer", "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;", "submitting", "(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 19 */    public final class ReviewScreenKt {

                /* JADX INFO: compiled from: ReviewScreen.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[Rating.values().length];
                        try {
                            iArr[Rating.AGAIN.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[Rating.HARD.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[Rating.GOOD.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        try {
                            iArr[Rating.EASY.ordinal()] = 4;
                        } catch (NoSuchFieldError e4) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit RatingGrid$lambda$1(ReviewUiState.Answer answer, boolean z, Function1 function1, int i, Composer composer, int i2) {
                    RatingGrid(answer, z, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit ReviewScreen$lambda$2(ReviewUiState reviewUiState, boolean z, Function0 function0, Function1 function1, Function0 function2, Function0 function3, Function0 function4, Function2 function5, int i, int i2, Composer composer, int i3) {
                    ReviewScreen(reviewUiState, z, function0, function1, function2, function3, function4, function5, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:102:0x0232  */
                /* JADX WARN: Code duplicated, block: B:103:0x0235  */
                /* JADX WARN: Code duplicated, block: B:107:0x0316  */
                /* JADX WARN: Code duplicated, block: B:110:0x0322  */
                /* JADX WARN: Code duplicated, block: B:111:0x0326  */
                /* JADX WARN: Code duplicated, block: B:114:0x0355  */
                /* JADX WARN: Code duplicated, block: B:118:0x036b A[ADDED_TO_REGION] */
                /* JADX WARN: Code duplicated, block: B:122:0x043b  */
                /* JADX WARN: Code duplicated, block: B:123:0x047e  */
                /* JADX WARN: Code duplicated, block: B:126:0x04ad  */
                /* JADX WARN: Code duplicated, block: B:127:0x04cd  */
                /* JADX WARN: Code duplicated, block: B:129:0x04d1  */
                /* JADX WARN: Code duplicated, block: B:131:0x053d  */
                /* JADX WARN: Code duplicated, block: B:134:0x0549  */
                /* JADX WARN: Code duplicated, block: B:135:0x054d  */
                /* JADX WARN: Code duplicated, block: B:138:0x057b  */
                /* JADX WARN: Code duplicated, block: B:142:0x0591 A[ADDED_TO_REGION] */
                /* JADX WARN: Code duplicated, block: B:145:0x0629  */
                /* JADX WARN: Code duplicated, block: B:147:0x062d  */
                /* JADX WARN: Code duplicated, block: B:149:0x06d2  */
                /* JADX WARN: Code duplicated, block: B:152:0x06de  */
                /* JADX WARN: Code duplicated, block: B:153:0x06e2  */
                /* JADX WARN: Code duplicated, block: B:156:0x070f  */
                /* JADX WARN: Code duplicated, block: B:160:0x0721  */
                /* JADX WARN: Code duplicated, block: B:163:0x07f3  */
                /* JADX WARN: Code duplicated, block: B:166:0x07ff  */
                /* JADX WARN: Code duplicated, block: B:167:0x0805  */
                /* JADX WARN: Code duplicated, block: B:170:0x0836  */
                /* JADX WARN: Code duplicated, block: B:174:0x084c A[ADDED_TO_REGION] */
                /* JADX WARN: Code duplicated, block: B:178:0x08d5  */
                /* JADX WARN: Code duplicated, block: B:179:0x08d8  */
                /* JADX WARN: Code duplicated, block: B:182:0x08e3  */
                /* JADX WARN: Code duplicated, block: B:183:0x090c  */
                /* JADX WARN: Code duplicated, block: B:185:0x09d0  */
                /* JADX WARN: Code duplicated, block: B:187:0x09ea  */
                /* JADX WARN: Code duplicated, block: B:188:0x09ee  */
                /* JADX WARN: Code duplicated, block: B:190:0x09f2  */
                /* JADX WARN: Code duplicated, block: B:191:0x09fa  */
                /* JADX WARN: Code duplicated, block: B:193:0x09fd  */
                /* JADX WARN: Code duplicated, block: B:195:0x0a03  */
                /* JADX WARN: Code duplicated, block: B:198:0x0aa8  */
                /* JADX WARN: Code duplicated, block: B:201:0x0ab4  */
                /* JADX WARN: Code duplicated, block: B:202:0x0ab8  */
                /* JADX WARN: Code duplicated, block: B:205:0x0ae6  */
                /* JADX WARN: Code duplicated, block: B:208:0x0af9  */
                /* JADX WARN: Code duplicated, block: B:209:0x0afc  */
                /* JADX WARN: Code duplicated, block: B:213:0x0b9c  */
                /* JADX WARN: Code duplicated, block: B:215:0x0ba2  */
                /* JADX WARN: Code duplicated, block: B:217:0x0ba6  */
                /* JADX WARN: Code duplicated, block: B:218:0x0baa  */
                /* JADX WARN: Code duplicated, block: B:220:0x0bad  */
                /* JADX WARN: Code duplicated, block: B:221:0x0bb2  */
                /* JADX WARN: Code duplicated, block: B:224:0x0c4a  */
                /* JADX WARN: Code duplicated, block: B:225:0x0c82  */
                /* JADX WARN: Code duplicated, block: B:227:0x0ca0  */
                /* JADX WARN: Code duplicated, block: B:228:0x0cb6  */
                /* JADX WARN: Code duplicated, block: B:231:0x0cc6  */
                /* JADX WARN: Code duplicated, block: B:233:0x0cd3  */
                /* JADX WARN: Code duplicated, block: B:234:0x0cd6  */
                /* JADX WARN: Code duplicated, block: B:237:0x0ce8  */
                /* JADX WARN: Code duplicated, block: B:238:0x0cea  */
                /* JADX WARN: Code duplicated, block: B:241:0x0cfb  */
                /* JADX WARN: Code duplicated, block: B:245:0x0d0b  */
                /* JADX WARN: Code duplicated, block: B:247:0x0d37  */
                /* JADX WARN: Code duplicated, block: B:252:0x0d91  */
                /* JADX WARN: Code duplicated, block: B:89:0x014e  */
                /* JADX WARN: Code duplicated, block: B:92:0x01de  */
                /* JADX WARN: Code duplicated, block: B:95:0x01ea  */
                /* JADX WARN: Code duplicated, block: B:96:0x01f0  */
                /* JADX WARN: Code duplicated, block: B:99:0x0221  */
/* 20 */        public static final void ReviewScreen(final ReviewUiState state, final boolean canUndo, final Function0<Unit> onReveal, Function1<? super Rating, Unit> onGrade, final Function0<Unit> onUndo, final Function0<Unit> onRefresh, final Function0<Unit> onExit, Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function2, Composer $composer, final int $changed, final int i) {
                    Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function3;
                    final Function1<? super Rating, Unit> function1;
                    Composer $composer2;
                    final Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function4;
                    Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function5;
                    int $dirty;
                    boolean submitting;
                    Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function6;
                    int iHashCode;
                    int $dirty2;
                    Function0<ComposeUiNode> constructor;
                    Function0<ComposeUiNode> function0;
                    Composer composerM4979constructorimpl;
                    boolean submitting2;
                    int iHashCode2;
                    Function0<ComposeUiNode> constructor2;
                    Composer composerM4979constructorimpl2;
                    Composer composer;
                    Composer $composer3;
                    final ReviewUiState.Answer answer;
                    final CardCandidate candidate;
                    int iHashCode3;
                    Function0<ComposeUiNode> constructor3;
                    Composer composerM4979constructorimpl3;
                    Composer composer2;
                    int i2;
                    ReviewUiState.Question question;
                    RenderedCard rendered;
                    final ReviewUiState.Answer answer2;
                    final Function2<? super CardMedia, ? super Continuation<? super InputStream>, ? extends Object> function7;
                    final boolean submitting3;
                    Composer composer3;
                    boolean z;
                    String str;
                    boolean z2;
                    boolean zChangedInstance;
                    Object objRememberedValue;
                    int iHashCode4;
                    Function0<ComposeUiNode> constructor4;
                    Composer composerM4979constructorimpl4;
                    Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash;
                    int iHashCode5;
                    Function0<ComposeUiNode> constructor5;
                    Function0<ComposeUiNode> function8;
                    Composer composerM4979constructorimpl5;
                    String str2;
                    String str3;
                    int iHashCode6;
                    Function0<ComposeUiNode> constructor6;
                    Composer composerM4979constructorimpl6;
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(onReveal, "onReveal");
                    Intrinsics.checkNotNullParameter(onGrade, "onGrade");
                    Intrinsics.checkNotNullParameter(onUndo, "onUndo");
                    Intrinsics.checkNotNullParameter(onRefresh, "onRefresh");
                    Intrinsics.checkNotNullParameter(onExit, "onExit");
/* 21 */            Composer $composer4 = $composer.startRestartGroup(-1825906056);
                    ComposerKt.sourceInformation($composer4, "C(ReviewScreen)N(state,canUndo,onReveal,onGrade,onUndo,onRefresh,onExit,openMedia)22@959L4058:ReviewScreen.kt#i35lj1");
                    int $dirty3 = $changed;
                    if (($changed & 6) == 0) {
                        $dirty3 |= ($changed & 8) == 0 ? $composer4.changed(state) : $composer4.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty3 |= $composer4.changed(canUndo) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty3 |= $composer4.changedInstance(onReveal) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        $dirty3 |= $composer4.changedInstance(onGrade) ? 2048 : 1024;
                    }
                    if (($changed & 24576) == 0) {
                        $dirty3 |= $composer4.changedInstance(onUndo) ? 16384 : 8192;
                    }
                    if ((196608 & $changed) == 0) {
                        $dirty3 |= $composer4.changedInstance(onRefresh) ? 131072 : 65536;
                    }
                    if ((1572864 & $changed) == 0) {
                        $dirty3 |= $composer4.changedInstance(onExit) ? 1048576 : 524288;
                    }
                    if ((12582912 & $changed) == 0) {
                        if ((i & 128) == 0) {
                            function3 = function2;
                            int i3 = $composer4.changedInstance(function3) ? 8388608 : 4194304;
                            $dirty3 |= i3;
                        } else {
                            function3 = function2;
                        }
                        $dirty3 |= i3;
                    } else {
                        function3 = function2;
                    }
                    if ($composer4.shouldExecute((4793491 & $dirty3) != 4793490, $dirty3 & 1)) {
                        $composer4.startDefaults();
                        ComposerKt.sourceInformation($composer4, "20@898L6");
                        if (($changed & 1) == 0 || $composer4.getDefaultsInvalid()) {
                            if ((i & 128) != 0) {
                                ComposerKt.sourceInformationMarkerStart($composer4, 1945910302, "CC(remember):ReviewScreen.kt#9igjgp");
/* 93 */                        Object objRememberedValue2 = $composer4.rememberedValue();
/* 94 */                        if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 21 */                            Object obj = (Function2) new ReviewScreenKt$ReviewScreen$1$1(null);
/* 96 */                            $composer4.updateRememberedValue(obj);
/* 97 */                            objRememberedValue2 = obj;
                                }
/* 21 */                        function5 = (Function2) objRememberedValue2;
                                ComposerKt.sourceInformationMarkerEnd($composer4);
                                $dirty = $dirty3 & (-29360129);
                            }
                            $composer4.endDefaults();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventStart(-1825906056, $dirty, -1, "com.xunji.flashcards.ui.screens.ReviewScreen (ReviewScreen.kt:20)");
                            }
/* 22 */                    submitting = state instanceof ReviewUiState.Submitting;
/* 23 */                    Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 99 */                    ComposerKt.sourceInformationMarkerStart($composer4, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 104 */                   MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer4, ((6 >> 3) & 14) | ((6 >> 3) & 112));
                            function6 = function5;
                            ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 110 */                   iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 111 */                   CompositionLocalMap currentCompositionLocalMap = $composer4.getCurrentCompositionLocalMap();
                            $dirty2 = $dirty;
/* 112 */                   Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer4, modifierFillMaxSize$default);
/* 114 */                   constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 105 */                   int i4 = ((((6 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 116 */                   if (!($composer4.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 117 */                   $composer4.startReusableNode();
/* 118 */                   if ($composer4.getInserting()) {
/* 119 */                       function0 = constructor;
                                $composer4.createNode(function0);
                            } else {
/* 121 */                       function0 = constructor;
                                $composer4.useNode();
                            }
                            composerM4979constructorimpl = Updater.m4979constructorimpl($composer4);
/* 124 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 125 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 126 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 128 */                   if (composerM4979constructorimpl.getInserting()) {
                                submitting2 = submitting;
                            } else {
                                submitting2 = submitting;
/* 127 */                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                }
/* 133 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 135 */                       int i5 = (i4 >> 6) & 14;
/* 106 */                       ComposerKt.sourceInformationMarkerStart($composer4, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                int i6 = ((6 >> 6) & 112) | 6;
/* 24 */                        ComposerKt.sourceInformationMarkerStart($composer4, 1003414049, "C23@994L358:ReviewScreen.kt#i35lj1");
/* 24 */                        Modifier modifierM841paddingVpY3zN4 = PaddingKt.m841paddingVpY3zN4(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(10), Dp.m8404constructorimpl(6));
                                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 137 */                       ComposerKt.sourceInformationMarkerStart($composer4, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 142 */                       MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(Arrangement.INSTANCE.getStart(), centerVertically, $composer4, ((390 >> 3) & 14) | ((390 >> 3) & 112));
                                ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 148 */                       iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 149 */                       CompositionLocalMap currentCompositionLocalMap2 = $composer4.getCurrentCompositionLocalMap();
/* 143 */                       Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer4, modifierM841paddingVpY3zN4);
/* 152 */                       constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 146 */                       int i7 = ((((390 << 3) & 112) << 6) & 896) | 6;
/* 153 */                       ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 154 */                       if (!($composer4.getApplier() instanceof Applier)) {
                                    ComposablesKt.invalidApplier();
                                }
/* 155 */                       $composer4.startReusableNode();
/* 156 */                       if ($composer4.getInserting()) {
/* 157 */                           $composer4.createNode(constructor2);
                                } else {
/* 159 */                           $composer4.useNode();
                                }
/* 161 */                       composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer4);
/* 162 */                       Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 163 */                       Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 164 */                       Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 166 */                       if (!composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 165 */                           composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 168 */                           composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash3);
                                }
/* 171 */                       Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 173 */                       int i8 = (i7 >> 6) & 14;
/* 144 */                       ComposerKt.sourceInformationMarkerStart($composer4, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                int i9 = ((390 >> 6) & 112) | 6;
                                RowScope rowScope = RowScopeInstance.INSTANCE;
                                composer = $composer4;
/* 25 */                        ComposerKt.sourceInformationMarkerStart(composer, 1872688178, "C24@1093L58,25@1188L10,25@1155L84:ReviewScreen.kt#i35lj1");
                                XunjiComponentsKt.IconAction("back", "结束复习", onExit, "review-exit", !submitting2, composer, (($dirty2 >> 12) & 896) | 3126, 0);
/* 26 */                        TextKt.m3584TextNvy7gAk("专注这一张", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer, MaterialTheme.$stable).getTitleLarge(), composer, 6, 0, 131068);
/* 27 */                        if (canUndo) {
                                    composer.startReplaceGroup(1872842898);
                                    ComposerKt.sourceInformation(composer, "26@1254L94");
                                    $composer3 = $composer4;
                                    ButtonKt.TextButton(onUndo, TestTagKt.testTag(Modifier.INSTANCE, "undo-rating"), !submitting2, null, null, null, null, null, null, ComposableSingletons$ReviewScreenKt.INSTANCE.getLambda$1943808554$app_debug(), composer, (($dirty2 >> 12) & 14) | 805306416, 504);
                                    composer = composer;
                                } else {
                                    $composer3 = $composer4;
                                    composer.startReplaceGroup(1871595024);
                                }
                                composer.endReplaceGroup();
/* 25 */                        ComposerKt.sourceInformationMarkerEnd(composer);
/* 144 */                       ComposerKt.sourceInformationMarkerEnd($composer4);
/* 174 */                       $composer4.endNode();
/* 153 */                       ComposerKt.sourceInformationMarkerEnd($composer4);
/* 147 */                       ComposerKt.sourceInformationMarkerEnd($composer4);
/* 137 */                       ComposerKt.sourceInformationMarkerEnd($composer4);
/* 30 */                        if (Intrinsics.areEqual(state, ReviewUiState.Loading.INSTANCE)) {
/* 150 */                           $composer4.startReplaceGroup(-1076001644);
/* 150 */                           ComposerKt.sourceInformation($composer4, "29@1395L6");
/* 150 */                           XunjiComponentsKt.Busy($composer4, 0);
/* 150 */                           $composer4.endReplaceGroup();
                                    function1 = onGrade;
/* 150 */                           composer2 = $composer4;
                                    function7 = function6;
                                    $composer2 = $composer3;
                                } else if (state instanceof ReviewUiState.Failure) {
/* 150 */                           $composer4.startReplaceGroup(-1076000412);
/* 150 */                           ComposerKt.sourceInformation($composer4, "30@1431L86");
/* 31 */                            Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(22));
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 184 */                           MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.INSTANCE.getTopStart(), false);
/* 189 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 150 */                           iHashCode6 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 191 */                           CompositionLocalMap currentCompositionLocalMap3 = $composer4.getCurrentCompositionLocalMap();
/* 192 */                           Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer4, modifierM840padding3ABfNKs);
/* 194 */                           constructor6 = ComposeUiNode.INSTANCE.getConstructor();
                                    int i10 = ((((6 << 3) & 112) << 6) & 896) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 196 */                           if (!($composer4.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 197 */                           $composer4.startReusableNode();
/* 198 */                           if ($composer4.getInserting()) {
/* 199 */                               $composer4.createNode(constructor6);
                                    } else {
/* 201 */                               $composer4.useNode();
                                    }
/* 203 */                           composerM4979constructorimpl6 = Updater.m4979constructorimpl($composer4);
/* 204 */                           Updater.m4986setimpl(composerM4979constructorimpl6, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 205 */                           Updater.m4986setimpl(composerM4979constructorimpl6, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 206 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 208 */                           if (!composerM4979constructorimpl6.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl6.rememberedValue(), Integer.valueOf(iHashCode6))) {
/* 207 */                               composerM4979constructorimpl6.updateRememberedValue(Integer.valueOf(iHashCode6));
/* 210 */                               composerM4979constructorimpl6.apply(Integer.valueOf(iHashCode6), setCompositeKeyHash4);
                                    }
/* 213 */                           Updater.m4986setimpl(composerM4979constructorimpl6, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 215 */                           int i11 = (i10 >> 6) & 14;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                                    BoxScopeInstance boxScopeInstance = BoxScopeInstance.INSTANCE;
                                    int i12 = ((6 >> 6) & 112) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1437550087, "C30@1462L53:ReviewScreen.kt#i35lj1");
/* 150 */                           XunjiComponentsKt.EmptyState("暂时遇到一点问题", ((ReviewUiState.Failure) state).getMessage(), "重新读取", onRefresh, $composer4, (($dirty2 >> 6) & 7168) | 390, 0);
/* 150 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 186 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 216 */                           $composer4.endNode();
/* 195 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 189 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 179 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 31 */                            $composer4.endReplaceGroup();
                                    function1 = onGrade;
/* 150 */                           composer2 = $composer4;
                                    function7 = function6;
                                    $composer2 = $composer3;
                                } else if (state instanceof ReviewUiState.Complete) {
/* 150 */                           $composer4.startReplaceGroup(-1075995818);
/* 150 */                           ComposerKt.sourceInformation($composer4, "31@1593L21,31@1548L936");
/* 32 */                            Modifier modifierM840padding3ABfNKs2 = PaddingKt.m840padding3ABfNKs(ScrollKt.verticalScroll$default(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), ScrollKt.rememberScrollState(0, $composer4, 0, 1), false, null, false, 14, null), Dp.m8404constructorimpl(22));
/* 32 */                            Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 150 */                           MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer4, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 230 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 150 */                           iHashCode4 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 232 */                           CompositionLocalMap currentCompositionLocalMap4 = $composer4.getCurrentCompositionLocalMap();
/* 233 */                           Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer4, modifierM840padding3ABfNKs2);
/* 235 */                           constructor4 = ComposeUiNode.INSTANCE.getConstructor();
                                    int i13 = ((((48 << 3) & 112) << 6) & 896) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 237 */                           if (!($composer4.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 238 */                           $composer4.startReusableNode();
/* 239 */                           if ($composer4.getInserting()) {
/* 240 */                               $composer4.createNode(constructor4);
                                    } else {
/* 242 */                               $composer4.useNode();
                                    }
/* 244 */                           composerM4979constructorimpl4 = Updater.m4979constructorimpl($composer4);
/* 245 */                           Updater.m4986setimpl(composerM4979constructorimpl4, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 246 */                           Updater.m4986setimpl(composerM4979constructorimpl4, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 247 */                           setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 249 */                           if (composerM4979constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl4.rememberedValue(), Integer.valueOf(iHashCode4))) {
/* 248 */                               composerM4979constructorimpl4.updateRememberedValue(Integer.valueOf(iHashCode4));
/* 251 */                               composerM4979constructorimpl4.apply(Integer.valueOf(iHashCode4), setCompositeKeyHash);
                                    }
/* 254 */                           Updater.m4986setimpl(composerM4979constructorimpl4, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
/* 256 */                           int i14 = (i13 >> 6) & 14;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                    ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                                    int i15 = ((48 >> 6) & 112) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1452958682, "C32@1686L30,32@1717L93,33@1815L149,34@2027L257,34@1969L315,35@2289L36,36@2330L28,36@2359L120:ReviewScreen.kt#i35lj1");
/* 150 */                           SpacerKt.Spacer(SizeKt.m878height3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(16)), $composer4, 6);
                                    Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                                    Alignment center = Alignment.INSTANCE.getCenter();
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1042775818, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo");
/* 262 */                           MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(center, false);
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 150 */                           iHashCode5 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 269 */                           CompositionLocalMap currentCompositionLocalMap5 = $composer4.getCurrentCompositionLocalMap();
/* 150 */                           Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier($composer4, modifierFillMaxWidth$default);
/* 272 */                           constructor5 = ComposeUiNode.INSTANCE.getConstructor();
/* 266 */                           int i16 = ((((54 << 3) & 112) << 6) & 896) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 274 */                           if (!($composer4.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 275 */                           $composer4.startReusableNode();
/* 276 */                           if ($composer4.getInserting()) {
/* 277 */                               function8 = constructor5;
/* 150 */                               $composer4.createNode(function8);
                                    } else {
/* 279 */                               function8 = constructor5;
/* 150 */                               $composer4.useNode();
                                    }
/* 281 */                           composerM4979constructorimpl5 = Updater.m4979constructorimpl($composer4);
/* 282 */                           Updater.m4986setimpl(composerM4979constructorimpl5, measurePolicyMaybeCachedBoxMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 283 */                           Updater.m4986setimpl(composerM4979constructorimpl5, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 284 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 286 */                           if (!composerM4979constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl5.rememberedValue(), Integer.valueOf(iHashCode5))) {
/* 285 */                               composerM4979constructorimpl5.updateRememberedValue(Integer.valueOf(iHashCode5));
/* 288 */                               composerM4979constructorimpl5.apply(Integer.valueOf(iHashCode5), setCompositeKeyHash5);
                                    }
/* 291 */                           Updater.m4986setimpl(composerM4979constructorimpl5, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
/* 293 */                           int i17 = (i16 >> 6) & 14;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1833054614, "C72@3469L9:Box.kt#2w3rfo");
                                    BoxScopeInstance boxScopeInstance2 = BoxScopeInstance.INSTANCE;
                                    int i18 = ((54 >> 6) & 112) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -795168769, "C32@1782L26:ReviewScreen.kt#i35lj1");
/* 150 */                           XunjiComponentsKt.Mark(SizeKt.m892size3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(64)), $composer4, 6, 0);
/* 150 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 264 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 294 */                           $composer4.endNode();
/* 273 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 267 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 258 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 34 */                            if (((ReviewUiState.Complete) state).getScoreCount() > 0) {
                                        str2 = "这一轮，辛苦了。";
                                    } else {
                                        str2 = "现在可以歇一歇。";
                                    }
                                    if (((ReviewUiState.Complete) state).getNextDueAt() != null) {
                                        str3 = "下一张将在 " + XunjiComponentsKt.localTime(((ReviewUiState.Complete) state).getNextDueAt().longValue()) + " 到期。";
                                    } else {
                                        str3 = "当前没有可以学习的卡片。";
                                    }
/* 150 */                           XunjiComponentsKt.SectionTitle(str2, str3, $composer4, 0, 0);
/* 150 */                           XunjiComponentsKt.Paper(TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "review-complete"), ComposableLambdaKt.rememberComposableLambda(1414100948, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda6
                                        @Override // kotlin.jvm.functions.Function3
                                        public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                            return ReviewScreenKt.ReviewScreen$lambda$1$2$1(state, (ColumnScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                                        }
                                    }, $composer4, 54), $composer4, 54, 0);
/* 150 */                           XunjiComponentsKt.Notice("学习步骤会在到期后再次出现。留一点空间，让记忆沉淀。", false, $composer4, 6, 2);
/* 150 */                           XunjiComponentsKt.PrimaryButton("完成复习", onExit, null, false, null, $composer4, (($dirty2 >> 15) & 112) | 6, 28);
/* 150 */                           ButtonKt.OutlinedButton(onRefresh, SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(52), 0.0f, 2, null), false, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(18)), null, null, null, null, null, ComposableSingletons$ReviewScreenKt.INSTANCE.m8997getLambda$964842$app_debug(), $composer4, (($dirty2 >> 15) & 14) | 805306416, 500);
/* 33 */                            ComposerKt.sourceInformationMarkerEnd($composer4);
/* 227 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 299 */                           $composer4.endNode();
/* 236 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 230 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 221 */                           ComposerKt.sourceInformationMarkerEnd($composer4);
/* 32 */                            $composer4.endReplaceGroup();
                                    function1 = onGrade;
/* 150 */                           composer2 = $composer4;
                                    function7 = function6;
                                    $composer2 = $composer3;
                                } else {
/* 150 */                           $composer4.startReplaceGroup(1004855424);
/* 150 */                           ComposerKt.sourceInformation($composer4, "41@2698L2307");
/* 40 */                            if (state instanceof ReviewUiState.Answer) {
/* 39 */                                answer = (ReviewUiState.Answer) state;
                                    } else if (state instanceof ReviewUiState.Submitting) {
/* 39 */                                answer = ((ReviewUiState.Submitting) state).getAnswer();
                                    } else {
                                        answer = null;
                                    }
/* 41 */                            if (answer != null || (candidate = answer.getCandidate()) == null) {
/* 39 */                                candidate = ((ReviewUiState.Question) state).getCandidate();
                                    }
/* 42 */                            Modifier modifierM843paddingqDBjuR0 = PaddingKt.m843paddingqDBjuR0(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(12), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18));
/* 42 */                            Arrangement.Vertical verticalM699spacedBy0680j_5 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(16));
/* 304 */                           ComposerKt.sourceInformationMarkerStart($composer4, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 150 */                           MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_5, Alignment.INSTANCE.getStart(), $composer4, ((54 >> 3) & 14) | ((54 >> 3) & 112));
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 150 */                           iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer4, 0));
/* 315 */                           CompositionLocalMap currentCompositionLocalMap6 = $composer4.getCurrentCompositionLocalMap();
/* 316 */                           Modifier modifierMaterializeModifier6 = ComposedModifierKt.materializeModifier($composer4, modifierM843paddingqDBjuR0);
/* 318 */                           constructor3 = ComposeUiNode.INSTANCE.getConstructor();
/* 309 */                           int i19 = ((((54 << 3) & 112) << 6) & 896) | 6;
/* 150 */                           ComposerKt.sourceInformationMarkerStart($composer4, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 320 */                           if (!($composer4.getApplier() instanceof Applier)) {
                                        ComposablesKt.invalidApplier();
                                    }
/* 321 */                           $composer4.startReusableNode();
/* 322 */                           if ($composer4.getInserting()) {
/* 323 */                               $composer4.createNode(constructor3);
                                    } else {
/* 325 */                               $composer4.useNode();
                                    }
/* 327 */                           composerM4979constructorimpl3 = Updater.m4979constructorimpl($composer4);
/* 150 */                           composer2 = $composer4;
/* 328 */                           Updater.m4986setimpl(composerM4979constructorimpl3, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 329 */                           Updater.m4986setimpl(composerM4979constructorimpl3, currentCompositionLocalMap6, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 330 */                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash6 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 332 */                           if (composerM4979constructorimpl3.getInserting()) {
                                        i2 = iHashCode3;
                                    } else {
                                        i2 = iHashCode3;
/* 331 */                               if (!Intrinsics.areEqual(composerM4979constructorimpl3.rememberedValue(), Integer.valueOf(i2))) {
                                        }
/* 337 */                               Updater.m4986setimpl(composerM4979constructorimpl3, modifierMaterializeModifier6, ComposeUiNode.INSTANCE.getSetModifier());
/* 339 */                               int i20 = (i19 >> 6) & 14;
/* 150 */                               ComposerKt.sourceInformationMarkerStart($composer4, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                        int i21 = ((54 >> 6) & 112) | 6;
                                        ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
/* 150 */                               ComposerKt.sourceInformationMarkerStart($composer4, -307080552, "C42@2947L81,42@2817L211:ReviewScreen.kt#i35lj1");
/* 150 */                               FlowLayoutKt.FlowRow(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(18)), Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(6)), null, 0, 0, ComposableLambdaKt.rememberComposableLambda(-531964790, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda7
                                            @Override // kotlin.jvm.functions.Function3
                                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                                return ReviewScreenKt.ReviewScreen$lambda$1$3$0(candidate, answer, (FlowRowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                                            }
                                        }, $composer4, 54), $composer4, 1573302, 56);
                                        if (answer != null || (rendered = answer.getRendered()) == null) {
/* 39 */                                    if (state instanceof ReviewUiState.Question) {
/* 39 */                                        question = (ReviewUiState.Question) state;
                                            } else {
                                                question = null;
                                            }
                                            if (question != null) {
                                                rendered = question.getRendered();
                                            } else {
                                                rendered = null;
                                            }
                                        }
/* 44 */                                $composer4.startMovableGroup(-702630524, candidate.getCard().getId());
/* 44 */                                ComposerKt.sourceInformation($composer4, "46@3339L11,46@3398L11,46@3427L1219,46@3244L1402");
                                        final RenderedCard renderedCard = rendered;
                                        final CardCandidate cardCandidate = candidate;
                                        answer2 = answer;
                                        function7 = function6;
                                        submitting3 = submitting2;
/* 44 */                                SurfaceKt.m3412SurfaceT9BRK9s(SizeKt.fillMaxWidth$default(ColumnScope.weight$default(columnScope, Modifier.INSTANCE, 1.0f, false, 2, null), 0.0f, 1, null), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(28)), MaterialTheme.INSTANCE.getColorScheme($composer4, MaterialTheme.$stable).getSurface(), 0L, 0.0f, 0.0f, BorderStrokeKt.m295BorderStrokecXLIe8U(Dp.m8404constructorimpl(1), MaterialTheme.INSTANCE.getColorScheme($composer4, MaterialTheme.$stable).getOutlineVariant()), ComposableLambdaKt.rememberComposableLambda(-143813859, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda8
                                            @Override // kotlin.jvm.functions.Function2
                                            public final Object invoke(Object obj2, Object obj3) {
                                                return ReviewScreenKt.ReviewScreen$lambda$1$3$1(renderedCard, submitting3, function7, cardCandidate, answer2, (Composer) obj2, ((Integer) obj3).intValue());
                                            }
                                        }, $composer4, 54), $composer4, 12582912, 56);
/* 44 */                                $composer4.endMovableGroup();
/* 61 */                                if (answer2 == null) {
/* 44 */                                    $composer4.startReplaceGroup(-702585161);
/* 44 */                                    ComposerKt.sourceInformation($composer4, "60@4675L50");
/* 44 */                                    composer3 = $composer4;
                                            XunjiComponentsKt.PrimaryButton("显示答案", onReveal, null, false, "reveal-answer", composer3, (($dirty2 >> 3) & 112) | 24582, 12);
                                            composer3.endReplaceGroup();
                                            $composer2 = $composer3;
                                            function1 = onGrade;
                                        } else {
                                            composer3.startReplaceGroup(-305236394);
                                            ComposerKt.sourceInformation(composer3, "");
/* 63 */                                    if (answer2.getError() != null) {
/* 44 */                                        composer3 = $composer4;
                                                composer3.startReplaceGroup(-702582274);
                                                ComposerKt.sourceInformation(composer3, "62@4766L25");
                                                z = false;
                                                XunjiComponentsKt.Notice(answer2.getError(), true, composer3, 48, 0);
                                            } else {
/* 44 */                                        composer3 = $composer4;
                                                z = false;
                                                composer3.startReplaceGroup(-309943651);
                                            }
                                            composer3.endReplaceGroup();
/* 64 */                                    if (answer2.getRetryRating() != null) {
                                                composer3.startReplaceGroup(-702580262);
                                                ComposerKt.sourceInformation(composer3, "63@4874L29,63@4826L117");
                                                if (submitting3) {
                                                    str = "正在记录…";
                                                } else {
                                                    str = "重试记录";
                                                }
                                                String str4 = str;
                                                ComposerKt.sourceInformationMarkerStart(composer3, -702578814, "CC(remember):ReviewScreen.kt#9igjgp");
                                                if (($dirty2 & 7168) == 2048) {
                                                    z2 = true;
                                                } else {
                                                    z2 = z;
                                                }
                                                $composer2 = $composer3;
                                                zChangedInstance = $composer2.changedInstance(answer2) | z2;
/* 342 */                                       objRememberedValue = composer3.rememberedValue();
/* 343 */                                       if (!zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                                    function1 = onGrade;
                                                    Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda9
                                                        @Override // kotlin.jvm.functions.Function0
                                                        public final Object invoke() {
                                                            return ReviewScreenKt.ReviewScreen$lambda$1$3$2$0(function1, answer2);
                                                        }
                                                    };
/* 345 */                                           composer3.updateRememberedValue(obj2);
/* 346 */                                           objRememberedValue = obj2;
                                                } else {
                                                    function1 = onGrade;
                                                }
                                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 64 */                                        XunjiComponentsKt.PrimaryButton(str4, (Function0) objRememberedValue, null, !submitting3, "retry-rating", composer3, 24576, 4);
                                                composer3.endReplaceGroup();
                                            } else {
                                                $composer2 = $composer3;
                                                function1 = onGrade;
                                                composer3.startReplaceGroup(-702576214);
                                                ComposerKt.sourceInformation(composer3, "64@4955L37");
                                                RatingGrid(answer2, submitting3, function1, composer3, ReviewUiState.Answer.$stable | (($dirty2 >> 3) & 896));
                                                composer3.endReplaceGroup();
                                            }
/* 62 */                                    composer3.endReplaceGroup();
                                        }
/* 43 */                                ComposerKt.sourceInformationMarkerEnd(composer3);
/* 310 */                               ComposerKt.sourceInformationMarkerEnd($composer4);
/* 348 */                               
                                        /*  JADX ERROR: Method code generation error
                                            jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0d62: INVOKE (r9v24 ?? I:??[OBJECT, ARRAY]) INTERFACE call: androidx.compose.runtime.Composer.endNode():void A[MD:():void (m)] (LINE:348) in method: com.xunji.flashcards.ui.screens.ReviewScreenKt.ReviewScreen(com.xunji.flashcards.ui.ReviewUiState, boolean, kotlin.jvm.functions.Function0<kotlin.Unit>, kotlin.jvm.functions.Function1<? super com.xunji.core.model.Rating, kotlin.Unit>, kotlin.jvm.functions.Function0<kotlin.Unit>, kotlin.jvm.functions.Function0<kotlin.Unit>, kotlin.jvm.functions.Function0<kotlin.Unit>, kotlin.jvm.functions.Function2<? super com.xunji.flashcards.anki.CardMedia, ? super kotlin.coroutines.Continuation<? super java.io.InputStream>, ? extends java.lang.Object>, androidx.compose.runtime.Composer, int, int):void, file: classes10.dex
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                                            	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                                            	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                                            	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:140)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:140)
                                            	at jadx.core.codegen.RegionGen.connectElseIf(RegionGen.java:157)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:136)
                                            	at jadx.core.codegen.RegionGen.connectElseIf(RegionGen.java:157)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:136)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:140)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                            	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                            	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                            	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                            	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                                            	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                                            	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                                            	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                                            	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                                            	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                                            	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                                            	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                            	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                                            Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r9v24 ??
                                            	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                                            */
                                        /*
                                            Method dump skipped, instruction units count: 3521
                                            To view this dump change 'Code comments level' option to 'DEBUG'
                                        */
                                        throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.ui.screens.ReviewScreenKt.ReviewScreen(com.xunji.flashcards.ui.ReviewUiState, boolean, kotlin.jvm.functions.Function0, kotlin.jvm.functions.Function1, kotlin.jvm.functions.Function0, kotlin.jvm.functions.Function0, kotlin.jvm.functions.Function0, kotlin.jvm.functions.Function2, androidx.compose.runtime.Composer, int, int):void");
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
                                    /* JADX WARN: Code duplicated, block: B:28:0x01e0  */
/* 34 */                            public static final Unit ReviewScreen$lambda$1$2$1(ReviewUiState $state, ColumnScope Paper, Composer $composer, int $changed) {
                                        Function0<ComposeUiNode> function0;
                                        int i;
                                        Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                                        ComposerKt.sourceInformation($composer, "C34@2029L15,34@2045L187,34@2233L49:ReviewScreen.kt#i35lj1");
                                        if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventStart(1414100948, $changed, -1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:34)");
                                            }
/* 35 */                                    XunjiComponentsKt.Eyebrow("本次复习", $composer, 6);
/* 35 */                                    Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(20));
/* 358 */                                   ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 359 */                                   Modifier modifier = Modifier.INSTANCE;
/* 364 */                                   MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 369 */                                   ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 370 */                                   int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 371 */                                   CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 372 */                                   Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 374 */                                   Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 368 */                                   int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                            ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 376 */                                   if (!($composer.getApplier() instanceof Applier)) {
                                                ComposablesKt.invalidApplier();
                                            }
/* 377 */                                   $composer.startReusableNode();
/* 378 */                                   if ($composer.getInserting()) {
/* 379 */                                       function0 = constructor;
                                                $composer.createNode(function0);
                                            } else {
/* 381 */                                       function0 = constructor;
                                                $composer.useNode();
                                            }
/* 383 */                                   Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 384 */                                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 385 */                                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 386 */                                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 388 */                                   if (composerM4979constructorimpl.getInserting()) {
                                                i = iHashCode;
                                            } else {
                                                i = iHashCode;
/* 387 */                                       if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(i))) {
                                                }
/* 393 */                                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 395 */                                       int i3 = (i2 >> 6) & 14;
/* 366 */                                       ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                                int i4 = ((48 >> 6) & 112) | 6;
                                                RowScope rowScope = RowScopeInstance.INSTANCE;
                                                ComposerKt.sourceInformationMarkerStart($composer, -462667181, "C34@2102L62,34@2165L65:ReviewScreen.kt#i35lj1");
                                                XunjiComponentsKt.Metric(String.valueOf(((ReviewUiState.Complete) $state).getScoreCount()), "评分次数", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                                                XunjiComponentsKt.Metric(String.valueOf(((ReviewUiState.Complete) $state).getDistinctCards()), "学习卡片", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 366 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 396 */                                       $composer.endNode();
/* 375 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 369 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 358 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
                                                XunjiComponentsKt.Notice("有效用时 " + XunjiComponentsKt.durationLabel(((ReviewUiState.Complete) $state).getDurationMs()), false, $composer, 0, 2);
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            }
/* 387 */                                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(i));
/* 390 */                                   composerM4979constructorimpl.apply(Integer.valueOf(i), setCompositeKeyHash);
/* 393 */                                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 395 */                                   int i5 = (i2 >> 6) & 14;
/* 366 */                                   ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                            int i6 = ((48 >> 6) & 112) | 6;
                                            RowScope rowScope2 = RowScopeInstance.INSTANCE;
                                            ComposerKt.sourceInformationMarkerStart($composer, -462667181, "C34@2102L62,34@2165L65:ReviewScreen.kt#i35lj1");
                                            XunjiComponentsKt.Metric(String.valueOf(((ReviewUiState.Complete) $state).getScoreCount()), "评分次数", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                                            XunjiComponentsKt.Metric(String.valueOf(((ReviewUiState.Complete) $state).getDistinctCards()), "学习卡片", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 366 */                                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 396 */                                   $composer.endNode();
/* 375 */                                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 369 */                                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 358 */                                   ComposerKt.sourceInformationMarkerEnd($composer);
                                            XunjiComponentsKt.Notice("有效用时 " + XunjiComponentsKt.durationLabel(((ReviewUiState.Complete) $state).getDurationMs()), false, $composer, 0, 2);
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventEnd();
                                            }
                                        } else {
                                            $composer.skipToGroupEnd();
                                        }
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
/* 42 */                            public static final Unit ReviewScreen$lambda$1$3$0(CardCandidate $candidate, ReviewUiState.Answer $answer, FlowRowScope FlowRow, Composer $composer, int $changed) {
                                        Intrinsics.checkNotNullParameter(FlowRow, "$this$FlowRow");
                                        ComposerKt.sourceInformation($composer, "C42@2949L27,42@2977L49:ReviewScreen.kt#i35lj1");
                                        if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventStart(-531964790, $changed, -1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:42)");
                                            }
/* 43 */                                    XunjiComponentsKt.Eyebrow($candidate.getDeckName(), $composer, 0);
                                            XunjiComponentsKt.Eyebrow($answer == null ? "先回忆，再揭晓" : "按真实感受评分", $composer, 0);
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventEnd();
                                            }
                                        } else {
                                            $composer.skipToGroupEnd();
                                        }
                                        return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
                                    /* JADX WARN: Code duplicated, block: B:35:0x0252  */
                                    /* JADX WARN: Code duplicated, block: B:36:0x0255  */
                                    /* JADX WARN: Code duplicated, block: B:40:0x02c3  */
/* 47 */                            public static final Unit ReviewScreen$lambda$1$3$1(RenderedCard $rendered, boolean $submitting, Function2 $openMedia, final CardCandidate $candidate, ReviewUiState.Answer $answer, Composer $composer, int $changed) {
                                        Function0<ComposeUiNode> function0;
                                        int i;
                                        boolean z;
                                        ComposerKt.sourceInformation($composer, "C:ReviewScreen.kt#i35lj1");
                                        if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventStart(-143813859, $changed, -1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:47)");
                                            }
/* 48 */                                    if ($rendered == null || !$submitting) {
                                                if ($rendered != null) {
                                                    $composer.startReplaceGroup(-766162714);
                                                    ComposerKt.sourceInformation($composer, "47@3497L73");
/* 48 */                                            AnkiCardContentKt.AnkiCardContent($rendered, $openMedia, PaddingKt.m840padding3ABfNKs(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(12)), $composer, 384, 0);
                                                } else {
                                                    $composer.startReplaceGroup(-766159196);
                                                    ComposerKt.sourceInformation($composer, "47@3621L21,47@3576L1063");
/* 48 */                                            Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(ScrollKt.verticalScroll$default(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null), ScrollKt.rememberScrollState(0, $composer, 0, 1), false, null, false, 14, null), Dp.m8404constructorimpl(26));
/* 48 */                                            Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(20));
/* 401 */                                           ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 405 */                                           MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 410 */                                           ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 411 */                                           int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 412 */                                           CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 413 */                                           Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 415 */                                           Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 409 */                                           int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                                    ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 417 */                                           if (!($composer.getApplier() instanceof Applier)) {
                                                        ComposablesKt.invalidApplier();
                                                    }
/* 418 */                                           $composer.startReusableNode();
/* 419 */                                           if ($composer.getInserting()) {
/* 420 */                                               function0 = constructor;
                                                        $composer.createNode(function0);
                                                    } else {
/* 422 */                                               function0 = constructor;
                                                        $composer.useNode();
                                                    }
/* 424 */                                           Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 425 */                                           Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 426 */                                           Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 427 */                                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 429 */                                           if (composerM4979constructorimpl.getInserting()) {
                                                        i = i2;
                                                    } else {
                                                        i = i2;
/* 428 */                                               if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                                        }
/* 434 */                                               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 436 */                                               int i3 = (i >> 6) & 14;
/* 407 */                                               ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                        int i4 = ((48 >> 6) & 112) | 6;
                                                        ColumnScope columnScope = ColumnScopeInstance.INSTANCE;
                                                        ComposerKt.sourceInformationMarkerStart($composer, 810286714, "C48@3717L24,49@3795L10,49@3749L177,50@4017L614,50@3934L697:ReviewScreen.kt#i35lj1");
/* 416 */                                               XunjiComponentsKt.Eyebrow("QUESTION · 正面", $composer, 6);
/* 50 */                                                TextKt.m3584TextNvy7gAk($candidate.getCard().getFront(), TestTagKt.testTag(Modifier.INSTANCE, "card-front"), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, TextStyle.m7851copyp1EtxEg$default(MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getHeadlineLarge(), 0L, TextUnitKt.getSp(32), null, null, null, FontFamily.INSTANCE.getSerif(), null, 0L, null, null, null, 0L, null, null, null, 0, 0, TextUnitKt.getSp(44), null, null, null, 0, 0, null, 16646109, null), $composer, 48, 0, 131068);
/* 51 */                                                if ($answer != null) {
                                                            z = true;
                                                        } else {
                                                            z = false;
                                                        }
/* 49 */                                                AnimatedVisibilityKt.AnimatedVisibility(columnScope, z, (Modifier) null, EnterExitTransitionKt.fadeIn$default(AnimationSpecKt.tween$default(200, 0, null, 6, null), 0.0f, 2, null), EnterExitTransitionKt.fadeOut$default(AnimationSpecKt.tween$default(180, 0, null, 6, null), 0.0f, 2, null), (String) null, ComposableLambdaKt.rememberComposableLambda(1807995535, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda0
                                                            @Override // kotlin.jvm.functions.Function3
                                                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                                                return ReviewScreenKt.ReviewScreen$lambda$1$3$1$0$0($candidate, (AnimatedVisibilityScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                                            }
                                                        }, $composer, 54), $composer, (i4 & 14) | 1600512, 18);
/* 49 */                                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 407 */                                               ComposerKt.sourceInformationMarkerEnd($composer);
/* 437 */                                               $composer.endNode();
/* 416 */                                               ComposerKt.sourceInformationMarkerEnd($composer);
/* 410 */                                               ComposerKt.sourceInformationMarkerEnd($composer);
/* 401 */                                               ComposerKt.sourceInformationMarkerEnd($composer);
/* 48 */                                                $composer.endReplaceGroup();
                                                    }
/* 428 */                                           composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 431 */                                           composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 434 */                                           Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 436 */                                           int i5 = (i >> 6) & 14;
/* 407 */                                           ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                    int i6 = ((48 >> 6) & 112) | 6;
                                                    ColumnScope columnScope2 = ColumnScopeInstance.INSTANCE;
                                                    ComposerKt.sourceInformationMarkerStart($composer, 810286714, "C48@3717L24,49@3795L10,49@3749L177,50@4017L614,50@3934L697:ReviewScreen.kt#i35lj1");
/* 416 */                                           XunjiComponentsKt.Eyebrow("QUESTION · 正面", $composer, 6);
/* 50 */                                            TextKt.m3584TextNvy7gAk($candidate.getCard().getFront(), TestTagKt.testTag(Modifier.INSTANCE, "card-front"), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, TextStyle.m7851copyp1EtxEg$default(MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getHeadlineLarge(), 0L, TextUnitKt.getSp(32), null, null, null, FontFamily.INSTANCE.getSerif(), null, 0L, null, null, null, 0L, null, null, null, 0, 0, TextUnitKt.getSp(44), null, null, null, 0, 0, null, 16646109, null), $composer, 48, 0, 131068);
/* 51 */                                            if ($answer != null) {
                                                        z = true;
                                                    } else {
                                                        z = false;
                                                    }
/* 49 */                                            AnimatedVisibilityKt.AnimatedVisibility(columnScope2, z, (Modifier) null, EnterExitTransitionKt.fadeIn$default(AnimationSpecKt.tween$default(200, 0, null, 6, null), 0.0f, 2, null), EnterExitTransitionKt.fadeOut$default(AnimationSpecKt.tween$default(180, 0, null, 6, null), 0.0f, 2, null), (String) null, ComposableLambdaKt.rememberComposableLambda(1807995535, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda0
                                                        @Override // kotlin.jvm.functions.Function3
                                                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                                                            return ReviewScreenKt.ReviewScreen$lambda$1$3$1$0$0($candidate, (AnimatedVisibilityScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                                        }
                                                    }, $composer, 54), $composer, (i6 & 14) | 1600512, 18);
/* 49 */                                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 407 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 437 */                                           $composer.endNode();
/* 416 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 410 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 401 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 48 */                                            $composer.endReplaceGroup();
                                                }
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            } else {
                                                $composer.startReplaceGroup(-766163741);
                                                ComposerKt.sourceInformation($composer, "47@3467L6");
                                                XunjiComponentsKt.Busy($composer, 0);
                                            }
                                            $composer.endReplaceGroup();
                                            if (ComposerKt.isTraceInProgress()) {
                                                ComposerKt.traceEventEnd();
                                            }
                                        } else {
/* 47 */                                    $composer.skipToGroupEnd();
                                        }
/* 59 */                                return Unit.INSTANCE;
                                    }

                                    /* JADX INFO: Access modifiers changed from: private */
                                    /* JADX WARN: Code duplicated, block: B:23:0x01b8  */
                                    /* JADX WARN: Code duplicated, block: B:24:0x020e  */
                                    /* JADX WARN: Code duplicated, block: B:27:0x0238  */
/* 51 */                            public static final Unit ReviewScreen$lambda$1$3$1$0$0(final CardCandidate $candidate, AnimatedVisibilityScope AnimatedVisibility, Composer $composer, int $changed) {
                                        Function0<ComposeUiNode> function0;
                                        int i;
                                        Intrinsics.checkNotNullParameter(AnimatedVisibility, "$this$AnimatedVisibility");
                                        ComposerKt.sourceInformation($composer, "C51@4027L595:ReviewScreen.kt#i35lj1");
                                        if (ComposerKt.isTraceInProgress()) {
                                            ComposerKt.traceEventStart(1807995535, $changed, -1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:51)");
                                        }
/* 52 */                                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(20));
/* 442 */                               ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 443 */                               Modifier modifier = Modifier.INSTANCE;
/* 448 */                               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 453 */                               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 454 */                               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 455 */                               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 456 */                               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 458 */                               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 452 */                               int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 460 */                               if (!($composer.getApplier() instanceof Applier)) {
                                            ComposablesKt.invalidApplier();
                                        }
/* 461 */                               $composer.startReusableNode();
/* 462 */                               if ($composer.getInserting()) {
/* 463 */                                   function0 = constructor;
                                            $composer.createNode(function0);
                                        } else {
/* 465 */                                   function0 = constructor;
                                            $composer.useNode();
                                        }
/* 467 */                               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 468 */                               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 469 */                               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 470 */                               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 472 */                               if (!composerM4979constructorimpl.getInserting()) {
                                            i = 48;
/* 471 */                                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                            }
/* 477 */                                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 479 */                                   int i3 = (i2 >> 6) & 14;
/* 450 */                                   ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                            int i4 = ((i >> 6) & 112) | 6;
                                            ComposerKt.sourceInformationMarkerStart($composer, 1806917560, "C52@4132L11,52@4094L65,52@4160L22,53@4237L10,53@4192L105:ReviewScreen.kt#i35lj1");
                                            DividerKt.m2731HorizontalDivider9IZ8Weo(null, 0.0f, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOutlineVariant(), $composer, 0, 3);
/* 459 */                                   XunjiComponentsKt.Eyebrow("ANSWER · 背面", $composer, 6);
/* 54 */                                    TextKt.m3584TextNvy7gAk($candidate.getCard().getBack(), TestTagKt.testTag(Modifier.INSTANCE, "card-back"), 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodyLarge(), $composer, 48, 0, 131068);
/* 55 */                                    if (StringsKt.isBlank($candidate.getCard().getExample())) {
                                                $composer.startReplaceGroup(1802839261);
                                            } else {
                                                $composer.startReplaceGroup(1807160692);
                                                ComposerKt.sourceInformation($composer, "54@4409L11,54@4437L173,54@4349L261");
/* 55 */                                        SurfaceKt.m3412SurfaceT9BRK9s(null, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16)), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getSurfaceVariant(), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-278000069, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda3
                                                    @Override // kotlin.jvm.functions.Function2
                                                    public final Object invoke(Object obj, Object obj2) {
                                                        return ReviewScreenKt.ReviewScreen$lambda$1$3$1$0$0$0$0($candidate, (Composer) obj, ((Integer) obj2).intValue());
                                                    }
                                                }, $composer, 54), $composer, 12582912, 121);
                                            }
                                            $composer.endReplaceGroup();
/* 53 */                                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 450 */                                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 481 */                                   
                                            /*  JADX ERROR: Method code generation error
                                                jadx.core.utils.exceptions.CodegenException: Error generate insn: 0x0223: INVOKE (r4v1 ?? I:??[OBJECT, ARRAY]) INTERFACE call: androidx.compose.runtime.Composer.endNode():void A[MD:():void (m)] (LINE:481) in method: com.xunji.flashcards.ui.screens.ReviewScreenKt.ReviewScreen$lambda$1$3$1$0$0(com.xunji.core.model.CardCandidate, androidx.compose.animation.AnimatedVisibilityScope, androidx.compose.runtime.Composer, int):kotlin.Unit, file: classes10.dex
                                                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:310)
                                                	at jadx.core.codegen.InsnGen.makeInsn(InsnGen.java:273)
                                                	at jadx.core.codegen.RegionGen.makeSimpleBlock(RegionGen.java:94)
                                                	at jadx.core.dex.nodes.IBlock.generate(IBlock.java:15)
                                                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                                	at jadx.core.codegen.RegionGen.makeRegionIndent(RegionGen.java:83)
                                                	at jadx.core.codegen.RegionGen.makeIf(RegionGen.java:126)
                                                	at jadx.core.dex.regions.conditions.IfRegion.generate(IfRegion.java:90)
                                                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                                	at jadx.core.dex.regions.Region.generate(Region.java:35)
                                                	at jadx.core.codegen.RegionGen.makeRegion(RegionGen.java:66)
                                                	at jadx.core.codegen.MethodGen.addRegionInsns(MethodGen.java:291)
                                                	at jadx.core.codegen.MethodGen.addInstructions(MethodGen.java:270)
                                                	at jadx.core.codegen.ClassGen.addMethodCode(ClassGen.java:420)
                                                	at jadx.core.codegen.ClassGen.addMethod(ClassGen.java:345)
                                                	at jadx.core.codegen.ClassGen.lambda$addInnerClsAndMethods$3(ClassGen.java:299)
                                                	at java.base/java.util.stream.ForEachOps$ForEachOp$OfRef.accept(ForEachOps.java:184)
                                                	at java.base/java.util.ArrayList.forEach(ArrayList.java:1596)
                                                	at java.base/java.util.stream.SortedOps$RefSortingSink.end(SortedOps.java:395)
                                                	at java.base/java.util.stream.Sink$ChainedReference.end(Sink.java:261)
                                                Caused by: jadx.core.utils.exceptions.JadxRuntimeException: Code variable not set in r4v1 ??
                                                	at jadx.core.dex.instructions.args.SSAVar.getCodeVar(SSAVar.java:236)
                                                */
                                            /*
                                                Method dump skipped, instruction units count: 574
                                                To view this dump change 'Code comments level' option to 'DEBUG'
                                            */
                                            throw new UnsupportedOperationException("Method not decompiled: com.xunji.flashcards.ui.screens.ReviewScreenKt.ReviewScreen$lambda$1$3$1$0$0(com.xunji.core.model.CardCandidate, androidx.compose.animation.AnimatedVisibilityScope, androidx.compose.runtime.Composer, int):kotlin.Unit");
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
/* 54 */                                public static final Unit ReviewScreen$lambda$1$3$1$0$0$0$0(CardCandidate $candidate, Composer $composer, int $changed) {
                                            ComposerKt.sourceInformation($composer, "C54@4439L169:ReviewScreen.kt#i35lj1");
                                            if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventStart(-278000069, $changed, -1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:54)");
                                                }
/* 55 */                                        Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(16));
/* 55 */                                        Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
/* 485 */                                       ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 489 */                                       MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
/* 494 */                                       ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 495 */                                       int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 496 */                                       CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 497 */                                       Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 499 */                                       Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 493 */                                       int i = ((((54 << 3) & 112) << 6) & 896) | 6;
                                                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 501 */                                       if (!($composer.getApplier() instanceof Applier)) {
                                                    ComposablesKt.invalidApplier();
                                                }
/* 502 */                                       $composer.startReusableNode();
/* 503 */                                       if ($composer.getInserting()) {
/* 504 */                                           $composer.createNode(constructor);
                                                } else {
/* 506 */                                           $composer.useNode();
                                                }
/* 508 */                                       Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 509 */                                       Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 510 */                                       Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 511 */                                       Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 513 */                                       if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 512 */                                           composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 515 */                                           composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                                                }
/* 518 */                                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 520 */                                       int i2 = (i >> 6) & 14;
/* 491 */                                       ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                                int i3 = ((54 >> 6) & 112) | 6;
                                                ComposerKt.sourceInformationMarkerStart($composer, -1526587512, "C54@4520L16,54@4585L10,54@4537L69:ReviewScreen.kt#i35lj1");
/* 500 */                                       XunjiComponentsKt.Eyebrow("放进句子里", $composer, 6);
                                                TextKt.m3584TextNvy7gAk($candidate.getCard().getExample(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodyLarge(), $composer, 0, 0, 131070);
                                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 491 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 521 */                                       $composer.endNode();
/* 500 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 494 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 485 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            } else {
/* 55 */                                        $composer.skipToGroupEnd();
                                            }
                                            return Unit.INSTANCE;
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
/* 63 */                                public static final Unit ReviewScreen$lambda$1$3$2$0(Function1 $onGrade, ReviewUiState.Answer $answer) {
/* 64 */                                    $onGrade.invoke($answer.getRetryRating());
                                            return Unit.INSTANCE;
                                        }

/* 71 */                                private static final void RatingGrid(final ReviewUiState.Answer answer, final boolean submitting, final Function1<? super Rating, Unit> function1, Composer $composer, final int $changed) {
/* 72 */                                    Composer $composer2 = $composer.startRestartGroup(1841019925);
                                            ComposerKt.sourceInformation($composer2, "C(RatingGrid)N(answer,submitting,onGrade)72@5156L7,73@5219L1514,73@5175L1558:ReviewScreen.kt#i35lj1");
                                            int $dirty = $changed;
                                            if (($changed & 6) == 0) {
                                                $dirty |= ($changed & 8) == 0 ? $composer2.changed(answer) : $composer2.changedInstance(answer) ? 4 : 2;
                                            }
                                            if (($changed & 48) == 0) {
                                                $dirty |= $composer2.changed(submitting) ? 32 : 16;
                                            }
                                            if (($changed & 384) == 0) {
                                                $dirty |= $composer2.changedInstance(function1) ? 256 : 128;
                                            }
                                            if (!$composer2.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
/* 72 */                                        $composer2.skipToGroupEnd();
                                            } else {
                                                if (ComposerKt.isTraceInProgress()) {
/* 72 */                                            ComposerKt.traceEventStart(1841019925, $dirty, -1, "com.xunji.flashcards.ui.screens.RatingGrid (ReviewScreen.kt:71)");
                                                }
/* 73 */                                        ProvidableCompositionLocal<Density> localDensity = CompositionLocalsKt.getLocalDensity();
/* 356 */                                       ComposerKt.sourceInformationMarkerStart($composer2, 2023513938, "CC(<get-current>):CompositionLocal.kt#9igjgp");
                                                Object objConsume = $composer2.consume(localDensity);
                                                ComposerKt.sourceInformationMarkerEnd($composer2);
/* 73 */                                        final float fontScale = ((Density) objConsume).getFontScale();
/* 74 */                                        BoxWithConstraintsKt.BoxWithConstraints(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), null, false, ComposableLambdaKt.rememberComposableLambda(857455211, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda4
                                                    @Override // kotlin.jvm.functions.Function3
                                                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                                                        return ReviewScreenKt.RatingGrid$lambda$0(fontScale, function1, submitting, answer, (BoxWithConstraintsScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                                    }
                                                }, $composer2, 54), $composer2, 3078, 6);
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            }
/* 91 */                                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                                            if (scopeUpdateScopeEndRestartGroup != null) {
                                                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda5
                                                    @Override // kotlin.jvm.functions.Function2
                                                    public final Object invoke(Object obj, Object obj2) {
                                                        return ReviewScreenKt.RatingGrid$lambda$1(answer, submitting, function1, $changed, (Composer) obj, ((Integer) obj2).intValue());
                                                    }
                                                });
                                            }
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
                                        /* JADX WARN: Code duplicated, block: B:101:0x0313 A[SYNTHETIC] */
                                        /* JADX WARN: Code duplicated, block: B:41:0x01a3  */
                                        /* JADX WARN: Code duplicated, block: B:43:0x023a  */
                                        /* JADX WARN: Code duplicated, block: B:46:0x0246  */
                                        /* JADX WARN: Code duplicated, block: B:47:0x024c  */
                                        /* JADX WARN: Code duplicated, block: B:59:0x02fc  */
                                        /* JADX WARN: Code duplicated, block: B:63:0x0319  */
                                        /* JADX WARN: Code duplicated, block: B:64:0x0322  */
                                        /* JADX WARN: Code duplicated, block: B:65:0x032b  */
                                        /* JADX WARN: Code duplicated, block: B:66:0x0334  */
                                        /* JADX WARN: Code duplicated, block: B:69:0x0357  */
                                        /* JADX WARN: Code duplicated, block: B:70:0x0373  */
                                        /* JADX WARN: Code duplicated, block: B:71:0x038f  */
                                        /* JADX WARN: Code duplicated, block: B:74:0x03fa  */
                                        /* JADX WARN: Code duplicated, block: B:83:0x048a  */
                                        /* JADX WARN: Code duplicated, block: B:96:0x05d8  */
/* 74 */                                public static final Unit RatingGrid$lambda$0(float $fontScale, final Function1 $onGrade, boolean $submitting, final ReviewUiState.Answer $answer, BoxWithConstraintsScope BoxWithConstraints, Composer $composer, int $changed) {
                                            Function0<ComposeUiNode> function0;
                                            int i;
                                            Composer composer;
                                            int i2;
                                            int i3;
                                            String str;
                                            Iterable<Iterable> iterableChunked;
                                            Composer composer2;
                                            int iHashCode;
                                            Modifier modifierMaterializeModifier;
                                            Function0<ComposeUiNode> constructor;
                                            Function0<ComposeUiNode> function1;
                                            Composer composerM4979constructorimpl;
                                            Composer composer3;
                                            int i4;
                                            int i5;
                                            RowScope rowScope;
                                            Iterable<Rating> iterable;
                                            String str2;
                                            String str3;
                                            long error;
                                            long j;
                                            Modifier modifierTestTag;
                                            Function3 function3RememberComposableLambda;
                                            boolean zChanged;
                                            Object objRememberedValue;
                                            Composer composer4;
                                            boolean zChanged2;
                                            Object objRememberedValue2;
                                            Intrinsics.checkNotNullParameter(BoxWithConstraints, "$this$BoxWithConstraints");
                                            ComposerKt.sourceInformation($composer, "C75@5283L1447:ReviewScreen.kt#i35lj1");
                                            int $dirty = $changed;
                                            if (($changed & 6) == 0) {
                                                $dirty |= $composer.changed(BoxWithConstraints) ? 4 : 2;
                                            }
                                            if ($composer.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventStart(857455211, $dirty, -1, "com.xunji.flashcards.ui.screens.RatingGrid.<anonymous> (ReviewScreen.kt:74)");
                                                }
/* 75 */                                        int columns = (Dp.m8403compareTo0680j_4(BoxWithConstraints.mo728getMaxWidthD9Ej5fM(), Dp.m8404constructorimpl((float) 360)) < 0 || $fontScale > 1.2f) ? 2 : 4;
/* 76 */                                        Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(10));
/* 527 */                                       ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 528 */                                       Modifier modifier = Modifier.INSTANCE;
/* 533 */                                       MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                                                String str4 = "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh";
/* 538 */                                       ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 539 */                                       int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 540 */                                       CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 541 */                                       Modifier modifier2 = modifier;
                                                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifier2);
/* 543 */                                       Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 537 */                                       int i6 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                                String str5 = "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp";
                                                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 545 */                                       if (!($composer.getApplier() instanceof Applier)) {
                                                    ComposablesKt.invalidApplier();
                                                }
/* 546 */                                       $composer.startReusableNode();
/* 547 */                                       if ($composer.getInserting()) {
/* 548 */                                           function0 = constructor2;
                                                    $composer.createNode(function0);
                                                } else {
/* 550 */                                           function0 = constructor2;
                                                    $composer.useNode();
                                                }
                                                Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer);
/* 553 */                                       Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 554 */                                       Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 555 */                                       Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 557 */                                       if (composerM4979constructorimpl2.getInserting()) {
                                                    i = 48;
                                                } else {
                                                    i = 48;
/* 556 */                                           if (!Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                                                    }
/* 562 */                                           Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 564 */                                           int i7 = (i6 >> 6) & 14;
                                                    composer = $composer;
                                                    i2 = 0;
/* 535 */                                           ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                    ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                                    i3 = ((i >> 6) & 112) | 6;
                                                    str = "C:ReviewScreen.kt#i35lj1";
                                                    ComposerKt.sourceInformationMarkerStart(composer, 2067157308, "C:ReviewScreen.kt#i35lj1");
                                                    composer.startReplaceGroup(1452156807);
                                                    ComposerKt.sourceInformation(composer, "*77@5396L1325");
                                                    iterableChunked = CollectionsKt.chunked(Rating.getEntries(), columns);
                                                    for (Iterable iterable2 : iterableChunked) {
/* 78 */                                                Iterable iterable3 = iterableChunked;
                                                        composer2 = composer;
/* 566 */                                               int columns2 = columns;
/* 78 */                                                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(10));
                                                        int i8 = i2;
                                                        ComposerKt.sourceInformationMarkerStart(composer2, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 568 */                                               Modifier modifier3 = Modifier.INSTANCE;
/* 567 */                                               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                                                        ComposerKt.sourceInformationMarkerStart(composer2, -1159599143, str4);
/* 579 */                                               iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer2, 0));
/* 580 */                                               CompositionLocalMap currentCompositionLocalMap2 = composer2.getCurrentCompositionLocalMap();
/* 581 */                                               String str6 = str4;
/* 574 */                                               modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifier3);
/* 583 */                                               constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 577 */                                               int i9 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                                        ComposerKt.sourceInformationMarkerStart(composer2, -553112988, str5);
/* 585 */                                               if (!(composer2.getApplier() instanceof Applier)) {
                                                            ComposablesKt.invalidApplier();
                                                        }
/* 586 */                                               composer2.startReusableNode();
/* 587 */                                               if (composer2.getInserting()) {
/* 588 */                                                   function1 = constructor;
                                                            composer2.createNode(function1);
                                                        } else {
/* 590 */                                                   function1 = constructor;
                                                            composer2.useNode();
                                                        }
/* 592 */                                               String str7 = str5;
                                                        composerM4979constructorimpl = Updater.m4979constructorimpl(composer2);
/* 593 */                                               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 594 */                                               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 595 */                                               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 597 */                                               if (!composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 596 */                                                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 599 */                                                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash2);
                                                        }
/* 602 */                                               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 604 */                                               int i10 = (i9 >> 6) & 14;
                                                        composer3 = composer2;
                                                        i4 = 0;
/* 575 */                                               ComposerKt.sourceInformationMarkerStart(composer3, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
/* 567 */                                               i5 = ((48 >> 6) & 112) | 6;
                                                        rowScope = RowScopeInstance.INSTANCE;
                                                        ComposerKt.sourceInformationMarkerStart(composer3, 899543104, str);
                                                        composer3.startReplaceGroup(-386624353);
                                                        ComposerKt.sourceInformation(composer3, "*82@5949L293");
                                                        iterable = iterable2;
                                                        for (final Rating rating : iterable) {
                                                            Iterable iterable4 = iterable;
                                                            switch (WhenMappings.$EnumSwitchMapping$0[rating.ordinal()]) {
                                                                case 1:
                                                                    str2 = "忘记";
                                                                    str3 = "rating-again";
                                                                    break;
                                                                case 2:
                                                                    str2 = "困难";
                                                                    str3 = "rating-hard";
                                                                    break;
                                                                case 3:
                                                                    str2 = "记得";
                                                                    str3 = "rating-good";
                                                                    break;
                                                                case 4:
                                                                    str2 = "轻松";
                                                                    str3 = "rating-easy";
                                                                    break;
                                                                default:
                                                                    throw new NoWhenBranchMatchedException();
                                                            }
                                                            Pair pair = TuplesKt.to(str2, str3);
                                                            final String str8 = (String) pair.component1();
                                                            String str9 = (String) pair.component2();
                                                            switch (WhenMappings.$EnumSwitchMapping$0[rating.ordinal()]) {
                                                                case 1:
                                                                    composer3.startReplaceGroup(249741251);
                                                                    ComposerKt.sourceInformation(composer3, "80@5720L11");
                                                                    error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getError();
                                                                    break;
                                                                case 2:
                                                                    composer3.startReplaceGroup(249742695);
                                                                    ComposerKt.sourceInformation(composer3, "80@5765L11");
                                                                    error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSecondary();
                                                                    break;
                                                                default:
                                                                    composer3.startReplaceGroup(249744037);
                                                                    ComposerKt.sourceInformation(composer3, "80@5807L11");
                                                                    error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getPrimary();
                                                                    break;
                                                            }
                                                            composer3.endReplaceGroup();
                                                            j = error;
                                                            RowScope rowScope2 = rowScope;
/* 606 */                                                   Modifier modifier4 = modifierMaterializeModifier;
                                                            int i11 = i3;
                                                            Modifier modifier5 = modifier2;
/* 82 */                                                    modifierTestTag = TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), Dp.m8404constructorimpl(64), 0.0f, 2, null), str9);
/* 83 */                                                    function3RememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(1948323047, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda11
                                                                @Override // kotlin.jvm.functions.Function3
                                                                public final Object invoke(Object obj, Object obj2, Object obj3) {
                                                                    return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$0(str8, $answer, rating, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                                                                }
                                                            }, composer3, 54);
/* 84 */                                                    if (rating == Rating.GOOD) {
                                                                composer3.startReplaceGroup(249758669);
                                                                ComposerKt.sourceInformation(composer3, "83@6279L17,83@6272L143");
                                                                ComposerKt.sourceInformationMarkerStart(composer3, 249758767, "CC(remember):ReviewScreen.kt#9igjgp");
                                                                zChanged2 = composer3.changed($onGrade) | composer3.changed(rating.ordinal());
                                                                Composer composer5 = composer3;
/* 607 */                                                       objRememberedValue2 = composer5.rememberedValue();
/* 608 */                                                       if (!zChanged2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
                                                                    Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda1
                                                                        @Override // kotlin.jvm.functions.Function0
                                                                        public final Object invoke() {
                                                                            return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$1$0($onGrade, rating);
                                                                        }
                                                                    };
/* 610 */                                                           composer5.updateRememberedValue(obj);
/* 611 */                                                           objRememberedValue2 = obj;
                                                                }
                                                                ComposerKt.sourceInformationMarkerEnd(composer3);
                                                                composer4 = composer3;
/* 84 */                                                        ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag, !$submitting, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16)), null, null, null, PaddingKt.m834PaddingValuesYgX7TsA(Dp.m8404constructorimpl(8), Dp.m8404constructorimpl(12)), null, function3RememberComposableLambda, composer4, 817889280, 368);
                                                                composer3.endReplaceGroup();
                                                            } else {
                                                                composer3.startReplaceGroup(-847257813);
                                                                ComposerKt.sourceInformation(composer3, "84@6543L40,84@6664L11,84@6442L17,84@6427L281");
                                                                boolean z = !$submitting;
/* 85 */                                                        RoundedCornerShape roundedCornerShapeM1205RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16));
                                                                Composer composer6 = composer3;
                                                                ButtonColors buttonColorsM2400outlinedButtonColorsro_MJ88 = ButtonDefaults.INSTANCE.m2400outlinedButtonColorsro_MJ88(0L, j, 0L, 0L, composer6, ButtonDefaults.$stable << 12, 13);
/* 85 */                                                        PaddingValues paddingValuesM834PaddingValuesYgX7TsA = PaddingKt.m834PaddingValuesYgX7TsA(Dp.m8404constructorimpl(8), Dp.m8404constructorimpl(12));
/* 85 */                                                        BorderStroke borderStrokeM295BorderStrokecXLIe8U = BorderStrokeKt.m295BorderStrokecXLIe8U(Dp.m8404constructorimpl(1), MaterialTheme.INSTANCE.getColorScheme(composer6, MaterialTheme.$stable).getOutlineVariant());
                                                                ComposerKt.sourceInformationMarkerStart(composer6, 249763983, "CC(remember):ReviewScreen.kt#9igjgp");
                                                                zChanged = composer6.changed($onGrade) | composer6.changed(rating.ordinal());
/* 615 */                                                       objRememberedValue = composer6.rememberedValue();
/* 616 */                                                       if (!zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                                                    Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda2
                                                                        @Override // kotlin.jvm.functions.Function0
                                                                        public final Object invoke() {
                                                                            return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$2$0($onGrade, rating);
                                                                        }
                                                                    };
/* 618 */                                                           composer6.updateRememberedValue(obj2);
/* 619 */                                                           objRememberedValue = obj2;
                                                                }
                                                                ComposerKt.sourceInformationMarkerEnd(composer6);
                                                                composer4 = composer6;
/* 614 */                                                       ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag, z, roundedCornerShapeM1205RoundedCornerShape0680j_4, buttonColorsM2400outlinedButtonColorsro_MJ88, null, borderStrokeM295BorderStrokecXLIe8U, paddingValuesM834PaddingValuesYgX7TsA, null, function3RememberComposableLambda, composer4, 817889280, 288);
                                                                composer4.endReplaceGroup();
                                                            }
/* 605 */                                                   composer3 = composer4;
                                                            iterable = iterable4;
                                                            str = str;
                                                            i4 = i4;
                                                            i5 = i5;
                                                            function1 = function1;
                                                            rowScope = rowScope2;
                                                            modifierMaterializeModifier = modifier4;
                                                            i3 = i11;
                                                            modifier2 = modifier5;
                                                        }
                                                        Composer composer7 = composer3;
                                                        composer7.endReplaceGroup();
/* 79 */                                                ComposerKt.sourceInformationMarkerEnd(composer7);
/* 575 */                                               ComposerKt.sourceInformationMarkerEnd(composer3);
/* 622 */                                               composer2.endNode();
/* 584 */                                               ComposerKt.sourceInformationMarkerEnd(composer2);
/* 578 */                                               ComposerKt.sourceInformationMarkerEnd(composer2);
/* 567 */                                               ComposerKt.sourceInformationMarkerEnd(composer2);
/* 565 */                                               iterableChunked = iterable3;
                                                        composer = composer2;
                                                        columns = columns2;
                                                        i2 = i8;
                                                        str4 = str6;
                                                        str5 = str7;
                                                    }
                                                    Composer composer8 = composer;
                                                    composer8.endReplaceGroup();
/* 77 */                                            ComposerKt.sourceInformationMarkerEnd(composer8);
/* 535 */                                           ComposerKt.sourceInformationMarkerEnd(composer);
/* 627 */                                           $composer.endNode();
/* 544 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 538 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
/* 527 */                                           ComposerKt.sourceInformationMarkerEnd($composer);
                                                    if (ComposerKt.isTraceInProgress()) {
                                                        ComposerKt.traceEventEnd();
                                                    }
                                                }
/* 556 */                                       composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 559 */                                       composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash);
/* 562 */                                       Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 564 */                                       int i12 = (i6 >> 6) & 14;
                                                composer = $composer;
                                                i2 = 0;
/* 535 */                                       ComposerKt.sourceInformationMarkerStart(composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                                                i3 = ((i >> 6) & 112) | 6;
                                                str = "C:ReviewScreen.kt#i35lj1";
                                                ComposerKt.sourceInformationMarkerStart(composer, 2067157308, "C:ReviewScreen.kt#i35lj1");
                                                composer.startReplaceGroup(1452156807);
                                                ComposerKt.sourceInformation(composer, "*77@5396L1325");
                                                iterableChunked = CollectionsKt.chunked(Rating.getEntries(), columns);
                                                while (r32.hasNext()) {
/* 78 */                                            Iterable iterable5 = iterableChunked;
                                                    composer2 = composer;
/* 566 */                                           int columns3 = columns;
/* 78 */                                            Arrangement.Horizontal horizontalM699spacedBy0680j_5 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(10));
                                                    int i13 = i2;
                                                    ComposerKt.sourceInformationMarkerStart(composer2, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 568 */                                           Modifier modifier6 = Modifier.INSTANCE;
/* 567 */                                           MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_5, Alignment.INSTANCE.getTop(), composer2, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                                                    ComposerKt.sourceInformationMarkerStart(composer2, -1159599143, str4);
/* 579 */                                           iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer2, 0));
/* 580 */                                           CompositionLocalMap currentCompositionLocalMap3 = composer2.getCurrentCompositionLocalMap();
/* 581 */                                           String str10 = str4;
/* 574 */                                           modifierMaterializeModifier = ComposedModifierKt.materializeModifier(composer2, modifier6);
/* 583 */                                           constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 577 */                                           int i14 = ((((48 << 3) & 112) << 6) & 896) | 6;
                                                    ComposerKt.sourceInformationMarkerStart(composer2, -553112988, str5);
/* 585 */                                           if (!(composer2.getApplier() instanceof Applier)) {
                                                        ComposablesKt.invalidApplier();
                                                    }
/* 586 */                                           composer2.startReusableNode();
/* 587 */                                           if (composer2.getInserting()) {
/* 588 */                                               function1 = constructor;
                                                        composer2.createNode(function1);
                                                    } else {
/* 590 */                                               function1 = constructor;
                                                        composer2.useNode();
                                                    }
/* 592 */                                           String str11 = str5;
                                                    composerM4979constructorimpl = Updater.m4979constructorimpl(composer2);
/* 593 */                                           Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 594 */                                           Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 595 */                                           Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 597 */                                           if (!composerM4979constructorimpl.getInserting()) {
                                                    }
/* 596 */                                           composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 599 */                                           composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash3);
/* 602 */                                           Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 604 */                                           int i15 = (i14 >> 6) & 14;
                                                    composer3 = composer2;
                                                    i4 = 0;
/* 575 */                                           ComposerKt.sourceInformationMarkerStart(composer3, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
/* 567 */                                           i5 = ((48 >> 6) & 112) | 6;
                                                    rowScope = RowScopeInstance.INSTANCE;
                                                    ComposerKt.sourceInformationMarkerStart(composer3, 899543104, str);
                                                    composer3.startReplaceGroup(-386624353);
                                                    ComposerKt.sourceInformation(composer3, "*82@5949L293");
                                                    iterable = iterable2;
                                                    while (r73.hasNext()) {
                                                        Iterable iterable6 = iterable;
                                                        switch (WhenMappings.$EnumSwitchMapping$0[rating.ordinal()]) {
                                                            case 1:
                                                                str2 = "忘记";
                                                                str3 = "rating-again";
                                                                break;
                                                            case 2:
                                                                str2 = "困难";
                                                                str3 = "rating-hard";
                                                                break;
                                                            case 3:
                                                                str2 = "记得";
                                                                str3 = "rating-good";
                                                                break;
                                                            case 4:
                                                                str2 = "轻松";
                                                                str3 = "rating-easy";
                                                                break;
                                                            default:
                                                                throw new NoWhenBranchMatchedException();
                                                        }
                                                        Pair pair2 = TuplesKt.to(str2, str3);
                                                        final String str12 = (String) pair2.component1();
                                                        String str13 = (String) pair2.component2();
                                                        switch (WhenMappings.$EnumSwitchMapping$0[rating.ordinal()]) {
                                                            case 1:
                                                                composer3.startReplaceGroup(249741251);
                                                                ComposerKt.sourceInformation(composer3, "80@5720L11");
                                                                error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getError();
                                                                break;
                                                            case 2:
                                                                composer3.startReplaceGroup(249742695);
                                                                ComposerKt.sourceInformation(composer3, "80@5765L11");
                                                                error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getSecondary();
                                                                break;
                                                            default:
                                                                composer3.startReplaceGroup(249744037);
                                                                ComposerKt.sourceInformation(composer3, "80@5807L11");
                                                                error = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getPrimary();
                                                                break;
                                                        }
                                                        composer3.endReplaceGroup();
                                                        j = error;
                                                        RowScope rowScope3 = rowScope;
/* 606 */                                               Modifier modifier7 = modifierMaterializeModifier;
                                                        int i16 = i3;
                                                        Modifier modifier8 = modifier2;
/* 82 */                                                modifierTestTag = TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), Dp.m8404constructorimpl(64), 0.0f, 2, null), str13);
/* 83 */                                                function3RememberComposableLambda = ComposableLambdaKt.rememberComposableLambda(1948323047, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda11
                                                            @Override // kotlin.jvm.functions.Function3
                                                            public final Object invoke(Object obj3, Object obj4, Object obj5) {
                                                                return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$0(str12, $answer, rating, (RowScope) obj3, (Composer) obj4, ((Integer) obj5).intValue());
                                                            }
                                                        }, composer3, 54);
/* 84 */                                                if (rating == Rating.GOOD) {
                                                            composer3.startReplaceGroup(249758669);
                                                            ComposerKt.sourceInformation(composer3, "83@6279L17,83@6272L143");
                                                            ComposerKt.sourceInformationMarkerStart(composer3, 249758767, "CC(remember):ReviewScreen.kt#9igjgp");
                                                            zChanged2 = composer3.changed($onGrade) | composer3.changed(rating.ordinal());
                                                            Composer composer9 = composer3;
/* 607 */                                                   objRememberedValue2 = composer9.rememberedValue();
/* 608 */                                                   if (!zChanged2) {
                                                            }
                                                            Object obj3 = new Function0() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda1
                                                                @Override // kotlin.jvm.functions.Function0
                                                                public final Object invoke() {
                                                                    return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$1$0($onGrade, rating);
                                                                }
                                                            };
/* 610 */                                                   composer9.updateRememberedValue(obj3);
/* 611 */                                                   objRememberedValue2 = obj3;
                                                            ComposerKt.sourceInformationMarkerEnd(composer3);
                                                            composer4 = composer3;
/* 84 */                                                    ButtonKt.Button((Function0) objRememberedValue2, modifierTestTag, !$submitting, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16)), null, null, null, PaddingKt.m834PaddingValuesYgX7TsA(Dp.m8404constructorimpl(8), Dp.m8404constructorimpl(12)), null, function3RememberComposableLambda, composer4, 817889280, 368);
                                                            composer3.endReplaceGroup();
                                                        } else {
                                                            composer3.startReplaceGroup(-847257813);
                                                            ComposerKt.sourceInformation(composer3, "84@6543L40,84@6664L11,84@6442L17,84@6427L281");
                                                            boolean z2 = !$submitting;
/* 85 */                                                    RoundedCornerShape roundedCornerShapeM1205RoundedCornerShape0680j_5 = RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16));
                                                            Composer composer10 = composer3;
                                                            ButtonColors buttonColorsM2400outlinedButtonColorsro_MJ89 = ButtonDefaults.INSTANCE.m2400outlinedButtonColorsro_MJ88(0L, j, 0L, 0L, composer10, ButtonDefaults.$stable << 12, 13);
/* 85 */                                                    PaddingValues paddingValuesM834PaddingValuesYgX7TsA2 = PaddingKt.m834PaddingValuesYgX7TsA(Dp.m8404constructorimpl(8), Dp.m8404constructorimpl(12));
/* 85 */                                                    BorderStroke borderStrokeM295BorderStrokecXLIe8U2 = BorderStrokeKt.m295BorderStrokecXLIe8U(Dp.m8404constructorimpl(1), MaterialTheme.INSTANCE.getColorScheme(composer10, MaterialTheme.$stable).getOutlineVariant());
                                                            ComposerKt.sourceInformationMarkerStart(composer10, 249763983, "CC(remember):ReviewScreen.kt#9igjgp");
                                                            zChanged = composer10.changed($onGrade) | composer10.changed(rating.ordinal());
/* 615 */                                                   objRememberedValue = composer10.rememberedValue();
/* 616 */                                                   if (!zChanged) {
                                                            }
                                                            Object obj4 = new Function0() { // from class: com.xunji.flashcards.ui.screens.ReviewScreenKt$$ExternalSyntheticLambda2
                                                                @Override // kotlin.jvm.functions.Function0
                                                                public final Object invoke() {
                                                                    return ReviewScreenKt.RatingGrid$lambda$0$0$0$0$0$2$0($onGrade, rating);
                                                                }
                                                            };
/* 618 */                                                   composer10.updateRememberedValue(obj4);
/* 619 */                                                   objRememberedValue = obj4;
                                                            ComposerKt.sourceInformationMarkerEnd(composer10);
                                                            composer4 = composer10;
/* 614 */                                                   ButtonKt.OutlinedButton((Function0) objRememberedValue, modifierTestTag, z2, roundedCornerShapeM1205RoundedCornerShape0680j_5, buttonColorsM2400outlinedButtonColorsro_MJ89, null, borderStrokeM295BorderStrokecXLIe8U2, paddingValuesM834PaddingValuesYgX7TsA2, null, function3RememberComposableLambda, composer4, 817889280, 288);
                                                            composer4.endReplaceGroup();
                                                        }
/* 605 */                                               composer3 = composer4;
                                                        iterable = iterable6;
                                                        str = str;
                                                        i4 = i4;
                                                        i5 = i5;
                                                        function1 = function1;
                                                        rowScope = rowScope3;
                                                        modifierMaterializeModifier = modifier7;
                                                        i3 = i16;
                                                        modifier2 = modifier8;
                                                    }
                                                    Composer composer11 = composer3;
                                                    composer11.endReplaceGroup();
/* 79 */                                            ComposerKt.sourceInformationMarkerEnd(composer11);
/* 575 */                                           ComposerKt.sourceInformationMarkerEnd(composer3);
/* 622 */                                           composer2.endNode();
/* 584 */                                           ComposerKt.sourceInformationMarkerEnd(composer2);
/* 578 */                                           ComposerKt.sourceInformationMarkerEnd(composer2);
/* 567 */                                           ComposerKt.sourceInformationMarkerEnd(composer2);
/* 565 */                                           iterableChunked = iterable5;
                                                    composer = composer2;
                                                    columns = columns3;
                                                    i2 = i13;
                                                    str4 = str10;
                                                    str5 = str11;
                                                }
                                                Composer composer12 = composer;
                                                composer12.endReplaceGroup();
/* 77 */                                        ComposerKt.sourceInformationMarkerEnd(composer12);
/* 535 */                                       ComposerKt.sourceInformationMarkerEnd(composer);
/* 627 */                                       $composer.endNode();
/* 544 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 538 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 527 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            } else {
                                                $composer.skipToGroupEnd();
                                            }
/* 90 */                                    return Unit.INSTANCE;
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
/* 82 */                                public static final Unit RatingGrid$lambda$0$0$0$0$0$0(String $label, ReviewUiState.Answer $answer, Rating $rating, RowScope rowScope, Composer $composer, int $changed) {
                                            Function0<ComposeUiNode> function0;
                                            Intrinsics.checkNotNullParameter(rowScope, "<this>");
                                            ComposerKt.sourceInformation($composer, "C82@5950L290:ReviewScreen.kt#i35lj1");
                                            if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventStart(1948323047, $changed, -1, "com.xunji.flashcards.ui.screens.RatingGrid.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:82)");
                                                }
/* 83 */                                        Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
/* 83 */                                        Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(3));
/* 632 */                                       ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 633 */                                       Modifier modifier = Modifier.INSTANCE;
/* 638 */                                       MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, centerHorizontally, $composer, ((432 >> 3) & 14) | ((432 >> 3) & 112));
/* 643 */                                       ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 644 */                                       int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 645 */                                       CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 646 */                                       Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 648 */                                       Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 642 */                                       int i = ((((432 << 3) & 112) << 6) & 896) | 6;
                                                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 650 */                                       if (!($composer.getApplier() instanceof Applier)) {
                                                    ComposablesKt.invalidApplier();
                                                }
/* 651 */                                       $composer.startReusableNode();
/* 652 */                                       if ($composer.getInserting()) {
/* 653 */                                           function0 = constructor;
                                                    $composer.createNode(function0);
                                                } else {
/* 655 */                                           function0 = constructor;
                                                    $composer.useNode();
                                                }
/* 657 */                                       Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 658 */                                       Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 659 */                                       Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 660 */                                       Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 662 */                                       if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 661 */                                           composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 664 */                                           composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                                                }
/* 667 */                                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 669 */                                       int i2 = (i >> 6) & 14;
/* 640 */                                       ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                                                ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                                                int i3 = ((432 >> 6) & 112) | 6;
                                                ComposerKt.sourceInformationMarkerStart($composer, -1137507844, "C82@6087L10,82@6056L53,82@6215L10,82@6110L128:ReviewScreen.kt#i35lj1");
                                                TextKt.m3584TextNvy7gAk($label, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getLabelLarge(), $composer, 0, 0, 131070);
                                                TextKt.m3584TextNvy7gAk(XunjiComponentsKt.intervalLabel(((CardSchedule) MapsKt.getValue($answer.getPreview(), $rating)).getDueAt(), System.currentTimeMillis()), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getLabelMedium(), $composer, 0, 0, 131070);
                                                ComposerKt.sourceInformationMarkerEnd($composer);
/* 640 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 670 */                                       $composer.endNode();
/* 649 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 643 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
/* 632 */                                       ComposerKt.sourceInformationMarkerEnd($composer);
                                                if (ComposerKt.isTraceInProgress()) {
                                                    ComposerKt.traceEventEnd();
                                                }
                                            } else {
/* 83 */                                        $composer.skipToGroupEnd();
                                            }
                                            return Unit.INSTANCE;
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
/* 83 */                                public static final Unit RatingGrid$lambda$0$0$0$0$0$1$0(Function1 $onGrade, Rating $rating) {
/* 84 */                                    $onGrade.invoke($rating);
                                            return Unit.INSTANCE;
                                        }

                                        /* JADX INFO: Access modifiers changed from: private */
/* 84 */                                public static final Unit RatingGrid$lambda$0$0$0$0$0$2$0(Function1 $onGrade, Rating $rating) {
/* 85 */                                    $onGrade.invoke($rating);
                                            return Unit.INSTANCE;
                                        }
                                    }

            package com.xunji.flashcards.ui.screens;

            import com.xunji.flashcards.ui.SettingsViewModel;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.internal.FunctionReferenceImpl;
            
            /* JADX INFO: compiled from: SettingsScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
/* 48 */    final /* synthetic */ class SettingsScreenKt$SettingsScreen$4$1$1 extends FunctionReferenceImpl implements Function0<Unit> {
                SettingsScreenKt$SettingsScreen$4$1$1(Object obj) {
                    super(0, obj, SettingsViewModel.class, "confirmRestore", "confirmRestore()V", 0);
                }

                @Override // kotlin.jvm.functions.Function0
/* 49 */        public /* bridge */ /* synthetic */ Unit invoke() {
/* 50 */            invoke2();
                    return Unit.INSTANCE;
                }

                /* JADX INFO: renamed from: invoke, reason: avoid collision after fix types in other method */
/* 49 */        public final void invoke2() {
/* 50 */            ((SettingsViewModel) this.receiver).confirmRestore();
                }
            }

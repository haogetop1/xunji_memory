            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.interaction.MutableInteractionSource;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.FlowLayoutKt;
            import androidx.compose.foundation.layout.FlowRowScope;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.WindowInsetsPadding_androidKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.foundation.shape.RoundedCornerShape;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.foundation.text.KeyboardActions;
            import androidx.compose.foundation.text.KeyboardOptions;
            import androidx.compose.material3.AndroidAlertDialog_androidKt;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.ChipKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.OutlinedTextFieldKt;
            import androidx.compose.material3.TextFieldColors;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.EffectsKt;
            import androidx.compose.runtime.MutableState;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.SnapshotStateKt__SnapshotStateKt;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.runtime.saveable.RememberSaveableKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.graphics.Shape;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.platform.TestTagKt;
            import androidx.compose.ui.text.TextStyle;
            import androidx.compose.ui.text.input.KeyboardType;
            import androidx.compose.ui.text.input.PlatformImeOptions;
            import androidx.compose.ui.text.input.VisualTransformation;
            import androidx.compose.ui.text.intl.LocaleList;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.model.AppSettings;
            import com.xunji.core.model.ThemeMode;
            import com.xunji.flashcards.backup.PreparedBackup;
            import com.xunji.flashcards.ui.SettingsUiState;
            import com.xunji.flashcards.ui.SettingsViewModel;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.util.Locale;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Unit;
            import kotlin.coroutines.Continuation;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.internal.DefaultConstructorMarker;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.reflect.KFunction;
            import kotlin.text.StringsKt;
            import kotlinx.coroutines.CoroutineScope;
            
            /* JADX INFO: compiled from: SettingsScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\u001aG\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00010\u00072\f\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00010\u0007H\u0007¢\u0006\u0002\u0010\n¨\u0006\u000b²\u0006\n\u0010\f\u001a\u00020\rX\u008a\u008e\u0002²\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002"}, d2 = {"SettingsScreen", "", "state", "Lcom/xunji/flashcards/ui/SettingsUiState;", "viewModel", "Lcom/xunji/flashcards/ui/SettingsViewModel;", "onExport", "Lkotlin/Function0;", "onImport", "onAnkiImport", "(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_debug", "limit", "", "limitError", ""}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 17 */    public final class SettingsScreenKt {

                /* JADX INFO: compiled from: SettingsScreen.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[ThemeMode.values().length];
                        try {
                            iArr[ThemeMode.SYSTEM.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[ThemeMode.LIGHT.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[ThemeMode.DARK.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit SettingsScreen$lambda$12(SettingsUiState settingsUiState, SettingsViewModel settingsViewModel, Function0 function0, Function0 function1, Function0 function2, int i, Composer composer, int i2) {
                    SettingsScreen(settingsUiState, settingsViewModel, function0, function1, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 18 */        public static final void SettingsScreen(final SettingsUiState state, final SettingsViewModel viewModel, final Function0<Unit> onExport, final Function0<Unit> onImport, final Function0<Unit> onAnkiImport, Composer $composer, final int $changed) {
                    Composer $composer2;
                    Object obj;
                    final SettingsViewModel viewModel2 = viewModel;
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(viewModel2, "viewModel");
                    Intrinsics.checkNotNullParameter(onExport, "onExport");
                    Intrinsics.checkNotNullParameter(onImport, "onImport");
                    Intrinsics.checkNotNullParameter(onAnkiImport, "onAnkiImport");
/* 19 */            Composer $composer3 = $composer.startRestartGroup(-1426363628);
                    ComposerKt.sourceInformation($composer3, "C(SettingsScreen)N(state,viewModel,onExport,onImport,onAnkiImport)19@857L60,19@840L77,20@937L34,21@1019L50,21@973L96,22@1221L2425,22@1071L2575:SettingsScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= ($changed & 8) == 0 ? $composer3.changed(state) : $composer3.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= ($changed & 64) == 0 ? $composer3.changed(viewModel2) : $composer3.changedInstance(viewModel2) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer3.changedInstance(onExport) ? 256 : 128;
                    }
                    if (($changed & 3072) == 0) {
                        $dirty |= $composer3.changedInstance(onImport) ? 2048 : 1024;
                    }
                    if (($changed & 24576) == 0) {
                        $dirty |= $composer3.changedInstance(onAnkiImport) ? 16384 : 8192;
                    }
                    if ($composer3.shouldExecute(($dirty & 9363) != 9362, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 19 */                    ComposerKt.traceEventStart(-1426363628, $dirty, -1, "com.xunji.flashcards.ui.screens.SettingsScreen (SettingsScreen.kt:18)");
                        }
                        Object[] objArr = new Object[0];
/* 20 */                ComposerKt.sourceInformationMarkerStart($composer3, -640873872, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean z = ($dirty & 14) == 4 || (($dirty & 8) != 0 && $composer3.changedInstance(state));
/* 53 */                Object objRememberedValue = $composer3.rememberedValue();
/* 54 */                if (z || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 20 */                    Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda18
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return SettingsScreenKt.SettingsScreen$lambda$0$0(state);
                                }
                            };
/* 56 */                    $composer3.updateRememberedValue(obj2);
/* 57 */                    objRememberedValue = obj2;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 20 */                final MutableState limit$delegate = (MutableState) RememberSaveableKt.rememberSaveable(objArr, (Function0) objRememberedValue, $composer3, 0);
/* 21 */                ComposerKt.sourceInformationMarkerStart($composer3, -640871338, "CC(remember):SettingsScreen.kt#9igjgp");
/* 59 */                Object objRememberedValue2 = $composer3.rememberedValue();
/* 60 */                if (objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 1 */                     Object objMutableStateOf$default = SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(false, null, 2, null);
/* 62 */                    $composer3.updateRememberedValue(objMutableStateOf$default);
/* 63 */                    objRememberedValue2 = objMutableStateOf$default;
                        }
/* 21 */                final MutableState limitError$delegate = (MutableState) objRememberedValue2;
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 22 */                Integer numValueOf = Integer.valueOf(state.getSettings().getNewCardsPerDay());
                        ComposerKt.sourceInformationMarkerStart($composer3, -640868698, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean zChanged = $composer3.changed(limit$delegate) | (($dirty & 14) == 4 || (($dirty & 8) != 0 && $composer3.changedInstance(state)));
/* 65 */                Object objRememberedValue3 = $composer3.rememberedValue();
/* 66 */                if (zChanged || objRememberedValue3 == Composer.INSTANCE.getEmpty()) {
                            Object obj3 = (Function2) new SettingsScreenKt$SettingsScreen$1$1(state, limit$delegate, null);
/* 68 */                    $composer3.updateRememberedValue(obj3);
/* 69 */                    objRememberedValue3 = obj3;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 22 */                EffectsKt.LaunchedEffect(numValueOf, (Function2<? super CoroutineScope, ? super Continuation<? super Unit>, ? extends Object>) objRememberedValue3, $composer3, 0);
/* 23 */                Modifier modifierImePadding = WindowInsetsPadding_androidKt.imePadding(SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null));
/* 23 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 23 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(22));
                        ComposerKt.sourceInformationMarkerStart($composer3, -640859859, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean zChanged2 = (($dirty & 14) == 4 || (($dirty & 8) != 0 && $composer3.changedInstance(state))) | $composer3.changed(limit$delegate) | (($dirty & 112) == 32 || (($dirty & 64) != 0 && $composer3.changedInstance(viewModel2))) | (($dirty & 896) == 256) | (($dirty & 7168) == 2048) | ((57344 & $dirty) == 16384);
/* 72 */                Object objRememberedValue4 = $composer3.rememberedValue();
/* 73 */                if (zChanged2 || objRememberedValue4 == Composer.INSTANCE.getEmpty()) {
/* 23 */                    obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda19
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj4) {
                                    return SettingsScreenKt.SettingsScreen$lambda$7$0(state, limit$delegate, viewModel, limitError$delegate, onExport, onImport, onAnkiImport, (LazyListScope) obj4);
                                }
                            };
/* 74 */                    viewModel2 = viewModel;
/* 75 */                    $composer3.updateRememberedValue(obj);
                        } else {
                            obj = objRememberedValue4;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer3);
/* 23 */                LazyDslKt.LazyColumn(modifierImePadding, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) obj, $composer3, 24960, 490);
/* 49 */                $composer2 = $composer3;
                        final PreparedBackup prepared = state.getPrepared();
/* 50 */                if (prepared != null) {
                            $composer2.startReplaceGroup(1610580160);
                            ComposerKt.sourceInformation($composer2, "49@3724L24,49@4034L183,49@4232L116,49@3780L239,49@3695L654");
                            ComposerKt.sourceInformationMarkerStart($composer2, -640782164, "CC(remember):SettingsScreen.kt#9igjgp");
                            boolean z2 = ($dirty & 112) == 32 || (($dirty & 64) != 0 && $composer2.changedInstance(viewModel2));
/* 78 */                    Object objRememberedValue5 = $composer2.rememberedValue();
/* 79 */                    if (z2 || objRememberedValue5 == Composer.INSTANCE.getEmpty()) {
/* 50 */                        Object obj4 = (KFunction) new SettingsScreenKt$SettingsScreen$3$1(viewModel2);
/* 81 */                        $composer2.updateRememberedValue(obj4);
/* 82 */                        objRememberedValue5 = obj4;
                            }
                            ComposerKt.sourceInformationMarkerEnd($composer2);
/* 50 */                    AndroidAlertDialog_androidKt.m2302AlertDialogOix01E0((Function0) ((KFunction) objRememberedValue5), ComposableLambdaKt.rememberComposableLambda(-1990279967, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda20
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return SettingsScreenKt.SettingsScreen$lambda$9(viewModel2, state, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, ComposableLambdaKt.rememberComposableLambda(-1970738845, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda21
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return SettingsScreenKt.SettingsScreen$lambda$10(viewModel2, state, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9006getLambda$1951197723$app_debug(), ComposableLambdaKt.rememberComposableLambda(-1941427162, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda22
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj5, Object obj6) {
                                    return SettingsScreenKt.SettingsScreen$lambda$11(prepared, state, (Composer) obj5, ((Integer) obj6).intValue());
                                }
                            }, $composer2, 54), null, 0L, 0L, 0L, 0L, 0.0f, null, $composer2, 1772592, 0, 16276);
                            $composer2 = $composer2;
                        } else {
                            $composer2.startReplaceGroup(1606893454);
                        }
                        $composer2.endReplaceGroup();
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2 = $composer3;
                        $composer2.skipToGroupEnd();
                    }
/* 51 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj5, Object obj6) {
                                return SettingsScreenKt.SettingsScreen$lambda$12(state, viewModel2, onExport, onImport, onAnkiImport, $changed, (Composer) obj5, ((Integer) obj6).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 19 */        public static final MutableState SettingsScreen$lambda$0$0(SettingsUiState $state) {
/* 1 */             return SnapshotStateKt__SnapshotStateKt.mutableStateOf$default(String.valueOf($state.getSettings().getNewCardsPerDay()), null, 2, null);
                }

/* 19 */        private static final String SettingsScreen$lambda$1(MutableState<String> mutableState) {
/* 84 */            return mutableState.getValue();
                }

/* 20 */        private static final boolean SettingsScreen$lambda$4(MutableState<Boolean> mutableState) {
/* 87 */            return mutableState.getValue().booleanValue();
                }

/* 20 */        private static final void SettingsScreen$lambda$5(MutableState<Boolean> mutableState, boolean z) {
/* 88 */            mutableState.setValue(Boolean.valueOf(z));
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 23 */        public static final Unit SettingsScreen$lambda$7$0(final SettingsUiState $state, final MutableState $limit$delegate, final SettingsViewModel $viewModel, final MutableState $limitError$delegate, final Function0 $onExport, final Function0 $onImport, final Function0 $onAnkiImport, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 24 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9003getLambda$1037137569$app_debug(), 3, null);
/* 25 */            if ($state.getError() != null) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(747608036, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$0($state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 26 */            if ($state.getMessage() != null) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(2051950797, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$1($state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 27 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(603375496, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return SettingsScreenKt.SettingsScreen$lambda$7$0$2($state, $limit$delegate, $viewModel, $limitError$delegate, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 32 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(176105767, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda5
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return SettingsScreenKt.SettingsScreen$lambda$7$0$3($state, $viewModel, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 36 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-251163962, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda6
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return SettingsScreenKt.SettingsScreen$lambda$7$0$4($state, $onExport, $onImport, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 42 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-678433691, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda7
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return SettingsScreenKt.SettingsScreen$lambda$7$0$5($onAnkiImport, $state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 47 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9004getLambda$1105703420$app_debug(), 3, null);
/* 48 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 24 */        public static final Unit SettingsScreen$lambda$7$0$0(SettingsUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C24@1303L24:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(747608036, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:24)");
                        }
/* 25 */                XunjiComponentsKt.Notice($state.getError(), true, $composer, 48, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 25 */        public static final Unit SettingsScreen$lambda$7$0$1(SettingsUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C25@1362L21:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2051950797, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:25)");
                        }
/* 26 */                XunjiComponentsKt.Notice($state.getMessage(), false, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 26 */        public static final Unit SettingsScreen$lambda$7$0$2(final SettingsUiState $state, final MutableState $limit$delegate, final SettingsViewModel $viewModel, final MutableState $limitError$delegate, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C26@1426L697,26@1395L728:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(603375496, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:26)");
                        }
/* 27 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-670894504, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda14
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$2$0($state, $limit$delegate, $viewModel, $limitError$delegate, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 31 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 27 */        public static final Unit SettingsScreen$lambda$7$0$2$0(final SettingsUiState $state, final MutableState $limit$delegate, final SettingsViewModel $viewModel, final MutableState $limitError$delegate, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C27@1464L10,27@1431L55,27@1487L37,28@1552L27,28@1817L62,28@1528L384,29@1939L139,29@1916L203:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-670894504, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:27)");
                        }
/* 28 */                TextKt.m3584TextNvy7gAk("每天的新卡", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        XunjiComponentsKt.Notice("所有牌组合计。设为 0 可暂停新卡，到期复习仍然保留。", false, $composer, 6, 2);
/* 29 */                String strSettingsScreen$lambda$1 = SettingsScreen$lambda$1($limit$delegate);
                        KeyboardOptions keyboardOptions = new KeyboardOptions(0, (Boolean) null, KeyboardType.INSTANCE.m8077getNumberPjHm6EE(), 0, (PlatformImeOptions) null, (Boolean) null, (LocaleList) null, 123, (DefaultConstructorMarker) null);
                        boolean zSettingsScreen$lambda$4 = SettingsScreen$lambda$4($limitError$delegate);
                        boolean z = !$state.getBusy();
                        Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), "new-card-limit");
/* 29 */                RoundedCornerShape roundedCornerShapeM1205RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16));
                        ComposerKt.sourceInformationMarkerStart($composer, -484519885, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean zChanged = $composer.changed($limit$delegate);
/* 91 */                Object objRememberedValue = $composer.rememberedValue();
/* 92 */                if (zChanged || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                            Object obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda8
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return SettingsScreenKt.SettingsScreen$lambda$7$0$2$0$0$0($limit$delegate, $limitError$delegate, (String) obj2);
                                }
                            };
/* 94 */                    $composer.updateRememberedValue(obj);
/* 95 */                    objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 29 */                OutlinedTextFieldKt.OutlinedTextField(strSettingsScreen$lambda$1, (Function1<? super String, Unit>) objRememberedValue, modifierTestTag, z, false, (TextStyle) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$SettingsScreenKt.INSTANCE.m9005getLambda$1235225230$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) null, (Function2<? super Composer, ? super Integer, Unit>) ComposableSingletons$SettingsScreenKt.INSTANCE.getLambda$164190816$app_debug(), (Function2<? super Composer, ? super Integer, Unit>) ComposableLambdaKt.rememberComposableLambda(1020840959, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$2$0$1($limitError$delegate, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), zSettingsScreen$lambda$4, (VisualTransformation) null, keyboardOptions, (KeyboardActions) null, true, 0, 0, (MutableInteractionSource) null, (Shape) roundedCornerShapeM1205RoundedCornerShape0680j_4, (TextFieldColors) null, $composer, 1573248, 12779952, 0, 6113200);
/* 30 */                ComposerKt.sourceInformationMarkerStart($composer, -484507389, "CC(remember):SettingsScreen.kt#9igjgp");
/* 30 */                boolean zChanged2 = $composer.changed($limit$delegate) | $composer.changedInstance($viewModel) | $composer.changedInstance($state);
/* 97 */                Object objRememberedValue2 = $composer.rememberedValue();
/* 98 */                if (zChanged2 || objRememberedValue2 == Composer.INSTANCE.getEmpty()) {
/* 30 */                    Object obj2 = new Function0() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda10
                                @Override // kotlin.jvm.functions.Function0
                                public final Object invoke() {
                                    return SettingsScreenKt.SettingsScreen$lambda$7$0$2$0$2$0($viewModel, $state, $limit$delegate, $limitError$delegate);
                                }
                            };
/* 100 */                   $composer.updateRememberedValue(obj2);
/* 101 */                   objRememberedValue2 = obj2;
                        }
/* 30 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 30 */                XunjiComponentsKt.PrimaryButton("保存学习设置", (Function0) objRememberedValue2, null, !$state.getBusy(), "save-settings", $composer, 24582, 4);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 31 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 28 */        public static final Unit SettingsScreen$lambda$7$0$2$0$0$0(MutableState $limit$delegate, MutableState $limitError$delegate, String it) {
                    Intrinsics.checkNotNullParameter(it, "it");
/* 85 */            $limit$delegate.setValue(it);
                    SettingsScreen$lambda$5($limitError$delegate, false);
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 28 */        public static final Unit SettingsScreen$lambda$7$0$2$0$1(MutableState $limitError$delegate, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C28@1818L60:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1020840959, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:28)");
                        }
/* 29 */                TextKt.m3584TextNvy7gAk(SettingsScreen$lambda$4($limitError$delegate) ? "请输入 0～100 的整数" : "0～100 张 · 默认 20 张", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:12:0x002e  */
/* 29 */        public static final Unit SettingsScreen$lambda$7$0$2$0$2$0(SettingsViewModel $viewModel, SettingsUiState $state, MutableState $limit$delegate, MutableState $limitError$delegate) {
/* 30 */            Integer n = StringsKt.toIntOrNull(SettingsScreen$lambda$1($limit$delegate));
                    if (n != null) {
                        int iIntValue = n.intValue();
                        boolean z = false;
                        if (iIntValue >= 0 && iIntValue < 101) {
                            z = true;
                        }
                        if (z) {
                            $viewModel.saveSettings(AppSettings.copy$default($state.getSettings(), n.intValue(), null, 0, 6, null));
                        } else {
                            SettingsScreen$lambda$5($limitError$delegate, true);
                        }
                    } else {
                        SettingsScreen$lambda$5($limitError$delegate, true);
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 31 */        public static final Unit SettingsScreen$lambda$7$0$3(final SettingsUiState $state, final SettingsViewModel $viewModel, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C31@2166L528,31@2135L559:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(176105767, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:31)");
                        }
/* 32 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1098164233, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda15
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$3$0($state, $viewModel, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 35 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 32 */        public static final Unit SettingsScreen$lambda$7$0$3$0(final SettingsUiState $state, final SettingsViewModel $viewModel, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C32@2203L10,32@2171L54,33@2335L355,33@2229L461:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1098164233, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:32)");
                        }
/* 33 */                TextKt.m3584TextNvy7gAk("界面主题", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
/* 34 */                FlowLayoutKt.FlowRow(null, Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(10)), Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(6)), null, 0, 0, ComposableLambdaKt.rememberComposableLambda(444434524, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda17
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$3$0$0($state, $viewModel, (FlowRowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 1573296, 57);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 35 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 33 */        public static final Unit SettingsScreen$lambda$7$0$3$0$0(final SettingsUiState $state, final SettingsViewModel $viewModel, FlowRowScope FlowRow, Composer $composer, int $changed) {
                    Composer composer = $composer;
                    Intrinsics.checkNotNullParameter(FlowRow, "$this$FlowRow");
                    ComposerKt.sourceInformation(composer, "C*33@2430L61,33@2518L87,33@2371L315:SettingsScreen.kt#i35lj1");
                    boolean z = true;
                    if (composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(444434524, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:33)");
                        }
                        for (final ThemeMode themeMode : ThemeMode.getEntries()) {
/* 34 */                    boolean z2 = $state.getSettings().getThemeMode() == themeMode ? z : false;
                            boolean busy = $state.getBusy() ^ z;
/* 34 */                    Modifier modifierM880heightInVpY3zN4$default = SizeKt.m880heightInVpY3zN4$default(Modifier.INSTANCE, Dp.m8404constructorimpl(48), 0.0f, 2, null);
                            String lowerCase = themeMode.name().toLowerCase(Locale.ROOT);
                            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                            Modifier modifierTestTag = TestTagKt.testTag(modifierM880heightInVpY3zN4$default, "theme-" + lowerCase);
                            ComposerKt.sourceInformationMarkerStart(composer, -1319851346, "CC(remember):SettingsScreen.kt#9igjgp");
                            boolean zChangedInstance = composer.changedInstance($viewModel) | composer.changedInstance($state) | composer.changed(themeMode.ordinal());
/* 105 */                   Object objRememberedValue = $composer.rememberedValue();
/* 106 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 34 */                        Object obj = new Function0() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function0
                                    public final Object invoke() {
                                        return SettingsScreenKt.SettingsScreen$lambda$7$0$3$0$0$0$0$0($viewModel, $state, themeMode);
                                    }
                                };
/* 108 */                       $composer.updateRememberedValue(obj);
/* 109 */                       objRememberedValue = obj;
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer);
/* 34 */                    ChipKt.FilterChip(z2, (Function0) objRememberedValue, ComposableLambdaKt.rememberComposableLambda(-1313837180, z, new Function2() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda11
                                @Override // kotlin.jvm.functions.Function2
                                public final Object invoke(Object obj2, Object obj3) {
                                    return SettingsScreenKt.SettingsScreen$lambda$7$0$3$0$0$0$1(themeMode, (Composer) obj2, ((Integer) obj3).intValue());
                                }
                            }, composer, 54), modifierTestTag, busy, null, null, null, null, null, null, null, composer, 384, 0, 4064);
                            composer = $composer;
                            z = z;
                        }
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 34 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 33 */        public static final Unit SettingsScreen$lambda$7$0$3$0$0$0$0$0(SettingsViewModel $viewModel, SettingsUiState $state, ThemeMode $mode) {
/* 34 */            $viewModel.saveSettings(AppSettings.copy$default($state.getSettings(), 0, $mode, 0, 5, null));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 33 */        public static final Unit SettingsScreen$lambda$7$0$3$0$0$0$1(ThemeMode $mode, Composer $composer, int $changed) {
                    String str;
                    ComposerKt.sourceInformation($composer, "C33@2519L85:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1313837180, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:33)");
                        }
                        switch (WhenMappings.$EnumSwitchMapping$0[$mode.ordinal()]) {
                            case 1:
                                str = "跟随系统";
                                break;
                            case 2:
                                str = "浅色";
                                break;
                            case 3:
                                str = "深色";
                                break;
                            default:
                                throw new NoWhenBranchMatchedException();
                        }
                        TextKt.m3584TextNvy7gAk(str, null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 35 */        public static final Unit SettingsScreen$lambda$7$0$4(final SettingsUiState $state, final Function0 $onExport, final Function0 $onImport, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C35@2737L456,35@2706L487:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-251163962, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:35)");
                        }
/* 36 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1525433962, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda16
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$4$0($state, $onExport, $onImport, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 41 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 36 */        public static final Unit SettingsScreen$lambda$7$0$4$0(SettingsUiState $state, Function0 $onExport, Function0 $onImport, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C36@2777L10,36@2742L57,36@2800L73,37@2877L97,38@2978L163,39@3145L44:SettingsScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 36 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1525433962, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:36)");
                        }
/* 37 */                TextKt.m3584TextNvy7gAk("把记忆好好保存", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        XunjiComponentsKt.Notice("导出循记 V2 备份（.xunji.zip），包含卡片、复习进度、设置及 Anki 模板和媒体。请将重要备份保存在可靠的位置。", false, $composer, 6, 2);
/* 38 */                XunjiComponentsKt.PrimaryButton($state.getBusy() ? "正在处理…" : "导出备份", $onExport, null, !$state.getBusy(), "export-backup", $composer, 24576, 4);
/* 39 */                ButtonKt.OutlinedButton($onImport, TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(56), 0.0f, 2, null), "import-backup"), !$state.getBusy(), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(18)), null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9007getLambda$492772856$app_debug(), $composer, 805306416, 496);
/* 40 */                XunjiComponentsKt.Notice("恢复会替换当前全部数据。支持循记 V2 备份及旧版 V1 JSON。", false, $composer, 6, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 41 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 41 */        public static final Unit SettingsScreen$lambda$7$0$5(final Function0 $onAnkiImport, final SettingsUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C41@3236L303,41@3205L334:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-678433691, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:41)");
                        }
/* 42 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1952703691, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda13
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return SettingsScreenKt.SettingsScreen$lambda$7$0$5$0($onAnkiImport, $state, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 46 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 42 */        public static final Unit SettingsScreen$lambda$7$0$5$0(Function0 $onAnkiImport, SettingsUiState $state, ColumnScope Paper, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C42@3279L10,42@3241L60,43@3305L56,44@3365L170:SettingsScreen.kt#i35lj1");
                    if (!$composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
/* 42 */                $composer.skipToGroupEnd();
                    } else {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1952703691, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:42)");
                        }
/* 43 */                TextKt.m3584TextNvy7gAk("导入 Anki 牌组", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
/* 44 */                XunjiComponentsKt.Notice("选择 .apkg 文件，先查看兼容性和受影响卡片，再确认导入。已有卡片与复习进度不会被覆盖。", false, $composer, 6, 2);
/* 44 */                ButtonKt.OutlinedButton($onAnkiImport, TestTagKt.testTag(SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(56), 0.0f, 2, null), "import-anki"), !$state.getBusy(), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(18)), null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9009getLambda$920042585$app_debug(), $composer, 805306416, 496);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    }
/* 46 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit SettingsScreen$lambda$10(SettingsViewModel $viewModel, SettingsUiState $state, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C49@4244L24,49@4233L113:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1970738845, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                ComposerKt.sourceInformationMarkerStart($composer, 200547899, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer.changedInstance($viewModel);
/* 114 */               Object objRememberedValue = $composer.rememberedValue();
/* 115 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 50 */                    Object obj = (KFunction) new SettingsScreenKt$SettingsScreen$5$1$1($viewModel);
/* 117 */                   $composer.updateRememberedValue(obj);
/* 118 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 50 */                ButtonKt.TextButton((Function0) ((KFunction) objRememberedValue), TestTagKt.testTag(Modifier.INSTANCE, "restore-cancel"), true ^ $state.getBusy(), null, null, null, null, null, null, ComposableSingletons$SettingsScreenKt.INSTANCE.m9008getLambda$607905248$app_debug(), $composer, 805306416, 504);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:28:0x01c3  */
                /* JADX WARN: Code duplicated, block: B:29:0x01da  */
                /* JADX WARN: Code duplicated, block: B:32:0x01ff  */
/* 49 */        public static final Unit SettingsScreen$lambda$11(PreparedBackup $prepared, SettingsUiState $state, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    int i;
                    ComposerKt.sourceInformation($composer, "C49@3781L237:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1941427162, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(12));
/* 121 */               ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 122 */               Modifier modifier = Modifier.INSTANCE;
/* 127 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 132 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 133 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 134 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 135 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 137 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 131 */               int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
/* 138 */               ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 139 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 140 */               $composer.startReusableNode();
/* 141 */               if ($composer.getInserting()) {
/* 142 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 144 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 146 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 147 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 148 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 149 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 151 */               if (composerM4979constructorimpl.getInserting()) {
                            i = 48;
                        } else {
                            i = 48;
/* 150 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 156 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 158 */                   int i3 = (i2 >> 6) & 14;
/* 129 */                   ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                            int i4 = ((i >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -715823594, "C49@3839L92,49@3932L38:SettingsScreen.kt#i35lj1");
                            TextKt.m3584TextNvy7gAk("备份包含 " + $prepared.getDeckCount() + " 个牌组、" + $prepared.getCardCount() + " 张卡片、" + $prepared.getLogCount() + " 条评分记录。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                            TextKt.m3584TextNvy7gAk("当前牌组、卡片和记录将被替换，无法撤回。建议先导出当前数据。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                            if ($state.getError() != null) {
                                $composer.startReplaceGroup(808197652);
                                ComposerKt.sourceInformation($composer, "49@3992L24");
                                XunjiComponentsKt.Notice($state.getError(), true, $composer, 48, 0);
                            } else {
                                $composer.startReplaceGroup(-719638362);
                            }
                            $composer.endReplaceGroup();
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 129 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 159 */                   $composer.endNode();
/* 138 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 132 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 121 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 150 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 153 */               composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
/* 156 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 158 */               int i5 = (i2 >> 6) & 14;
/* 129 */               ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                        int i6 = ((i >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -715823594, "C49@3839L92,49@3932L38:SettingsScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk("备份包含 " + $prepared.getDeckCount() + " 个牌组、" + $prepared.getCardCount() + " 张卡片、" + $prepared.getLogCount() + " 条评分记录。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
                        TextKt.m3584TextNvy7gAk("当前牌组、卡片和记录将被替换，无法撤回。建议先导出当前数据。", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 6, 0, 262142);
                        if ($state.getError() != null) {
                            $composer.startReplaceGroup(808197652);
                            ComposerKt.sourceInformation($composer, "49@3992L24");
                            XunjiComponentsKt.Notice($state.getError(), true, $composer, 48, 0);
                        } else {
                            $composer.startReplaceGroup(-719638362);
                        }
                        $composer.endReplaceGroup();
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 129 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 159 */               $composer.endNode();
/* 138 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 132 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 121 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 50 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit SettingsScreen$lambda$9(SettingsViewModel $viewModel, final SettingsUiState $state, Composer $composer, int $changed) {
                    ComposerKt.sourceInformation($composer, "C49@4046L25,49@4138L78,49@4035L181:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1990279967, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                ComposerKt.sourceInformationMarkerStart($composer, -1398601158, "CC(remember):SettingsScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer.changedInstance($viewModel);
/* 114 */               Object objRememberedValue = $composer.rememberedValue();
/* 115 */               if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 50 */                    Object obj = (KFunction) new SettingsScreenKt$SettingsScreen$4$1$1($viewModel);
/* 117 */                   $composer.updateRememberedValue(obj);
/* 118 */                   objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 50 */                ButtonKt.TextButton((Function0) ((KFunction) objRememberedValue), TestTagKt.testTag(Modifier.INSTANCE, "restore-confirm"), !$state.getBusy(), null, null, null, null, null, null, ComposableLambdaKt.rememberComposableLambda(-627446370, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.SettingsScreenKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj2, Object obj3, Object obj4) {
                                return SettingsScreenKt.SettingsScreen$lambda$9$1($state, (RowScope) obj2, (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }, $composer, 54), $composer, 805306416, 504);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 49 */        public static final Unit SettingsScreen$lambda$9$1(SettingsUiState $state, RowScope TextButton, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(TextButton, "$this$TextButton");
                    ComposerKt.sourceInformation($composer, "C49@4197L11,49@4139L76:SettingsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-627446370, $changed, -1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous> (SettingsScreen.kt:49)");
                        }
/* 50 */                TextKt.m3584TextNvy7gAk($state.getBusy() ? "恢复中…" : "确认替换", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getError(), null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262138);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

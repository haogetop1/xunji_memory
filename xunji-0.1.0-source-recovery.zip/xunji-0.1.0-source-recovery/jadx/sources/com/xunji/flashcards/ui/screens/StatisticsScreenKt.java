            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.BackgroundKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.BoxKt;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.material3.DividerKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.draw.ClipKt;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.semantics.SemanticsModifierKt;
            import androidx.compose.ui.semantics.SemanticsPropertiesKt;
            import androidx.compose.ui.semantics.SemanticsPropertyReceiver;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.stats.DaySummary;
            import com.xunji.core.stats.StatisticsSummary;
            import com.xunji.flashcards.ui.MainUiState;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import java.util.Iterator;
            import java.util.NoSuchElementException;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.collections.CollectionsKt;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            import kotlin.ranges.RangesKt;
            
            /* JADX INFO: compiled from: StatisticsScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0007¢\u0006\u0002\u0010\u0004¨\u0006\u0005"}, d2 = {"StatisticsScreen", "", "state", "Lcom/xunji/flashcards/ui/MainUiState;", "(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 14 */    public final class StatisticsScreenKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit StatisticsScreen$lambda$1(MainUiState mainUiState, int i, Composer composer, int i2) {
                    StatisticsScreen(mainUiState, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 15 */        public static final void StatisticsScreen(final MainUiState state, Composer $composer, final int $changed) {
                    Intrinsics.checkNotNullParameter(state, "state");
/* 16 */            Composer $composer2 = $composer.startRestartGroup(-1500401467);
                    ComposerKt.sourceInformation($composer2, "C(StatisticsScreen)N(state)17@759L2230,17@622L2367:StatisticsScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changedInstance(state) ? 4 : 2;
                    }
                    if ($composer2.shouldExecute(($dirty & 3) != 2, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 16 */                    ComposerKt.traceEventStart(-1500401467, $dirty, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen (StatisticsScreen.kt:15)");
                        }
/* 17 */                final StatisticsSummary stats = state.getStatistics();
/* 18 */                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 18 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 18 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(22));
                        ComposerKt.sourceInformationMarkerStart($composer2, 1223210555, "CC(remember):StatisticsScreen.kt#9igjgp");
                        boolean zChangedInstance = $composer2.changedInstance(stats);
/* 40 */                Object objRememberedValue = $composer2.rememberedValue();
/* 41 */                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 18 */                    Object obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda7
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return StatisticsScreenKt.StatisticsScreen$lambda$0$0(stats, (LazyListScope) obj2);
                                }
                            };
/* 43 */                    $composer2.updateRememberedValue(obj);
/* 44 */                    objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 18 */                LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, $composer2, 24966, 490);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2.skipToGroupEnd();
                    }
/* 37 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$1(state, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:9:0x0037  */
/* 18 */        public static final Unit StatisticsScreen$lambda$0$0(final StatisticsSummary $stats, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 19 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$StatisticsScreenKt.INSTANCE.getLambda$1383379216$app_debug(), 3, null);
                    if ($stats != null) {
                        Iterator<T> it = $stats.getLastSevenDays().iterator();
                        int scoreCount = 0;
                        while (it.hasNext()) {
/* 20 */                    scoreCount += ((DaySummary) it.next()).getScoreCount();
                        }
                        if (scoreCount == 0) {
/* 20 */                    LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$StatisticsScreenKt.INSTANCE.getLambda$253803925$app_debug(), 3, null);
                        }
                    } else {
/* 20 */                LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$StatisticsScreenKt.INSTANCE.getLambda$253803925$app_debug(), 3, null);
                    }
/* 21 */            if ($stats != null) {
/* 20 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(410750, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda1
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$1($stats, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
/* 20 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(2105205543, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda2
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$2($stats, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
/* 20 */                LazyListScope.items$default(LazyColumn, $stats.getLastSevenDays().size(), null, null, ComposableLambdaKt.composableLambdaInstance(-1700612523, true, new Function4() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function4
                            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$3($stats, (LazyItemScope) obj, ((Integer) obj2).intValue(), (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }), 6, null);
                    }
/* 20 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$StatisticsScreenKt.INSTANCE.m9011getLambda$1104460487$app_debug(), 3, null);
/* 36 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 21 */        public static final Unit StatisticsScreen$lambda$0$0$1(final StatisticsSummary $stats, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C21@990L512,21@959L543:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(410750, $changed, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:21)");
                        }
/* 22 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1347350706, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda4
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$1$0($stats, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:28:0x024d  */
                /* JADX WARN: Code duplicated, block: B:31:0x0259  */
                /* JADX WARN: Code duplicated, block: B:32:0x025f  */
                /* JADX WARN: Code duplicated, block: B:35:0x0290  */
                /* JADX WARN: Code duplicated, block: B:38:0x02a3  */
                /* JADX WARN: Code duplicated, block: B:39:0x02a6  */
                /* JADX WARN: Code duplicated, block: B:43:0x02fe  */
                /* JADX WARN: Code duplicated, block: B:45:0x0323  */
                /* JADX WARN: Code duplicated, block: B:48:0x0383  */
/* 21 */        public static final Unit StatisticsScreen$lambda$0$0$1$0(StatisticsSummary $stats, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Composer composer;
                    int iHashCode;
                    Function0<ComposeUiNode> constructor;
                    Function0<ComposeUiNode> function1;
                    Composer composerM4979constructorimpl;
                    int i;
                    Composer composer2;
                    Double againRatio;
                    String str;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C21@992L13,21@1006L199,21@1244L11,21@1206L65,21@1272L228:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1347350706, $changed, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:21)");
                        }
/* 22 */                XunjiComponentsKt.Eyebrow("今天", $composer, 6);
/* 22 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 48 */                ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 49 */                Modifier modifier = Modifier.INSTANCE;
/* 54 */                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 60 */                int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 61 */                CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 62 */                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 64 */                Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 58 */                int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 66 */                if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 67 */                $composer.startReusableNode();
/* 68 */                if ($composer.getInserting()) {
/* 69 */                    function0 = constructor2;
                            $composer.createNode(function0);
                        } else {
/* 71 */                    function0 = constructor2;
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer);
/* 74 */                Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 75 */                Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 76 */                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 78 */                if (composerM4979constructorimpl2.getInserting()) {
                            composer = $composer;
                        } else {
                            composer = $composer;
/* 77 */                    if (!Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            }
/* 83 */                    Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                    int i3 = (i2 >> 6) & 14;
                            Composer composer3 = composer;
/* 56 */                    ComposerKt.sourceInformationMarkerStart(composer3, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            int i4 = ((48 >> 6) & 112) | 6;
                            RowScope rowScope = RowScopeInstance.INSTANCE;
/* 22 */                    ComposerKt.sourceInformationMarkerStart(composer3, -1916641595, "C21@1063L68,21@1132L71:StatisticsScreen.kt#i35lj1");
                            XunjiComponentsKt.Metric(String.valueOf($stats.getToday().getScoreCount()), "评分次数", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), composer3, 48, 0);
                            XunjiComponentsKt.Metric(String.valueOf($stats.getToday().getDistinctCards()), "学习卡片", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), composer3, 48, 0);
                            ComposerKt.sourceInformationMarkerEnd(composer3);
/* 56 */                    ComposerKt.sourceInformationMarkerEnd(composer3);
/* 86 */                    composer.endNode();
/* 65 */                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 59 */                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 48 */                    ComposerKt.sourceInformationMarkerEnd(composer);
/* 22 */                    DividerKt.m2731HorizontalDivider9IZ8Weo(null, 0.0f, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOutlineVariant(), $composer, 0, 3);
/* 22 */                    Arrangement.Horizontal horizontalM699spacedBy0680j_5 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 48 */                    ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 90 */                    Modifier modifier2 = Modifier.INSTANCE;
/* 95 */                    MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_5, Alignment.INSTANCE.getTop(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 59 */                    ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 60 */                    iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 61 */                    CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
/* 62 */                    Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifier2);
/* 64 */                    constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 99 */                    int i5 = ((((48 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 66 */                    if (!($composer.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 67 */                    $composer.startReusableNode();
/* 68 */                    if ($composer.getInserting()) {
/* 69 */                        function1 = constructor;
                                $composer.createNode(function1);
                            } else {
/* 71 */                        function1 = constructor;
                                $composer.useNode();
                            }
/* 73 */                    composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 100 */                   Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 101 */                   Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 102 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 78 */                    if (composerM4979constructorimpl.getInserting()) {
                                i = 48;
                                composer2 = $composer;
                            } else {
                                i = 48;
                                composer2 = $composer;
/* 77 */                        if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                                }
/* 103 */                       Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                        int i6 = (i5 >> 6) & 14;
                                Composer composer4 = composer2;
/* 97 */                        ComposerKt.sourceInformationMarkerStart(composer4, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                                int i7 = ((i >> 6) & 112) | 6;
                                RowScope rowScope2 = RowScopeInstance.INSTANCE;
                                ComposerKt.sourceInformationMarkerStart(composer4, -1085263247, "C21@1329L96,21@1426L72:StatisticsScreen.kt#i35lj1");
                                againRatio = $stats.getToday().getAgainRatio();
                                if (againRatio != null) {
/* 22 */                            str = ((int) (((double) 100) * againRatio.doubleValue())) + "%";
                                    if (str == null) {
                                        str = "—";
                                    }
                                } else {
                                    str = "—";
                                }
                                XunjiComponentsKt.Metric(str, "忘记比例", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), composer4, 48, 0);
                                XunjiComponentsKt.Metric(XunjiComponentsKt.durationLabel($stats.getToday().getDurationMs()), "有效用时", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), composer4, 48, 0);
                                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 97 */                        ComposerKt.sourceInformationMarkerEnd(composer4);
/* 86 */                        composer2.endNode();
/* 65 */                        ComposerKt.sourceInformationMarkerEnd(composer2);
/* 59 */                        ComposerKt.sourceInformationMarkerEnd(composer2);
/* 48 */                        ComposerKt.sourceInformationMarkerEnd(composer2);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                            }
/* 77 */                    composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 80 */                    composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash2);
/* 103 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                    int i8 = (i5 >> 6) & 14;
                            Composer composer5 = composer2;
/* 97 */                    ComposerKt.sourceInformationMarkerStart(composer5, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            int i9 = ((i >> 6) & 112) | 6;
                            RowScope rowScope3 = RowScopeInstance.INSTANCE;
                            ComposerKt.sourceInformationMarkerStart(composer5, -1085263247, "C21@1329L96,21@1426L72:StatisticsScreen.kt#i35lj1");
                            againRatio = $stats.getToday().getAgainRatio();
                            if (againRatio != null) {
/* 22 */                        str = ((int) (((double) 100) * againRatio.doubleValue())) + "%";
                                if (str == null) {
                                    str = "—";
                                }
                            } else {
                                str = "—";
                            }
                            XunjiComponentsKt.Metric(str, "忘记比例", RowScope.weight$default(rowScope3, Modifier.INSTANCE, 1.0f, false, 2, null), composer5, 48, 0);
                            XunjiComponentsKt.Metric(XunjiComponentsKt.durationLabel($stats.getToday().getDurationMs()), "有效用时", RowScope.weight$default(rowScope3, Modifier.INSTANCE, 1.0f, false, 2, null), composer5, 48, 0);
                            ComposerKt.sourceInformationMarkerEnd(composer5);
/* 97 */                    ComposerKt.sourceInformationMarkerEnd(composer5);
/* 86 */                    composer2.endNode();
/* 65 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 59 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 48 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 77 */                composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 80 */                composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash);
/* 83 */                Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                int i10 = (i2 >> 6) & 14;
                        Composer composer6 = composer;
/* 56 */                ComposerKt.sourceInformationMarkerStart(composer6, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        int i11 = ((48 >> 6) & 112) | 6;
                        RowScope rowScope4 = RowScopeInstance.INSTANCE;
/* 22 */                ComposerKt.sourceInformationMarkerStart(composer6, -1916641595, "C21@1063L68,21@1132L71:StatisticsScreen.kt#i35lj1");
                        XunjiComponentsKt.Metric(String.valueOf($stats.getToday().getScoreCount()), "评分次数", RowScope.weight$default(rowScope4, Modifier.INSTANCE, 1.0f, false, 2, null), composer6, 48, 0);
                        XunjiComponentsKt.Metric(String.valueOf($stats.getToday().getDistinctCards()), "学习卡片", RowScope.weight$default(rowScope4, Modifier.INSTANCE, 1.0f, false, 2, null), composer6, 48, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer6);
/* 56 */                ComposerKt.sourceInformationMarkerEnd(composer6);
/* 86 */                composer.endNode();
/* 65 */                ComposerKt.sourceInformationMarkerEnd(composer);
/* 59 */                ComposerKt.sourceInformationMarkerEnd(composer);
/* 48 */                ComposerKt.sourceInformationMarkerEnd(composer);
/* 22 */                DividerKt.m2731HorizontalDivider9IZ8Weo(null, 0.0f, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOutlineVariant(), $composer, 0, 3);
/* 22 */                Arrangement.Horizontal horizontalM699spacedBy0680j_6 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 48 */                ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 90 */                Modifier modifier3 = Modifier.INSTANCE;
/* 95 */                MeasurePolicy measurePolicyRowMeasurePolicy3 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_6, Alignment.INSTANCE.getTop(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 59 */                ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 60 */                iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 61 */                CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
/* 62 */                Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifier3);
/* 64 */                constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 99 */                int i12 = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 66 */                if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 67 */                $composer.startReusableNode();
/* 68 */                if ($composer.getInserting()) {
/* 69 */                    function1 = constructor;
                            $composer.createNode(function1);
                        } else {
/* 71 */                    function1 = constructor;
                            $composer.useNode();
                        }
/* 73 */                composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 100 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 101 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 102 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 78 */                if (composerM4979constructorimpl.getInserting()) {
                            i = 48;
                            composer2 = $composer;
/* 77 */                    if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                            }
/* 103 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                    int i13 = (i12 >> 6) & 14;
                            Composer composer7 = composer2;
/* 97 */                    ComposerKt.sourceInformationMarkerStart(composer7, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            int i14 = ((i >> 6) & 112) | 6;
                            RowScope rowScope5 = RowScopeInstance.INSTANCE;
                            ComposerKt.sourceInformationMarkerStart(composer7, -1085263247, "C21@1329L96,21@1426L72:StatisticsScreen.kt#i35lj1");
                            againRatio = $stats.getToday().getAgainRatio();
                            if (againRatio != null) {
/* 22 */                        str = ((int) (((double) 100) * againRatio.doubleValue())) + "%";
                                if (str == null) {
                                    str = "—";
                                }
                            } else {
                                str = "—";
                            }
                            XunjiComponentsKt.Metric(str, "忘记比例", RowScope.weight$default(rowScope5, Modifier.INSTANCE, 1.0f, false, 2, null), composer7, 48, 0);
                            XunjiComponentsKt.Metric(XunjiComponentsKt.durationLabel($stats.getToday().getDurationMs()), "有效用时", RowScope.weight$default(rowScope5, Modifier.INSTANCE, 1.0f, false, 2, null), composer7, 48, 0);
                            ComposerKt.sourceInformationMarkerEnd(composer7);
/* 97 */                    ComposerKt.sourceInformationMarkerEnd(composer7);
/* 86 */                    composer2.endNode();
/* 65 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 59 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
/* 48 */                    ComposerKt.sourceInformationMarkerEnd(composer2);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        } else {
                            i = 48;
                            composer2 = $composer;
                        }
/* 77 */                composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 80 */                composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash3);
/* 103 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 85 */                int i15 = (i12 >> 6) & 14;
                        Composer composer8 = composer2;
/* 97 */                ComposerKt.sourceInformationMarkerStart(composer8, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        int i16 = ((i >> 6) & 112) | 6;
                        RowScope rowScope6 = RowScopeInstance.INSTANCE;
                        ComposerKt.sourceInformationMarkerStart(composer8, -1085263247, "C21@1329L96,21@1426L72:StatisticsScreen.kt#i35lj1");
                        againRatio = $stats.getToday().getAgainRatio();
                        if (againRatio != null) {
/* 22 */                    str = ((int) (((double) 100) * againRatio.doubleValue())) + "%";
                            if (str == null) {
                                str = "—";
                            }
                        } else {
                            str = "—";
                        }
                        XunjiComponentsKt.Metric(str, "忘记比例", RowScope.weight$default(rowScope6, Modifier.INSTANCE, 1.0f, false, 2, null), composer8, 48, 0);
                        XunjiComponentsKt.Metric(XunjiComponentsKt.durationLabel($stats.getToday().getDurationMs()), "有效用时", RowScope.weight$default(rowScope6, Modifier.INSTANCE, 1.0f, false, 2, null), composer8, 48, 0);
                        ComposerKt.sourceInformationMarkerEnd(composer8);
/* 97 */                ComposerKt.sourceInformationMarkerEnd(composer8);
/* 86 */                composer2.endNode();
/* 65 */                ComposerKt.sourceInformationMarkerEnd(composer2);
/* 59 */                ComposerKt.sourceInformationMarkerEnd(composer2);
/* 48 */                ComposerKt.sourceInformationMarkerEnd(composer2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 22 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 22 */        public static final Unit StatisticsScreen$lambda$0$0$2(final StatisticsSummary $stats, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C22@1546L985,22@1515L1016:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2105205543, $changed, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:22)");
                        }
/* 23 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-308397577, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda5
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$2$0($stats, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 32 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 22 */        public static final Unit StatisticsScreen$lambda$0$0$2$0(StatisticsSummary $stats, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    long primaryContainer;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C22@1582L10,22@1548L56,22@1605L21,24@1704L822:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-308397577, $changed, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:22)");
                        }
/* 23 */                TextKt.m3584TextNvy7gAk("最近 7 天", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        XunjiComponentsKt.Notice("评分次数 · 包含今天", false, $composer, 6, 2);
/* 24 */                Iterator<T> it = $stats.getLastSevenDays().iterator();
                        if (!it.hasNext()) {
/* 24 */                    throw new NoSuchElementException();
                        }
/* 24 */                int scoreCount = ((DaySummary) it.next()).getScoreCount();
                        while (it.hasNext()) {
/* 24 */                    int scoreCount2 = ((DaySummary) it.next()).getScoreCount();
                            if (scoreCount < scoreCount2) {
                                scoreCount = scoreCount2;
                            }
                        }
                        int max = RangesKt.coerceAtLeast(scoreCount, 1);
/* 25 */                Modifier modifierM878height3ABfNKs = SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(152));
/* 25 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
                        Alignment.Vertical bottom = Alignment.INSTANCE.getBottom();
/* 110 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 111 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, bottom, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
/* 116 */               int i = 6;
                        String str = "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh";
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 117 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 118 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 119 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM878height3ABfNKs);
/* 121 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 115 */               int i2 = ((((438 << 3) & 112) << 6) & 896) | 6;
                        String str2 = "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp";
/* 122 */               ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 123 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 124 */               $composer.startReusableNode();
/* 125 */               if ($composer.getInserting()) {
/* 126 */                   $composer.createNode(constructor);
                        } else {
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 131 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 132 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 133 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 135 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 134 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 137 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 140 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 142 */               int i3 = (i2 >> 6) & 14;
/* 113 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        int i4 = ((438 >> 6) & 112) | 6;
                        RowScope rowScope = RowScopeInstance.INSTANCE;
                        Composer composer = $composer;
                        ComposerKt.sourceInformationMarkerStart(composer, 1904903519, "C:StatisticsScreen.kt#i35lj1");
                        composer.startReplaceGroup(-492740208);
                        ComposerKt.sourceInformation(composer, "*25@1934L83,25@1874L644");
                        Iterable<DaySummary> lastSevenDays = $stats.getLastSevenDays();
                        int i5 = 0;
                        for (final DaySummary daySummary : lastSevenDays) {
                            Iterable iterable = lastSevenDays;
                            int i6 = i5;
/* 26 */                    Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
                            int i7 = i4;
                            Alignment.Vertical vertical = bottom;
                            ComposerKt.sourceInformationMarkerStart(composer, 1933262391, "CC(remember):StatisticsScreen.kt#9igjgp");
                            boolean zChangedInstance = composer.changedInstance(daySummary);
                            Composer composer2 = composer;
/* 144 */                   Composer composer3 = composer;
                            Object objRememberedValue = composer2.rememberedValue();
/* 145 */                   if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
                                objRememberedValue = new Function1() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda0
                                    @Override // kotlin.jvm.functions.Function1
                                    public final Object invoke(Object obj) {
                                        return StatisticsScreenKt.StatisticsScreen$lambda$0$0$2$0$1$0$0$0(daySummary, (SemanticsPropertyReceiver) obj);
                                    }
                                };
/* 147 */                       composer2.updateRememberedValue(objRememberedValue);
                            }
                            ComposerKt.sourceInformationMarkerEnd(composer3);
/* 26 */                    Modifier modifierSemantics = SemanticsModifierKt.semantics(modifierWeight$default, true, (Function1) objRememberedValue);
                            Alignment.Horizontal centerHorizontally = Alignment.INSTANCE.getCenterHorizontally();
/* 26 */                    Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(8));
                            ComposerKt.sourceInformationMarkerStart(composer3, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 152 */                   MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, centerHorizontally, composer3, ((432 >> 3) & 14) | ((432 >> 3) & 112));
                            ComposerKt.sourceInformationMarkerStart(composer3, -1159599143, str);
/* 158 */                   int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode(composer3, 0));
                            CompositionLocalMap currentCompositionLocalMap2 = composer3.getCurrentCompositionLocalMap();
/* 160 */                   String str3 = str;
/* 151 */                   Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier(composer3, modifierSemantics);
/* 162 */                   Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 156 */                   int i8 = ((((432 << 3) & 112) << 6) & 896) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer3, -553112988, str2);
/* 164 */                   if (!(composer3.getApplier() instanceof Applier)) {
                                ComposablesKt.invalidApplier();
                            }
/* 165 */                   composer3.startReusableNode();
/* 166 */                   if (composer3.getInserting()) {
/* 167 */                       function0 = constructor2;
                                composer3.createNode(function0);
                            } else {
/* 169 */                       function0 = constructor2;
                                composer3.useNode();
                            }
/* 171 */                   String str4 = str2;
                            Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl(composer3);
/* 172 */                   Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 173 */                   Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 174 */                   Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 176 */                   if (composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 175 */                       composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 178 */                       composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
                            }
/* 181 */                   Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 183 */                   int i9 = (i8 >> 6) & 14;
/* 154 */                   ComposerKt.sourceInformationMarkerStart(composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                            int i10 = ((432 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer3, -667261583, "C26@2174L10,26@2123L74,27@2204L221,28@2488L10,28@2432L79:StatisticsScreen.kt#i35lj1");
/* 150 */                   TextKt.m3584TextNvy7gAk(String.valueOf(daySummary.getScoreCount()), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getLabelMedium(), composer3, 0, 0, 131070);
/* 28 */                    Modifier modifierClip = ClipKt.clip(SizeKt.m878height3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(i + ((daySummary.getScoreCount() * 80.0f) / max))), RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(8)));
/* 150 */                   if (Intrinsics.areEqual(daySummary.getDate(), $stats.getToday().getDate())) {
                                composer3.startReplaceGroup(1363956213);
                                ComposerKt.sourceInformation(composer3, "27@2356L11");
                                primaryContainer = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getPrimary();
                            } else {
                                composer3.startReplaceGroup(1363957470);
                                ComposerKt.sourceInformation(composer3, "27@2395L11");
                                primaryContainer = MaterialTheme.INSTANCE.getColorScheme(composer3, MaterialTheme.$stable).getPrimaryContainer();
                            }
                            composer3.endReplaceGroup();
                            BoxKt.Box(BackgroundKt.m265backgroundbw27NRU$default(modifierClip, primaryContainer, null, 2, null), composer3, 0);
/* 29 */                    TextKt.m3584TextNvy7gAk(String.valueOf(daySummary.getDate().getDayOfMonth()), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getLabelMedium(), composer3, 0, 0, 131070);
/* 27 */                    ComposerKt.sourceInformationMarkerEnd(composer3);
/* 154 */                   ComposerKt.sourceInformationMarkerEnd(composer3);
/* 186 */                   composer3.endNode();
/* 163 */                   ComposerKt.sourceInformationMarkerEnd(composer3);
/* 157 */                   ComposerKt.sourceInformationMarkerEnd(composer3);
/* 151 */                   ComposerKt.sourceInformationMarkerEnd(composer3);
/* 143 */                   i4 = i7;
                            bottom = vertical;
                            composer = composer3;
                            lastSevenDays = iterable;
                            i5 = i6;
                            str = str3;
                            str2 = str4;
                            i = 6;
                        }
                        Composer composer4 = composer;
                        composer4.endReplaceGroup();
/* 26 */                ComposerKt.sourceInformationMarkerEnd(composer4);
/* 113 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 191 */               $composer.endNode();
/* 122 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 116 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 110 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 23 */                $composer.skipToGroupEnd();
                    }
/* 32 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 25 */        public static final Unit StatisticsScreen$lambda$0$0$2$0$1$0$0$0(DaySummary $day, SemanticsPropertyReceiver semantics) {
                    Intrinsics.checkNotNullParameter(semantics, "$this$semantics");
                    SemanticsPropertiesKt.setContentDescription(semantics, $day.getDate() + "：" + $day.getScoreCount() + " 次评分，" + $day.getDistinctCards() + " 张卡片");
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 32 */        public static final Unit StatisticsScreen$lambda$0$0$3(StatisticsSummary $stats, LazyItemScope items, int i, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(items, "$this$items");
                    ComposerKt.sourceInformation($composer, "CN(i)32@2647L267,32@2616L298:StatisticsScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 48) == 0) {
                        $dirty |= $composer.changed(i) ? 32 : 16;
                    }
                    if ($composer.shouldExecute(($dirty & 145) != 144, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1700612523, $dirty, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:32)");
                        }
/* 33 */                final DaySummary day = (DaySummary) CollectionsKt.reversed($stats.getLastSevenDays()).get(i);
                        XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1890871003, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.StatisticsScreenKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return StatisticsScreenKt.StatisticsScreen$lambda$0$0$3$0(day, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:15:0x0102  */
/* 32 */        public static final Unit StatisticsScreen$lambda$0$0$3$0(DaySummary $day, ColumnScope Paper, Composer $composer, int $changed) {
                    String str;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C32@2723L10,32@2649L97,32@2747L93,32@2841L71:StatisticsScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1890871003, $changed, -1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:32)");
                        }
                        TextKt.m3584TextNvy7gAk($day.getDate().getMonthValue() + "月" + $day.getDate().getDayOfMonth() + "日", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 0, 0, 131070);
                        XunjiComponentsKt.Notice($day.getScoreCount() + " 次评分 · " + $day.getDistinctCards() + " 张卡片 · " + XunjiComponentsKt.durationLabel($day.getDurationMs()), false, $composer, 0, 2);
                        Double againRatio = $day.getAgainRatio();
                        if (againRatio != null) {
                            str = ((int) (((double) 100) * againRatio.doubleValue())) + "%";
                            if (str == null) {
                                str = "—";
                            }
                        } else {
                            str = "—";
                        }
                        XunjiComponentsKt.Notice("忘记比例 " + str, false, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

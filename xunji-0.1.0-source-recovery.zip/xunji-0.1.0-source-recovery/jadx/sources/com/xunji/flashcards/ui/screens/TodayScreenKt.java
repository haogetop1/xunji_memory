            package com.xunji.flashcards.ui.screens;

            import androidx.compose.foundation.ClickableKt;
            import androidx.compose.foundation.layout.Arrangement;
            import androidx.compose.foundation.layout.ColumnKt;
            import androidx.compose.foundation.layout.ColumnScope;
            import androidx.compose.foundation.layout.ColumnScopeInstance;
            import androidx.compose.foundation.layout.PaddingKt;
            import androidx.compose.foundation.layout.PaddingValues;
            import androidx.compose.foundation.layout.RowKt;
            import androidx.compose.foundation.layout.RowScope;
            import androidx.compose.foundation.layout.RowScopeInstance;
            import androidx.compose.foundation.layout.SizeKt;
            import androidx.compose.foundation.layout.SpacerKt;
            import androidx.compose.foundation.lazy.LazyDslKt;
            import androidx.compose.foundation.lazy.LazyItemScope;
            import androidx.compose.foundation.lazy.LazyListScope;
            import androidx.compose.foundation.shape.RoundedCornerShape;
            import androidx.compose.foundation.shape.RoundedCornerShapeKt;
            import androidx.compose.material3.ButtonDefaults;
            import androidx.compose.material3.ButtonKt;
            import androidx.compose.material3.MaterialTheme;
            import androidx.compose.material3.SurfaceKt;
            import androidx.compose.material3.TextKt;
            import androidx.compose.runtime.Applier;
            import androidx.compose.runtime.ComposablesKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.CompositionLocalMap;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.runtime.Updater;
            import androidx.compose.runtime.internal.ComposableLambdaKt;
            import androidx.compose.ui.Alignment;
            import androidx.compose.ui.ComposedModifierKt;
            import androidx.compose.ui.Modifier;
            import androidx.compose.ui.graphics.Color;
            import androidx.compose.ui.layout.MeasurePolicy;
            import androidx.compose.ui.node.ComposeUiNode;
            import androidx.compose.ui.unit.Dp;
            import com.xunji.core.model.DeckSummary;
            import com.xunji.core.stats.DaySummary;
            import com.xunji.core.stats.StatisticsSummary;
            import com.xunji.flashcards.ui.MainUiState;
            import com.xunji.flashcards.ui.components.XunjiComponentsKt;
            import kotlin.Metadata;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function0;
            import kotlin.jvm.functions.Function1;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.functions.Function3;
            import kotlin.jvm.functions.Function4;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: TodayScreen.kt */
            /* JADX INFO: loaded from: classes10.dex */
            @Metadata(d1 = {"\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a1\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00010\u00052\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0005H\u0007¢\u0006\u0002\u0010\u0007¨\u0006\b"}, d2 = {"TodayScreen", "", "state", "Lcom/xunji/flashcards/ui/MainUiState;", "onReview", "Lkotlin/Function0;", "onDecks", "(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 16 */    public final class TodayScreenKt {
                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit TodayScreen$lambda$0(MainUiState mainUiState, Function0 function0, Function0 function1, int i, Composer composer, int i2) {
                    TodayScreen(mainUiState, function0, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit TodayScreen$lambda$2(MainUiState mainUiState, Function0 function0, Function0 function1, int i, Composer composer, int i2) {
                    TodayScreen(mainUiState, function0, function1, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1));
                    return Unit.INSTANCE;
                }

/* 17 */        public static final void TodayScreen(final MainUiState state, final Function0<Unit> onReview, final Function0<Unit> onDecks, Composer $composer, final int $changed) {
                    Intrinsics.checkNotNullParameter(state, "state");
                    Intrinsics.checkNotNullParameter(onReview, "onReview");
                    Intrinsics.checkNotNullParameter(onDecks, "onDecks");
/* 18 */            Composer $composer2 = $composer.startRestartGroup(2031371891);
                    ComposerKt.sourceInformation($composer2, "C(TodayScreen)N(state,onReview,onDecks)19@867L2825,19@730L2962:TodayScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 6) == 0) {
                        $dirty |= $composer2.changedInstance(state) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(onReview) ? 32 : 16;
                    }
                    if (($changed & 384) == 0) {
                        $dirty |= $composer2.changedInstance(onDecks) ? 256 : 128;
                    }
                    if ($composer2.shouldExecute(($dirty & 147) != 146, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
/* 18 */                    ComposerKt.traceEventStart(2031371891, $dirty, -1, "com.xunji.flashcards.ui.screens.TodayScreen (TodayScreen.kt:17)");
                        }
/* 19 */                if (state.getLoading()) {
                            $composer2.startReplaceGroup(510894942);
                            ComposerKt.sourceInformation($composer2, "18@713L6");
                            XunjiComponentsKt.Busy($composer2, 0);
                            $composer2.endReplaceGroup();
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
/* 43 */                    ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                            if (scopeUpdateScopeEndRestartGroup != null) {
                                scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda1
                                    @Override // kotlin.jvm.functions.Function2
                                    public final Object invoke(Object obj, Object obj2) {
                                        return TodayScreenKt.TodayScreen$lambda$0(state, onReview, onDecks, $changed, (Composer) obj, ((Integer) obj2).intValue());
                                    }
                                });
/* 19 */                        return;
                            }
/* 19 */                    return;
                        }
                        $composer2.startReplaceGroup(510188111);
                        $composer2.endReplaceGroup();
/* 20 */                Modifier modifierFillMaxSize$default = SizeKt.fillMaxSize$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 20 */                PaddingValues paddingValuesM836PaddingValuesa9UjIt4 = PaddingKt.m836PaddingValuesa9UjIt4(Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(18), Dp.m8404constructorimpl(22), Dp.m8404constructorimpl(28));
/* 20 */                Arrangement.HorizontalOrVertical horizontalOrVerticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(22));
                        ComposerKt.sourceInformationMarkerStart($composer2, -2061721700, "CC(remember):TodayScreen.kt#9igjgp");
                        boolean zChangedInstance = (($dirty & 112) == 32) | $composer2.changedInstance(state) | (($dirty & 896) == 256);
/* 46 */                Object objRememberedValue = $composer2.rememberedValue();
/* 47 */                if (zChangedInstance || objRememberedValue == Composer.INSTANCE.getEmpty()) {
/* 20 */                    Object obj = new Function1() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda2
                                @Override // kotlin.jvm.functions.Function1
                                public final Object invoke(Object obj2) {
                                    return TodayScreenKt.TodayScreen$lambda$1$0(state, onReview, onDecks, (LazyListScope) obj2);
                                }
                            };
/* 49 */                    $composer2.updateRememberedValue(obj);
/* 50 */                    objRememberedValue = obj;
                        }
                        ComposerKt.sourceInformationMarkerEnd($composer2);
/* 20 */                LazyDslKt.LazyColumn(modifierFillMaxSize$default, null, paddingValuesM836PaddingValuesa9UjIt4, false, horizontalOrVerticalM699spacedBy0680j_4, null, null, false, null, (Function1) objRememberedValue, $composer2, 24966, 490);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer2.skipToGroupEnd();
                    }
/* 43 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup2 = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup2 != null) {
                        scopeUpdateScopeEndRestartGroup2.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda3
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$2(state, onReview, onDecks, $changed, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        });
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 20 */        public static final Unit TodayScreen$lambda$1$0(final MainUiState $state, final Function0 $onReview, final Function0 $onDecks, LazyListScope LazyColumn) {
                    Intrinsics.checkNotNullParameter(LazyColumn, "$this$LazyColumn");
/* 21 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$TodayScreenKt.INSTANCE.m9013getLambda$2076728066$app_debug(), 3, null);
/* 22 */            if ($state.getError() != null) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1830129475, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$0($state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    }
/* 23 */            LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(1415961063, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda4
                        @Override // kotlin.jvm.functions.Function3
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            return TodayScreenKt.TodayScreen$lambda$1$0$1($onReview, $state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                        }
                    }), 3, null);
/* 35 */            if ($state.getCards().isEmpty()) {
                        LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(2104641260, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda5
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$2($onDecks, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
                    } else {
/* 37 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-730768445, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda6
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$3($state, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
/* 38 */                LazyListScope.item$default(LazyColumn, null, null, ComposableLambdaKt.composableLambdaInstance(-1147846292, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda7
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$4($onDecks, (LazyItemScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }), 3, null);
/* 39 */                LazyListScope.items$default(LazyColumn, Math.min(2, $state.getDecks().size()), null, null, ComposableLambdaKt.composableLambdaInstance(-846854502, true, new Function4() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda8
                            @Override // kotlin.jvm.functions.Function4
                            public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$5($state, $onDecks, (LazyItemScope) obj, ((Integer) obj2).intValue(), (Composer) obj3, ((Integer) obj4).intValue());
                            }
                        }), 6, null);
                    }
/* 41 */            LazyListScope.item$default(LazyColumn, null, null, ComposableSingletons$TodayScreenKt.INSTANCE.getLambda$1071045318$app_debug(), 3, null);
/* 42 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 21 */        public static final Unit TodayScreen$lambda$1$0$0(MainUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C21@1085L24:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1830129475, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:21)");
                        }
/* 22 */                XunjiComponentsKt.Notice($state.getError(), true, $composer, 48, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 23 */        public static final Unit TodayScreen$lambda$1$0$1(final Function0 $onReview, final MainUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C23@1184L11,23@1205L1342,23@1124L1423:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1415961063, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:23)");
                        }
/* 24 */                SurfaceKt.m3412SurfaceT9BRK9s(null, RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(28)), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), 0L, 0.0f, 0.0f, null, ComposableLambdaKt.rememberComposableLambda(-1589352724, true, new Function2() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda12
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$1$0($onReview, $state, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        }, $composer, 54), $composer, 12582912, 121);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 34 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 24 */        public static final Unit TodayScreen$lambda$1$0$1$0(Function0 $onReview, final MainUiState $state, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Function0<ComposeUiNode> function1;
                    Function0<ComposeUiNode> function2;
                    Function0<ComposeUiNode> function3;
                    Function0<ComposeUiNode> function4;
                    ComposerKt.sourceInformation($composer, "C24@1211L1331:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 3) != 2, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1589352724, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:24)");
                        }
/* 25 */                Modifier modifierM840padding3ABfNKs = PaddingKt.m840padding3ABfNKs(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(24));
/* 25 */                Arrangement.Vertical verticalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 54 */                ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 58 */                MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(verticalM699spacedBy0680j_4, Alignment.INSTANCE.getStart(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
/* 63 */                ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 64 */                int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 65 */                CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 66 */                Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierM840padding3ABfNKs);
/* 68 */                Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 62 */                int i = ((((54 << 3) & 112) << 6) & 896) | 6;
/* 69 */                ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 70 */                if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 71 */                $composer.startReusableNode();
/* 72 */                if ($composer.getInserting()) {
/* 73 */                    function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 75 */                    function0 = constructor;
                            $composer.useNode();
                        }
/* 77 */                Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 78 */                Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 79 */                Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 80 */                Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 82 */                if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 81 */                    composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 84 */                    composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 87 */                Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 89 */                int i2 = (i >> 6) & 14;
/* 60 */                ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
                        int i3 = ((54 >> 6) & 112) | 6;
/* 26 */                ComposerKt.sourceInformationMarkerStart($composer, 586753178, "C25@1313L237,26@1556L424,30@2181L11,30@2231L11,30@2288L11,30@2363L11,30@2139L244,30@2385L151,30@1986L550:TodayScreen.kt#i35lj1");
                        Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
                        ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 91 */                MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 97 */                int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
                        CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
/* 92 */                Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
/* 101 */               Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 95 */                int i4 = ((((438 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 103 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 104 */               $composer.startReusableNode();
/* 105 */               if ($composer.getInserting()) {
/* 106 */                   function1 = constructor2;
                            $composer.createNode(function1);
                        } else {
/* 108 */                   function1 = constructor2;
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer);
/* 111 */               Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 112 */               Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 113 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 115 */               if (composerM4979constructorimpl2.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
/* 114 */                   composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 117 */                   composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
                        }
/* 120 */               Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 122 */               int i5 = (i4 >> 6) & 14;
/* 93 */                ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i6 = ((438 >> 6) & 112) | 6;
/* 26 */                ComposerKt.sourceInformationMarkerStart($composer, -1402017843, "C25@1469L10,25@1436L56,25@1526L11,25@1493L55:TodayScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk("今天的学习", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleMedium(), $composer, 6, 0, 131070);
                        XunjiComponentsKt.m8967GlyphFNF3uiM("leaf", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getOnPrimary(), $composer, 6, 2);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 93 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 123 */               $composer.endNode();
/* 102 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 96 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 90 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 27 */                Modifier modifierFillMaxWidth$default2 = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
/* 27 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
                        ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 128 */               MeasurePolicy measurePolicyRowMeasurePolicy2 = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((54 >> 3) & 14) | ((54 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 138 */               int iHashCode3 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
                        CompositionLocalMap currentCompositionLocalMap3 = $composer.getCurrentCompositionLocalMap();
/* 133 */               Modifier modifierMaterializeModifier3 = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default2);
/* 142 */               Function0<ComposeUiNode> constructor3 = ComposeUiNode.INSTANCE.getConstructor();
/* 136 */               int i7 = ((((54 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 144 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 145 */               $composer.startReusableNode();
/* 146 */               if ($composer.getInserting()) {
/* 147 */                   function2 = constructor3;
                            $composer.createNode(function2);
                        } else {
/* 149 */                   function2 = constructor3;
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl3 = Updater.m4979constructorimpl($composer);
/* 152 */               Updater.m4986setimpl(composerM4979constructorimpl3, measurePolicyRowMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 153 */               Updater.m4986setimpl(composerM4979constructorimpl3, currentCompositionLocalMap3, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 154 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash3 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 156 */               if (composerM4979constructorimpl3.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
/* 155 */                   composerM4979constructorimpl3.updateRememberedValue(Integer.valueOf(iHashCode3));
/* 158 */                   composerM4979constructorimpl3.apply(Integer.valueOf(iHashCode3), setCompositeKeyHash3);
                        }
/* 161 */               Updater.m4986setimpl(composerM4979constructorimpl3, modifierMaterializeModifier3, ComposeUiNode.INSTANCE.getSetModifier());
/* 163 */               int i8 = (i7 >> 6) & 14;
/* 134 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
/* 128 */               int i9 = ((54 >> 6) & 112) | 6;
                        RowScope rowScope = RowScopeInstance.INSTANCE;
                        ComposerKt.sourceInformationMarkerStart($composer, 2134091356, "C27@1643L157,28@1807L166:TodayScreen.kt#i35lj1");
                        Modifier modifierWeight$default = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
                        ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 169 */               MeasurePolicy measurePolicyColumnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 175 */               int iHashCode4 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
                        CompositionLocalMap currentCompositionLocalMap4 = $composer.getCurrentCompositionLocalMap();
/* 164 */               Modifier modifierMaterializeModifier4 = ComposedModifierKt.materializeModifier($composer, modifierWeight$default);
/* 179 */               Function0<ComposeUiNode> constructor4 = ComposeUiNode.INSTANCE.getConstructor();
/* 173 */               int i10 = ((((0 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 181 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 182 */               $composer.startReusableNode();
/* 183 */               if ($composer.getInserting()) {
/* 184 */                   function3 = constructor4;
                            $composer.createNode(function3);
                        } else {
/* 186 */                   function3 = constructor4;
                            $composer.useNode();
                        }
/* 188 */               Composer composerM4979constructorimpl4 = Updater.m4979constructorimpl($composer);
/* 189 */               Updater.m4986setimpl(composerM4979constructorimpl4, measurePolicyColumnMeasurePolicy2, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 190 */               Updater.m4986setimpl(composerM4979constructorimpl4, currentCompositionLocalMap4, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 191 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash4 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 193 */               if (composerM4979constructorimpl4.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl4.rememberedValue(), Integer.valueOf(iHashCode4))) {
/* 192 */                   composerM4979constructorimpl4.updateRememberedValue(Integer.valueOf(iHashCode4));
/* 195 */                   composerM4979constructorimpl4.apply(Integer.valueOf(iHashCode4), setCompositeKeyHash4);
                        }
/* 198 */               Updater.m4986setimpl(composerM4979constructorimpl4, modifierMaterializeModifier4, ComposeUiNode.INSTANCE.getSetModifier());
/* 200 */               int i11 = (i10 >> 6) & 14;
/* 188 */               ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
                        int i12 = ((0 >> 6) & 112) | 6;
/* 188 */               ComposerKt.sourceInformationMarkerStart($composer, -502604525, "C27@1719L10,27@1673L70,27@1776L10,27@1744L54:TodayScreen.kt#i35lj1");
/* 188 */               TextKt.m3584TextNvy7gAk(String.valueOf($state.getDue()), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getDisplaySmall(), $composer, 0, 0, 131070);
/* 188 */               TextKt.m3584TextNvy7gAk("到期复习", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodyMedium(), $composer, 6, 0, 131070);
/* 188 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 171 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 201 */               $composer.endNode();
/* 180 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 174 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 164 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 29 */                Modifier modifierWeight$default2 = RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null);
/* 205 */               ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 210 */               MeasurePolicy measurePolicyColumnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 216 */               int iHashCode5 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 217 */               CompositionLocalMap currentCompositionLocalMap5 = $composer.getCurrentCompositionLocalMap();
                        Modifier modifierMaterializeModifier5 = ComposedModifierKt.materializeModifier($composer, modifierWeight$default2);
/* 220 */               Function0<ComposeUiNode> constructor5 = ComposeUiNode.INSTANCE.getConstructor();
/* 214 */               int i13 = ((((0 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 222 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 223 */               $composer.startReusableNode();
/* 224 */               if ($composer.getInserting()) {
/* 225 */                   function4 = constructor5;
                            $composer.createNode(function4);
                        } else {
/* 227 */                   function4 = constructor5;
                            $composer.useNode();
                        }
/* 229 */               Composer composerM4979constructorimpl5 = Updater.m4979constructorimpl($composer);
/* 230 */               Updater.m4986setimpl(composerM4979constructorimpl5, measurePolicyColumnMeasurePolicy3, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 231 */               Updater.m4986setimpl(composerM4979constructorimpl5, currentCompositionLocalMap5, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 232 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash5 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 234 */               if (composerM4979constructorimpl5.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl5.rememberedValue(), Integer.valueOf(iHashCode5))) {
/* 233 */                   composerM4979constructorimpl5.updateRememberedValue(Integer.valueOf(iHashCode5));
/* 236 */                   composerM4979constructorimpl5.apply(Integer.valueOf(iHashCode5), setCompositeKeyHash5);
                        }
/* 239 */               Updater.m4986setimpl(composerM4979constructorimpl5, modifierMaterializeModifier5, ComposeUiNode.INSTANCE.getSetModifier());
/* 241 */               int i14 = (i13 >> 6) & 14;
/* 212 */               ComposerKt.sourceInformationMarkerStart($composer, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance3 = ColumnScopeInstance.INSTANCE;
/* 215 */               int i15 = ((0 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -1585520237, "C28@1892L10,28@1837L79,28@1949L10,28@1917L54:TodayScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk(String.valueOf($state.getAvailableNew()), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getDisplaySmall(), $composer, 0, 0, 131070);
                        TextKt.m3584TextNvy7gAk("可学新卡", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getBodyMedium(), $composer, 6, 0, 131070);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 212 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 242 */               $composer.endNode();
/* 221 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 215 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 205 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 28 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 134 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 246 */               $composer.endNode();
/* 143 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 137 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 128 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 31 */                Modifier modifierM880heightInVpY3zN4$default = SizeKt.m880heightInVpY3zN4$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), Dp.m8404constructorimpl(56), 0.0f, 2, null);
                        boolean z = $state.getDue() + $state.getAvailableNew() > 0;
/* 31 */                RoundedCornerShape roundedCornerShapeM1205RoundedCornerShape0680j_4 = RoundedCornerShapeKt.m1205RoundedCornerShape0680j_4(Dp.m8404constructorimpl(16));
                        ButtonDefaults buttonDefaults = ButtonDefaults.INSTANCE;
                        long background = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getBackground();
                        long primary = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary();
                        long background2 = MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getBackground();
/* 238 */               ButtonKt.Button($onReview, modifierM880heightInVpY3zN4$default, z, roundedCornerShapeM1205RoundedCornerShape0680j_4, buttonDefaults.m2390buttonColorsro_MJ88(background, primary, Color.m5658copywmQWz5c(background2, (14 & 1) != 0 ? Color.m5662getAlphaimpl(background2) : 0.85f, (14 & 2) != 0 ? Color.m5666getRedimpl(background2) : 0.0f, (14 & 4) != 0 ? Color.m5665getGreenimpl(background2) : 0.0f, (14 & 8) != 0 ? Color.m5663getBlueimpl(background2) : 0.0f), MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), $composer, ButtonDefaults.$stable << 12, 0), null, null, null, null, ComposableLambdaKt.rememberComposableLambda(1995374418, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda10
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$1$0$0$2($state, (RowScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 805306416, 480);
/* 26 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 60 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 251 */               $composer.endNode();
/* 69 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 63 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 54 */                ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
/* 33 */            return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 30 */        public static final Unit TodayScreen$lambda$1$0$1$0$0$2(MainUiState $state, RowScope Button, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(Button, "$this$Button");
                    ComposerKt.sourceInformation($composer, "C30@2387L62,30@2450L29,30@2514L11,30@2480L54:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(1995374418, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:30)");
                        }
/* 31 */                TextKt.m3584TextNvy7gAk($state.getDue() + $state.getAvailableNew() > 0 ? "开始复习" : "暂时没有待学卡片", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, null, $composer, 0, 0, 262142);
/* 31 */                SpacerKt.Spacer(SizeKt.m897width3ABfNKs(Modifier.INSTANCE, Dp.m8404constructorimpl(12)), $composer, 6);
                        XunjiComponentsKt.m8967GlyphFNF3uiM("arrow", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), $composer, 6, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 34 */        public static final Unit TodayScreen$lambda$1$0$2(Function0 $onDecks, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C34@2586L59:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2104641260, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:34)");
                        }
/* 35 */                XunjiComponentsKt.EmptyState("从第一张卡开始", "收集一个词、一句话，或一个想记住的答案。", "创建牌组", $onDecks, $composer, 438, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 36 */        public static final Unit TodayScreen$lambda$1$0$3(final MainUiState $state, LazyItemScope item, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C36@2698L302,36@2667L333:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-730768445, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:36)");
                        }
/* 37 */                XunjiComponentsKt.Paper(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), ComposableLambdaKt.rememberComposableLambda(-1320397165, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda9
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$3$0($state, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 54, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:31:0x0167  */
                /* JADX WARN: Code duplicated, block: B:34:0x01ea  */
/* 36 */        public static final Unit TodayScreen$lambda$1$0$3$0(MainUiState $state, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    int i;
                    StatisticsSummary statistics;
                    int scoreCount;
                    DaySummary today;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C36@2700L25,36@2726L210,36@2937L61:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1320397165, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:36)");
                        }
/* 37 */                XunjiComponentsKt.Eyebrow("TODAY · 已经走过的路", $composer, 6);
/* 37 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(24));
/* 256 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 257 */               Modifier modifier = Modifier.INSTANCE;
/* 262 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, Alignment.INSTANCE.getTop(), $composer, ((48 >> 3) & 14) | ((48 >> 3) & 112));
/* 267 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 268 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 269 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 270 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 272 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 266 */               int i2 = ((((48 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 274 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 275 */               $composer.startReusableNode();
/* 276 */               if ($composer.getInserting()) {
/* 277 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 279 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 281 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 282 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 283 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 284 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 286 */               if (composerM4979constructorimpl.getInserting()) {
                            i = iHashCode;
                        } else {
                            i = iHashCode;
/* 285 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(i))) {
                            }
/* 291 */                   Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 293 */                   int i3 = (i2 >> 6) & 14;
/* 264 */                   ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                            int i4 = ((48 >> 6) & 112) | 6;
                            RowScope rowScope = RowScopeInstance.INSTANCE;
                            ComposerKt.sourceInformationMarkerStart($composer, -672580939, "C36@2783L88,36@2872L62:TodayScreen.kt#i35lj1");
                            statistics = $state.getStatistics();
                            if (statistics != null || (today = statistics.getToday()) == null) {
                                scoreCount = 0;
                            } else {
                                scoreCount = today.getScoreCount();
                            }
                            XunjiComponentsKt.Metric(String.valueOf(scoreCount), "评分次数", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                            XunjiComponentsKt.Metric(String.valueOf($state.getLearnedNew()), "已学新卡", RowScope.weight$default(rowScope, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                            ComposerKt.sourceInformationMarkerEnd($composer);
/* 264 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 294 */                   $composer.endNode();
/* 273 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 267 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 256 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                            XunjiComponentsKt.Notice("每日新卡上限 " + $state.getSettings().getNewCardsPerDay() + " 张 · 到期复习不限量", false, $composer, 0, 2);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 285 */               composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(i));
/* 288 */               composerM4979constructorimpl.apply(Integer.valueOf(i), setCompositeKeyHash);
/* 291 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 293 */               int i5 = (i2 >> 6) & 14;
/* 264 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        int i6 = ((48 >> 6) & 112) | 6;
                        RowScope rowScope2 = RowScopeInstance.INSTANCE;
                        ComposerKt.sourceInformationMarkerStart($composer, -672580939, "C36@2783L88,36@2872L62:TodayScreen.kt#i35lj1");
                        statistics = $state.getStatistics();
                        if (statistics != null) {
                            scoreCount = 0;
                        } else {
                            scoreCount = 0;
                        }
                        XunjiComponentsKt.Metric(String.valueOf(scoreCount), "评分次数", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                        XunjiComponentsKt.Metric(String.valueOf($state.getLearnedNew()), "已学新卡", RowScope.weight$default(rowScope2, Modifier.INSTANCE, 1.0f, false, 2, null), $composer, 48, 0);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 264 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 294 */               $composer.endNode();
/* 273 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 267 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 256 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        XunjiComponentsKt.Notice("每日新卡上限 " + $state.getSettings().getNewCardsPerDay() + " 张 · 到期复习不限量", false, $composer, 0, 2);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 37 */        public static final Unit TodayScreen$lambda$1$0$4(Function0 $onDecks, LazyItemScope item, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Intrinsics.checkNotNullParameter(item, "$this$item");
                    ComposerKt.sourceInformation($composer, "C37@3013L218:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-1147846292, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:37)");
                        }
/* 38 */                Modifier modifierFillMaxWidth$default = SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null);
                        Arrangement.Horizontal spaceBetween = Arrangement.INSTANCE.getSpaceBetween();
                        Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 298 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 299 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(spaceBetween, centerVertically, $composer, ((438 >> 3) & 14) | ((438 >> 3) & 112));
/* 304 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 305 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 306 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 307 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifierFillMaxWidth$default);
/* 309 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 303 */               int i = ((((438 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 311 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 312 */               $composer.startReusableNode();
/* 313 */               if ($composer.getInserting()) {
/* 314 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 316 */                   function0 = constructor;
                            $composer.useNode();
                        }
/* 318 */               Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 319 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 320 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 321 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 323 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 322 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 325 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 328 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 330 */               int i2 = (i >> 6) & 14;
/* 301 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i3 = ((438 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -2059220354, "C37@3170L10,37@3136L56,37@3193L36:TodayScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk("你的记忆花园", null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography($composer, MaterialTheme.$stable).getTitleLarge(), $composer, 6, 0, 131070);
                        ButtonKt.TextButton($onDecks, null, false, null, null, null, null, null, null, ComposableSingletons$TodayScreenKt.INSTANCE.m9012getLambda$1573877077$app_debug(), $composer, 805306368, 510);
                        ComposerKt.sourceInformationMarkerEnd($composer);
/* 301 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 331 */               $composer.endNode();
/* 310 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 304 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 298 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 38 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
/* 38 */        public static final Unit TodayScreen$lambda$1$0$5(MainUiState $state, Function0 $onDecks, LazyItemScope items, int i, Composer $composer, int $changed) {
                    Intrinsics.checkNotNullParameter(items, "$this$items");
                    ComposerKt.sourceInformation($composer, "CN(i)38@3357L283,38@3299L341:TodayScreen.kt#i35lj1");
                    int $dirty = $changed;
                    if (($changed & 48) == 0) {
                        $dirty |= $composer.changed(i) ? 32 : 16;
                    }
                    if ($composer.shouldExecute(($dirty & 145) != 144, $dirty & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(-846854502, $dirty, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:38)");
                        }
/* 39 */                final DeckSummary deck = $state.getDecks().get(i);
                        XunjiComponentsKt.Paper(ClickableKt.m306clickableoSLSa3U$default(SizeKt.fillMaxWidth$default(Modifier.INSTANCE, 0.0f, 1, null), false, null, null, null, $onDecks, 15, null), ComposableLambdaKt.rememberComposableLambda(2076645738, true, new Function3() { // from class: com.xunji.flashcards.ui.screens.TodayScreenKt$$ExternalSyntheticLambda11
                            @Override // kotlin.jvm.functions.Function3
                            public final Object invoke(Object obj, Object obj2, Object obj3) {
                                return TodayScreenKt.TodayScreen$lambda$1$0$5$0(deck, (ColumnScope) obj, (Composer) obj2, ((Integer) obj3).intValue());
                            }
                        }, $composer, 54), $composer, 48, 0);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
                        $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Access modifiers changed from: private */
                /* JADX WARN: Code duplicated, block: B:43:0x0325  */
/* 38 */        public static final Unit TodayScreen$lambda$1$0$5$0(DeckSummary $deck, ColumnScope Paper, Composer $composer, int $changed) {
                    Function0<ComposeUiNode> function0;
                    Function0<ComposeUiNode> function1;
                    Composer composer;
                    Intrinsics.checkNotNullParameter(Paper, "$this$Paper");
                    ComposerKt.sourceInformation($composer, "C38@3359L279:TodayScreen.kt#i35lj1");
                    if ($composer.shouldExecute(($changed & 17) != 16, $changed & 1)) {
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventStart(2076645738, $changed, -1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:38)");
                        }
/* 39 */                Alignment.Vertical centerVertically = Alignment.INSTANCE.getCenterVertically();
/* 39 */                Arrangement.Horizontal horizontalM699spacedBy0680j_4 = Arrangement.INSTANCE.m699spacedBy0680j_4(Dp.m8404constructorimpl(16));
/* 336 */               ComposerKt.sourceInformationMarkerStart($composer, 844473419, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo");
/* 337 */               Modifier modifier = Modifier.INSTANCE;
/* 342 */               MeasurePolicy measurePolicyRowMeasurePolicy = RowKt.rowMeasurePolicy(horizontalM699spacedBy0680j_4, centerVertically, $composer, ((432 >> 3) & 14) | ((432 >> 3) & 112));
/* 347 */               ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 348 */               int iHashCode = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 349 */               CompositionLocalMap currentCompositionLocalMap = $composer.getCurrentCompositionLocalMap();
/* 350 */               Modifier modifierMaterializeModifier = ComposedModifierKt.materializeModifier($composer, modifier);
/* 352 */               Function0<ComposeUiNode> constructor = ComposeUiNode.INSTANCE.getConstructor();
/* 346 */               int i = ((((432 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 354 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 355 */               $composer.startReusableNode();
/* 356 */               if ($composer.getInserting()) {
/* 357 */                   function0 = constructor;
                            $composer.createNode(function0);
                        } else {
/* 359 */                   function0 = constructor;
                            $composer.useNode();
                        }
                        Composer composerM4979constructorimpl = Updater.m4979constructorimpl($composer);
/* 362 */               Updater.m4986setimpl(composerM4979constructorimpl, measurePolicyRowMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 363 */               Updater.m4986setimpl(composerM4979constructorimpl, currentCompositionLocalMap, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 364 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 366 */               if (composerM4979constructorimpl.getInserting() || !Intrinsics.areEqual(composerM4979constructorimpl.rememberedValue(), Integer.valueOf(iHashCode))) {
/* 365 */                   composerM4979constructorimpl.updateRememberedValue(Integer.valueOf(iHashCode));
/* 368 */                   composerM4979constructorimpl.apply(Integer.valueOf(iHashCode), setCompositeKeyHash);
                        }
/* 371 */               Updater.m4986setimpl(composerM4979constructorimpl, modifierMaterializeModifier, ComposeUiNode.INSTANCE.getSetModifier());
/* 373 */               int i2 = (i >> 6) & 14;
/* 344 */               ComposerKt.sourceInformationMarkerStart($composer, 1456264949, "C101@5233L9:Row.kt#2w3rfo");
                        RowScopeInstance rowScopeInstance = RowScopeInstance.INSTANCE;
                        int i3 = ((432 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -512128666, "C38@3495L11,38@3461L54,38@3516L120:TodayScreen.kt#i35lj1");
                        XunjiComponentsKt.m8967GlyphFNF3uiM("decks", null, MaterialTheme.INSTANCE.getColorScheme($composer, MaterialTheme.$stable).getPrimary(), $composer, 6, 2);
                        ComposerKt.sourceInformationMarkerStart($composer, 1341605231, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo");
/* 375 */               Modifier modifier2 = Modifier.INSTANCE;
/* 374 */               MeasurePolicy measurePolicyColumnMeasurePolicy = ColumnKt.columnMeasurePolicy(Arrangement.INSTANCE.getTop(), Alignment.INSTANCE.getStart(), $composer, ((0 >> 3) & 14) | ((0 >> 3) & 112));
                        ComposerKt.sourceInformationMarkerStart($composer, -1159599143, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh");
/* 348 */               int iHashCode2 = Long.hashCode(ComposablesKt.getCurrentCompositeKeyHashCode($composer, 0));
/* 349 */               CompositionLocalMap currentCompositionLocalMap2 = $composer.getCurrentCompositionLocalMap();
/* 381 */               Modifier modifierMaterializeModifier2 = ComposedModifierKt.materializeModifier($composer, modifier2);
/* 352 */               Function0<ComposeUiNode> constructor2 = ComposeUiNode.INSTANCE.getConstructor();
/* 384 */               int i4 = ((((0 << 3) & 112) << 6) & 896) | 6;
                        ComposerKt.sourceInformationMarkerStart($composer, -553112988, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp");
/* 354 */               if (!($composer.getApplier() instanceof Applier)) {
                            ComposablesKt.invalidApplier();
                        }
/* 355 */               $composer.startReusableNode();
/* 356 */               if ($composer.getInserting()) {
/* 357 */                   function1 = constructor2;
                            $composer.createNode(function1);
                        } else {
/* 359 */                   function1 = constructor2;
                            $composer.useNode();
                        }
/* 361 */               Composer composerM4979constructorimpl2 = Updater.m4979constructorimpl($composer);
/* 385 */               Updater.m4986setimpl(composerM4979constructorimpl2, measurePolicyColumnMeasurePolicy, ComposeUiNode.INSTANCE.getSetMeasurePolicy());
/* 386 */               Updater.m4986setimpl(composerM4979constructorimpl2, currentCompositionLocalMap2, ComposeUiNode.INSTANCE.getSetResolvedCompositionLocals());
/* 387 */               Function2<ComposeUiNode, Integer, Unit> setCompositeKeyHash2 = ComposeUiNode.INSTANCE.getSetCompositeKeyHash();
/* 366 */               if (composerM4979constructorimpl2.getInserting()) {
                            composer = $composer;
                        } else {
                            composer = $composer;
/* 350 */                   if (!Intrinsics.areEqual(composerM4979constructorimpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            }
/* 388 */                   Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 373 */                   int i5 = (i4 >> 6) & 14;
                            Composer composer2 = composer;
/* 382 */                   ComposerKt.sourceInformationMarkerStart(composer2, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                            ColumnScopeInstance columnScopeInstance = ColumnScopeInstance.INSTANCE;
/* 374 */                   int i6 = ((0 >> 6) & 112) | 6;
                            ComposerKt.sourceInformationMarkerStart(composer2, -1076981710, "C38@3565L10,38@3525L63,38@3589L45:TodayScreen.kt#i35lj1");
                            TextKt.m3584TextNvy7gAk($deck.getDeck().getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer2, MaterialTheme.$stable).getTitleMedium(), composer2, 0, 0, 131070);
                            XunjiComponentsKt.Notice($deck.getTotal() + " 张卡片 · " + $deck.getDue() + " 张到期", false, composer2, 0, 2);
                            ComposerKt.sourceInformationMarkerEnd(composer2);
/* 382 */                   ComposerKt.sourceInformationMarkerEnd(composer2);
/* 390 */                   composer.endNode();
/* 353 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 347 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 374 */                   ComposerKt.sourceInformationMarkerEnd(composer);
/* 39 */                    ComposerKt.sourceInformationMarkerEnd($composer);
/* 344 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 390 */                   $composer.endNode();
/* 353 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 347 */                   ComposerKt.sourceInformationMarkerEnd($composer);
/* 336 */                   ComposerKt.sourceInformationMarkerEnd($composer);
                            if (ComposerKt.isTraceInProgress()) {
                                ComposerKt.traceEventEnd();
                            }
                        }
/* 365 */               composerM4979constructorimpl2.updateRememberedValue(Integer.valueOf(iHashCode2));
/* 368 */               composerM4979constructorimpl2.apply(Integer.valueOf(iHashCode2), setCompositeKeyHash2);
/* 388 */               Updater.m4986setimpl(composerM4979constructorimpl2, modifierMaterializeModifier2, ComposeUiNode.INSTANCE.getSetModifier());
/* 373 */               int i7 = (i4 >> 6) & 14;
                        Composer composer3 = composer;
/* 382 */               ComposerKt.sourceInformationMarkerStart(composer3, 2093002350, "C89@4557L9:Column.kt#2w3rfo");
                        ColumnScopeInstance columnScopeInstance2 = ColumnScopeInstance.INSTANCE;
/* 374 */               int i8 = ((0 >> 6) & 112) | 6;
                        ComposerKt.sourceInformationMarkerStart(composer3, -1076981710, "C38@3565L10,38@3525L63,38@3589L45:TodayScreen.kt#i35lj1");
                        TextKt.m3584TextNvy7gAk($deck.getDeck().getName(), null, 0L, null, 0L, null, null, null, 0L, null, null, 0L, 0, false, 0, 0, null, MaterialTheme.INSTANCE.getTypography(composer3, MaterialTheme.$stable).getTitleMedium(), composer3, 0, 0, 131070);
                        XunjiComponentsKt.Notice($deck.getTotal() + " 张卡片 · " + $deck.getDue() + " 张到期", false, composer3, 0, 2);
                        ComposerKt.sourceInformationMarkerEnd(composer3);
/* 382 */               ComposerKt.sourceInformationMarkerEnd(composer3);
/* 390 */               composer.endNode();
/* 353 */               ComposerKt.sourceInformationMarkerEnd(composer);
/* 347 */               ComposerKt.sourceInformationMarkerEnd(composer);
/* 374 */               ComposerKt.sourceInformationMarkerEnd(composer);
/* 39 */                ComposerKt.sourceInformationMarkerEnd($composer);
/* 344 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 390 */               $composer.endNode();
/* 353 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 347 */               ComposerKt.sourceInformationMarkerEnd($composer);
/* 336 */               ComposerKt.sourceInformationMarkerEnd($composer);
                        if (ComposerKt.isTraceInProgress()) {
                            ComposerKt.traceEventEnd();
                        }
                    } else {
/* 39 */                $composer.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }

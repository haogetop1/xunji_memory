            package com.xunji.flashcards.ui.theme;

            import kotlin.Metadata;
            
            /* JADX INFO: compiled from: Color.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\b\f\"\u0013\u0010\u0000\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0002\u0010\u0003\"\u0013\u0010\u0005\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\u0006\u0010\u0003\"\u0013\u0010\u0007\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\b\u0010\u0003\"\u0013\u0010\t\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\n\u0010\u0003\"\u0013\u0010\u000b\u001a\u00020\u0001¢\u0006\n\n\u0002\u0010\u0004\u001a\u0004\b\f\u0010\u0003¨\u0006\r"}, d2 = {"Forest", "Landroidx/compose/ui/graphics/Color;", "getForest", "()J", "J", "WarmWhite", "getWarmWhite", "Ink", "getInk", "Muted", "getMuted", "Amber", "getAmber", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 1 */     public final class ColorKt {
                private static final long Forest = androidx.compose.ui.graphics.ColorKt.Color(4280571978L);
                private static final long WarmWhite = androidx.compose.ui.graphics.ColorKt.Color(4294440431L);
                private static final long Ink = androidx.compose.ui.graphics.ColorKt.Color(4280298278L);
                private static final long Muted = androidx.compose.ui.graphics.ColorKt.Color(4284114527L);
                private static final long Amber = androidx.compose.ui.graphics.ColorKt.Color(4286599192L);

/* 2 */         public static final long getForest() {
/* 3 */             return Forest;
                }

/* 3 */         public static final long getWarmWhite() {
/* 4 */             return WarmWhite;
                }

/* 4 */         public static final long getInk() {
/* 5 */             return Ink;
                }

/* 5 */         public static final long getMuted() {
/* 6 */             return Muted;
                }

/* 6 */         public static final long getAmber() {
/* 7 */             return Amber;
                }
            }

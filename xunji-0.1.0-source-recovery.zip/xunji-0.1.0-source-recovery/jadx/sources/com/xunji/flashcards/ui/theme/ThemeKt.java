            package com.xunji.flashcards.ui.theme;

            import androidx.compose.foundation.DarkThemeKt;
            import androidx.compose.material3.ColorScheme;
            import androidx.compose.material3.ColorSchemeKt;
            import androidx.compose.material3.MaterialThemeKt;
            import androidx.compose.runtime.Composer;
            import androidx.compose.runtime.ComposerKt;
            import androidx.compose.runtime.RecomposeScopeImplKt;
            import androidx.compose.runtime.ScopeUpdateScope;
            import androidx.compose.ui.graphics.Color;
            import com.xunji.core.model.ThemeMode;
            import kotlin.Metadata;
            import kotlin.NoWhenBranchMatchedException;
            import kotlin.Unit;
            import kotlin.jvm.functions.Function2;
            import kotlin.jvm.internal.Intrinsics;
            
            /* JADX INFO: compiled from: Theme.kt */
            /* JADX INFO: loaded from: classes13.dex */
            @Metadata(d1 = {"\u0000\"\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a*\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\u0011\u0010\u0007\u001a\r\u0012\u0004\u0012\u00020\u00040\b¢\u0006\u0002\b\tH\u0007¢\u0006\u0002\u0010\n\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Light", "Landroidx/compose/material3/ColorScheme;", "Dark", "XunjiTheme", "", "mode", "Lcom/xunji/core/model/ThemeMode;", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(Lcom/xunji/core/model/ThemeMode;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {2, 2, 0}, xi = 48)
/* 7 */     public final class ThemeKt {
                private static final ColorScheme Light = ColorSchemeKt.m2558lightColorScheme_VG5OTI$default(ColorKt.getForest(), Color.INSTANCE.m5697getWhite0d7_KjU(), androidx.compose.ui.graphics.ColorKt.Color(4293062116L), ColorKt.getForest(), 0, ColorKt.getAmber(), Color.INSTANCE.m5697getWhite0d7_KjU(), androidx.compose.ui.graphics.ColorKt.Color(4294240207L), ColorKt.getAmber(), 0, 0, 0, 0, ColorKt.getWarmWhite(), ColorKt.getInk(), Color.INSTANCE.m5697getWhite0d7_KjU(), ColorKt.getInk(), androidx.compose.ui.graphics.ColorKt.Color(4293849321L), ColorKt.getMuted(), 0, 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4288885298L), 0, 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4285628535L), androidx.compose.ui.graphics.ColorKt.Color(4292403158L), 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4293914598L), 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4294638068L), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1279779312, 65533, null);
                private static final ColorScheme Dark = ColorSchemeKt.m2552darkColorScheme_VG5OTI$default(androidx.compose.ui.graphics.ColorKt.Color(4288992188L), androidx.compose.ui.graphics.ColorKt.Color(4279384877L), androidx.compose.ui.graphics.ColorKt.Color(4280700736L), androidx.compose.ui.graphics.ColorKt.Color(4292209629L), 0, androidx.compose.ui.graphics.ColorKt.Color(4293508990L), androidx.compose.ui.graphics.ColorKt.Color(4282265108L), androidx.compose.ui.graphics.ColorKt.Color(4282988834L), androidx.compose.ui.graphics.ColorKt.Color(4294433191L), 0, 0, 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4279376919L), androidx.compose.ui.graphics.ColorKt.Color(4293258724L), androidx.compose.ui.graphics.ColorKt.Color(4280101411L), androidx.compose.ui.graphics.ColorKt.Color(4293258724L), androidx.compose.ui.graphics.ColorKt.Color(4280957232L), androidx.compose.ui.graphics.ColorKt.Color(4290299836L), 0, 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4294948011L), 0, 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4286815115L), androidx.compose.ui.graphics.ColorKt.Color(4282010432L), 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4280365095L), 0, 0, androidx.compose.ui.graphics.ColorKt.Color(4279706396L), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1279779312, 65533, null);

                /* JADX INFO: compiled from: Theme.kt */
                @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
                public static final /* synthetic */ class WhenMappings {
                    public static final /* synthetic */ int[] $EnumSwitchMapping$0;

                    static {
                        int[] iArr = new int[ThemeMode.values().length];
                        try {
                            iArr[ThemeMode.SYSTEM.ordinal()] = 1;
                        } catch (NoSuchFieldError e) {
                        }
                        try {
                            iArr[ThemeMode.DARK.ordinal()] = 2;
                        } catch (NoSuchFieldError e2) {
                        }
                        try {
                            iArr[ThemeMode.LIGHT.ordinal()] = 3;
                        } catch (NoSuchFieldError e3) {
                        }
                        $EnumSwitchMapping$0 = iArr;
                    }
                }

                /* JADX INFO: Access modifiers changed from: private */
                public static final Unit XunjiTheme$lambda$0(ThemeMode themeMode, Function2 function2, int i, int i2, Composer composer, int i3) {
                    XunjiTheme(themeMode, function2, composer, RecomposeScopeImplKt.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }

                /* JADX WARN: Code duplicated, block: B:43:0x00a7  */
                /* JADX WARN: Code duplicated, block: B:44:0x00aa  */
                /* JADX WARN: Code duplicated, block: B:47:0x00c2  */
/* 8 */         public static final void XunjiTheme(final ThemeMode mode, Function2<? super Composer, ? super Integer, Unit> content, Composer $composer, final int $changed, final int i) {
                    final Function2<? super Composer, ? super Integer, Unit> function2;
                    boolean dark;
                    ColorScheme colorScheme;
                    Intrinsics.checkNotNullParameter(content, "content");
/* 9 */             Composer $composer2 = $composer.startRestartGroup(-1595784286);
                    ComposerKt.sourceInformation($composer2, "C(XunjiTheme)N(mode,content)10@1607L93:Theme.kt#77exof");
                    int $dirty = $changed;
                    int i2 = i & 1;
                    if (i2 != 0) {
                        $dirty |= 6;
                    } else if (($changed & 6) == 0) {
                        $dirty |= $composer2.changed(mode == null ? -1 : mode.ordinal()) ? 4 : 2;
                    }
                    if (($changed & 48) == 0) {
                        $dirty |= $composer2.changedInstance(content) ? 32 : 16;
                    }
                    boolean zIsSystemInDarkTheme = false;
                    if (!$composer2.shouldExecute(($dirty & 19) != 18, $dirty & 1)) {
/* 9 */                 function2 = content;
                        $composer2.skipToGroupEnd();
                    } else {
                        if (i2 != 0) {
                            mode = ThemeMode.SYSTEM;
                        }
                        if (ComposerKt.isTraceInProgress()) {
/* 9 */                     ComposerKt.traceEventStart(-1595784286, $dirty, -1, "com.xunji.flashcards.ui.theme.XunjiTheme (Theme.kt:8)");
                        }
                        switch (WhenMappings.$EnumSwitchMapping$0[mode.ordinal()]) {
                            case 1:
                                $composer2.startReplaceGroup(-245370313);
                                ComposerKt.sourceInformation($composer2, "9@1538L21");
                                zIsSystemInDarkTheme = DarkThemeKt.isSystemInDarkTheme($composer2, 0);
                                $composer2.endReplaceGroup();
                                dark = zIsSystemInDarkTheme;
/* 11 */                        if (dark) {
                                    colorScheme = Dark;
                                } else {
                                    colorScheme = Light;
                                }
                                function2 = content;
                                MaterialThemeKt.MaterialTheme(colorScheme, null, TypeKt.getXunjiTypography(), function2, $composer2, (($dirty << 6) & 7168) | 384, 2);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                                break;
                            case 2:
                                $composer2.startReplaceGroup(983493289);
                                $composer2.endReplaceGroup();
                                zIsSystemInDarkTheme = true;
                                dark = zIsSystemInDarkTheme;
/* 11 */                        if (dark) {
                                    colorScheme = Dark;
                                } else {
                                    colorScheme = Light;
                                }
                                function2 = content;
                                MaterialThemeKt.MaterialTheme(colorScheme, null, TypeKt.getXunjiTypography(), function2, $composer2, (($dirty << 6) & 7168) | 384, 2);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                                break;
                            case 3:
                                $composer2.startReplaceGroup(983515150);
                                $composer2.endReplaceGroup();
                                dark = zIsSystemInDarkTheme;
/* 11 */                        if (dark) {
                                    colorScheme = Dark;
                                } else {
                                    colorScheme = Light;
                                }
                                function2 = content;
                                MaterialThemeKt.MaterialTheme(colorScheme, null, TypeKt.getXunjiTypography(), function2, $composer2, (($dirty << 6) & 7168) | 384, 2);
                                if (ComposerKt.isTraceInProgress()) {
                                    ComposerKt.traceEventEnd();
                                }
                                break;
                            default:
                                $composer2.startReplaceGroup(-245371228);
                                $composer2.endReplaceGroup();
                                throw new NoWhenBranchMatchedException();
                        }
                    }
/* 12 */            ScopeUpdateScope scopeUpdateScopeEndRestartGroup = $composer2.endRestartGroup();
                    if (scopeUpdateScopeEndRestartGroup != null) {
                        scopeUpdateScopeEndRestartGroup.updateScope(new Function2() { // from class: com.xunji.flashcards.ui.theme.ThemeKt$$ExternalSyntheticLambda0
                            @Override // kotlin.jvm.functions.Function2
                            public final Object invoke(Object obj, Object obj2) {
                                return ThemeKt.XunjiTheme$lambda$0(mode, function2, $changed, i, (Composer) obj, ((Integer) obj2).intValue());
                            }
                        });
                    }
                }
            }

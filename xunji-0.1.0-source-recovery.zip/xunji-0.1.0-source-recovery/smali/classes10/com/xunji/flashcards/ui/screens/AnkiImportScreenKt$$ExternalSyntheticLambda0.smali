.class public final synthetic Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

.field public final synthetic f$1:Lcom/xunji/flashcards/anki/AnkiImportReport;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Ljava/util/List;

.field public final synthetic f$4:I

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

.field public final synthetic f$7:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;)V
    .registers 9

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$1:Lcom/xunji/flashcards/anki/AnkiImportReport;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$2:Ljava/util/List;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$3:Ljava/util/List;

    iput p5, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$4:I

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$5:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$6:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    iput-object p8, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$7:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$1:Lcom/xunji/flashcards/anki/AnkiImportReport;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$2:Ljava/util/List;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$3:Ljava/util/List;

    iget v4, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$4:I

    iget-object v5, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$5:Lkotlin/jvm/functions/Function0;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$6:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    iget-object v7, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;->f$7:Lkotlin/jvm/functions/Function0;

    move-object v8, p1

    check-cast v8, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static/range {v0 .. v8}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->$r8$lambda$mS87fKe5EOaIqt9cFcec6vBC1fw(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/AnkiImportUiState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;->f$0:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;->f$1:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;->f$0:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;->f$1:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->$r8$lambda$AZb325Tq2xHT_h_LExtQSWaUpUk(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

.field public final synthetic f$1:I

.field public final synthetic f$2:Lcom/xunji/flashcards/ui/AnkiImportViewModel;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    iput p2, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$1:I

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$2:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/flashcards/ui/AnkiImportUiState;

    iget v1, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$1:I

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;->f$2:Lcom/xunji/flashcards/ui/AnkiImportViewModel;

    move-object v3, p1

    check-cast v3, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v4, p2

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->$r8$lambda$g1hzSCd_3h6aExY94FUuIRPOwq8(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

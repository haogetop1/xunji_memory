.class public final Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;
.super Ljava/lang/Object;
.source "AnkiImportScreen.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiImportScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiImportScreen.kt\ncom/xunji/flashcards/ui/screens/AnkiImportScreenKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 10 _Maps.kt\nkotlin/collections/MapsKt___MapsKt\n*L\n1#1,109:1\n113#2:110\n113#2:111\n113#2:119\n113#2:158\n113#2:169\n113#2:180\n1282#3,6:112\n1282#3,6:163\n1282#3,6:174\n1282#3,6:257\n1282#3,6:263\n1#4:118\n99#5:120\n95#5,10:121\n106#5:162\n99#5,6:186\n99#5:219\n95#5,10:220\n106#5:272\n106#5:276\n80#6,6:131\n87#6,3:146\n90#6,2:155\n94#6:161\n80#6,6:192\n87#6,3:207\n90#6,2:216\n80#6,6:230\n87#6,3:245\n90#6,2:254\n94#6:271\n94#6:275\n391#7,9:137\n400#7:157\n401#7,2:159\n391#7,9:198\n400#7:218\n391#7,9:236\n400#7:256\n401#7,2:269\n401#7,2:273\n4360#8,6:149\n4360#8,6:210\n4360#8,6:248\n1563#9:170\n1634#9,3:171\n1068#9:181\n1869#9,2:182\n1869#9,2:184\n216#10,2:277\n*S KotlinDebug\n*F\n+ 1 AnkiImportScreen.kt\ncom/xunji/flashcards/ui/screens/AnkiImportScreenKt\n*L\n25#1:110\n26#1:111\n37#1:119\n38#1:158\n51#1:169\n67#1:180\n27#1:112,6\n51#1:163,6\n65#1:174,6\n91#1:257,6\n92#1:263,6\n37#1:120\n37#1:121,10\n37#1:162\n88#1:186,6\n90#1:219\n90#1:220,10\n90#1:272\n88#1:276\n37#1:131,6\n37#1:146,3\n37#1:155,2\n37#1:161\n88#1:192,6\n88#1:207,3\n88#1:216,2\n90#1:230,6\n90#1:245,3\n90#1:254,2\n90#1:271\n88#1:275\n37#1:137,9\n37#1:157\n37#1:159,2\n88#1:198,9\n88#1:218\n90#1:236,9\n90#1:256\n90#1:269,2\n88#1:273,2\n37#1:149,6\n88#1:210,6\n90#1:248,6\n62#1:170\n62#1:171,3\n74#1:181\n74#1:182,2\n84#1:184,2\n103#1:277,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a9\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0001\u00a2\u0006\u0002\u0010\t\u00a8\u0006\n"
    }
    d2 = {
        "AnkiImportScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/AnkiImportUiState;",
        "viewModel",
        "Lcom/xunji/flashcards/ui/AnkiImportViewModel;",
        "onChoose",
        "Lkotlin/Function0;",
        "onDone",
        "(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-D5Lsj4IJ8bxVUpaqy04kf9Akws(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$2$0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$3vEGazoNkvjuk6MDJCOx8U5FLec(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$5$0(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6EHdE7QXgEON9SYh06Kk5YHZP0s(Lcom/xunji/flashcards/anki/ImportPreviewCard;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$6$0(Lcom/xunji/flashcards/anki/ImportPreviewCard;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$AZb325Tq2xHT_h_LExtQSWaUpUk(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$7$0$0$0$0(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$IvfgyWyrrgP7JfoW7xVOKhcc-2Y(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$1(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LYXJ_x5p1T5Ja3eEWR8mqPEX7KQ(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$3$0(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TWXGJRmNLgCCVLJ3qhz38VCPJqw(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$8$0(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Wh6CQMWpNwPEpo9Kf6de9gB_0aQ(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$8$0$0(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XIRKh_ssM543HgQlFP3H3c0p4P8(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$7$0$0$1$0(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$eSHas5ADysWylu1o0oqbhEkrP0I(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$5(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$eTOr74_J1V4fQNJxDk8MC2apVh0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$1(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fqUbz_MCERjrfIZcrpA4Wy-G2RY(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$4(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g1hzSCd_3h6aExY94FUuIRPOwq8(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$7(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$h-ojQQSTFVUa0RCrj8R2D5EoWTo(Lcom/xunji/flashcards/anki/ImportResult;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$0$0(Lcom/xunji/flashcards/anki/ImportResult;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$igjtUzsLUE9Vy-0UJJDVvrllO5k(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$6(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mS87fKe5EOaIqt9cFcec6vBC1fw(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$oVgV4g895prlR-OTsbywp4bE4y0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$2(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zx3WFUY2QBaMp1lMQqYAqyeSzZE(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen$lambda$0$0$4$0(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final AnkiImportScreen(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 29
    .param p0, "state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;
    .param p1, "viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p2, "onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onDone"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/AnkiImportUiState;",
            "Lcom/xunji/flashcards/ui/AnkiImportViewModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v9, p5

    const-string v0, "state"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "viewModel"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onChoose"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDone"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    const v0, 0x6823ba0e

    move-object/from16 v5, p4

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(AnkiImportScreen)N(state,viewModel,onChoose,onDone)26@1152L4808,22@945L5015:AnkiImportScreen.kt#i35lj1"

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p5

    .local v5, "$dirty":I
    and-int/lit8 v6, v9, 0x6

    if-nez v6, :cond_3c

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3a

    const/4 v6, 0x4

    goto :goto_3b

    :cond_3a
    const/4 v6, 0x2

    :goto_3b
    or-int/2addr v5, v6

    :cond_3c
    and-int/lit8 v6, v9, 0x30

    if-nez v6, :cond_4c

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_49

    const/16 v6, 0x20

    goto :goto_4b

    :cond_49
    const/16 v6, 0x10

    :goto_4b
    or-int/2addr v5, v6

    :cond_4c
    and-int/lit16 v6, v9, 0x180

    if-nez v6, :cond_5c

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_59

    const/16 v6, 0x100

    goto :goto_5b

    :cond_59
    const/16 v6, 0x80

    :goto_5b
    or-int/2addr v5, v6

    :cond_5c
    and-int/lit16 v6, v9, 0xc00

    if-nez v6, :cond_6c

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_69

    const/16 v6, 0x800

    goto :goto_6b

    :cond_69
    const/16 v6, 0x400

    :goto_6b
    or-int/2addr v5, v6

    :cond_6c
    move v11, v5

    .end local v5    # "$dirty":I
    .local v11, "$dirty":I
    and-int/lit16 v5, v11, 0x493

    const/16 v6, 0x492

    const/4 v13, 0x1

    if-eq v5, v6, :cond_76

    move v5, v13

    goto :goto_77

    :cond_76
    const/4 v5, 0x0

    :goto_77
    and-int/lit8 v6, v11, 0x1

    invoke-interface {v10, v5, v6}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_19b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_8b

    const/4 v5, -0x1

    const-string v6, "com.xunji.flashcards.ui.screens.AnkiImportScreen (AnkiImportScreen.kt:16)"

    invoke-static {v0, v11, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 18
    :cond_8b
    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPreview()Lcom/xunji/flashcards/anki/AnkiImportReport;

    move-result-object v0

    .line 19
    .local v0, "report":Lcom/xunji/flashcards/anki/AnkiImportReport;
    const/4 v5, 0x0

    if-eqz v0, :cond_97

    invoke-virtual {v0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getAffectedCards()Ljava/util/List;

    move-result-object v6

    goto :goto_98

    :cond_97
    move-object v6, v5

    :goto_98
    if-nez v6, :cond_9e

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v6

    .line 20
    .local v6, "affected":Ljava/util/List;
    :cond_9e
    const/16 v14, 0x14

    .line 21
    .local v14, "pageSize":I
    invoke-interface {v6}, Ljava/util/List;->size()I

    move-result v15

    add-int/2addr v15, v14

    sub-int/2addr v15, v13

    div-int/2addr v15, v14

    .line 22
    .local v15, "pages":I
    if-eqz v0, :cond_b2

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v12

    invoke-virtual {v0, v12, v14, v13}, Lcom/xunji/flashcards/anki/AnkiImportReport;->page(IIZ)Ljava/util/List;

    move-result-object v12

    goto :goto_b3

    :cond_b2
    move-object v12, v5

    :goto_b3
    if-nez v12, :cond_b9

    invoke-static {}, Lkotlin/collections/CollectionsKt;->emptyList()Ljava/util/List;

    move-result-object v12

    .line 24
    .local v12, "pageCards":Ljava/util/List;
    :cond_b9
    sget-object v16, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v8, v16

    check-cast v8, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    invoke-static {v8, v7, v13, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const-string v7, "anki-import-screen"

    invoke-static {v5, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v18

    .line 25
    const/16 v5, 0x16

    .local v5, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 110
    .local v7, "$i$f$getDp\\1\\25":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 25
    .end local v5    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\25":I
    const/16 v7, 0x12

    .local v7, "$this$dp\\2":I
    const/4 v8, 0x0

    .line 110
    .local v8, "$i$f$getDp\\2\\25":I
    int-to-float v13, v7

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 25
    .end local v7    # "$this$dp\\2":I
    .end local v8    # "$i$f$getDp\\2\\25":I
    const/16 v8, 0x16

    .local v8, "$this$dp\\3":I
    const/4 v13, 0x0

    .line 110
    .local v13, "$i$f$getDp\\3\\25":I
    int-to-float v3, v8

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 25
    .end local v8    # "$this$dp\\3":I
    .end local v13    # "$i$f$getDp\\3\\25":I
    const/16 v8, 0x1c

    .local v8, "$this$dp\\4":I
    const/4 v13, 0x0

    .line 110
    .local v13, "$i$f$getDp\\4\\25":I
    int-to-float v4, v8

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 25
    .end local v8    # "$this$dp\\4":I
    .end local v13    # "$i$f$getDp\\4\\25":I
    invoke-static {v5, v7, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v13

    .line 26
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v4, 0x12

    .local v4, "$this$dp\\5":I
    const/4 v5, 0x0

    .line 111
    .local v5, "$i$f$getDp\\5\\26":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 26
    .end local v4    # "$this$dp\\5":I
    .end local v5    # "$i$f$getDp\\5\\26":I
    invoke-virtual {v3, v4}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    move-object/from16 v20, v3

    check-cast v20, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .line 27
    const v3, -0x11e2362a

    const-string v4, "CC(remember):AnkiImportScreen.kt#9igjgp"

    invoke-static {v10, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    and-int/lit16 v4, v11, 0x380

    const/16 v5, 0x100

    if-ne v4, v5, :cond_119

    const/4 v4, 0x1

    goto :goto_11a

    :cond_119
    const/4 v4, 0x0

    :goto_11a
    or-int/2addr v3, v4

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v4

    or-int/2addr v3, v4

    and-int/lit16 v4, v11, 0x1c00

    const/16 v5, 0x800

    if-ne v4, v5, :cond_138

    const/16 v19, 0x1

    goto :goto_13a

    :cond_138
    const/16 v19, 0x0

    :goto_13a
    or-int v16, v3, v19

    .local v16, "invalid\\6":Z
    move-object v3, v10

    .local v3, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 112
    .local v17, "$i$f$cache\\6\\27":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\6":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 113
    .local v19, "$i$a$-let-ComposerKt$cache$1\\7\\112\\6":I
    if-nez v16, :cond_157

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v4, v5, :cond_150

    goto :goto_157

    .line 117
    :cond_150
    move-object v2, v0

    move-object v0, v4

    move-object v4, v12

    move v5, v15

    move-object v12, v3

    move-object v3, v6

    goto :goto_16f

    .line 114
    :cond_157
    :goto_157
    const/16 v21, 0x0

    .line 27
    .local v21, "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1\\8\\114\\0":I
    move-object v2, v0

    .end local v0    # "report":Lcom/xunji/flashcards/anki/AnkiImportReport;
    .local v2, "report":Lcom/xunji/flashcards/anki/AnkiImportReport;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;

    move-object/from16 v7, p1

    move-object/from16 v8, p3

    move v5, v15

    move-object v15, v4

    move-object v4, v12

    move-object v12, v3

    move-object v3, v6

    move-object/from16 v6, p2

    .end local v6    # "affected":Ljava/util/List;
    .local v3, "affected":Ljava/util/List;
    .local v4, "pageCards":Ljava/util/List;
    .local v5, "pages":I
    .local v12, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .local v15, "it\\6":Ljava/lang/Object;
    invoke-direct/range {v0 .. v8}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;)V

    .line 114
    .end local v21    # "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1\\8\\114\\0":I
    nop

    .line 115
    .local v0, "value\\7":Ljava/lang/Object;
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 116
    nop

    .line 112
    .end local v0    # "value\\7":Ljava/lang/Object;
    .end local v15    # "it\\6":Ljava/lang/Object;
    .end local v19    # "$i$a$-let-ComposerKt$cache$1\\7\\112\\6":I
    :goto_16f
    nop

    .line 27
    .end local v12    # "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\6":Z
    .end local v17    # "$i$f$cache\\6\\27":I
    move-object/from16 v19, v0

    check-cast v19, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 23
    move v0, v11

    .end local v11    # "$dirty":I
    .local v0, "$dirty":I
    const/4 v11, 0x0

    move-object v12, v13

    const/4 v13, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move v1, v14

    move-object/from16 v14, v20

    move-object/from16 v20, v10

    move-object/from16 v10, v18

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v14    # "pageSize":I
    .local v1, "pageSize":I
    .local v20, "$composer":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    const/16 v21, 0x6186

    const/16 v22, 0x1ea

    move v6, v0

    .end local v0    # "$dirty":I
    .local v6, "$dirty":I
    invoke-static/range {v10 .. v22}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1a1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "pageSize":I
    .end local v2    # "report":Lcom/xunji/flashcards/anki/AnkiImportReport;
    .end local v3    # "affected":Ljava/util/List;
    .end local v4    # "pageCards":Ljava/util/List;
    .end local v5    # "pages":I
    goto :goto_1a1

    .line 17
    .end local v6    # "$dirty":I
    .end local v20    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$dirty":I
    :cond_19b
    move-object/from16 v20, v10

    move v6, v11

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v11    # "$dirty":I
    .restart local v6    # "$dirty":I
    .restart local v20    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 108
    :cond_1a1
    :goto_1a1
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_1b8

    new-instance v0, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda9;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move v5, v9

    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda9;-><init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_1b8
    return-void
.end method

.method private static final AnkiImportScreen$lambda$0$0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Ljava/util/List;ILkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 25
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;
    .param p1, "$report"    # Lcom/xunji/flashcards/anki/AnkiImportReport;
    .param p2, "$affected"    # Ljava/util/List;
    .param p3, "$pageCards"    # Ljava/util/List;
    .param p4, "$pages"    # I
    .param p5, "$onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p6, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p7, "$onDone"    # Lkotlin/jvm/functions/Function0;
    .param p8, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    move-object/from16 v4, p5

    move-object/from16 v5, p6

    const-string v6, "$this$LazyColumn"

    move-object/from16 v7, p8

    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 28
    sget-object v6, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;

    invoke-virtual {v6}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->getLambda$697298713$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 29
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPreviousCompleted()Lcom/xunji/flashcards/anki/ImportResult;

    move-result-object v6

    const/4 v14, 0x1

    if-eqz v6, :cond_42

    .line 118
    .local v6, "previous\\1":Lcom/xunji/flashcards/anki/ImportResult;
    const/4 v13, 0x0

    .line 29
    .local v13, "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$1\\1\\29\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda17;

    invoke-direct {v7, v6}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda17;-><init>(Lcom/xunji/flashcards/anki/ImportResult;)V

    const v8, -0x8b6f538

    invoke-static {v8, v14, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v10, v7

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 31
    nop

    .line 29
    .end local v6    # "previous\\1":Lcom/xunji/flashcards/anki/ImportResult;
    .end local v13    # "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$1\\1\\29\\0":I
    nop

    .line 32
    :cond_42
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getBusy()Z

    move-result v6

    if-nez v6, :cond_6e

    if-nez v1, :cond_6e

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getResult()Lcom/xunji/flashcards/anki/ImportResult;

    move-result-object v6

    if-nez v6, :cond_6e

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getError()Ljava/lang/String;

    move-result-object v6

    if-nez v6, :cond_6e

    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v6, v4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function0;)V

    const v7, 0x5b7cdade

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 35
    :cond_6e
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getBusy()Z

    move-result v6

    if-eqz v6, :cond_8c

    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v6, v0, v5}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda2;-><init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;)V

    const v7, 0x5fd4b207

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 54
    :cond_8c
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getError()Ljava/lang/String;

    move-result-object v6

    if-eqz v6, :cond_ad

    .line 118
    .local v6, "error\\2":Ljava/lang/String;
    const/4 v13, 0x0

    .line 54
    .local v13, "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$4\\2\\54\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v7, v6, v4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda3;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    const v8, 0x20bd0ca2

    invoke-static {v8, v14, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v10, v7

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 56
    nop

    .line 54
    .end local v6    # "error\\2":Ljava/lang/String;
    .end local v13    # "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$4\\2\\54\\0":I
    nop

    .line 57
    :cond_ad
    if-eqz v1, :cond_129

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getBusy()Z

    move-result v6

    if-nez v6, :cond_129

    .line 58
    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v6, v1, v2, v5, v4}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;)V

    const v7, 0x45f6ef66

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 70
    move-object v6, v2

    check-cast v6, Ljava/util/Collection;

    invoke-interface {v6}, Ljava/util/Collection;->isEmpty()Z

    move-result v6

    if-nez v6, :cond_126

    .line 71
    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v6, v1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda5;-><init>(Lcom/xunji/flashcards/anki/AnkiImportReport;)V

    const v7, -0x3850a455

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 79
    invoke-interface/range {p3 .. p3}, Ljava/util/List;->size()I

    move-result v8

    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda6;

    move-object/from16 v15, p3

    invoke-direct {v6, v15}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda6;-><init>(Ljava/util/List;)V

    const v7, -0x3a67a37e

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v11, v6

    check-cast v11, Lkotlin/jvm/functions/Function4;

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v10, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v13}, Landroidx/compose/foundation/lazy/LazyListScope;->items$default(Landroidx/compose/foundation/lazy/LazyListScope;ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;ILjava/lang/Object;)V

    .line 87
    if-le v3, v14, :cond_12b

    new-instance v6, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v6, v0, v3, v5}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda7;-><init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;)V

    const v7, 0x2074f5b0

    invoke-static {v7, v14, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v10, v6

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    goto :goto_12b

    .line 70
    :cond_126
    move-object/from16 v15, p3

    goto :goto_12b

    .line 57
    :cond_129
    move-object/from16 v15, p3

    .line 98
    :cond_12b
    :goto_12b
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getResult()Lcom/xunji/flashcards/anki/ImportResult;

    move-result-object v6

    if-eqz v6, :cond_14e

    .line 118
    .local v6, "result\\3":Lcom/xunji/flashcards/anki/ImportResult;
    const/4 v13, 0x0

    .line 98
    .local v13, "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$9\\3\\98\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda8;

    move-object/from16 v8, p7

    invoke-direct {v7, v6, v8}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;)V

    const v9, 0x1f76ccd0

    invoke-static {v9, v14, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    move-object v10, v7

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v7, p8

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 106
    nop

    .line 98
    .end local v6    # "result\\3":Lcom/xunji/flashcards/anki/ImportResult;
    .end local v13    # "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$9\\3\\98\\0":I
    nop

    .line 107
    :cond_14e
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v6
.end method

.method private static final AnkiImportScreen$lambda$0$0$0$0(Lcom/xunji/flashcards/anki/ImportResult;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8
    .param p0, "$previous"    # Lcom/xunji/flashcards/anki/ImportResult;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C29@1294L51:AnkiImportScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eq v0, v1, :cond_13

    const/4 v0, 0x1

    goto :goto_14

    :cond_13
    move v0, v2

    :goto_14
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2b

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:29)"

    const v3, -0x8b6f538

    invoke-static {v3, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 30
    :cond_2b
    invoke-virtual {p0}, Lcom/xunji/flashcards/anki/ImportResult;->getAddedCards()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u4e0a\u4e00\u4efd\u724c\u7ec4\u5df2\u5b8c\u6210\u5bfc\u5165\uff1a\u65b0\u589e "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5361\u7247\u3002"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-static {v0, v2, p2, v2, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_59

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_59

    .line 29
    :cond_56
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 31
    :cond_59
    :goto_59
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$1(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14
    .param p0, "$onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C32@1467L58:AnkiImportScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    if-eq v0, v1, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_42

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:32)"

    const v2, 0x5b7cdade

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_2a
    const/16 v8, 0x1b6

    const/4 v9, 0x0

    const-string v3, "\u9009\u62e9\u724c\u7ec4\u6587\u4ef6"

    const-string v4, "\u9009\u62e9 .apkg \u6587\u4ef6\u5f00\u59cb\u9884\u68c0\u3002"

    const-string v5, "\u9009\u62e9\u6587\u4ef6"

    move-object v6, p0

    move-object v7, p2

    .end local p0    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$onChoose":Lkotlin/jvm/functions/Function0;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_47

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_47

    .line 32
    .end local v6    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p0    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .restart local p2    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_42
    move-object v6, p0

    move-object v7, p2

    .end local p0    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 34
    :cond_47
    :goto_47
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final AnkiImportScreen$lambda$0$0$2(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 11
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C35@1610L1019,35@1579L1050:AnkiImportScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:35)"

    const v4, 0x5fd4b207

    invoke-static {v4, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 36
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda12;

    invoke-direct {v1, p0, p1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda12;-><init>(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;)V

    const v4, 0xb6d10d7

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p3, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    .line 35
    :cond_53
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 53
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$2$0(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 60
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p2, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p1

    move-object/from16 v11, p3

    move/from16 v14, p4

    const-string v1, "$this$Paper"

    move-object/from16 v15, p2

    invoke-static {v15, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C36@1628L327,50@2512L17,50@2497L118:AnkiImportScreen.kt#i35lj1"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v14, 0x11

    const/16 v2, 0x10

    if-eq v1, v2, :cond_1a

    const/4 v1, 0x1

    goto :goto_1b

    :cond_1a
    const/4 v1, 0x0

    :goto_1b
    and-int/lit8 v2, v14, 0x1

    invoke-interface {v11, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_2d9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_32

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:36)"

    const v5, 0xb6d10d7

    invoke-static {v5, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 37
    :cond_32
    sget-object v1, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v1

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v5, 0xe

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 119
    .local v6, "$i$f$getDp\\1\\37":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 37
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\37":I
    invoke-virtual {v2, v5}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v5, 0x1b0

    .local v1, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v5, "$changed\\2":I
    move-object/from16 v6, p3

    .local v6, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 120
    .local v7, "$i$f$Row\\2\\37":I
    const v8, 0x3255a44b

    const-string v9, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 121
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 126
    .local v8, "modifier\\2":Landroidx/compose/ui/Modifier;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v2, v1, v6, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 130
    .local v9, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 127
    nop

    .local v10, "$changed\\3":I
    move-object v12, v8

    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 131
    .local v13, "$i$f$Layout\\3\\127":I
    const v3, -0x451e1427

    const-string v4, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 132
    const/4 v3, 0x0

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->hashCode(J)I

    move-result v3

    .line 133
    .local v3, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 134
    .local v4, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v16, v1

    .end local v1    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v16, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v6, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 136
    .local v1, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    move-object/from16 v18, v2

    .end local v2    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v18, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shl-int/lit8 v2, v10, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 135
    nop

    .local v2, "$changed\\4":I
    move-object/from16 v19, v17

    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 137
    .local v17, "$i$f$ReusableComposeNode\\4\\135":I
    move/from16 v20, v2

    .end local v2    # "$changed\\4":I
    .local v20, "$changed\\4":I
    const v2, -0x20f7d59c

    move/from16 v21, v3

    .end local v3    # "compositeKeyHash\\3":I
    .local v21, "compositeKeyHash\\3":I
    const-string v3, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 138
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_b2

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 139
    :cond_b2
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 140
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_c1

    .line 141
    move-object/from16 v2, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c6

    .line 143
    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c1
    move-object/from16 v2, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 145
    :goto_c6
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 146
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\145\\3":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v2

    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 147
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 148
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 149
    .local v22, "$i$f$set-impl\\6\\148":I
    move-object/from16 v24, v3

    .local v24, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 150
    .local v25, "$i$a$-with-Updater$set$1\\7\\149\\6":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_108

    move-object/from16 v26, v4

    .end local v4    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v26, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move/from16 v27, v5

    .end local v5    # "$changed\\2":I
    .local v27, "$changed\\2":I
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_105

    goto :goto_10c

    :cond_105
    move-object/from16 v5, v24

    goto :goto_11c

    .end local v26    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v27    # "$changed\\2":I
    .restart local v4    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$changed\\2":I
    :cond_108
    move-object/from16 v26, v4

    move/from16 v27, v5

    .line 151
    .end local v4    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "$changed\\2":I
    .restart local v26    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v27    # "$changed\\2":I
    :goto_10c
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 152
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 154
    :goto_11c
    nop

    .line 149
    .end local v5    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\7\\149\\6":I
    nop

    .line 154
    nop

    .line 155
    .end local v2    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\6\\148":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 156
    nop

    .line 145
    .end local v3    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\145\\3":I
    nop

    .line 157
    shr-int/lit8 v2, v20, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\8":I
    move-object v3, v6

    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 128
    .local v4, "$i$a$-Layout-RowKt$Row$1\\8\\157\\2":I
    const v5, 0x56ccd6f5

    move-object/from16 v19, v1

    .end local v1    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v19, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v27, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$AnkiImportScreen_u24lambda_u240_u240_u242_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v36, v3

    .local v36, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 38
    .local v22, "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$1\\9\\128\\0":I
    move-object/from16 v24, v1

    .end local v1    # "$this$AnkiImportScreen_u24lambda_u240_u240_u242_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v24, "$this$AnkiImportScreen_u24lambda_u240_u240_u242_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const v1, -0x585a79ce

    move/from16 v25, v2

    .end local v2    # "$changed\\8":I
    .local v25, "$changed\\8":I
    const-string v2, "C37@1755L67,38@1914L10,38@1843L94:AnkiImportScreen.kt#i35lj1"

    move-object/from16 v54, v3

    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x1c

    .local v2, "$this$dp\\10":I
    const/16 v28, 0x0

    .line 158
    .local v28, "$i$f$getDp\\10\\38":I
    nop

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    int-to-float v3, v2

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 38
    .end local v2    # "$this$dp\\10":I
    .end local v28    # "$i$f$getDp\\10\\38":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v28

    const/4 v1, 0x3

    .local v1, "$this$dp\\11":I
    const/4 v2, 0x0

    .line 158
    .local v2, "$i$f$getDp\\11\\38":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v31

    .line 38
    .end local v1    # "$this$dp\\11":I
    .end local v2    # "$i$f$getDp\\11\\38":I
    const-wide/16 v29, 0x0

    const-wide/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v37, 0x186

    const/16 v38, 0x3a

    invoke-static/range {v28 .. v38}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-4lLiAd8(Landroidx/compose/ui/Modifier;JFJIFLandroidx/compose/runtime/Composer;II)V

    .line 39
    move-object/from16 v3, v36

    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getCommitting()Z

    move-result v1

    if-eqz v1, :cond_189

    const-string v1, "\u6b63\u5728\u5bfc\u5165\u2026"

    goto :goto_18b

    :cond_189
    const-string v1, "\u6b63\u5728\u9884\u68c0\u2026"

    :goto_18b
    move-object/from16 v28, v1

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v49

    const/16 v52, 0x0

    const v53, 0x1fffe

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v51, 0x0

    move-object/from16 v50, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v53}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 38
    .end local v50    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 40
    nop

    .line 128
    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\9":I
    .end local v22    # "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$1\\9\\128\\0":I
    .end local v24    # "$this$AnkiImportScreen_u24lambda_u240_u240_u242_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 157
    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\8\\157\\2":I
    .end local v25    # "$changed\\8":I
    .end local v54    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 159
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 137
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 160
    nop

    .line 131
    .end local v17    # "$i$f$ReusableComposeNode\\4\\135":I
    .end local v20    # "$changed\\4":I
    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 161
    nop

    .line 120
    .end local v10    # "$changed\\3":I
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\3\\127":I
    .end local v19    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v21    # "compositeKeyHash\\3":I
    .end local v26    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 162
    nop

    .line 41
    .end local v6    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$Row\\2\\37":I
    .end local v8    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v9    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v16    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v18    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v27    # "$changed\\2":I
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getProgress()Lcom/xunji/core/anki/ImportProgress;

    move-result-object v1

    const/4 v2, 0x2

    if-nez v1, :cond_1ee

    const v1, -0x56df5fe2

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_1e9
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_268

    :cond_1ee
    const v3, -0x56df5fe1

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*48@2379L83"

    invoke-static {v11, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .local v1, "progress\\12":Lcom/xunji/core/anki/ImportProgress;
    const/4 v3, 0x0

    .line 42
    .local v3, "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$2\\12\\41\\0":I
    invoke-virtual {v1}, Lcom/xunji/core/anki/ImportProgress;->getStage()Lcom/xunji/core/anki/ImportStage;

    move-result-object v4

    sget-object v5, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v4}, Lcom/xunji/core/anki/ImportStage;->ordinal()I

    move-result v4

    aget v4, v5, v4

    packed-switch v4, :pswitch_data_2e0

    new-instance v2, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v2}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v2

    .line 47
    :pswitch_20f
    const-string v4, "\u68c0\u67e5\u6a21\u677f\u4e0e\u517c\u5bb9\u6027"

    goto :goto_21d

    .line 46
    :pswitch_212
    const-string v4, "\u68c0\u67e5\u5a92\u4f53"

    goto :goto_21d

    .line 45
    :pswitch_215
    const-string v4, "\u68c0\u67e5\u5361\u7247\u6570\u636e"

    goto :goto_21d

    .line 44
    :pswitch_218
    const-string v4, "\u68c0\u67e5\u5305\u7ed3\u6784"

    goto :goto_21d

    .line 43
    :pswitch_21b
    const-string v4, "\u8bfb\u53d6\u6587\u4ef6"

    .line 42
    :goto_21d
    nop

    .line 49
    .local v4, "stage\\12":Ljava/lang/String;
    invoke-virtual {v1}, Lcom/xunji/core/anki/ImportProgress;->getCompleted()J

    move-result-wide v5

    invoke-virtual {v1}, Lcom/xunji/core/anki/ImportProgress;->getTotal()Ljava/lang/Long;

    move-result-object v7

    if-eqz v7, :cond_245

    check-cast v7, Ljava/lang/Number;

    invoke-virtual {v7}, Ljava/lang/Number;->longValue()J

    move-result-wide v7

    .line 118
    nop

    .local v7, "it\\13":J
    const/4 v9, 0x0

    .line 49
    .local v9, "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$2$1\\13\\49\\12":I
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, " / "

    invoke-virtual {v10, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v7, v8}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    .end local v7    # "it\\13":J
    .end local v9    # "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$2$1\\13\\49\\12":I
    if-nez v7, :cond_247

    :cond_245
    const-string v7, ""

    :cond_247
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " \u00b7 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    invoke-static {v5, v6, v11, v6, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 50
    nop

    .line 41
    .end local v1    # "progress\\12":Lcom/xunji/core/anki/ImportProgress;
    .end local v3    # "$i$a$-let-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$2\\12\\41\\0":I
    .end local v4    # "stage\\12":Ljava/lang/String;
    goto :goto_1e9

    .line 51
    :goto_268
    const v1, -0x1b935818

    const-string v3, "CC(remember):AnkiImportScreen.kt#9igjgp"

    invoke-static {v11, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\14":Z
    move-object/from16 v3, p3

    .local v3, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 163
    .local v4, "$i$f$cache\\14\\51":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\14":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 164
    .local v6, "$i$a$-let-ComposerKt$cache$1\\15\\163\\14":I
    if-nez v1, :cond_288

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_287

    goto :goto_288

    .line 168
    :cond_287
    goto :goto_295

    .line 165
    :cond_288
    :goto_288
    const/4 v7, 0x0

    .line 51
    .local v7, "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3\\16\\165\\0":I
    new-instance v8, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3$1;

    invoke-direct {v8, v0}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3$1;-><init>(Ljava/lang/Object;)V

    check-cast v8, Lkotlin/reflect/KFunction;

    .line 165
    .end local v7    # "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$3$1$3\\16\\165\\0":I
    nop

    .line 166
    .local v8, "value\\15":Ljava/lang/Object;
    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 167
    move-object v5, v8

    .line 163
    .end local v5    # "it\\14":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\15\\163\\14":I
    .end local v8    # "value\\15":Ljava/lang/Object;
    :goto_295
    nop

    .line 51
    .end local v1    # "invalid\\14":Z
    .end local v3    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\14\\51":I
    check-cast v5, Lkotlin/reflect/KFunction;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v1, v5

    check-cast v1, Lkotlin/jvm/functions/Function0;

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v3, v4, v6, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v6, 0x30

    .local v6, "$this$dp\\17":I
    const/4 v7, 0x0

    .line 169
    .local v7, "$i$f$getDp\\17\\51":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 51
    .end local v6    # "$this$dp\\17":I
    .end local v7    # "$i$f$getDp\\17\\51":I
    invoke-static {v3, v6, v4, v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const-string v3, "anki-cancel"

    invoke-static {v2, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->getLambda$600549193$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const v12, 0x30000030

    const/16 v13, 0x1fc

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2dc

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_2dc

    .line 36
    :cond_2d9
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 52
    :cond_2dc
    :goto_2dc
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    nop

    :pswitch_data_2e0
    .packed-switch 0x1
        :pswitch_21b
        :pswitch_218
        :pswitch_215
        :pswitch_212
        :pswitch_20f
    .end packed-switch
.end method

.method private static final AnkiImportScreen$lambda$0$0$3$0(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 15
    .param p0, "$error"    # Ljava/lang/String;
    .param p1, "$onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C54@2695L46:AnkiImportScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    if-eq v0, v1, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_41

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:54)"

    const v2, 0x20bd0ca2

    invoke-static {v2, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 55
    :cond_2a
    const/16 v8, 0x186

    const/4 v9, 0x0

    const-string v3, "\u5bfc\u5165\u672a\u5b8c\u6210"

    const-string v5, "\u91cd\u65b0\u9009\u62e9\u6587\u4ef6"

    move-object v4, p0

    move-object v6, p1

    move-object v7, p3

    .end local p0    # "$error":Ljava/lang/String;
    .end local p1    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$error":Ljava/lang/String;
    .local v6, "$onChoose":Lkotlin/jvm/functions/Function0;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_47

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_47

    .line 54
    .end local v4    # "$error":Ljava/lang/String;
    .end local v6    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p0    # "$error":Ljava/lang/String;
    .restart local p1    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .restart local p3    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_41
    move-object v4, p0

    move-object v6, p1

    move-object v7, p3

    .end local p0    # "$error":Ljava/lang/String;
    .end local p1    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$error":Ljava/lang/String;
    .restart local v6    # "$onChoose":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 56
    :cond_47
    :goto_47
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final AnkiImportScreen$lambda$0$0$4(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 13
    .param p0, "$report"    # Lcom/xunji/flashcards/anki/AnkiImportReport;
    .param p1, "$affected"    # Ljava/util/List;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p3, "$onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C58@2865L863,58@2834L894:AnkiImportScreen.kt#i35lj1"

    invoke-static {p5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p6, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p6, 0x1

    invoke-interface {p5, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:58)"

    const v4, 0x45f6ef66

    invoke-static {v4, p6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 59
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda16;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda16;-><init>(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;)V

    const v4, -0xe70b1ca

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p5, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p5, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    .line 58
    :cond_53
    invoke-interface {p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 69
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$4$0(Lcom/xunji/flashcards/anki/AnkiImportReport;Ljava/util/List;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 35
    .param p0, "$report"    # Lcom/xunji/flashcards/anki/AnkiImportReport;
    .param p1, "$affected"    # Ljava/util/List;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p3, "$onChoose"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v11, p5

    move/from16 v1, p6

    const-string v2, "$this$Paper"

    move-object/from16 v3, p4

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C59@2922L10,59@2887L57,60@2965L130,66@3591L119:AnkiImportScreen.kt#i35lj1"

    invoke-static {v11, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v2, v4, :cond_1a

    move v2, v5

    goto :goto_1b

    :cond_1a
    move v2, v6

    :goto_1b
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v11, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_274

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:59)"

    const v7, -0xe70b1ca

    invoke-static {v7, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 60
    :cond_32
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v11, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v22

    const/16 v25, 0x0

    const v26, 0x1fffe

    const-string v1, "\u9884\u68c0\u7ed3\u679c"

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    move v7, v5

    const/4 v5, 0x0

    move v9, v6

    move v8, v7

    const-wide/16 v6, 0x0

    move v10, v8

    const/4 v8, 0x0

    move v12, v9

    const/4 v9, 0x0

    move v13, v10

    const/4 v10, 0x0

    move v14, v12

    const-wide/16 v11, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const/4 v14, 0x0

    move/from16 v17, v15

    move/from16 v18, v16

    const-wide/16 v15, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v21, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v24, v21

    const/16 v21, 0x0

    move/from16 v27, v24

    const/16 v24, 0x6

    move/from16 v0, v23

    move-object/from16 v23, p5

    invoke-static/range {v1 .. v26}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 61
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getTotalCards()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getCompatibleCards()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getDuplicateCards()I

    move-result v3

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getSkippedCards()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u6e90\u5361 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v5, " \u5f20 \u00b7 \u53ef\u5bfc\u5165 "

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20 \u00b7 \u5df2\u5b58\u5728 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20 \u00b7 \u8df3\u8fc7 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const v26, 0x3fffe

    const/4 v2, 0x0

    const-wide/16 v3, 0x0

    const/4 v5, 0x0

    const-wide/16 v6, 0x0

    const/16 v22, 0x0

    const/16 v24, 0x0

    invoke-static/range {v1 .. v26}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 62
    move-object/from16 v11, v23

    move-object/from16 v1, p1

    check-cast v1, Ljava/util/Collection;

    invoke-interface {v1}, Ljava/util/Collection;->isEmpty()Z

    move-result v1

    const/4 v9, 0x2

    if-nez v1, :cond_19c

    const v1, -0x350b43fc    # -8019458.0f

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "61@3143L142"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object/from16 v1, p1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$map\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 170
    .local v2, "$i$f$map\\1\\62":I
    new-instance v3, Ljava/util/ArrayList;

    const/16 v4, 0xa

    invoke-static {v1, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v5

    invoke-direct {v3, v5}, Ljava/util/ArrayList;-><init>(I)V

    check-cast v3, Ljava/util/Collection;

    .local v3, "destination\\2":Ljava/util/Collection;
    move-object v5, v1

    .local v5, "$this$mapTo\\2":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 171
    .local v6, "$i$f$mapTo\\2\\170":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_108
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_11e

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 172
    .local v8, "item\\2":Ljava/lang/Object;
    move-object v10, v8

    check-cast v10, Lcom/xunji/flashcards/anki/ImportPreviewCard;

    .local v10, "it\\3":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    const/4 v12, 0x0

    .line 62
    .local v12, "$i$a$-map-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$1\\3\\172\\0":I
    invoke-virtual {v10}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getGuid()Ljava/lang/String;

    move-result-object v10

    .line 172
    .end local v10    # "it\\3":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    .end local v12    # "$i$a$-map-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$1\\3\\172\\0":I
    invoke-interface {v3, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_108

    .line 173
    .end local v8    # "item\\2":Ljava/lang/Object;
    :cond_11e
    nop

    .end local v3    # "destination\\2":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\2":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\2\\170":I
    check-cast v3, Ljava/util/List;

    .line 170
    nop

    .end local v1    # "$this$map\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$map\\1\\62":I
    check-cast v3, Ljava/lang/Iterable;

    .line 62
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    move-object/from16 v2, p1

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$map\\4":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 170
    .local v3, "$i$f$map\\4\\62":I
    new-instance v5, Ljava/util/ArrayList;

    invoke-static {v2, v4}, Lkotlin/collections/CollectionsKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    move-result v4

    invoke-direct {v5, v4}, Ljava/util/ArrayList;-><init>(I)V

    move-object v4, v5

    check-cast v4, Ljava/util/Collection;

    .local v4, "destination\\5":Ljava/util/Collection;
    move-object v5, v2

    .local v5, "$this$mapTo\\5":Ljava/lang/Iterable;
    const/4 v6, 0x0

    .line 171
    .local v6, "$i$f$mapTo\\5\\170":I
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v7

    :goto_143
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    move-result v8

    if-eqz v8, :cond_159

    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v8

    .line 172
    .local v8, "item\\5":Ljava/lang/Object;
    move-object v10, v8

    check-cast v10, Lcom/xunji/flashcards/anki/ImportPreviewCard;

    .local v10, "it\\6":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    const/4 v12, 0x0

    .line 62
    .local v12, "$i$a$-map-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$2\\6\\172\\0":I
    invoke-virtual {v10}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getDeckName()Ljava/lang/String;

    move-result-object v10

    .line 172
    .end local v10    # "it\\6":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    .end local v12    # "$i$a$-map-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$2\\6\\172\\0":I
    invoke-interface {v4, v10}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_143

    .line 173
    .end local v8    # "item\\5":Ljava/lang/Object;
    :cond_159
    nop

    .end local v4    # "destination\\5":Ljava/util/Collection;
    .end local v5    # "$this$mapTo\\5":Ljava/lang/Iterable;
    .end local v6    # "$i$f$mapTo\\5\\170":I
    check-cast v4, Ljava/util/List;

    .line 170
    nop

    .end local v2    # "$this$map\\4":Ljava/lang/Iterable;
    .end local v3    # "$i$f$map\\4\\62":I
    check-cast v4, Ljava/lang/Iterable;

    .line 62
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    invoke-interface/range {p1 .. p1}, Ljava/util/List;->size()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "\u53d7\u5f71\u54cd\uff1a"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " \u6761\u7b14\u8bb0\u3001"

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u4e2a\u724c\u7ec4\u3001"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20\u5361\u7247\u3002\u4e0b\u65b9\u5217\u51fa\u539f\u56e0\u3002"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v0, v11, v0, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_1a2

    :cond_19c
    const v1, -0x6c8ce3b4

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_1a2
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 63
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getCompatibleCards()I

    move-result v1

    const/4 v2, 0x6

    if-lez v1, :cond_221

    const v1, -0x6c5a4041

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "63@3364L38,64@3480L18,64@3427L94"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 64
    const-string v1, "\u786e\u8ba4\u540e\u4ec5\u6dfb\u52a0\u517c\u5bb9\u7684\u65b0\u5361\uff1b\u5df2\u6709\u7b14\u8bb0\u5b57\u6bb5\u548c\u590d\u4e60\u8fdb\u5ea6\u4fdd\u6301\u539f\u6837\u3002"

    invoke-static {v1, v0, v11, v2, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 65
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getCompatibleCards()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "\u786e\u8ba4\u5bfc\u5165 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u517c\u5bb9\u5361"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const v0, -0x350b1a58    # -8024788.0f

    const-string v2, "CC(remember):AnkiImportScreen.kt#9igjgp"

    invoke-static {v11, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v14, p2

    invoke-interface {v11, v14}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\7":Z
    move-object/from16 v2, p5

    .local v2, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 174
    .local v3, "$i$f$cache\\7\\65":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\7":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 175
    .local v5, "$i$a$-let-ComposerKt$cache$1\\8\\174\\7":I
    if-nez v0, :cond_1fb

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_1fa

    goto :goto_1fb

    .line 179
    :cond_1fa
    goto :goto_208

    .line 176
    :cond_1fb
    :goto_1fb
    const/4 v6, 0x0

    .line 65
    .local v6, "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3\\9\\176\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3$1;

    invoke-direct {v7, v14}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3$1;-><init>(Ljava/lang/Object;)V

    check-cast v7, Lkotlin/reflect/KFunction;

    .line 176
    .end local v6    # "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$5$1$3\\9\\176\\0":I
    nop

    .line 177
    .local v7, "value\\8":Ljava/lang/Object;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 178
    move-object v4, v7

    .line 174
    .end local v4    # "it\\7":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\8\\174\\7":I
    .end local v7    # "value\\8":Ljava/lang/Object;
    :goto_208
    nop

    .line 65
    .end local v0    # "invalid\\7":Z
    .end local v2    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\7\\65":I
    check-cast v4, Lkotlin/reflect/KFunction;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v2, v4

    check-cast v2, Lkotlin/jvm/functions/Function0;

    const/16 v7, 0x6000

    const/16 v8, 0xc

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v5, "anki-confirm"

    move-object v6, v11

    invoke-static/range {v1 .. v8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 63
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_236

    .line 66
    :cond_221
    move-object/from16 v14, p2

    const v1, -0x350b11b5    # -8025893.5f

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "65@3549L21"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const-string v1, "\u6ca1\u6709\u53ef\u65b0\u589e\u7684\u517c\u5bb9\u5361\u7247\u3002"

    invoke-static {v1, v0, v11, v2, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 67
    :goto_236
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v10, 0x1

    invoke-static {v0, v1, v10, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x30

    .local v3, "$this$dp\\10":I
    const/4 v4, 0x0

    .line 180
    .local v4, "$i$f$getDp\\10\\67":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 67
    .end local v3    # "$this$dp\\10":I
    .end local v4    # "$i$f$getDp\\10\\67":I
    invoke-static {v0, v3, v1, v9, v2}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "anki-choose-again"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->getLambda$166585512$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const v12, 0x30000030

    const/16 v13, 0x1fc

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_279

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_279

    .line 59
    :cond_274
    move-object/from16 v14, p2

    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 68
    :cond_279
    :goto_279
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$5(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10
    .param p0, "$report"    # Lcom/xunji/flashcards/anki/AnkiImportReport;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C71@3858L295,71@3827L326:AnkiImportScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:71)"

    const v4, -0x3850a455

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 72
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda15;

    invoke-direct {v1, p0}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda15;-><init>(Lcom/xunji/flashcards/anki/AnkiImportReport;)V

    const v4, -0x37448985

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p2, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    .line 71
    :cond_53
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 78
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$5$0(Lcom/xunji/flashcards/anki/AnkiImportReport;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$report"    # Lcom/xunji/flashcards/anki/AnkiImportReport;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C72@3922L10,72@3884L60,*74@4079L26:AnkiImportScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_e5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:72)"

    const v6, -0x37448985

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 73
    :cond_31
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v0, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u9700\u8981\u6ce8\u610f\u7684\u95ee\u9898"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move v7, v5

    const-wide/16 v5, 0x0

    move v8, v7

    const/4 v7, 0x0

    move v9, v8

    const/4 v8, 0x0

    move v10, v9

    const/4 v9, 0x0

    move v12, v10

    const-wide/16 v10, 0x0

    move v13, v12

    const/4 v12, 0x0

    move v14, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const-wide/16 v14, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v19, v18

    const/16 v18, 0x0

    move/from16 v20, v19

    const/16 v19, 0x0

    move/from16 v22, v20

    const/16 v20, 0x0

    const/16 v23, 0x6

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 74
    move-object/from16 v0, v22

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/AnkiImportReport;->getReasons()Ljava/util/Map;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$sortedByDescending\\1":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 181
    .local v2, "$i$f$sortedByDescending\\1\\74":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$lambda$0$0$5$0$$inlined$sortedByDescending$1;

    invoke-direct {v3}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$AnkiImportScreen$lambda$0$0$5$0$$inlined$sortedByDescending$1;-><init>()V

    check-cast v3, Ljava/util/Comparator;

    invoke-static {v1, v3}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    move-result-object v1

    .end local v1    # "$this$sortedByDescending\\1":Ljava/lang/Iterable;
    .end local v2    # "$i$f$sortedByDescending\\1\\74":I
    check-cast v1, Ljava/lang/Iterable;

    .line 74
    nop

    .local v1, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 182
    .local v2, "$i$f$forEach\\2\\74":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_97
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_da

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\2":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ljava/util/Map$Entry;

    const/4 v6, 0x0

    .local v6, "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$6$1$2\\3\\182\\0":I
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v7

    check-cast v7, Ljava/lang/String;

    .local v7, "code\\3":Ljava/lang/String;
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    check-cast v5, Ljava/lang/Number;

    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    move-result v5

    .line 75
    .local v5, "count\\3":I
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " \u00b7 "

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v8

    const-string v9, " \u5f20"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v8, v10, v0, v10, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 76
    nop

    .line 182
    .end local v5    # "count\\3":I
    .end local v6    # "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$6$1$2\\3\\182\\0":I
    .end local v7    # "code\\3":Ljava/lang/String;
    nop

    .end local v4    # "element\\2":Ljava/lang/Object;
    goto :goto_97

    .line 183
    :cond_da
    nop

    .end local v1    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\2\\74":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_e8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_e8

    .line 72
    :cond_e5
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 77
    :cond_e8
    :goto_e8
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final AnkiImportScreen$lambda$0$0$6(Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 13
    .param p0, "$pageCards"    # Ljava/util/List;
    .param p1, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "index"    # I
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$items"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "CN(index)80@4320L352,80@4289L383:AnkiImportScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v0, p4

    .local v0, "$dirty":I
    and-int/lit8 v1, p4, 0x30

    if-nez v1, :cond_1b

    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v1

    if-eqz v1, :cond_18

    const/16 v1, 0x20

    goto :goto_1a

    :cond_18
    const/16 v1, 0x10

    :goto_1a
    or-int/2addr v0, v1

    :cond_1b
    and-int/lit16 v1, v0, 0x91

    const/16 v2, 0x90

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq v1, v2, :cond_25

    move v1, v4

    goto :goto_26

    :cond_25
    move v1, v3

    :goto_26
    and-int/lit8 v2, v0, 0x1

    invoke-interface {p3, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_6a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_3d

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:79)"

    const v5, -0x3a67a37e

    invoke-static {v5, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 80
    :cond_3d
    invoke-interface {p0, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/xunji/flashcards/anki/ImportPreviewCard;

    .line 81
    .local v1, "card":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v2, v5, v4, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    new-instance v5, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v5, v1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda14;-><init>(Lcom/xunji/flashcards/anki/ImportPreviewCard;)V

    const v6, -0x258570ae

    const/16 v7, 0x36

    invoke-static {v6, v4, v5, p3, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function3;

    invoke-static {v2, v4, p3, v7, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_6d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "card":Lcom/xunji/flashcards/anki/ImportPreviewCard;
    goto :goto_6d

    .line 79
    :cond_6a
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 86
    :cond_6d
    :goto_6d
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final AnkiImportScreen$lambda$0$0$6$0(Lcom/xunji/flashcards/anki/ImportPreviewCard;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 31
    .param p0, "$card"    # Lcom/xunji/flashcards/anki/ImportPreviewCard;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C81@4407L10,81@4346L84,82@4455L83,*83@4594L54:AnkiImportScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v2, v4, :cond_1a

    move v2, v5

    goto :goto_1b

    :cond_1a
    move v2, v6

    :goto_1b
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_11a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:81)"

    const v7, -0x258570ae

    invoke-static {v7, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 82
    :cond_32
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getDeckName()Ljava/lang/String;

    move-result-object v2

    check-cast v2, Ljava/lang/CharSequence;

    invoke-static {v2}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v4

    if-eqz v4, :cond_42

    .line 118
    const/4 v2, 0x0

    .line 82
    .local v2, "$i$a$-ifBlank-AnkiImportScreenKt$AnkiImportScreen$1$1$7$1$1\\1\\82\\0":I
    nop

    .end local v2    # "$i$a$-ifBlank-AnkiImportScreenKt$AnkiImportScreen$1$1$7$1$1\\1\\82\\0":I
    const-string v2, "\u672a\u77e5\u724c\u7ec4"

    :cond_42
    check-cast v2, Ljava/lang/String;

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v0, v7}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move v7, v5

    move v8, v6

    const-wide/16 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v10, v8

    const/4 v8, 0x0

    move v11, v9

    const/4 v9, 0x0

    move v13, v10

    move v12, v11

    const-wide/16 v10, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    move/from16 v17, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 83
    move-object/from16 v0, v22

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getSourceCardId()J

    move-result-wide v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getGuid()Ljava/lang/String;

    move-result-object v3

    const/16 v4, 0x50

    invoke-static {v3, v4}, Lkotlin/text/StringsKt;->take(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v3

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getOrdinal()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u6e90\u5361 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u00b7 \u7b14\u8bb0 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u00b7 \u6a21\u677f\u5e8f\u53f7 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    const/4 v13, 0x0

    invoke-static {v1, v13, v0, v13, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 84
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportPreviewCard;->getIssues()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 184
    .local v2, "$i$f$forEach\\2\\84":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_da
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_10f

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\2":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Lcom/xunji/core/anki/ImportIssue;

    .local v5, "issue\\3":Lcom/xunji/core/anki/ImportIssue;
    const/4 v6, 0x0

    .line 84
    .local v6, "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$7$1$2\\3\\184\\0":I
    invoke-virtual {v5}, Lcom/xunji/core/anki/ImportIssue;->getCode()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v5}, Lcom/xunji/core/anki/ImportIssue;->getDetail()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    const-string v9, ": "

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x30

    const/4 v12, 0x1

    invoke-static {v7, v12, v0, v8, v13}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 184
    .end local v5    # "issue\\3":Lcom/xunji/core/anki/ImportIssue;
    .end local v6    # "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$7$1$2\\3\\184\\0":I
    nop

    .end local v4    # "element\\2":Ljava/lang/Object;
    goto :goto_da

    .line 185
    :cond_10f
    nop

    .end local v1    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\2\\84":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_11d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_11d

    .line 81
    :cond_11a
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 85
    :cond_11d
    :goto_11d
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final AnkiImportScreen$lambda$0$0$7(Lcom/xunji/flashcards/ui/AnkiImportUiState;ILcom/xunji/flashcards/ui/AnkiImportViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 82
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;
    .param p1, "$pages"    # I
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p3, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p4

    move/from16 v4, p5

    const-string v5, "$this$item"

    move-object/from16 v6, p3

    invoke-static {v6, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "C87@4749L601:AnkiImportScreen.kt#i35lj1"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v5, v4, 0x11

    const/16 v7, 0x10

    const/4 v9, 0x1

    if-eq v5, v7, :cond_1f

    move v5, v9

    goto :goto_20

    :cond_1f
    const/4 v5, 0x0

    :goto_20
    and-int/lit8 v7, v4, 0x1

    invoke-interface {v3, v5, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_3e4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_37

    const/4 v5, -0x1

    const-string v7, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:87)"

    const v10, 0x2074f5b0

    invoke-static {v10, v4, v5, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 88
    :cond_37
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v10, 0x0

    invoke-static {v5, v7, v9, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .local v5, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v7

    check-cast v7, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v7, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    .local v10, "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v11, 0x1b6

    .local v11, "$changed\\1":I
    move-object/from16 v12, p4

    .local v12, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 186
    .local v13, "$i$f$Row\\1\\88":I
    const v14, 0x3255a44b

    const-string v15, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v12, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 187
    shr-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v17, v11, 0x3

    and-int/lit8 v17, v17, 0x70

    move/from16 v18, v9

    or-int v9, v16, v17

    invoke-static {v7, v10, v12, v9}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 191
    .local v9, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v11, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 188
    nop

    .local v16, "$changed\\2":I
    move-object/from16 v17, v5

    .local v17, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/16 v19, 0x0

    .line 192
    .local v19, "$i$f$Layout\\2\\188":I
    const v14, -0x451e1427

    const-string v8, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v12, v14, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 193
    const/4 v14, 0x0

    invoke-static {v12, v14}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v23

    invoke-static/range {v23 .. v24}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 194
    .local v14, "compositeKeyHash\\2":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 195
    .local v3, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v4, v17

    .end local v5    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v4, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v17, "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-static {v12, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 197
    .local v5, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    move-object/from16 v24, v4

    .end local v4    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\2":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v16, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 196
    move-object/from16 v25, v23

    .local v4, "$changed\\3":I
    .local v25, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 198
    .local v23, "$i$f$ReusableComposeNode\\3\\196":I
    move/from16 v26, v4

    .end local v4    # "$changed\\3":I
    .local v26, "$changed\\3":I
    const v4, -0x20f7d59c

    const-string v6, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v12, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 199
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_b7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 200
    :cond_b7
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 201
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_c6

    .line 202
    move-object/from16 v4, v25

    .end local v25    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_cb

    .line 204
    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_c6
    move-object/from16 v4, v25

    .end local v25    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 206
    :goto_cb
    move-object/from16 v25, v4

    .end local v4    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 207
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\206\\2":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v30, v7

    .end local v7    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v30, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v4, v9, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 208
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v4, v3, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 209
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 210
    .local v29, "$i$f$set-impl\\5\\209":I
    move-object/from16 v31, v4

    .local v31, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 211
    .local v32, "$i$a$-with-Updater$set$1\\6\\210\\5":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_10f

    move-object/from16 v33, v3

    .end local v3    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .local v33, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v34, v9

    .end local v9    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v34, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-static {v3, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10c

    goto :goto_113

    :cond_10c
    move-object/from16 v9, v31

    goto :goto_123

    .end local v33    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v34    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v9    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_10f
    move-object/from16 v33, v3

    move-object/from16 v34, v9

    .line 212
    .end local v3    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v9    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v33    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v34    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_113
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v9, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v4, v3, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 215
    :goto_123
    nop

    .line 210
    .end local v9    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\6\\210\\5":I
    nop

    .line 215
    nop

    .line 216
    .end local v7    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\5\\209":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 217
    nop

    .line 206
    .end local v4    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\206\\2":I
    nop

    .line 218
    shr-int/lit8 v3, v26, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\7":I
    move-object v4, v12

    .local v4, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 189
    .local v7, "$i$a$-Layout-RowKt$Row$1\\7\\218\\1":I
    const v9, 0x56ccd6f5

    move/from16 v28, v3

    .end local v3    # "$changed\\7":I
    .local v28, "$changed\\7":I
    const-string v3, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v29, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v31, v11, 0x6

    and-int/lit8 v31, v31, 0x70

    or-int/lit8 v31, v31, 0x6

    .local v31, "$changed\\8":I
    check-cast v29, Landroidx/compose/foundation/layout/RowScope;

    .local v29, "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v57, v4

    .local v57, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 89
    .local v32, "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1\\8\\189\\0":I
    const v9, 0xe49890d

    move-object/from16 v61, v4

    .end local v4    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v61, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v4, "C88@4902L34,89@4961L367:AnkiImportScreen.kt#i35lj1"

    move-object/from16 v62, v5

    move-object/from16 v5, v57

    .end local v57    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v62, "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v9, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v4

    add-int/lit8 v4, v4, 0x1

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    const-string v9, " / "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v35

    const/16 v59, 0x0

    const v60, 0x3fffe

    const/16 v36, 0x0

    const-wide/16 v37, 0x0

    const/16 v39, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const-wide/16 v45, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const-wide/16 v49, 0x0

    const/16 v51, 0x0

    const/16 v52, 0x0

    const/16 v53, 0x0

    const/16 v54, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v58, 0x0

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v35 .. v60}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 90
    .end local v57    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    move-object v4, v5

    const/16 v21, 0x0

    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    move/from16 v9, v21

    .local v9, "$changed\\9":I
    const/16 v35, 0x0

    .line 219
    .local v35, "$i$f$Row\\9\\90":I
    const v5, 0x3255a44b

    .end local v5    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v57    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v5, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 220
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 221
    .local v5, "modifier\\9":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v15}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v15

    .line 222
    .local v15, "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v20, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v36, v5

    .end local v5    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\9":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 225
    .local v5, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v20, v9, 0x3

    and-int/lit8 v20, v20, 0xe

    shr-int/lit8 v37, v9, 0x3

    and-int/lit8 v37, v37, 0x70

    move/from16 v38, v7

    .end local v7    # "$i$a$-Layout-RowKt$Row$1\\7\\218\\1":I
    .local v38, "$i$a$-Layout-RowKt$Row$1\\7\\218\\1":I
    or-int v7, v20, v37

    invoke-static {v15, v5, v4, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .line 229
    .local v7, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v20, v9, 0x3

    and-int/lit8 v20, v20, 0x70

    .line 226
    move-object/from16 v37, v36

    .local v20, "$changed\\10":I
    .local v37, "modifier\\10":Landroidx/compose/ui/Modifier;
    const/16 v39, 0x0

    .line 230
    .local v39, "$i$f$Layout\\10\\226":I
    move-object/from16 v40, v5

    const v5, -0x451e1427

    .end local v5    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .local v40, "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v4, v5, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 231
    const/4 v5, 0x0

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v21

    invoke-static/range {v21 .. v22}, Ljava/lang/Long;->hashCode(J)I

    move-result v8

    .line 232
    .local v8, "compositeKeyHash\\10":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 233
    .local v5, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v22, v8

    move-object/from16 v8, v37

    move/from16 v37, v9

    .end local v9    # "$changed\\9":I
    .local v8, "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v22, "compositeKeyHash\\10":I
    .local v37, "$changed\\9":I
    invoke-static {v4, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 235
    .local v9, "materialized\\10":Landroidx/compose/ui/Modifier;
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v41

    move-object/from16 v42, v8

    .end local v8    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v42, "modifier\\10":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v8, v20, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 234
    nop

    .local v8, "$changed\\11":I
    move-object/from16 v43, v41

    .local v43, "factory\\11":Lkotlin/jvm/functions/Function0;
    const/16 v41, 0x0

    .line 236
    .local v41, "$i$f$ReusableComposeNode\\11\\234":I
    move/from16 v44, v8

    const v8, -0x20f7d59c

    .end local v8    # "$changed\\11":I
    .local v44, "$changed\\11":I
    invoke-static {v4, v8, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 237
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_222

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 238
    :cond_222
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 239
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_231

    .line 240
    move-object/from16 v6, v43

    .end local v43    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_236

    .line 242
    .end local v6    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v43    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_231
    move-object/from16 v6, v43

    .end local v43    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 244
    :goto_236
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .local v8, "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 245
    .local v27, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\244\\10":I
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v45, v4

    .end local v4    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 246
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 247
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\13":Lkotlin/jvm/functions/Function2;
    const/16 v43, 0x0

    .line 248
    .local v43, "$i$f$set-impl\\13\\247":I
    move-object/from16 v46, v8

    .local v46, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 249
    .local v47, "$i$a$-with-Updater$set$1\\14\\248\\13":I
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v48

    if-nez v48, :cond_278

    move-object/from16 v48, v5

    .end local v5    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v49, v6

    .end local v6    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v49, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_275

    goto :goto_27c

    :cond_275
    move-object/from16 v6, v46

    goto :goto_28c

    .end local v48    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v49    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_278
    move-object/from16 v48, v5

    move-object/from16 v49, v6

    .line 250
    .end local v5    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v48    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v49    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :goto_27c
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v46

    .end local v46    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v8, v5, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 253
    :goto_28c
    nop

    .line 248
    .end local v6    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$a$-with-Updater$set$1\\14\\248\\13":I
    nop

    .line 253
    nop

    .line 254
    .end local v4    # "block\\13":Lkotlin/jvm/functions/Function2;
    .end local v43    # "$i$f$set-impl\\13\\247":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v8, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 255
    nop

    .line 244
    .end local v8    # "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\244\\10":I
    nop

    .line 256
    shr-int/lit8 v4, v44, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\15":I
    move-object/from16 v5, v45

    .local v5, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 227
    .local v6, "$i$a$-Layout-RowKt$Row$1\\15\\256\\9":I
    const v8, 0x56ccd6f5

    invoke-static {v5, v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v8, v37, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\16":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240_u240\\16":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v73, v5

    .local v73, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 91
    .local v27, "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1\\16\\227\\8":I
    move-object/from16 v43, v3

    .end local v3    # "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240_u240\\16":Landroidx/compose/foundation/layout/RowScope;
    .local v43, "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240_u240\\16":Landroidx/compose/foundation/layout/RowScope;
    const v3, -0x2a588078

    move/from16 v46, v4

    .end local v4    # "$changed\\15":I
    .local v46, "$changed\\15":I
    const-string v4, "C90@5006L34,90@4995L135,91@5170L34,91@5159L143:AnkiImportScreen.kt#i35lj1"

    move-object/from16 v47, v5

    .end local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v3

    if-lez v3, :cond_2cc

    move/from16 v65, v18

    goto :goto_2ce

    :cond_2cc
    const/16 v65, 0x0

    :goto_2ce
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const-string v4, "anki-prev-page"

    invoke-static {v3, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    const v3, -0x2aa803d6

    const-string v4, "CC(remember):AnkiImportScreen.kt#9igjgp"

    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v50

    or-int v3, v3, v50

    .local v3, "invalid\\17":Z
    move-object/from16 v50, v5

    .local v50, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 257
    .local v51, "$i$f$cache\\17\\91":I
    move/from16 v52, v3

    .end local v3    # "invalid\\17":Z
    .local v52, "invalid\\17":Z
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\17":Ljava/lang/Object;
    const/16 v53, 0x0

    .line 258
    .local v53, "$i$a$-let-ComposerKt$cache$1\\18\\257\\17":I
    if-nez v52, :cond_306

    sget-object v54, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v73, v5

    .end local v5    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v54 .. v54}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_303

    goto :goto_308

    .line 262
    :cond_303
    move-object/from16 v5, v50

    goto :goto_317

    .line 258
    .end local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :cond_306
    move-object/from16 v73, v5

    .line 259
    .end local v5    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    :goto_308
    const/4 v5, 0x0

    .line 91
    .local v5, "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1$1\\19\\259\\16":I
    move-object/from16 v54, v3

    .end local v3    # "it\\17":Ljava/lang/Object;
    .local v54, "it\\17":Ljava/lang/Object;
    new-instance v3, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v3, v2, v0}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda10;-><init>(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)V

    .line 259
    .end local v5    # "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1$1\\19\\259\\16":I
    nop

    .line 260
    .local v3, "value\\18":Ljava/lang/Object;
    move-object/from16 v5, v50

    .end local v50    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .local v5, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 261
    nop

    .line 257
    .end local v3    # "value\\18":Ljava/lang/Object;
    .end local v53    # "$i$a$-let-ComposerKt$cache$1\\18\\257\\17":I
    .end local v54    # "it\\17":Ljava/lang/Object;
    :goto_317
    nop

    .line 91
    .end local v5    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$f$cache\\17\\91":I
    .end local v52    # "invalid\\17":Z
    move-object/from16 v63, v3

    check-cast v63, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->getLambda$1775359435$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v72

    const v74, 0x30000030

    const/16 v75, 0x1f8

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    invoke-static/range {v63 .. v75}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 92
    move-object/from16 v5, v73

    .end local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v3

    add-int/lit8 v3, v3, 0x1

    if-ge v3, v1, :cond_346

    move/from16 v65, v18

    goto :goto_348

    :cond_346
    const/16 v65, 0x0

    :goto_348
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const-string v1, "anki-next-page"

    invoke-static {v3, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v64

    const v1, -0x2aa7ef56

    invoke-static {v5, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .local v1, "invalid\\20":Z
    move-object v3, v5

    .local v3, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 263
    .local v4, "$i$f$cache\\20\\92":I
    move/from16 v18, v1

    .end local v1    # "invalid\\20":Z
    .local v18, "invalid\\20":Z
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\20":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 264
    .local v21, "$i$a$-let-ComposerKt$cache$1\\21\\263\\20":I
    if-nez v18, :cond_379

    sget-object v50, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v51, v4

    .end local v4    # "$i$f$cache\\20\\92":I
    .local v51, "$i$f$cache\\20\\92":I
    invoke-virtual/range {v50 .. v50}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v1, v4, :cond_378

    goto :goto_37b

    .line 268
    :cond_378
    goto :goto_388

    .line 264
    .end local v51    # "$i$f$cache\\20\\92":I
    .restart local v4    # "$i$f$cache\\20\\92":I
    :cond_379
    move/from16 v51, v4

    .line 265
    .end local v4    # "$i$f$cache\\20\\92":I
    .restart local v51    # "$i$f$cache\\20\\92":I
    :goto_37b
    const/4 v4, 0x0

    .line 92
    .local v4, "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1$2\\22\\265\\16":I
    move-object/from16 v50, v1

    .end local v1    # "it\\20":Ljava/lang/Object;
    .local v50, "it\\20":Ljava/lang/Object;
    new-instance v1, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v1, v2, v0}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda11;-><init>(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)V

    .line 265
    .end local v4    # "$i$a$-cache-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1$2\\22\\265\\16":I
    nop

    .line 266
    .local v1, "value\\21":Ljava/lang/Object;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 267
    nop

    .line 263
    .end local v1    # "value\\21":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\21\\263\\20":I
    .end local v50    # "it\\20":Ljava/lang/Object;
    :goto_388
    nop

    .line 92
    .end local v3    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v18    # "invalid\\20":Z
    .end local v51    # "$i$f$cache\\20\\92":I
    move-object/from16 v63, v1

    check-cast v63, Lkotlin/jvm/functions/Function0;

    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$AnkiImportScreenKt;->getLambda$50309940$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v72

    const v74, 0x30000030

    const/16 v75, 0x1f8

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    move-object/from16 v73, v5

    .end local v5    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v63 .. v75}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 91
    invoke-static/range {v73 .. v73}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 93
    nop

    .line 227
    .end local v8    # "$changed\\16":I
    .end local v27    # "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1$1\\16\\227\\8":I
    .end local v43    # "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240_u240\\16":Landroidx/compose/foundation/layout/RowScope;
    .end local v73    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 256
    .end local v6    # "$i$a$-Layout-RowKt$Row$1\\15\\256\\9":I
    .end local v46    # "$changed\\15":I
    .end local v47    # "$composer\\15":Landroidx/compose/runtime/Composer;
    nop

    .line 269
    invoke-interface/range {v45 .. v45}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 236
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 270
    nop

    .line 230
    .end local v41    # "$i$f$ReusableComposeNode\\11\\234":I
    .end local v44    # "$changed\\11":I
    .end local v49    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 271
    nop

    .line 219
    .end local v9    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .end local v20    # "$changed\\10":I
    .end local v22    # "compositeKeyHash\\10":I
    .end local v39    # "$i$f$Layout\\10\\226":I
    .end local v42    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v48    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 272
    nop

    .line 89
    .end local v7    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v15    # "horizontalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v35    # "$i$f$Row\\9\\90":I
    .end local v36    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .end local v37    # "$changed\\9":I
    .end local v40    # "verticalAlignment\\9":Landroidx/compose/ui/Alignment$Vertical;
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 94
    nop

    .line 189
    .end local v29    # "$this$AnkiImportScreen_u24lambda_u240_u240_u247_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .end local v31    # "$changed\\8":I
    .end local v32    # "$i$a$-Row-AnkiImportScreenKt$AnkiImportScreen$1$1$8$1\\8\\189\\0":I
    .end local v57    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v61 .. v61}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 218
    .end local v28    # "$changed\\7":I
    .end local v38    # "$i$a$-Layout-RowKt$Row$1\\7\\218\\1":I
    .end local v61    # "$composer\\7":Landroidx/compose/runtime/Composer;
    nop

    .line 273
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 198
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 274
    nop

    .line 192
    .end local v23    # "$i$f$ReusableComposeNode\\3\\196":I
    .end local v25    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v26    # "$changed\\3":I
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    nop

    .line 186
    .end local v14    # "compositeKeyHash\\2":I
    .end local v16    # "$changed\\2":I
    .end local v19    # "$i$f$Layout\\2\\188":I
    .end local v24    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v33    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v62    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 276
    nop

    .end local v10    # "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    .end local v11    # "$changed\\1":I
    .end local v12    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$Row\\1\\88":I
    .end local v17    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v30    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v34    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_3e7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_3e7

    .line 87
    :cond_3e4
    invoke-interface/range {p4 .. p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 95
    :cond_3e7
    :goto_3e7
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final AnkiImportScreen$lambda$0$0$7$0$0$0$0(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;

    .line 91
    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    invoke-virtual {p0, v0}, Lcom/xunji/flashcards/ui/AnkiImportViewModel;->page(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$7$0$0$1$0(Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lcom/xunji/flashcards/ui/AnkiImportUiState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/AnkiImportViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/AnkiImportUiState;

    .line 92
    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/AnkiImportUiState;->getPage()I

    move-result v0

    add-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Lcom/xunji/flashcards/ui/AnkiImportViewModel;->page(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$8$0(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 11
    .param p0, "$result"    # Lcom/xunji/flashcards/anki/ImportResult;
    .param p1, "$onDone"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C98@5481L461,98@5450L492:AnkiImportScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:98)"

    const v4, 0x1f76ccd0

    invoke-static {v4, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 99
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0, p1}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt$$ExternalSyntheticLambda13;-><init>(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;)V

    const v4, 0x1bb52800

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p3, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    .line 98
    :cond_53
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 106
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$0$0$8$0$0(Lcom/xunji/flashcards/anki/ImportResult;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 31
    .param p0, "$result"    # Lcom/xunji/flashcards/anki/ImportResult;
    .param p1, "$onDone"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v5, p3

    move/from16 v0, p4

    const-string v1, "$this$Paper"

    move-object/from16 v2, p2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C99@5534L10,99@5499L57,100@5573L86,101@5676L69,103@5880L48:AnkiImportScreen.kt#i35lj1"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    const/4 v4, 0x0

    if-eq v1, v3, :cond_19

    const/4 v1, 0x1

    goto :goto_1a

    :cond_19
    move v1, v4

    :goto_1a
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v5, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_170

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.AnkiImportScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiImportScreen.kt:99)"

    const v6, 0x1bb52800

    invoke-static {v6, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 100
    :cond_31
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u5bfc\u5165\u5b8c\u6210"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    move v6, v4

    const/4 v4, 0x0

    move v7, v6

    const-wide/16 v5, 0x0

    move v8, v7

    const/4 v7, 0x0

    move v9, v8

    const/4 v8, 0x0

    move v10, v9

    const/4 v9, 0x0

    move v12, v10

    const-wide/16 v10, 0x0

    move v13, v12

    const/4 v12, 0x0

    move v14, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const-wide/16 v14, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v19, v18

    const/16 v18, 0x0

    move/from16 v20, v19

    const/16 v19, 0x0

    move/from16 v22, v20

    const/16 v20, 0x0

    const/16 v23, 0x6

    move-object/from16 v22, p3

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 101
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getAddedDecks()I

    move-result v0

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getAddedNotes()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getAddedCards()I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u65b0\u589e "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, " \u4e2a\u724c\u7ec4\u3001"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u6761\u7b14\u8bb0\u3001"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5361\u7247\u3002"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const v25, 0x3fffe

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 102
    move-object/from16 v5, v22

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getDuplicateCards()I

    move-result v0

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getSkippedCards()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u5df2\u5b58\u5728 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v2, " \u5f20\uff1b\u8df3\u8fc7 "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u3002"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v6, 0x0

    invoke-static {v0, v6, v5, v6, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 103
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getReasons()Ljava/util/Map;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/Map;->isEmpty()Z

    move-result v0

    if-nez v0, :cond_14e

    const v0, 0x5e5ed94d

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*102@5837L24"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/ImportResult;->getReasons()Ljava/util/Map;

    move-result-object v0

    .local v0, "$this$forEach\\1":Ljava/util/Map;
    const/4 v2, 0x0

    .line 277
    .local v2, "$i$f$forEach\\1\\103":I
    invoke-interface {v0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_113
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_14c

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/util/Map$Entry;

    .local v4, "element\\1":Ljava/util/Map$Entry;
    const/4 v7, 0x0

    .local v7, "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$9$1$1$1\\2\\277\\0":I
    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v8

    check-cast v8, Ljava/lang/String;

    .local v8, "code\\2":Ljava/lang/String;
    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/Number;

    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    move-result v9

    .line 103
    .local v9, "count\\2":I
    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    const-string v11, " \u00b7 "

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v10

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10, v6, v5, v6, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 277
    .end local v7    # "$i$a$-forEach-AnkiImportScreenKt$AnkiImportScreen$1$1$9$1$1$1\\2\\277\\0":I
    .end local v8    # "code\\2":Ljava/lang/String;
    .end local v9    # "count\\2":I
    nop

    .end local v4    # "element\\1":Ljava/util/Map$Entry;
    goto :goto_113

    .line 278
    :cond_14c
    nop

    .line 103
    .end local v0    # "$this$forEach\\1":Ljava/util/Map;
    .end local v2    # "$i$f$forEach\\1\\103":I
    goto :goto_154

    :cond_14e
    const v0, 0x5e06dd42

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_154
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 104
    const/16 v6, 0x6006

    const/16 v7, 0xc

    const-string v0, "\u8fd4\u56de\u724c\u7ec4"

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v4, "anki-done"

    move-object/from16 v1, p1

    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_173

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_173

    .line 99
    :cond_170
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 105
    :cond_173
    :goto_173
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiImportScreen$lambda$1(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p5

    invoke-static/range {v1 .. v6}, Lcom/xunji/flashcards/ui/screens/AnkiImportScreenKt;->AnkiImportScreen(Lcom/xunji/flashcards/ui/AnkiImportUiState;Lcom/xunji/flashcards/ui/AnkiImportViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

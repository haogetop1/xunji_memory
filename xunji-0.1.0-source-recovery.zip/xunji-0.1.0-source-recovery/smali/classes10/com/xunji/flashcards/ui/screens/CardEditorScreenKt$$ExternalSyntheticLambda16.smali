.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/EditorUiState;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$0:Lcom/xunji/flashcards/ui/EditorUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$1:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$0:Lcom/xunji/flashcards/ui/EditorUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$1:Lkotlin/jvm/functions/Function0;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;->f$2:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->$r8$lambda$1BDEvSkiShgEl2Tjy7fA8Swex2I(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

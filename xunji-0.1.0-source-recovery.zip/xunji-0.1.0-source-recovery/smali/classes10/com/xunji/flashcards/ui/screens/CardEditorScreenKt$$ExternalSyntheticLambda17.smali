.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/EditorUiState;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/EditorViewModel;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Lkotlin/jvm/functions/Function2;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$5:I

.field public final synthetic f$6:I


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;II)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$0:Lcom/xunji/flashcards/ui/EditorUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$1:Lcom/xunji/flashcards/ui/EditorViewModel;

    iput-boolean p3, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$2:Z

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$3:Lkotlin/jvm/functions/Function2;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$4:Lkotlin/jvm/functions/Function0;

    iput p6, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$5:I

    iput p7, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$6:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$0:Lcom/xunji/flashcards/ui/EditorUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$1:Lcom/xunji/flashcards/ui/EditorViewModel;

    iget-boolean v2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$2:Z

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$3:Lkotlin/jvm/functions/Function2;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$4:Lkotlin/jvm/functions/Function0;

    iget v5, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$5:I

    iget v6, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;->f$6:I

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->$r8$lambda$_uQlQyPW0NdsDS7qjsmDNo5JUfg(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

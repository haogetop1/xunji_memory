.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/EditorViewModel;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda2;->f$0:Lcom/xunji/flashcards/ui/EditorViewModel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda2;->f$0:Lcom/xunji/flashcards/ui/EditorViewModel;

    invoke-static {v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->$r8$lambda$qGhXUAzOLxK6oh98h8OlAwEfTT0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

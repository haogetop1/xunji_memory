.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/EditorViewModel;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/EditorViewModel;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/EditorViewModel;

    check-cast p1, Ljava/lang/String;

    invoke-static {v0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->$r8$lambda$tX-pMY2y-eF6_ScJDQ-GUUs0oJE(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/focus/FocusManager;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/EditorViewModel;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;->f$0:Landroidx/compose/ui/focus/FocusManager;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;->f$1:Lcom/xunji/flashcards/ui/EditorViewModel;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;->f$0:Landroidx/compose/ui/focus/FocusManager;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;->f$1:Lcom/xunji/flashcards/ui/EditorViewModel;

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->$r8$lambda$HNFAks3n14NRS-k1wemFcau3XPM(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

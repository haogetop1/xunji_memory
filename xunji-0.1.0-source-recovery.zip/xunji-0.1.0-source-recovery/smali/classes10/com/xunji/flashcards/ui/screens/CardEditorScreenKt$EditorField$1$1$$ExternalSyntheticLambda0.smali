.class public final synthetic Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    check-cast p1, Ljava/lang/Long;

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$r8$lambda$GBg1DhqW1Br0NUqK-TWJAG-PyvY(J)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class final Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "CardEditorScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.screens.CardEditorScreenKt$EditorField$1$1"
    f = "CardEditorScreen.kt"
    i = {}
    l = {
        0x3a,
        0x3a
    }
    m = "invokeSuspend"
    n = {}
    s = {}
    v = 0x1
.end annotation


# instance fields
.field final synthetic $error:Ljava/lang/String;

.field final synthetic $errorView:Landroidx/compose/foundation/relocation/BringIntoViewRequester;

.field label:I


# direct methods
.method public static synthetic $r8$lambda$GBg1DhqW1Br0NUqK-TWJAG-PyvY(J)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->invokeSuspend$lambda$0(J)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method constructor <init>(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Lkotlin/coroutines/Continuation;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Landroidx/compose/foundation/relocation/BringIntoViewRequester;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$error:Ljava/lang/String;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$errorView:Landroidx/compose/foundation/relocation/BringIntoViewRequester;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method private static final invokeSuspend$lambda$0(J)Lkotlin/Unit;
    .registers 3
    .param p0, "it"    # J

    .line 58
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$error:Ljava/lang/String;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$errorView:Landroidx/compose/foundation/relocation/BringIntoViewRequester;

    invoke-direct {v0, v1, v2, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;-><init>(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 58
    iget v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->label:I

    const/4 v2, 0x1

    packed-switch v1, :pswitch_data_46

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_42

    :pswitch_16
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_32

    :pswitch_1a
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$error:Ljava/lang/String;

    if-eqz v1, :cond_42

    new-instance v1, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1$$ExternalSyntheticLambda0;

    invoke-direct {v1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1$$ExternalSyntheticLambda0;-><init>()V

    move-object v3, p0

    check-cast v3, Lkotlin/coroutines/Continuation;

    iput v2, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->label:I

    invoke-static {v1, v3}, Landroidx/compose/runtime/MonotonicFrameClockKt;->withFrameNanos(Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_32

    return-object v0

    :cond_32
    :goto_32
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->$errorView:Landroidx/compose/foundation/relocation/BringIntoViewRequester;

    move-object v3, p0

    check-cast v3, Lkotlin/coroutines/Continuation;

    const/4 v4, 0x2

    iput v4, p0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;->label:I

    const/4 v4, 0x0

    invoke-static {v1, v4, v3, v2, v4}, Landroidx/compose/foundation/relocation/BringIntoViewRequester;->bringIntoView$default(Landroidx/compose/foundation/relocation/BringIntoViewRequester;Landroidx/compose/ui/geometry/Rect;Lkotlin/coroutines/Continuation;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_42

    return-object v0

    :cond_42
    :goto_42
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    nop

    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_16
        :pswitch_12
    .end packed-switch
.end method

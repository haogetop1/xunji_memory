.class public final Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;
.super Ljava/lang/Object;
.source "CardEditorScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nCardEditorScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CardEditorScreen.kt\ncom/xunji/flashcards/ui/screens/CardEditorScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 9 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 10 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 11 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 12 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 13 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n*L\n1#1,64:1\n1282#2,6:65\n1282#2,6:72\n1282#2,6:78\n1282#2,6:84\n1282#2,6:208\n1282#2,6:254\n1282#2,6:260\n1282#2,6:272\n1282#2,6:278\n1282#2,6:284\n1282#2,6:332\n1282#2,6:346\n1282#2,6:352\n1282#2,6:359\n1282#2,6:412\n75#3:71\n75#3:358\n87#4:90\n84#4,9:91\n87#4:170\n85#4,8:171\n94#4:293\n94#4:345\n87#4:366\n83#4,10:367\n94#4:408\n80#5,6:100\n87#5,3:115\n90#5,2:124\n80#5,6:138\n87#5,3:153\n90#5,2:162\n94#5:167\n80#5,6:179\n87#5,3:194\n90#5,2:203\n80#5,6:227\n87#5,3:242\n90#5,2:251\n94#5:268\n94#5:292\n80#5,6:305\n87#5,3:320\n90#5,2:329\n94#5:340\n94#5:344\n80#5,6:377\n87#5,3:392\n90#5,2:401\n94#5:407\n391#6,9:106\n400#6:126\n391#6,9:144\n400#6,3:164\n391#6,9:185\n400#6:205\n391#6,9:233\n400#6:253\n401#6,2:266\n401#6,2:290\n391#6,9:311\n400#6:331\n401#6,2:338\n401#6,2:342\n391#6,9:383\n400#6:403\n401#6,2:405\n4360#7,6:118\n4360#7,6:156\n4360#7,6:197\n4360#7,6:245\n4360#7,6:323\n4360#7,6:395\n113#8:127\n113#8:169\n113#8:215\n113#8:271\n113#8:294\n113#8:365\n113#8:404\n99#9:128\n96#9,9:129\n106#9:168\n99#9:216\n95#9,10:217\n106#9:269\n1878#10,2:206\n1880#10:214\n1#11:270\n70#12:295\n67#12,9:296\n77#12:341\n85#13:409\n117#13,2:410\n*S KotlinDebug\n*F\n+ 1 CardEditorScreen.kt\ncom/xunji/flashcards/ui/screens/CardEditorScreenKt\n*L\n23#1:65,6\n25#1:72,6\n26#1:78,6\n28#1:84,6\n35#1:208,6\n37#1:254,6\n38#1:260,6\n44#1:272,6\n45#1:278,6\n46#1:284,6\n50#1:332,6\n52#1:346,6\n55#1:352,6\n58#1:359,6\n52#1:412,6\n24#1:71\n56#1:358\n29#1:90\n29#1:91,9\n32#1:170\n32#1:171,8\n32#1:293\n29#1:345\n59#1:366\n59#1:367,10\n59#1:408\n29#1:100,6\n29#1:115,3\n29#1:124,2\n30#1:138,6\n30#1:153,3\n30#1:162,2\n30#1:167\n32#1:179,6\n32#1:194,3\n32#1:203,2\n36#1:227,6\n36#1:242,3\n36#1:251,2\n36#1:268\n32#1:292\n50#1:305,6\n50#1:320,3\n50#1:329,2\n50#1:340\n29#1:344\n59#1:377,6\n59#1:392,3\n59#1:401,2\n59#1:407\n29#1:106,9\n29#1:126\n30#1:144,9\n30#1:164,3\n32#1:185,9\n32#1:205\n36#1:233,9\n36#1:253\n36#1:266,2\n32#1:290,2\n50#1:311,9\n50#1:331\n50#1:338,2\n29#1:342,2\n59#1:383,9\n59#1:403\n59#1:405,2\n29#1:118,6\n30#1:156,6\n32#1:197,6\n36#1:245,6\n50#1:323,6\n59#1:395,6\n30#1:127\n32#1:169\n36#1:215\n41#1:271\n50#1:294\n59#1:365\n61#1:404\n30#1:128\n30#1:129,9\n30#1:168\n36#1:216\n36#1:217,10\n36#1:269\n35#1:206,2\n35#1:214\n50#1:295\n50#1:296,9\n50#1:341\n25#1:409\n25#1:410,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0006\u001a[\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072&\u0008\u0002\u0010\u0008\u001a \u0008\u0001\u0012\u0004\u0012\u00020\n\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u000c0\u000b\u0012\u0006\u0012\u0004\u0018\u00010\r0\t2\u000c\u0010\u000e\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000fH\u0007\u00a2\u0006\u0002\u0010\u0010\u001aS\u0010\u0011\u001a\u00020\u00012\u0006\u0010\u0012\u001a\u00020\u00132\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0015\u001a\u00020\u00132\u0012\u0010\u0016\u001a\u000e\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00020\u00010\u00172\u0008\u0010\u0018\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u0019\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u0007H\u0003\u00a2\u0006\u0002\u0010\u001b\u00a8\u0006\u001c\u00b2\u0006\n\u0010\u001d\u001a\u00020\u0007X\u008a\u008e\u0002"
    }
    d2 = {
        "CardEditorScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/EditorUiState;",
        "viewModel",
        "Lcom/xunji/flashcards/ui/EditorViewModel;",
        "editing",
        "",
        "openMedia",
        "Lkotlin/Function2;",
        "Lcom/xunji/flashcards/anki/CardMedia;",
        "Lkotlin/coroutines/Continuation;",
        "Ljava/io/InputStream;",
        "",
        "onExit",
        "Lkotlin/Function0;",
        "(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "EditorField",
        "label",
        "",
        "placeholder",
        "value",
        "onChange",
        "Lkotlin/Function1;",
        "error",
        "tag",
        "enabled",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "discard"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$0Lo0_0S2lTQ6Z9NvKkqwNWhh_CA(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$3$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$1BDEvSkiShgEl2Tjy7fA8Swex2I(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$4$0(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$1GCfPFIQJ8mRkmQOL-qh5deMbxc(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$9$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4uqS-ns9BmnC9c2bT7ZdL1Nh2h8(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField$lambda$2$0(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8QMVtDFt89knMDMiIlhl3OGD9Y0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$5$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$D9bOBEXshcwSsNvW6NnZY8b2FPk(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10

    invoke-static/range {p0 .. p9}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField$lambda$3(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$HNFAks3n14NRS-k1wemFcau3XPM(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$3$0$0(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$HXlFXd--bfYa8g79-BOoI57PgQA(Lcom/xunji/flashcards/ui/EditorViewModel;ILjava/lang/String;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$0$0$0(Lcom/xunji/flashcards/ui/EditorViewModel;ILjava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$I-WRYtIi-u8pZSsknhhyvbYvFiQ(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$7$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Rr42jqJufDYuSZbYSQo6NkPf_R0()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$1$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$SKA3T8ArPp-JpN-IjcChyIjm78w(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$9(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TLc_hR6HT-fIasGv3HtAG59dBvA(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField$lambda$2$1(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$VC2AZpIiX-fVqXvmjVrtNb0LrVo(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$1$0$0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XOHGoiEwJ5G-CnqogKCk3B6-NwE(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$8$0$0(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$_uQlQyPW0NdsDS7qjsmDNo5JUfg(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$1(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$a8rkzQD3DOtYwbCMiU6gYZMexJ0(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$10(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$fMEeCv59g5-9ILh7pHj2T7tDCS4(Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$8(Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qGhXUAzOLxK6oh98h8OlAwEfTT0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$1$1$0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tX-pMY2y-eF6_ScJDQ-GUUs0oJE(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$6$2$4$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final CardEditorScreen(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .registers 109
    .param p0, "state"    # Lcom/xunji/flashcards/ui/EditorUiState;
    .param p1, "viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;
    .param p2, "editing"    # Z
    .param p3, "openMedia"    # Lkotlin/jvm/functions/Function2;
    .param p4, "onExit"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/EditorUiState;",
            "Lcom/xunji/flashcards/ui/EditorViewModel;",
            "Z",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v5, p4

    move/from16 v6, p6

    const-string v0, "state"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "viewModel"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onExit"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    const v0, 0x6bc0b1c1

    move-object/from16 v4, p5

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(CardEditorScreen)N(state,viewModel,editing,openMedia,onExit)23@1082L7,24@1123L25,24@1106L42,25@1166L71,26@1239L31,27@1300L27,27@1272L55,28@1329L1937:CardEditorScreen.kt#i35lj1"

    invoke-static {v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentMarker()I

    move-result v4

    move/from16 v7, p6

    .local v7, "$dirty":I
    and-int/lit8 v9, v6, 0x6

    if-nez v9, :cond_3b

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_39

    const/4 v9, 0x4

    goto :goto_3a

    :cond_39
    const/4 v9, 0x2

    :goto_3a
    or-int/2addr v7, v9

    :cond_3b
    and-int/lit8 v9, v6, 0x30

    if-nez v9, :cond_4b

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_48

    const/16 v9, 0x20

    goto :goto_4a

    :cond_48
    const/16 v9, 0x10

    :goto_4a
    or-int/2addr v7, v9

    :cond_4b
    and-int/lit16 v9, v6, 0x180

    if-nez v9, :cond_5b

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v9

    if-eqz v9, :cond_58

    const/16 v9, 0x100

    goto :goto_5a

    :cond_58
    const/16 v9, 0x80

    :goto_5a
    or-int/2addr v7, v9

    :cond_5b
    and-int/lit16 v9, v6, 0xc00

    if-nez v9, :cond_74

    and-int/lit8 v9, p7, 0x8

    if-nez v9, :cond_6e

    move-object/from16 v9, p3

    invoke-interface {v8, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_70

    const/16 v11, 0x800

    goto :goto_72

    :cond_6e
    move-object/from16 v9, p3

    :cond_70
    const/16 v11, 0x400

    :goto_72
    or-int/2addr v7, v11

    goto :goto_76

    :cond_74
    move-object/from16 v9, p3

    :goto_76
    and-int/lit16 v11, v6, 0x6000

    if-nez v11, :cond_86

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_83

    const/16 v11, 0x4000

    goto :goto_85

    :cond_83
    const/16 v11, 0x2000

    :goto_85
    or-int/2addr v7, v11

    :cond_86
    and-int/lit16 v11, v7, 0x2493

    const/16 v13, 0x2492

    if-eq v11, v13, :cond_8e

    const/4 v11, 0x1

    goto :goto_8f

    :cond_8e
    const/4 v11, 0x0

    :goto_8f
    and-int/lit8 v13, v7, 0x1

    invoke-interface {v8, v11, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v11

    if-eqz v11, :cond_e2a

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startDefaults()V

    const-string v11, "22@1027L6"

    invoke-static {v8, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v11, v6, 0x1

    const/4 v13, 0x0

    const-string v10, "CC(remember):CardEditorScreen.kt#9igjgp"

    if-eqz v11, :cond_ba

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getDefaultsInvalid()Z

    move-result v11

    if-eqz v11, :cond_ad

    goto :goto_ba

    :cond_ad
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    and-int/lit8 v11, p7, 0x8

    if-eqz v11, :cond_f6

    and-int/lit16 v7, v7, -0x1c01

    move-object/from16 v23, v9

    move v9, v7

    goto :goto_f9

    :cond_ba
    :goto_ba
    and-int/lit8 v11, p7, 0x8

    if-eqz v11, :cond_f6

    const v11, 0x7e5b5567

    invoke-static {v8, v11, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v11, 0x0

    .local v11, "invalid\\1":Z
    move-object/from16 v16, v8

    .local v16, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 65
    .local v17, "$i$f$cache\\1\\23":I
    invoke-interface/range {v16 .. v16}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\1":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 66
    .local v19, "$i$a$-let-ComposerKt$cache$1\\2\\65\\1":I
    sget-object v20, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v14, v12, :cond_e7

    .line 67
    const/4 v12, 0x0

    .line 23
    .local v12, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$1\\3\\67\\0":I
    new-instance v15, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$CardEditorScreen$1$1;

    invoke-direct {v15, v13}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$CardEditorScreen$1$1;-><init>(Lkotlin/coroutines/Continuation;)V

    check-cast v15, Lkotlin/jvm/functions/Function2;

    .line 67
    .end local v12    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$1\\3\\67\\0":I
    nop

    .line 68
    .local v15, "value\\2":Ljava/lang/Object;
    move-object/from16 v12, v16

    .end local v16    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .local v12, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    invoke-interface {v12, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 69
    move-object v14, v15

    .end local v15    # "value\\2":Ljava/lang/Object;
    goto :goto_e9

    .line 70
    .end local v12    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .restart local v16    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    :cond_e7
    move-object/from16 v12, v16

    .line 65
    .end local v14    # "it\\1":Ljava/lang/Object;
    .end local v16    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-let-ComposerKt$cache$1\\2\\65\\1":I
    .restart local v12    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    :goto_e9
    nop

    .line 23
    .end local v11    # "invalid\\1":Z
    .end local v12    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$f$cache\\1\\23":I
    move-object v9, v14

    check-cast v9, Lkotlin/jvm/functions/Function2;

    .end local p3    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v9, "openMedia":Lkotlin/jvm/functions/Function2;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    and-int/lit16 v7, v7, -0x1c01

    move-object/from16 v23, v9

    move v9, v7

    goto :goto_f9

    .end local v9    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local p3    # "openMedia":Lkotlin/jvm/functions/Function2;
    :cond_f6
    move-object/from16 v23, v9

    move v9, v7

    .end local v7    # "$dirty":I
    .end local p3    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v9, "$dirty":I
    .local v23, "openMedia":Lkotlin/jvm/functions/Function2;
    :goto_f9
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endDefaults()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_108

    const/4 v7, -0x1

    const-string v11, "com.xunji.flashcards.ui.screens.CardEditorScreen (CardEditorScreen.kt:22)"

    invoke-static {v0, v9, v7, v11}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 24
    :cond_108
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalFocusManager()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/CompositionLocal;

    .local v0, "this_\\4":Landroidx/compose/runtime/CompositionLocal;
    const/4 v7, 0x0

    .local v7, "$changed\\4":I
    move-object v11, v8

    .local v11, "$composer\\4":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 71
    .local v12, "$i$f$getCurrent\\4\\24":I
    const v14, 0x789c5f52

    const-string v15, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    invoke-static {v11, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v14

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 24
    .end local v0    # "this_\\4":Landroidx/compose/runtime/CompositionLocal;
    .end local v7    # "$changed\\4":I
    .end local v11    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$getCurrent\\4\\24":I
    move-object v11, v14

    check-cast v11, Landroidx/compose/ui/focus/FocusManager;

    const/4 v0, 0x0

    .local v11, "focus":Landroidx/compose/ui/focus/FocusManager;
    new-array v7, v0, [Ljava/lang/Object;

    .line 25
    const v0, 0x7e5b617a

    invoke-static {v8, v0, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\5":Z
    move-object v12, v8

    .local v12, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 72
    .local v14, "$i$f$cache\\5\\25":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\5":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 73
    .local v16, "$i$a$-let-ComposerKt$cache$1\\6\\72\\5":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v15, v13, :cond_14a

    .line 74
    const/4 v13, 0x0

    .local v13, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$discard$2\\7\\74\\0":I
    new-instance v17, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda11;

    invoke-direct/range {v17 .. v17}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda11;-><init>()V

    .end local v13    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$discard$2\\7\\74\\0":I
    move-object/from16 v13, v17

    .line 75
    .local v13, "value\\6":Ljava/lang/Object;
    invoke-interface {v12, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 76
    move-object v15, v13

    .end local v13    # "value\\6":Ljava/lang/Object;
    goto :goto_14b

    .line 77
    :cond_14a
    nop

    .line 72
    .end local v15    # "it\\5":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\6\\72\\5":I
    :goto_14b
    nop

    .line 25
    .end local v0    # "invalid\\5":Z
    .end local v12    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\5\\25":I
    check-cast v15, Lkotlin/jvm/functions/Function0;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v0, 0x30

    invoke-static {v7, v15, v8, v0}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v7

    move-object v12, v7

    check-cast v12, Landroidx/compose/runtime/MutableState;

    .line 26
    .local v12, "discard$delegate":Landroidx/compose/runtime/MutableState;
    const v7, 0x7e5b6708

    invoke-static {v8, v7, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    invoke-interface {v8, v12}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v13

    or-int/2addr v7, v13

    const v13, 0xe000

    and-int v14, v9, v13

    const/16 v15, 0x4000

    if-ne v14, v15, :cond_174

    const/4 v14, 0x1

    goto :goto_175

    :cond_174
    const/4 v14, 0x0

    :goto_175
    or-int/2addr v7, v14

    .local v7, "invalid\\8":Z
    move-object v14, v8

    .local v14, "$this$cache\\8":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 78
    .local v15, "$i$f$cache\\8\\26":I
    move/from16 p3, v13

    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\8":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 79
    .local v16, "$i$a$-let-ComposerKt$cache$1\\9\\78\\8":I
    if-nez v7, :cond_18c

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v13, v0, :cond_18b

    goto :goto_18c

    .line 83
    :cond_18b
    goto :goto_199

    .line 80
    :cond_18c
    :goto_18c
    const/4 v0, 0x0

    .line 26
    .local v0, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$requestExit$1\\10\\80\\0":I
    move/from16 v17, v0

    .end local v0    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$requestExit$1\\10\\80\\0":I
    .local v17, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$requestExit$1\\10\\80\\0":I
    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;

    invoke-direct {v0, v1, v5, v12}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda16;-><init>(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 80
    .end local v17    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$requestExit$1\\10\\80\\0":I
    nop

    .line 81
    .local v0, "value\\9":Ljava/lang/Object;
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 82
    move-object v13, v0

    .line 78
    .end local v0    # "value\\9":Ljava/lang/Object;
    .end local v13    # "it\\8":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\9\\78\\8":I
    :goto_199
    nop

    .line 26
    .end local v7    # "invalid\\8":Z
    .end local v14    # "$this$cache\\8":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\8\\26":I
    move-object v0, v13

    check-cast v0, Lkotlin/jvm/functions/Function0;

    .local v0, "requestExit":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 27
    const/4 v7, 0x1

    const/4 v13, 0x0

    invoke-static {v13, v0, v8, v13, v7}, Landroidx/activity/compose/BackHandlerKt;->BackHandler(ZLkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .line 28
    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaved()Z

    move-result v7

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    const v13, 0x7e5b779c

    invoke-static {v8, v13, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    and-int v14, v9, p3

    const/16 v15, 0x4000

    if-ne v14, v15, :cond_1bf

    const/4 v14, 0x1

    goto :goto_1c0

    :cond_1bf
    const/4 v14, 0x0

    :goto_1c0
    or-int/2addr v13, v14

    .local v13, "invalid\\11":Z
    move-object v14, v8

    .local v14, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 84
    .local v15, "$i$f$cache\\11\\28":I
    move-object/from16 v31, v0

    .end local v0    # "requestExit":Lkotlin/jvm/functions/Function0;
    .local v31, "requestExit":Lkotlin/jvm/functions/Function0;
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\11":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 85
    .local v16, "$i$a$-let-ComposerKt$cache$1\\12\\84\\11":I
    if-nez v13, :cond_1d7

    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_1d6

    goto :goto_1d7

    .line 89
    :cond_1d6
    goto :goto_1e9

    .line 86
    :cond_1d7
    :goto_1d7
    const/4 v2, 0x0

    .line 28
    .local v2, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$2\\13\\86\\0":I
    move-object/from16 p3, v0

    .end local v0    # "it\\11":Ljava/lang/Object;
    .local p3, "it\\11":Ljava/lang/Object;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$CardEditorScreen$2$1;

    move/from16 v17, v2

    const/4 v2, 0x0

    .end local v2    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$2\\13\\86\\0":I
    .local v17, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$2\\13\\86\\0":I
    invoke-direct {v0, v1, v5, v2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$CardEditorScreen$2$1;-><init>(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    .line 86
    .end local v17    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$2\\13\\86\\0":I
    nop

    .line 87
    .local v0, "value\\12":Ljava/lang/Object;
    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 88
    nop

    .line 84
    .end local v0    # "value\\12":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\12\\84\\11":I
    .end local p3    # "it\\11":Ljava/lang/Object;
    :goto_1e9
    nop

    .line 28
    .end local v13    # "invalid\\11":Z
    .end local v14    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\11\\28":I
    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v13, 0x0

    invoke-static {v7, v0, v8, v13}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 29
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v13, 0x1

    invoke-static {v0, v2, v13, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-static {v0}, Landroidx/compose/foundation/layout/WindowInsetsPadding_androidKt;->imePadding(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .local v13, "modifier\\14":Landroidx/compose/ui/Modifier;
    const/4 v0, 0x0

    .local v0, "$changed\\14":I
    move-object v14, v8

    .local v14, "$composer\\14":Landroidx/compose/runtime/Composer;
    move v15, v0

    .end local v0    # "$changed\\14":I
    .local v15, "$changed\\14":I
    const/16 v16, 0x0

    .line 90
    .local v16, "$i$f$Column\\14\\29":I
    const v0, 0x4ff7456f

    const-string v7, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v14, v0, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 91
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v0

    .line 92
    .local v0, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 95
    .local v7, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v17, v15, 0x3

    and-int/lit8 v17, v17, 0xe

    shr-int/lit8 v21, v15, 0x3

    and-int/lit8 v21, v21, 0x70

    or-int v2, v17, v21

    invoke-static {v0, v7, v14, v2}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .line 99
    .local v2, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v17, v15, 0x3

    and-int/lit8 v17, v17, 0x70

    .line 96
    nop

    .local v17, "$changed\\15":I
    move-object/from16 v21, v13

    .local v21, "modifier\\15":Landroidx/compose/ui/Modifier;
    const/16 v37, 0x0

    .line 100
    .local v37, "$i$f$Layout\\15\\96":I
    move-object/from16 v22, v0

    .end local v0    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v22, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const v0, -0x451e1427

    const-string v1, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v14, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 101
    const/4 v0, 0x0

    invoke-static {v14, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v24

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->hashCode(J)I

    move-result v39

    .line 102
    .local v39, "compositeKeyHash\\15":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 103
    .local v0, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v40, v9

    move-object/from16 v9, v21

    .end local v13    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v9, "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v21, "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v40, "$dirty":I
    invoke-static {v14, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 105
    .local v13, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v24

    shl-int/lit8 v3, v17, 0x6

    and-int/lit16 v3, v3, 0x380

    move/from16 v25, v3

    const/4 v3, 0x6

    or-int/lit8 v25, v25, 0x6

    .line 104
    move-object/from16 v41, v24

    .local v41, "factory\\16":Lkotlin/jvm/functions/Function0;
    move/from16 v42, v25

    .local v42, "$changed\\16":I
    const/16 v43, 0x0

    .line 106
    .local v43, "$i$f$ReusableComposeNode\\16\\104":I
    move/from16 v44, v3

    const v3, -0x20f7d59c

    const-string v5, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v14, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 107
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_27b

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 108
    :cond_27b
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 109
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_28a

    .line 110
    move-object/from16 v3, v41

    .end local v41    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v14, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_28f

    .line 112
    .end local v3    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v41    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_28a
    move-object/from16 v3, v41

    .end local v41    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 114
    :goto_28f
    move-object/from16 v24, v3

    .end local v3    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v24, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-static {v14}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 115
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\114\\15":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v2, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 116
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    invoke-static {v3, v0, v6}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 117
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    .local v6, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 118
    .local v26, "$i$f$set-impl\\18\\117":I
    move-object/from16 v27, v3

    .local v27, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 119
    .local v29, "$i$a$-with-Updater$set$1\\19\\118\\18":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_2d1

    move-object/from16 v41, v0

    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v41, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v46, v2

    .end local v2    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v46, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_2ce

    goto :goto_2d5

    :cond_2ce
    move-object/from16 v2, v27

    goto :goto_2e5

    .end local v41    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v46    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_2d1
    move-object/from16 v41, v0

    move-object/from16 v46, v2

    .line 120
    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v2    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v41    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v46    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_2d5
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v2, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 121
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v3, v0, v6}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 123
    :goto_2e5
    nop

    .line 118
    .end local v2    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-with-Updater$set$1\\19\\118\\18":I
    nop

    .line 123
    nop

    .line 124
    .end local v6    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v26    # "$i$f$set-impl\\18\\117":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v3, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 125
    nop

    .line 114
    .end local v3    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\114\\15":I
    nop

    .line 126
    shr-int/lit8 v0, v42, 0x6

    and-int/lit8 v47, v0, 0xe

    .local v47, "$changed\\20":I
    move-object v0, v14

    .local v0, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v48, 0x0

    .line 97
    .local v48, "$i$a$-Layout-ColumnKt$Column$1\\20\\126\\14":I
    const v2, 0x7cc0ae6e

    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v0, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v15, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v49, v3, 0x6

    .local v49, "$changed\\21":I
    check-cast v2, Landroidx/compose/foundation/layout/ColumnScope;

    .local v2, "$this$CardEditorScreen_u24lambda_u246\\21":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v3, v0

    .local v3, "$composer\\21":Landroidx/compose/runtime/Composer;
    move-object/from16 v50, v2

    .end local v2    # "$this$CardEditorScreen_u24lambda_u246\\21":Landroidx/compose/foundation/layout/ColumnScope;
    .local v50, "$this$CardEditorScreen_u24lambda_u246\\21":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v56, 0x0

    .line 30
    .local v56, "$i$a$-Column-CardEditorScreenKt$CardEditorScreen$3\\21\\97\\0":I
    const v2, 0x2d82b3ce

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "C29@1377L239,31@1696L21,31@1654L1411,49@3068L195:CardEditorScreen.kt#i35lj1"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v25, v0

    move-object/from16 v26, v7

    const/4 v0, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    .end local v0    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v7    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v25, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v26, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v2, v6, v7, v0}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v0, 0xa

    .local v0, "$this$dp\\22":I
    const/4 v6, 0x0

    .line 127
    .local v6, "$i$f$getDp\\22\\30":I
    int-to-float v7, v0

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 30
    .end local v0    # "$this$dp\\22":I
    .end local v6    # "$i$f$getDp\\22\\30":I
    const/4 v6, 0x6

    .local v6, "$this$dp\\23":I
    const/4 v7, 0x0

    .line 127
    .local v7, "$i$f$getDp\\23\\30":I
    move/from16 v27, v7

    .end local v7    # "$i$f$getDp\\23\\30":I
    .local v27, "$i$f$getDp\\23\\30":I
    int-to-float v7, v6

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 30
    .end local v6    # "$this$dp\\23":I
    .end local v27    # "$i$f$getDp\\23\\30":I
    invoke-static {v2, v0, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\24":Landroidx/compose/ui/Modifier;
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    .local v2, "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v6, 0x186

    .local v6, "$changed\\24":I
    move-object v7, v3

    .local v7, "$composer\\24":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 128
    .local v27, "$i$f$Row\\24\\30":I
    move-object/from16 v51, v0

    .end local v0    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v51, "modifier\\24":Landroidx/compose/ui/Modifier;
    const v0, 0x3255a44b

    move/from16 v52, v6

    .end local v6    # "$changed\\24":I
    .local v52, "$changed\\24":I
    const-string v6, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v7, v0, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 129
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v0

    .line 133
    .local v0, "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v6, v52, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v29, v52, 0x3

    and-int/lit8 v29, v29, 0x70

    or-int v6, v6, v29

    invoke-static {v0, v2, v7, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 137
    .local v6, "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v29, v52, 0x3

    and-int/lit8 v29, v29, 0x70

    .line 134
    move-object/from16 v53, v51

    .local v53, "modifier\\25":Landroidx/compose/ui/Modifier;
    move/from16 v54, v29

    .local v54, "$changed\\25":I
    const/16 v55, 0x0

    .line 138
    .local v55, "$i$f$Layout\\25\\134":I
    move-object/from16 v57, v0

    const v0, -0x451e1427

    .end local v0    # "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v57, "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 139
    const/4 v0, 0x0

    invoke-static {v7, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v29

    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 140
    .local v0, "compositeKeyHash\\25":I
    move/from16 v58, v0

    .end local v0    # "compositeKeyHash\\25":I
    .local v58, "compositeKeyHash\\25":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 141
    .local v0, "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v59, v2

    move-object/from16 v60, v9

    move-object/from16 v2, v53

    .end local v9    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v53    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v2, "modifier\\25":Landroidx/compose/ui/Modifier;
    .local v59, "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    .local v60, "modifier\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v9

    .line 143
    .local v9, "materialized\\25":Landroidx/compose/ui/Modifier;
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v29

    .end local v2    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .restart local v53    # "modifier\\25":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v54, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 142
    nop

    .local v2, "$changed\\26":I
    move-object/from16 v61, v29

    .local v61, "factory\\26":Lkotlin/jvm/functions/Function0;
    const/16 v62, 0x0

    .line 144
    .local v62, "$i$f$ReusableComposeNode\\26\\142":I
    move/from16 v63, v2

    const v2, -0x20f7d59c

    .end local v2    # "$changed\\26":I
    .local v63, "$changed\\26":I
    invoke-static {v7, v2, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 145
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_3ba

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 146
    :cond_3ba
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 147
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_3c9

    .line 148
    move-object/from16 v2, v61

    .end local v61    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_3ce

    .line 150
    .end local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v61    # "factory\\26":Lkotlin/jvm/functions/Function0;
    :cond_3c9
    move-object/from16 v2, v61

    .end local v61    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 152
    :goto_3ce
    move-object/from16 v61, v2

    .end local v2    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .restart local v61    # "factory\\26":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 153
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\27\\152\\25":I
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v64, v7

    .end local v7    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\24":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v6, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 154
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v2, v0, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 155
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\28":Lkotlin/jvm/functions/Function2;
    const/16 v30, 0x0

    .line 156
    .local v30, "$i$f$set-impl\\28\\155":I
    move-object/from16 v32, v2

    .local v32, "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 157
    .local v33, "$i$a$-with-Updater$set$1\\29\\156\\28":I
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v34

    if-nez v34, :cond_412

    move-object/from16 v65, v0

    .end local v0    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .local v65, "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v32 .. v32}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v66, v6

    .end local v6    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v66, "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v58 .. v58}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_40f

    goto :goto_416

    :cond_40f
    move-object/from16 v6, v32

    goto :goto_426

    .end local v65    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v66    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_412
    move-object/from16 v65, v0

    move-object/from16 v66, v6

    .line 158
    .end local v0    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v65    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v66    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_416
    invoke-static/range {v58 .. v58}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v6, v32

    .end local v32    # "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 159
    invoke-static/range {v58 .. v58}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v2, v0, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 161
    :goto_426
    nop

    .line 156
    .end local v6    # "$this$set_impl_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-with-Updater$set$1\\29\\156\\28":I
    nop

    .line 161
    nop

    .line 162
    .end local v7    # "block\\28":Lkotlin/jvm/functions/Function2;
    .end local v30    # "$i$f$set-impl\\28\\155":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v2, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 163
    nop

    .line 152
    .end local v2    # "$this$Layout_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\27\\152\\25":I
    nop

    .line 164
    shr-int/lit8 v0, v63, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\30":I
    move-object/from16 v2, v64

    .local v2, "$composer\\30":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 135
    .local v6, "$i$a$-Layout-RowKt$Row$1\\30\\164\\24":I
    const v7, 0x56ccd6f5

    move/from16 v67, v0

    .end local v0    # "$changed\\30":I
    .local v67, "$changed\\30":I
    const-string v0, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v7, v52, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\31":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$CardEditorScreen_u24lambda_u246_u240\\31":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v34, v2

    .local v34, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/16 v94, 0x0

    .line 30
    .local v94, "$i$a$-Row-CardEditorScreenKt$CardEditorScreen$3$1\\31\\135\\21":I
    move-object/from16 v95, v0

    .end local v0    # "$this$CardEditorScreen_u24lambda_u246_u240\\31":Landroidx/compose/foundation/layout/RowScope;
    .local v95, "$this$CardEditorScreen_u24lambda_u246_u240\\31":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x58649925

    move-object/from16 v96, v2

    .end local v2    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .local v96, "$composer\\30":Landroidx/compose/runtime/Composer;
    const-string v2, "C29@1473L63,29@1592L10,29@1537L77:CardEditorScreen.kt#i35lj1"

    move/from16 v97, v6

    move-object/from16 v6, v34

    .end local v34    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v97, "$i$a$-Layout-RowKt$Row$1\\30\\164\\24":I
    invoke-static {v6, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v0

    const/16 v18, 0x1

    xor-int/lit8 v33, v0, 0x1

    const/16 v35, 0xc36

    const/16 v36, 0x0

    const-string v29, "back"

    const-string v30, "\u8fd4\u56de"

    const-string v32, "editor-exit"

    move-object/from16 v34, v6

    .end local v6    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v34    # "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v36}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .end local v34    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\31":Landroidx/compose/runtime/Composer;
    if-eqz p2, :cond_47f

    const-string v0, "\u7f16\u8f91\u5361\u7247"

    goto :goto_481

    :cond_47f
    const-string v0, "\u65b0\u5efa\u5361\u7247"

    :goto_481
    move-object/from16 v68, v0

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v6, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v89

    const/16 v92, 0x0

    const v93, 0x1fffe

    const/16 v69, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const-wide/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const-wide/16 v78, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const-wide/16 v82, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v91, 0x0

    move-object/from16 v90, v6

    .end local v6    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v90, "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static/range {v68 .. v93}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v90    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$composer\\31":Landroidx/compose/runtime/Composer;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 135
    .end local v6    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v7    # "$changed\\31":I
    .end local v94    # "$i$a$-Row-CardEditorScreenKt$CardEditorScreen$3$1\\31\\135\\21":I
    .end local v95    # "$this$CardEditorScreen_u24lambda_u246_u240\\31":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v96 .. v96}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 164
    .end local v67    # "$changed\\30":I
    .end local v96    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .end local v97    # "$i$a$-Layout-RowKt$Row$1\\30\\164\\24":I
    nop

    .line 165
    invoke-interface/range {v64 .. v64}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 144
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 166
    nop

    .line 138
    .end local v61    # "factory\\26":Lkotlin/jvm/functions/Function0;
    .end local v62    # "$i$f$ReusableComposeNode\\26\\142":I
    .end local v63    # "$changed\\26":I
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 167
    nop

    .line 128
    .end local v9    # "materialized\\25":Landroidx/compose/ui/Modifier;
    .end local v53    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .end local v54    # "$changed\\25":I
    .end local v55    # "$i$f$Layout\\25\\134":I
    .end local v58    # "compositeKeyHash\\25":I
    .end local v65    # "localMap\\25":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 168
    nop

    .line 31
    .end local v27    # "$i$f$Row\\24\\30":I
    .end local v51    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .end local v52    # "$changed\\24":I
    .end local v57    # "horizontalArrangement\\24":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v59    # "verticalAlignment\\24":Landroidx/compose/ui/Alignment$Vertical;
    .end local v64    # "$composer\\24":Landroidx/compose/runtime/Composer;
    .end local v66    # "measurePolicy\\24":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getLoading()Z

    move-result v0

    if-eqz v0, :cond_52d

    const v0, 0x2d85bcdc

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "30@1637L6"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {v3, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->endToMarker(I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_4f2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 53
    :cond_4f2
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_51c

    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v5, p4

    move/from16 v6, p6

    move/from16 v7, p7

    move-object/from16 v64, v3

    move-object/from16 v29, v22

    move-object/from16 v4, v23

    move-object/from16 v32, v24

    move-object/from16 v33, v25

    move-object/from16 v30, v26

    move/from16 v3, p2

    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v22    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v24    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v26    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v4, "openMedia":Lkotlin/jvm/functions/Function2;
    .local v29, "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v30, "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .local v32, "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v33, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda17;-><init>(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;II)V

    move-object v1, v0

    move-object v0, v2

    move-object v2, v5

    invoke-interface {v9, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_52c

    .end local v4    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v30    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v32    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v33    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v64    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v22    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v24    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v26    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_51c
    move-object/from16 v0, p1

    move-object/from16 v2, p4

    move-object/from16 v64, v3

    move-object/from16 v29, v22

    move-object/from16 v4, v23

    move-object/from16 v32, v24

    move-object/from16 v33, v25

    move-object/from16 v30, v26

    .line 31
    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v22    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v24    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v26    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v4    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v30    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v32    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v64    # "$composer\\21":Landroidx/compose/runtime/Composer;
    :goto_52c
    return-void

    .end local v4    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v30    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v32    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v33    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v64    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v22    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v24    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v26    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_52d
    move-object/from16 v0, p1

    move-object/from16 v2, p4

    move-object/from16 v29, v22

    move-object/from16 v4, v23

    move-object/from16 v32, v24

    move-object/from16 v33, v25

    move-object/from16 v30, v26

    .end local v22    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v24    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v25    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v26    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v4    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v30    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v32    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "$composer\\20":Landroidx/compose/runtime/Composer;
    const v6, 0x2d6cf3ab

    invoke-interface {v3, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 32
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v51, v6

    check-cast v51, Landroidx/compose/ui/Modifier;

    const/16 v54, 0x2

    const/16 v55, 0x0

    const/high16 v52, 0x3f800000    # 1.0f

    const/16 v53, 0x0

    invoke-static/range {v50 .. v55}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v61

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v6, v3, v6, v7}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v62

    const/16 v66, 0xe

    const/16 v67, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    invoke-static/range {v61 .. v67}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v7, 0x16

    .local v7, "$this$dp\\32":I
    const/4 v9, 0x0

    .line 169
    .local v9, "$i$f$getDp\\32\\32":I
    move-object/from16 v64, v3

    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v64    # "$composer\\21":Landroidx/compose/runtime/Composer;
    int-to-float v3, v7

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 32
    .end local v7    # "$this$dp\\32":I
    .end local v9    # "$i$f$getDp\\32\\32":I
    invoke-static {v6, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x14

    .local v7, "$this$dp\\33":I
    const/4 v9, 0x0

    .line 169
    .local v9, "$i$f$getDp\\33\\32":I
    move-object/from16 v22, v3

    int-to-float v3, v7

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 32
    .end local v7    # "$this$dp\\33":I
    .end local v9    # "$i$f$getDp\\33\\32":I
    invoke-virtual {v6, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v3, "verticalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x30

    .local v6, "$changed\\34":I
    move-object/from16 v7, v22

    .local v7, "modifier\\34":Landroidx/compose/ui/Modifier;
    move-object/from16 v9, v64

    .local v9, "$composer\\34":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 170
    .local v34, "$i$f$Column\\34\\32":I
    nop

    .end local v4    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    const v4, 0x4ff7456f

    move/from16 v35, v6

    .end local v6    # "$changed\\34":I
    .local v35, "$changed\\34":I
    const-string v6, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v9, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 171
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 174
    .local v4, "horizontalAlignment\\34":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v6, v35, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v22, v35, 0x3

    and-int/lit8 v22, v22, 0x70

    or-int v6, v6, v22

    invoke-static {v3, v4, v9, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 178
    .local v6, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v22, v35, 0x3

    and-int/lit8 v22, v22, 0x70

    .line 175
    move-object/from16 v36, v7

    .local v36, "modifier\\35":Landroidx/compose/ui/Modifier;
    move/from16 v51, v22

    .local v51, "$changed\\35":I
    const/16 v52, 0x0

    .line 179
    .local v52, "$i$f$Layout\\35\\175":I
    move-object/from16 v53, v3

    const v3, -0x451e1427

    .end local v3    # "verticalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v53, "verticalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v9, v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 180
    const/4 v3, 0x0

    invoke-static {v9, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v24

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->hashCode(J)I

    move-result v3

    .line 181
    .local v3, "compositeKeyHash\\35":I
    move/from16 v54, v3

    .end local v3    # "compositeKeyHash\\35":I
    .local v54, "compositeKeyHash\\35":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 182
    .local v3, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v55, v4

    move-object/from16 v4, v36

    .end local v7    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .local v4, "modifier\\35":Landroidx/compose/ui/Modifier;
    .local v36, "modifier\\34":Landroidx/compose/ui/Modifier;
    .local v55, "horizontalAlignment\\34":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v9, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 184
    .local v7, "materialized\\35":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    move-object/from16 v57, v4

    .end local v4    # "modifier\\35":Landroidx/compose/ui/Modifier;
    .local v57, "modifier\\35":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v51, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 183
    nop

    .local v4, "$changed\\36":I
    move-object/from16 v58, v22

    .local v58, "factory\\36":Lkotlin/jvm/functions/Function0;
    const/16 v59, 0x0

    .line 185
    .local v59, "$i$f$ReusableComposeNode\\36\\183":I
    move/from16 v61, v4

    const v4, -0x20f7d59c

    .end local v4    # "$changed\\36":I
    .local v61, "$changed\\36":I
    invoke-static {v9, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 186
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_600

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 187
    :cond_600
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 188
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_60f

    .line 189
    move-object/from16 v4, v58

    .end local v58    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_614

    .line 191
    .end local v4    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v58    # "factory\\36":Lkotlin/jvm/functions/Function0;
    :cond_60f
    move-object/from16 v4, v58

    .end local v58    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 193
    :goto_614
    move-object/from16 v58, v4

    .end local v4    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .restart local v58    # "factory\\36":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 194
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\193\\35":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v62, v9

    .end local v9    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v62, "$composer\\34":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v4, v6, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 195
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v4, v3, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 196
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .local v9, "block\\38":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 197
    .local v24, "$i$f$set-impl\\38\\196":I
    move-object/from16 v25, v4

    .local v25, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 198
    .local v26, "$i$a$-with-Updater$set$1\\39\\197\\38":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_658

    move-object/from16 v63, v3

    .end local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .local v63, "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v65, v6

    .end local v6    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v65, "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_655

    goto :goto_65c

    :cond_655
    move-object/from16 v6, v25

    goto :goto_66c

    .end local v63    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v65    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_658
    move-object/from16 v63, v3

    move-object/from16 v65, v6

    .line 199
    .end local v3    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v63    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v65    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_65c
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v6, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 200
    invoke-static/range {v54 .. v54}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v4, v3, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 202
    :goto_66c
    nop

    .line 197
    .end local v6    # "$this$set_impl_u24lambda_u240\\38":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\39\\197\\38":I
    nop

    .line 202
    nop

    .line 203
    .end local v9    # "block\\38":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\38\\196":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v7, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 204
    nop

    .line 193
    .end local v4    # "$this$Layout_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\37\\193\\35":I
    nop

    .line 205
    shr-int/lit8 v3, v61, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\40":I
    move-object/from16 v4, v62

    .local v4, "$composer\\40":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 176
    .local v6, "$i$a$-Layout-ColumnKt$Column$1\\40\\205\\34":I
    const v9, 0x7cc0ae6e

    move/from16 v66, v3

    .end local v3    # "$changed\\40":I
    .local v66, "$changed\\40":I
    const-string v3, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v35, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\41":I
    check-cast v3, Landroidx/compose/foundation/layout/ColumnScope;

    .local v3, "$this$CardEditorScreen_u24lambda_u246_u242\\41":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v74, v4

    .local v74, "$composer\\41":Landroidx/compose/runtime/Composer;
    const/16 v78, 0x0

    .line 33
    .local v78, "$i$a$-Column-CardEditorScreenKt$CardEditorScreen$3$3\\41\\176\\21":I
    move-object/from16 v79, v3

    .end local v3    # "$this$CardEditorScreen_u24lambda_u246_u242\\41":Landroidx/compose/foundation/layout/ColumnScope;
    .local v79, "$this$CardEditorScreen_u24lambda_u246_u242\\41":Landroidx/compose/foundation/layout/ColumnScope;
    const v3, -0x34226e43    # -2.904153E7f

    move-object/from16 v80, v4

    .end local v4    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .local v80, "$composer\\40":Landroidx/compose/runtime/Composer;
    const-string v4, "C:CardEditorScreen.kt#i35lj1"

    move/from16 v81, v6

    move-object/from16 v6, v74

    .end local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v6, "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v81, "$i$a$-Layout-ColumnKt$Column$1\\40\\205\\34":I
    invoke-static {v6, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getAnkiFieldNames()Ljava/util/List;

    move-result-object v3

    if-eqz v3, :cond_a2f

    const v3, -0x3422374a

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "33@1825L81,35@2108L295"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 34
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getLinkedCards()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 v82, v7

    .end local v7    # "materialized\\35":Landroidx/compose/ui/Modifier;
    .local v82, "materialized\\35":Landroidx/compose/ui/Modifier;
    const-string v7, "\u540c\u4e00\u7b14\u8bb0\u7684 "

    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " \u5f20\u5df2\u4fdd\u5b58\u5361\u7247\u4f1a\u8054\u52a8\u66f4\u65b0\u3002\u5b57\u6bb5\u542b HTML \u6216\u5a92\u4f53\u5f15\u7528\u65f6\u8bf7\u7f16\u8f91\u6e90\u7801\uff1b\u8fd9\u91cc\u4e0d\u4f1a\u81ea\u52a8\u8f6c\u6362\u6392\u7248\u3002"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v4, 0x2

    const/4 v7, 0x0

    invoke-static {v3, v7, v6, v7, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    const v3, 0x69ac5cb8

    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*34@2029L32,34@1963L138"

    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 35
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getAnkiFieldNames()Ljava/util/List;

    move-result-object v3

    check-cast v3, Ljava/lang/Iterable;

    .local v3, "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    const/4 v4, 0x0

    .line 206
    .local v4, "$i$f$forEachIndexed\\42\\35":I
    const/4 v7, 0x0

    .line 207
    .local v7, "index\\42":I
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v22

    :goto_6f5
    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->hasNext()Z

    move-result v24

    if-eqz v24, :cond_790

    invoke-interface/range {v22 .. v22}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v24

    .local v24, "item\\42":Ljava/lang/Object;
    add-int/lit8 v25, v7, 0x1

    .end local v7    # "index\\42":I
    .local v25, "index\\42":I
    if-gez v7, :cond_706

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_706
    move-object/from16 v67, v24

    check-cast v67, Ljava/lang/String;

    .local v7, "index\\43":I
    .local v67, "name\\43":Ljava/lang/String;
    const/16 v26, 0x0

    .line 35
    .local v26, "$i$a$-forEachIndexed-CardEditorScreenKt$CardEditorScreen$3$3$1\\43\\207\\41":I
    move-object/from16 p5, v3

    .end local v3    # "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    .local p5, "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getAnkiFields()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v69, v3

    check-cast v69, Ljava/lang/String;

    const v3, 0x369fb78e

    invoke-static {v6, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v27

    or-int v3, v3, v27

    .local v3, "invalid\\44":Z
    move-object/from16 v27, v6

    .local v27, "$this$cache\\44":Landroidx/compose/runtime/Composer;
    const/16 v68, 0x0

    .line 208
    .local v68, "$i$f$cache\\44\\35":I
    move/from16 v70, v3

    .end local v3    # "invalid\\44":Z
    .local v70, "invalid\\44":Z
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\44":Ljava/lang/Object;
    const/16 v71, 0x0

    .line 209
    .local v71, "$i$a$-let-ComposerKt$cache$1\\45\\208\\44":I
    if-nez v70, :cond_746

    sget-object v72, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v76, v4

    .end local v4    # "$i$f$forEachIndexed\\42\\35":I
    .local v76, "$i$f$forEachIndexed\\42\\35":I
    invoke-virtual/range {v72 .. v72}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v3, v4, :cond_743

    goto :goto_748

    .line 213
    :cond_743
    move-object/from16 v4, v27

    goto :goto_757

    .line 209
    .end local v76    # "$i$f$forEachIndexed\\42\\35":I
    .restart local v4    # "$i$f$forEachIndexed\\42\\35":I
    :cond_746
    move/from16 v76, v4

    .line 210
    .end local v4    # "$i$f$forEachIndexed\\42\\35":I
    .restart local v76    # "$i$f$forEachIndexed\\42\\35":I
    :goto_748
    const/4 v4, 0x0

    .line 35
    .local v4, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$1$1\\46\\210\\43":I
    move-object/from16 v72, v3

    .end local v3    # "it\\44":Ljava/lang/Object;
    .local v72, "it\\44":Ljava/lang/Object;
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda18;

    invoke-direct {v3, v0, v7}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda18;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;I)V

    .line 210
    .end local v4    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$1$1\\46\\210\\43":I
    nop

    .line 211
    .local v3, "value\\45":Ljava/lang/Object;
    move-object/from16 v4, v27

    .end local v27    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .local v4, "$this$cache\\44":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 212
    nop

    .line 208
    .end local v3    # "value\\45":Ljava/lang/Object;
    .end local v71    # "$i$a$-let-ComposerKt$cache$1\\45\\208\\44":I
    .end local v72    # "it\\44":Ljava/lang/Object;
    :goto_757
    nop

    .line 35
    .end local v4    # "$this$cache\\44":Landroidx/compose/runtime/Composer;
    .end local v68    # "$i$f$cache\\44\\35":I
    .end local v70    # "invalid\\44":Z
    move-object/from16 v70, v3

    check-cast v70, Lkotlin/jvm/functions/Function1;

    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "anki-field-"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v72

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    const/16 v18, 0x1

    xor-int/lit8 v73, v3, 0x1

    const/16 v75, 0x6030

    const-string v68, "\u4fdd\u7559\u539f HTML / [sound:\u6587\u4ef6\u540d]"

    const/16 v71, 0x0

    move-object/from16 v74, v6

    .end local v6    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v75}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V

    .line 207
    move-object/from16 v4, v74

    .end local v7    # "index\\43":I
    .end local v26    # "$i$a$-forEachIndexed-CardEditorScreenKt$CardEditorScreen$3$3$1\\43\\207\\41":I
    .end local v67    # "name\\43":Ljava/lang/String;
    .end local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\41":Landroidx/compose/runtime/Composer;
    move-object/from16 v3, p5

    move-object v6, v4

    move/from16 v7, v25

    move/from16 v4, v76

    .end local v24    # "item\\42":Ljava/lang/Object;
    goto/16 :goto_6f5

    .line 214
    .end local v25    # "index\\42":I
    .end local v76    # "$i$f$forEachIndexed\\42\\35":I
    .end local p5    # "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    .local v3, "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    .local v4, "$i$f$forEachIndexed\\42\\35":I
    .restart local v6    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v7, "index\\42":I
    :cond_790
    move-object/from16 p5, v3

    move/from16 v76, v4

    move-object v4, v6

    .end local v3    # "$this$forEachIndexed\\42":Ljava/lang/Iterable;
    .end local v6    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v7    # "index\\42":I
    .local v4, "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 36
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v6, 0x8

    .local v6, "$this$dp\\47":I
    const/4 v7, 0x0

    .line 215
    .local v7, "$i$f$getDp\\47\\36":I
    move/from16 p5, v7

    .end local v7    # "$i$f$getDp\\47\\36":I
    .local p5, "$i$f$getDp\\47\\36":I
    int-to-float v7, v6

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 36
    .end local v6    # "$this$dp\\47":I
    .end local p5    # "$i$f$getDp\\47\\36":I
    invoke-virtual {v3, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v3, "horizontalArrangement\\48":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v6, 0x30

    .local v6, "$changed\\48":I
    move-object v7, v4

    .local v7, "$composer\\48":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 216
    .local v22, "$i$f$Row\\48\\36":I
    move/from16 p5, v6

    .end local v6    # "$changed\\48":I
    .local p5, "$changed\\48":I
    const v6, 0x3255a44b

    move/from16 v83, v9

    .end local v9    # "$changed\\41":I
    .local v83, "$changed\\41":I
    const-string v9, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v7, v6, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 217
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 219
    .local v6, "modifier\\48":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v9

    .line 222
    .local v9, "verticalAlignment\\48":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v24, p5, 0x3

    and-int/lit8 v24, v24, 0xe

    shr-int/lit8 v25, p5, 0x3

    and-int/lit8 v25, v25, 0x70

    move-object/from16 v26, v6

    .end local v6    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .local v26, "modifier\\48":Landroidx/compose/ui/Modifier;
    or-int v6, v24, v25

    invoke-static {v3, v9, v7, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 226
    .local v6, "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v24, p5, 0x3

    and-int/lit8 v24, v24, 0x70

    .line 223
    move-object/from16 v25, v26

    .local v24, "$changed\\49":I
    .local v25, "modifier\\49":Landroidx/compose/ui/Modifier;
    const/16 v27, 0x0

    .line 227
    .local v27, "$i$f$Layout\\49\\223":I
    move-object/from16 v67, v3

    const v3, -0x451e1427

    .end local v3    # "horizontalArrangement\\48":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v67, "horizontalArrangement\\48":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 228
    const/4 v3, 0x0

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v68

    invoke-static/range {v68 .. v69}, Ljava/lang/Long;->hashCode(J)I

    move-result v3

    .line 229
    .local v3, "compositeKeyHash\\49":I
    move/from16 v68, v3

    .end local v3    # "compositeKeyHash\\49":I
    .local v68, "compositeKeyHash\\49":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 230
    .local v3, "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v69, v9

    move-object/from16 v84, v13

    move-object/from16 v9, v25

    .end local v13    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v25    # "modifier\\49":Landroidx/compose/ui/Modifier;
    .local v9, "modifier\\49":Landroidx/compose/ui/Modifier;
    .local v69, "verticalAlignment\\48":Landroidx/compose/ui/Alignment$Vertical;
    .local v84, "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v7, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 232
    .local v13, "materialized\\49":Landroidx/compose/ui/Modifier;
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v25

    move-object/from16 v70, v9

    .end local v9    # "modifier\\49":Landroidx/compose/ui/Modifier;
    .local v70, "modifier\\49":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v9, v24, 0x6

    and-int/lit16 v9, v9, 0x380

    or-int/lit8 v9, v9, 0x6

    .line 231
    move-object/from16 v71, v25

    .local v9, "$changed\\50":I
    .local v71, "factory\\50":Lkotlin/jvm/functions/Function0;
    const/16 v25, 0x0

    .line 233
    .local v25, "$i$f$ReusableComposeNode\\50\\231":I
    move/from16 v72, v9

    const v9, -0x20f7d59c

    .end local v9    # "$changed\\50":I
    .local v72, "$changed\\50":I
    invoke-static {v7, v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 234
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v9

    instance-of v9, v9, Landroidx/compose/runtime/Applier;

    if-nez v9, :cond_823

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 235
    :cond_823
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 236
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v9

    if-eqz v9, :cond_832

    .line 237
    move-object/from16 v9, v71

    .end local v71    # "factory\\50":Lkotlin/jvm/functions/Function0;
    .local v9, "factory\\50":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_837

    .line 239
    .end local v9    # "factory\\50":Lkotlin/jvm/functions/Function0;
    .restart local v71    # "factory\\50":Lkotlin/jvm/functions/Function0;
    :cond_832
    move-object/from16 v9, v71

    .end local v71    # "factory\\50":Lkotlin/jvm/functions/Function0;
    .restart local v9    # "factory\\50":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 241
    :goto_837
    move-object/from16 v71, v7

    .end local v7    # "$composer\\48":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\48":Landroidx/compose/runtime/Composer;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    const/16 v73, 0x0

    .line 242
    .local v73, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\51\\241\\49":I
    sget-object v74, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v75, v9

    .end local v9    # "factory\\50":Lkotlin/jvm/functions/Function0;
    .local v75, "factory\\50":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v74 .. v74}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v7, v6, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 243
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    invoke-static {v7, v3, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 244
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v9

    .local v9, "block\\52":Lkotlin/jvm/functions/Function2;
    const/16 v74, 0x0

    .line 245
    .local v74, "$i$f$set-impl\\52\\244":I
    move-object/from16 v76, v7

    .local v76, "$this$set_impl_u24lambda_u240\\52":Landroidx/compose/runtime/Composer;
    const/16 v77, 0x0

    .line 246
    .local v77, "$i$a$-with-Updater$set$1\\53\\245\\52":I
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v85

    if-nez v85, :cond_87b

    move-object/from16 v85, v3

    .end local v3    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    .local v85, "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v86, v6

    .end local v6    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v86, "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_878

    goto :goto_87f

    :cond_878
    move-object/from16 v6, v76

    goto :goto_88f

    .end local v85    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v86    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_87b
    move-object/from16 v85, v3

    move-object/from16 v86, v6

    .line 247
    .end local v3    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v85    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v86    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_87f
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v6, v76

    .end local v76    # "$this$set_impl_u24lambda_u240\\52":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\52":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 248
    invoke-static/range {v68 .. v68}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v7, v3, v9}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 250
    :goto_88f
    nop

    .line 245
    .end local v6    # "$this$set_impl_u24lambda_u240\\52":Landroidx/compose/runtime/Composer;
    .end local v77    # "$i$a$-with-Updater$set$1\\53\\245\\52":I
    nop

    .line 250
    nop

    .line 251
    .end local v9    # "block\\52":Lkotlin/jvm/functions/Function2;
    .end local v74    # "$i$f$set-impl\\52\\244":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v7, v13, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 252
    nop

    .line 241
    .end local v7    # "$this$Layout_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    .end local v73    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\51\\241\\49":I
    nop

    .line 253
    shr-int/lit8 v3, v72, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\54":I
    move-object/from16 v6, v71

    .local v6, "$composer\\54":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 224
    .local v7, "$i$a$-Layout-RowKt$Row$1\\54\\253\\48":I
    const v9, 0x56ccd6f5

    move/from16 v73, v3

    .end local v3    # "$changed\\54":I
    .local v73, "$changed\\54":I
    const-string v3, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v6, v9, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v9, p5, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v9, v9, 0x6

    .local v9, "$changed\\55":I
    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    .local v3, "$this$CardEditorScreen_u24lambda_u246_u242_u241\\55":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v97, v6

    .local v97, "$composer\\55":Landroidx/compose/runtime/Composer;
    const/16 v74, 0x0

    .line 37
    .local v74, "$i$a$-Row-CardEditorScreenKt$CardEditorScreen$3$3$2\\55\\224\\41":I
    move-object/from16 v76, v3

    .end local v3    # "$this$CardEditorScreen_u24lambda_u246_u242_u241\\55":Landroidx/compose/foundation/layout/RowScope;
    .local v76, "$this$CardEditorScreen_u24lambda_u246_u242_u241\\55":Landroidx/compose/foundation/layout/RowScope;
    const v3, -0x63daa46d

    move-object/from16 v77, v6

    .end local v6    # "$composer\\54":Landroidx/compose/runtime/Composer;
    .local v77, "$composer\\54":Landroidx/compose/runtime/Composer;
    const-string v6, "C36@2184L38,36@2169L112,37@2302L36,37@2287L110:CardEditorScreen.kt#i35lj1"

    move/from16 v100, v7

    move-object/from16 v7, v97

    .end local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\55":Landroidx/compose/runtime/Composer;
    .local v100, "$i$a$-Layout-RowKt$Row$1\\54\\253\\48":I
    invoke-static {v7, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v3, -0x3d070c6e

    invoke-static {v7, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\56":Z
    move-object v6, v7

    .local v6, "$this$cache\\56":Landroidx/compose/runtime/Composer;
    const/16 v87, 0x0

    .line 254
    .local v87, "$i$f$cache\\56\\37":I
    move/from16 v88, v3

    .end local v3    # "invalid\\56":Z
    .local v88, "invalid\\56":Z
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\56":Ljava/lang/Object;
    const/16 v89, 0x0

    .line 255
    .local v89, "$i$a$-let-ComposerKt$cache$1\\57\\254\\56":I
    if-nez v88, :cond_8ef

    sget-object v90, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v97, v7

    .end local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v90 .. v90}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_8ee

    goto :goto_8f1

    .line 259
    :cond_8ee
    goto :goto_8fe

    .line 255
    .end local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    :cond_8ef
    move-object/from16 v97, v7

    .line 256
    .end local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    :goto_8f1
    const/4 v7, 0x0

    .line 37
    .local v7, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$2$1\\58\\256\\55":I
    move-object/from16 v90, v3

    .end local v3    # "it\\56":Ljava/lang/Object;
    .local v90, "it\\56":Ljava/lang/Object;
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v3, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda1;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 256
    .end local v7    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$2$1\\58\\256\\55":I
    nop

    .line 257
    .local v3, "value\\57":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 258
    nop

    .line 254
    .end local v3    # "value\\57":Ljava/lang/Object;
    .end local v89    # "$i$a$-let-ComposerKt$cache$1\\57\\254\\56":I
    .end local v90    # "it\\56":Ljava/lang/Object;
    :goto_8fe
    nop

    .line 37
    .end local v6    # "$this$cache\\56":Landroidx/compose/runtime/Composer;
    .end local v87    # "$i$f$cache\\56\\37":I
    .end local v88    # "invalid\\56":Z
    move-object/from16 v87, v3

    check-cast v87, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v97 .. v97}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    if-nez v3, :cond_915

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getPreviewing()Z

    move-result v3

    if-nez v3, :cond_915

    const/16 v89, 0x1

    goto :goto_917

    :cond_915
    const/16 v89, 0x0

    :goto_917
    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$1652162462$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v96

    const/high16 v98, 0x30000000

    const/16 v99, 0x1fa

    const/16 v88, 0x0

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    invoke-static/range {v87 .. v99}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 38
    move-object/from16 v7, v97

    .end local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\55":Landroidx/compose/runtime/Composer;
    const v3, -0x3d06fdb0

    invoke-static {v7, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\59":Z
    move-object v6, v7

    .local v6, "$this$cache\\59":Landroidx/compose/runtime/Composer;
    const/16 v87, 0x0

    .line 260
    .local v87, "$i$f$cache\\59\\38":I
    move/from16 v88, v3

    .end local v3    # "invalid\\59":Z
    .local v88, "invalid\\59":Z
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\59":Ljava/lang/Object;
    const/16 v89, 0x0

    .line 261
    .local v89, "$i$a$-let-ComposerKt$cache$1\\60\\260\\59":I
    if-nez v88, :cond_957

    sget-object v90, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v97, v7

    .end local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v90 .. v90}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v3, v7, :cond_956

    goto :goto_959

    .line 265
    :cond_956
    goto :goto_966

    .line 261
    .end local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    :cond_957
    move-object/from16 v97, v7

    .line 262
    .end local v7    # "$composer\\55":Landroidx/compose/runtime/Composer;
    .restart local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    :goto_959
    const/4 v7, 0x0

    .line 38
    .local v7, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$2$2\\61\\262\\55":I
    move-object/from16 v90, v3

    .end local v3    # "it\\59":Ljava/lang/Object;
    .local v90, "it\\59":Ljava/lang/Object;
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v3, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda2;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 262
    .end local v7    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$2$2\\61\\262\\55":I
    nop

    .line 263
    .local v3, "value\\60":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 264
    nop

    .line 260
    .end local v3    # "value\\60":Ljava/lang/Object;
    .end local v89    # "$i$a$-let-ComposerKt$cache$1\\60\\260\\59":I
    .end local v90    # "it\\59":Ljava/lang/Object;
    :goto_966
    nop

    .line 38
    .end local v6    # "$this$cache\\59":Landroidx/compose/runtime/Composer;
    .end local v87    # "$i$f$cache\\59\\38":I
    .end local v88    # "invalid\\59":Z
    move-object/from16 v87, v3

    check-cast v87, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v97 .. v97}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    if-nez v3, :cond_97d

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getPreviewing()Z

    move-result v3

    if-nez v3, :cond_97d

    const/16 v89, 0x1

    goto :goto_97f

    :cond_97d
    const/16 v89, 0x0

    :goto_97f
    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$232184213$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v96

    const/high16 v98, 0x30000000

    const/16 v99, 0x1fa

    const/16 v88, 0x0

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v95, 0x0

    invoke-static/range {v87 .. v99}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 37
    invoke-static/range {v97 .. v97}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 39
    nop

    .line 224
    .end local v9    # "$changed\\55":I
    .end local v74    # "$i$a$-Row-CardEditorScreenKt$CardEditorScreen$3$3$2\\55\\224\\41":I
    .end local v76    # "$this$CardEditorScreen_u24lambda_u246_u242_u241\\55":Landroidx/compose/foundation/layout/RowScope;
    .end local v97    # "$composer\\55":Landroidx/compose/runtime/Composer;
    invoke-static/range {v77 .. v77}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 253
    .end local v73    # "$changed\\54":I
    .end local v77    # "$composer\\54":Landroidx/compose/runtime/Composer;
    .end local v100    # "$i$a$-Layout-RowKt$Row$1\\54\\253\\48":I
    nop

    .line 266
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 233
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 267
    nop

    .line 227
    .end local v25    # "$i$f$ReusableComposeNode\\50\\231":I
    .end local v72    # "$changed\\50":I
    .end local v75    # "factory\\50":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 268
    nop

    .line 216
    .end local v13    # "materialized\\49":Landroidx/compose/ui/Modifier;
    .end local v24    # "$changed\\49":I
    .end local v27    # "$i$f$Layout\\49\\223":I
    .end local v68    # "compositeKeyHash\\49":I
    .end local v70    # "modifier\\49":Landroidx/compose/ui/Modifier;
    .end local v85    # "localMap\\49":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 269
    nop

    .line 40
    .end local v22    # "$i$f$Row\\48\\36":I
    .end local v26    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .end local v67    # "horizontalArrangement\\48":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v69    # "verticalAlignment\\48":Landroidx/compose/ui/Alignment$Vertical;
    .end local v71    # "$composer\\48":Landroidx/compose/runtime/Composer;
    .end local v86    # "measurePolicy\\48":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p5    # "$changed\\48":I
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getPreviewing()Z

    move-result v3

    if-eqz v3, :cond_9d8

    const v3, 0x69ac9a28

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "39@2428L27"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v76, 0x0

    const/16 v77, 0x3f

    const/16 v67, 0x0

    const-wide/16 v68, 0x0

    const/16 v70, 0x0

    const-wide/16 v71, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    move-object/from16 v75, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v75, "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v77}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-4lLiAd8(Landroidx/compose/ui/Modifier;JFJIFLandroidx/compose/runtime/Composer;II)V

    .end local v75    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    goto :goto_9de

    :cond_9d8
    const v3, -0x343e1ccb    # -2.5413226E7f

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_9de
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 41
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getPreview()Lcom/xunji/flashcards/anki/RenderedCard;

    move-result-object v22

    if-nez v22, :cond_9f1

    const v3, -0x34189956

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_a2a

    :cond_9f1
    const v3, -0x34189955    # -3.0330198E7f

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "*40@2480L68"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 270
    .local v22, "it\\62":Lcom/xunji/flashcards/anki/RenderedCard;
    const/4 v3, 0x0

    .line 41
    .local v3, "$i$a$-let-CardEditorScreenKt$CardEditorScreen$3$3$3\\62\\41\\41":I
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v13, 0x1

    invoke-static {v6, v7, v13, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v7, 0x190

    .local v7, "$this$dp\\63":I
    const/4 v9, 0x0

    .line 271
    .local v9, "$i$f$getDp\\63\\41":I
    int-to-float v13, v7

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 41
    .end local v7    # "$this$dp\\63":I
    .end local v9    # "$i$f$getDp\\63\\41":I
    invoke-static {v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v24

    shr-int/lit8 v6, v40, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit16 v6, v6, 0x180

    const/16 v27, 0x0

    move-object/from16 v25, v4

    move/from16 v26, v6

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v27}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    .end local v3    # "$i$a$-let-CardEditorScreenKt$CardEditorScreen$3$3$3\\62\\41\\41":I
    .end local v22    # "it\\62":Lcom/xunji/flashcards/anki/RenderedCard;
    .end local v25    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 33
    :goto_a2a
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_b69

    .line 42
    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v82    # "materialized\\35":Landroidx/compose/ui/Modifier;
    .end local v83    # "$changed\\41":I
    .end local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v6, "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v7, "materialized\\35":Landroidx/compose/ui/Modifier;
    .local v9, "$changed\\41":I
    .local v13, "materialized\\15":Landroidx/compose/ui/Modifier;
    :cond_a2f
    move-object v4, v6

    move-object/from16 v82, v7

    move/from16 v83, v9

    move-object/from16 v84, v13

    .end local v6    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v7    # "materialized\\35":Landroidx/compose/ui/Modifier;
    .end local v9    # "$changed\\41":I
    .end local v13    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v82    # "materialized\\35":Landroidx/compose/ui/Modifier;
    .restart local v83    # "$changed\\41":I
    .restart local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    const v3, -0x3417222f    # -3.0522274E7f

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "42@2565L26,43@2647L30,43@2595L134,44@2786L29,44@2733L132,45@2919L32,45@2869L138"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 43
    const-string v3, "\u8ba9\u95ee\u9898\u7b80\u5355\u4e00\u70b9\uff0c\u8ba9\u7b54\u6848\u6e05\u695a\u4e00\u70b9\u3002"

    move/from16 v7, v44

    const/4 v6, 0x2

    const/4 v13, 0x0

    invoke-static {v3, v13, v4, v7, v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 44
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getFront()Ljava/lang/String;

    move-result-object v69

    const v3, 0x69acb58b

    invoke-static {v4, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\64":Z
    move-object v6, v4

    .local v6, "$this$cache\\64":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 272
    .local v7, "$i$f$cache\\64\\44":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\64":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 273
    .local v13, "$i$a$-let-ComposerKt$cache$1\\65\\272\\64":I
    if-nez v3, :cond_a6d

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p3, v3

    .end local v3    # "invalid\\64":Z
    .local p3, "invalid\\64":Z
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v9, v3, :cond_a6c

    goto :goto_a6f

    .line 277
    :cond_a6c
    goto :goto_a7c

    .line 273
    .end local p3    # "invalid\\64":Z
    .restart local v3    # "invalid\\64":Z
    :cond_a6d
    move/from16 p3, v3

    .line 274
    .end local v3    # "invalid\\64":Z
    .restart local p3    # "invalid\\64":Z
    :goto_a6f
    const/4 v3, 0x0

    .line 44
    .local v3, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$4\\66\\274\\41":I
    move/from16 p5, v3

    .end local v3    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$4\\66\\274\\41":I
    .local p5, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$4\\66\\274\\41":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v3, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda3;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 274
    .end local p5    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$4\\66\\274\\41":I
    nop

    .line 275
    .local v3, "value\\65":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 276
    move-object v9, v3

    .line 272
    .end local v3    # "value\\65":Ljava/lang/Object;
    .end local v9    # "it\\64":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\65\\272\\64":I
    :goto_a7c
    nop

    .line 44
    .end local v6    # "$this$cache\\64":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\64\\44":I
    .end local p3    # "invalid\\64":Z
    move-object/from16 v70, v9

    check-cast v70, Lkotlin/jvm/functions/Function1;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getErrors()Ljava/util/Map;

    move-result-object v3

    const-string v6, "front"

    invoke-interface {v3, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v71, v3

    check-cast v71, Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    const/16 v18, 0x1

    xor-int/lit8 v73, v3, 0x1

    const v75, 0x30036

    const-string v67, "\u6b63\u9762 \u00b7 \u95ee\u9898\u6216\u8bcd\u6c47"

    const-string v68, "\u4f8b\u5982\uff1aresilient"

    const-string v72, "editor-front"

    move-object/from16 v74, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .local v74, "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v75}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V

    .line 45
    .end local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getBack()Ljava/lang/String;

    move-result-object v69

    const v3, 0x69acc6ea

    invoke-static {v4, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\67":Z
    move-object v6, v4

    .local v6, "$this$cache\\67":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 278
    .local v7, "$i$f$cache\\67\\45":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\67":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 279
    .local v13, "$i$a$-let-ComposerKt$cache$1\\68\\278\\67":I
    if-nez v3, :cond_acb

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p3, v3

    .end local v3    # "invalid\\67":Z
    .local p3, "invalid\\67":Z
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v9, v3, :cond_aca

    goto :goto_acd

    .line 283
    :cond_aca
    goto :goto_ada

    .line 279
    .end local p3    # "invalid\\67":Z
    .restart local v3    # "invalid\\67":Z
    :cond_acb
    move/from16 p3, v3

    .line 280
    .end local v3    # "invalid\\67":Z
    .restart local p3    # "invalid\\67":Z
    :goto_acd
    const/4 v3, 0x0

    .line 45
    .local v3, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$5\\69\\280\\41":I
    move/from16 p5, v3

    .end local v3    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$5\\69\\280\\41":I
    .local p5, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$5\\69\\280\\41":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v3, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 280
    .end local p5    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$5\\69\\280\\41":I
    nop

    .line 281
    .local v3, "value\\68":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 282
    move-object v9, v3

    .line 278
    .end local v3    # "value\\68":Ljava/lang/Object;
    .end local v9    # "it\\67":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\68\\278\\67":I
    :goto_ada
    nop

    .line 45
    .end local v6    # "$this$cache\\67":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\67\\45":I
    .end local p3    # "invalid\\67":Z
    move-object/from16 v70, v9

    check-cast v70, Lkotlin/jvm/functions/Function1;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getErrors()Ljava/util/Map;

    move-result-object v3

    const-string v6, "back"

    invoke-interface {v3, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v71, v3

    check-cast v71, Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    const/16 v18, 0x1

    xor-int/lit8 v73, v3, 0x1

    const v75, 0x30036

    const-string v67, "\u80cc\u9762 \u00b7 \u7b54\u6848\u6216\u91ca\u4e49"

    const-string v68, "\u4f8b\u5982\uff1a\u6709\u97e7\u6027\u7684\uff1b\u80fd\u8fc5\u901f\u6062\u590d\u7684"

    const-string v72, "editor-back"

    move-object/from16 v74, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v75}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V

    .line 46
    .end local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getExample()Ljava/lang/String;

    move-result-object v69

    const v3, 0x69acd78d

    invoke-static {v4, v3, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    .local v3, "invalid\\70":Z
    move-object v6, v4

    .local v6, "$this$cache\\70":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 284
    .local v7, "$i$f$cache\\70\\46":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\70":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 285
    .local v13, "$i$a$-let-ComposerKt$cache$1\\71\\284\\70":I
    if-nez v3, :cond_b29

    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 p3, v3

    .end local v3    # "invalid\\70":Z
    .local p3, "invalid\\70":Z
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v9, v3, :cond_b28

    goto :goto_b2b

    .line 289
    :cond_b28
    goto :goto_b38

    .line 285
    .end local p3    # "invalid\\70":Z
    .restart local v3    # "invalid\\70":Z
    :cond_b29
    move/from16 p3, v3

    .line 286
    .end local v3    # "invalid\\70":Z
    .restart local p3    # "invalid\\70":Z
    :goto_b2b
    const/4 v3, 0x0

    .line 46
    .local v3, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$6\\72\\286\\41":I
    move/from16 p5, v3

    .end local v3    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$6\\72\\286\\41":I
    .local p5, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$6\\72\\286\\41":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v3, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda5;-><init>(Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 286
    .end local p5    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$3$6\\72\\286\\41":I
    nop

    .line 287
    .local v3, "value\\71":Ljava/lang/Object;
    invoke-interface {v6, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 288
    move-object v9, v3

    .line 284
    .end local v3    # "value\\71":Ljava/lang/Object;
    .end local v9    # "it\\70":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\71\\284\\70":I
    :goto_b38
    nop

    .line 46
    .end local v6    # "$this$cache\\70":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$cache\\70\\46":I
    .end local p3    # "invalid\\70":Z
    move-object/from16 v70, v9

    check-cast v70, Lkotlin/jvm/functions/Function1;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getErrors()Ljava/util/Map;

    move-result-object v3

    const-string v6, "example"

    invoke-interface {v3, v6}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v71, v3

    check-cast v71, Ljava/lang/String;

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v3

    const/16 v18, 0x1

    xor-int/lit8 v73, v3, 0x1

    const v75, 0x30036

    const-string v67, "\u4f8b\u53e5 \u00b7 \u53ef\u9009"

    const-string v68, "\u7ed9\u8fd9\u4e2a\u77e5\u8bc6\u70b9\u4e00\u4e2a\u4e0a\u4e0b\u6587"

    const-string v72, "editor-example"

    move-object/from16 v74, v4

    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-static/range {v67 .. v75}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V

    .line 42
    .end local v74    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 48
    :goto_b69
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getError()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_b86

    const v3, 0x69ace645

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "47@3037L24"

    invoke-static {v4, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getError()Ljava/lang/String;

    move-result-object v3

    const/16 v6, 0x30

    const/4 v7, 0x1

    const/4 v13, 0x0

    invoke-static {v3, v7, v4, v6, v13}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_b8c

    :cond_b86
    const v3, -0x343e1ccb    # -2.5413226E7f

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_b8c
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 33
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 49
    nop

    .line 176
    .end local v4    # "$composer\\41":Landroidx/compose/runtime/Composer;
    .end local v78    # "$i$a$-Column-CardEditorScreenKt$CardEditorScreen$3$3\\41\\176\\21":I
    .end local v79    # "$this$CardEditorScreen_u24lambda_u246_u242\\41":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v83    # "$changed\\41":I
    invoke-static/range {v80 .. v80}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 205
    .end local v66    # "$changed\\40":I
    .end local v80    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .end local v81    # "$i$a$-Layout-ColumnKt$Column$1\\40\\205\\34":I
    nop

    .line 290
    invoke-interface/range {v62 .. v62}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 185
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 291
    nop

    .line 179
    .end local v58    # "factory\\36":Lkotlin/jvm/functions/Function0;
    .end local v59    # "$i$f$ReusableComposeNode\\36\\183":I
    .end local v61    # "$changed\\36":I
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 292
    nop

    .line 170
    .end local v51    # "$changed\\35":I
    .end local v52    # "$i$f$Layout\\35\\175":I
    .end local v54    # "compositeKeyHash\\35":I
    .end local v57    # "modifier\\35":Landroidx/compose/ui/Modifier;
    .end local v63    # "localMap\\35":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v82    # "materialized\\35":Landroidx/compose/ui/Modifier;
    invoke-static/range {v62 .. v62}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 293
    nop

    .line 50
    .end local v34    # "$i$f$Column\\34\\32":I
    .end local v35    # "$changed\\34":I
    .end local v36    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .end local v53    # "verticalArrangement\\34":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v55    # "horizontalAlignment\\34":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .end local v65    # "measurePolicy\\34":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x16

    .local v4, "$this$dp\\73":I
    const/4 v6, 0x0

    .line 294
    .local v6, "$i$f$getDp\\73\\50":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 50
    .end local v4    # "$this$dp\\73":I
    .end local v6    # "$i$f$getDp\\73\\50":I
    const/16 v6, 0xc

    .local v6, "$this$dp\\74":I
    const/4 v7, 0x0

    .line 294
    .local v7, "$i$f$getDp\\74\\50":I
    int-to-float v9, v6

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 50
    .end local v6    # "$this$dp\\74":I
    .end local v7    # "$i$f$getDp\\74\\50":I
    const/16 v7, 0x16

    .local v7, "$this$dp\\75":I
    const/4 v9, 0x0

    .line 294
    .local v9, "$i$f$getDp\\75\\50":I
    int-to-float v13, v7

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 50
    .end local v7    # "$this$dp\\75":I
    .end local v9    # "$i$f$getDp\\75\\50":I
    const/16 v9, 0x14

    .local v9, "$this$dp\\76":I
    const/4 v13, 0x0

    .line 294
    .local v13, "$i$f$getDp\\76\\50":I
    move/from16 p3, v13

    .end local v13    # "$i$f$getDp\\76\\50":I
    .local p3, "$i$f$getDp\\76\\50":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 50
    .end local v9    # "$this$dp\\76":I
    .end local p3    # "$i$f$getDp\\76\\50":I
    invoke-static {v3, v4, v6, v7, v9}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\77":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x6

    .local v4, "$changed\\77":I
    move-object/from16 v6, v64

    .local v6, "$composer\\77":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 295
    .local v7, "$i$f$Box\\77\\50":I
    const v9, 0x3e277f0a

    const-string v13, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v6, v9, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 296
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v9

    .line 297
    .local v9, "contentAlignment\\77":Landroidx/compose/ui/Alignment;
    const/4 v13, 0x0

    .line 300
    .local v13, "propagateMinConstraints\\77":Z
    move-object/from16 p3, v3

    .end local v3    # "modifier\\77":Landroidx/compose/ui/Modifier;
    .local p3, "modifier\\77":Landroidx/compose/ui/Modifier;
    invoke-static {v9, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .line 304
    .local v3, "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v19, v4, 0x3

    and-int/lit8 v19, v19, 0x70

    .line 301
    move-object/from16 p5, p3

    .local v19, "$changed\\78":I
    .local p5, "modifier\\78":Landroidx/compose/ui/Modifier;
    const/16 v22, 0x0

    .line 305
    .local v22, "$i$f$Layout\\78\\301":I
    move/from16 v24, v4

    const v4, -0x451e1427

    .end local v4    # "$changed\\77":I
    .local v24, "$changed\\77":I
    invoke-static {v6, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 306
    const/4 v1, 0x0

    invoke-static {v6, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v25

    invoke-static/range {v25 .. v26}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 307
    .local v4, "compositeKeyHash\\78":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 308
    .local v1, "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v25, v4

    move-object/from16 v4, p5

    move/from16 p5, v7

    .end local v7    # "$i$f$Box\\77\\50":I
    .local v4, "modifier\\78":Landroidx/compose/ui/Modifier;
    .local v25, "compositeKeyHash\\78":I
    .local p5, "$i$f$Box\\77\\50":I
    invoke-static {v6, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 310
    .local v7, "materialized\\78":Landroidx/compose/ui/Modifier;
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v26

    move-object/from16 v27, v4

    .end local v4    # "modifier\\78":Landroidx/compose/ui/Modifier;
    .local v27, "modifier\\78":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v19, 0x6

    and-int/lit16 v4, v4, 0x380

    const/16 v44, 0x6

    or-int/lit8 v4, v4, 0x6

    .line 309
    nop

    .local v4, "$changed\\79":I
    move-object/from16 v28, v26

    .local v28, "factory\\79":Lkotlin/jvm/functions/Function0;
    const/16 v26, 0x0

    .line 311
    .local v26, "$i$f$ReusableComposeNode\\79\\309":I
    move/from16 v34, v4

    const v4, -0x20f7d59c

    .end local v4    # "$changed\\79":I
    .local v34, "$changed\\79":I
    invoke-static {v6, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 312
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_c38

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 313
    :cond_c38
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 314
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_c47

    .line 315
    move-object/from16 v4, v28

    .end local v28    # "factory\\79":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\79":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c4c

    .line 317
    .end local v4    # "factory\\79":Lkotlin/jvm/functions/Function0;
    .restart local v28    # "factory\\79":Lkotlin/jvm/functions/Function0;
    :cond_c47
    move-object/from16 v4, v28

    .end local v28    # "factory\\79":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\79":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 319
    :goto_c4c
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\80":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 320
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\80\\319\\78":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v36, v4

    .end local v4    # "factory\\79":Lkotlin/jvm/functions/Function0;
    .local v36, "factory\\79":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v5, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 321
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v5, v1, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 322
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\81":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 323
    .local v35, "$i$f$set-impl\\81\\322":I
    move-object/from16 v38, v5

    .local v38, "$this$set_impl_u24lambda_u240\\81":Landroidx/compose/runtime/Composer;
    const/16 v45, 0x0

    .line 324
    .local v45, "$i$a$-with-Updater$set$1\\82\\323\\81":I
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v51

    if-nez v51, :cond_c8e

    move-object/from16 v51, v1

    .end local v1    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    .local v51, "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v52, v3

    .end local v3    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v52, "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_c8b

    goto :goto_c92

    :cond_c8b
    move-object/from16 v3, v38

    goto :goto_ca2

    .end local v51    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_c8e
    move-object/from16 v51, v1

    move-object/from16 v52, v3

    .line 325
    .end local v1    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v51    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v52    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_c92
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v3, v38

    .end local v38    # "$this$set_impl_u24lambda_u240\\81":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\81":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 326
    invoke-static/range {v25 .. v25}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v5, v1, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 328
    :goto_ca2
    nop

    .line 323
    .end local v3    # "$this$set_impl_u24lambda_u240\\81":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-with-Updater$set$1\\82\\323\\81":I
    nop

    .line 328
    nop

    .line 329
    .end local v4    # "block\\81":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\81\\322":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v5, v7, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 330
    nop

    .line 319
    .end local v5    # "$this$Layout_u24lambda_u240\\80":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\80\\319\\78":I
    nop

    .line 331
    shr-int/lit8 v1, v34, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\83":I
    move-object v3, v6

    .local v3, "$composer\\83":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 302
    .local v4, "$i$a$-Layout-BoxKt$Box$1\\83\\331\\77":I
    const v5, 0x6d423196

    move/from16 v28, v1

    .end local v1    # "$changed\\83":I
    .local v28, "$changed\\83":I
    const-string v1, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, v24, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v44, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\84":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    .local v1, "$this$CardEditorScreen_u24lambda_u246_u243\\84":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v70, v3

    .local v70, "$composer\\84":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 50
    .local v35, "$i$a$-Box-CardEditorScreenKt$CardEditorScreen$3$4\\84\\302\\21":I
    move-object/from16 v38, v1

    .end local v1    # "$this$CardEditorScreen_u24lambda_u246_u243\\84":Landroidx/compose/foundation/layout/BoxScope;
    .local v38, "$this$CardEditorScreen_u24lambda_u246_u243\\84":Landroidx/compose/foundation/layout/BoxScope;
    const v1, -0x1565c2a

    move-object/from16 v44, v3

    .end local v3    # "$composer\\83":Landroidx/compose/runtime/Composer;
    .local v44, "$composer\\83":Landroidx/compose/runtime/Composer;
    const-string v3, "C49@3167L37,49@3117L144:CardEditorScreen.kt#i35lj1"

    move/from16 v45, v4

    move-object/from16 v4, v70

    .end local v70    # "$composer\\84":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\84":Landroidx/compose/runtime/Composer;
    .local v45, "$i$a$-Layout-BoxKt$Box$1\\83\\331\\77":I
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v1

    if-eqz v1, :cond_ce9

    const-string v1, "\u6b63\u5728\u4fdd\u5b58\u2026"

    goto :goto_ceb

    :cond_ce9
    const-string v1, "\u4fdd\u5b58\u5361\u7247"

    :goto_ceb
    move-object/from16 v65, v1

    const v1, 0x10791ba2

    invoke-static {v4, v1, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .local v1, "invalid\\85":Z
    move-object v3, v4

    .local v3, "$this$cache\\85":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 332
    .local v53, "$i$f$cache\\85\\50":I
    move/from16 v54, v1

    .end local v1    # "invalid\\85":Z
    .local v54, "invalid\\85":Z
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\85":Ljava/lang/Object;
    const/16 v55, 0x0

    .line 333
    .local v55, "$i$a$-let-ComposerKt$cache$1\\86\\332\\85":I
    if-nez v54, :cond_d15

    sget-object v57, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v70, v4

    .end local v4    # "$composer\\84":Landroidx/compose/runtime/Composer;
    .restart local v70    # "$composer\\84":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v57 .. v57}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v1, v4, :cond_d14

    goto :goto_d17

    .line 337
    :cond_d14
    goto :goto_d24

    .line 333
    .end local v70    # "$composer\\84":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\84":Landroidx/compose/runtime/Composer;
    :cond_d15
    move-object/from16 v70, v4

    .line 334
    .end local v4    # "$composer\\84":Landroidx/compose/runtime/Composer;
    .restart local v70    # "$composer\\84":Landroidx/compose/runtime/Composer;
    :goto_d17
    const/4 v4, 0x0

    .line 50
    .local v4, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$4$1\\87\\334\\84":I
    move-object/from16 v57, v1

    .end local v1    # "it\\85":Ljava/lang/Object;
    .local v57, "it\\85":Ljava/lang/Object;
    new-instance v1, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v1, v11, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)V

    .line 334
    .end local v4    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$3$4$1\\87\\334\\84":I
    nop

    .line 335
    .local v1, "value\\86":Ljava/lang/Object;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 336
    nop

    .line 332
    .end local v1    # "value\\86":Ljava/lang/Object;
    .end local v55    # "$i$a$-let-ComposerKt$cache$1\\86\\332\\85":I
    .end local v57    # "it\\85":Ljava/lang/Object;
    :goto_d24
    nop

    .line 50
    .end local v3    # "$this$cache\\85":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$f$cache\\85\\50":I
    .end local v54    # "invalid\\85":Z
    move-object/from16 v66, v1

    check-cast v66, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v1

    if-nez v1, :cond_d3b

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getLoading()Z

    move-result v1

    if-nez v1, :cond_d3b

    const/16 v68, 0x1

    goto :goto_d3d

    :cond_d3b
    const/16 v68, 0x0

    :goto_d3d
    const/16 v71, 0x6000

    const/16 v72, 0x4

    const/16 v67, 0x0

    const-string v69, "save-card"

    invoke-static/range {v65 .. v72}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 302
    .end local v5    # "$changed\\84":I
    .end local v35    # "$i$a$-Box-CardEditorScreenKt$CardEditorScreen$3$4\\84\\302\\21":I
    .end local v38    # "$this$CardEditorScreen_u24lambda_u246_u243\\84":Landroidx/compose/foundation/layout/BoxScope;
    .end local v70    # "$composer\\84":Landroidx/compose/runtime/Composer;
    invoke-static/range {v44 .. v44}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 331
    .end local v28    # "$changed\\83":I
    .end local v44    # "$composer\\83":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-Layout-BoxKt$Box$1\\83\\331\\77":I
    nop

    .line 338
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 311
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 339
    nop

    .line 305
    .end local v26    # "$i$f$ReusableComposeNode\\79\\309":I
    .end local v34    # "$changed\\79":I
    .end local v36    # "factory\\79":Lkotlin/jvm/functions/Function0;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 340
    nop

    .line 295
    .end local v7    # "materialized\\78":Landroidx/compose/ui/Modifier;
    .end local v19    # "$changed\\78":I
    .end local v22    # "$i$f$Layout\\78\\301":I
    .end local v25    # "compositeKeyHash\\78":I
    .end local v27    # "modifier\\78":Landroidx/compose/ui/Modifier;
    .end local v51    # "localMap\\78":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 341
    nop

    .end local v6    # "$composer\\77":Landroidx/compose/runtime/Composer;
    .end local v9    # "contentAlignment\\77":Landroidx/compose/ui/Alignment;
    .end local v13    # "propagateMinConstraints\\77":Z
    .end local v24    # "$changed\\77":I
    .end local v52    # "measurePolicy\\77":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local p3    # "modifier\\77":Landroidx/compose/ui/Modifier;
    .end local p5    # "$i$f$Box\\77\\50":I
    invoke-interface/range {v64 .. v64}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 51
    nop

    .line 97
    .end local v49    # "$changed\\21":I
    .end local v50    # "$this$CardEditorScreen_u24lambda_u246\\21":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v56    # "$i$a$-Column-CardEditorScreenKt$CardEditorScreen$3\\21\\97\\0":I
    .end local v64    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 126
    .end local v33    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v47    # "$changed\\20":I
    .end local v48    # "$i$a$-Layout-ColumnKt$Column$1\\20\\126\\14":I
    nop

    .line 342
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 106
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 343
    nop

    .line 100
    .end local v32    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v42    # "$changed\\16":I
    .end local v43    # "$i$f$ReusableComposeNode\\16\\104":I
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 344
    nop

    .line 90
    .end local v17    # "$changed\\15":I
    .end local v37    # "$i$f$Layout\\15\\96":I
    .end local v39    # "compositeKeyHash\\15":I
    .end local v41    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v60    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 345
    nop

    .line 52
    .end local v14    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v15    # "$changed\\14":I
    .end local v16    # "$i$f$Column\\14\\29":I
    .end local v21    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v29    # "verticalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v30    # "horizontalAlignment\\14":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v46    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {v12}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$2(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    if-eqz v1, :cond_e10

    const v1, 0x7e5c6feb

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "51@3308L15,51@3393L91,51@3499L45,51@3279L266"

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v1, 0x7e5c7290

    invoke-static {v8, v1, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v8, v12}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\88":Z
    move-object v3, v8

    .local v3, "$this$cache\\88":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 346
    .local v4, "$i$f$cache\\88\\52":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\88":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 347
    .local v6, "$i$a$-let-ComposerKt$cache$1\\89\\346\\88":I
    if-nez v1, :cond_da3

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_da2

    goto :goto_da3

    .line 351
    :cond_da2
    goto :goto_dae

    .line 348
    :cond_da3
    :goto_da3
    const/4 v7, 0x0

    .line 52
    .local v7, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$4\\90\\348\\0":I
    new-instance v9, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda12;

    invoke-direct {v9, v12}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 348
    .end local v7    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$4\\90\\348\\0":I
    nop

    .line 349
    .local v9, "value\\89":Ljava/lang/Object;
    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 350
    move-object v5, v9

    .line 346
    .end local v5    # "it\\88":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\89\\346\\88":I
    .end local v9    # "value\\89":Ljava/lang/Object;
    :goto_dae
    nop

    .line 52
    .end local v1    # "invalid\\88":Z
    .end local v3    # "$this$cache\\88":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\88\\52":I
    move-object v1, v5

    check-cast v1, Lkotlin/jvm/functions/Function0;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v3, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v3, v12, v2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda13;-><init>(Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;)V

    const/16 v4, 0x36

    const v5, -0x566687ec

    const/4 v7, 0x1

    invoke-static {v5, v7, v3, v8, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    new-instance v4, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v4, v12}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda14;-><init>(Landroidx/compose/runtime/MutableState;)V

    const/16 v5, 0x36

    const v6, -0x3a3f332e

    invoke-static {v6, v7, v4, v8, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function2;

    sget-object v5, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v5}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$-504880752$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v6

    sget-object v5, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v5}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$-268710929$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    const/16 v21, 0x0

    const/16 v22, 0x3f94

    move-object v2, v3

    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object/from16 v19, v8

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    move-object v13, v11

    move-object v14, v12

    .end local v11    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .end local v12    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .local v13, "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v14, "discard$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v11, 0x0

    move-object v15, v13

    move-object/from16 v16, v14

    .end local v13    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .end local v14    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .local v15, "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v16, "discard$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v13, 0x0

    move-object/from16 v17, v15

    move-object/from16 v18, v16

    .end local v15    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .end local v16    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .local v17, "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v18, "discard$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v15, 0x0

    move-object/from16 v20, v17

    .end local v17    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v20, "focus":Landroidx/compose/ui/focus/FocusManager;
    const/16 v17, 0x0

    move-object/from16 v24, v18

    .end local v18    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .local v24, "discard$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v18, 0x0

    move-object/from16 v25, v20

    .end local v20    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v25, "focus":Landroidx/compose/ui/focus/FocusManager;
    const v20, 0x1b0c30

    invoke-static/range {v1 .. v22}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v12, v19

    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_e1b

    .end local v24    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .end local v25    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .restart local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v11    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v12, "discard$delegate":Landroidx/compose/runtime/MutableState;
    :cond_e10
    move-object/from16 v25, v11

    move-object/from16 v24, v12

    move-object v12, v8

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v11    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    .restart local v24    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v25    # "focus":Landroidx/compose/ui/focus/FocusManager;
    const v1, 0x4cffc741    # 1.3410151E8f

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_e1b
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_e27

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 53
    .end local v24    # "discard$delegate":Landroidx/compose/runtime/MutableState;
    .end local v25    # "focus":Landroidx/compose/ui/focus/FocusManager;
    .end local v31    # "requestExit":Lkotlin/jvm/functions/Function0;
    :cond_e27
    move-object/from16 v4, v23

    goto :goto_e32

    .line 23
    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v23    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v40    # "$dirty":I
    .local v7, "$dirty":I
    .restart local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .local p3, "openMedia":Lkotlin/jvm/functions/Function2;
    :cond_e2a
    move-object v0, v2

    move-object v12, v8

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v40, v7

    move-object v4, v9

    .line 53
    .end local v7    # "$dirty":I
    .end local p3    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v4, "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v40    # "$dirty":I
    :goto_e32
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_e4c

    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda15;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v3, p2

    move-object/from16 v5, p4

    move/from16 v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda15;-><init>(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_e4c
    return-void
.end method

.method private static final CardEditorScreen$lambda$1$0()Landroidx/compose/runtime/MutableState;
    .registers 3

    .line 25
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$10(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move v8, p6

    move-object/from16 v6, p7

    invoke-static/range {v1 .. v8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$2(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 25
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 409
    .local v3, "$i$f$getValue\\1\\25":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\25":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 25
    return v0
.end method

.method private static final CardEditorScreen$lambda$3(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 25
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 410
    .local v4, "$i$f$setValue\\1\\25":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 411
    nop

    .line 25
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\25":I
    return-void
.end method

.method private static final CardEditorScreen$lambda$4$0(Lcom/xunji/flashcards/ui/EditorUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 4
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/EditorUiState;
    .param p1, "$onExit"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 26
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getSaving()Z

    move-result v0

    if-nez v0, :cond_14

    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/EditorUiState;->getDirty()Z

    move-result v0

    if-eqz v0, :cond_11

    const/4 v0, 0x1

    invoke-static {p2, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$3(Landroidx/compose/runtime/MutableState;Z)V

    goto :goto_14

    :cond_11
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    :cond_14
    :goto_14
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$1(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move v3, p2

    move-object v4, p3

    move-object v5, p4

    move v8, p6

    move-object/from16 v6, p7

    invoke-static/range {v1 .. v8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen(Lcom/xunji/flashcards/ui/EditorUiState;Lcom/xunji/flashcards/ui/EditorViewModel;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$0$0$0(Lcom/xunji/flashcards/ui/EditorViewModel;ILjava/lang/String;)Lkotlin/Unit;
    .registers 4
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;
    .param p1, "$index"    # I
    .param p2, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/EditorViewModel;->updateAnki(ILjava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$1$0$0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 2
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;

    .line 37
    sget-object v0, Lcom/xunji/core/anki/CardSide;->QUESTION:Lcom/xunji/core/anki/CardSide;

    invoke-virtual {p0, v0}, Lcom/xunji/flashcards/ui/EditorViewModel;->preview(Lcom/xunji/core/anki/CardSide;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$1$1$0(Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 2
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;

    .line 38
    sget-object v0, Lcom/xunji/core/anki/CardSide;->ANSWER:Lcom/xunji/core/anki/CardSide;

    invoke-virtual {p0, v0}, Lcom/xunji/flashcards/ui/EditorViewModel;->preview(Lcom/xunji/core/anki/CardSide;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$3$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 44
    const-string v0, "front"

    invoke-virtual {p0, v0, p1}, Lcom/xunji/flashcards/ui/EditorViewModel;->update(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$4$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    const-string v0, "back"

    invoke-virtual {p0, v0, p1}, Lcom/xunji/flashcards/ui/EditorViewModel;->update(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$2$5$0(Lcom/xunji/flashcards/ui/EditorViewModel;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    const-string v0, "example"

    invoke-virtual {p0, v0, p1}, Lcom/xunji/flashcards/ui/EditorViewModel;->update(Ljava/lang/String;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$6$3$0$0(Landroidx/compose/ui/focus/FocusManager;Lcom/xunji/flashcards/ui/EditorViewModel;)Lkotlin/Unit;
    .registers 5
    .param p0, "$focus"    # Landroidx/compose/ui/focus/FocusManager;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/EditorViewModel;

    .line 50
    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p0, v2, v0, v1}, Landroidx/compose/ui/focus/FocusManager;->clearFocus$default(Landroidx/compose/ui/focus/FocusManager;ZILjava/lang/Object;)V

    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/EditorViewModel;->save()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$7$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 52
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$3(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$8(Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 20
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$onExit"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v12, p2

    move/from16 v15, p3

    const-string v2, "C51@3405L24,51@3394L89:CardEditorScreen.kt#i35lj1"

    invoke-static {v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v15, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_14

    const/4 v2, 0x1

    goto :goto_15

    :cond_14
    const/4 v2, 0x0

    :goto_15
    and-int/lit8 v3, v15, 0x1

    invoke-interface {v12, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_82

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2c

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.CardEditorScreen.<anonymous> (CardEditorScreen.kt:51)"

    const v4, -0x566687ec

    invoke-static {v4, v15, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 52
    :cond_2c
    const v2, -0x56e43b54

    const-string v3, "CC(remember):CardEditorScreen.kt#9igjgp"

    invoke-static {v12, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\1":Z
    move-object/from16 v3, p2

    .local v3, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 412
    .local v4, "$i$f$cache\\1\\52":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\1":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 413
    .local v6, "$i$a$-let-ComposerKt$cache$1\\2\\412\\1":I
    if-nez v2, :cond_51

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_50

    goto :goto_51

    .line 417
    :cond_50
    goto :goto_5c

    .line 414
    :cond_51
    :goto_51
    const/4 v7, 0x0

    .line 52
    .local v7, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$5$1\\3\\414\\0":I
    new-instance v8, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v8, v1, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda0;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)V

    .line 414
    .end local v7    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$5$1\\3\\414\\0":I
    nop

    .line 415
    .local v8, "value\\2":Ljava/lang/Object;
    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 416
    move-object v5, v8

    .line 412
    .end local v5    # "it\\1":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\2\\412\\1":I
    .end local v8    # "value\\2":Ljava/lang/Object;
    :goto_5c
    nop

    .line 52
    .end local v2    # "invalid\\1":Z
    .end local v3    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\1\\52":I
    move-object v2, v5

    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$274740599$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v11

    const/high16 v13, 0x30000000

    const/16 v14, 0x1fe

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static/range {v2 .. v14}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_85

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_85

    :cond_82
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_85
    :goto_85
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final CardEditorScreen$lambda$8$0$0(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$onExit"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 52
    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$3(Landroidx/compose/runtime/MutableState;Z)V

    invoke-interface {p0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$9(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 17
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object v10, p1

    move/from16 v13, p2

    const-string v0, "C51@3511L15,51@3500L42:CardEditorScreen.kt#i35lj1"

    invoke-static {p1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_f

    const/4 v0, 0x1

    goto :goto_10

    :cond_f
    const/4 v0, 0x0

    :goto_10
    and-int/lit8 v1, v13, 0x1

    invoke-interface {p1, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_77

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_27

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.CardEditorScreen.<anonymous> (CardEditorScreen.kt:51)"

    const v2, -0x3a3f332e

    invoke-static {v2, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 52
    :cond_27
    const v0, 0x58c0e1e1    # 1.696611E15f

    const-string v1, "CC(remember):CardEditorScreen.kt#9igjgp"

    invoke-static {p1, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p1, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    move-object v1, p1

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 412
    .local v2, "$i$f$cache\\1\\52":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\1":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 413
    .local v4, "$i$a$-let-ComposerKt$cache$1\\2\\412\\1":I
    if-nez v0, :cond_46

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_45

    goto :goto_46

    .line 417
    :cond_45
    goto :goto_51

    .line 414
    :cond_46
    :goto_46
    const/4 v5, 0x0

    .line 52
    .local v5, "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$6$1\\3\\414\\0":I
    new-instance v6, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v6, p0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda10;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 414
    .end local v5    # "$i$a$-cache-CardEditorScreenKt$CardEditorScreen$6$1\\3\\414\\0":I
    nop

    .line 415
    .local v6, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 416
    move-object v3, v6

    .line 412
    .end local v3    # "it\\1":Ljava/lang/Object;
    .end local v4    # "$i$a$-let-ComposerKt$cache$1\\2\\412\\1":I
    .end local v6    # "value\\2":Ljava/lang/Object;
    :goto_51
    nop

    .line 52
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\1\\52":I
    move-object v0, v3

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-static {p1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$CardEditorScreenKt;->getLambda$747080245$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/high16 v11, 0x30000000

    const/16 v12, 0x1fe

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_7a

    :cond_77
    invoke-interface {p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_7a
    :goto_7a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final CardEditorScreen$lambda$9$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2
    .param p0, "$discard$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 52
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->CardEditorScreen$lambda$3(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V
    .registers 68
    .param p0, "label"    # Ljava/lang/String;
    .param p1, "placeholder"    # Ljava/lang/String;
    .param p2, "value"    # Ljava/lang/String;
    .param p3, "onChange"    # Lkotlin/jvm/functions/Function1;
    .param p4, "error"    # Ljava/lang/String;
    .param p5, "tag"    # Ljava/lang/String;
    .param p6, "enabled"    # Z
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Z",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 54
    move-object/from16 v2, p1

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move/from16 v8, p8

    const v0, -0x5d3b21eb

    move-object/from16 v1, p7

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p7    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v1, "C(EditorField)N(label,placeholder,value,onChange,error,tag,enabled)54@3712L37,55@3783L3,55@3810L7,57@3941L63,57@3904L100,58@4006L408:CardEditorScreen.kt#i35lj1"

    invoke-static {v9, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v1, p8

    .local v1, "$dirty":I
    and-int/lit8 v3, v8, 0x6

    if-nez v3, :cond_29

    move-object/from16 v10, p0

    invoke-interface {v9, v10}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_26

    const/4 v3, 0x4

    goto :goto_27

    :cond_26
    const/4 v3, 0x2

    :goto_27
    or-int/2addr v1, v3

    goto :goto_2b

    :cond_29
    move-object/from16 v10, p0

    :goto_2b
    and-int/lit8 v3, v8, 0x30

    if-nez v3, :cond_3b

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_38

    const/16 v3, 0x20

    goto :goto_3a

    :cond_38
    const/16 v3, 0x10

    :goto_3a
    or-int/2addr v1, v3

    :cond_3b
    and-int/lit16 v3, v8, 0x180

    if-nez v3, :cond_4e

    move-object/from16 v3, p2

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4a

    const/16 v4, 0x100

    goto :goto_4c

    :cond_4a
    const/16 v4, 0x80

    :goto_4c
    or-int/2addr v1, v4

    goto :goto_50

    :cond_4e
    move-object/from16 v3, p2

    :goto_50
    and-int/lit16 v4, v8, 0xc00

    if-nez v4, :cond_63

    move-object/from16 v4, p3

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_5f

    const/16 v7, 0x800

    goto :goto_61

    :cond_5f
    const/16 v7, 0x400

    :goto_61
    or-int/2addr v1, v7

    goto :goto_65

    :cond_63
    move-object/from16 v4, p3

    :goto_65
    and-int/lit16 v7, v8, 0x6000

    if-nez v7, :cond_75

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_72

    const/16 v7, 0x4000

    goto :goto_74

    :cond_72
    const/16 v7, 0x2000

    :goto_74
    or-int/2addr v1, v7

    :cond_75
    const/high16 v7, 0x30000

    and-int/2addr v7, v8

    if-nez v7, :cond_86

    invoke-interface {v9, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_83

    const/high16 v7, 0x20000

    goto :goto_85

    :cond_83
    const/high16 v7, 0x10000

    :goto_85
    or-int/2addr v1, v7

    :cond_86
    const/high16 v7, 0x180000

    and-int/2addr v7, v8

    if-nez v7, :cond_9a

    move/from16 v7, p6

    invoke-interface {v9, v7}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v12

    if-eqz v12, :cond_96

    const/high16 v12, 0x100000

    goto :goto_98

    :cond_96
    const/high16 v12, 0x80000

    :goto_98
    or-int/2addr v1, v12

    goto :goto_9c

    :cond_9a
    move/from16 v7, p6

    :goto_9c
    const v12, 0x92493

    and-int/2addr v12, v1

    const v13, 0x92492

    if-eq v12, v13, :cond_a7

    const/4 v12, 0x1

    goto :goto_a8

    :cond_a7
    const/4 v12, 0x0

    :goto_a8
    and-int/lit8 v13, v1, 0x1

    invoke-interface {v9, v12, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v12

    if-eqz v12, :cond_399

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v12

    if-eqz v12, :cond_bc

    const/4 v12, -0x1

    const-string v13, "com.xunji.flashcards.ui.screens.EditorField (CardEditorScreen.kt:53)"

    invoke-static {v0, v1, v12, v13}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 55
    :cond_bc
    const v0, 0x505befa

    const-string v12, "CC(remember):CardEditorScreen.kt#9igjgp"

    invoke-static {v9, v0, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\1":Z
    move-object v13, v9

    .local v13, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 352
    .local v16, "$i$f$cache\\1\\55":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\1":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 353
    .local v17, "$i$a$-let-ComposerKt$cache$1\\2\\352\\1":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v15, v14, :cond_e1

    .line 354
    const/4 v14, 0x0

    .line 55
    .local v14, "$i$a$-cache-CardEditorScreenKt$EditorField$errorView$1\\3\\354\\0":I
    invoke-static {}, Landroidx/compose/foundation/relocation/BringIntoViewRequesterKt;->BringIntoViewRequester()Landroidx/compose/foundation/relocation/BringIntoViewRequester;

    move-result-object v14

    .line 354
    .end local v14    # "$i$a$-cache-CardEditorScreenKt$EditorField$errorView$1\\3\\354\\0":I
    nop

    .line 355
    .local v14, "value\\2":Ljava/lang/Object;
    invoke-interface {v13, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 356
    move-object v15, v14

    .end local v14    # "value\\2":Ljava/lang/Object;
    goto :goto_e2

    .line 357
    :cond_e1
    nop

    .line 352
    .end local v15    # "it\\1":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\2\\352\\1":I
    :goto_e2
    nop

    .line 55
    .end local v0    # "invalid\\1":Z
    .end local v13    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\1\\55":I
    move-object v0, v15

    check-cast v0, Landroidx/compose/foundation/relocation/BringIntoViewRequester;

    .local v0, "errorView":Landroidx/compose/foundation/relocation/BringIntoViewRequester;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 56
    sget-object v13, Landroidx/compose/foundation/layout/WindowInsets;->Companion:Landroidx/compose/foundation/layout/WindowInsets$Companion;

    const/4 v14, 0x6

    invoke-static {v13, v9, v14}, Landroidx/compose/foundation/layout/WindowInsets_androidKt;->getIme(Landroidx/compose/foundation/layout/WindowInsets$Companion;Landroidx/compose/runtime/Composer;I)Landroidx/compose/foundation/layout/WindowInsets;

    move-result-object v13

    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalDensity()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v15

    check-cast v15, Landroidx/compose/runtime/CompositionLocal;

    .local v15, "this_\\4":Landroidx/compose/runtime/CompositionLocal;
    const/16 v16, 0x0

    .local v16, "$changed\\4":I
    move-object/from16 v17, v9

    .local v17, "$composer\\4":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 358
    .local v18, "$i$f$getCurrent\\4\\56":I
    move/from16 v20, v14

    const v14, 0x789c5f52

    const-string v11, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    move/from16 v38, v1

    move-object/from16 v1, v17

    .end local v17    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .local v1, "$composer\\4":Landroidx/compose/runtime/Composer;
    .local v38, "$dirty":I
    invoke-static {v1, v14, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v15}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v11

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .end local v1    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .end local v15    # "this_\\4":Landroidx/compose/runtime/CompositionLocal;
    .end local v16    # "$changed\\4":I
    .end local v18    # "$i$f$getCurrent\\4\\56":I
    check-cast v11, Landroidx/compose/ui/unit/Density;

    .line 56
    invoke-interface {v13, v11}, Landroidx/compose/foundation/layout/WindowInsets;->getBottom(Landroidx/compose/ui/unit/Density;)I

    move-result v1

    .line 58
    .local v1, "keyboardHeight":I
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v11

    const v13, 0x505dbb4

    invoke-static {v9, v13, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v12, 0xe000

    and-int v12, v38, v12

    const/16 v13, 0x4000

    if-ne v12, v13, :cond_12c

    const/4 v12, 0x1

    goto :goto_12d

    :cond_12c
    const/4 v12, 0x0

    :goto_12d
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v13

    or-int/2addr v12, v13

    .local v12, "invalid\\5":Z
    move-object v13, v9

    .local v13, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 359
    .local v14, "$i$f$cache\\5\\58":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\5":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 360
    .local v16, "$i$a$-let-ComposerKt$cache$1\\6\\359\\5":I
    move/from16 v17, v12

    .end local v12    # "invalid\\5":Z
    .local v17, "invalid\\5":Z
    if-nez v17, :cond_14b

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v15, v12, :cond_147

    goto :goto_14b

    .line 364
    :cond_147
    move/from16 v39, v1

    const/4 v3, 0x0

    goto :goto_15b

    .line 361
    :cond_14b
    :goto_14b
    const/4 v12, 0x0

    .line 58
    .local v12, "$i$a$-cache-CardEditorScreenKt$EditorField$1\\7\\361\\0":I
    move/from16 v39, v1

    .end local v1    # "keyboardHeight":I
    .local v39, "keyboardHeight":I
    new-instance v1, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;

    const/4 v3, 0x0

    invoke-direct {v1, v5, v0, v3}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$EditorField$1$1;-><init>(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Lkotlin/coroutines/Continuation;)V

    check-cast v1, Lkotlin/jvm/functions/Function2;

    .line 361
    .end local v12    # "$i$a$-cache-CardEditorScreenKt$EditorField$1\\7\\361\\0":I
    nop

    .line 362
    .local v1, "value\\6":Ljava/lang/Object;
    invoke-interface {v13, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 363
    move-object v15, v1

    .line 359
    .end local v1    # "value\\6":Ljava/lang/Object;
    .end local v15    # "it\\5":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\6\\359\\5":I
    :goto_15b
    nop

    .line 58
    .end local v13    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\5\\58":I
    .end local v17    # "invalid\\5":Z
    check-cast v15, Lkotlin/jvm/functions/Function2;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    shr-int/lit8 v1, v38, 0xc

    and-int/lit8 v1, v1, 0xe

    invoke-static {v5, v11, v15, v9, v1}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 59
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v11, 0xa

    .local v11, "$this$dp\\8":I
    const/4 v12, 0x0

    .line 365
    .local v12, "$i$f$getDp\\8\\59":I
    int-to-float v13, v11

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 59
    .end local v11    # "$this$dp\\8":I
    .end local v12    # "$i$f$getDp\\8\\59":I
    invoke-virtual {v1, v11}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v1, "verticalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v11, 0x30

    .local v11, "$changed\\9":I
    move-object v12, v9

    .local v12, "$composer\\9":Landroidx/compose/runtime/Composer;
    move/from16 v40, v11

    .end local v11    # "$changed\\9":I
    .local v40, "$changed\\9":I
    const/16 v41, 0x0

    .line 366
    .local v41, "$i$f$Column\\9\\59":I
    const v11, 0x4ff7456f

    const-string v13, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v12, v11, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 367
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v42, v11

    check-cast v42, Landroidx/compose/ui/Modifier;

    .line 369
    .local v42, "modifier\\9":Landroidx/compose/ui/Modifier;
    sget-object v11, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v11

    .line 372
    .local v11, "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v13, v40, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v40, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v1, v11, v12, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .line 376
    .local v13, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v40, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 373
    move-object/from16 v15, v42

    .local v15, "modifier\\10":Landroidx/compose/ui/Modifier;
    move/from16 v43, v14

    .local v43, "$changed\\10":I
    const/16 v44, 0x0

    .line 377
    .local v44, "$i$f$Layout\\10\\373":I
    const v14, -0x451e1427

    const-string v3, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v12, v14, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 378
    const/4 v3, 0x0

    invoke-static {v12, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->hashCode(J)I

    move-result v45

    .line 379
    .local v45, "compositeKeyHash\\10":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 380
    .local v14, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 382
    .local v3, "materialized\\10":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v46, v1

    .end local v1    # "verticalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v46, "verticalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shl-int/lit8 v1, v43, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 381
    move-object/from16 v47, v16

    .local v1, "$changed\\11":I
    .local v47, "factory\\11":Lkotlin/jvm/functions/Function0;
    const/16 v48, 0x0

    .line 383
    .local v48, "$i$f$ReusableComposeNode\\11\\381":I
    move/from16 v49, v1

    .end local v1    # "$changed\\11":I
    .local v49, "$changed\\11":I
    const v1, -0x20f7d59c

    const-string v4, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v12, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 384
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_1ea

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 385
    :cond_1ea
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 386
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_1f9

    .line 387
    move-object/from16 v1, v47

    .end local v47    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1fe

    .line 389
    .end local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v47    # "factory\\11":Lkotlin/jvm/functions/Function0;
    :cond_1f9
    move-object/from16 v1, v47

    .end local v47    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 391
    :goto_1fe
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 392
    .local v16, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\391\\10":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v47, v1

    .end local v1    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .restart local v47    # "factory\\11":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 393
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 394
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\13":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 395
    .local v17, "$i$f$set-impl\\13\\394":I
    move-object/from16 v18, v4

    .local v18, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 396
    .local v22, "$i$a$-with-Updater$set$1\\14\\395\\13":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_23c

    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_239

    goto :goto_23c

    :cond_239
    move-object/from16 v8, v18

    goto :goto_24c

    .line 397
    :cond_23c
    :goto_23c
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v8, v18

    .end local v18    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 398
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v4, v7, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 400
    :goto_24c
    nop

    .line 395
    .end local v8    # "$this$set_impl_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\14\\395\\13":I
    nop

    .line 400
    nop

    .line 401
    .end local v1    # "block\\13":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\13\\394":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 402
    nop

    .line 391
    .end local v4    # "$this$Layout_u24lambda_u240\\12":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\12\\391\\10":I
    nop

    .line 403
    shr-int/lit8 v1, v49, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\15":I
    move-object v4, v12

    .local v4, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 374
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\15\\403\\9":I
    const v8, 0x7cc0ae6e

    move/from16 v50, v1

    .end local v1    # "$changed\\15":I
    .local v50, "$changed\\15":I
    const-string v1, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v4, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, v40, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\16":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$EditorField_u24lambda_u242\\16":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v32, v4

    .local v32, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 60
    .local v51, "$i$a$-Column-CardEditorScreenKt$EditorField$2\\16\\374\\0":I
    move-object/from16 v52, v1

    .end local v1    # "$this$EditorField_u24lambda_u242\\16":Landroidx/compose/foundation/layout/ColumnScope;
    .local v52, "$this$EditorField_u24lambda_u242\\16":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, -0x1e8b5375

    move-object/from16 v53, v3

    .end local v3    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .local v53, "materialized\\10":Landroidx/compose/ui/Modifier;
    const-string v3, "C59@4097L10,59@4066L54,60@4214L19,60@4339L71,60@4123L288:CardEditorScreen.kt#i35lj1"

    move-object/from16 v54, v4

    .end local v32    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    and-int/lit8 v33, v38, 0xe

    const/16 v34, 0x0

    const v35, 0x1fffe

    move-object v1, v11

    .end local v11    # "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    .local v1, "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v11, 0x0

    move-object v3, v12

    move-object/from16 v16, v13

    .end local v12    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v13    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v16, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    const-wide/16 v12, 0x0

    move-object/from16 v17, v14

    .end local v14    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v17, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v14, 0x0

    move-object/from16 v20, v15

    move-object/from16 v18, v16

    .end local v15    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v16    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v18, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v20, "modifier\\10":Landroidx/compose/ui/Modifier;
    const-wide/16 v15, 0x0

    move-object/from16 v22, v17

    .end local v17    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v22, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v23, v18

    .end local v18    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v23, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v18, 0x0

    const/16 v24, 0x0

    const/16 v19, 0x0

    move-object/from16 v25, v20

    const/16 v26, 0x0

    .end local v20    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v25, "modifier\\10":Landroidx/compose/ui/Modifier;
    const-wide/16 v20, 0x0

    move-object/from16 v27, v22

    .end local v22    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v27, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v22, 0x0

    move-object/from16 v28, v23

    .end local v23    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v28, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v23, 0x0

    move/from16 v30, v24

    move-object/from16 v29, v25

    .end local v25    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v29, "modifier\\10":Landroidx/compose/ui/Modifier;
    const-wide/16 v24, 0x0

    move-object/from16 v32, v26

    const/16 v26, 0x0

    move-object/from16 v36, v27

    .end local v27    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v36, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v27, 0x0

    move-object/from16 v37, v28

    .end local v28    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v37, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v28, 0x0

    move-object/from16 v55, v29

    .end local v29    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v55, "modifier\\10":Landroidx/compose/ui/Modifier;
    const/16 v29, 0x0

    move/from16 v56, v30

    const/16 v30, 0x0

    move-object/from16 p7, v1

    move-object/from16 v58, v3

    move-object/from16 v1, v32

    move-object/from16 v57, v36

    const/4 v3, 0x1

    move-object/from16 v32, v4

    move-object/from16 v4, v37

    .end local v1    # "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v36    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v37    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v4, "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v32    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v57, "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    .local v58, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local p7, "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static/range {v10 .. v35}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 61
    move-object/from16 v10, v32

    .end local v32    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v10, "$composer\\16":Landroidx/compose/runtime/Composer;
    sget-object v11, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v11, Landroidx/compose/ui/Modifier;

    const/4 v12, 0x0

    invoke-static {v11, v12, v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-static {v1, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    if-eqz v5, :cond_301

    move/from16 v23, v3

    goto :goto_303

    :cond_301
    move/from16 v23, v56

    :goto_303
    const/16 v1, 0x12

    .local v1, "$this$dp\\17":I
    const/4 v11, 0x0

    .line 404
    .local v11, "$i$f$getDp\\17\\61":I
    int-to-float v13, v1

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 61
    .end local v1    # "$this$dp\\17":I
    .end local v11    # "$i$f$getDp\\17\\61":I
    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    new-instance v11, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v11, v2}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda7;-><init>(Ljava/lang/String;)V

    const v13, 0x7ebcc746

    const/16 v14, 0x36

    invoke-static {v13, v3, v11, v10, v14}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v11

    move-object/from16 v17, v11

    check-cast v17, Lkotlin/jvm/functions/Function2;

    new-instance v11, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v11, v5, v0}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda8;-><init>(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;)V

    const v13, 0x6026718

    invoke-static {v13, v3, v11, v10, v14}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    move-object/from16 v22, v3

    check-cast v22, Lkotlin/jvm/functions/Function2;

    move-object/from16 v31, v1

    check-cast v31, Landroidx/compose/ui/graphics/Shape;

    shr-int/lit8 v1, v38, 0x6

    and-int/lit8 v1, v1, 0xe

    const/high16 v3, 0xc00000

    or-int/2addr v1, v3

    shr-int/lit8 v3, v38, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/2addr v1, v3

    shr-int/lit8 v3, v38, 0x9

    and-int/lit16 v3, v3, 0x1c00

    or-int v34, v1, v3

    const/16 v36, 0x0

    const v37, 0x53cf70

    const/4 v14, 0x0

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x8

    const/16 v29, 0x3

    const/16 v30, 0x0

    const/16 v32, 0x0

    const v35, 0x36000180

    move-object/from16 v11, p3

    move/from16 v13, p6

    move-object/from16 v33, v10

    move-object/from16 v10, p2

    .end local v10    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v33, "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v37}, Landroidx/compose/material3/OutlinedTextFieldKt;->OutlinedTextField(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLandroidx/compose/ui/text/input/VisualTransformation;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;ZIILandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/TextFieldColors;Landroidx/compose/runtime/Composer;IIII)V

    .line 60
    move-object/from16 v10, v33

    .end local v33    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer\\16":Landroidx/compose/runtime/Composer;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 62
    nop

    .line 374
    .end local v8    # "$changed\\16":I
    .end local v10    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Column-CardEditorScreenKt$EditorField$2\\16\\374\\0":I
    .end local v52    # "$this$EditorField_u24lambda_u242\\16":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 403
    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\15\\403\\9":I
    .end local v50    # "$changed\\15":I
    .end local v54    # "$composer\\15":Landroidx/compose/runtime/Composer;
    nop

    .line 405
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 383
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 406
    nop

    .line 377
    .end local v47    # "factory\\11":Lkotlin/jvm/functions/Function0;
    .end local v48    # "$i$f$ReusableComposeNode\\11\\381":I
    .end local v49    # "$changed\\11":I
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 407
    nop

    .line 366
    .end local v43    # "$changed\\10":I
    .end local v44    # "$i$f$Layout\\10\\373":I
    .end local v45    # "compositeKeyHash\\10":I
    .end local v53    # "materialized\\10":Landroidx/compose/ui/Modifier;
    .end local v55    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v57    # "localMap\\10":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v58 .. v58}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 408
    nop

    .end local v4    # "measurePolicy\\9":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v40    # "$changed\\9":I
    .end local v41    # "$i$f$Column\\9\\59":I
    .end local v42    # "modifier\\9":Landroidx/compose/ui/Modifier;
    .end local v46    # "verticalArrangement\\9":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v58    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local p7    # "horizontalAlignment\\9":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_39e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "errorView":Landroidx/compose/foundation/relocation/BringIntoViewRequester;
    .end local v39    # "keyboardHeight":I
    goto :goto_39e

    .line 54
    .end local v38    # "$dirty":I
    .local v1, "$dirty":I
    :cond_399
    move/from16 v38, v1

    .end local v1    # "$dirty":I
    .restart local v38    # "$dirty":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 63
    :cond_39e
    :goto_39e
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v10

    if-eqz v10, :cond_3b6

    new-instance v0, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda9;

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move/from16 v7, p6

    move/from16 v8, p8

    invoke-direct/range {v0 .. v8}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt$$ExternalSyntheticLambda9;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZI)V

    invoke-interface {v10, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_3b6
    return-void
.end method

.method private static final EditorField$lambda$2$0(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 29
    .param p0, "$placeholder"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C60@4215L17:CardEditorScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_10

    const/4 v2, 0x1

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_5b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.EditorField.<anonymous>.<anonymous> (CardEditorScreen.kt:60)"

    const v4, 0x7ebcc746

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 61
    :cond_28
    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, v0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_5e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_5e

    :cond_5b
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_5e
    :goto_5e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final EditorField$lambda$2$1(Ljava/lang/String;Landroidx/compose/foundation/relocation/BringIntoViewRequester;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$error"    # Ljava/lang/String;
    .param p1, "$errorView"    # Landroidx/compose/foundation/relocation/BringIntoViewRequester;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "C:CardEditorScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_10

    const/4 v2, 0x1

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_7e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.EditorField.<anonymous>.<anonymous> (CardEditorScreen.kt:60)"

    const v4, 0x6026718

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 61
    :cond_28
    if-eqz p0, :cond_6b

    const v2, -0x70fafcb2

    invoke-interface {v0, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "60@4355L54"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v3, p1

    invoke-static {v2, v3}, Landroidx/compose/foundation/relocation/BringIntoViewRequesterKt;->bringIntoViewRequester(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/relocation/BringIntoViewRequester;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v24, 0x0

    const v25, 0x3fffc

    move-object v1, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, v0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v0, v22

    goto :goto_71

    :cond_6b
    const v1, 0x5159706a

    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_71
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_81

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_81

    :cond_7e
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_81
    :goto_81
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final EditorField$lambda$3(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 20

    or-int/lit8 v0, p7, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v9

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p5

    move/from16 v7, p6

    move-object/from16 v8, p8

    invoke-static/range {v1 .. v9}, Lcom/xunji/flashcards/ui/screens/CardEditorScreenKt;->EditorField(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Ljava/lang/String;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

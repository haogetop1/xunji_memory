.class public final synthetic Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda12;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/xunji/core/model/CardCandidate;

    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->$r8$lambda$V-EApQvXdJ83boSHBwCNG-lf4JY(Lcom/xunji/core/model/CardCandidate;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda14;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/MutableState;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda14;->f$0:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda14;->f$0:Landroidx/compose/runtime/MutableState;

    invoke-static {v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->$r8$lambda$08HXMdDbl4gE_L0DrRutv-tbjrI(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

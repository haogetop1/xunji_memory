.class final Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;
.super Ljava/lang/Object;
.source "DeckDetailScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $candidate:Lcom/xunji/core/model/CardCandidate;

.field final synthetic $onEdit:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/CardCandidate;)V
    .registers 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lcom/xunji/core/model/CardCandidate;",
            ")V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;->$onEdit:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;->$candidate:Lcom/xunji/core/model/CardCandidate;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 28
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;->invoke()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke()V
    .registers 3

    .line 28
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;->$onEdit:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$1$1;->$candidate:Lcom/xunji/core/model/CardCandidate;

    invoke-virtual {v1}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/model/Flashcard;->getId()Ljava/lang/String;

    move-result-object v1

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    return-void
.end method

.class final Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;
.super Ljava/lang/Object;
.source "DeckDetailScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeckDetailScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeckDetailScreen.kt\ncom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 8 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,42:1\n113#2:43\n113#2:82\n99#3:44\n95#3,10:45\n106#3:132\n80#4,6:55\n87#4,3:70\n90#4,2:79\n80#4,6:92\n87#4,3:107\n90#4,2:116\n94#4:121\n94#4:131\n391#5,9:61\n400#5:81\n391#5,9:98\n400#5,3:118\n401#5,2:129\n4360#6,6:73\n4360#6,6:110\n87#7:83\n85#7,8:84\n94#7:122\n1282#8,6:123\n*S KotlinDebug\n*F\n+ 1 DeckDetailScreen.kt\ncom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2\n*L\n29#1:43\n30#1:82\n29#1:44\n29#1:45,10\n29#1:132\n29#1:55,6\n29#1:70,3\n29#1:79,2\n30#1:92,6\n30#1:107,3\n30#1:116,2\n30#1:121\n29#1:131\n29#1:61,9\n29#1:81\n30#1:98,9\n30#1:118,3\n29#1:129,2\n29#1:73,6\n30#1:110,6\n30#1:83\n30#1:84,8\n30#1:122\n35#1:123,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $candidate:Lcom/xunji/core/model/CardCandidate;

.field final synthetic $deleting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $error$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method constructor <init>(Landroidx/compose/runtime/MutableState;Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/MutableState;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/xunji/core/model/CardCandidate;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$candidate:Lcom/xunji/core/model/CardCandidate;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$error$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 28
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .registers 82
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$Paper"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C28@1915L631:DeckDetailScreen.kt#i35lj1"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    if-eq v3, v5, :cond_1a

    const/4 v3, 0x1

    goto :goto_1b

    :cond_1a
    const/4 v3, 0x0

    :goto_1b
    and-int/lit8 v5, v2, 0x1

    invoke-interface {v1, v3, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_3d2

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_32

    const/4 v3, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:28)"

    const v7, 0x4f78aedc

    invoke-static {v7, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 29
    :cond_32
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0xc

    .local v7, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 43
    .local v8, "$i$f$getDp\\1\\29":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 29
    .end local v7    # "$this$dp\\1":I
    .end local v8    # "$i$f$getDp\\1\\29":I
    invoke-virtual {v5, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v5, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-object v7, v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v8, v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$candidate:Lcom/xunji/core/model/CardCandidate;

    iget-object v9, v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2;->$error$delegate:Landroidx/compose/runtime/MutableState;

    const/16 v10, 0x1b0

    .local v10, "$changed\\2":I
    move-object/from16 v11, p2

    .local v3, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v11, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 44
    .local v12, "$i$f$Row\\2\\29":I
    const v13, 0x3255a44b

    const-string v14, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v11, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 45
    sget-object v13, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v13, Landroidx/compose/ui/Modifier;

    .line 50
    .local v13, "modifier\\2":Landroidx/compose/ui/Modifier;
    shr-int/lit8 v14, v10, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v10, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v5, v3, v11, v14}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .line 54
    .local v14, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v10, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 51
    move-object/from16 v16, v13

    .local v15, "$changed\\3":I
    .local v16, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v17, 0x0

    .line 55
    .local v17, "$i$f$Layout\\3\\51":I
    const v6, -0x451e1427

    const-string v0, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v11, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 56
    const/4 v6, 0x0

    invoke-static {v11, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v20

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->hashCode(J)I

    move-result v6

    .line 57
    .local v6, "compositeKeyHash\\3":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 58
    .local v1, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v2, v16

    move-object/from16 v16, v3

    .end local v3    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v16, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v11, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 60
    .local v3, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move-object/from16 v21, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v21, "modifier\\3":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v15, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 59
    nop

    .local v2, "$changed\\4":I
    move-object/from16 v22, v20

    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 61
    .local v20, "$i$f$ReusableComposeNode\\4\\59":I
    move/from16 v23, v2

    .end local v2    # "$changed\\4":I
    .local v23, "$changed\\4":I
    const v2, -0x20f7d59c

    const-string v4, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v11, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 62
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_b9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 63
    :cond_b9
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 64
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_c8

    .line 65
    move-object/from16 v2, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_cd

    .line 67
    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c8
    move-object/from16 v2, v22

    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 69
    :goto_cd
    move-object/from16 v22, v2

    .end local v2    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 70
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\69\\3":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v27, v5

    .end local v5    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v27, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v14, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 71
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v1, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 72
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 73
    .local v26, "$i$f$set-impl\\6\\72":I
    move-object/from16 v28, v2

    .local v28, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 74
    .local v29, "$i$a$-with-Updater$set$1\\7\\73\\6":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_111

    move-object/from16 v30, v1

    .end local v1    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v31, v6

    .end local v6    # "compositeKeyHash\\3":I
    .local v31, "compositeKeyHash\\3":I
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_10e

    goto :goto_115

    :cond_10e
    move-object/from16 v6, v28

    goto :goto_125

    .end local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v31    # "compositeKeyHash\\3":I
    .restart local v1    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "compositeKeyHash\\3":I
    :cond_111
    move-object/from16 v30, v1

    move/from16 v31, v6

    .line 75
    .end local v1    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "compositeKeyHash\\3":I
    .restart local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v31    # "compositeKeyHash\\3":I
    :goto_115
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v6, v28

    .end local v28    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 76
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v2, v1, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 78
    :goto_125
    nop

    .line 73
    .end local v6    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-with-Updater$set$1\\7\\73\\6":I
    nop

    .line 78
    nop

    .line 79
    .end local v5    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v26    # "$i$f$set-impl\\6\\72":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 80
    nop

    .line 69
    .end local v2    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\69\\3":I
    nop

    .line 81
    shr-int/lit8 v1, v23, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object v2, v11

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 52
    .local v5, "$i$a$-Layout-RowKt$Row$1\\8\\81\\2":I
    const v6, 0x56ccd6f5

    move/from16 v25, v1

    .end local v1    # "$changed\\8":I
    .local v25, "$changed\\8":I
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v10, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v32, v1

    .end local v1    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v32, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object v1, v2

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 30
    .local v26, "$i$a$-Row-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1\\9\\52\\0":I
    move-object/from16 v28, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v28, "$composer\\8":Landroidx/compose/runtime/Composer;
    const v2, -0x2da5cc1b

    move-object/from16 v29, v3

    .end local v3    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v29, "materialized\\3":Landroidx/compose/ui/Modifier;
    const-string v3, "C29@2022L445,34@2500L39,34@2473L67:DeckDetailScreen.kt#i35lj1"

    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v33, v2

    check-cast v33, Landroidx/compose/ui/Modifier;

    const/16 v36, 0x2

    const/16 v37, 0x0

    const/high16 v34, 0x3f800000    # 1.0f

    const/16 v35, 0x0

    invoke-static/range {v32 .. v37}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move-object/from16 v33, v2

    const/16 v2, 0x8

    .local v2, "$this$dp\\10":I
    const/16 v34, 0x0

    .line 82
    .local v34, "$i$f$getDp\\10\\30":I
    move/from16 v41, v5

    .end local v5    # "$i$a$-Layout-RowKt$Row$1\\8\\81\\2":I
    .local v41, "$i$a$-Layout-RowKt$Row$1\\8\\81\\2":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 30
    .end local v2    # "$this$dp\\10":I
    .end local v34    # "$i$f$getDp\\10\\30":I
    invoke-virtual {v3, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v2, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v3, 0x30

    .local v3, "$changed\\11":I
    .local v33, "modifier\\11":Landroidx/compose/ui/Modifier;
    move-object v5, v1

    .local v5, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 83
    .local v34, "$i$f$Column\\11\\30":I
    move/from16 v35, v3

    .end local v3    # "$changed\\11":I
    .local v35, "$changed\\11":I
    const v3, 0x4ff7456f

    move/from16 v42, v6

    .end local v6    # "$changed\\9":I
    .local v42, "$changed\\9":I
    const-string v6, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v5, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 84
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 87
    .local v3, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v6, v35, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v36, v35, 0x3

    and-int/lit8 v36, v36, 0x70

    or-int v6, v6, v36

    invoke-static {v2, v3, v5, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 91
    .local v6, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v36, v35, 0x3

    and-int/lit8 v36, v36, 0x70

    .line 88
    move-object/from16 v37, v33

    .local v36, "$changed\\12":I
    .local v37, "modifier\\12":Landroidx/compose/ui/Modifier;
    const/16 v38, 0x0

    .line 92
    .local v38, "$i$f$Layout\\12\\88":I
    move-object/from16 v39, v2

    const v2, -0x451e1427

    .end local v2    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v39, "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 93
    const/4 v0, 0x0

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v43

    invoke-static/range {v43 .. v44}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 94
    .local v0, "compositeKeyHash\\12":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 95
    .local v2, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v19, v0

    move-object/from16 v0, v37

    move-object/from16 v37, v3

    .end local v3    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .local v0, "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v19, "compositeKeyHash\\12":I
    .local v37, "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v5, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 97
    .local v3, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v40, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v40 .. v40}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v40

    move-object/from16 v43, v0

    .end local v0    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v36, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 96
    move-object/from16 v44, v40

    .local v0, "$changed\\13":I
    .local v44, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v40, 0x0

    .line 98
    .local v40, "$i$f$ReusableComposeNode\\13\\96":I
    move/from16 v45, v0

    const v0, -0x20f7d59c

    .end local v0    # "$changed\\13":I
    .local v45, "$changed\\13":I
    invoke-static {v5, v0, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 99
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1f6

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 100
    :cond_1f6
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 101
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_205

    .line 102
    move-object/from16 v0, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_20a

    .line 104
    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_205
    move-object/from16 v0, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 106
    :goto_20a
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 107
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\106\\12":I
    sget-object v44, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v46, v0

    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v46, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v44 .. v44}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 108
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 109
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v44, 0x0

    .line 110
    .local v44, "$i$f$set-impl\\15\\109":I
    move-object/from16 v47, v4

    .local v47, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v48, 0x0

    .line 111
    .local v48, "$i$a$-with-Updater$set$1\\16\\110\\15":I
    invoke-interface/range {v47 .. v47}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v49

    if-nez v49, :cond_24c

    move-object/from16 v49, v2

    .end local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v49, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v47 .. v47}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v50, v5

    .end local v5    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v50, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v2, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_249

    goto :goto_250

    :cond_249
    move-object/from16 v5, v47

    goto :goto_260

    .end local v49    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "$composer\\11":Landroidx/compose/runtime/Composer;
    :cond_24c
    move-object/from16 v49, v2

    move-object/from16 v50, v5

    .line 112
    .end local v2    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v49    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    :goto_250
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v5, v47

    .end local v47    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 113
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v4, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 115
    :goto_260
    nop

    .line 110
    .end local v5    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v48    # "$i$a$-with-Updater$set$1\\16\\110\\15":I
    nop

    .line 115
    nop

    .line 116
    .end local v0    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v44    # "$i$f$set-impl\\15\\109":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 117
    nop

    .line 106
    .end local v4    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\106\\12":I
    nop

    .line 118
    shr-int/lit8 v0, v45, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\17":I
    move-object/from16 v2, v50

    .local v2, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 89
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\17\\118\\11":I
    const v5, 0x7cc0ae6e

    move/from16 v24, v0

    .end local v0    # "$changed\\17":I
    .local v24, "$changed\\17":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v2, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v35, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\18":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$invoke_u24lambda_u240_u240\\18":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v73, v2

    .local v73, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v44, 0x0

    .line 31
    .local v44, "$i$a$-Column-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$1\\18\\89\\9":I
    move-object/from16 v47, v0

    .end local v0    # "$this$invoke_u24lambda_u240_u240\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .local v47, "$this$invoke_u24lambda_u240_u240\\18":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x7d0a4402

    move-object/from16 v48, v2

    .end local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v2, "C30@2151L10,30@2105L111,32@2349L111:DeckDetailScreen.kt#i35lj1"

    move-object/from16 v77, v3

    move-object/from16 v3, v73

    .end local v73    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v77, "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v8}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getFront()Ljava/lang/String;

    move-result-object v51

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v72

    sget-object v0, Landroidx/compose/ui/text/style/TextOverflow;->Companion:Landroidx/compose/ui/text/style/TextOverflow$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/style/TextOverflow$Companion;->getEllipsis-gIe3tQ8()I

    move-result v67

    const/16 v75, 0x6180

    const v76, 0x1affe

    const/16 v52, 0x0

    const-wide/16 v53, 0x0

    const/16 v55, 0x0

    const-wide/16 v56, 0x0

    const/16 v58, 0x0

    const/16 v59, 0x0

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x2

    const/16 v70, 0x0

    const/16 v71, 0x0

    const/16 v74, 0x0

    .end local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v73    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v76}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 32
    .end local v73    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-virtual {v8}, Lcom/xunji/core/model/CardCandidate;->getSchedule()Lcom/xunji/core/model/CardSchedule;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/CardSchedule;->getPhase()Lcom/xunji/core/model/Phase;

    move-result-object v0

    sget-object v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v0}, Lcom/xunji/core/model/Phase;->ordinal()I

    move-result v0

    aget v0, v2, v0

    packed-switch v0, :pswitch_data_3d6

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    :pswitch_2f8
    const-string v0, "\u5df2\u5b66\u4e60"

    goto :goto_300

    :pswitch_2fb
    const-string v0, "\u5b66\u4e60\u4e2d"

    goto :goto_300

    :pswitch_2fe
    const-string v0, "\u65b0\u5361"

    .line 33
    .local v0, "label\\18":Ljava/lang/String;
    :goto_300
    invoke-virtual {v8}, Lcom/xunji/core/model/CardCandidate;->getSchedule()Lcom/xunji/core/model/CardSchedule;

    move-result-object v2

    invoke-virtual {v2}, Lcom/xunji/core/model/CardSchedule;->getPhase()Lcom/xunji/core/model/Phase;

    move-result-object v2

    move/from16 v51, v4

    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\17\\118\\11":I
    .local v51, "$i$a$-Layout-ColumnKt$Column$1\\17\\118\\11":I
    sget-object v4, Lcom/xunji/core/model/Phase;->NEW:Lcom/xunji/core/model/Phase;

    if-ne v2, v4, :cond_313

    const-string v2, " \u00b7 \u5c1a\u672a\u5f00\u59cb"

    move/from16 v52, v5

    goto :goto_334

    :cond_313
    invoke-virtual {v8}, Lcom/xunji/core/model/CardCandidate;->getSchedule()Lcom/xunji/core/model/CardSchedule;

    move-result-object v2

    invoke-virtual {v2}, Lcom/xunji/core/model/CardSchedule;->getDueAt()J

    move-result-wide v52

    invoke-static/range {v52 .. v53}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->localTime(J)Ljava/lang/String;

    move-result-object v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v52, v5

    .end local v5    # "$changed\\18":I
    .local v52, "$changed\\18":I
    const-string v5, " \u00b7 "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :goto_334
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v2, v5, v3, v5, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 31
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 34
    .end local v0    # "label\\18":Ljava/lang/String;
    nop

    .line 89
    .end local v3    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v44    # "$i$a$-Column-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$1\\18\\89\\9":I
    .end local v47    # "$this$invoke_u24lambda_u240_u240\\18":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v52    # "$changed\\18":I
    invoke-static/range {v48 .. v48}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 118
    .end local v24    # "$changed\\17":I
    .end local v48    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Layout-ColumnKt$Column$1\\17\\118\\11":I
    nop

    .line 119
    invoke-interface/range {v50 .. v50}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 98
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 120
    nop

    .line 92
    .end local v40    # "$i$f$ReusableComposeNode\\13\\96":I
    .end local v45    # "$changed\\13":I
    .end local v46    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 121
    nop

    .line 83
    .end local v19    # "compositeKeyHash\\12":I
    .end local v36    # "$changed\\12":I
    .end local v38    # "$i$f$Layout\\12\\88":I
    .end local v43    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v49    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v77    # "materialized\\12":Landroidx/compose/ui/Modifier;
    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 122
    nop

    .line 35
    .end local v6    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v33    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v34    # "$i$f$Column\\11\\30":I
    .end local v35    # "$changed\\11":I
    .end local v37    # "horizontalAlignment\\11":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v39    # "verticalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    const v0, -0x2280fe41

    const-string v2, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v1, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    invoke-interface {v1, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v0, v2

    .local v0, "invalid\\19":Z
    move-object v2, v1

    .local v2, "$this$cache\\19":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 123
    .local v3, "$i$f$cache\\19\\35":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\19":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 124
    .local v5, "$i$a$-let-ComposerKt$cache$1\\20\\123\\19":I
    if-nez v0, :cond_387

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_384

    goto :goto_387

    .line 128
    :cond_384
    move/from16 v18, v0

    goto :goto_396

    .line 125
    :cond_387
    :goto_387
    const/4 v6, 0x0

    .line 35
    .local v6, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2\\21\\125\\9":I
    move/from16 v18, v0

    .end local v0    # "invalid\\19":Z
    .local v18, "invalid\\19":Z
    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1;

    invoke-direct {v0, v8, v7, v9}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2$1;-><init>(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    check-cast v0, Lkotlin/jvm/functions/Function0;

    .line 125
    .end local v6    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1$2\\21\\125\\9":I
    nop

    .line 126
    .local v0, "value\\20":Ljava/lang/Object;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 127
    move-object v4, v0

    .line 123
    .end local v0    # "value\\20":Ljava/lang/Object;
    .end local v4    # "it\\19":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\20\\123\\19":I
    :goto_396
    nop

    .line 35
    .end local v2    # "$this$cache\\19":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\19\\35":I
    .end local v18    # "invalid\\19":Z
    move-object/from16 v35, v4

    check-cast v35, Lkotlin/jvm/functions/Function0;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v39, 0x36

    const/16 v40, 0x18

    const-string v33, "delete"

    const-string v34, "\u5220\u9664\u5361\u7247"

    const/16 v36, 0x0

    const/16 v37, 0x0

    move-object/from16 v38, v1

    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v33 .. v40}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 30
    move-object/from16 v2, v38

    .end local v38    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 36
    nop

    .line 52
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-Row-DeckDetailScreenKt$DeckDetailScreen$4$1$6$2$1\\9\\52\\0":I
    .end local v32    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v42    # "$changed\\9":I
    invoke-static/range {v28 .. v28}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 81
    .end local v25    # "$changed\\8":I
    .end local v28    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-Layout-RowKt$Row$1\\8\\81\\2":I
    nop

    .line 129
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 61
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 130
    nop

    .line 55
    .end local v20    # "$i$f$ReusableComposeNode\\4\\59":I
    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v23    # "$changed\\4":I
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 131
    nop

    .line 44
    .end local v15    # "$changed\\3":I
    .end local v17    # "$i$f$Layout\\3\\51":I
    .end local v21    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v29    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v30    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v31    # "compositeKeyHash\\3":I
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 132
    nop

    .end local v10    # "$changed\\2":I
    .end local v11    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$Row\\2\\29":I
    .end local v13    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v14    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v16    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v27    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_3d5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_3d5

    .line 28
    :cond_3d2
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 37
    :cond_3d5
    :goto_3d5
    return-void

    :pswitch_data_3d6
    .packed-switch 0x1
        :pswitch_2fe
        :pswitch_2fb
        :pswitch_2fb
        :pswitch_2f8
    .end packed-switch
.end method

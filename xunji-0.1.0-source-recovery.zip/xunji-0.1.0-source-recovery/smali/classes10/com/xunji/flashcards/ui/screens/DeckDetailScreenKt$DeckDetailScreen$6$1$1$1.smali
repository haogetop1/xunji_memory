.class final Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DeckDetailScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.screens.DeckDetailScreenKt$DeckDetailScreen$6$1$1$1"
    f = "DeckDetailScreen.kt"
    i = {}
    l = {
        0x28
    }
    m = "invokeSuspend"
    n = {}
    s = {}
    v = 0x1
.end annotation


# instance fields
.field final synthetic $busy$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $deleting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $error$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

.field label:I


# direct methods
.method constructor <init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/MainViewModel;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;-><init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 40
    iget v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->label:I

    const/4 v2, 0x0

    packed-switch v1, :pswitch_data_56

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12
    :try_start_12
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_15
    .catch Ljava/util/concurrent/CancellationException; {:try_start_12 .. :try_end_15} :catch_1a
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_15} :catch_18
    .catchall {:try_start_12 .. :try_end_15} :catchall_16

    goto :goto_37

    :catchall_16
    move-exception v0

    goto :goto_4f

    :catch_18
    move-exception v0

    goto :goto_43

    :catch_1a
    move-exception v0

    goto :goto_4e

    :pswitch_1c
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    :try_start_1f
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->access$DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/Continuation;

    const/4 v5, 0x1

    iput v5, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->label:I

    invoke-virtual {v1, v3, v4}, Lcom/xunji/flashcards/ui/MainViewModel;->deleteCard(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_37

    return-object v0

    :cond_37
    :goto_37
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v1, 0x0

    # invokes: Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->access$DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    :try_end_3d
    .catch Ljava/util/concurrent/CancellationException; {:try_start_1f .. :try_end_3d} :catch_1a
    .catch Ljava/lang/Exception; {:try_start_1f .. :try_end_3d} :catch_18
    .catchall {:try_start_1f .. :try_end_3d} :catchall_16

    :goto_3d
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V
    invoke-static {v0, v2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->access$DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V

    goto :goto_4b

    .local v0, "<unused var>":Ljava/lang/Exception;
    :goto_43
    :try_start_43
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    const-string v3, "\u5220\u9664\u672a\u5b8c\u6210\uff0c\u8bf7\u91cd\u8bd5"

    # invokes: Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$7(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v1, v3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->access$DeckDetailScreen$lambda$7(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    :try_end_4a
    .catchall {:try_start_43 .. :try_end_4a} :catchall_16

    .end local v0    # "<unused var>":Ljava/lang/Exception;
    goto :goto_3d

    :goto_4b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .end local p1    # "$result":Ljava/lang/Object;
    .local v0, "e":Ljava/util/concurrent/CancellationException;
    :goto_4e
    :try_start_4e
    throw v0
    :try_end_4f
    .catchall {:try_start_4e .. :try_end_4f} :catchall_16

    .end local v0    # "e":Ljava/util/concurrent/CancellationException;
    .restart local p1    # "$result":Ljava/lang/Object;
    :goto_4f
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V
    invoke-static {v1, v2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->access$DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V

    throw v0

    nop

    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_1c
        :pswitch_12
    .end packed-switch
.end method

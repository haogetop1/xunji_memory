.class public final Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;
.super Ljava/lang/Object;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$1\n*L\n1#1,171:1\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final INSTANCE:Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;

    invoke-direct {v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;-><init>()V

    sput-object v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;->INSTANCE:Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;

    return-void
.end method

.method public constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3
    .param p1, "p1"    # Ljava/lang/Object;

    .line 171
    invoke-virtual {p0, p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;->invoke(Ljava/lang/Object;)Ljava/lang/Void;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Ljava/lang/Object;)Ljava/lang/Void;
    .registers 3
    .param p1, "it"    # Ljava/lang/Object;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/core/model/CardCandidate;",
            ")",
            "Ljava/lang/Void;"
        }
    .end annotation

    .line 171
    const/4 v0, 0x0

    return-object v0
.end method

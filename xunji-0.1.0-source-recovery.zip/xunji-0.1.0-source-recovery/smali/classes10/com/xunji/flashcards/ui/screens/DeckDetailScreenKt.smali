.class public final Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;
.super Ljava/lang/Object;
.source "DeckDetailScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDeckDetailScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeckDetailScreen.kt\ncom/xunji/flashcards/ui/screens/DeckDetailScreenKt\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 5 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n+ 6 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 7 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 8 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 9 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 10 Composer.kt\nandroidx/compose/runtime/Updater\n+ 11 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 12 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n+ 13 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 14 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n*L\n1#1,42:1\n295#2,2:43\n774#2:45\n865#2,2:46\n1282#3,6:48\n1282#3,6:105\n1282#3,6:111\n1282#3,6:166\n1282#3,6:176\n1282#3,6:182\n607#4:54\n604#4,6:55\n605#5:61\n113#6:62\n113#6:104\n70#7:63\n67#7,9:64\n77#7:103\n80#8,6:73\n87#8,3:88\n90#8,2:97\n94#8:102\n80#8,6:139\n87#8,3:154\n90#8,2:163\n94#8:174\n80#8,6:199\n87#8,3:214\n90#8,2:223\n94#8:228\n391#9,9:79\n400#9,3:99\n391#9,9:145\n400#9:165\n401#9,2:172\n391#9,9:205\n400#9,3:225\n4360#10,6:91\n4360#10,6:157\n4360#10,6:217\n85#11:117\n117#11,2:118\n168#12,13:120\n99#13,6:133\n106#13:175\n87#14:188\n83#14,10:189\n94#14:229\n*S KotlinDebug\n*F\n+ 1 DeckDetailScreen.kt\ncom/xunji/flashcards/ui/screens/DeckDetailScreenKt\n*L\n18#1:43,2\n18#1:45\n18#1:46,2\n19#1:48,6\n22#1:105,6\n40#1:111,6\n25#1:166,6\n26#1:176,6\n40#1:182,6\n19#1:54\n19#1:55,6\n19#1:61\n21#1:62\n22#1:104\n21#1:63\n21#1:64,9\n21#1:103\n21#1:73,6\n21#1:88,3\n21#1:97,2\n21#1:102\n25#1:139,6\n25#1:154,3\n25#1:163,2\n25#1:174\n40#1:199,6\n40#1:214,3\n40#1:223,2\n40#1:228\n21#1:79,9\n21#1:99,3\n25#1:145,9\n25#1:165\n25#1:172,2\n40#1:205,9\n40#1:225,3\n21#1:91,6\n25#1:157,6\n40#1:217,6\n19#1:117\n19#1:118,2\n27#1:120,13\n25#1:133,6\n25#1:175\n40#1:188\n40#1:189,10\n40#1:229\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000,\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000b\u001aI\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00072\u0014\u0010\u0008\u001a\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u0003\u0012\u0004\u0012\u00020\u00010\t2\u000c\u0010\n\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u000bH\u0007\u00a2\u0006\u0002\u0010\u000c\u00a8\u0006\r\u00b2\u0006\u000c\u0010\u000e\u001a\u0004\u0018\u00010\u0003X\u008a\u008e\u0002\u00b2\u0006\u000c\u0010\u000f\u001a\u0004\u0018\u00010\u0003X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u008e\u0002"
    }
    d2 = {
        "DeckDetailScreen",
        "",
        "deckId",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/MainUiState;",
        "viewModel",
        "Lcom/xunji/flashcards/ui/MainViewModel;",
        "onEdit",
        "Lkotlin/Function1;",
        "onReview",
        "Lkotlin/Function0;",
        "(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "deleting",
        "error",
        "busy",
        ""
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$08HXMdDbl4gE_L0DrRutv-tbjrI(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$17$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$0c8_qXZsELQtfaMqN2V3bpWFlH8(Ljava/util/List;Lcom/xunji/core/model/DeckSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0(Ljava/util/List;Lcom/xunji/core/model/DeckSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$1swtYcXOW-3A7G2GDueManby1XY(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$11(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4SkVH469MRod-ILYb2y5U6NvHp4(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$17(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6ZMVFU6Q8Z0OQWmlfI0qS-Hf3eo(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$3(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7dGdYfFBcE8NRxIWgOlv4RQGccA(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$2$0$0$0(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$DdZVfE45VX3ItpsFG95giKA0zEA()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$2$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$J66Ref_U8LReRVcJsReFQWvmzGI(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$18(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Lo1-3VDy4jXpdNjz45UMRBxAHJs(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$3$0$0(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$V-EApQvXdJ83boSHBwCNG-lf4JY(Lcom/xunji/core/model/CardCandidate;)Ljava/lang/Object;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$4(Lcom/xunji/core/model/CardCandidate;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XZoXAA1359adqyI_OQ2U3V4AASI(Lcom/xunji/core/model/DeckSummary;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$0(Lcom/xunji/core/model/DeckSummary;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$clKtYS4DG_bVpfEsS_D8JZCn83U(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$19(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jf6iE36u_z86oUZ1VduW-n_7yTE(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$13(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$mqsxIWl-y2fP2QFFTfVLqB32iao(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$15$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ohRPn10oGZBYFbcuaNbDLckmV5c(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$2(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tBuUnEKIiP1cfmz3OUzHLYcBoU4(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$16(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tvTK0-2VGBFdYikZNGdtIdRPcrA(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$16$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$uig_OC24xlMnkJyLtuNr1GoOxXI(Lkotlin/jvm/functions/Function0;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$14$0$1(Lkotlin/jvm/functions/Function0;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 46
    .param p0, "deckId"    # Ljava/lang/String;
    .param p1, "state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p2, "viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p3, "onEdit"    # Lkotlin/jvm/functions/Function1;
    .param p4, "onReview"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/xunji/flashcards/ui/MainUiState;",
            "Lcom/xunji/flashcards/ui/MainViewModel;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    const-string v0, "deckId"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "state"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "viewModel"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onEdit"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onReview"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 17
    const v0, -0x17b35756

    move-object/from16 v7, p5

    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v11

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "$composer":Landroidx/compose/runtime/Composer;
    const-string v7, "C(DeckDetailScreen)N(deckId,state,viewModel,onEdit,onReview)18@831L33,18@814L50,18@878L42,18@933L34,18@978L24,21@1273L1285,21@1136L1422:DeckDetailScreen.kt#i35lj1"

    invoke-static {v11, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v7, p6

    .local v7, "$dirty":I
    and-int/lit8 v8, v6, 0x6

    if-nez v8, :cond_43

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_41

    const/4 v8, 0x4

    goto :goto_42

    :cond_41
    const/4 v8, 0x2

    :goto_42
    or-int/2addr v7, v8

    :cond_43
    and-int/lit8 v8, v6, 0x30

    if-nez v8, :cond_53

    invoke-interface {v11, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_50

    const/16 v8, 0x20

    goto :goto_52

    :cond_50
    const/16 v8, 0x10

    :goto_52
    or-int/2addr v7, v8

    :cond_53
    and-int/lit16 v8, v6, 0x180

    if-nez v8, :cond_63

    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_60

    const/16 v8, 0x100

    goto :goto_62

    :cond_60
    const/16 v8, 0x80

    :goto_62
    or-int/2addr v7, v8

    :cond_63
    and-int/lit16 v8, v6, 0xc00

    if-nez v8, :cond_73

    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_70

    const/16 v8, 0x800

    goto :goto_72

    :cond_70
    const/16 v8, 0x400

    :goto_72
    or-int/2addr v7, v8

    :cond_73
    and-int/lit16 v8, v6, 0x6000

    if-nez v8, :cond_83

    invoke-interface {v11, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_80

    const/16 v8, 0x4000

    goto :goto_82

    :cond_80
    const/16 v8, 0x2000

    :goto_82
    or-int/2addr v7, v8

    :cond_83
    move v14, v7

    .end local v7    # "$dirty":I
    .local v14, "$dirty":I
    and-int/lit16 v7, v14, 0x2493

    const/16 v8, 0x2492

    const/4 v13, 0x0

    if-eq v7, v8, :cond_8d

    const/4 v7, 0x1

    goto :goto_8e

    :cond_8d
    move v7, v13

    :goto_8e
    and-int/lit8 v8, v14, 0x1

    invoke-interface {v11, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_54d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_a2

    const/4 v7, -0x1

    const-string v8, "com.xunji.flashcards.ui.screens.DeckDetailScreen (DeckDetailScreen.kt:16)"

    invoke-static {v0, v14, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 18
    :cond_a2
    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$firstOrNull\\1":Ljava/lang/Iterable;
    const/4 v7, 0x0

    .line 43
    .local v7, "$i$f$firstOrNull\\1\\18":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v8

    :cond_ad
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    move-result v16

    if-eqz v16, :cond_cc

    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v16

    .local v16, "element\\1":Ljava/lang/Object;
    move-object/from16 v17, v16

    check-cast v17, Lcom/xunji/core/model/DeckSummary;

    .local v17, "it\\2":Lcom/xunji/core/model/DeckSummary;
    const/16 v18, 0x0

    .line 18
    .local v18, "$i$a$-firstOrNull-DeckDetailScreenKt$DeckDetailScreen$deck$1\\2\\43\\0":I
    invoke-virtual/range {v17 .. v17}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v19

    invoke-virtual/range {v19 .. v19}, Lcom/xunji/core/model/Deck;->getId()Ljava/lang/String;

    move-result-object v12

    invoke-static {v12, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v12

    .line 43
    .end local v17    # "it\\2":Lcom/xunji/core/model/DeckSummary;
    .end local v18    # "$i$a$-firstOrNull-DeckDetailScreenKt$DeckDetailScreen$deck$1\\2\\43\\0":I
    if-eqz v12, :cond_ad

    goto :goto_ce

    .line 44
    .end local v16    # "element\\1":Ljava/lang/Object;
    :cond_cc
    const/16 v16, 0x0

    .line 18
    .end local v0    # "$this$firstOrNull\\1":Ljava/lang/Iterable;
    .end local v7    # "$i$f$firstOrNull\\1\\18":I
    :goto_ce
    move-object/from16 v7, v16

    check-cast v7, Lcom/xunji/core/model/DeckSummary;

    .local v7, "deck":Lcom/xunji/core/model/DeckSummary;
    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/MainUiState;->getCards()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$filter\\3":Ljava/lang/Iterable;
    const/4 v8, 0x0

    .line 45
    .local v8, "$i$f$filter\\3\\18":I
    new-instance v12, Ljava/util/ArrayList;

    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    check-cast v12, Ljava/util/Collection;

    .local v12, "destination\\4":Ljava/util/Collection;
    move-object/from16 v16, v0

    .local v16, "$this$filterTo\\4":Ljava/lang/Iterable;
    const/16 v17, 0x0

    .line 46
    .local v17, "$i$f$filterTo\\4\\45":I
    invoke-interface/range {v16 .. v16}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v18

    :cond_e8
    :goto_e8
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    move-result v19

    if-eqz v19, :cond_10a

    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v15

    .local v15, "element\\4":Ljava/lang/Object;
    move-object/from16 v21, v15

    check-cast v21, Lcom/xunji/core/model/CardCandidate;

    .local v21, "it\\5":Lcom/xunji/core/model/CardCandidate;
    const/16 v22, 0x0

    .line 18
    .local v22, "$i$a$-filter-DeckDetailScreenKt$DeckDetailScreen$cards$1\\5\\46\\0":I
    invoke-virtual/range {v21 .. v21}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v23

    invoke-virtual/range {v23 .. v23}, Lcom/xunji/core/model/Flashcard;->getDeckId()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v9

    .line 46
    .end local v21    # "it\\5":Lcom/xunji/core/model/CardCandidate;
    .end local v22    # "$i$a$-filter-DeckDetailScreenKt$DeckDetailScreen$cards$1\\5\\46\\0":I
    if-eqz v9, :cond_e8

    invoke-interface {v12, v15}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    goto :goto_e8

    .line 47
    .end local v15    # "element\\4":Ljava/lang/Object;
    :cond_10a
    nop

    .end local v12    # "destination\\4":Ljava/util/Collection;
    .end local v16    # "$this$filterTo\\4":Ljava/lang/Iterable;
    .end local v17    # "$i$f$filterTo\\4\\45":I
    move-object v9, v12

    check-cast v9, Ljava/util/List;

    .line 45
    nop

    .line 18
    .end local v0    # "$this$filter\\3":Ljava/lang/Iterable;
    .end local v8    # "$i$f$filter\\3\\18":I
    nop

    .local v9, "cards":Ljava/util/List;
    new-array v0, v13, [Ljava/lang/Object;

    .line 19
    const v8, 0x7c547cb

    const-string v15, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {v11, v8, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v8, 0x0

    .local v8, "invalid\\6":Z
    move-object v12, v11

    .local v12, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 48
    .local v16, "$i$f$cache\\6\\19":I
    move/from16 v17, v13

    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\6":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 49
    .local v18, "$i$a$-let-ComposerKt$cache$1\\7\\48\\6":I
    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v13, v10, :cond_13b

    .line 50
    const/4 v10, 0x0

    .local v10, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$deleting$2\\8\\50\\0":I
    new-instance v21, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda16;

    invoke-direct/range {v21 .. v21}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda16;-><init>()V

    .end local v10    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$deleting$2\\8\\50\\0":I
    move-object/from16 v10, v21

    .line 51
    .local v10, "value\\7":Ljava/lang/Object;
    invoke-interface {v12, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 52
    move-object v13, v10

    .end local v10    # "value\\7":Ljava/lang/Object;
    goto :goto_13c

    .line 53
    :cond_13b
    nop

    .line 48
    .end local v13    # "it\\6":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\7\\48\\6":I
    :goto_13c
    nop

    .line 19
    .end local v8    # "invalid\\6":Z
    .end local v12    # "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\6\\19":I
    check-cast v13, Lkotlin/jvm/functions/Function0;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v8, 0x30

    invoke-static {v0, v13, v11, v8}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v0

    move-object v8, v0

    check-cast v8, Landroidx/compose/runtime/MutableState;

    .local v8, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    const v0, 0x7c54db4

    invoke-static {v11, v0, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\9":Z
    move-object v10, v11

    .local v10, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 48
    .local v12, "$i$f$cache\\9\\19":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\9":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 49
    .local v16, "$i$a$-let-ComposerKt$cache$1\\10\\48\\9":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v0

    .end local v0    # "invalid\\9":Z
    .local v21, "invalid\\9":Z
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v13, v0, :cond_174

    .line 50
    const/4 v0, 0x0

    .line 19
    .local v0, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$error$2\\11\\50\\0":I
    move/from16 v18, v0

    const/4 v0, 0x2

    const/4 v1, 0x0

    .end local v0    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$error$2\\11\\50\\0":I
    .local v18, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$error$2\\11\\50\\0":I
    invoke-static {v1, v1, v0, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v18

    .line 50
    .end local v18    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$error$2\\11\\50\\0":I
    move-object/from16 v0, v18

    .line 51
    .local v0, "value\\10":Ljava/lang/Object;
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 52
    move-object v13, v0

    .end local v0    # "value\\10":Ljava/lang/Object;
    goto :goto_175

    .line 53
    :cond_174
    nop

    .line 48
    .end local v13    # "it\\9":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\10\\48\\9":I
    :goto_175
    nop

    .line 19
    .end local v10    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\9\\19":I
    .end local v21    # "invalid\\9":Z
    move-object v10, v13

    check-cast v10, Landroidx/compose/runtime/MutableState;

    .local v10, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v0, 0x7c5548c

    invoke-static {v11, v0, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\12":Z
    move-object v1, v11

    .local v1, "$this$cache\\12":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 48
    .local v12, "$i$f$cache\\12\\19":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\12":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 49
    .local v16, "$i$a$-let-ComposerKt$cache$1\\13\\48\\12":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v0

    .end local v0    # "invalid\\12":Z
    .local v21, "invalid\\12":Z
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v0

    if-ne v13, v0, :cond_1a8

    .line 50
    const/4 v0, 0x0

    .line 19
    .local v0, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$busy$2\\14\\50\\0":I
    move/from16 v18, v0

    .end local v0    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$busy$2\\14\\50\\0":I
    .local v18, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$busy$2\\14\\50\\0":I
    invoke-static/range {v17 .. v17}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 50
    .end local v18    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$busy$2\\14\\50\\0":I
    nop

    .line 51
    .local v0, "value\\13":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 52
    move-object v13, v0

    .end local v0    # "value\\13":Ljava/lang/Object;
    goto :goto_1a9

    .line 53
    :cond_1a8
    nop

    .line 48
    .end local v13    # "it\\12":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\13\\48\\12":I
    :goto_1a9
    nop

    .line 19
    .end local v1    # "$this$cache\\12":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\12\\19":I
    .end local v21    # "invalid\\12":Z
    move-object v12, v13

    check-cast v12, Landroidx/compose/runtime/MutableState;

    .local v12, "busy$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v0, 0x0

    .local v0, "$changed\\15":I
    move-object v1, v11

    .local v1, "$composer\\15":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 54
    .local v2, "$i$f$rememberCoroutineScope\\15\\19":I
    const v3, 0x2e20b340

    const-string v13, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp"

    invoke-static {v1, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 55
    nop

    .line 59
    move-object v3, v1

    .line 60
    .local v3, "composer\\15":Landroidx/compose/runtime/Composer;
    const v13, 0x28c10104

    move/from16 v16, v0

    .end local v0    # "$changed\\15":I
    .local v16, "$changed\\15":I
    const-string v0, "CC(remember):Effects.kt#9igjgp"

    invoke-static {v1, v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\16":Z
    move-object v13, v1

    .local v13, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 48
    .local v18, "$i$f$cache\\16\\60":I
    move/from16 v21, v0

    .end local v0    # "invalid\\16":Z
    .local v21, "invalid\\16":Z
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\16":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 49
    .local v23, "$i$a$-let-ComposerKt$cache$1\\17\\48\\16":I
    sget-object v24, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v25, v1

    .end local v1    # "$composer\\15":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\15":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v0, v1, :cond_1f2

    .line 50
    const/4 v1, 0x0

    .line 60
    .local v1, "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\18\\50\\15":I
    const/16 v24, 0x0

    .line 61
    .local v24, "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\19\\60\\0":I
    sget-object v24, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 60
    .end local v24    # "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\19\\60\\0":I
    move-object/from16 v26, v0

    .end local v0    # "it\\16":Ljava/lang/Object;
    .local v26, "it\\16":Ljava/lang/Object;
    move-object/from16 v0, v24

    check-cast v0, Lkotlin/coroutines/CoroutineContext;

    invoke-static {v0, v3}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v0

    .line 50
    .end local v1    # "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\18\\50\\15":I
    nop

    .line 51
    .local v0, "value\\17":Ljava/lang/Object;
    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 52
    nop

    .end local v0    # "value\\17":Ljava/lang/Object;
    goto :goto_1f4

    .line 53
    .end local v26    # "it\\16":Ljava/lang/Object;
    .local v0, "it\\16":Ljava/lang/Object;
    :cond_1f2
    move-object/from16 v26, v0

    .line 48
    .end local v0    # "it\\16":Ljava/lang/Object;
    .end local v23    # "$i$a$-let-ComposerKt$cache$1\\17\\48\\16":I
    :goto_1f4
    nop

    .line 60
    .end local v13    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$f$cache\\16\\60":I
    .end local v21    # "invalid\\16":Z
    move-object v1, v0

    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 54
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 60
    nop

    .line 19
    .end local v2    # "$i$f$rememberCoroutineScope\\15\\19":I
    .end local v3    # "composer\\15":Landroidx/compose/runtime/Composer;
    .end local v16    # "$changed\\15":I
    .end local v25    # "$composer\\15":Landroidx/compose/runtime/Composer;
    move-object/from16 v16, v1

    .line 20
    .local v16, "scope":Lkotlinx/coroutines/CoroutineScope;
    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/MainUiState;->getLoading()Z

    move-result v0

    if-eqz v0, :cond_238

    const v0, -0xf197057

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "19@1022L6"

    invoke-static {v11, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v0, v17

    invoke-static {v11, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_223

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 41
    :cond_223
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v13

    if-eqz v13, :cond_237

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda17;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda17;-><init>(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v13, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 20
    :cond_237
    return-void

    :cond_238
    const v13, -0xf28ea68

    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 21
    if-nez v7, :cond_3b6

    const v0, -0xf18f01a

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "20@1054L71"

    invoke-static {v11, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x16

    .local v1, "$this$dp\\20":I
    const/4 v2, 0x0

    .line 62
    .local v2, "$i$f$getDp\\20\\21":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 21
    .end local v1    # "$this$dp\\20":I
    .end local v2    # "$i$f$getDp\\20\\21":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\21":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x6

    .local v1, "$changed\\21":I
    move-object v2, v11

    .local v2, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 63
    .local v3, "$i$f$Box\\21\\21":I
    const v4, 0x3e277f0a

    const-string v5, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v2, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 64
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 65
    .local v4, "contentAlignment\\21":Landroidx/compose/ui/Alignment;
    const/4 v5, 0x0

    .line 68
    .local v5, "propagateMinConstraints\\21":Z
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 72
    .local v6, "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v1, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 69
    nop

    .local v13, "$changed\\22":I
    move-object v15, v0

    .local v15, "modifier\\22":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    .line 73
    .local v18, "$i$f$Layout\\22\\69":I
    move-object/from16 p5, v0

    .end local v0    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local p5, "modifier\\21":Landroidx/compose/ui/Modifier;
    const v0, -0x451e1427

    move/from16 v19, v1

    .end local v1    # "$changed\\21":I
    .local v19, "$changed\\21":I
    const-string v1, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 74
    const/4 v0, 0x0

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 75
    .local v0, "compositeKeyHash\\22":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 76
    .local v1, "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v17, v0

    .end local v0    # "compositeKeyHash\\22":I
    .local v17, "compositeKeyHash\\22":I
    invoke-static {v2, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .line 78
    .local v0, "materialized\\22":Landroidx/compose/ui/Modifier;
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v20

    move/from16 v21, v3

    .end local v3    # "$i$f$Box\\21\\21":I
    .local v21, "$i$f$Box\\21\\21":I
    shl-int/lit8 v3, v13, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 77
    nop

    .local v3, "$changed\\23":I
    move-object/from16 v22, v20

    .local v22, "factory\\23":Lkotlin/jvm/functions/Function0;
    const/16 v20, 0x0

    .line 79
    .local v20, "$i$f$ReusableComposeNode\\23\\77":I
    move/from16 v23, v3

    .end local v3    # "$changed\\23":I
    .local v23, "$changed\\23":I
    const v3, -0x20f7d59c

    move-object/from16 v24, v4

    .end local v4    # "contentAlignment\\21":Landroidx/compose/ui/Alignment;
    .local v24, "contentAlignment\\21":Landroidx/compose/ui/Alignment;
    const-string v4, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v2, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 80
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_2c5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 81
    :cond_2c5
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 82
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_2d4

    .line 83
    move-object/from16 v3, v22

    .end local v22    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2d9

    .line 85
    .end local v3    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v22    # "factory\\23":Lkotlin/jvm/functions/Function0;
    :cond_2d4
    move-object/from16 v3, v22

    .end local v22    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 87
    :goto_2d9
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 88
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\24\\87\\22":I
    sget-object v25, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v26, v2

    .end local v2    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v26, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v25 .. v25}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 89
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 90
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\25":Lkotlin/jvm/functions/Function2;
    const/16 v25, 0x0

    .line 91
    .local v25, "$i$f$set-impl\\25\\90":I
    move-object/from16 v27, v4

    .local v27, "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 92
    .local v28, "$i$a$-with-Updater$set$1\\26\\91\\25":I
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v29

    if-nez v29, :cond_31b

    move-object/from16 v29, v1

    .end local v1    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .local v29, "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v30, v3

    .end local v3    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .local v30, "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_318

    goto :goto_31f

    :cond_318
    move-object/from16 v3, v27

    goto :goto_32f

    .end local v29    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v30    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "factory\\23":Lkotlin/jvm/functions/Function0;
    :cond_31b
    move-object/from16 v29, v1

    move-object/from16 v30, v3

    .line 93
    .end local v1    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "factory\\23":Lkotlin/jvm/functions/Function0;
    .restart local v29    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v30    # "factory\\23":Lkotlin/jvm/functions/Function0;
    :goto_31f
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v3, v27

    .end local v27    # "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v4, v1, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 96
    :goto_32f
    nop

    .line 91
    .end local v3    # "$this$set_impl_u24lambda_u240\\25":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-with-Updater$set$1\\26\\91\\25":I
    nop

    .line 96
    nop

    .line 97
    .end local v2    # "block\\25":Lkotlin/jvm/functions/Function2;
    .end local v25    # "$i$f$set-impl\\25\\90":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 98
    nop

    .line 87
    .end local v4    # "$this$Layout_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\24\\87\\22":I
    nop

    .line 99
    shr-int/lit8 v1, v23, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\27":I
    move-object/from16 v2, v26

    .local v2, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 70
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\27\\99\\21":I
    const v4, 0x6d423196

    move-object/from16 v22, v0

    .end local v0    # "materialized\\22":Landroidx/compose/ui/Modifier;
    .local v22, "materialized\\22":Landroidx/compose/ui/Modifier;
    const-string v0, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v4, v19, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\28":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$DeckDetailScreen_u24lambda_u2412\\28":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v35, v2

    .local v35, "$composer\\28":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 21
    .local v25, "$i$a$-Box-DeckDetailScreenKt$DeckDetailScreen$2\\28\\70\\0":I
    move-object/from16 v27, v0

    .end local v0    # "$this$DeckDetailScreen_u24lambda_u2412\\28":Landroidx/compose/foundation/layout/BoxScope;
    .local v27, "$this$DeckDetailScreen_u24lambda_u2412\\28":Landroidx/compose/foundation/layout/BoxScope;
    const v0, -0x1b600e65

    move/from16 v28, v1

    .end local v1    # "$changed\\27":I
    .local v28, "$changed\\27":I
    const-string v1, "C20@1085L38:DeckDetailScreen.kt#i35lj1"

    move-object/from16 v38, v2

    .end local v35    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v38, "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v36, 0x36

    const/16 v37, 0xc

    const-string v31, "\u724c\u7ec4\u5df2\u4e0d\u5b58\u5728"

    const-string v32, "\u8bf7\u8fd4\u56de\u724c\u7ec4\u5217\u8868\uff0c\u9009\u62e9\u5176\u5b83\u5185\u5bb9\u3002"

    const/16 v33, 0x0

    const/16 v34, 0x0

    .end local v2    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v35    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v31 .. v37}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    .end local v35    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 70
    .end local v2    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v4    # "$changed\\28":I
    .end local v25    # "$i$a$-Box-DeckDetailScreenKt$DeckDetailScreen$2\\28\\70\\0":I
    .end local v27    # "$this$DeckDetailScreen_u24lambda_u2412\\28":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 99
    .end local v3    # "$i$a$-Layout-BoxKt$Box$1\\27\\99\\21":I
    .end local v28    # "$changed\\27":I
    .end local v38    # "$composer\\27":Landroidx/compose/runtime/Composer;
    nop

    .line 100
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 79
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 101
    nop

    .line 73
    .end local v20    # "$i$f$ReusableComposeNode\\23\\77":I
    .end local v23    # "$changed\\23":I
    .end local v30    # "factory\\23":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 102
    nop

    .line 63
    .end local v13    # "$changed\\22":I
    .end local v15    # "modifier\\22":Landroidx/compose/ui/Modifier;
    .end local v17    # "compositeKeyHash\\22":I
    .end local v18    # "$i$f$Layout\\22\\69":I
    .end local v22    # "materialized\\22":Landroidx/compose/ui/Modifier;
    .end local v29    # "localMap\\22":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v26 .. v26}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 103
    nop

    .end local v5    # "propagateMinConstraints\\21":Z
    .end local v6    # "measurePolicy\\21":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "$changed\\21":I
    .end local v21    # "$i$f$Box\\21\\21":I
    .end local v24    # "contentAlignment\\21":Landroidx/compose/ui/Alignment;
    .end local v26    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local p5    # "modifier\\21":Landroidx/compose/ui/Modifier;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_39b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 41
    :cond_39b
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v13

    if-eqz v13, :cond_3b5

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda1;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v13, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 21
    :cond_3b5
    return-void

    :cond_3b6
    const/4 v0, 0x0

    invoke-interface {v11, v13}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 22
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v2, v4, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v17

    const/16 v1, 0x16

    .local v1, "$this$dp\\29":I
    const/4 v2, 0x0

    .line 104
    .local v2, "$i$f$getDp\\29\\22":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 22
    .end local v1    # "$this$dp\\29":I
    .end local v2    # "$i$f$getDp\\29\\22":I
    const/16 v2, 0x12

    .local v2, "$this$dp\\30":I
    const/4 v3, 0x0

    .line 104
    .local v3, "$i$f$getDp\\30\\22":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 22
    .end local v2    # "$this$dp\\30":I
    .end local v3    # "$i$f$getDp\\30\\22":I
    const/16 v3, 0x16

    .local v3, "$this$dp\\31":I
    const/4 v4, 0x0

    .line 104
    .local v4, "$i$f$getDp\\31\\22":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 22
    .end local v3    # "$this$dp\\31":I
    .end local v4    # "$i$f$getDp\\31\\22":I
    const/16 v4, 0x1c

    .local v4, "$this$dp\\32":I
    const/4 v5, 0x0

    .line 104
    .local v5, "$i$f$getDp\\32\\22":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 22
    .end local v4    # "$this$dp\\32":I
    .end local v5    # "$i$f$getDp\\32\\22":I
    invoke-static {v1, v2, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v18

    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v2, 0x10

    .local v2, "$this$dp\\33":I
    const/4 v3, 0x0

    .line 104
    .local v3, "$i$f$getDp\\33\\22":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 22
    .end local v2    # "$this$dp\\33":I
    .end local v3    # "$i$f$getDp\\33\\22":I
    invoke-virtual {v1, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    move-object/from16 v21, v1

    check-cast v21, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    const v1, 0x7c583ef

    invoke-static {v11, v1, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v11, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v11, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    or-int/2addr v1, v2

    const v2, 0xe000

    and-int/2addr v2, v14

    const/16 v3, 0x4000

    if-ne v2, v3, :cond_417

    const/4 v2, 0x1

    goto :goto_418

    :cond_417
    move v2, v0

    :goto_418
    or-int/2addr v1, v2

    and-int/lit16 v2, v14, 0x1c00

    const/16 v3, 0x800

    if-ne v2, v3, :cond_420

    const/4 v0, 0x1

    :cond_420
    or-int/2addr v0, v1

    invoke-interface {v11, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    .local v0, "invalid\\34":Z
    move-object v1, v11

    .local v1, "$this$cache\\34":Landroidx/compose/runtime/Composer;
    move/from16 v20, v0

    .end local v0    # "invalid\\34":Z
    .local v20, "invalid\\34":Z
    const/16 v22, 0x0

    .line 105
    .local v22, "$i$f$cache\\34\\22":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    .local v0, "it\\34":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 106
    .local v23, "$i$a$-let-ComposerKt$cache$1\\35\\105\\34":I
    if-nez v20, :cond_446

    sget-object v2, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v2}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v0, v2, :cond_43c

    goto :goto_446

    .line 110
    :cond_43c
    move-object/from16 v24, v7

    move-object/from16 v25, v9

    move-object/from16 v26, v10

    move-object v7, v1

    move-object v1, v0

    move-object v0, v8

    goto :goto_464

    .line 107
    :cond_446
    :goto_446
    const/16 v24, 0x0

    .line 22
    .local v24, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4\\36\\107\\0":I
    move-object v2, v0

    .end local v0    # "it\\34":Ljava/lang/Object;
    .local v2, "it\\34":Ljava/lang/Object;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda2;

    move-object/from16 v4, p3

    move-object/from16 v3, p4

    move-object v5, v8

    move-object v6, v10

    move-object v8, v2

    move-object v2, v7

    move-object v7, v1

    move-object v1, v9

    .end local v9    # "cards":Ljava/util/List;
    .end local v10    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "cards":Ljava/util/List;
    .local v2, "deck":Lcom/xunji/core/model/DeckSummary;
    .local v5, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v6, "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "$this$cache\\34":Landroidx/compose/runtime/Composer;
    .local v8, "it\\34":Ljava/lang/Object;
    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda2;-><init>(Ljava/util/List;Lcom/xunji/core/model/DeckSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 107
    move-object/from16 v25, v1

    move-object/from16 v24, v2

    move-object/from16 v26, v6

    move-object v1, v0

    move-object v0, v5

    .line 108
    .end local v2    # "deck":Lcom/xunji/core/model/DeckSummary;
    .end local v5    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v6    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v0, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "value\\35":Ljava/lang/Object;
    .local v24, "deck":Lcom/xunji/core/model/DeckSummary;
    .local v25, "cards":Ljava/util/List;
    .local v26, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 109
    nop

    .line 105
    .end local v1    # "value\\35":Ljava/lang/Object;
    .end local v8    # "it\\34":Ljava/lang/Object;
    .end local v23    # "$i$a$-let-ComposerKt$cache$1\\35\\105\\34":I
    :goto_464
    nop

    .line 22
    .end local v7    # "$this$cache\\34":Landroidx/compose/runtime/Composer;
    .end local v20    # "invalid\\34":Z
    .end local v22    # "$i$f$cache\\34\\22":I
    move-object v10, v1

    check-cast v10, Lkotlin/jvm/functions/Function1;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v4, v12

    .end local v12    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v12, 0x6186

    move v1, v13

    const/16 v13, 0x1ea

    const/4 v2, 0x0

    move-object v3, v4

    .end local v4    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v3, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    move/from16 v20, v14

    move-object/from16 v1, v17

    move-object/from16 v5, v21

    move-object v14, v3

    move-object/from16 v3, v18

    .end local v3    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v14, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v20, "$dirty":I
    invoke-static/range {v1 .. v13}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 40
    invoke-static {v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_534

    const v1, 0x7c6241f

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "39@2607L24,39@2755L280,39@3050L60,39@2661L79,39@2578L533"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v1, 0x7c625c2

    invoke-static {v11, v1, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\37":Z
    move-object v2, v11

    .local v2, "$this$cache\\37":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 111
    .local v3, "$i$f$cache\\37\\40":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\37":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 112
    .local v5, "$i$a$-let-ComposerKt$cache$1\\38\\111\\37":I
    if-nez v1, :cond_4b2

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_4b1

    goto :goto_4b2

    .line 116
    :cond_4b1
    goto :goto_4bd

    .line 113
    :cond_4b2
    :goto_4b2
    const/4 v6, 0x0

    .line 40
    .local v6, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$5\\39\\113\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v7, v14, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda3;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 113
    .end local v6    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$5\\39\\113\\0":I
    nop

    .line 114
    .local v7, "value\\38":Ljava/lang/Object;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 115
    move-object v4, v7

    .line 111
    .end local v4    # "it\\37":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\38\\111\\37":I
    .end local v7    # "value\\38":Ljava/lang/Object;
    :goto_4bd
    nop

    .line 40
    .end local v1    # "invalid\\37":Z
    .end local v2    # "$this$cache\\37":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\37\\40":I
    move-object v6, v4

    check-cast v6, Lkotlin/jvm/functions/Function0;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v3, v0

    .end local v0    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v3, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda4;

    move-object/from16 v2, p2

    move-object v4, v14

    move-object/from16 v1, v16

    move-object/from16 v5, v26

    .end local v14    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local v16    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v26    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v4, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda4;-><init>(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object v2, v3

    move-object v3, v0

    move-object v0, v2

    move-object/from16 v23, v1

    move-object v2, v4

    move-object v1, v5

    .end local v3    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v4    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local v5    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v0    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v23, "scope":Lkotlinx/coroutines/CoroutineScope;
    const v4, 0x25d37635

    const/16 v5, 0x36

    const/4 v7, 0x1

    invoke-static {v4, v7, v3, v11, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    new-instance v4, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v4, v0, v2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda5;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v8, -0x33c3ff8d    # -4.9283532E7f

    invoke-static {v8, v7, v4, v11, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function2;

    sget-object v8, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;

    invoke-virtual {v8}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->getLambda$1923386033$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    new-instance v9, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v9, v1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/runtime/MutableState;)V

    const v10, 0x45d8cfd0

    invoke-static {v10, v7, v9, v11, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object v7, v5

    check-cast v7, Lkotlin/jvm/functions/Function2;

    const/16 v21, 0x0

    const/16 v22, 0x3f94

    move-object v14, v2

    move-object v2, v3

    .end local v2    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v14    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/4 v3, 0x0

    const/4 v5, 0x0

    move-object/from16 v26, v1

    move-object v1, v6

    move-object v6, v8

    .end local v1    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v26    # "error$delegate":Landroidx/compose/runtime/MutableState;
    const/4 v8, 0x0

    const-wide/16 v9, 0x0

    move-object/from16 v19, v11

    .end local v11    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    const-wide/16 v11, 0x0

    move-object v15, v14

    .end local v14    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v15, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v13, 0x0

    move-object/from16 v17, v15

    .end local v15    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v17, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const-wide/16 v15, 0x0

    move-object/from16 v18, v17

    .end local v17    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v18, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v17, 0x0

    move-object/from16 v27, v18

    .end local v18    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v27, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v18, 0x0

    move/from16 v28, v20

    .end local v20    # "$dirty":I
    .local v28, "$dirty":I
    const v20, 0x1b0c30

    invoke-static/range {v1 .. v22}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v11, v19

    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_540

    .end local v23    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v27    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local v28    # "$dirty":I
    .restart local v14    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v16    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v20    # "$dirty":I
    :cond_534
    move-object/from16 v27, v14

    move-object/from16 v23, v16

    move/from16 v28, v20

    .end local v14    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local v16    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v20    # "$dirty":I
    .restart local v23    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v27    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v28    # "$dirty":I
    const v1, -0xf28ea68

    invoke-interface {v11, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_540
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_552

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v23    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v24    # "deck":Lcom/xunji/core/model/DeckSummary;
    .end local v25    # "cards":Ljava/util/List;
    .end local v26    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .end local v27    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    goto :goto_552

    .line 17
    .end local v28    # "$dirty":I
    .local v14, "$dirty":I
    :cond_54d
    move/from16 v28, v14

    .end local v14    # "$dirty":I
    .restart local v28    # "$dirty":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 41
    :cond_552
    :goto_552
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_56c

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda7;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda7;-><init>(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_56c
    return-void
.end method

.method private static final DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 19
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 118
    .local v4, "$i$f$setValue\\1\\19":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 119
    nop

    .line 19
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\19":I
    return-void
.end method

.method private static final DeckDetailScreen$lambda$11(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeckDetailScreen$lambda$13(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeckDetailScreen$lambda$14$0(Ljava/util/List;Lcom/xunji/core/model/DeckSummary;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 23
    .param p0, "$cards"    # Ljava/util/List;
    .param p1, "$deck"    # Lcom/xunji/core/model/DeckSummary;
    .param p2, "$onReview"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$onEdit"    # Lkotlin/jvm/functions/Function1;
    .param p4, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p5, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p6, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    const-string v2, "$this$LazyColumn"

    move-object/from16 v3, p6

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    new-instance v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda0;

    move-object/from16 v9, p1

    invoke-direct {v2, v9, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/core/model/DeckSummary;Ljava/util/List;)V

    const v4, -0x1d8fc741

    const/4 v10, 0x1

    invoke-static {v4, v10, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lkotlin/jvm/functions/Function3;

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 24
    new-instance v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda9;

    move-object/from16 v11, p2

    invoke-direct {v2, v11, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda9;-><init>(Lkotlin/jvm/functions/Function0;Ljava/util/List;)V

    const v3, 0x4d65a6b6    # 2.4080675E8f

    invoke-static {v3, v10, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lkotlin/jvm/functions/Function3;

    move-object/from16 v3, p6

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 25
    new-instance v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v2, v1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda10;-><init>(Lkotlin/jvm/functions/Function1;)V

    const v3, -0x2a23b609

    invoke-static {v3, v10, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lkotlin/jvm/functions/Function3;

    move-object/from16 v3, p6

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 26
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v2

    if-eqz v2, :cond_6c

    new-instance v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v2, v1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda11;-><init>(Lkotlin/jvm/functions/Function1;)V

    const v3, -0x12a9ba26

    invoke-static {v3, v10, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v6, v2

    check-cast v6, Lkotlin/jvm/functions/Function3;

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    move-object/from16 v3, p6

    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 27
    :cond_6c
    new-instance v2, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda12;

    invoke-direct {v2}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda12;-><init>()V

    .local v2, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object/from16 v3, p0

    .local v3, "items\\1":Ljava/util/List;
    move-object/from16 v4, p6

    .line 120
    .local v4, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    nop

    .line 123
    sget-object v5, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;->INSTANCE:Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$1;

    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 120
    .local v5, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v6, 0x0

    .line 126
    .local v6, "$i$f$items\\1\\27":I
    nop

    .line 127
    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v7

    .line 128
    nop

    .line 126
    new-instance v8, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$2;

    invoke-direct {v8, v2, v3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v8, Lkotlin/jvm/functions/Function1;

    new-instance v12, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$3;

    invoke-direct {v12, v5, v3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 130
    new-instance v13, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$4;

    move-object/from16 v14, p4

    move-object/from16 v15, p5

    invoke-direct {v13, v3, v1, v14, v15}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$lambda$14$0$$inlined$items$default$4;-><init>(Ljava/util/List;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v0, 0x2fd4df92

    invoke-static {v0, v10, v13}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function4;

    .line 126
    invoke-interface {v4, v7, v8, v12, v0}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 132
    nop

    .line 39
    .end local v2    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v3    # "items\\1":Ljava/util/List;
    .end local v4    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v5    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v6    # "$i$f$items\\1\\27":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$14$0$0(Lcom/xunji/core/model/DeckSummary;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10
    .param p0, "$deck"    # Lcom/xunji/core/model/DeckSummary;
    .param p1, "$cards"    # Ljava/util/List;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C22@1284L68:DeckDetailScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eq v0, v1, :cond_13

    const/4 v0, 0x1

    goto :goto_14

    :cond_13
    move v0, v2

    :goto_14
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_65

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2b

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:22)"

    const v3, -0x1d8fc741

    invoke-static {v3, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 23
    :cond_2b
    invoke-virtual {p0}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Deck;->getName()Ljava/lang/String;

    move-result-object v0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v1

    invoke-virtual {p0}, Lcom/xunji/core/model/DeckSummary;->getDue()I

    move-result v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " \u5f20\u5361\u7247 \u00b7 "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " \u5f20\u5230\u671f\u590d\u4e60"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1, p3, v2, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->SectionTitle(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_68

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_68

    :cond_65
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_68
    :goto_68
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$14$0$1(Lkotlin/jvm/functions/Function0;Ljava/util/List;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16
    .param p0, "$onReview"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$cards"    # Ljava/util/List;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C23@1364L78:DeckDetailScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x1

    if-eq v0, v1, :cond_13

    move v0, v2

    goto :goto_14

    :cond_13
    const/4 v0, 0x0

    :goto_14
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_4b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2b

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:23)"

    const v3, 0x4d65a6b6    # 2.4080675E8f

    invoke-static {v3, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 24
    :cond_2b
    move-object v0, p1

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    move-result v0

    xor-int/lit8 v6, v0, 0x1

    const/16 v9, 0x6006

    const/4 v10, 0x4

    const-string v3, "\u590d\u4e60\u8fd9\u4e2a\u724c\u7ec4"

    const/4 v5, 0x0

    const-string v7, "review-start"

    move-object v4, p0

    move-object v8, p3

    .end local p0    # "$onReview":Lkotlin/jvm/functions/Function0;
    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$onReview":Lkotlin/jvm/functions/Function0;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_50

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_50

    .end local v4    # "$onReview":Lkotlin/jvm/functions/Function0;
    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p0    # "$onReview":Lkotlin/jvm/functions/Function0;
    .restart local p3    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_4b
    move-object v4, p0

    move-object v8, p3

    .end local p0    # "$onReview":Lkotlin/jvm/functions/Function0;
    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$onReview":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_50
    :goto_50
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeckDetailScreen$lambda$14$0$2(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 56
    .param p0, "$onEdit"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    move/from16 v2, p3

    const-string v3, "$this$item"

    move-object/from16 v4, p1

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C24@1454L230:DeckDetailScreen.kt#i35lj1"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    const/4 v7, 0x1

    if-eq v3, v5, :cond_1b

    move v3, v7

    goto :goto_1c

    :cond_1b
    const/4 v3, 0x0

    :goto_1c
    and-int/lit8 v5, v2, 0x1

    invoke-interface {v1, v3, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_1f1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_33

    const/4 v3, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:24)"

    const v8, -0x2a23b609

    invoke-static {v8, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 25
    :cond_33
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v8, 0x0

    invoke-static {v3, v5, v7, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v5}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v5

    check-cast v5, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v5, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .local v7, "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v8, 0x1b6

    .local v8, "$changed\\1":I
    move-object/from16 v9, p2

    .local v9, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 133
    .local v10, "$i$f$Row\\1\\25":I
    const v11, 0x3255a44b

    const-string v12, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v9, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 134
    shr-int/lit8 v11, v8, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v8, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v5, v7, v9, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 138
    .local v11, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v8, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 135
    nop

    .local v12, "$changed\\2":I
    move-object v13, v3

    .local v13, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v14, 0x0

    .line 139
    .local v14, "$i$f$Layout\\2\\135":I
    const v15, -0x451e1427

    const-string v6, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v15, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 140
    const/4 v6, 0x0

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v15

    invoke-static/range {v15 .. v16}, Ljava/lang/Long;->hashCode(J)I

    move-result v6

    .line 141
    .local v6, "compositeKeyHash\\2":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 142
    .local v15, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 144
    .local v1, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v2, v12, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 143
    move-object/from16 v17, v16

    .local v2, "$changed\\3":I
    .local v17, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 145
    .local v16, "$i$f$ReusableComposeNode\\3\\143":I
    move/from16 v18, v2

    .end local v2    # "$changed\\3":I
    .local v18, "$changed\\3":I
    const v2, -0x20f7d59c

    move-object/from16 v19, v3

    .end local v3    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v19, "modifier\\1":Landroidx/compose/ui/Modifier;
    const-string v3, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 146
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_ac

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 147
    :cond_ac
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 148
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_bb

    .line 149
    move-object/from16 v2, v17

    .end local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c0

    .line 151
    .end local v2    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_bb
    move-object/from16 v2, v17

    .end local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 153
    :goto_c0
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 154
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\153\\2":I
    sget-object v20, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v21, v2

    .end local v2    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v21, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v11, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 155
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v15, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 156
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v20, 0x0

    .line 157
    .local v20, "$i$f$set-impl\\5\\156":I
    move-object/from16 v22, v3

    .local v22, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 158
    .local v23, "$i$a$-with-Updater$set$1\\6\\157\\5":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v24

    if-nez v24, :cond_100

    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v24, v5

    .end local v5    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v24, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_fd

    goto :goto_102

    :cond_fd
    move-object/from16 v5, v22

    goto :goto_112

    .end local v24    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v5    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_100
    move-object/from16 v24, v5

    .line 159
    .end local v5    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v24    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_102
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v5, v22

    .end local v22    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 160
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v3, v4, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 162
    :goto_112
    nop

    .line 157
    .end local v5    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-with-Updater$set$1\\6\\157\\5":I
    nop

    .line 162
    nop

    .line 163
    .end local v2    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v20    # "$i$f$set-impl\\5\\156":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 164
    nop

    .line 153
    .end local v3    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\153\\2":I
    nop

    .line 165
    shr-int/lit8 v2, v18, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\7":I
    move-object v3, v9

    .local v3, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 136
    .local v4, "$i$a$-Layout-RowKt$Row$1\\7\\165\\1":I
    const v5, 0x56ccd6f5

    move-object/from16 v17, v1

    .end local v1    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v17, "materialized\\2":Landroidx/compose/ui/Modifier;
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v8, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\8":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$DeckDetailScreen_u24lambda_u2414_u240_u242_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v47, v3

    .local v47, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 25
    .local v20, "$i$a$-Row-DeckDetailScreenKt$DeckDetailScreen$4$1$3$1\\8\\136\\0":I
    move-object/from16 v22, v1

    .end local v1    # "$this$DeckDetailScreen_u24lambda_u2414_u240_u242_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .local v22, "$this$DeckDetailScreen_u24lambda_u2414_u240_u242_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    const v1, -0x72a26c1

    move/from16 v23, v2

    .end local v2    # "$changed\\7":I
    .local v23, "$changed\\7":I
    const-string v2, "C24@1609L10,24@1577L54,24@1656L14,24@1632L50:DeckDetailScreen.kt#i35lj1"

    move-object/from16 v51, v3

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v51, "$composer\\7":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v46

    const/16 v49, 0x0

    const v50, 0x1fffe

    const-string v25, "\u6240\u6709\u5361\u7247"

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v48, 0x6

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v25 .. v50}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    const v1, -0x6353e737

    const-string v2, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\9":Z
    move-object v2, v3

    .local v2, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 166
    .local v25, "$i$f$cache\\9\\25":I
    move/from16 v26, v1

    .end local v1    # "invalid\\9":Z
    .local v26, "invalid\\9":Z
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\9":Ljava/lang/Object;
    const/16 v27, 0x0

    .line 167
    .local v27, "$i$a$-let-ComposerKt$cache$1\\10\\166\\9":I
    if-nez v26, :cond_1a9

    sget-object v28, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v47, v3

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v28 .. v28}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v1, v3, :cond_1a8

    goto :goto_1ab

    .line 171
    :cond_1a8
    goto :goto_1b8

    .line 167
    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    :cond_1a9
    move-object/from16 v47, v3

    .line 168
    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    :goto_1ab
    const/4 v3, 0x0

    .line 25
    .local v3, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$3$1$1\\11\\168\\8":I
    move-object/from16 v28, v1

    .end local v1    # "it\\9":Ljava/lang/Object;
    .local v28, "it\\9":Ljava/lang/Object;
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v1, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda8;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 168
    .end local v3    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$3$1$1\\11\\168\\8":I
    nop

    .line 169
    .local v1, "value\\10":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 170
    nop

    .line 166
    .end local v1    # "value\\10":Ljava/lang/Object;
    .end local v27    # "$i$a$-let-ComposerKt$cache$1\\10\\166\\9":I
    .end local v28    # "it\\9":Ljava/lang/Object;
    :goto_1b8
    nop

    .line 25
    .end local v2    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$f$cache\\9\\25":I
    .end local v26    # "invalid\\9":Z
    move-object/from16 v27, v1

    check-cast v27, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v31, 0xc36

    const/16 v32, 0x10

    const-string v25, "add"

    const-string v26, "\u65b0\u589e\u5361\u7247"

    const-string v28, "add-card"

    const/16 v29, 0x0

    move-object/from16 v30, v47

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v25 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .end local v30    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 136
    .end local v5    # "$changed\\8":I
    .end local v20    # "$i$a$-Row-DeckDetailScreenKt$DeckDetailScreen$4$1$3$1\\8\\136\\0":I
    .end local v22    # "$this$DeckDetailScreen_u24lambda_u2414_u240_u242_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 165
    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\7\\165\\1":I
    .end local v23    # "$changed\\7":I
    .end local v51    # "$composer\\7":Landroidx/compose/runtime/Composer;
    nop

    .line 172
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 145
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 173
    nop

    .line 139
    .end local v16    # "$i$f$ReusableComposeNode\\3\\143":I
    .end local v18    # "$changed\\3":I
    .end local v21    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 174
    nop

    .line 133
    .end local v6    # "compositeKeyHash\\2":I
    .end local v12    # "$changed\\2":I
    .end local v13    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v14    # "$i$f$Layout\\2\\135":I
    .end local v15    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v17    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 175
    nop

    .end local v7    # "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    .end local v8    # "$changed\\1":I
    .end local v9    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$Row\\1\\25":I
    .end local v11    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v24    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1f4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1f4

    .line 25
    :cond_1f1
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1f4
    :goto_1f4
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final DeckDetailScreen$lambda$14$0$2$0$0$0(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .registers 2
    .param p0, "$onEdit"    # Lkotlin/jvm/functions/Function1;

    .line 25
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$14$0$3(Lkotlin/jvm/functions/Function1;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 15
    .param p0, "$onEdit"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C25@1770L14,25@1715L70:DeckDetailScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    if-eq v0, v1, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_72

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous>.<anonymous>.<anonymous> (DeckDetailScreen.kt:25)"

    const v2, -0x12a9ba26

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 26
    :cond_2a
    const v0, -0xf23c178

    const-string v1, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {p2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p2, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    move-object v1, p2

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 176
    .local v2, "$i$f$cache\\1\\26":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\1":Ljava/lang/Object;
    const/4 v4, 0x0

    .line 177
    .local v4, "$i$a$-let-ComposerKt$cache$1\\2\\176\\1":I
    if-nez v0, :cond_49

    sget-object v5, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v5}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v3, v5, :cond_48

    goto :goto_49

    .line 181
    :cond_48
    goto :goto_54

    .line 178
    :cond_49
    :goto_49
    const/4 v5, 0x0

    .line 26
    .local v5, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$4$1\\3\\178\\0":I
    new-instance v6, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v6, p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda13;-><init>(Lkotlin/jvm/functions/Function1;)V

    .line 178
    .end local v5    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$4$1$4$1\\3\\178\\0":I
    nop

    .line 179
    .local v6, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 180
    move-object v3, v6

    .line 176
    .end local v3    # "it\\1":Ljava/lang/Object;
    .end local v4    # "$i$a$-let-ComposerKt$cache$1\\2\\176\\1":I
    .end local v6    # "value\\2":Ljava/lang/Object;
    :goto_54
    nop

    .line 26
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\1\\26":I
    move-object v7, v3

    check-cast v7, Lkotlin/jvm/functions/Function0;

    invoke-static {p2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v9, 0x1b6

    const/4 v10, 0x0

    const-string v4, "\u7559\u4e0b\u4e00\u70b9\u65b0\u77e5\u8bc6"

    const-string v5, "\u6b63\u9762\u5199\u95ee\u9898\uff0c\u80cc\u9762\u5199\u7b54\u6848\u3002\u4f8b\u53e5\u8ba9\u8bb0\u5fc6\u6709\u4e0a\u4e0b\u6587\u3002"

    const-string v6, "\u521b\u5efa\u7b2c\u4e00\u5f20\u5361"

    move-object v8, p2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v4 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p2

    if-eqz p2, :cond_76

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_76

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p2    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_72
    move-object v8, p2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v8    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_76
    :goto_76
    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p2
.end method

.method private static final DeckDetailScreen$lambda$14$0$3$0$0(Lkotlin/jvm/functions/Function1;)Lkotlin/Unit;
    .registers 2
    .param p0, "$onEdit"    # Lkotlin/jvm/functions/Function1;

    .line 26
    const/4 v0, 0x0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$14$0$4(Lcom/xunji/core/model/CardCandidate;)Ljava/lang/Object;
    .registers 2
    .param p0, "it"    # Lcom/xunji/core/model/CardCandidate;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 27
    invoke-virtual {p0}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$15$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 40
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$9(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_a

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    :cond_a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$16(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 22
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p2, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v10, p5

    move/from16 v13, p6

    const-string v0, "C39@2768L195,39@2757L276:DeckDetailScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_91

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)"

    const v3, 0x25d37635

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_29
    const v0, -0x13140a8

    const-string v1, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    move-object/from16 v6, p1

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    move-object/from16 v7, p2

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    .local v0, "invalid\\1":Z
    move-object/from16 v1, p5

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 182
    .local v9, "$i$f$cache\\1\\40":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 183
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\182\\1":I
    if-nez v0, :cond_57

    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v11, v3, :cond_56

    goto :goto_57

    .line 187
    :cond_56
    goto :goto_67

    .line 184
    :cond_57
    :goto_57
    const/4 v14, 0x0

    .line 40
    .local v14, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$6$1\\3\\184\\0":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda15;

    move-object v4, p0

    move-object/from16 v5, p3

    move-object/from16 v8, p4

    invoke-direct/range {v3 .. v8}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda15;-><init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 184
    .end local v14    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$6$1\\3\\184\\0":I
    nop

    .line 185
    .local v3, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 186
    move-object v11, v3

    .line 182
    .end local v3    # "value\\2":Ljava/lang/Object;
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\182\\1":I
    :goto_67
    nop

    .line 40
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\1\\40":I
    move-object v0, v11

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static/range {p3 .. p3}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$9(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    xor-int/2addr v2, v1

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->getLambda$-1805515944$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/high16 v11, 0x30000000

    const/16 v12, 0x1fa

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_94

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_94

    :cond_91
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_94
    :goto_94
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$16$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 13
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p3, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$error$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 40
    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$9(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_1f

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;

    const/4 v6, 0x0

    move-object v5, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-direct/range {v1 .. v6}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$DeckDetailScreen$6$1$1$1;-><init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    move-object v5, v1

    check-cast v5, Lkotlin/jvm/functions/Function2;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v2, p0

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    :cond_1f
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$17(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v10, p2

    move/from16 v13, p3

    const-string v0, "C39@3063L15,39@3052L56:DeckDetailScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_7e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)"

    const v3, -0x33c3ff8d    # -4.9283532E7f

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_29
    const v0, -0x52c24e9e

    const-string v1, "CC(remember):DeckDetailScreen.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    move-object/from16 v1, p2

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 182
    .local v3, "$i$f$cache\\1\\40":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 183
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\182\\1":I
    if-nez v0, :cond_49

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_48

    goto :goto_49

    .line 187
    :cond_48
    goto :goto_54

    .line 184
    :cond_49
    :goto_49
    const/4 v6, 0x0

    .line 40
    .local v6, "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$7$1\\3\\184\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v7, p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt$$ExternalSyntheticLambda14;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 184
    .end local v6    # "$i$a$-cache-DeckDetailScreenKt$DeckDetailScreen$7$1\\3\\184\\0":I
    nop

    .line 185
    .local v7, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 186
    move-object v4, v7

    .line 182
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\182\\1":I
    .end local v7    # "value\\2":Ljava/lang/Object;
    :goto_54
    nop

    .line 40
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\40":I
    move-object v0, v4

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$9(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    xor-int/2addr v2, v1

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DeckDetailScreenKt;->getLambda$986353046$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/high16 v11, 0x30000000

    const/16 v12, 0x1fa

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_81

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_81

    :cond_7e
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_81
    :goto_81
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$17$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 40
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$18(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 55
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C39@2663L75:DeckDetailScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x0

    if-eq v2, v3, :cond_11

    const/4 v2, 0x1

    goto :goto_12

    :cond_11
    move v2, v5

    :goto_12
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1ba

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.DeckDetailScreen.<anonymous> (DeckDetailScreen.kt:39)"

    const v6, 0x45d8cfd0

    invoke-static {v6, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_29
    move-object/from16 v2, p1

    .local v2, "$composer\\1":Landroidx/compose/runtime/Composer;
    move v3, v5

    .local v3, "$changed\\1":I
    const/4 v6, 0x0

    .line 188
    .local v6, "$i$f$Column\\1\\40":I
    const v7, 0x4ff7456f

    const-string v8, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v2, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 189
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    .line 190
    .local v7, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 191
    .local v8, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 194
    .local v9, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v8, v9, v2, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 198
    .local v10, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 195
    nop

    .local v11, "$changed\\2":I
    move-object v12, v7

    .local v12, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 199
    .local v13, "$i$f$Layout\\2\\195":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v2, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 200
    invoke-static {v2, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 201
    .local v14, "compositeKeyHash\\2":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 202
    .local v15, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 204
    .local v4, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v5, v11, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 203
    move-object/from16 v18, v17

    .local v5, "$changed\\3":I
    .local v18, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 205
    .local v17, "$i$f$ReusableComposeNode\\3\\203":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_94

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 207
    :cond_94
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 208
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_a3

    .line 209
    move-object/from16 v0, v18

    .end local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a8

    .line 211
    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_a3
    move-object/from16 v0, v18

    .end local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 213
    :goto_a8
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 214
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v20, v0

    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v20, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 215
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 216
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 217
    .local v19, "$i$f$set-impl\\5\\216":I
    move-object/from16 v21, v1

    .local v21, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 218
    .local v22, "$i$a$-with-Updater$set$1\\6\\217\\5":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_ea

    move-object/from16 v23, v2

    .end local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .local v23, "$composer\\1":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v24, v3

    .end local v3    # "$changed\\1":I
    .local v24, "$changed\\1":I
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_e7

    goto :goto_ee

    :cond_e7
    move-object/from16 v3, v21

    goto :goto_fe

    .end local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v24    # "$changed\\1":I
    .restart local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$changed\\1":I
    :cond_ea
    move-object/from16 v23, v2

    move/from16 v24, v3

    .line 219
    .end local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$changed\\1":I
    .restart local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v24    # "$changed\\1":I
    :goto_ee
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 220
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 222
    :goto_fe
    nop

    .line 217
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\6\\217\\5":I
    nop

    .line 222
    nop

    .line 223
    .end local v0    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\5\\216":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    nop

    .line 213
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\213\\2":I
    nop

    .line 225
    shr-int/lit8 v0, v5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object/from16 v1, v23

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 196
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\7\\225\\1":I
    const v3, 0x7cc0ae6e

    move/from16 v18, v0

    .end local v0    # "$changed\\7":I
    .local v18, "$changed\\7":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v24, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$DeckDetailScreen_u24lambda_u2418_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v47, v1

    .local v47, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 40
    .local v19, "$i$a$-Column-DeckDetailScreenKt$DeckDetailScreen$8$1\\8\\196\\0":I
    move-object/from16 v21, v0

    .end local v0    # "$this$DeckDetailScreen_u24lambda_u2418_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v21, "$this$DeckDetailScreen_u24lambda_u2418_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x3bbfd757

    move-object/from16 v22, v1

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v1, "C39@2672L28:DeckDetailScreen.kt#i35lj1"

    move/from16 v51, v2

    move-object/from16 v2, v47

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v51, "$i$a$-Layout-ColumnKt$Column$1\\7\\225\\1":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v49, 0x0

    const v50, 0x3fffe

    const-string v25, "\u8fd9\u5f20\u5361\u7247\u53ca\u5176\u5b66\u4e60\u8bb0\u5f55\u5c06\u88ab\u5220\u9664\uff0c\u65e0\u6cd5\u64a4\u56de\u3002"

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v48, 0x6

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v25 .. v50}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$6(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_18d

    const v0, 0x48652fee

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "39@2716L20"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$6(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v1, 0x30

    move/from16 v25, v3

    move-object/from16 v16, v4

    const/4 v3, 0x1

    const/4 v4, 0x0

    .end local v3    # "$changed\\8":I
    .end local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v16, "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v25, "$changed\\8":I
    invoke-static {v0, v3, v2, v1, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_197

    .end local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v25    # "$changed\\8":I
    .restart local v3    # "$changed\\8":I
    .restart local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    :cond_18d
    move/from16 v25, v3

    move-object/from16 v16, v4

    .end local v3    # "$changed\\8":I
    .end local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v25    # "$changed\\8":I
    const v0, -0x3be854f8

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_197
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 196
    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-Column-DeckDetailScreenKt$DeckDetailScreen$8$1\\8\\196\\0":I
    .end local v21    # "$this$DeckDetailScreen_u24lambda_u2418_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v25    # "$changed\\8":I
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 225
    .end local v18    # "$changed\\7":I
    .end local v22    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Layout-ColumnKt$Column$1\\7\\225\\1":I
    nop

    .line 226
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 205
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 227
    nop

    .line 199
    .end local v5    # "$changed\\3":I
    .end local v17    # "$i$f$ReusableComposeNode\\3\\203":I
    .end local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 228
    nop

    .line 188
    .end local v11    # "$changed\\2":I
    .end local v12    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\2\\195":I
    .end local v14    # "compositeKeyHash\\2":I
    .end local v15    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 229
    nop

    .end local v6    # "$i$f$Column\\1\\40":I
    .end local v7    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v8    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v24    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1bd

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1bd

    .line 40
    :cond_1ba
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1bd
    :goto_1bd
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$19(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen(Ljava/lang/String;Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final DeckDetailScreen$lambda$2$0()Landroidx/compose/runtime/MutableState;
    .registers 2

    .line 19
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 19
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 117
    .local v3, "$i$f$getValue\\1\\19":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\19":I
    check-cast v0, Ljava/lang/String;

    .line 19
    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 19
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 118
    .local v4, "$i$f$setValue\\1\\19":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 119
    nop

    .line 19
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\19":I
    return-void
.end method

.method private static final DeckDetailScreen$lambda$6(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 19
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 117
    .local v3, "$i$f$getValue\\1\\19":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\19":I
    check-cast v0, Ljava/lang/String;

    .line 19
    return-object v0
.end method

.method private static final DeckDetailScreen$lambda$7(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 19
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 118
    .local v4, "$i$f$setValue\\1\\19":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 119
    nop

    .line 19
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\19":I
    return-void
.end method

.method private static final DeckDetailScreen$lambda$9(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 19
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 117
    .local v3, "$i$f$getValue\\1\\19":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\19":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 19
    return v0
.end method

.method public static final synthetic access$DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V
    .registers 2
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$10(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$3(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$DeckDetailScreen$lambda$7(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DeckDetailScreenKt;->DeckDetailScreen$lambda$7(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

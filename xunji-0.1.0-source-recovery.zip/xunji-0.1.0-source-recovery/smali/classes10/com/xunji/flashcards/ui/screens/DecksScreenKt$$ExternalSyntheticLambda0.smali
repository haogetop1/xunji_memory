.class public final synthetic Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Lcom/xunji/flashcards/ui/MainViewModel;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$4:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$2:Lcom/xunji/flashcards/ui/MainViewModel;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$3:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$4:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$2:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$3:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;->f$4:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, v2, v3, v4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->$r8$lambda$Oam6o14cCWVqzaM2GRH0YGa1H5k(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

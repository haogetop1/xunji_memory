.class public final synthetic Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lkotlinx/coroutines/CoroutineScope;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Lcom/xunji/flashcards/ui/MainViewModel;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$4:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$5:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$6:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$2:Lcom/xunji/flashcards/ui/MainViewModel;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$3:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$4:Landroidx/compose/runtime/MutableState;

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$5:Landroidx/compose/runtime/MutableState;

    iput-object p7, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$6:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 12

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$0:Lkotlinx/coroutines/CoroutineScope;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$2:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$3:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$4:Landroidx/compose/runtime/MutableState;

    iget-object v5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$5:Landroidx/compose/runtime/MutableState;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;->f$6:Landroidx/compose/runtime/MutableState;

    move-object v7, p1

    check-cast v7, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v8

    invoke-static/range {v0 .. v8}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->$r8$lambda$vwbsfSQO99aGNMnrx-bnrS_nl08(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

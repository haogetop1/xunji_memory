.class public final synthetic Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 0
    check-cast p1, Lcom/xunji/core/model/DeckSummary;

    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->$r8$lambda$MqSUyWVbwvTJQA39P7LKNSetslU(Lcom/xunji/core/model/DeckSummary;)Ljava/lang/Object;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$0:Landroidx/compose/runtime/MutableState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$0:Landroidx/compose/runtime/MutableState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;->f$2:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->$r8$lambda$MHstt5XuV3-GpF_6500v-oORJ4w(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

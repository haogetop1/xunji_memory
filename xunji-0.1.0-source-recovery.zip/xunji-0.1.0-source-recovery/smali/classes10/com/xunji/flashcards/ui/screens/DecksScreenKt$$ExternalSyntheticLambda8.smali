.class public final synthetic Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/MainUiState;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$5:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$6:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$2:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$3:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$4:Lkotlin/jvm/functions/Function1;

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$5:Landroidx/compose/runtime/MutableState;

    iput-object p7, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$6:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$2:Landroidx/compose/runtime/MutableState;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$3:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$4:Lkotlin/jvm/functions/Function1;

    iget-object v5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$5:Landroidx/compose/runtime/MutableState;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;->f$6:Landroidx/compose/runtime/MutableState;

    move-object v7, p1

    check-cast v7, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->$r8$lambda$xrvwWE68WrEBm6COFRkV6q4rb3Y(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class final Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;
.super Ljava/lang/Object;
.source "DecksScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $deleting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $error$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $summary:Lcom/xunji/core/model/DeckSummary;


# direct methods
.method constructor <init>(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/core/model/DeckSummary;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$summary:Lcom/xunji/core/model/DeckSummary;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 28
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->invoke()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke()V
    .registers 3

    .line 28
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$summary:Lcom/xunji/core/model/DeckSummary;

    invoke-virtual {v1}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/model/Deck;->getId()Ljava/lang/String;

    move-result-object v1

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v1, 0x0

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

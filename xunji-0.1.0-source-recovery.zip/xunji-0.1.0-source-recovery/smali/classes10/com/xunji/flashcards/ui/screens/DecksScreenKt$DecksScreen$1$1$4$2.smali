.class final Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;
.super Ljava/lang/Object;
.source "DecksScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function3<",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDecksScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 8 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,38:1\n113#2:39\n113#2:130\n99#3,6:40\n106#3:129\n99#3:131\n95#3,10:132\n106#3:172\n80#4,6:46\n87#4,3:61\n90#4,2:70\n80#4,6:83\n87#4,3:98\n90#4,2:107\n94#4:112\n94#4:128\n80#4,6:142\n87#4,3:157\n90#4,2:166\n94#4:171\n391#5,9:52\n400#5:72\n391#5,9:89\n400#5,3:109\n401#5,2:126\n391#5,9:148\n400#5,3:168\n4360#6,6:64\n4360#6,6:101\n4360#6,6:160\n87#7:73\n84#7,9:74\n94#7:113\n1282#8,6:114\n1282#8,6:120\n*S KotlinDebug\n*F\n+ 1 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2\n*L\n25#1:39\n31#1:130\n25#1:40,6\n25#1:129\n31#1:131\n31#1:132,10\n31#1:172\n25#1:46,6\n25#1:61,3\n25#1:70,2\n26#1:83,6\n26#1:98,3\n26#1:107,2\n26#1:112\n25#1:128\n31#1:142,6\n31#1:157,3\n31#1:166,2\n31#1:171\n25#1:52,9\n25#1:72\n26#1:89,9\n26#1:109,3\n25#1:126,2\n31#1:148,9\n31#1:168,3\n25#1:64,6\n26#1:101,6\n31#1:160,6\n26#1:73\n26#1:74,9\n26#1:113\n27#1:114,6\n28#1:120,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $deleting$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $editing$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $error$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $name$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $summary:Lcom/xunji/core/model/DeckSummary;


# direct methods
.method constructor <init>(Landroidx/compose/runtime/MutableState;Lcom/xunji/core/model/DeckSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/xunji/core/model/DeckSummary;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$summary:Lcom/xunji/core/model/DeckSummary;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$name$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$error$delegate:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;

    .line 24
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    move-object v1, p2

    check-cast v1, Landroidx/compose/runtime/Composer;

    move-object v2, p3

    check-cast v2, Ljava/lang/Number;

    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    move-result v2

    invoke-virtual {p0, v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)V
    .registers 93
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v5, p2

    move/from16 v8, p3

    const-string v1, "$this$Paper"

    move-object/from16 v9, p1

    invoke-static {v9, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C24@1719L440,29@2202L11,29@2164L65,30@2234L160:DecksScreen.kt#i35lj1"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v8, 0x11

    const/16 v2, 0x10

    const/4 v3, 0x1

    const/4 v10, 0x0

    if-eq v1, v2, :cond_1c

    move v1, v3

    goto :goto_1d

    :cond_1c
    move v1, v10

    :goto_1d
    and-int/lit8 v2, v8, 0x1

    invoke-interface {v5, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_594

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_34

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:24)"

    const v4, -0x3f0b8aaf

    invoke-static {v4, v8, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 25
    :cond_34
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v2, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0xc

    .local v7, "$this$dp\\1":I
    const/4 v11, 0x0

    .line 39
    .local v11, "$i$f$getDp\\1\\25":I
    int-to-float v12, v7

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 25
    .end local v7    # "$this$dp\\1":I
    .end local v11    # "$i$f$getDp\\1\\25":I
    invoke-virtual {v6, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    check-cast v6, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v6, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-object v7, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v11, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$summary:Lcom/xunji/core/model/DeckSummary;

    iget-object v12, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$name$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v13, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$deleting$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v14, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$error$delegate:Landroidx/compose/runtime/MutableState;

    const/16 v15, 0x1b6

    .local v15, "$changed\\2":I
    move-object/from16 v16, p2

    .local v1, "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v2, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v16, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 40
    .local v17, "$i$f$Row\\2\\25":I
    move-object/from16 v18, v1

    .end local v1    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .local v18, "modifier\\2":Landroidx/compose/ui/Modifier;
    const v1, 0x3255a44b

    const-string v3, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    move-object/from16 v4, v16

    .end local v16    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 41
    shr-int/lit8 v16, v15, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v21, v15, 0x3

    and-int/lit8 v21, v21, 0x70

    or-int v1, v16, v21

    invoke-static {v6, v2, v4, v1}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v1

    .line 45
    .local v1, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v15, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 42
    move-object/from16 v21, v18

    .local v16, "$changed\\3":I
    .local v21, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v23, 0x0

    .line 46
    .local v23, "$i$f$Layout\\3\\42":I
    move-object/from16 v24, v2

    .end local v2    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v24, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    const v2, -0x451e1427

    move-object/from16 v25, v6

    .end local v6    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v25, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const-string v6, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v4, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 47
    invoke-static {v4, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v26

    invoke-static/range {v26 .. v27}, Ljava/lang/Long;->hashCode(J)I

    move-result v26

    .line 48
    .local v26, "compositeKeyHash\\3":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 49
    .local v2, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v10, v21

    move-object/from16 v21, v3

    .end local v21    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v10, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v4, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 51
    .local v3, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v28, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v28 .. v28}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v28

    shl-int/lit8 v8, v16, 0x6

    and-int/lit16 v8, v8, 0x380

    or-int/lit8 v8, v8, 0x6

    .line 50
    move-object/from16 v29, v28

    .local v8, "$changed\\4":I
    .local v29, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v28, 0x0

    .line 52
    .local v28, "$i$f$ReusableComposeNode\\4\\50":I
    move/from16 v30, v8

    .end local v8    # "$changed\\4":I
    .local v30, "$changed\\4":I
    const v8, -0x20f7d59c

    const-string v9, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v4, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 53
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v8

    instance-of v8, v8, Landroidx/compose/runtime/Applier;

    if-nez v8, :cond_cb

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 54
    :cond_cb
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 55
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v8

    if-eqz v8, :cond_da

    .line 56
    move-object/from16 v8, v29

    .end local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v8, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_df

    .line 58
    .end local v8    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_da
    move-object/from16 v8, v29

    .end local v29    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v8    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 60
    :goto_df
    move-object/from16 v29, v4

    .end local v4    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v29, "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 61
    .local v32, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\60\\3":I
    sget-object v33, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v34, v8

    .end local v8    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v34, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v4, v1, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 62
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v4, v2, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 63
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v33, 0x0

    .line 64
    .local v33, "$i$f$set-impl\\6\\63":I
    move-object/from16 v35, v4

    .local v35, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 65
    .local v36, "$i$a$-with-Updater$set$1\\7\\64\\6":I
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v37

    if-nez v37, :cond_123

    move-object/from16 v37, v1

    .end local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v37, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v35 .. v35}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v38, v2

    .end local v2    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v38, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_120

    goto :goto_127

    :cond_120
    move-object/from16 v2, v35

    goto :goto_137

    .end local v37    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v38    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_123
    move-object/from16 v37, v1

    move-object/from16 v38, v2

    .line 66
    .end local v1    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v2    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v37    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v38    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_127
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v35

    .end local v35    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 67
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v4, v1, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 69
    :goto_137
    nop

    .line 64
    .end local v2    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-with-Updater$set$1\\7\\64\\6":I
    nop

    .line 69
    nop

    .line 70
    .end local v8    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v33    # "$i$f$set-impl\\6\\63":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v4, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 71
    nop

    .line 60
    .end local v4    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\60\\3":I
    nop

    .line 72
    shr-int/lit8 v1, v30, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object/from16 v2, v29

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 43
    .local v4, "$i$a$-Layout-RowKt$Row$1\\8\\72\\2":I
    const v8, 0x56ccd6f5

    move/from16 v32, v1

    .end local v1    # "$changed\\8":I
    .local v32, "$changed\\8":I
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v33, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v35, v15, 0x6

    and-int/lit8 v35, v35, 0x70

    or-int/lit8 v35, v35, 0x6

    .local v35, "$changed\\9":I
    check-cast v33, Landroidx/compose/foundation/layout/RowScope;

    .local v33, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v39, v33

    .end local v33    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v39, "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v45, v2

    .local v45, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v33, 0x0

    .line 26
    .local v33, "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$4$2$1\\9\\43\\0":I
    const v8, -0x5df1a401

    move-object/from16 v48, v1

    const-string v1, "C25@1850L6,25@1857L129,26@2018L61,26@1992L88,27@2113L39,27@2086L67:DecksScreen.kt#i35lj1"

    move-object/from16 v49, v2

    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v19, v3

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v8, 0x1

    .end local v3    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v19, "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v1, v2, v3, v8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Mark(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v40, v1

    check-cast v40, Landroidx/compose/ui/Modifier;

    const/16 v43, 0x2

    const/16 v44, 0x0

    const/high16 v41, 0x3f800000    # 1.0f

    const/16 v42, 0x0

    invoke-static/range {v39 .. v44}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\10":Landroidx/compose/ui/Modifier;
    const/4 v3, 0x0

    .local v3, "$changed\\10":I
    move-object v8, v2

    .local v8, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 73
    .local v20, "$i$f$Column\\10\\26":I
    move-object/from16 v40, v1

    .end local v1    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v40, "modifier\\10":Landroidx/compose/ui/Modifier;
    const v1, 0x4ff7456f

    move/from16 v41, v3

    .end local v3    # "$changed\\10":I
    .local v41, "$changed\\10":I
    const-string v3, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v8, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 74
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v1}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v1

    .line 75
    .local v1, "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v3

    .line 78
    .local v3, "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v42, v41, 0x3

    and-int/lit8 v42, v42, 0xe

    shr-int/lit8 v43, v41, 0x3

    and-int/lit8 v43, v43, 0x70

    move/from16 v50, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\8\\72\\2":I
    .local v50, "$i$a$-Layout-RowKt$Row$1\\8\\72\\2":I
    or-int v4, v42, v43

    invoke-static {v1, v3, v8, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .line 82
    .local v4, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v42, v41, 0x3

    and-int/lit8 v42, v42, 0x70

    .line 79
    nop

    .local v42, "$changed\\11":I
    move-object/from16 v43, v40

    .local v43, "modifier\\11":Landroidx/compose/ui/Modifier;
    const/16 v44, 0x0

    .line 83
    .local v44, "$i$f$Layout\\11\\79":I
    move-object/from16 v45, v1

    const v1, -0x451e1427

    .end local v1    # "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v45, "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v8, v1, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 84
    const/4 v1, 0x0

    invoke-static {v8, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v46

    invoke-static/range {v46 .. v47}, Ljava/lang/Long;->hashCode(J)I

    move-result v1

    .line 85
    .local v1, "compositeKeyHash\\11":I
    move/from16 v46, v1

    .end local v1    # "compositeKeyHash\\11":I
    .local v46, "compositeKeyHash\\11":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 86
    .local v1, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v47, v3

    move-object/from16 v51, v6

    move-object/from16 v3, v43

    .end local v43    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v3, "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v47, "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v8, v3}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 88
    .local v6, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v43, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v43 .. v43}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v43

    move-object/from16 v52, v3

    .end local v3    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v52, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v3, v42, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 87
    move-object/from16 v53, v43

    .local v3, "$changed\\12":I
    .local v53, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v43, 0x0

    .line 89
    .local v43, "$i$f$ReusableComposeNode\\12\\87":I
    move/from16 v54, v3

    const v3, -0x20f7d59c

    .end local v3    # "$changed\\12":I
    .local v54, "$changed\\12":I
    invoke-static {v8, v3, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 90
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_207

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 91
    :cond_207
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 92
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_216

    .line 93
    move-object/from16 v3, v53

    .end local v53    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_21b

    .line 95
    .end local v3    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v53    # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_216
    move-object/from16 v3, v53

    .end local v53    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 97
    :goto_21b
    move-object/from16 v53, v3

    .end local v3    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v53    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 98
    .local v55, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\97\\11":I
    sget-object v56, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v57, v8

    .end local v8    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v57, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v3, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 99
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    invoke-static {v3, v1, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 100
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v8

    .local v8, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v56, 0x0

    .line 101
    .local v56, "$i$f$set-impl\\14\\100":I
    move-object/from16 v58, v3

    .local v58, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 102
    .local v59, "$i$a$-with-Updater$set$1\\15\\101\\14":I
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v60

    if-nez v60, :cond_25f

    move-object/from16 v60, v1

    .end local v1    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v61, v4

    .end local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v61, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_25c

    goto :goto_263

    :cond_25c
    move-object/from16 v4, v58

    goto :goto_273

    .end local v60    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v61    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_25f
    move-object/from16 v60, v1

    move-object/from16 v61, v4

    .line 103
    .end local v1    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v60    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v61    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_263
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v4, v58

    .end local v58    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 104
    invoke-static/range {v46 .. v46}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v3, v1, v8}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 106
    :goto_273
    nop

    .line 101
    .end local v4    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$a$-with-Updater$set$1\\15\\101\\14":I
    nop

    .line 106
    nop

    .line 107
    .end local v8    # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v56    # "$i$f$set-impl\\14\\100":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v3, v6, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 108
    nop

    .line 97
    .end local v3    # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\97\\11":I
    nop

    .line 109
    shr-int/lit8 v1, v54, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\16":I
    move-object/from16 v3, v57

    .local v3, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 80
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\16\\109\\10":I
    const v8, 0x7cc0ae6e

    move/from16 v55, v1

    .end local v1    # "$changed\\16":I
    .local v55, "$changed\\16":I
    const-string v1, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v3, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, v41, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\17":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$invoke_u24lambda_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v84, v3

    .local v84, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 26
    .local v56, "$i$a$-Column-DecksScreenKt$DecksScreen$1$1$4$2$1$1\\17\\80\\9":I
    move-object/from16 v58, v1

    .end local v1    # "$this$invoke_u24lambda_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    .local v58, "$this$invoke_u24lambda_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x3f5ab3f7

    move-object/from16 v59, v3

    .end local v3    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v59, "$composer\\16":Landroidx/compose/runtime/Composer;
    const-string v3, "C25@1930L10,25@1887L66,25@1954L30:DecksScreen.kt#i35lj1"

    move/from16 v88, v4

    move-object/from16 v4, v84

    .end local v84    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v88, "$i$a$-Layout-ColumnKt$Column$1\\16\\109\\10":I
    invoke-static {v4, v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual {v11}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/model/Deck;->getName()Ljava/lang/String;

    move-result-object v62

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v83

    const/16 v86, 0x0

    const v87, 0x1fffe

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const-wide/16 v72, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v85, 0x0

    .end local v4    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v84    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v62 .. v87}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v84    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-virtual {v11}, Lcom/xunji/core/model/DeckSummary;->getTotal()I

    move-result v1

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v3, " \u5f20\u5361\u7247"

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    move-object/from16 v62, v6

    const/4 v6, 0x0

    .end local v6    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v62, "materialized\\11":Landroidx/compose/ui/Modifier;
    invoke-static {v1, v6, v4, v6, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 80
    .end local v4    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v8    # "$changed\\17":I
    .end local v56    # "$i$a$-Column-DecksScreenKt$DecksScreen$1$1$4$2$1$1\\17\\80\\9":I
    .end local v58    # "$this$invoke_u24lambda_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 109
    .end local v55    # "$changed\\16":I
    .end local v59    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v88    # "$i$a$-Layout-ColumnKt$Column$1\\16\\109\\10":I
    nop

    .line 110
    invoke-interface/range {v57 .. v57}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 89
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 111
    nop

    .line 83
    .end local v43    # "$i$f$ReusableComposeNode\\12\\87":I
    .end local v53    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .end local v54    # "$changed\\12":I
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 112
    nop

    .line 73
    .end local v42    # "$changed\\11":I
    .end local v44    # "$i$f$Layout\\11\\79":I
    .end local v46    # "compositeKeyHash\\11":I
    .end local v52    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v60    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v62    # "materialized\\11":Landroidx/compose/ui/Modifier;
    invoke-static/range {v57 .. v57}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 113
    nop

    .line 27
    .end local v20    # "$i$f$Column\\10\\26":I
    .end local v40    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v41    # "$changed\\10":I
    .end local v45    # "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v47    # "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v57    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v61    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    const v1, -0x307b76e

    const-string v4, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v2, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v1, v6

    invoke-interface {v2, v12}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v1, v6

    .local v1, "invalid\\18":Z
    move-object v6, v2

    .local v6, "$this$cache\\18":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 114
    .local v8, "$i$f$cache\\18\\27":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\18":Ljava/lang/Object;
    const/16 v40, 0x0

    .line 115
    .local v40, "$i$a$-let-ComposerKt$cache$1\\19\\114\\18":I
    if-nez v1, :cond_34e

    sget-object v41, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v42, v1

    .end local v1    # "invalid\\18":Z
    .local v42, "invalid\\18":Z
    invoke-virtual/range {v41 .. v41}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v3, v1, :cond_34d

    goto :goto_350

    .line 119
    :cond_34d
    goto :goto_35f

    .line 115
    .end local v42    # "invalid\\18":Z
    .restart local v1    # "invalid\\18":Z
    :cond_34e
    move/from16 v42, v1

    .line 116
    .end local v1    # "invalid\\18":Z
    .restart local v42    # "invalid\\18":Z
    :goto_350
    const/4 v1, 0x0

    .line 27
    .local v1, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$2\\20\\116\\9":I
    move/from16 v41, v1

    .end local v1    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$2\\20\\116\\9":I
    .local v41, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$2\\20\\116\\9":I
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$2$1;

    invoke-direct {v1, v11, v7, v12, v14}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$2$1;-><init>(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 116
    .end local v41    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$2\\20\\116\\9":I
    nop

    .line 117
    .local v1, "value\\19":Ljava/lang/Object;
    invoke-interface {v6, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    move-object v3, v1

    .line 114
    .end local v1    # "value\\19":Ljava/lang/Object;
    .end local v3    # "it\\18":Ljava/lang/Object;
    .end local v40    # "$i$a$-let-ComposerKt$cache$1\\19\\114\\18":I
    :goto_35f
    nop

    .line 27
    .end local v6    # "$this$cache\\18":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\18\\27":I
    .end local v42    # "invalid\\18":Z
    move-object/from16 v42, v3

    check-cast v42, Lkotlin/jvm/functions/Function0;

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v46, 0x36

    const/16 v47, 0x18

    const-string v40, "edit"

    const-string v41, "\u91cd\u547d\u540d\u724c\u7ec4"

    const/16 v43, 0x0

    const/16 v44, 0x0

    move-object/from16 v45, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v40 .. v47}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 28
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const v1, -0x307aba4

    invoke-static {v2, v1, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v2, v13}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .local v1, "invalid\\21":Z
    move-object v3, v2

    .local v3, "$this$cache\\21":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 120
    .local v4, "$i$f$cache\\21\\28":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\21":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 121
    .local v7, "$i$a$-let-ComposerKt$cache$1\\22\\120\\21":I
    if-nez v1, :cond_39a

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_399

    goto :goto_39a

    .line 125
    :cond_399
    goto :goto_3a7

    .line 122
    :cond_39a
    :goto_39a
    const/4 v8, 0x0

    .line 28
    .local v8, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$3\\23\\122\\9":I
    new-instance v12, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;

    invoke-direct {v12, v11, v13, v14}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2$1$3$1;-><init>(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    check-cast v12, Lkotlin/jvm/functions/Function0;

    .line 122
    .end local v8    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$2$1$3\\23\\122\\9":I
    nop

    .line 123
    .local v12, "value\\22":Ljava/lang/Object;
    invoke-interface {v3, v12}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 124
    move-object v6, v12

    .line 120
    .end local v6    # "it\\21":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\22\\120\\21":I
    .end local v12    # "value\\22":Ljava/lang/Object;
    :goto_3a7
    nop

    .line 28
    .end local v1    # "invalid\\21":Z
    .end local v3    # "$this$cache\\21":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\21\\28":I
    move-object/from16 v42, v6

    check-cast v42, Lkotlin/jvm/functions/Function0;

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v46, 0x36

    const/16 v47, 0x18

    const-string v40, "delete"

    const-string v41, "\u5220\u9664\u724c\u7ec4"

    const/16 v43, 0x0

    const/16 v44, 0x0

    move-object/from16 v45, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v40 .. v47}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 26
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 29
    nop

    .line 43
    .end local v33    # "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$4$2$1\\9\\43\\0":I
    .end local v35    # "$changed\\9":I
    .end local v39    # "$this$invoke_u24lambda_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 72
    .end local v32    # "$changed\\8":I
    .end local v49    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-RowKt$Row$1\\8\\72\\2":I
    nop

    .line 126
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 52
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 127
    nop

    .line 46
    .end local v28    # "$i$f$ReusableComposeNode\\4\\50":I
    .end local v30    # "$changed\\4":I
    .end local v34    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 128
    nop

    .line 40
    .end local v10    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v16    # "$changed\\3":I
    .end local v19    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v23    # "$i$f$Layout\\3\\42":I
    .end local v26    # "compositeKeyHash\\3":I
    .end local v38    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v29 .. v29}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 129
    nop

    .line 30
    .end local v15    # "$changed\\2":I
    .end local v17    # "$i$f$Row\\2\\25":I
    .end local v18    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v24    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v25    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v29    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v37    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    move-object/from16 v11, v21

    move-object/from16 v10, v48

    move-object/from16 v13, v51

    const/4 v8, 0x2

    const v12, 0x3255a44b

    const v14, -0x451e1427

    invoke-static/range {v1 .. v7}, Landroidx/compose/material3/DividerKt;->HorizontalDivider-9IZ8Weo(Landroidx/compose/ui/Modifier;FJLandroidx/compose/runtime/Composer;II)V

    .line 31
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v2, 0x14

    .local v2, "$this$dp\\24":I
    const/4 v3, 0x0

    .line 130
    .local v3, "$i$f$getDp\\24\\31":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 31
    .end local v2    # "$this$dp\\24":I
    .end local v3    # "$i$f$getDp\\24\\31":I
    invoke-virtual {v1, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v1, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    iget-object v2, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;->$summary:Lcom/xunji/core/model/DeckSummary;

    const/16 v3, 0x30

    .local v3, "$changed\\25":I
    move-object/from16 v4, p2

    .local v4, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 131
    .local v5, "$i$f$Row\\25\\31":I
    invoke-static {v4, v12, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 132
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    .line 134
    .local v6, "modifier\\25":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 137
    .local v7, "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v3, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v1, v7, v4, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 141
    .local v11, "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v3, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 138
    move-object v15, v6

    .local v12, "$changed\\26":I
    .local v15, "modifier\\26":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    .line 142
    .local v16, "$i$f$Layout\\26\\138":I
    invoke-static {v4, v14, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 143
    const/4 v13, 0x0

    invoke-static {v4, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v13

    .line 144
    .local v13, "compositeKeyHash\\26":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 145
    .local v14, "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 147
    .local v8, "materialized\\26":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v0, v12, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 146
    nop

    .local v0, "$changed\\27":I
    move-object/from16 v18, v17

    .local v18, "factory\\27":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 148
    .local v17, "$i$f$ReusableComposeNode\\27\\146":I
    move/from16 v19, v0

    const v0, -0x20f7d59c

    .end local v0    # "$changed\\27":I
    .local v19, "$changed\\27":I
    invoke-static {v4, v0, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 149
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_467

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 150
    :cond_467
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 151
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_476

    .line 152
    move-object/from16 v0, v18

    .end local v18    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_47b

    .line 154
    .end local v0    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v18    # "factory\\27":Lkotlin/jvm/functions/Function0;
    :cond_476
    move-object/from16 v0, v18

    .end local v18    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 156
    :goto_47b
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .local v9, "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 157
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\156\\26":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v0

    .end local v0    # "factory\\27":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v9, v11, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 158
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v9, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 159
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\29":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 160
    .local v21, "$i$f$set-impl\\29\\159":I
    move-object/from16 v23, v9

    .local v23, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 161
    .local v24, "$i$a$-with-Updater$set$1\\30\\160\\29":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_4bd

    move-object/from16 v25, v1

    .end local v1    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v25, "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v26, v2

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_4ba

    goto :goto_4c1

    :cond_4ba
    move-object/from16 v2, v23

    goto :goto_4d1

    .end local v25    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v1    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_4bd
    move-object/from16 v25, v1

    move-object/from16 v26, v2

    .line 162
    .end local v1    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v25    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_4c1
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 163
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v9, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 165
    :goto_4d1
    nop

    .line 160
    .end local v2    # "$this$set_impl_u24lambda_u240\\29":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\30\\160\\29":I
    nop

    .line 165
    nop

    .line 166
    .end local v0    # "block\\29":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\29\\159":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v9, v8, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 167
    nop

    .line 156
    .end local v9    # "$this$Layout_u24lambda_u240\\28":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\28\\156\\26":I
    nop

    .line 168
    shr-int/lit8 v0, v19, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\31":I
    move-object v1, v4

    .local v1, "$composer\\31":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 139
    .local v2, "$i$a$-Layout-RowKt$Row$1\\31\\168\\25":I
    const v9, 0x56ccd6f5

    invoke-static {v1, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v9, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v10, v3, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v10, v10, 0x6

    .local v10, "$changed\\32":I
    check-cast v9, Landroidx/compose/foundation/layout/RowScope;

    .local v9, "$this$invoke_u24lambda_u241\\32":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v50, v1

    .local v50, "$composer\\32":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 31
    .local v18, "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$4$2$2\\32\\139\\0":I
    move/from16 v21, v0

    .end local v0    # "$changed\\31":I
    .local v21, "$changed\\31":I
    const v0, 0x43540492

    move-object/from16 v23, v1

    .end local v1    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .local v23, "$composer\\31":Landroidx/compose/runtime/Composer;
    const-string v1, "C30@2338L11,30@2291L67,30@2359L33:DecksScreen.kt#i35lj1"

    move/from16 v24, v2

    move-object/from16 v2, v50

    .end local v50    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\32":Landroidx/compose/runtime/Composer;
    .local v24, "$i$a$-Layout-RowKt$Row$1\\31\\168\\25":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {v26 .. v26}, Lcom/xunji/core/model/DeckSummary;->getDue()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5f85\u590d\u4e60"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v28

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v30

    const/16 v52, 0x0

    const v53, 0x3fffa

    const/16 v29, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v51, 0x0

    .end local v2    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v53}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v50    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\32":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v26 .. v26}, Lcom/xunji/core/model/DeckSummary;->getNewCards()I

    move-result v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u65b0\u5361"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    move/from16 v20, v3

    const/4 v1, 0x2

    const/4 v3, 0x0

    .end local v3    # "$changed\\25":I
    .local v20, "$changed\\25":I
    invoke-static {v0, v3, v2, v3, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 139
    .end local v2    # "$composer\\32":Landroidx/compose/runtime/Composer;
    .end local v9    # "$this$invoke_u24lambda_u241\\32":Landroidx/compose/foundation/layout/RowScope;
    .end local v10    # "$changed\\32":I
    .end local v18    # "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$4$2$2\\32\\139\\0":I
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 168
    .end local v21    # "$changed\\31":I
    .end local v23    # "$composer\\31":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Layout-RowKt$Row$1\\31\\168\\25":I
    nop

    .line 169
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 148
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 170
    nop

    .line 142
    .end local v17    # "$i$f$ReusableComposeNode\\27\\146":I
    .end local v19    # "$changed\\27":I
    .end local v22    # "factory\\27":Lkotlin/jvm/functions/Function0;
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 171
    nop

    .line 131
    .end local v8    # "materialized\\26":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\26":I
    .end local v13    # "compositeKeyHash\\26":I
    .end local v14    # "localMap\\26":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "modifier\\26":Landroidx/compose/ui/Modifier;
    .end local v16    # "$i$f$Layout\\26\\138":I
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 172
    nop

    .end local v4    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$Row\\25\\31":I
    .end local v6    # "modifier\\25":Landroidx/compose/ui/Modifier;
    .end local v7    # "verticalAlignment\\25":Landroidx/compose/ui/Alignment$Vertical;
    .end local v11    # "measurePolicy\\25":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20    # "$changed\\25":I
    .end local v25    # "horizontalArrangement\\25":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_597

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_597

    .line 24
    :cond_594
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 32
    :cond_597
    :goto_597
    return-void
.end method

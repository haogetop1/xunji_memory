.class final Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "DecksScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.screens.DecksScreenKt$DecksScreen$3$1$1$1"
    f = "DecksScreen.kt"
    i = {}
    l = {
        0x23,
        0x23
    }
    m = "invokeSuspend"
    n = {}
    s = {}
    v = 0x1
.end annotation


# instance fields
.field final synthetic $adding$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $busy$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $editing$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $error$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $name$delegate:Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field final synthetic $viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

.field label:I


# direct methods
.method constructor <init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/MainViewModel;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$adding$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$name$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p7}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$adding$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$name$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    move-object v7, p2

    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;-><init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 35
    iget v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->label:I

    const/4 v2, 0x0

    packed-switch v1, :pswitch_data_94

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12
    :try_start_12
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    goto :goto_61

    :pswitch_16
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_19
    .catch Ljava/util/concurrent/CancellationException; {:try_start_12 .. :try_end_19} :catch_21
    .catch Ljava/lang/IllegalArgumentException; {:try_start_12 .. :try_end_19} :catch_1f
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_19} :catch_1d
    .catchall {:try_start_12 .. :try_end_19} :catchall_1a

    goto :goto_63

    :catchall_1a
    move-exception v0

    goto/16 :goto_8e

    :catch_1d
    move-exception v0

    goto :goto_6f

    :catch_1f
    move-exception v0

    goto :goto_7c

    :catch_21
    move-exception v0

    goto :goto_8d

    :pswitch_23
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    :try_start_26
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$adding$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    invoke-static {v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    if-eqz v1, :cond_43

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$name$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v3

    move-object v4, p0

    check-cast v4, Lkotlin/coroutines/Continuation;

    const/4 v5, 0x1

    iput v5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->label:I

    invoke-virtual {v1, v3, v4}, Lcom/xunji/flashcards/ui/MainViewModel;->createDeck(Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_63

    return-object v0

    :cond_43
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$viewModel:Lcom/xunji/flashcards/ui/MainViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$name$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    invoke-static {v4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v4

    move-object v5, p0

    check-cast v5, Lkotlin/coroutines/Continuation;

    const/4 v6, 0x2

    iput v6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->label:I

    invoke-virtual {v1, v3, v4, v5}, Lcom/xunji/flashcards/ui/MainViewModel;->renameDeck(Ljava/lang/String;Ljava/lang/String;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_61

    return-object v0

    :cond_61
    :goto_61
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    :cond_63
    :goto_63
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$adding$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    invoke-static {v0, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$editing$delegate:Landroidx/compose/runtime/MutableState;

    const/4 v1, 0x0

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    :try_end_6e
    .catch Ljava/util/concurrent/CancellationException; {:try_start_26 .. :try_end_6e} :catch_21
    .catch Ljava/lang/IllegalArgumentException; {:try_start_26 .. :try_end_6e} :catch_1f
    .catch Ljava/lang/Exception; {:try_start_26 .. :try_end_6e} :catch_1d
    .catchall {:try_start_26 .. :try_end_6e} :catchall_1a

    goto :goto_76

    .local v0, "<unused var>":Ljava/lang/Exception;
    :goto_6f
    :try_start_6f
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    const-string v3, "\u4fdd\u5b58\u672a\u5b8c\u6210\uff0c\u8bf7\u91cd\u8bd5"

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v1, v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    :try_end_76
    .catchall {:try_start_6f .. :try_end_76} :catchall_1a

    .end local v0    # "<unused var>":Ljava/lang/Exception;
    :goto_76
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    invoke-static {v0, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    goto :goto_8a

    .local v0, "e":Ljava/lang/IllegalArgumentException;
    :goto_7c
    :try_start_7c
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$error$delegate:Landroidx/compose/runtime/MutableState;

    invoke-virtual {v0}, Ljava/lang/IllegalArgumentException;->getMessage()Ljava/lang/String;

    move-result-object v3

    if-nez v3, :cond_86

    const-string v3, "\u8bf7\u68c0\u67e5\u540d\u79f0"

    :cond_86
    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    invoke-static {v1, v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    :try_end_89
    .catchall {:try_start_7c .. :try_end_89} :catchall_1a

    .end local v0    # "e":Ljava/lang/IllegalArgumentException;
    goto :goto_76

    :goto_8a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .end local p1    # "$result":Ljava/lang/Object;
    .local v0, "e":Ljava/util/concurrent/CancellationException;
    :goto_8d
    :try_start_8d
    throw v0
    :try_end_8e
    .catchall {:try_start_8d .. :try_end_8e} :catchall_1a

    .end local v0    # "e":Ljava/util/concurrent/CancellationException;
    .restart local p1    # "$result":Ljava/lang/Object;
    :goto_8e
    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;->$busy$delegate:Landroidx/compose/runtime/MutableState;

    # invokes: Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    invoke-static {v1, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->access$DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    throw v0

    :pswitch_data_94
    .packed-switch 0x0
        :pswitch_23
        :pswitch_16
        :pswitch_12
    .end packed-switch
.end method

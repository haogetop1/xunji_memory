.class public final Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;
.super Ljava/lang/Object;
.source "LazyDsl.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Lkotlin/jvm/functions/Function4<",
        "Landroidx/compose/foundation/lazy/LazyItemScope;",
        "Ljava/lang/Integer;",
        "Landroidx/compose/runtime/Composer;",
        "Ljava/lang/Integer;",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nLazyDsl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt$items$4\n+ 2 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n*L\n1#1,180:1\n24#2:181\n33#2:188\n1282#3,6:182\n*S KotlinDebug\n*F\n+ 1 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt\n*L\n24#1:182,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $deleting$delegate$inlined:Landroidx/compose/runtime/MutableState;

.field final synthetic $editing$delegate$inlined:Landroidx/compose/runtime/MutableState;

.field final synthetic $error$delegate$inlined:Landroidx/compose/runtime/MutableState;

.field final synthetic $items:Ljava/util/List;

.field final synthetic $name$delegate$inlined:Landroidx/compose/runtime/MutableState;

.field final synthetic $onDeck$inlined:Lkotlin/jvm/functions/Function1;


# direct methods
.method public constructor <init>(Ljava/util/List;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 7

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$items:Ljava/util/List;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$onDeck$inlined:Lkotlin/jvm/functions/Function1;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$editing$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$name$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$deleting$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$error$delegate$inlined:Landroidx/compose/runtime/MutableState;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9
    .param p1, "p1"    # Ljava/lang/Object;
    .param p2, "p2"    # Ljava/lang/Object;
    .param p3, "p3"    # Ljava/lang/Object;
    .param p4, "p4"    # Ljava/lang/Object;

    .line 178
    move-object v0, p1

    check-cast v0, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v1, p2

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->intValue()I

    move-result v1

    move-object v2, p3

    check-cast v2, Landroidx/compose/runtime/Composer;

    move-object v3, p4

    check-cast v3, Ljava/lang/Number;

    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    move-result v3

    invoke-virtual {p0, v0, v1, v2, v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke(Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)V
    .registers 30
    .param p1, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "it"    # I
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    move-object/from16 v2, p3

    const-string v3, "CN(it)178@8834L22:LazyDsl.kt#428nma"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p4

    .local v3, "$dirty":I
    and-int/lit8 v4, p4, 0x6

    if-nez v4, :cond_1e

    move-object/from16 v4, p1

    invoke-interface {v2, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_1b

    const/4 v5, 0x4

    goto :goto_1c

    :cond_1b
    const/4 v5, 0x2

    :goto_1c
    or-int/2addr v3, v5

    goto :goto_20

    :cond_1e
    move-object/from16 v4, p1

    :goto_20
    and-int/lit8 v5, p4, 0x30

    if-nez v5, :cond_30

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v5

    if-eqz v5, :cond_2d

    const/16 v5, 0x20

    goto :goto_2f

    :cond_2d
    const/16 v5, 0x10

    :goto_2f
    or-int/2addr v3, v5

    :cond_30
    and-int/lit16 v5, v3, 0x93

    const/16 v6, 0x92

    const/4 v8, 0x1

    if-eq v5, v6, :cond_39

    move v5, v8

    goto :goto_3a

    :cond_39
    const/4 v5, 0x0

    :goto_3a
    and-int/lit8 v6, v3, 0x1

    invoke-interface {v2, v5, v6}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_f1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_51

    const/4 v5, -0x1

    const-string v6, "androidx.compose.foundation.lazy.items.<anonymous> (LazyDsl.kt:178)"

    const v9, 0x2fd4df92

    invoke-static {v9, v3, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 179
    :cond_51
    iget-object v5, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$items:Ljava/util/List;

    invoke-interface {v5, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v5

    and-int/lit8 v6, v3, 0xe

    .local v6, "$changed\\1":I
    move-object v11, v5

    check-cast v11, Lcom/xunji/core/model/DeckSummary;

    .local v11, "summary\\1":Lcom/xunji/core/model/DeckSummary;
    move-object/from16 v5, p1

    .local v5, "$this$DecksScreen_u24lambda_u2418_u240_u243\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    move-object/from16 v15, p3

    .local v15, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 181
    .local v16, "$i$a$-items$default-DecksScreenKt$DecksScreen$1$1$4\\1\\179\\0":I
    const v9, 0x3356a74f

    invoke-interface {v15, v9}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v9, "CN(summary)*23@1684L27,23@1713L686,23@1644L755:DecksScreen.kt#i35lj1"

    invoke-static {v15, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v12, 0x0

    invoke-static {v9, v10, v8, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v17

    const v9, -0x592ebea4    # -1.4520004E-15f

    const-string v10, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v15, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    iget-object v9, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$onDeck$inlined:Lkotlin/jvm/functions/Function1;

    invoke-interface {v15, v9}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    invoke-interface {v15, v11}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    or-int/2addr v9, v10

    .local v9, "invalid\\2":Z
    move-object v10, v15

    .local v10, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 182
    .local v12, "$i$f$cache\\2\\181":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\2":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 183
    .local v14, "$i$a$-let-ComposerKt$cache$1\\3\\182\\2":I
    if-nez v9, :cond_9d

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v13, v7, :cond_9c

    goto :goto_9d

    .line 187
    :cond_9c
    goto :goto_ac

    .line 184
    :cond_9d
    :goto_9d
    const/4 v7, 0x0

    .line 181
    .local v7, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$1\\4\\184\\1":I
    new-instance v8, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$1$1;

    iget-object v1, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$onDeck$inlined:Lkotlin/jvm/functions/Function1;

    invoke-direct {v8, v1, v11}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$1$1;-><init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/DeckSummary;)V

    check-cast v8, Lkotlin/jvm/functions/Function0;

    .line 184
    .end local v7    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$4$1\\4\\184\\1":I
    nop

    .line 185
    .local v8, "value\\3":Ljava/lang/Object;
    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 186
    move-object v13, v8

    .line 182
    .end local v8    # "value\\3":Ljava/lang/Object;
    .end local v13    # "it\\2":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\3\\182\\2":I
    :goto_ac
    nop

    .line 181
    .end local v9    # "invalid\\2":Z
    .end local v10    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\2\\181":I
    move-object/from16 v22, v13

    check-cast v22, Lkotlin/jvm/functions/Function0;

    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v23, 0xf

    const/16 v24, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    invoke-static/range {v17 .. v24}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    new-instance v9, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;

    iget-object v10, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$editing$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iget-object v12, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$name$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iget-object v13, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$deleting$delegate$inlined:Landroidx/compose/runtime/MutableState;

    iget-object v14, v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;->$error$delegate$inlined:Landroidx/compose/runtime/MutableState;

    invoke-direct/range {v9 .. v14}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$1$1$4$2;-><init>(Landroidx/compose/runtime/MutableState;Lcom/xunji/core/model/DeckSummary;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const/16 v7, 0x36

    const v8, -0x3f0b8aaf

    const/4 v10, 0x1

    invoke-static {v8, v10, v9, v15, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function3;

    const/16 v8, 0x30

    const/4 v9, 0x0

    invoke-static {v1, v7, v15, v8, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 188
    nop

    .line 179
    .end local v5    # "$this$DecksScreen_u24lambda_u2418_u240_u243\\1":Landroidx/compose/foundation/lazy/LazyItemScope;
    .end local v6    # "$changed\\1":I
    .end local v11    # "summary\\1":Lcom/xunji/core/model/DeckSummary;
    .end local v15    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$a$-items$default-DecksScreenKt$DecksScreen$1$1$4\\1\\179\\0":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_f4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_f4

    .line 178
    :cond_f1
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 180
    :cond_f4
    :goto_f4
    return-void
.end method

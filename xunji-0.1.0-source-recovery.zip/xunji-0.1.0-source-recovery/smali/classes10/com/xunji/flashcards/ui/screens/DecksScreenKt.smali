.class public final Lcom/xunji/flashcards/ui/screens/DecksScreenKt;
.super Ljava/lang/Object;
.source "DecksScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nDecksScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 4 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n+ 5 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 6 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 7 LazyDsl.kt\nandroidx/compose/foundation/lazy/LazyDslKt\n+ 8 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 9 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 10 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 11 Composer.kt\nandroidx/compose/runtime/Updater\n+ 12 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n*L\n1#1,38:1\n1282#2,6:39\n1282#2,6:45\n1282#2,6:60\n1282#2,6:66\n1282#2,6:72\n1282#2,6:136\n1282#2,6:146\n1282#2,6:152\n1282#2,6:200\n607#3:51\n604#3,6:52\n605#4:58\n113#5:59\n85#6:78\n117#6,2:79\n85#6:81\n117#6,2:82\n85#6:84\n117#6,2:85\n85#6:87\n117#6,2:88\n168#7,13:90\n99#8,6:103\n106#8:145\n80#9,6:109\n87#9,3:124\n90#9,2:133\n94#9:144\n80#9,6:169\n87#9,3:184\n90#9,2:193\n94#9:198\n80#9,6:217\n87#9,3:232\n90#9,2:241\n94#9:246\n391#10,9:115\n400#10:135\n401#10,2:142\n391#10,9:175\n400#10,3:195\n391#10,9:223\n400#10,3:243\n4360#11,6:127\n4360#11,6:187\n4360#11,6:235\n87#12:158\n83#12,10:159\n94#12:199\n87#12:206\n83#12,10:207\n94#12:247\n*S KotlinDebug\n*F\n+ 1 DecksScreen.kt\ncom/xunji/flashcards/ui/screens/DecksScreenKt\n*L\n17#1:39,6\n18#1:45,6\n19#1:60,6\n35#1:66,6\n36#1:72,6\n20#1:136,6\n22#1:146,6\n35#1:152,6\n36#1:200,6\n18#1:51\n18#1:52,6\n18#1:58\n19#1:59\n17#1:78\n17#1:79,2\n18#1:81\n18#1:82,2\n18#1:84\n18#1:85,2\n18#1:87\n18#1:88,2\n23#1:90,13\n20#1:103,6\n20#1:145\n20#1:109,6\n20#1:124,3\n20#1:133,2\n20#1:144\n35#1:169,6\n35#1:184,3\n35#1:193,2\n35#1:198\n36#1:217,6\n36#1:232,3\n36#1:241,2\n36#1:246\n20#1:115,9\n20#1:135\n20#1:142,2\n35#1:175,9\n35#1:195,3\n36#1:223,9\n36#1:243,3\n20#1:127,6\n35#1:187,6\n36#1:235,6\n35#1:158\n35#1:159,10\n35#1:199\n36#1:206\n36#1:207,10\n36#1:247\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000(\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0002\u0008\u0004\u001a1\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u0012\u0010\u0006\u001a\u000e\u0012\u0004\u0012\u00020\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0007\u00a2\u0006\u0002\u0010\t\u00a8\u0006\n\u00b2\u0006\u000c\u0010\u000b\u001a\u0004\u0018\u00010\u0008X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u000c\u001a\u00020\rX\u008a\u008e\u0002\u00b2\u0006\u000c\u0010\u000e\u001a\u0004\u0018\u00010\u0008X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u000f\u001a\u00020\u0008X\u008a\u008e\u0002\u00b2\u0006\u000c\u0010\u0010\u001a\u0004\u0018\u00010\u0008X\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0011\u001a\u00020\rX\u008a\u008e\u0002"
    }
    d2 = {
        "DecksScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/MainUiState;",
        "viewModel",
        "Lcom/xunji/flashcards/ui/MainViewModel;",
        "onDeck",
        "Lkotlin/Function1;",
        "",
        "(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "editing",
        "adding",
        "",
        "deleting",
        "name",
        "error",
        "busy"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$0VZoLmi3zYqLs0xDSpSCFpjhEeY()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$3$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$5vNSS9fkcrh5DFG7xE1bA3uR-Cc(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8mA14SPwEzIyPCcJOZg14Ps84dA(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$21$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Bq-ICEhAKPsaysnfvQ_aGoOAVDM()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$0$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$Dw06o_Gi6HtDBA5sOmR7LdIhgAo(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$23$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$GTGaVL6lbiVlTEtNzMXd9w9rIYA(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0$0$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Hb_z42lqkAhzuSGO-ftRW2TTPJo(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$MHstt5XuV3-GpF_6500v-oORJ4w(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0$1$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$MqSUyWVbwvTJQA39P7LKNSetslU(Lcom/xunji/core/model/DeckSummary;)Ljava/lang/Object;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0$2(Lcom/xunji/core/model/DeckSummary;)Ljava/lang/Object;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Oam6o14cCWVqzaM2GRH0YGa1H5k(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$25$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$SvXo3pY27fVZElEWS2Q-F82lqo0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$22(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TyB4J4M3PzMP-KdUPD6h84Lles4(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$27(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UNv0IJ_-lNTJ4ygim1Lf4FdKQmI(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$20$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$WRRH8BFNTVvqcnNzeZbbtdA-91o(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$24$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Wsr2rxrbFaLXLV1aGDYdCnBbxfQ(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$21(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XXAFyvOOeP0ICCRF-bdhke2hXpc(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$26$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ye1LA_yikSimcLxAXVQq4UUDxJU(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$26(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ZB30flydLnmKNhWGZpkWntjrnVg(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$25(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Zu73820npzsEBkID4vdcEVvA00I(Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$20$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$eQ-oJhXYPLeA5-xJBBnPQuDXt-Y(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$23(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ndwiKRX3VSJPDTdv_m_KIcHekoI(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$19$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vCoD0tjF7wWPz1R1Wvz9qY_99v4(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$28(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vwbsfSQO99aGNMnrx-bnrS_nl08(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$20(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$xrvwWE68WrEBm6COFRkV6q4rb3Y(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$18$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ykpPloL6MOCaZlSsDVPl0LOQ0Iw()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$9$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$zkMGxcuLYk3NP_cLY_edQWgyeC8()Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$6$0()Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static final DecksScreen(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .registers 39
    .param p0, "state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p2, "onDeck"    # Lkotlin/jvm/functions/Function1;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/MainUiState;",
            "Lcom/xunji/flashcards/ui/MainViewModel;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v8, p1

    move-object/from16 v5, p2

    move/from16 v9, p4

    const-string v0, "state"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "viewModel"

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onDeck"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    const v0, -0x6fcd0593

    move-object/from16 v2, p3

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(DecksScreen)N(state,viewModel,onDeck)16@642L33,16@625L50,16@707L25,16@690L42,16@766L33,16@749L50,17@830L22,17@813L39,17@866L42,17@921L34,17@966L24,18@1129L1277,18@992L1414:DecksScreen.kt#i35lj1"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, v9, 0x6

    if-nez v3, :cond_35

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_33

    const/4 v3, 0x4

    goto :goto_34

    :cond_33
    const/4 v3, 0x2

    :goto_34
    or-int/2addr v2, v3

    :cond_35
    and-int/lit8 v3, v9, 0x30

    if-nez v3, :cond_45

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_42

    const/16 v3, 0x20

    goto :goto_44

    :cond_42
    const/16 v3, 0x10

    :goto_44
    or-int/2addr v2, v3

    :cond_45
    and-int/lit16 v3, v9, 0x180

    if-nez v3, :cond_55

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_52

    const/16 v3, 0x100

    goto :goto_54

    :cond_52
    const/16 v3, 0x80

    :goto_54
    or-int/2addr v2, v3

    :cond_55
    move v11, v2

    .end local v2    # "$dirty":I
    .local v11, "$dirty":I
    and-int/lit16 v2, v11, 0x93

    const/16 v3, 0x92

    const/4 v7, 0x0

    if-eq v2, v3, :cond_5f

    const/4 v2, 0x1

    goto :goto_60

    :cond_5f
    move v2, v7

    :goto_60
    and-int/lit8 v3, v11, 0x1

    invoke-interface {v10, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_48c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_74

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.DecksScreen (DecksScreen.kt:15)"

    invoke-static {v0, v11, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_74
    new-array v0, v7, [Ljava/lang/Object;

    .line 17
    const v2, 0x4f5e21ce

    const-string v13, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\1":Z
    move-object v3, v10

    .local v3, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 39
    .local v14, "$i$f$cache\\1\\17":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\1":Ljava/lang/Object;
    const/16 v16, 0x0

    .line 40
    .local v16, "$i$a$-let-ComposerKt$cache$1\\2\\39\\1":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v15, v6, :cond_9c

    .line 41
    const/4 v6, 0x0

    .local v6, "$i$a$-cache-DecksScreenKt$DecksScreen$editing$2\\3\\41\\0":I
    new-instance v17, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda24;

    invoke-direct/range {v17 .. v17}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda24;-><init>()V

    .end local v6    # "$i$a$-cache-DecksScreenKt$DecksScreen$editing$2\\3\\41\\0":I
    move-object/from16 v6, v17

    .line 42
    .local v6, "value\\2":Ljava/lang/Object;
    invoke-interface {v3, v6}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 43
    move-object v15, v6

    .end local v6    # "value\\2":Ljava/lang/Object;
    goto :goto_9d

    .line 44
    :cond_9c
    nop

    .line 39
    .end local v15    # "it\\1":Ljava/lang/Object;
    .end local v16    # "$i$a$-let-ComposerKt$cache$1\\2\\39\\1":I
    :goto_9d
    nop

    .line 17
    .end local v2    # "invalid\\1":Z
    .end local v3    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\1\\17":I
    check-cast v15, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v2, 0x30

    invoke-static {v0, v15, v10, v2}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Landroidx/compose/runtime/MutableState;

    .local v6, "editing$delegate":Landroidx/compose/runtime/MutableState;
    new-array v0, v7, [Ljava/lang/Object;

    const v3, 0x4f5e29e6

    invoke-static {v10, v3, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v3, 0x0

    .local v3, "invalid\\4":Z
    move-object v14, v10

    .local v14, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 39
    .local v15, "$i$f$cache\\4\\17":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\4":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 40
    .local v17, "$i$a$-let-ComposerKt$cache$1\\5\\39\\4":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v4

    if-ne v12, v4, :cond_d2

    .line 41
    const/4 v4, 0x0

    .local v4, "$i$a$-cache-DecksScreenKt$DecksScreen$adding$2\\6\\41\\0":I
    new-instance v18, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda5;

    invoke-direct/range {v18 .. v18}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda5;-><init>()V

    .end local v4    # "$i$a$-cache-DecksScreenKt$DecksScreen$adding$2\\6\\41\\0":I
    move-object/from16 v4, v18

    .line 42
    .local v4, "value\\5":Ljava/lang/Object;
    invoke-interface {v14, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 43
    move-object v12, v4

    .end local v4    # "value\\5":Ljava/lang/Object;
    goto :goto_d3

    .line 44
    :cond_d2
    nop

    .line 39
    .end local v12    # "it\\4":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\5\\39\\4":I
    :goto_d3
    nop

    .line 17
    .end local v3    # "invalid\\4":Z
    .end local v14    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\4\\17":I
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v12, v10, v2}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/MutableState;

    .local v0, "adding$delegate":Landroidx/compose/runtime/MutableState;
    new-array v3, v7, [Ljava/lang/Object;

    const v4, 0x4f5e314e

    invoke-static {v10, v4, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\7":Z
    move-object v12, v10

    .local v12, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 39
    .local v14, "$i$f$cache\\7\\17":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\7":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 40
    .local v17, "$i$a$-let-ComposerKt$cache$1\\8\\39\\7":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v15, v7, :cond_105

    .line 41
    const/4 v7, 0x0

    .local v7, "$i$a$-cache-DecksScreenKt$DecksScreen$deleting$2\\9\\41\\0":I
    new-instance v18, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda6;

    invoke-direct/range {v18 .. v18}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda6;-><init>()V

    .end local v7    # "$i$a$-cache-DecksScreenKt$DecksScreen$deleting$2\\9\\41\\0":I
    move-object/from16 v7, v18

    .line 42
    .local v7, "value\\8":Ljava/lang/Object;
    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 43
    move-object v15, v7

    .end local v7    # "value\\8":Ljava/lang/Object;
    goto :goto_106

    .line 44
    :cond_105
    nop

    .line 39
    .end local v15    # "it\\7":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\8\\39\\7":I
    :goto_106
    nop

    .line 17
    .end local v4    # "invalid\\7":Z
    .end local v12    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\7\\17":I
    check-cast v15, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v3, v15, v10, v2}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/compose/runtime/MutableState;

    const/4 v4, 0x0

    .local v3, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    new-array v7, v4, [Ljava/lang/Object;

    .line 18
    const v4, 0x4f5e3943

    invoke-static {v10, v4, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\10":Z
    move-object v12, v10

    .local v12, "$this$cache\\10":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 45
    .local v14, "$i$f$cache\\10\\18":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\10":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 46
    .local v17, "$i$a$-let-ComposerKt$cache$1\\11\\45\\10":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v15, v2, :cond_139

    .line 47
    const/4 v2, 0x0

    .local v2, "$i$a$-cache-DecksScreenKt$DecksScreen$name$2\\12\\47\\0":I
    new-instance v18, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda7;

    invoke-direct/range {v18 .. v18}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda7;-><init>()V

    .end local v2    # "$i$a$-cache-DecksScreenKt$DecksScreen$name$2\\12\\47\\0":I
    move-object/from16 v2, v18

    .line 48
    .local v2, "value\\11":Ljava/lang/Object;
    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 49
    move-object v15, v2

    .end local v2    # "value\\11":Ljava/lang/Object;
    goto :goto_13a

    .line 50
    :cond_139
    nop

    .line 45
    .end local v15    # "it\\10":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\11\\45\\10":I
    :goto_13a
    nop

    .line 18
    .end local v4    # "invalid\\10":Z
    .end local v12    # "$this$cache\\10":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\10\\18":I
    check-cast v15, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v2, 0x30

    invoke-static {v7, v15, v10, v2}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "name$delegate":Landroidx/compose/runtime/MutableState;
    const v2, 0x4f5e3dd7

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\13":Z
    move-object v7, v10

    .local v7, "$this$cache\\13":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 45
    .local v12, "$i$f$cache\\13\\18":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\13":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 46
    .local v15, "$i$a$-let-ComposerKt$cache$1\\14\\45\\13":I
    sget-object v17, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v18, v2

    .end local v2    # "invalid\\13":Z
    .local v18, "invalid\\13":Z
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x0

    if-ne v14, v2, :cond_171

    .line 47
    const/4 v2, 0x0

    .line 18
    .local v2, "$i$a$-cache-DecksScreenKt$DecksScreen$error$2\\15\\47\\0":I
    move/from16 v17, v2

    const/4 v2, 0x2

    .end local v2    # "$i$a$-cache-DecksScreenKt$DecksScreen$error$2\\15\\47\\0":I
    .local v17, "$i$a$-cache-DecksScreenKt$DecksScreen$error$2\\15\\47\\0":I
    invoke-static {v5, v5, v2, v5}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v17

    .line 47
    .end local v17    # "$i$a$-cache-DecksScreenKt$DecksScreen$error$2\\15\\47\\0":I
    move-object/from16 v2, v17

    .line 48
    .local v2, "value\\14":Ljava/lang/Object;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 49
    move-object v14, v2

    .end local v2    # "value\\14":Ljava/lang/Object;
    goto :goto_172

    .line 50
    :cond_171
    nop

    .line 45
    .end local v14    # "it\\13":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\14\\45\\13":I
    :goto_172
    nop

    .line 18
    .end local v7    # "$this$cache\\13":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\13\\18":I
    .end local v18    # "invalid\\13":Z
    move-object v7, v14

    check-cast v7, Landroidx/compose/runtime/MutableState;

    .local v7, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v2, 0x4f5e44af    # 3.7290432E9f

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\16":Z
    move-object v12, v10

    .local v12, "$this$cache\\16":Landroidx/compose/runtime/Composer;
    const/4 v14, 0x0

    .line 45
    .local v14, "$i$f$cache\\16\\18":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v15

    .local v15, "it\\16":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 46
    .local v17, "$i$a$-let-ComposerKt$cache$1\\17\\45\\16":I
    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v15, v5, :cond_1a9

    .line 47
    const/4 v5, 0x0

    .line 18
    .local v5, "$i$a$-cache-DecksScreenKt$DecksScreen$busy$2\\18\\47\\0":I
    move/from16 v18, v2

    const/16 v20, 0x0

    .end local v2    # "invalid\\16":Z
    .local v18, "invalid\\16":Z
    invoke-static/range {v20 .. v20}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    move/from16 v22, v5

    move-object/from16 v19, v7

    const/4 v5, 0x2

    const/4 v7, 0x0

    .end local v5    # "$i$a$-cache-DecksScreenKt$DecksScreen$busy$2\\18\\47\\0":I
    .end local v7    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v19, "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v22, "$i$a$-cache-DecksScreenKt$DecksScreen$busy$2\\18\\47\\0":I
    invoke-static {v2, v7, v5, v7}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v2

    .line 47
    .end local v22    # "$i$a$-cache-DecksScreenKt$DecksScreen$busy$2\\18\\47\\0":I
    nop

    .line 48
    .local v2, "value\\17":Ljava/lang/Object;
    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 49
    move-object v15, v2

    .end local v2    # "value\\17":Ljava/lang/Object;
    goto :goto_1af

    .line 50
    .end local v18    # "invalid\\16":Z
    .end local v19    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "invalid\\16":Z
    .restart local v7    # "error$delegate":Landroidx/compose/runtime/MutableState;
    :cond_1a9
    move/from16 v18, v2

    move-object/from16 v19, v7

    const/16 v20, 0x0

    .line 45
    .end local v2    # "invalid\\16":Z
    .end local v7    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .end local v15    # "it\\16":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\17\\45\\16":I
    .restart local v18    # "invalid\\16":Z
    .restart local v19    # "error$delegate":Landroidx/compose/runtime/MutableState;
    :goto_1af
    nop

    .line 18
    .end local v12    # "$this$cache\\16":Landroidx/compose/runtime/Composer;
    .end local v14    # "$i$f$cache\\16\\18":I
    .end local v18    # "invalid\\16":Z
    move-object v12, v15

    check-cast v12, Landroidx/compose/runtime/MutableState;

    .local v12, "busy$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v2, 0x0

    .local v2, "$changed\\19":I
    move-object v5, v10

    .local v5, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 51
    .local v7, "$i$f$rememberCoroutineScope\\19\\18":I
    const v14, 0x2e20b340

    const-string v15, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp"

    invoke-static {v5, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 52
    nop

    .line 56
    move-object v14, v5

    .line 57
    .local v14, "composer\\19":Landroidx/compose/runtime/Composer;
    const v15, 0x28c10104

    move/from16 v17, v2

    .end local v2    # "$changed\\19":I
    .local v17, "$changed\\19":I
    const-string v2, "CC(remember):Effects.kt#9igjgp"

    invoke-static {v5, v15, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v2, 0x0

    .local v2, "invalid\\20":Z
    move-object v15, v5

    .local v15, "$this$cache\\20":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 45
    .local v18, "$i$f$cache\\20\\57":I
    move/from16 v22, v2

    .end local v2    # "invalid\\20":Z
    .local v22, "invalid\\20":Z
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\20":Ljava/lang/Object;
    const/16 v23, 0x0

    .line 46
    .local v23, "$i$a$-let-ComposerKt$cache$1\\21\\45\\20":I
    sget-object v24, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v25, v5

    .end local v5    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\19":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v2, v5, :cond_1f8

    .line 47
    const/4 v5, 0x0

    .line 57
    .local v5, "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\22\\47\\19":I
    const/16 v24, 0x0

    .line 58
    .local v24, "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\23\\57\\0":I
    sget-object v24, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 57
    .end local v24    # "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\23\\57\\0":I
    move-object/from16 v26, v2

    .end local v2    # "it\\20":Ljava/lang/Object;
    .local v26, "it\\20":Ljava/lang/Object;
    move-object/from16 v2, v24

    check-cast v2, Lkotlin/coroutines/CoroutineContext;

    invoke-static {v2, v14}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v2

    .line 47
    .end local v5    # "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\22\\47\\19":I
    nop

    .line 48
    .local v2, "value\\21":Ljava/lang/Object;
    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 49
    nop

    .end local v2    # "value\\21":Ljava/lang/Object;
    goto :goto_1fa

    .line 50
    .end local v26    # "it\\20":Ljava/lang/Object;
    .local v2, "it\\20":Ljava/lang/Object;
    :cond_1f8
    move-object/from16 v26, v2

    .line 45
    .end local v2    # "it\\20":Ljava/lang/Object;
    .end local v23    # "$i$a$-let-ComposerKt$cache$1\\21\\45\\20":I
    :goto_1fa
    nop

    .line 57
    .end local v15    # "$this$cache\\20":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$f$cache\\20\\57":I
    .end local v22    # "invalid\\20":Z
    check-cast v2, Lkotlinx/coroutines/CoroutineScope;

    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 51
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 57
    nop

    .line 18
    .end local v7    # "$i$f$rememberCoroutineScope\\19\\18":I
    .end local v14    # "composer\\19":Landroidx/compose/runtime/Composer;
    .end local v17    # "$changed\\19":I
    .end local v25    # "$composer\\19":Landroidx/compose/runtime/Composer;
    move-object/from16 v23, v2

    .line 19
    .local v23, "scope":Lkotlinx/coroutines/CoroutineScope;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v14, 0x1

    invoke-static {v2, v5, v14, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    const/16 v2, 0x16

    .local v2, "$this$dp\\24":I
    const/4 v5, 0x0

    .line 59
    .local v5, "$i$f$getDp\\24\\19":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 19
    .end local v2    # "$this$dp\\24":I
    .end local v5    # "$i$f$getDp\\24\\19":I
    const/16 v5, 0x12

    .local v5, "$this$dp\\25":I
    const/4 v7, 0x0

    .line 59
    .local v7, "$i$f$getDp\\25\\19":I
    int-to-float v14, v5

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 19
    .end local v5    # "$this$dp\\25":I
    .end local v7    # "$i$f$getDp\\25\\19":I
    const/16 v7, 0x16

    .local v7, "$this$dp\\26":I
    const/4 v14, 0x0

    .line 59
    .local v14, "$i$f$getDp\\26\\19":I
    int-to-float v8, v7

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 19
    .end local v7    # "$this$dp\\26":I
    .end local v14    # "$i$f$getDp\\26\\19":I
    const/16 v8, 0x1c

    .local v8, "$this$dp\\27":I
    const/4 v14, 0x0

    .line 59
    .local v14, "$i$f$getDp\\27\\19":I
    move-object/from16 v17, v12

    .end local v12    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v17, "busy$delegate":Landroidx/compose/runtime/MutableState;
    int-to-float v12, v8

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 19
    .end local v8    # "$this$dp\\27":I
    .end local v14    # "$i$f$getDp\\27\\19":I
    invoke-static {v2, v5, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v12

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v5, 0x10

    .local v5, "$this$dp\\28":I
    const/4 v7, 0x0

    .line 59
    .local v7, "$i$f$getDp\\28\\19":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 19
    .end local v5    # "$this$dp\\28":I
    .end local v7    # "$i$f$getDp\\28\\19":I
    invoke-virtual {v2, v5}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    move-object v14, v2

    check-cast v14, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    const v2, 0x4f5e638a

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v2, v5

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v2, v5

    and-int/lit16 v5, v11, 0x380

    const/16 v7, 0x100

    if-ne v5, v7, :cond_264

    const/4 v7, 0x1

    goto :goto_266

    :cond_264
    move/from16 v7, v20

    :goto_266
    or-int/2addr v2, v7

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v2, v5

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int v8, v2, v5

    .local v8, "invalid\\29":Z
    move-object v2, v10

    .local v2, "$this$cache\\29":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 60
    .local v18, "$i$f$cache\\29\\19":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\29":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 61
    .local v20, "$i$a$-let-ComposerKt$cache$1\\30\\60\\29":I
    if-nez v8, :cond_28f

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_286

    goto :goto_28f

    .line 65
    :cond_286
    move/from16 p3, v8

    move-object/from16 v7, v19

    move-object v8, v2

    move-object v2, v0

    move-object v0, v5

    move-object v5, v6

    goto :goto_2ac

    .line 62
    :cond_28f
    :goto_28f
    const/16 v21, 0x0

    .line 19
    .local v21, "$i$a$-cache-DecksScreenKt$DecksScreen$1\\31\\62\\0":I
    move-object v7, v2

    move-object v2, v0

    .end local v0    # "adding$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "adding$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "$this$cache\\29":Landroidx/compose/runtime/Composer;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;

    move/from16 p3, v8

    move-object v8, v7

    move-object v7, v3

    move-object v3, v4

    move-object/from16 v4, v19

    move-object/from16 v19, v5

    move-object/from16 v5, p2

    .end local v5    # "it\\29":Ljava/lang/Object;
    .local v3, "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v8, "$this$cache\\29":Landroidx/compose/runtime/Composer;
    .local v19, "it\\29":Ljava/lang/Object;
    .local p3, "invalid\\29":Z
    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 62
    move-object v5, v4

    move-object v4, v3

    move-object v3, v7

    move-object v7, v5

    move-object v5, v6

    .line 63
    .end local v6    # "editing$delegate":Landroidx/compose/runtime/MutableState;
    .end local v21    # "$i$a$-cache-DecksScreenKt$DecksScreen$1\\31\\62\\0":I
    .local v0, "value\\30":Ljava/lang/Object;
    .local v3, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "editing$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 64
    nop

    .line 60
    .end local v0    # "value\\30":Ljava/lang/Object;
    .end local v19    # "it\\29":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\30\\60\\29":I
    :goto_2ac
    nop

    .line 19
    .end local v8    # "$this$cache\\29":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$f$cache\\29\\19":I
    .end local p3    # "invalid\\29":Z
    move-object/from16 v19, v0

    check-cast v19, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v21, 0x6186

    const/16 v22, 0x1ea

    move v0, v11

    .end local v11    # "$dirty":I
    .local v0, "$dirty":I
    const/4 v11, 0x0

    move-object v1, v13

    const/4 v13, 0x0

    move-object/from16 v28, v10

    move-object v10, v15

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v28, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    const/4 v6, 0x1

    const/16 v16, 0x0

    move-object/from16 v8, v17

    .end local v17    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v8, "busy$delegate":Landroidx/compose/runtime/MutableState;
    const/16 v17, 0x0

    const/16 v18, 0x0

    move-object/from16 v20, v8

    move v8, v0

    move-object v0, v1

    move v1, v6

    move-object/from16 v6, v20

    move-object/from16 v20, v28

    .end local v0    # "$dirty":I
    .end local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v8, "$dirty":I
    .local v20, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 35
    move-object/from16 v10, v20

    .end local v20    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v11

    const v12, -0x63a3a7ab

    if-nez v11, :cond_300

    invoke-static {v5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_2e7

    goto :goto_300

    :cond_2e7
    invoke-interface {v10, v12}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 p3, v6

    move v6, v1

    move-object/from16 v1, p3

    move-object/from16 v33, v4

    move-object/from16 p3, v5

    move-object v4, v7

    move-object/from16 v32, v23

    move-object v5, v0

    move-object v7, v2

    move v0, v12

    const/16 v2, 0x36

    goto/16 :goto_3d5

    :cond_300
    :goto_300
    const v11, 0x4f5f0529

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "34@2464L40,34@2780L427,34@3222L72,34@2511L39,34@2556L209,34@2435L860"

    invoke-static {v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v11, 0x4f5f0595

    invoke-static {v10, v11, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v11

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v14

    or-int/2addr v11, v14

    .local v11, "invalid\\32":Z
    move-object v14, v10

    .local v14, "$this$cache\\32":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 66
    .local v15, "$i$f$cache\\32\\35":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\32":Ljava/lang/Object;
    const/16 v17, 0x0

    .line 67
    .local v17, "$i$a$-let-ComposerKt$cache$1\\33\\66\\32":I
    if-nez v11, :cond_32e

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v1, v12, :cond_32d

    goto :goto_32e

    .line 71
    :cond_32d
    goto :goto_339

    .line 68
    :cond_32e
    :goto_32e
    const/4 v12, 0x0

    .line 35
    .local v12, "$i$a$-cache-DecksScreenKt$DecksScreen$2\\34\\68\\0":I
    new-instance v13, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda9;

    invoke-direct {v13, v6, v2, v5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 68
    .end local v12    # "$i$a$-cache-DecksScreenKt$DecksScreen$2\\34\\68\\0":I
    nop

    .line 69
    .local v13, "value\\33":Ljava/lang/Object;
    invoke-interface {v14, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 70
    move-object v1, v13

    .line 66
    .end local v1    # "it\\32":Ljava/lang/Object;
    .end local v13    # "value\\33":Ljava/lang/Object;
    .end local v17    # "$i$a$-let-ComposerKt$cache$1\\33\\66\\32":I
    :goto_339
    nop

    .line 35
    .end local v11    # "invalid\\32":Z
    .end local v14    # "$this$cache\\32":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$cache\\32\\35":I
    move-object v11, v1

    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v1, v0

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;

    move-object v13, v1

    move-object v12, v3

    move-object/from16 v1, v23

    const/4 v14, 0x1

    move-object/from16 v3, p1

    .end local v3    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v23    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v1, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v12, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda10;-><init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object v3, v0

    move-object v0, v4

    move-object v4, v7

    move-object v7, v2

    move-object v2, v1

    move-object v1, v6

    move-object v6, v5

    .end local v5    # "editing$delegate":Landroidx/compose/runtime/MutableState;
    .local v0, "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v4, "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v6, "editing$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "adding$delegate":Landroidx/compose/runtime/MutableState;
    const v5, 0x3389cf7a

    const/16 v15, 0x36

    invoke-static {v5, v14, v3, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    new-instance v5, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda12;

    invoke-direct {v5, v7, v6, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object/from16 v32, v2

    .end local v2    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v32, "scope":Lkotlinx/coroutines/CoroutineScope;
    const v2, 0x2a3dbc7c

    invoke-static {v2, v14, v5, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function2;

    new-instance v5, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v5, v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda13;-><init>(Landroidx/compose/runtime/MutableState;)V

    move-object/from16 v16, v2

    const v2, 0x20f1a97e

    invoke-static {v2, v14, v5, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function2;

    new-instance v5, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v5, v0, v4, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda14;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object/from16 v33, v0

    .end local v0    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .local v33, "name$delegate":Landroidx/compose/runtime/MutableState;
    const v0, 0x1c4b9fff

    invoke-static {v0, v14, v5, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function2;

    const/16 v30, 0x0

    const/16 v31, 0x3f94

    move-object v5, v12

    .end local v12    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "deleting$delegate":Landroidx/compose/runtime/MutableState;
    const/4 v12, 0x0

    move/from16 v17, v14

    const/4 v14, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const-wide/16 v18, 0x0

    move/from16 v22, v20

    const-wide/16 v20, 0x0

    move/from16 v24, v22

    const-wide/16 v22, 0x0

    move/from16 v26, v24

    const-wide/16 v24, 0x0

    move/from16 v27, v26

    const/16 v26, 0x0

    move/from16 v28, v27

    const/16 v27, 0x0

    const v29, 0x1b0c30

    move/from16 p3, v15

    move-object v15, v2

    move/from16 v2, p3

    move-object/from16 p3, v6

    move/from16 v6, v28

    move-object/from16 v28, v10

    move-object v10, v11

    move-object v11, v3

    move-object v3, v5

    move-object v5, v13

    move-object/from16 v13, v16

    move-object/from16 v16, v0

    const v0, -0x63a3a7ab

    .end local v5    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v6    # "editing$delegate":Landroidx/compose/runtime/MutableState;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .local p3, "editing$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static/range {v10 .. v31}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v10, v28

    .end local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 36
    :goto_3d5
    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$7(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v11

    if-eqz v11, :cond_476

    const v0, 0x4f5f71e0    # 3.748782E9f

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "35@3344L24,35@3490L280,35@3785L60,35@3398L77,35@3315L531"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v0, 0x4f5f7385

    invoke-static {v10, v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\35":Z
    move-object v5, v10

    .local v5, "$this$cache\\35":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 72
    .local v11, "$i$f$cache\\35\\36":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\35":Ljava/lang/Object;
    const/4 v13, 0x0

    .line 73
    .local v13, "$i$a$-let-ComposerKt$cache$1\\36\\72\\35":I
    if-nez v0, :cond_403

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v12, v14, :cond_402

    goto :goto_403

    .line 77
    :cond_402
    goto :goto_40e

    .line 74
    :cond_403
    :goto_403
    const/4 v14, 0x0

    .line 36
    .local v14, "$i$a$-cache-DecksScreenKt$DecksScreen$7\\37\\74\\0":I
    new-instance v15, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda25;

    invoke-direct {v15, v1, v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda25;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 74
    .end local v14    # "$i$a$-cache-DecksScreenKt$DecksScreen$7\\37\\74\\0":I
    nop

    .line 75
    .local v15, "value\\36":Ljava/lang/Object;
    invoke-interface {v5, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 76
    move-object v12, v15

    .line 72
    .end local v12    # "it\\35":Ljava/lang/Object;
    .end local v13    # "$i$a$-let-ComposerKt$cache$1\\36\\72\\35":I
    .end local v15    # "value\\36":Ljava/lang/Object;
    :goto_40e
    nop

    .line 36
    .end local v0    # "invalid\\35":Z
    .end local v5    # "$this$cache\\35":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$cache\\35\\36":I
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda1;

    move v15, v2

    move-object v5, v4

    move-object/from16 v2, p1

    move-object v4, v1

    move-object/from16 v1, v32

    .end local v32    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v1, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v4, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "error$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda1;-><init>(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    move-object v1, v4

    move-object v4, v5

    .end local v5    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .local v1, "busy$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "error$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v32    # "scope":Lkotlinx/coroutines/CoroutineScope;
    const v5, -0x6fe0ae5d

    invoke-static {v5, v6, v0, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v11, v0

    check-cast v11, Lkotlin/jvm/functions/Function2;

    new-instance v0, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v0, v3, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda2;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v5, -0x5673f9db

    invoke-static {v5, v6, v0, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v13, v0

    check-cast v13, Lkotlin/jvm/functions/Function2;

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$-1023886681$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    new-instance v5, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v5, v4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda3;-><init>(Landroidx/compose/runtime/MutableState;)V

    const v14, 0x4faf14e8

    invoke-static {v14, v6, v5, v10, v15}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v16, v5

    check-cast v16, Lkotlin/jvm/functions/Function2;

    const/16 v30, 0x0

    const/16 v31, 0x3f94

    move-object/from16 v28, v10

    move-object v10, v12

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v28    # "$composer":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    const/4 v14, 0x0

    const/16 v17, 0x0

    const-wide/16 v18, 0x0

    const-wide/16 v20, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const v29, 0x1b0c30

    move-object/from16 v5, p0

    move-object/from16 v6, p2

    move-object v15, v0

    invoke-static/range {v10 .. v31}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v10, v28

    .end local v28    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_47f

    :cond_476
    move-object/from16 v5, p0

    move-object/from16 v2, p1

    move-object/from16 v6, p2

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_47f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_493

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local v3    # "deleting$delegate":Landroidx/compose/runtime/MutableState;
    .end local v4    # "error$delegate":Landroidx/compose/runtime/MutableState;
    .end local v7    # "adding$delegate":Landroidx/compose/runtime/MutableState;
    .end local v32    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v33    # "name$delegate":Landroidx/compose/runtime/MutableState;
    .end local p3    # "editing$delegate":Landroidx/compose/runtime/MutableState;
    goto :goto_493

    .line 16
    .end local v8    # "$dirty":I
    .local v11, "$dirty":I
    :cond_48c
    move-object v6, v5

    move-object v2, v8

    move v8, v11

    move-object v5, v1

    .end local v11    # "$dirty":I
    .restart local v8    # "$dirty":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 37
    :cond_493
    :goto_493
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_4a1

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v1, v5, v2, v6, v9}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;I)V

    invoke-interface {v0, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_4a1
    return-void
.end method

.method private static final DecksScreen$lambda$0$0()Landroidx/compose/runtime/MutableState;
    .registers 2

    .line 17
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 17
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 78
    .local v3, "$i$f$getValue\\1\\17":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\17":I
    check-cast v0, Ljava/lang/String;

    .line 17
    return-object v0
.end method

.method private static final DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 18
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 81
    .local v3, "$i$f$getValue\\1\\18":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\18":I
    check-cast v0, Ljava/lang/String;

    .line 18
    return-object v0
.end method

.method private static final DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 18
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 82
    .local v4, "$i$f$setValue\\1\\18":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 83
    nop

    .line 18
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\18":I
    return-void
.end method

.method private static final DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 18
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 84
    .local v3, "$i$f$getValue\\1\\18":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\18":I
    check-cast v0, Ljava/lang/String;

    .line 18
    return-object v0
.end method

.method private static final DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 18
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 85
    .local v4, "$i$f$setValue\\1\\18":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 86
    nop

    .line 18
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\18":I
    return-void
.end method

.method private static final DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 18
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 87
    .local v3, "$i$f$getValue\\1\\18":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\18":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 18
    return v0
.end method

.method private static final DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 18
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 88
    .local v4, "$i$f$setValue\\1\\18":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 89
    nop

    .line 18
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\18":I
    return-void
.end method

.method private static final DecksScreen$lambda$18$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 25
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$onDeck"    # Lkotlin/jvm/functions/Function1;
    .param p5, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p6, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p7, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    move-object/from16 v0, p1

    move-object/from16 v5, p2

    move-object/from16 v7, p3

    const-string v1, "$this$LazyColumn"

    move-object/from16 v8, p7

    invoke-static {v8, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda15;

    move-object/from16 v14, p0

    invoke-direct {v1, v14, v0, v5, v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda15;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v2, -0x79e1e488

    const/4 v15, 0x1

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lkotlin/jvm/functions/Function3;

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 21
    invoke-virtual {v14}, Lcom/xunji/flashcards/ui/MainUiState;->getLoading()Z

    move-result v1

    if-eqz v1, :cond_3b

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$-1648141507$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v11

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object/from16 v8, p7

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 22
    :cond_3b
    invoke-virtual {v14}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    move-result v1

    if-eqz v1, :cond_63

    invoke-virtual {v14}, Lcom/xunji/flashcards/ui/MainUiState;->getLoading()Z

    move-result v1

    if-nez v1, :cond_63

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda16;

    invoke-direct {v1, v0, v5, v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda16;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v2, 0x3c3a1666

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    move-object v11, v1

    check-cast v11, Lkotlin/jvm/functions/Function3;

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object/from16 v8, p7

    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 23
    :cond_63
    invoke-virtual {v14}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v2

    .local v2, "items\\1":Ljava/util/List;
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda17;

    invoke-direct {v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda17;-><init>()V

    .local v1, "key\\1":Lkotlin/jvm/functions/Function1;
    move-object/from16 v8, p7

    .local v8, "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    move-object v9, v1

    .line 90
    .end local v1    # "key\\1":Lkotlin/jvm/functions/Function1;
    .local v9, "key\\1":Lkotlin/jvm/functions/Function1;
    nop

    .line 93
    sget-object v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$1;->INSTANCE:Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$1;

    move-object v10, v1

    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 90
    .local v10, "contentType\\1":Lkotlin/jvm/functions/Function1;
    const/4 v11, 0x0

    .line 96
    .local v11, "$i$f$items\\1\\23":I
    nop

    .line 97
    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v12

    .line 98
    nop

    .line 96
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$2;

    invoke-direct {v1, v9, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$2;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    move-object v13, v1

    check-cast v13, Lkotlin/jvm/functions/Function1;

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$3;

    invoke-direct {v1, v10, v2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$3;-><init>(Lkotlin/jvm/functions/Function1;Ljava/util/List;)V

    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 100
    move-object v3, v1

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;

    move-object/from16 v4, p5

    move-object/from16 v6, p6

    move-object/from16 v16, v3

    move-object/from16 v3, p4

    invoke-direct/range {v1 .. v7}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$lambda$18$0$$inlined$items$default$4;-><init>(Ljava/util/List;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    const v3, 0x2fd4df92

    invoke-static {v3, v15, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function4;

    .line 96
    move-object/from16 v3, v16

    invoke-interface {v8, v12, v13, v3, v1}, Landroidx/compose/foundation/lazy/LazyListScope;->items(ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;)V

    .line 102
    nop

    .line 34
    .end local v2    # "items\\1":Ljava/util/List;
    .end local v8    # "$this$items_u24default\\1":Landroidx/compose/foundation/lazy/LazyListScope;
    .end local v9    # "key\\1":Lkotlin/jvm/functions/Function1;
    .end local v10    # "contentType\\1":Lkotlin/jvm/functions/Function1;
    .end local v11    # "$i$f$items\\1\\23":I
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final DecksScreen$lambda$18$0$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 45
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v0, p1

    move-object/from16 v1, p2

    move-object/from16 v2, p5

    move/from16 v3, p6

    const-string v4, "$this$item"

    move-object/from16 v5, p4

    invoke-static {v5, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "C19@1140L268:DecksScreen.kt#i35lj1"

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v4, v3, 0x11

    const/16 v6, 0x10

    const/4 v7, 0x1

    if-eq v4, v6, :cond_1d

    move v4, v7

    goto :goto_1e

    :cond_1d
    const/4 v4, 0x0

    :goto_1e
    and-int/lit8 v6, v3, 0x1

    invoke-interface {v2, v4, v6}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_202

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_35

    const/4 v4, -0x1

    const-string v6, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:19)"

    const v9, -0x79e1e488

    invoke-static {v9, v3, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 20
    :cond_35
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v9, 0x0

    invoke-static {v4, v6, v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .local v4, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    check-cast v6, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v6, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .local v7, "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v9, 0x1b6

    .local v9, "$changed\\1":I
    move-object/from16 v10, p5

    .local v10, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 103
    .local v11, "$i$f$Row\\1\\20":I
    const v12, 0x3255a44b

    const-string v13, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 104
    shr-int/lit8 v12, v9, 0x3

    and-int/lit8 v12, v12, 0xe

    shr-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    or-int/2addr v12, v13

    invoke-static {v6, v7, v10, v12}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .line 108
    .local v12, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 105
    nop

    .local v13, "$changed\\2":I
    move-object v14, v4

    .local v14, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    .line 109
    .local v15, "$i$f$Layout\\2\\105":I
    const v8, -0x451e1427

    const-string v2, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v10, v8, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 110
    const/4 v2, 0x0

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 111
    .local v2, "compositeKeyHash\\2":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 112
    .local v8, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v17, v2

    .end local v2    # "compositeKeyHash\\2":I
    .local v17, "compositeKeyHash\\2":I
    invoke-static {v10, v14}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 114
    .local v2, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v3, v13, 0x6

    and-int/lit16 v3, v3, 0x380

    move/from16 v19, v3

    const/4 v3, 0x6

    or-int/lit8 v19, v19, 0x6

    .line 113
    nop

    .local v19, "$changed\\3":I
    move-object/from16 v20, v18

    .local v20, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 115
    .local v18, "$i$f$ReusableComposeNode\\3\\113":I
    move/from16 v21, v3

    const v3, -0x20f7d59c

    move-object/from16 v22, v4

    .end local v4    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\1":Landroidx/compose/ui/Modifier;
    const-string v4, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v10, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 116
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_b4

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 117
    :cond_b4
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 118
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_c3

    .line 119
    move-object/from16 v3, v20

    .end local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c8

    .line 121
    .end local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_c3
    move-object/from16 v3, v20

    .end local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 123
    :goto_c8
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 124
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\123\\2":I
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v24, v3

    .end local v3    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v24, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 125
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v8, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 126
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v23, 0x0

    .line 127
    .local v23, "$i$f$set-impl\\5\\126":I
    move-object/from16 v25, v4

    .local v25, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 128
    .local v26, "$i$a$-with-Updater$set$1\\6\\127\\5":I
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v27

    if-nez v27, :cond_108

    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v27, v6

    .end local v6    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v27, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_105

    goto :goto_10a

    :cond_105
    move-object/from16 v6, v25

    goto :goto_11a

    .end local v27    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v6    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_108
    move-object/from16 v27, v6

    .line 129
    .end local v6    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v27    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_10a
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v25

    .end local v25    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 130
    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 132
    :goto_11a
    nop

    .line 127
    .end local v6    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-with-Updater$set$1\\6\\127\\5":I
    nop

    .line 132
    nop

    .line 133
    .end local v3    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v23    # "$i$f$set-impl\\5\\126":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 134
    nop

    .line 123
    .end local v4    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\123\\2":I
    nop

    .line 135
    shr-int/lit8 v3, v19, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\7":I
    move-object v4, v10

    .local v4, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 106
    .local v5, "$i$a$-Layout-RowKt$Row$1\\7\\135\\1":I
    const v6, 0x56ccd6f5

    move-object/from16 v20, v2

    .end local v2    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v20, "materialized\\2":Landroidx/compose/ui/Modifier;
    const-string v2, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v9, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\8":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$DecksScreen_u24lambda_u2418_u240_u240_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v33, v4

    .local v33, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 20
    .local v23, "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$1$1\\8\\106\\0":I
    move-object/from16 v25, v2

    .end local v2    # "$this$DecksScreen_u24lambda_u2418_u240_u240_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .local v25, "$this$DecksScreen_u24lambda_u2418_u240_u240_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    const v2, -0x467e3100

    move/from16 v26, v3

    .end local v3    # "$changed\\7":I
    .local v26, "$changed\\7":I
    const-string v3, "C19@1263L72,19@1360L34,19@1336L70:DecksScreen.kt#i35lj1"

    move-object/from16 v36, v4

    .end local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v36, "$composer\\7":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v2

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getCards()Ljava/util/List;

    move-result-object v3

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v3

    move/from16 v37, v5

    .end local v5    # "$i$a$-Layout-RowKt$Row$1\\7\\135\\1":I
    .local v37, "$i$a$-Layout-RowKt$Row$1\\7\\135\\1":I
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " \u4e2a\u724c\u7ec4 \u00b7 "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5f20\u5361\u7247"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const-string v3, "\u8bb0\u5fc6\u82b1\u56ed"

    move/from16 v16, v6

    move/from16 v6, v21

    const/4 v5, 0x0

    .end local v6    # "$changed\\8":I
    .local v16, "$changed\\8":I
    invoke-static {v3, v2, v4, v6, v5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->SectionTitle(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    const v2, -0x24616ea

    const-string v3, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\9":Z
    move-object v3, v4

    .local v3, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 136
    .local v5, "$i$f$cache\\9\\20":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\9":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 137
    .local v21, "$i$a$-let-ComposerKt$cache$1\\10\\136\\9":I
    if-nez v2, :cond_1b8

    sget-object v28, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v29, v2

    .end local v2    # "invalid\\9":Z
    .local v29, "invalid\\9":Z
    invoke-virtual/range {v28 .. v28}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v6, v2, :cond_1b3

    goto :goto_1ba

    .line 141
    :cond_1b3
    move-object/from16 v33, v4

    move-object/from16 v4, p3

    goto :goto_1cb

    .line 137
    .end local v29    # "invalid\\9":Z
    .restart local v2    # "invalid\\9":Z
    :cond_1b8
    move/from16 v29, v2

    .line 138
    .end local v2    # "invalid\\9":Z
    .restart local v29    # "invalid\\9":Z
    :goto_1ba
    const/4 v2, 0x0

    .line 20
    .local v2, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$1$1$1\\11\\138\\8":I
    move/from16 v28, v2

    .end local v2    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$1$1$1\\11\\138\\8":I
    .local v28, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$1$1$1\\11\\138\\8":I
    new-instance v2, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda21;

    move-object/from16 v33, v4

    move-object/from16 v4, p3

    .end local v4    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-direct {v2, v0, v1, v4}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda21;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 138
    .end local v28    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$1$1$1\\11\\138\\8":I
    nop

    .line 139
    .local v2, "value\\10":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 140
    move-object v6, v2

    .line 136
    .end local v2    # "value\\10":Ljava/lang/Object;
    .end local v6    # "it\\9":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\10\\136\\9":I
    :goto_1cb
    nop

    .line 20
    .end local v3    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\9\\20":I
    .end local v29    # "invalid\\9":Z
    move-object/from16 v30, v6

    check-cast v30, Lkotlin/jvm/functions/Function0;

    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v34, 0xc36

    const/16 v35, 0x10

    const-string v28, "add"

    const-string v29, "\u521b\u5efa\u724c\u7ec4"

    const-string v31, "add-deck"

    const/16 v32, 0x0

    invoke-static/range {v28 .. v35}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 106
    .end local v16    # "$changed\\8":I
    .end local v23    # "$i$a$-Row-DecksScreenKt$DecksScreen$1$1$1$1\\8\\106\\0":I
    .end local v25    # "$this$DecksScreen_u24lambda_u2418_u240_u240_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .end local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v36 .. v36}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 135
    .end local v26    # "$changed\\7":I
    .end local v36    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v37    # "$i$a$-Layout-RowKt$Row$1\\7\\135\\1":I
    nop

    .line 142
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 115
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 143
    nop

    .line 109
    .end local v18    # "$i$f$ReusableComposeNode\\3\\113":I
    .end local v19    # "$changed\\3":I
    .end local v24    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 144
    nop

    .line 103
    .end local v8    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v13    # "$changed\\2":I
    .end local v14    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v15    # "$i$f$Layout\\2\\105":I
    .end local v17    # "compositeKeyHash\\2":I
    .end local v20    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 145
    nop

    .end local v7    # "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    .end local v9    # "$changed\\1":I
    .end local v10    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$Row\\1\\20":I
    .end local v12    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v27    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_207

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_207

    .line 20
    :cond_202
    move-object/from16 v4, p3

    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_207
    :goto_207
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final DecksScreen$lambda$18$0$0$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 4
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$error$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 20
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    const-string v0, ""

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p2, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$18$0$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move-object v4, p4

    move v7, p5

    const-string v0, "$this$item"

    move-object v8, p3

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C21@1550L34,21@1498L87:DecksScreen.kt#i35lj1"

    invoke-static {p4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v7, 0x11

    const/16 v1, 0x10

    if-eq v0, v1, :cond_15

    const/4 v0, 0x1

    goto :goto_16

    :cond_15
    const/4 v0, 0x0

    :goto_16
    and-int/lit8 v1, v7, 0x1

    invoke-interface {p4, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_78

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2d

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous>.<anonymous> (DecksScreen.kt:21)"

    const v2, 0x3c3a1666

    invoke-static {v2, p5, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_2d
    const v0, 0x160e1bc8

    const-string v1, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {p4, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    invoke-interface {p4, p1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    .local v0, "invalid\\1":Z
    move-object v1, p4

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 146
    .local v2, "$i$f$cache\\1\\22":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    .local v3, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 147
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\146\\1":I
    if-nez v0, :cond_51

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v3, v6, :cond_50

    goto :goto_51

    .line 151
    :cond_50
    goto :goto_5c

    .line 148
    :cond_51
    :goto_51
    const/4 v6, 0x0

    .line 22
    .local v6, "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$2$1\\3\\148\\0":I
    new-instance v9, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;

    invoke-direct {v9, p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda22;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 148
    .end local v6    # "$i$a$-cache-DecksScreenKt$DecksScreen$1$1$2$1\\3\\148\\0":I
    nop

    .line 149
    .local v9, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 150
    move-object v3, v9

    .line 146
    .end local v3    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\146\\1":I
    .end local v9    # "value\\2":Ljava/lang/Object;
    :goto_5c
    nop

    .line 22
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$f$cache\\1\\22":I
    check-cast v3, Lkotlin/jvm/functions/Function0;

    invoke-static {p4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v5, 0x1b6

    const/4 v6, 0x0

    const-string v0, "\u7ed9\u8bb0\u5fc6\u4e00\u4e2a\u5f52\u5904"

    const-string v1, "\u5c06\u76f8\u4f3c\u7684\u5185\u5bb9\u653e\u8fdb\u540c\u4e00\u4e2a\u724c\u7ec4\uff0c\u590d\u4e60\u65f6\u66f4\u4e13\u6ce8\u3002"

    const-string v2, "\u65b0\u5efa\u724c\u7ec4"

    invoke-static/range {v0 .. v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_7b

    :cond_78
    invoke-interface {p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_7b
    :goto_7b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$18$0$1$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 4
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$error$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 22
    const/4 v0, 0x1

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    const-string v0, ""

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p2, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$18$0$2(Lcom/xunji/core/model/DeckSummary;)Ljava/lang/Object;
    .registers 2
    .param p0, "it"    # Lcom/xunji/core/model/DeckSummary;

    const-string v0, "it"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 23
    invoke-virtual {p0}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Deck;->getId()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final DecksScreen$lambda$19$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 4
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 35
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_e

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    const/4 v0, 0x0

    invoke-static {p2, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    :cond_e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 17
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 79
    .local v4, "$i$f$setValue\\1\\17":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 80
    nop

    .line 17
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\17":I
    return-void
.end method

.method private static final DecksScreen$lambda$20(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 32
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p3, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p5, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p6, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p7, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p8, "$changed"    # I

    move-object/from16 v10, p7

    move/from16 v13, p8

    const-string v0, "C34@2801L315,34@3171L34,34@2782L423:DecksScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_c1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)"

    const v3, 0x3389cf7a

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_29
    invoke-static/range {p5 .. p5}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    xor-int/2addr v0, v2

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const-string v3, "save-deck"

    invoke-static {v1, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const v3, 0x7853dcd5

    const-string v4, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v10, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v15, p0

    invoke-interface {v10, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    move-object/from16 v4, p1

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    or-int/2addr v3, v5

    move-object/from16 v5, p2

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    or-int/2addr v3, v6

    move-object/from16 v6, p3

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    or-int/2addr v3, v7

    move-object/from16 v7, p4

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    or-int/2addr v3, v8

    .local v3, "invalid\\1":Z
    move-object/from16 v8, p7

    .local v8, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 152
    .local v9, "$i$f$cache\\1\\35":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 153
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\152\\1":I
    if-nez v3, :cond_76

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v11, v14, :cond_75

    goto :goto_76

    .line 157
    :cond_75
    goto :goto_8e

    .line 154
    :cond_76
    :goto_76
    const/16 v22, 0x0

    .line 35
    .local v22, "$i$a$-cache-DecksScreenKt$DecksScreen$3$1\\3\\154\\0":I
    new-instance v14, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda18;

    move-object/from16 v16, p5

    move-object/from16 v21, p6

    move-object/from16 v18, v4

    move-object/from16 v17, v5

    move-object/from16 v19, v6

    move-object/from16 v20, v7

    invoke-direct/range {v14 .. v21}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda18;-><init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 154
    .end local v22    # "$i$a$-cache-DecksScreenKt$DecksScreen$3$1\\3\\154\\0":I
    nop

    .line 155
    .local v14, "value\\2":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 156
    move-object v11, v14

    .line 152
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\152\\1":I
    .end local v14    # "value\\2":Ljava/lang/Object;
    :goto_8e
    nop

    .line 35
    .end local v3    # "invalid\\1":Z
    .end local v8    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\1\\35":I
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v3, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda19;

    move-object/from16 v14, p5

    invoke-direct {v3, v14}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda19;-><init>(Landroidx/compose/runtime/MutableState;)V

    const/16 v4, 0x36

    const v5, -0x5254c089

    invoke-static {v5, v2, v3, v10, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v9, v2

    check-cast v9, Lkotlin/jvm/functions/Function3;

    move v2, v0

    move-object v0, v11

    const v11, 0x30000030

    const/16 v12, 0x1f8

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_c6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_c6

    :cond_c1
    move-object/from16 v14, p5

    invoke-interface/range {p7 .. p7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_c6
    :goto_c6
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$20$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 16
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p3, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p5, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p6, "$error$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 35
    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_21

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;

    const/4 v8, 0x0

    move-object v7, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    .end local p1    # "$busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local p2    # "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .end local p3    # "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .end local p4    # "$name$delegate":Landroidx/compose/runtime/MutableState;
    .end local p5    # "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .end local p6    # "$error$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .local v3, "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "$name$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .local v6, "$error$delegate":Landroidx/compose/runtime/MutableState;
    .local v7, "$busy$delegate":Landroidx/compose/runtime/MutableState;
    invoke-direct/range {v1 .. v8}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$3$1$1$1;-><init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    move-object p3, v1

    check-cast p3, Lkotlin/jvm/functions/Function2;

    const/4 p4, 0x3

    const/4 p5, 0x0

    const/4 p1, 0x0

    const/4 p2, 0x0

    invoke-static/range {p0 .. p5}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    goto :goto_27

    .end local v2    # "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .end local v3    # "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$name$delegate":Landroidx/compose/runtime/MutableState;
    .end local v5    # "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .end local v6    # "$error$delegate":Landroidx/compose/runtime/MutableState;
    .end local v7    # "$busy$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p1    # "$busy$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p2    # "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .restart local p3    # "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p4    # "$name$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p5    # "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .restart local p6    # "$error$delegate":Landroidx/compose/runtime/MutableState;
    :cond_21
    move-object v7, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    move-object v5, p5

    move-object v6, p6

    .end local p1    # "$busy$delegate":Landroidx/compose/runtime/MutableState;
    .end local p2    # "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .end local p3    # "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .end local p4    # "$name$delegate":Landroidx/compose/runtime/MutableState;
    .end local p5    # "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .end local p6    # "$error$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v2    # "$viewModel":Lcom/xunji/flashcards/ui/MainViewModel;
    .restart local v3    # "$adding$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v4    # "$name$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v5    # "$editing$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v6    # "$error$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v7    # "$busy$delegate":Landroidx/compose/runtime/MutableState;
    :goto_27
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p1
.end method

.method private static final DecksScreen$lambda$20$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$this$TextButton"    # Landroidx/compose/foundation/layout/RowScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$TextButton"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C34@3173L30:DecksScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    if-eq v2, v4, :cond_18

    const/4 v2, 0x1

    goto :goto_19

    :cond_18
    const/4 v2, 0x0

    :goto_19
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_6d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous>.<anonymous> (DecksScreen.kt:34)"

    const v5, -0x5254c089

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_30
    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    if-eqz v2, :cond_39

    const-string v2, "\u4fdd\u5b58\u4e2d\u2026"

    goto :goto_3b

    :cond_39
    const-string v2, "\u4fdd\u5b58"

    :goto_3b
    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_70

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_70

    :cond_6d
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_70
    :goto_70
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$21(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 21
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v12, p3

    move/from16 v15, p4

    const-string v2, "C34@3235L27,34@3224L68:DecksScreen.kt#i35lj1"

    invoke-static {v12, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v15, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eq v2, v3, :cond_15

    move v2, v4

    goto :goto_16

    :cond_15
    const/4 v2, 0x0

    :goto_16
    and-int/lit8 v3, v15, 0x1

    invoke-interface {v12, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_87

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2d

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)"

    const v5, 0x2a3dbc7c

    invoke-static {v5, v15, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_2d
    const v2, -0x6e3f70c9

    const-string v3, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v12, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\1":Z
    move-object/from16 v3, p3

    .local v3, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 152
    .local v5, "$i$f$cache\\1\\35":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\1":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 153
    .local v7, "$i$a$-let-ComposerKt$cache$1\\2\\152\\1":I
    if-nez v2, :cond_52

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_51

    goto :goto_52

    .line 157
    :cond_51
    goto :goto_5d

    .line 154
    :cond_52
    :goto_52
    const/4 v8, 0x0

    .line 35
    .local v8, "$i$a$-cache-DecksScreenKt$DecksScreen$4$1\\3\\154\\0":I
    new-instance v9, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v9, v0, v1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 154
    .end local v8    # "$i$a$-cache-DecksScreenKt$DecksScreen$4$1\\3\\154\\0":I
    nop

    .line 155
    .local v9, "value\\2":Ljava/lang/Object;
    invoke-interface {v3, v9}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 156
    move-object v6, v9

    .line 152
    .end local v6    # "it\\1":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\2\\152\\1":I
    .end local v9    # "value\\2":Ljava/lang/Object;
    :goto_5d
    nop

    .line 35
    .end local v2    # "invalid\\1":Z
    .end local v3    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\1\\35":I
    move-object v2, v6

    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static/range {p2 .. p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v3

    xor-int/2addr v4, v3

    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$-1537266567$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v11

    const/high16 v13, 0x30000000

    const/16 v14, 0x1fa

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static/range {v2 .. v14}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_8a

    :cond_87
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_8a
    :goto_8a
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final DecksScreen$lambda$21$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 35
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$22(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 29
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C34@2513L35:DecksScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_10

    const/4 v2, 0x1

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_65

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)"

    const v4, 0x20f1a97e

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_28
    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    if-eqz v2, :cond_31

    const-string v2, "\u65b0\u5efa\u724c\u7ec4"

    goto :goto_33

    :cond_31
    const-string v2, "\u91cd\u547d\u540d\u724c\u7ec4"

    :goto_33
    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p1

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_68

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_68

    :cond_65
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_68
    :goto_68
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$23(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 61
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move/from16 v2, p4

    const-string v3, "C34@2558L205:DecksScreen.kt#i35lj1"

    invoke-static {v1, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x3

    const/4 v4, 0x2

    const/4 v6, 0x0

    if-eq v3, v4, :cond_13

    const/4 v3, 0x1

    goto :goto_14

    :cond_13
    move v3, v6

    :goto_14
    and-int/lit8 v4, v2, 0x1

    invoke-interface {v1, v3, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_227

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_2b

    const/4 v3, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:34)"

    const v7, 0x1c4b9fff

    invoke-static {v7, v2, v3, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_2b
    move-object/from16 v3, p3

    .local v3, "$composer\\1":Landroidx/compose/runtime/Composer;
    move v4, v6

    .local v4, "$changed\\1":I
    const/4 v7, 0x0

    .line 158
    .local v7, "$i$f$Column\\1\\35":I
    const v8, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v3, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 159
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 160
    .local v8, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v9}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v9

    .line 161
    .local v9, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 164
    .local v10, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v11, v4, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v9, v10, v3, v11}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 168
    .local v11, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v4, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 165
    move-object v13, v8

    .local v12, "$changed\\2":I
    .local v13, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v14, 0x0

    .line 169
    .local v14, "$i$f$Layout\\2\\165":I
    const v15, -0x451e1427

    const/16 v16, 0x1

    const-string v5, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v3, v15, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 170
    invoke-static {v3, v6}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v5

    .line 171
    .local v5, "compositeKeyHash\\2":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 172
    .local v15, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v3, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    .line 174
    .local v6, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v1, v12, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 173
    nop

    .local v1, "$changed\\3":I
    move-object/from16 v19, v18

    .local v19, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 175
    .local v18, "$i$f$ReusableComposeNode\\3\\173":I
    move/from16 v20, v1

    .end local v1    # "$changed\\3":I
    .local v20, "$changed\\3":I
    const v1, -0x20f7d59c

    const-string v2, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 176
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_9a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 177
    :cond_9a
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 178
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_a9

    .line 179
    move-object/from16 v1, v19

    .end local v19    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_ae

    .line 181
    .end local v1    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_a9
    move-object/from16 v1, v19

    .end local v19    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 183
    :goto_ae
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 184
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\183\\2":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v1

    .end local v1    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 185
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 186
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 187
    .local v21, "$i$f$set-impl\\5\\186":I
    move-object/from16 v23, v2

    .local v23, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 188
    .local v24, "$i$a$-with-Updater$set$1\\6\\187\\5":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_f0

    move-object/from16 v25, v3

    .end local v3    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\1":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v26, v4

    .end local v4    # "$changed\\1":I
    .local v26, "$changed\\1":I
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_ed

    goto :goto_f4

    :cond_ed
    move-object/from16 v4, v23

    goto :goto_104

    .end local v25    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v26    # "$changed\\1":I
    .restart local v3    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$changed\\1":I
    :cond_f0
    move-object/from16 v25, v3

    move/from16 v26, v4

    .line 189
    .end local v3    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$changed\\1":I
    .restart local v25    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v26    # "$changed\\1":I
    :goto_f4
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 190
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 192
    :goto_104
    nop

    .line 187
    .end local v4    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\6\\187\\5":I
    nop

    .line 192
    nop

    .line 193
    .end local v1    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\5\\186":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v6, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 194
    nop

    .line 183
    .end local v2    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\183\\2":I
    nop

    .line 195
    shr-int/lit8 v1, v20, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\7":I
    move-object/from16 v2, v25

    .local v2, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 166
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\7\\195\\1":I
    const v4, 0x7cc0ae6e

    move/from16 v19, v1

    .end local v1    # "$changed\\7":I
    .local v19, "$changed\\7":I
    const-string v1, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v4, v26, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\8":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$DecksScreen_u24lambda_u2423_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v50, v2

    .local v50, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 35
    .local v21, "$i$a$-Column-DecksScreenKt$DecksScreen$6$1\\8\\166\\0":I
    move-object/from16 v23, v1

    .end local v1    # "$this$DecksScreen_u24lambda_u2423_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v23, "$this$DecksScreen_u24lambda_u2423_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, -0xb2b73d4

    move-object/from16 v24, v2

    .end local v2    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v2, "C34@2590L22,34@2567L158:DecksScreen.kt#i35lj1"

    move/from16 v55, v3

    move-object/from16 v3, v50

    .end local v50    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v55, "$i$a$-Layout-ColumnKt$Column$1\\7\\195\\1":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static {v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v27

    invoke-static/range {p1 .. p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_14e

    move/from16 v40, v16

    goto :goto_150

    :cond_14e
    const/16 v40, 0x0

    :goto_150
    invoke-static/range {p2 .. p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    xor-int/lit8 v30, v1, 0x1

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const-string v2, "deck-name"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    const v1, -0x7c3b3315

    const-string v2, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\9":Z
    move-object v2, v3

    .local v2, "$this$cache\\9":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 152
    .local v28, "$i$f$cache\\9\\35":I
    move/from16 v31, v1

    .end local v1    # "invalid\\9":Z
    .local v31, "invalid\\9":Z
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\9":Ljava/lang/Object;
    const/16 v32, 0x0

    .line 153
    .local v32, "$i$a$-let-ComposerKt$cache$1\\10\\152\\9":I
    if-nez v31, :cond_187

    sget-object v33, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v50, v3

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v33 .. v33}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v1, v3, :cond_184

    goto :goto_189

    .line 157
    :cond_184
    move-object/from16 v3, p1

    goto :goto_19a

    .line 153
    .end local v50    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    :cond_187
    move-object/from16 v50, v3

    .line 154
    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\8":Landroidx/compose/runtime/Composer;
    :goto_189
    const/4 v3, 0x0

    .line 35
    .local v3, "$i$a$-cache-DecksScreenKt$DecksScreen$6$1$1\\11\\154\\8":I
    move-object/from16 v33, v1

    .end local v1    # "it\\9":Ljava/lang/Object;
    .local v33, "it\\9":Ljava/lang/Object;
    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda23;

    move/from16 v34, v3

    move-object/from16 v3, p1

    .end local v3    # "$i$a$-cache-DecksScreenKt$DecksScreen$6$1$1\\11\\154\\8":I
    .local v34, "$i$a$-cache-DecksScreenKt$DecksScreen$6$1$1\\11\\154\\8":I
    invoke-direct {v1, v0, v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda23;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 154
    .end local v34    # "$i$a$-cache-DecksScreenKt$DecksScreen$6$1$1\\11\\154\\8":I
    nop

    .line 155
    .local v1, "value\\10":Ljava/lang/Object;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 156
    nop

    .line 152
    .end local v1    # "value\\10":Ljava/lang/Object;
    .end local v32    # "$i$a$-let-ComposerKt$cache$1\\10\\152\\9":I
    .end local v33    # "it\\9":Ljava/lang/Object;
    :goto_19a
    nop

    .line 35
    .end local v2    # "$this$cache\\9":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$f$cache\\9\\35":I
    .end local v31    # "invalid\\9":Z
    move-object/from16 v28, v1

    check-cast v28, Lkotlin/jvm/functions/Function1;

    invoke-static/range {v50 .. v50}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$-2114441585$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v33

    const/16 v53, 0x0

    const v54, 0x7ddfb0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x1

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const v51, 0x180180

    const/high16 v52, 0xc00000

    invoke-static/range {v27 .. v54}, Landroidx/compose/material3/OutlinedTextFieldKt;->OutlinedTextField(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLandroidx/compose/ui/text/input/VisualTransformation;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;ZIILandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/TextFieldColors;Landroidx/compose/runtime/Composer;IIII)V

    move-object/from16 v2, v50

    .end local v50    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v1

    if-eqz v1, :cond_1fc

    const v1, -0x7c3b2037

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "34@2741L20"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v0, 0x30

    move/from16 v3, v16

    move/from16 v16, v4

    const/4 v4, 0x0

    .end local v4    # "$changed\\8":I
    .local v16, "$changed\\8":I
    invoke-static {v1, v3, v2, v0, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_204

    .end local v16    # "$changed\\8":I
    .restart local v4    # "$changed\\8":I
    :cond_1fc
    move/from16 v16, v4

    .end local v4    # "$changed\\8":I
    .restart local v16    # "$changed\\8":I
    const v0, -0xb526a53

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_204
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 166
    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v16    # "$changed\\8":I
    .end local v21    # "$i$a$-Column-DecksScreenKt$DecksScreen$6$1\\8\\166\\0":I
    .end local v23    # "$this$DecksScreen_u24lambda_u2423_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 195
    .end local v19    # "$changed\\7":I
    .end local v24    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-Layout-ColumnKt$Column$1\\7\\195\\1":I
    nop

    .line 196
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 175
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 197
    nop

    .line 169
    .end local v18    # "$i$f$ReusableComposeNode\\3\\173":I
    .end local v20    # "$changed\\3":I
    .end local v22    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 198
    nop

    .line 158
    .end local v5    # "compositeKeyHash\\2":I
    .end local v6    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\2":I
    .end local v13    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v14    # "$i$f$Layout\\2\\165":I
    .end local v15    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 199
    nop

    .end local v7    # "$i$f$Column\\1\\35":I
    .end local v8    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v9    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v10    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v11    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v25    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v26    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_22a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_22a

    .line 35
    :cond_227
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_22a
    :goto_22a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$23$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 4
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 35
    invoke-static {p0, p2}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$24$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 3
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 36
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_a

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    :cond_a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$25(Lkotlinx/coroutines/CoroutineScope;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 22
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p2, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v10, p5

    move/from16 v13, p6

    const-string v0, "C35@3503L195,35@3492L276:DecksScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_91

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)"

    const v3, -0x6fe0ae5d

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 36
    :cond_29
    const v0, 0x5917746

    const-string v1, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    move-object/from16 v6, p1

    invoke-interface {v10, v6}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    move-object/from16 v7, p2

    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    or-int/2addr v0, v1

    .local v0, "invalid\\1":Z
    move-object/from16 v1, p5

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 200
    .local v9, "$i$f$cache\\1\\36":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 201
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\200\\1":I
    if-nez v0, :cond_57

    sget-object v3, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v3}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v11, v3, :cond_56

    goto :goto_57

    .line 205
    :cond_56
    goto :goto_67

    .line 202
    :cond_57
    :goto_57
    const/4 v14, 0x0

    .line 36
    .local v14, "$i$a$-cache-DecksScreenKt$DecksScreen$8$1\\3\\202\\0":I
    new-instance v3, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;

    move-object v4, p0

    move-object/from16 v5, p3

    move-object/from16 v8, p4

    invoke-direct/range {v3 .. v8}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda0;-><init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 202
    .end local v14    # "$i$a$-cache-DecksScreenKt$DecksScreen$8$1\\3\\202\\0":I
    nop

    .line 203
    .local v3, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 204
    move-object v11, v3

    .line 200
    .end local v3    # "value\\2":Ljava/lang/Object;
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\200\\1":I
    :goto_67
    nop

    .line 36
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\1\\36":I
    move-object v0, v11

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static/range {p3 .. p3}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    xor-int/2addr v2, v1

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$128235104$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/high16 v11, 0x30000000

    const/16 v12, 0x1fa

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_94

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_94

    :cond_91
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_94
    :goto_94
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$25$0$0(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 13
    .param p0, "$scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p1, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/MainViewModel;
    .param p3, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$error$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 36
    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    if-nez v0, :cond_1f

    const/4 v0, 0x1

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    new-instance v1, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$8$1$1$1;

    const/4 v6, 0x0

    move-object v5, p1

    move-object v2, p2

    move-object v3, p3

    move-object v4, p4

    invoke-direct/range {v1 .. v6}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$DecksScreen$8$1$1$1;-><init>(Lcom/xunji/flashcards/ui/MainViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    move-object v5, v1

    check-cast v5, Lkotlin/jvm/functions/Function2;

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object v2, p0

    invoke-static/range {v2 .. v7}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    :cond_1f
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$26(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v10, p2

    move/from16 v13, p3

    const-string v0, "C35@3798L15,35@3787L56:DecksScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_7e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)"

    const v3, -0x5673f9db

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 36
    :cond_29
    const v0, 0x76a31294

    const-string v1, "CC(remember):DecksScreen.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    move-object/from16 v1, p2

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 200
    .local v3, "$i$f$cache\\1\\36":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 201
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\200\\1":I
    if-nez v0, :cond_49

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_48

    goto :goto_49

    .line 205
    :cond_48
    goto :goto_54

    .line 202
    :cond_49
    :goto_49
    const/4 v6, 0x0

    .line 36
    .local v6, "$i$a$-cache-DecksScreenKt$DecksScreen$9$1\\3\\202\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda20;

    invoke-direct {v7, p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt$$ExternalSyntheticLambda20;-><init>(Landroidx/compose/runtime/MutableState;)V

    .line 202
    .end local v6    # "$i$a$-cache-DecksScreenKt$DecksScreen$9$1\\3\\202\\0":I
    nop

    .line 203
    .local v7, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 204
    move-object v4, v7

    .line 200
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\200\\1":I
    .end local v7    # "value\\2":Ljava/lang/Object;
    :goto_54
    nop

    .line 36
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\36":I
    move-object v0, v4

    check-cast v0, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$16(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    xor-int/2addr v2, v1

    sget-object v1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$DecksScreenKt;->getLambda$554789602$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const/high16 v11, 0x30000000

    const/16 v12, 0x1fa

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_81

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_81

    :cond_7e
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_81
    :goto_81
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$26$0$0(Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 36
    const/4 v0, 0x0

    invoke-static {p0, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$27(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 55
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C35@3400L73:DecksScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x0

    if-eq v2, v3, :cond_11

    const/4 v2, 0x1

    goto :goto_12

    :cond_11
    move v2, v5

    :goto_12
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1ba

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.DecksScreen.<anonymous> (DecksScreen.kt:35)"

    const v6, 0x4faf14e8

    invoke-static {v6, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 36
    :cond_29
    move-object/from16 v2, p1

    .local v2, "$composer\\1":Landroidx/compose/runtime/Composer;
    move v3, v5

    .local v3, "$changed\\1":I
    const/4 v6, 0x0

    .line 206
    .local v6, "$i$f$Column\\1\\36":I
    const v7, 0x4ff7456f

    const-string v8, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v2, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 207
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    .line 208
    .local v7, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v8}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v8

    .line 209
    .local v8, "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 212
    .local v9, "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v8, v9, v2, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 216
    .local v10, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 213
    nop

    .local v11, "$changed\\2":I
    move-object v12, v7

    .local v12, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 217
    .local v13, "$i$f$Layout\\2\\213":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v2, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 218
    invoke-static {v2, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 219
    .local v14, "compositeKeyHash\\2":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 220
    .local v15, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 222
    .local v4, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v5, v11, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 221
    move-object/from16 v18, v17

    .local v5, "$changed\\3":I
    .local v18, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 223
    .local v17, "$i$f$ReusableComposeNode\\3\\221":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 224
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_94

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 225
    :cond_94
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 226
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_a3

    .line 227
    move-object/from16 v0, v18

    .end local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a8

    .line 229
    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_a3
    move-object/from16 v0, v18

    .end local v18    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 231
    :goto_a8
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 232
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\231\\2":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v20, v0

    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v20, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 233
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 234
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 235
    .local v19, "$i$f$set-impl\\5\\234":I
    move-object/from16 v21, v1

    .local v21, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 236
    .local v22, "$i$a$-with-Updater$set$1\\6\\235\\5":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_ea

    move-object/from16 v23, v2

    .end local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .local v23, "$composer\\1":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v24, v3

    .end local v3    # "$changed\\1":I
    .local v24, "$changed\\1":I
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_e7

    goto :goto_ee

    :cond_e7
    move-object/from16 v3, v21

    goto :goto_fe

    .end local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v24    # "$changed\\1":I
    .restart local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$changed\\1":I
    :cond_ea
    move-object/from16 v23, v2

    move/from16 v24, v3

    .line 237
    .end local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$changed\\1":I
    .restart local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .restart local v24    # "$changed\\1":I
    :goto_ee
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 238
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 240
    :goto_fe
    nop

    .line 235
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\6\\235\\5":I
    nop

    .line 240
    nop

    .line 241
    .end local v0    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\5\\234":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 242
    nop

    .line 231
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\231\\2":I
    nop

    .line 243
    shr-int/lit8 v0, v5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object/from16 v1, v23

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 214
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\7\\243\\1":I
    const v3, 0x7cc0ae6e

    move/from16 v18, v0

    .end local v0    # "$changed\\7":I
    .local v18, "$changed\\7":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v24, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$DecksScreen_u24lambda_u2427_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v47, v1

    .local v47, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 36
    .local v19, "$i$a$-Column-DecksScreenKt$DecksScreen$10$1\\8\\214\\0":I
    move-object/from16 v21, v0

    .end local v0    # "$this$DecksScreen_u24lambda_u2427_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .local v21, "$this$DecksScreen_u24lambda_u2427_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x189b4827

    move-object/from16 v22, v1

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v1, "C35@3409L26:DecksScreen.kt#i35lj1"

    move/from16 v51, v2

    move-object/from16 v2, v47

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v51, "$i$a$-Layout-ColumnKt$Column$1\\7\\243\\1":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/16 v49, 0x0

    const v50, 0x3fffe

    const-string v25, "\u5c06\u5220\u9664\u5168\u90e8\u5361\u7247\u548c\u5b66\u4e60\u8bb0\u5f55\uff0c\u65e0\u6cd5\u64a4\u56de\u3002"

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v48, 0x6

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v25 .. v50}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_18d

    const v0, -0x776d78e

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "35@3451L20"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$13(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNull(Ljava/lang/Object;)V

    const/16 v1, 0x30

    move/from16 v25, v3

    move-object/from16 v16, v4

    const/4 v3, 0x1

    const/4 v4, 0x0

    .end local v3    # "$changed\\8":I
    .end local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v16, "materialized\\2":Landroidx/compose/ui/Modifier;
    .local v25, "$changed\\8":I
    invoke-static {v0, v3, v2, v1, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_197

    .end local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v25    # "$changed\\8":I
    .restart local v3    # "$changed\\8":I
    .restart local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    :cond_18d
    move/from16 v25, v3

    move-object/from16 v16, v4

    .end local v3    # "$changed\\8":I
    .end local v4    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .restart local v25    # "$changed\\8":I
    const v0, 0x1867a2e4

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_197
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 214
    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-Column-DecksScreenKt$DecksScreen$10$1\\8\\214\\0":I
    .end local v21    # "$this$DecksScreen_u24lambda_u2427_u240\\8":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v25    # "$changed\\8":I
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 243
    .end local v18    # "$changed\\7":I
    .end local v22    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Layout-ColumnKt$Column$1\\7\\243\\1":I
    nop

    .line 244
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 223
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 245
    nop

    .line 217
    .end local v5    # "$changed\\3":I
    .end local v17    # "$i$f$ReusableComposeNode\\3\\221":I
    .end local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 246
    nop

    .line 206
    .end local v11    # "$changed\\2":I
    .end local v12    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\2\\213":I
    .end local v14    # "compositeKeyHash\\2":I
    .end local v15    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v16    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static/range {v23 .. v23}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 247
    nop

    .end local v6    # "$i$f$Column\\1\\36":I
    .end local v7    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .end local v8    # "verticalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9    # "horizontalAlignment\\1":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v24    # "$changed\\1":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1bd

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1bd

    .line 36
    :cond_1ba
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1bd
    :goto_1bd
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$28(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen(Lcom/xunji/flashcards/ui/MainUiState;Lcom/xunji/flashcards/ui/MainViewModel;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final DecksScreen$lambda$3$0()Landroidx/compose/runtime/MutableState;
    .registers 3

    .line 17
    const/4 v0, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 17
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 78
    .local v3, "$i$f$getValue\\1\\17":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\17":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 17
    return v0
.end method

.method private static final DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 17
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 79
    .local v4, "$i$f$setValue\\1\\17":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 80
    nop

    .line 17
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\17":I
    return-void
.end method

.method private static final DecksScreen$lambda$6$0()Landroidx/compose/runtime/MutableState;
    .registers 2

    .line 17
    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {v0, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final DecksScreen$lambda$7(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 17
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 78
    .local v3, "$i$f$getValue\\1\\17":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\17":I
    check-cast v0, Ljava/lang/String;

    .line 17
    return-object v0
.end method

.method private static final DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 17
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 79
    .local v4, "$i$f$setValue\\1\\17":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 80
    nop

    .line 17
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\17":I
    return-void
.end method

.method private static final DecksScreen$lambda$9$0()Landroidx/compose/runtime/MutableState;
    .registers 3

    .line 18
    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string v2, ""

    invoke-static {v2, v0, v1, v0}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 2
    .param p0, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 2
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$10(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$name$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$11(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$error$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$14(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V
    .registers 2
    .param p0, "$busy$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$17(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$editing$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.method public static final synthetic access$DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .registers 2
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v0

    return v0
.end method

.method public static final synthetic access$DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .registers 2
    .param p0, "$adding$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    return-void
.end method

.method public static final synthetic access$DecksScreen$lambda$7(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 1
    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$7(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final synthetic access$DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$deleting$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/DecksScreenKt;->DecksScreen$lambda$8(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

.field public final synthetic f$2:Lcom/xunji/core/model/Rating;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$0:Ljava/lang/String;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$2:Lcom/xunji/core/model/Rating;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$0:Ljava/lang/String;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;->f$2:Lcom/xunji/core/model/Rating;

    move-object v3, p1

    check-cast v3, Landroidx/compose/foundation/layout/RowScope;

    move-object v4, p2

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$9G7d1ITQ8dSL-Vigu3qwMauigOA(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

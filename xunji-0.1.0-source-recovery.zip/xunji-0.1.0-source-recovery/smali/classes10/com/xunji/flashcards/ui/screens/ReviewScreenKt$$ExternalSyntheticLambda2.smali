.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$1:Lcom/xunji/core/model/Rating;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function1;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/core/model/Rating;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;->f$0:Lkotlin/jvm/functions/Function1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/core/model/Rating;

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$V-7vvIw7SEuCyKPrcfKfHrKKL40(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

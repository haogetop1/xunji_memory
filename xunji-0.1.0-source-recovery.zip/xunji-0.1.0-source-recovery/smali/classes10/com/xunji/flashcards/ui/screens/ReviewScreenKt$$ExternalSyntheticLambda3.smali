.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/xunji/core/model/CardCandidate;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/core/model/CardCandidate;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda3;->f$0:Lcom/xunji/core/model/CardCandidate;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda3;->f$0:Lcom/xunji/core/model/CardCandidate;

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, p1, p2}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$RZxfSvmLI1HeoLDZsfYjiysveoQ(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

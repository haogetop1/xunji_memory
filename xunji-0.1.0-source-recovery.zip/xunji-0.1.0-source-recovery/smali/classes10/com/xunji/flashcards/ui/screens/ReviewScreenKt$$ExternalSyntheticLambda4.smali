.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:Lkotlin/jvm/functions/Function1;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;


# direct methods
.method public synthetic constructor <init>(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$0:F

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$1:Lkotlin/jvm/functions/Function1;

    iput-boolean p3, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$2:Z

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$3:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0
    iget v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$0:F

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$1:Lkotlin/jvm/functions/Function1;

    iget-boolean v2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$2:Z

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;->f$3:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    move-object v4, p1

    check-cast v4, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;

    move-object v5, p2

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$ymwSp5xhsnzFb_eSbM2m1l3ro1g(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/ReviewUiState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/ReviewUiState;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda6;->f$0:Lcom/xunji/flashcards/ui/ReviewUiState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda6;->f$0:Lcom/xunji/flashcards/ui/ReviewUiState;

    check-cast p1, Landroidx/compose/foundation/layout/ColumnScope;

    check-cast p2, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-static {v0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$aNAhkm2ed3uY2SMRld6oKK0GOCU(Lcom/xunji/flashcards/ui/ReviewUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

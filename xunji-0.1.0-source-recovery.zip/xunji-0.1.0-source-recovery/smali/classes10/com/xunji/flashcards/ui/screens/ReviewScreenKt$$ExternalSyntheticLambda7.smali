.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/xunji/core/model/CardCandidate;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/core/model/CardCandidate;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;->f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/core/model/CardCandidate;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;->f$1:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    check-cast p1, Landroidx/compose/foundation/layout/FlowRowScope;

    check-cast p2, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-static {v0, v1, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$iY0-8b0Hw7dCxfMdoXKt4WfwBwE(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/anki/RenderedCard;

.field public final synthetic f$1:Z

.field public final synthetic f$2:Lkotlin/jvm/functions/Function2;

.field public final synthetic f$3:Lcom/xunji/core/model/CardCandidate;

.field public final synthetic f$4:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V
    .registers 6

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/anki/RenderedCard;

    iput-boolean p2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$1:Z

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$2:Lkotlin/jvm/functions/Function2;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$3:Lcom/xunji/core/model/CardCandidate;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$4:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/anki/RenderedCard;

    iget-boolean v1, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$1:Z

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$2:Lkotlin/jvm/functions/Function2;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$3:Lcom/xunji/core/model/CardCandidate;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;->f$4:Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    move-object v5, p1

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->$r8$lambda$L5XER4E4r8K2ZoQ9_DFYtVvteZE(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

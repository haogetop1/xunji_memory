.class public final Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;
.super Ljava/lang/Object;
.source "ReviewScreen.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nReviewScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ReviewScreen.kt\ncom/xunji/flashcards/ui/screens/ReviewScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 4 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 5 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 6 Composer.kt\nandroidx/compose/runtime/Updater\n+ 7 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 8 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 9 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 10 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 11 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,92:1\n1282#2,6:93\n1282#2,6:342\n1282#2,6:607\n1282#2,6:615\n87#3:99\n84#3,9:100\n87#3:221\n85#3,8:222\n94#3:302\n87#3:304\n85#3,8:305\n94#3:351\n94#3:355\n87#3:401\n85#3,8:402\n94#3:440\n87#3:442\n83#3,10:443\n94#3:484\n87#3:485\n85#3,8:486\n94#3:524\n87#3:527\n83#3,10:528\n94#3:630\n87#3:632\n83#3,10:633\n94#3:673\n80#4,6:109\n87#4,3:124\n90#4,2:133\n80#4,6:147\n87#4,3:162\n90#4,2:171\n94#4:176\n80#4,6:189\n87#4,3:204\n90#4,2:213\n94#4:218\n80#4,6:230\n87#4,3:245\n90#4,2:254\n80#4,6:267\n87#4,3:282\n90#4,2:291\n94#4:296\n94#4:301\n80#4,6:313\n87#4,3:328\n90#4,2:337\n94#4:350\n94#4:354\n80#4,6:369\n87#4,3:384\n90#4,2:393\n94#4:398\n80#4,6:410\n87#4,3:425\n90#4,2:434\n94#4:439\n80#4,6:453\n87#4,3:468\n90#4,2:477\n94#4:483\n80#4,6:494\n87#4,3:509\n90#4,2:518\n94#4:523\n80#4,6:538\n87#4,3:553\n90#4,2:562\n80#4,6:578\n87#4,3:593\n90#4,2:602\n94#4:624\n94#4:629\n80#4,6:643\n87#4,3:658\n90#4,2:667\n94#4:672\n391#5,9:115\n400#5:135\n391#5,9:153\n400#5,3:173\n391#5,9:195\n400#5,3:215\n391#5,9:236\n400#5:256\n391#5,9:273\n400#5,3:293\n401#5,2:299\n391#5,9:319\n400#5:339\n401#5,2:348\n401#5,2:352\n391#5,9:375\n400#5,3:395\n391#5,9:416\n400#5,3:436\n391#5,9:459\n400#5:479\n401#5,2:481\n391#5,9:500\n400#5,3:520\n391#5,9:544\n400#5:564\n391#5,9:584\n400#5:604\n401#5,2:622\n401#5,2:627\n391#5,9:649\n400#5,3:669\n4360#6,6:127\n4360#6,6:165\n4360#6,6:207\n4360#6,6:248\n4360#6,6:285\n4360#6,6:331\n4360#6,6:387\n4360#6,6:428\n4360#6,6:471\n4360#6,6:512\n4360#6,6:556\n4360#6,6:596\n4360#6,6:661\n113#7:136\n113#7:178\n113#7:220\n113#7:257\n113#7:298\n113#7:303\n113#7:340\n113#7:341\n113#7:357\n113#7:400\n113#7:441\n113#7:480\n113#7:525\n113#7:526\n113#7:566\n113#7:606\n113#7:613\n113#7:614\n113#7:631\n99#8:137\n96#8,9:138\n106#8:177\n99#8:358\n95#8,10:359\n106#8:399\n99#8:567\n95#8,10:568\n106#8:625\n70#9:179\n67#9,9:180\n77#9:219\n70#9:258\n68#9,8:259\n77#9:297\n75#10:356\n1869#11:565\n1869#11:605\n1870#11:621\n1870#11:626\n*S KotlinDebug\n*F\n+ 1 ReviewScreen.kt\ncom/xunji/flashcards/ui/screens/ReviewScreenKt\n*L\n21#1:93,6\n64#1:342,6\n84#1:607,6\n85#1:615,6\n23#1:99\n23#1:100,9\n32#1:221\n32#1:222,8\n32#1:302\n42#1:304\n42#1:305,8\n42#1:351\n23#1:355\n48#1:401\n48#1:402,8\n48#1:440\n52#1:442\n52#1:443,10\n52#1:484\n55#1:485\n55#1:486,8\n55#1:524\n76#1:527\n76#1:528,10\n76#1:630\n83#1:632\n83#1:633,10\n83#1:673\n23#1:109,6\n23#1:124,3\n23#1:133,2\n24#1:147,6\n24#1:162,3\n24#1:171,2\n24#1:176\n31#1:189,6\n31#1:204,3\n31#1:213,2\n31#1:218\n32#1:230,6\n32#1:245,3\n32#1:254,2\n33#1:267,6\n33#1:282,3\n33#1:291,2\n33#1:296\n32#1:301\n42#1:313,6\n42#1:328,3\n42#1:337,2\n42#1:350\n23#1:354\n35#1:369,6\n35#1:384,3\n35#1:393,2\n35#1:398\n48#1:410,6\n48#1:425,3\n48#1:434,2\n48#1:439\n52#1:453,6\n52#1:468,3\n52#1:477,2\n52#1:483\n55#1:494,6\n55#1:509,3\n55#1:518,2\n55#1:523\n76#1:538,6\n76#1:553,3\n76#1:562,2\n78#1:578,6\n78#1:593,3\n78#1:602,2\n78#1:624\n76#1:629\n83#1:643,6\n83#1:658,3\n83#1:667,2\n83#1:672\n23#1:115,9\n23#1:135\n24#1:153,9\n24#1:173,3\n31#1:195,9\n31#1:215,3\n32#1:236,9\n32#1:256\n33#1:273,9\n33#1:293,3\n32#1:299,2\n42#1:319,9\n42#1:339\n42#1:348,2\n23#1:352,2\n35#1:375,9\n35#1:395,3\n48#1:416,9\n48#1:436,3\n52#1:459,9\n52#1:479\n52#1:481,2\n55#1:500,9\n55#1:520,3\n76#1:544,9\n76#1:564\n78#1:584,9\n78#1:604\n78#1:622,2\n76#1:627,2\n83#1:649,9\n83#1:669,3\n23#1:127,6\n24#1:165,6\n31#1:207,6\n32#1:248,6\n33#1:285,6\n42#1:331,6\n35#1:387,6\n48#1:428,6\n52#1:471,6\n55#1:512,6\n76#1:556,6\n78#1:596,6\n83#1:661,6\n24#1:136\n31#1:178\n32#1:220\n33#1:257\n37#1:298\n42#1:303\n43#1:340\n47#1:341\n35#1:357\n48#1:400\n52#1:441\n55#1:480\n75#1:525\n76#1:526\n78#1:566\n82#1:606\n84#1:613\n85#1:614\n83#1:631\n24#1:137\n24#1:138,9\n24#1:177\n35#1:358\n35#1:359,10\n35#1:399\n78#1:567\n78#1:568,10\n78#1:625\n31#1:179\n31#1:180,9\n31#1:219\n33#1:258\n33#1:259,8\n33#1:297\n73#1:356\n77#1:565\n79#1:605\n79#1:621\n77#1:626\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000F\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0003\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a\u0091\u0001\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u0012\u0010\u0008\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00010\t2\u000c\u0010\u000b\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\r\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072&\u0008\u0002\u0010\u000e\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0010\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00120\u0011\u0012\u0006\u0012\u0004\u0018\u00010\u00130\u000fH\u0007\u00a2\u0006\u0002\u0010\u0014\u001a1\u0010\u0015\u001a\u00020\u00012\u0006\u0010\u0016\u001a\u00020\u00172\u0006\u0010\u0018\u001a\u00020\u00052\u0012\u0010\u0008\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u00010\tH\u0003\u00a2\u0006\u0002\u0010\u0019\u00a8\u0006\u001a"
    }
    d2 = {
        "ReviewScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/ReviewUiState;",
        "canUndo",
        "",
        "onReveal",
        "Lkotlin/Function0;",
        "onGrade",
        "Lkotlin/Function1;",
        "Lcom/xunji/core/model/Rating;",
        "onUndo",
        "onRefresh",
        "onExit",
        "openMedia",
        "Lkotlin/Function2;",
        "Lcom/xunji/flashcards/anki/CardMedia;",
        "Lkotlin/coroutines/Continuation;",
        "Ljava/io/InputStream;",
        "",
        "(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V",
        "RatingGrid",
        "answer",
        "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;",
        "submitting",
        "(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$28Nx7K7P6b0Ikxg3Et0dKgjFTc8(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid$lambda$0$0$0$0$0$1$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$6bPQottJQ3L3vxM7HAkvTtgrczQ(Lkotlin/jvm/functions/Function1;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$3$2$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9G7d1ITQ8dSL-Vigu3qwMauigOA(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid$lambda$0$0$0$0$0$0(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$L5XER4E4r8K2ZoQ9_DFYtVvteZE(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$3$1(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$RZxfSvmLI1HeoLDZsfYjiysveoQ(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$3$1$0$0$0$0(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$V-7vvIw7SEuCyKPrcfKfHrKKL40(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid$lambda$0$0$0$0$0$2$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Vo5HKxpCf20111D0MQH6ikVwUTY(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid$lambda$1(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$aNAhkm2ed3uY2SMRld6oKK0GOCU(Lcom/xunji/flashcards/ui/ReviewUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$2$1(Lcom/xunji/flashcards/ui/ReviewUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$bO8WPTFWJIbPqjtMP1ZTiDQoAwA(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 12

    invoke-static/range {p0 .. p11}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$2(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$iY0-8b0Hw7dCxfMdoXKt4WfwBwE(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$3$0(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$tcwfrA0_BQvmDPPbGtGeBJM-FH8(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/animation/AnimatedVisibilityScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen$lambda$1$3$1$0$0(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/animation/AnimatedVisibilityScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ymwSp5xhsnzFb_eSbM2m1l3ro1g(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid$lambda$0(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method private static final RatingGrid(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V
    .registers 13
    .param p0, "answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .param p1, "submitting"    # Z
    .param p2, "onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/ReviewUiState$Answer;",
            "Z",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/xunji/core/model/Rating;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    .line 72
    const v0, 0x6dbbbc15

    invoke-interface {p3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    const-string p3, "C(RatingGrid)N(answer,submitting,onGrade)72@5156L7,73@5219L1514,73@5175L1558:ReviewScreen.kt#i35lj1"

    invoke-static {v5, p3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move p3, p4

    .local p3, "$dirty":I
    and-int/lit8 v1, p4, 0x6

    if-nez v1, :cond_24

    and-int/lit8 v1, p4, 0x8

    if-nez v1, :cond_1a

    invoke-interface {v5, p0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v1

    goto :goto_1e

    :cond_1a
    invoke-interface {v5, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    :goto_1e
    if-eqz v1, :cond_22

    const/4 v1, 0x4

    goto :goto_23

    :cond_22
    const/4 v1, 0x2

    :goto_23
    or-int/2addr p3, v1

    :cond_24
    and-int/lit8 v1, p4, 0x30

    if-nez v1, :cond_34

    invoke-interface {v5, p1}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v1

    if-eqz v1, :cond_31

    const/16 v1, 0x20

    goto :goto_33

    :cond_31
    const/16 v1, 0x10

    :goto_33
    or-int/2addr p3, v1

    :cond_34
    and-int/lit16 v1, p4, 0x180

    if-nez v1, :cond_44

    invoke-interface {v5, p2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_41

    const/16 v1, 0x100

    goto :goto_43

    :cond_41
    const/16 v1, 0x80

    :goto_43
    or-int/2addr p3, v1

    :cond_44
    and-int/lit16 v1, p3, 0x93

    const/16 v2, 0x92

    const/4 v3, 0x1

    if-eq v1, v2, :cond_4d

    move v1, v3

    goto :goto_4e

    :cond_4d
    const/4 v1, 0x0

    :goto_4e
    and-int/lit8 v2, p3, 0x1

    invoke-interface {v5, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_ad

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_62

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.RatingGrid (ReviewScreen.kt:71)"

    invoke-static {v0, p3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 73
    :cond_62
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalDensity()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/CompositionLocal;

    .local v0, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v1, 0x0

    .local v1, "$changed\\1":I
    move-object v2, v5

    .local v2, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 356
    .local v4, "$i$f$getCurrent\\1\\73":I
    const v6, 0x789c5f52

    const-string v7, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    invoke-static {v2, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .end local v0    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v1    # "$changed\\1":I
    .end local v2    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$getCurrent\\1\\73":I
    check-cast v6, Landroidx/compose/ui/unit/Density;

    .line 73
    invoke-interface {v6}, Landroidx/compose/ui/unit/Density;->getFontScale()F

    move-result v0

    .line 74
    .local v0, "fontScale":F
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v2, 0x0

    const/4 v4, 0x0

    invoke-static {v1, v2, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    new-instance v2, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v2, v0, p2, p1, p0}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda4;-><init>(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;)V

    const/16 v4, 0x36

    const v6, 0x331bba6b

    invoke-static {v6, v3, v2, v5, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object v4, v2

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/16 v6, 0xc06

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/layout/BoxWithConstraintsKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/Alignment;ZLkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_b0

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "fontScale":F
    goto :goto_b0

    .line 72
    :cond_ad
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 91
    :cond_b0
    :goto_b0
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v0

    if-eqz v0, :cond_be

    new-instance v1, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0, p1, p2, p4}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda5;-><init>(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;I)V

    invoke-interface {v0, v1}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_be
    return-void
.end method

.method private static final RatingGrid$lambda$0(FLkotlin/jvm/functions/Function1;ZLcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/BoxWithConstraintsScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 96
    .param p0, "$fontScale"    # F
    .param p1, "$onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p2, "$submitting"    # Z
    .param p3, "$answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .param p4, "$this$BoxWithConstraints"    # Landroidx/compose/foundation/layout/BoxWithConstraintsScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v0, p1

    move-object/from16 v1, p4

    move-object/from16 v2, p5

    const-string v3, "$this$BoxWithConstraints"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C75@5283L1447:ReviewScreen.kt#i35lj1"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p6

    .local v3, "$dirty":I
    and-int/lit8 v4, p6, 0x6

    const/4 v5, 0x4

    if-nez v4, :cond_21

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_1f

    move v4, v5

    goto :goto_20

    :cond_1f
    const/4 v4, 0x2

    :goto_20
    or-int/2addr v3, v4

    :cond_21
    and-int/lit8 v4, v3, 0x13

    const/16 v7, 0x12

    const/4 v8, 0x0

    if-eq v4, v7, :cond_2a

    const/4 v4, 0x1

    goto :goto_2b

    :cond_2a
    move v4, v8

    :goto_2b
    and-int/lit8 v7, v3, 0x1

    invoke-interface {v2, v4, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_5dc

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_42

    const/4 v4, -0x1

    const-string v7, "com.xunji.flashcards.ui.screens.RatingGrid.<anonymous> (ReviewScreen.kt:74)"

    const v10, 0x331bba6b

    invoke-static {v10, v3, v4, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 75
    :cond_42
    invoke-interface {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScope;->getMaxWidth-D9Ej5fM()F

    move-result v4

    const/16 v7, 0x168

    .local v7, "$this$dp\\1":I
    const/4 v10, 0x0

    .line 525
    .local v10, "$i$f$getDp\\1\\75":I
    int-to-float v11, v7

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 75
    .end local v7    # "$this$dp\\1":I
    .end local v10    # "$i$f$getDp\\1\\75":I
    invoke-static {v4, v7}, Landroidx/compose/ui/unit/Dp;->compareTo-0680j_4(FF)I

    move-result v4

    if-ltz v4, :cond_5b

    const v4, 0x3f99999a    # 1.2f

    cmpl-float v4, p0, v4

    if-lez v4, :cond_5c

    :cond_5b
    const/4 v5, 0x2

    .line 76
    .local v5, "columns":I
    :cond_5c
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0xa

    .local v7, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 526
    .local v10, "$i$f$getDp\\2\\76":I
    int-to-float v11, v7

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 76
    .end local v7    # "$this$dp\\2":I
    .end local v10    # "$i$f$getDp\\2\\76":I
    invoke-virtual {v4, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v4, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v7, 0x30

    .local v7, "$changed\\3":I
    move-object/from16 v10, p5

    .local v10, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 527
    .local v11, "$i$f$Column\\3\\76":I
    const v12, 0x4ff7456f

    const-string v13, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 528
    sget-object v12, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v12, Landroidx/compose/ui/Modifier;

    .line 530
    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 533
    .local v13, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v14, v7, 0x3

    and-int/lit8 v14, v14, 0xe

    shr-int/lit8 v15, v7, 0x3

    and-int/lit8 v15, v15, 0x70

    or-int/2addr v14, v15

    invoke-static {v4, v13, v10, v14}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v14

    .line 537
    .local v14, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v15, v7, 0x3

    and-int/lit8 v15, v15, 0x70

    .line 534
    move-object/from16 v16, v12

    .local v15, "$changed\\4":I
    .local v16, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/16 v17, 0x0

    .line 538
    .local v17, "$i$f$Layout\\4\\534":I
    const v9, -0x451e1427

    const-string v6, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v10, v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 539
    invoke-static {v10, v8}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v18

    invoke-static/range {v18 .. v19}, Ljava/lang/Long;->hashCode(J)I

    move-result v18

    .line 540
    .local v18, "compositeKeyHash\\4":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v8

    .line 541
    .local v8, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v9, v16

    .end local v16    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v9, "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v10, v9}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .line 543
    .local v1, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v2, v15, 0x6

    and-int/lit16 v2, v2, 0x380

    or-int/lit8 v2, v2, 0x6

    .line 542
    nop

    .local v2, "$changed\\5":I
    move-object/from16 v20, v16

    .local v20, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 544
    .local v16, "$i$f$ReusableComposeNode\\5\\542":I
    move/from16 v21, v2

    .end local v2    # "$changed\\5":I
    .local v21, "$changed\\5":I
    const v2, -0x20f7d59c

    move/from16 v22, v3

    .end local v3    # "$dirty":I
    .local v22, "$dirty":I
    const-string v3, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v10, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 545
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v2

    instance-of v2, v2, Landroidx/compose/runtime/Applier;

    if-nez v2, :cond_da

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 546
    :cond_da
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 547
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v2

    if-eqz v2, :cond_e9

    .line 548
    move-object/from16 v2, v20

    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v2, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_ee

    .line 550
    .end local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_e9
    move-object/from16 v2, v20

    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 552
    :goto_ee
    move-object/from16 v20, v2

    .end local v2    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 553
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\552\\4":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v25, v4

    .end local v4    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v25, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v14, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 554
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v8, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 555
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 556
    .local v24, "$i$f$set-impl\\7\\555":I
    move-object/from16 v26, v2

    .local v26, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 557
    .local v27, "$i$a$-with-Updater$set$1\\8\\556\\7":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_132

    move/from16 v28, v7

    .end local v7    # "$changed\\3":I
    .local v28, "$changed\\3":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    move-object/from16 v29, v8

    .end local v8    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v29, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v7

    if-nez v7, :cond_12f

    goto :goto_136

    :cond_12f
    move-object/from16 v8, v26

    goto :goto_146

    .end local v28    # "$changed\\3":I
    .end local v29    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v7    # "$changed\\3":I
    .restart local v8    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_132
    move/from16 v28, v7

    move-object/from16 v29, v8

    .line 558
    .end local v7    # "$changed\\3":I
    .end local v8    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v28    # "$changed\\3":I
    .restart local v29    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_136
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    move-object/from16 v8, v26

    .end local v26    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v8, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 559
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-interface {v2, v7, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 561
    :goto_146
    nop

    .line 556
    .end local v8    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-with-Updater$set$1\\8\\556\\7":I
    nop

    .line 561
    nop

    .line 562
    .end local v4    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\7\\555":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v1, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 563
    nop

    .line 552
    .end local v2    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\552\\4":I
    nop

    .line 564
    shr-int/lit8 v2, v21, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\9":I
    move-object v4, v10

    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 535
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    const v8, 0x7cc0ae6e

    move-object/from16 v23, v1

    .end local v1    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v23, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v1, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v4, v8, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v8, v28, 0x6

    and-int/lit8 v8, v8, 0x70

    or-int/lit8 v8, v8, 0x6

    .local v8, "$changed\\10":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$RatingGrid_u24lambda_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v24, v4

    .local v24, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 77
    .local v26, "$i$a$-Column-ReviewScreenKt$RatingGrid$1$1\\10\\535\\0":I
    move-object/from16 v27, v1

    .end local v1    # "$this$RatingGrid_u24lambda_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v27, "$this$RatingGrid_u24lambda_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v1, 0x7b36513c

    move/from16 v30, v2

    .end local v2    # "$changed\\9":I
    .local v30, "$changed\\9":I
    const-string v2, "C:ReviewScreen.kt#i35lj1"

    move-object/from16 v31, v4

    .end local v24    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v31, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, 0x568e2787

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*77@5396L1325"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Lcom/xunji/core/model/Rating;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1, v5}, Lkotlin/collections/CollectionsKt;->chunked(Ljava/lang/Iterable;I)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach\\11":Ljava/lang/Iterable;
    const/16 v24, 0x0

    .line 565
    .local v24, "$i$f$forEach\\11\\77":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v32

    :goto_19d
    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->hasNext()Z

    move-result v33

    if-eqz v33, :cond_5aa

    invoke-interface/range {v32 .. v32}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v33

    .local v33, "element\\11":Ljava/lang/Object;
    move-object/from16 v34, v33

    check-cast v34, Ljava/util/List;

    .local v34, "row\\12":Ljava/util/List;
    const/16 v35, 0x0

    .line 78
    .local v35, "$i$a$-forEach-ReviewScreenKt$RatingGrid$1$1$1\\12\\565\\10":I
    move-object/from16 v36, v1

    .end local v1    # "$this$forEach\\11":Ljava/lang/Iterable;
    .local v36, "$this$forEach\\11":Ljava/lang/Iterable;
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    move-object/from16 v37, v4

    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v4, 0xa

    .local v4, "$this$dp\\13":I
    const/16 v38, 0x0

    .line 566
    .local v38, "$i$f$getDp\\13\\78":I
    move/from16 v39, v5

    .end local v5    # "columns":I
    .local v39, "columns":I
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 78
    .end local v4    # "$this$dp\\13":I
    .end local v38    # "$i$f$getDp\\13\\78":I
    invoke-virtual {v1, v4}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v1, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v4, 0x30

    .local v4, "$changed\\14":I
    move-object/from16 v5, v37

    .local v5, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 567
    .local v38, "$i$f$Row\\14\\78":I
    move/from16 v40, v4

    .end local v4    # "$changed\\14":I
    .local v40, "$changed\\14":I
    const v4, 0x3255a44b

    move/from16 v41, v7

    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    .local v41, "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    const-string v7, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 568
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .line 570
    .local v4, "modifier\\14":Landroidx/compose/ui/Modifier;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .line 573
    .local v7, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v42, v40, 0x3

    and-int/lit8 v42, v42, 0xe

    shr-int/lit8 v43, v40, 0x3

    and-int/lit8 v43, v43, 0x70

    move-object/from16 v44, v4

    .end local v4    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v44, "modifier\\14":Landroidx/compose/ui/Modifier;
    or-int v4, v42, v43

    invoke-static {v1, v7, v5, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .line 577
    .local v4, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v42, v40, 0x3

    and-int/lit8 v42, v42, 0x70

    .line 574
    move-object/from16 v43, v44

    .local v42, "$changed\\15":I
    .local v43, "modifier\\15":Landroidx/compose/ui/Modifier;
    const/16 v45, 0x0

    .line 578
    .local v45, "$i$f$Layout\\15\\574":I
    move-object/from16 v46, v1

    const v1, -0x451e1427

    .end local v1    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v46, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v5, v1, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 579
    const/4 v1, 0x0

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v47

    invoke-static/range {v47 .. v48}, Ljava/lang/Long;->hashCode(J)I

    move-result v19

    .line 580
    .local v19, "compositeKeyHash\\15":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 581
    .local v1, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v48, v6

    move-object/from16 v6, v43

    move-object/from16 v43, v7

    .end local v7    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .local v6, "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v43, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v5, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 583
    .local v7, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v49, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v49 .. v49}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v49

    move-object/from16 v50, v6

    .end local v6    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v50, "modifier\\15":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v6, v42, 0x6

    and-int/lit16 v6, v6, 0x380

    or-int/lit8 v6, v6, 0x6

    .line 582
    nop

    .local v6, "$changed\\16":I
    move-object/from16 v51, v49

    .local v51, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v49, 0x0

    .line 584
    .local v49, "$i$f$ReusableComposeNode\\16\\582":I
    move/from16 v52, v6

    const v6, -0x20f7d59c

    .end local v6    # "$changed\\16":I
    .local v52, "$changed\\16":I
    invoke-static {v5, v6, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 585
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v6

    instance-of v6, v6, Landroidx/compose/runtime/Applier;

    if-nez v6, :cond_23d

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 586
    :cond_23d
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 587
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v6

    if-eqz v6, :cond_24c

    .line 588
    move-object/from16 v6, v51

    .end local v51    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v6, "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_251

    .line 590
    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v51    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :cond_24c
    move-object/from16 v6, v51

    .end local v51    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 592
    :goto_251
    move-object/from16 v51, v3

    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v53, 0x0

    .line 593
    .local v53, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\592\\15":I
    sget-object v54, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v55, v5

    .end local v5    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v54 .. v54}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v4, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 594
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v3, v1, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 595
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v54, 0x0

    .line 596
    .local v54, "$i$f$set-impl\\18\\595":I
    move-object/from16 v56, v3

    .local v56, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v57, 0x0

    .line 597
    .local v57, "$i$a$-with-Updater$set$1\\19\\596\\18":I
    invoke-interface/range {v56 .. v56}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v58

    if-nez v58, :cond_295

    move-object/from16 v58, v1

    .end local v1    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v58, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v56 .. v56}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v59, v4

    .end local v4    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v59, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_292

    goto :goto_299

    :cond_292
    move-object/from16 v4, v56

    goto :goto_2a9

    .end local v58    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v59    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v1    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_295
    move-object/from16 v58, v1

    move-object/from16 v59, v4

    .line 598
    .end local v1    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v58    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v59    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_299
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v4, v56

    .end local v56    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 599
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v3, v1, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 601
    :goto_2a9
    nop

    .line 596
    .end local v4    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v57    # "$i$a$-with-Updater$set$1\\19\\596\\18":I
    nop

    .line 601
    nop

    .line 602
    .end local v5    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v54    # "$i$f$set-impl\\18\\595":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v3, v7, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 603
    nop

    .line 592
    .end local v3    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\592\\15":I
    nop

    .line 604
    shr-int/lit8 v1, v52, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\20":I
    move-object/from16 v3, v55

    .local v3, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 575
    .local v4, "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    const v5, 0x56ccd6f5

    move/from16 v53, v1

    .end local v1    # "$changed\\20":I
    .local v53, "$changed\\20":I
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v3, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v5, v40, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\21":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v70, v3

    .local v70, "$composer\\21":Landroidx/compose/runtime/Composer;
    move-object/from16 v60, v1

    .end local v1    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    .local v60, "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    const/4 v1, 0x0

    .line 79
    .local v1, "$i$a$-Row-ReviewScreenKt$RatingGrid$1$1$1$1\\21\\575\\12":I
    move/from16 v54, v1

    .end local v1    # "$i$a$-Row-ReviewScreenKt$RatingGrid$1$1$1$1\\21\\575\\12":I
    .local v54, "$i$a$-Row-ReviewScreenKt$RatingGrid$1$1$1$1\\21\\575\\12":I
    const v1, 0x359df040

    move-object/from16 v56, v3

    .end local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v56, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v1, -0x170b6b61    # -9.239992E24f

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "*82@5949L293"

    invoke-static {v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move-object/from16 v1, v34

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach\\22":Ljava/lang/Iterable;
    const/16 v57, 0x0

    .line 605
    .local v57, "$i$f$forEach\\22\\79":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v73

    :goto_2f6
    invoke-interface/range {v73 .. v73}, Ljava/util/Iterator;->hasNext()Z

    move-result v61

    if-eqz v61, :cond_56b

    invoke-interface/range {v73 .. v73}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v74

    move-object/from16 v75, v1

    .end local v1    # "$this$forEach\\22":Ljava/lang/Iterable;
    .local v74, "element\\22":Ljava/lang/Object;
    .local v75, "$this$forEach\\22":Ljava/lang/Iterable;
    move-object/from16 v1, v74

    check-cast v1, Lcom/xunji/core/model/Rating;

    .local v1, "rating\\23":Lcom/xunji/core/model/Rating;
    const/16 v76, 0x0

    .line 80
    .local v76, "$i$a$-forEach-ReviewScreenKt$RatingGrid$1$1$1$1$1\\23\\605\\21":I
    sget-object v61, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v1}, Lcom/xunji/core/model/Rating;->ordinal()I

    move-result v62

    aget v61, v61, v62

    packed-switch v61, :pswitch_data_5e6

    new-instance v2, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v2}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v2

    :pswitch_319
    move-object/from16 v77, v2

    const-string v2, "\u8f7b\u677e"

    move/from16 v78, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .local v78, "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    const-string v4, "rating-easy"

    goto :goto_33c

    .end local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    :pswitch_322
    move-object/from16 v77, v2

    move/from16 v78, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    const-string v2, "\u8bb0\u5f97"

    const-string v4, "rating-good"

    goto :goto_33c

    .end local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    :pswitch_32b
    move-object/from16 v77, v2

    move/from16 v78, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    const-string v2, "\u56f0\u96be"

    const-string v4, "rating-hard"

    goto :goto_33c

    .end local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    :pswitch_334
    move-object/from16 v77, v2

    move/from16 v78, v4

    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    const-string v2, "\u5fd8\u8bb0"

    const-string v4, "rating-again"

    :goto_33c
    invoke-static {v2, v4}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v2

    invoke-virtual {v2}, Lkotlin/Pair;->component1()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Ljava/lang/String;

    .local v4, "label\\23":Ljava/lang/String;
    invoke-virtual {v2}, Lkotlin/Pair;->component2()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 81
    .local v2, "tag\\23":Ljava/lang/String;
    sget-object v61, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual {v1}, Lcom/xunji/core/model/Rating;->ordinal()I

    move-result v62

    aget v61, v61, v62

    packed-switch v61, :pswitch_data_5f2

    move/from16 v79, v5

    move-object/from16 v80, v6

    .end local v5    # "$changed\\21":I
    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v79, "$changed\\21":I
    .local v80, "factory\\16":Lkotlin/jvm/functions/Function0;
    const v5, 0xee2caa5

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "80@5807L11"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v3, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v5

    goto :goto_3aa

    .end local v79    # "$changed\\21":I
    .end local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "$changed\\21":I
    .restart local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :pswitch_373
    move/from16 v79, v5

    .end local v5    # "$changed\\21":I
    .restart local v79    # "$changed\\21":I
    const v5, 0xee2c567

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "80@5765L11"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    move-object/from16 v80, v6

    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v3, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getSecondary-0d7_KjU()J

    move-result-wide v5

    goto :goto_3aa

    .end local v79    # "$changed\\21":I
    .end local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "$changed\\21":I
    .restart local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    :pswitch_38f
    move/from16 v79, v5

    move-object/from16 v80, v6

    .end local v5    # "$changed\\21":I
    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v79    # "$changed\\21":I
    .restart local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    const v5, 0xee2bfc3

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "80@5720L11"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v3, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v5

    :goto_3aa
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v63, v5

    move-wide/from16 v5, v63

    .line 82
    .local v5, "color\\23":J
    sget-object v61, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v61, Landroidx/compose/ui/Modifier;

    const/16 v64, 0x2

    const/16 v65, 0x0

    const/high16 v62, 0x3f800000    # 1.0f

    const/16 v63, 0x0

    move-wide/from16 v81, v5

    .end local v5    # "color\\23":J
    .local v81, "color\\23":J
    invoke-static/range {v60 .. v65}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    move-object/from16 v83, v60

    .end local v60    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    .local v83, "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    const/16 v6, 0x40

    .local v6, "$this$dp\\24":I
    const/16 v60, 0x0

    .line 606
    .local v60, "$i$f$getDp\\24\\82":I
    move-object/from16 v84, v7

    .end local v7    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v84, "materialized\\15":Landroidx/compose/ui/Modifier;
    int-to-float v7, v6

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 82
    .end local v6    # "$this$dp\\24":I
    .end local v60    # "$i$f$getDp\\24\\82":I
    const/4 v7, 0x0

    move/from16 v85, v8

    .end local v8    # "$changed\\10":I
    .local v85, "$changed\\10":I
    const/4 v8, 0x0

    move-object/from16 v86, v9

    const/4 v9, 0x2

    .end local v9    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v86, "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v6, v7, v9, v8}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    invoke-static {v5, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v61

    .line 83
    .local v61, "modifier\\23":Landroidx/compose/ui/Modifier;
    new-instance v5, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;

    move-object/from16 v6, p3

    invoke-direct {v5, v4, v6, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda11;-><init>(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;)V

    const/16 v7, 0x36

    const v8, 0x74210ce7

    const/4 v9, 0x1

    invoke-static {v8, v9, v5, v3, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object/from16 v69, v5

    check-cast v69, Lkotlin/jvm/functions/Function3;

    .line 84
    .local v69, "content\\23":Lkotlin/jvm/functions/Function3;
    sget-object v5, Lcom/xunji/core/model/Rating;->GOOD:Lcom/xunji/core/model/Rating;

    const-string v7, "CC(remember):ReviewScreen.kt#9igjgp"

    if-ne v1, v5, :cond_48a

    const v5, 0xee303cd

    invoke-interface {v3, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "83@6279L17,83@6272L143"

    invoke-static {v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v5, 0xee3042f

    invoke-static {v3, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    move-object v7, v1

    check-cast v7, Ljava/lang/Enum;

    invoke-virtual {v7}, Ljava/lang/Enum;->ordinal()I

    move-result v7

    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v7

    or-int/2addr v5, v7

    .local v5, "invalid\\25":Z
    move-object v7, v3

    .local v7, "$this$cache\\25":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 607
    .local v8, "$i$f$cache\\25\\84":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\25":Ljava/lang/Object;
    const/16 v60, 0x0

    .line 608
    .local v60, "$i$a$-let-ComposerKt$cache$1\\26\\607\\25":I
    if-nez v5, :cond_431

    sget-object v62, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move-object/from16 v87, v2

    .end local v2    # "tag\\23":Ljava/lang/String;
    .local v87, "tag\\23":Ljava/lang/String;
    invoke-virtual/range {v62 .. v62}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v9, v2, :cond_430

    goto :goto_433

    .line 612
    :cond_430
    goto :goto_440

    .line 608
    .end local v87    # "tag\\23":Ljava/lang/String;
    .restart local v2    # "tag\\23":Ljava/lang/String;
    :cond_431
    move-object/from16 v87, v2

    .line 609
    .end local v2    # "tag\\23":Ljava/lang/String;
    .restart local v87    # "tag\\23":Ljava/lang/String;
    :goto_433
    const/4 v2, 0x0

    .line 84
    .local v2, "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$1\\27\\609\\23":I
    move/from16 v62, v2

    .end local v2    # "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$1\\27\\609\\23":I
    .local v62, "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$1\\27\\609\\23":I
    new-instance v2, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v2, v0, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda1;-><init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)V

    .line 609
    .end local v62    # "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$1\\27\\609\\23":I
    nop

    .line 610
    .local v2, "value\\26":Ljava/lang/Object;
    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 611
    move-object v9, v2

    .line 607
    .end local v2    # "value\\26":Ljava/lang/Object;
    .end local v9    # "it\\25":Ljava/lang/Object;
    .end local v60    # "$i$a$-let-ComposerKt$cache$1\\26\\607\\25":I
    :goto_440
    nop

    .line 84
    .end local v5    # "invalid\\25":Z
    .end local v7    # "$this$cache\\25":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\25\\84":I
    move-object/from16 v60, v9

    check-cast v60, Lkotlin/jvm/functions/Function0;

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    xor-int/lit8 v62, p2, 0x1

    const/16 v2, 0x10

    .local v2, "$this$dp\\28":I
    const/4 v5, 0x0

    .line 613
    .local v5, "$i$f$getDp\\28\\84":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 84
    .end local v2    # "$this$dp\\28":I
    .end local v5    # "$i$f$getDp\\28\\84":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    move-object/from16 v63, v2

    check-cast v63, Landroidx/compose/ui/graphics/Shape;

    const/16 v2, 0x8

    .local v2, "$this$dp\\29":I
    const/4 v5, 0x0

    .line 613
    .local v5, "$i$f$getDp\\29\\84":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 84
    .end local v2    # "$this$dp\\29":I
    .end local v5    # "$i$f$getDp\\29\\84":I
    const/16 v5, 0xc

    .local v5, "$this$dp\\30":I
    const/4 v7, 0x0

    .line 613
    .local v7, "$i$f$getDp\\30\\84":I
    int-to-float v8, v5

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 84
    .end local v5    # "$this$dp\\30":I
    .end local v7    # "$i$f$getDp\\30\\84":I
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v67

    const/high16 v71, 0x30c00000

    const/16 v72, 0x170

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v68, 0x0

    move-object/from16 v70, v3

    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v72}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v2, v61

    move-object/from16 v5, v69

    .end local v61    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v69    # "content\\23":Lkotlin/jvm/functions/Function3;
    .end local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v2, "modifier\\23":Landroidx/compose/ui/Modifier;
    .restart local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v5, "content\\23":Lkotlin/jvm/functions/Function3;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v88, v4

    goto/16 :goto_554

    .line 85
    .end local v5    # "content\\23":Lkotlin/jvm/functions/Function3;
    .end local v87    # "tag\\23":Ljava/lang/String;
    .local v2, "tag\\23":Ljava/lang/String;
    .restart local v61    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .restart local v69    # "content\\23":Lkotlin/jvm/functions/Function3;
    :cond_48a
    move-object/from16 v87, v2

    move-object/from16 v2, v61

    move-object/from16 v5, v69

    .end local v61    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v69    # "content\\23":Lkotlin/jvm/functions/Function3;
    .local v2, "modifier\\23":Landroidx/compose/ui/Modifier;
    .restart local v5    # "content\\23":Lkotlin/jvm/functions/Function3;
    .restart local v87    # "tag\\23":Ljava/lang/String;
    const v8, -0x328020d5

    invoke-interface {v3, v8}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v8, "84@6543L40,84@6664L11,84@6442L17,84@6427L281"

    invoke-static {v3, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    xor-int/lit8 v8, p2, 0x1

    const/16 v9, 0x10

    .local v9, "$this$dp\\31":I
    const/16 v60, 0x0

    .line 614
    .local v60, "$i$f$getDp\\31\\85":I
    move-object/from16 v72, v2

    .end local v2    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .local v72, "modifier\\23":Landroidx/compose/ui/Modifier;
    int-to-float v2, v9

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 85
    .end local v9    # "$this$dp\\31":I
    .end local v60    # "$i$f$getDp\\31\\85":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    sget-object v60, Landroidx/compose/material3/ButtonDefaults;->INSTANCE:Landroidx/compose/material3/ButtonDefaults;

    sget v9, Landroidx/compose/material3/ButtonDefaults;->$stable:I

    shl-int/lit8 v70, v9, 0xc

    const/16 v71, 0xd

    const-wide/16 v61, 0x0

    const-wide/16 v65, 0x0

    const-wide/16 v67, 0x0

    move-object/from16 v69, v3

    move-wide/from16 v63, v81

    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v81    # "color\\23":J
    .local v63, "color\\23":J
    .local v69, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v60 .. v71}, Landroidx/compose/material3/ButtonDefaults;->outlinedButtonColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/ButtonColors;

    move-result-object v3

    move-object/from16 v60, v2

    move-object/from16 v9, v69

    .end local v63    # "color\\23":J
    .end local v69    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v81    # "color\\23":J
    const/16 v2, 0x8

    .local v2, "$this$dp\\32":I
    const/16 v61, 0x0

    .line 614
    .local v61, "$i$f$getDp\\32\\85":I
    move-object/from16 v64, v3

    int-to-float v3, v2

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 85
    .end local v2    # "$this$dp\\32":I
    .end local v61    # "$i$f$getDp\\32\\85":I
    const/16 v3, 0xc

    .local v3, "$this$dp\\33":I
    const/16 v61, 0x0

    .line 614
    .local v61, "$i$f$getDp\\33\\85":I
    move-object/from16 v88, v4

    .end local v4    # "label\\23":Ljava/lang/String;
    .local v88, "label\\23":Ljava/lang/String;
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 85
    .end local v3    # "$this$dp\\33":I
    .end local v61    # "$i$f$getDp\\33\\85":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v67

    const/4 v2, 0x1

    .local v2, "$this$dp\\34":I
    const/4 v3, 0x0

    .line 614
    .local v3, "$i$f$getDp\\34\\85":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 85
    .end local v2    # "$this$dp\\34":I
    .end local v3    # "$i$f$getDp\\34\\85":I
    sget-object v3, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v3, v9, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v3

    invoke-virtual {v3}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v3

    invoke-static {v2, v3, v4}, Landroidx/compose/foundation/BorderStrokeKt;->BorderStroke-cXLIe8U(FJ)Landroidx/compose/foundation/BorderStroke;

    move-result-object v66

    const v2, 0xee3188f

    invoke-static {v9, v2, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v2

    move-object v3, v1

    check-cast v3, Ljava/lang/Enum;

    invoke-virtual {v3}, Ljava/lang/Enum;->ordinal()I

    move-result v3

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\35":Z
    move-object v3, v9

    .local v3, "$this$cache\\35":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 615
    .local v4, "$i$f$cache\\35\\85":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\35":Ljava/lang/Object;
    const/16 v61, 0x0

    .line 616
    .local v61, "$i$a$-let-ComposerKt$cache$1\\36\\615\\35":I
    if-nez v2, :cond_523

    sget-object v62, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v63, v2

    .end local v2    # "invalid\\35":Z
    .local v63, "invalid\\35":Z
    invoke-virtual/range {v62 .. v62}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v7, v2, :cond_522

    goto :goto_525

    .line 620
    :cond_522
    goto :goto_532

    .line 616
    .end local v63    # "invalid\\35":Z
    .restart local v2    # "invalid\\35":Z
    :cond_523
    move/from16 v63, v2

    .line 617
    .end local v2    # "invalid\\35":Z
    .restart local v63    # "invalid\\35":Z
    :goto_525
    const/4 v2, 0x0

    .line 85
    .local v2, "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$2\\37\\617\\23":I
    move/from16 v62, v2

    .end local v2    # "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$2\\37\\617\\23":I
    .local v62, "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$2\\37\\617\\23":I
    new-instance v2, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v2, v0, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda2;-><init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)V

    .line 617
    .end local v62    # "$i$a$-cache-ReviewScreenKt$RatingGrid$1$1$1$1$1$2\\37\\617\\23":I
    nop

    .line 618
    .local v2, "value\\36":Ljava/lang/Object;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 619
    move-object v7, v2

    .line 615
    .end local v2    # "value\\36":Ljava/lang/Object;
    .end local v7    # "it\\35":Ljava/lang/Object;
    .end local v61    # "$i$a$-let-ComposerKt$cache$1\\36\\615\\35":I
    :goto_532
    nop

    .line 85
    .end local v3    # "$this$cache\\35":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\35\\85":I
    .end local v63    # "invalid\\35":Z
    check-cast v7, Lkotlin/jvm/functions/Function0;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object/from16 v63, v60

    check-cast v63, Landroidx/compose/ui/graphics/Shape;

    const/high16 v71, 0x30c00000

    move-object/from16 v61, v72

    .end local v72    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .local v61, "modifier\\23":Landroidx/compose/ui/Modifier;
    const/16 v72, 0x120

    const/16 v65, 0x0

    const/16 v68, 0x0

    move-object/from16 v69, v5

    move-object/from16 v60, v7

    move/from16 v62, v8

    move-object/from16 v70, v9

    .end local v5    # "content\\23":Lkotlin/jvm/functions/Function3;
    .end local v9    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v69, "content\\23":Lkotlin/jvm/functions/Function3;
    .restart local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v60 .. v72}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 86
    :goto_554
    nop

    .line 605
    .end local v1    # "rating\\23":Lcom/xunji/core/model/Rating;
    .end local v61    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v69    # "content\\23":Lkotlin/jvm/functions/Function3;
    .end local v76    # "$i$a$-forEach-ReviewScreenKt$RatingGrid$1$1$1$1$1\\23\\605\\21":I
    .end local v81    # "color\\23":J
    .end local v87    # "tag\\23":Ljava/lang/String;
    .end local v88    # "label\\23":Ljava/lang/String;
    move-object/from16 v3, v70

    move-object/from16 v1, v75

    move-object/from16 v2, v77

    move/from16 v4, v78

    move/from16 v5, v79

    move-object/from16 v6, v80

    move-object/from16 v60, v83

    move-object/from16 v7, v84

    move/from16 v8, v85

    move-object/from16 v9, v86

    .end local v74    # "element\\22":Ljava/lang/Object;
    goto/16 :goto_2f6

    .line 621
    .end local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v75    # "$this$forEach\\22":Ljava/lang/Iterable;
    .end local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .end local v79    # "$changed\\21":I
    .end local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v83    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    .end local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v85    # "$changed\\10":I
    .end local v86    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v1, "$this$forEach\\22":Ljava/lang/Iterable;
    .local v3, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v4, "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .local v5, "$changed\\21":I
    .local v6, "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v7, "materialized\\15":Landroidx/compose/ui/Modifier;
    .local v8, "$changed\\10":I
    .local v9, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v60, "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    :cond_56b
    move-object/from16 v75, v1

    move-object/from16 v77, v2

    move-object/from16 v70, v3

    move/from16 v78, v4

    move/from16 v79, v5

    move-object/from16 v80, v6

    move-object/from16 v84, v7

    move/from16 v85, v8

    move-object/from16 v86, v9

    move-object/from16 v83, v60

    move-object/from16 v6, p3

    .end local v1    # "$this$forEach\\22":Ljava/lang/Iterable;
    .end local v3    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .end local v5    # "$changed\\21":I
    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v7    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v8    # "$changed\\10":I
    .end local v9    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v57    # "$i$f$forEach\\22\\79":I
    .end local v60    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    .restart local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    .restart local v79    # "$changed\\21":I
    .restart local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .restart local v83    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    .restart local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .restart local v85    # "$changed\\10":I
    .restart local v86    # "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 79
    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 87
    nop

    .line 575
    .end local v54    # "$i$a$-Row-ReviewScreenKt$RatingGrid$1$1$1$1\\21\\575\\12":I
    .end local v70    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v79    # "$changed\\21":I
    .end local v83    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v56 .. v56}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 604
    .end local v53    # "$changed\\20":I
    .end local v56    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v78    # "$i$a$-Layout-RowKt$Row$1\\20\\604\\14":I
    nop

    .line 622
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 584
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 623
    nop

    .line 578
    .end local v49    # "$i$f$ReusableComposeNode\\16\\582":I
    .end local v52    # "$changed\\16":I
    .end local v80    # "factory\\16":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 624
    nop

    .line 567
    .end local v19    # "compositeKeyHash\\15":I
    .end local v42    # "$changed\\15":I
    .end local v45    # "$i$f$Layout\\15\\574":I
    .end local v50    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v58    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v84    # "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 625
    nop

    .line 88
    .end local v38    # "$i$f$Row\\14\\78":I
    .end local v40    # "$changed\\14":I
    .end local v43    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .end local v44    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v46    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v55    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v59    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    nop

    .line 565
    .end local v34    # "row\\12":Ljava/util/List;
    .end local v35    # "$i$a$-forEach-ReviewScreenKt$RatingGrid$1$1$1\\12\\565\\10":I
    move-object/from16 v1, v36

    move-object/from16 v4, v37

    move/from16 v5, v39

    move/from16 v7, v41

    move-object/from16 v6, v48

    move-object/from16 v3, v51

    .end local v33    # "element\\11":Ljava/lang/Object;
    goto/16 :goto_19d

    .line 626
    .end local v36    # "$this$forEach\\11":Ljava/lang/Iterable;
    .end local v37    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v39    # "columns":I
    .end local v41    # "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    .end local v85    # "$changed\\10":I
    .end local v86    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v1, "$this$forEach\\11":Ljava/lang/Iterable;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v5, "columns":I
    .local v7, "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    .restart local v8    # "$changed\\10":I
    .restart local v9    # "modifier\\4":Landroidx/compose/ui/Modifier;
    :cond_5aa
    move-object/from16 v6, p3

    move-object/from16 v36, v1

    move-object/from16 v37, v4

    move/from16 v39, v5

    move/from16 v41, v7

    move/from16 v85, v8

    move-object/from16 v86, v9

    .end local v1    # "$this$forEach\\11":Ljava/lang/Iterable;
    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v5    # "columns":I
    .end local v7    # "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    .end local v8    # "$changed\\10":I
    .end local v9    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v24    # "$i$f$forEach\\11\\77":I
    .restart local v37    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v39    # "columns":I
    .restart local v41    # "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    .restart local v85    # "$changed\\10":I
    .restart local v86    # "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 77
    invoke-static/range {v37 .. v37}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 89
    nop

    .line 535
    .end local v26    # "$i$a$-Column-ReviewScreenKt$RatingGrid$1$1\\10\\535\\0":I
    .end local v27    # "$this$RatingGrid_u24lambda_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v37    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v85    # "$changed\\10":I
    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 564
    .end local v30    # "$changed\\9":I
    .end local v31    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v41    # "$i$a$-Layout-ColumnKt$Column$1\\9\\564\\3":I
    nop

    .line 627
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 544
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 628
    nop

    .line 538
    .end local v16    # "$i$f$ReusableComposeNode\\5\\542":I
    .end local v20    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v21    # "$changed\\5":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 629
    nop

    .line 527
    .end local v15    # "$changed\\4":I
    .end local v17    # "$i$f$Layout\\4\\534":I
    .end local v18    # "compositeKeyHash\\4":I
    .end local v23    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v29    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v86    # "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 630
    nop

    .end local v10    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$Column\\3\\76":I
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v14    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v25    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "$changed\\3":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_5e3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v39    # "columns":I
    goto :goto_5e3

    .line 74
    .end local v22    # "$dirty":I
    .local v3, "$dirty":I
    :cond_5dc
    move-object/from16 v6, p3

    move/from16 v22, v3

    .end local v3    # "$dirty":I
    .restart local v22    # "$dirty":I
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 90
    :cond_5e3
    :goto_5e3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    :pswitch_data_5e6
    .packed-switch 0x1
        :pswitch_334
        :pswitch_32b
        :pswitch_322
        :pswitch_319
    .end packed-switch

    :pswitch_data_5f2
    .packed-switch 0x1
        :pswitch_38f
        :pswitch_373
    .end packed-switch
.end method

.method private static final RatingGrid$lambda$0$0$0$0$0$0(Ljava/lang/String;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Lcom/xunji/core/model/Rating;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 59
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .param p2, "$rating"    # Lcom/xunji/core/model/Rating;
    .param p3, "<this>"    # Landroidx/compose/foundation/layout/RowScope;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move-object/from16 v0, p4

    move/from16 v1, p5

    const-string v2, "<this>"

    move-object/from16 v3, p3

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C82@5950L290:ReviewScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1ce

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.RatingGrid.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:82)"

    const v6, 0x74210ce7

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 83
    :cond_31
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v2

    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v6, 0x3

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 631
    .local v7, "$i$f$getDp\\1\\83":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 83
    .end local v6    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\83":I
    invoke-virtual {v4, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v4, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x1b0

    .local v2, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v6, "$changed\\2":I
    move-object/from16 v7, p4

    .local v7, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 632
    .local v8, "$i$f$Column\\2\\83":I
    const v9, 0x4ff7456f

    const-string v10, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 633
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    .line 638
    .local v9, "modifier\\2":Landroidx/compose/ui/Modifier;
    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v4, v2, v7, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 642
    .local v10, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 639
    nop

    .local v11, "$changed\\3":I
    move-object v12, v9

    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 643
    .local v13, "$i$f$Layout\\3\\639":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 644
    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v5

    .line 645
    .local v5, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 646
    .local v14, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 648
    .local v15, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v0, v11, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 647
    nop

    .local v0, "$changed\\4":I
    move-object/from16 v17, v16

    .local v17, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 649
    .local v16, "$i$f$ReusableComposeNode\\4\\647":I
    move/from16 v18, v0

    .end local v0    # "$changed\\4":I
    .local v18, "$changed\\4":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 650
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_a9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 651
    :cond_a9
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 652
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b8

    .line 653
    move-object/from16 v0, v17

    .end local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bd

    .line 655
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_b8
    move-object/from16 v0, v17

    .end local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 657
    :goto_bd
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 658
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\657\\3":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v20, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v20, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 659
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 660
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 661
    .local v19, "$i$f$set-impl\\6\\660":I
    move-object/from16 v21, v1

    .local v21, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 662
    .local v22, "$i$a$-with-Updater$set$1\\7\\661\\6":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_fd

    move-object/from16 v23, v2

    .end local v2    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v23, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_fa

    goto :goto_ff

    :cond_fa
    move-object/from16 v3, v21

    goto :goto_10f

    .end local v23    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v2    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_fd
    move-object/from16 v23, v2

    .line 663
    .end local v2    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v23    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_ff
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 664
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 666
    :goto_10f
    nop

    .line 661
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\7\\661\\6":I
    nop

    .line 666
    nop

    .line 667
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\6\\660":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 668
    nop

    .line 657
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\657\\3":I
    nop

    .line 669
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v1, v7

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 640
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    const v3, 0x7cc0ae6e

    move/from16 v17, v0

    .end local v0    # "$changed\\8":I
    .local v17, "$changed\\8":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v6, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$RatingGrid_u24lambda_u240_u240_u240_u240_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v46, v1

    .local v46, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 83
    .local v19, "$i$a$-Column-ReviewScreenKt$RatingGrid$1$1$1$1$1$content$1$1\\9\\640\\0":I
    move-object/from16 v21, v0

    .end local v0    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v21, "$this$RatingGrid_u24lambda_u240_u240_u240_u240_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x43ccfe04

    move-object/from16 v22, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C82@6087L10,82@6056L53,82@6215L10,82@6110L128:ReviewScreen.kt#i35lj1"

    move/from16 v50, v2

    move-object/from16 v2, v46

    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v45

    const/16 v48, 0x0

    const v49, 0x1fffe

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v47, 0x0

    move-object/from16 v24, p0

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v49}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getPreview()Ljava/util/Map;

    move-result-object v0

    move-object/from16 v1, p2

    invoke-static {v0, v1}, Lkotlin/collections/MapsKt;->getValue(Ljava/util/Map;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Lcom/xunji/core/model/CardSchedule;

    invoke-virtual {v0}, Lcom/xunji/core/model/CardSchedule;->getDueAt()J

    move-result-wide v0

    move/from16 v52, v3

    move-object/from16 v51, v4

    .end local v3    # "$changed\\9":I
    .end local v4    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v51, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v52, "$changed\\9":I
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    invoke-static {v0, v1, v3, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->intervalLabel(JJ)Ljava/lang/String;

    move-result-object v24

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v45

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v49}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 640
    .end local v19    # "$i$a$-Column-ReviewScreenKt$RatingGrid$1$1$1$1$1$content$1$1\\9\\640\\0":I
    .end local v21    # "$this$RatingGrid_u24lambda_u240_u240_u240_u240_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v52    # "$changed\\9":I
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 669
    .end local v17    # "$changed\\8":I
    .end local v22    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\8\\669\\2":I
    nop

    .line 670
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 649
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 671
    nop

    .line 643
    .end local v16    # "$i$f$ReusableComposeNode\\4\\647":I
    .end local v18    # "$changed\\4":I
    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 672
    nop

    .line 632
    .end local v5    # "compositeKeyHash\\3":I
    .end local v11    # "$changed\\3":I
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\3\\639":I
    .end local v14    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 673
    nop

    .end local v6    # "$changed\\2":I
    .end local v7    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Column\\2\\83":I
    .end local v9    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v10    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v51    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1d1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1d1

    .line 83
    :cond_1ce
    invoke-interface/range {p4 .. p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1d1
    :goto_1d1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final RatingGrid$lambda$0$0$0$0$0$1$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;
    .registers 3
    .param p0, "$onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$rating"    # Lcom/xunji/core/model/Rating;

    .line 84
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final RatingGrid$lambda$0$0$0$0$0$2$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/core/model/Rating;)Lkotlin/Unit;
    .registers 3
    .param p0, "$onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$rating"    # Lcom/xunji/core/model/Rating;

    .line 85
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final RatingGrid$lambda$1(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final ReviewScreen(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V
    .registers 106
    .param p0, "state"    # Lcom/xunji/flashcards/ui/ReviewUiState;
    .param p1, "canUndo"    # Z
    .param p2, "onReveal"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p4, "onUndo"    # Lkotlin/jvm/functions/Function0;
    .param p5, "onRefresh"    # Lkotlin/jvm/functions/Function0;
    .param p6, "onExit"    # Lkotlin/jvm/functions/Function0;
    .param p7, "openMedia"    # Lkotlin/jvm/functions/Function2;
    .param p8, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p9, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/ReviewUiState;",
            "Z",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Lcom/xunji/core/model/Rating;",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v0, p3

    move-object/from16 v5, p4

    move-object/from16 v4, p5

    move-object/from16 v7, p6

    move/from16 v14, p9

    move/from16 v15, p10

    const-string v6, "state"

    invoke-static {v1, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "onReveal"

    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "onGrade"

    invoke-static {v0, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "onUndo"

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "onRefresh"

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v6, "onExit"

    invoke-static {v7, v6}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    const v6, -0x6cd51d88

    move-object/from16 v8, p8

    invoke-interface {v8, v6}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v8

    .end local p8    # "$composer":Landroidx/compose/runtime/Composer;
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    const-string v9, "C(ReviewScreen)N(state,canUndo,onReveal,onGrade,onUndo,onRefresh,onExit,openMedia)22@959L4058:ReviewScreen.kt#i35lj1"

    invoke-static {v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v9, p9

    .local v9, "$dirty":I
    and-int/lit8 v10, v14, 0x6

    if-nez v10, :cond_57

    and-int/lit8 v10, v14, 0x8

    if-nez v10, :cond_4d

    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v10

    goto :goto_51

    :cond_4d
    invoke-interface {v8, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    :goto_51
    if-eqz v10, :cond_55

    const/4 v10, 0x4

    goto :goto_56

    :cond_55
    const/4 v10, 0x2

    :goto_56
    or-int/2addr v9, v10

    :cond_57
    and-int/lit8 v10, v14, 0x30

    if-nez v10, :cond_67

    invoke-interface {v8, v2}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v10

    if-eqz v10, :cond_64

    const/16 v10, 0x20

    goto :goto_66

    :cond_64
    const/16 v10, 0x10

    :goto_66
    or-int/2addr v9, v10

    :cond_67
    and-int/lit16 v10, v14, 0x180

    if-nez v10, :cond_77

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_74

    const/16 v10, 0x100

    goto :goto_76

    :cond_74
    const/16 v10, 0x80

    :goto_76
    or-int/2addr v9, v10

    :cond_77
    and-int/lit16 v10, v14, 0xc00

    if-nez v10, :cond_87

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_84

    const/16 v10, 0x800

    goto :goto_86

    :cond_84
    const/16 v10, 0x400

    :goto_86
    or-int/2addr v9, v10

    :cond_87
    and-int/lit16 v10, v14, 0x6000

    if-nez v10, :cond_97

    invoke-interface {v8, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_94

    const/16 v10, 0x4000

    goto :goto_96

    :cond_94
    const/16 v10, 0x2000

    :goto_96
    or-int/2addr v9, v10

    :cond_97
    const/high16 v10, 0x30000

    and-int/2addr v10, v14

    if-nez v10, :cond_a8

    invoke-interface {v8, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_a5

    const/high16 v10, 0x20000

    goto :goto_a7

    :cond_a5
    const/high16 v10, 0x10000

    :goto_a7
    or-int/2addr v9, v10

    :cond_a8
    const/high16 v10, 0x180000

    and-int/2addr v10, v14

    if-nez v10, :cond_b9

    invoke-interface {v8, v7}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_b6

    const/high16 v10, 0x100000

    goto :goto_b8

    :cond_b6
    const/high16 v10, 0x80000

    :goto_b8
    or-int/2addr v9, v10

    :cond_b9
    const/high16 v10, 0xc00000

    and-int/2addr v10, v14

    if-nez v10, :cond_d3

    and-int/lit16 v10, v15, 0x80

    if-nez v10, :cond_cd

    move-object/from16 v10, p7

    invoke-interface {v8, v10}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v12

    if-eqz v12, :cond_cf

    const/high16 v12, 0x800000

    goto :goto_d1

    :cond_cd
    move-object/from16 v10, p7

    :cond_cf
    const/high16 v12, 0x400000

    :goto_d1
    or-int/2addr v9, v12

    goto :goto_d5

    :cond_d3
    move-object/from16 v10, p7

    :goto_d5
    const v12, 0x492493

    and-int/2addr v12, v9

    const v13, 0x492492

    if-eq v12, v13, :cond_e0

    const/4 v12, 0x1

    goto :goto_e1

    :cond_e0
    const/4 v12, 0x0

    :goto_e1
    and-int/lit8 v13, v9, 0x1

    invoke-interface {v8, v12, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v12

    if-eqz v12, :cond_d96

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startDefaults()V

    const-string v12, "20@898L6"

    invoke-static {v8, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v12, v14, 0x1

    if-eqz v12, :cond_108

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getDefaultsInvalid()Z

    move-result v12

    if-eqz v12, :cond_fc

    goto :goto_108

    :cond_fc
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    and-int/lit16 v12, v15, 0x80

    if-eqz v12, :cond_143

    const v12, -0x1c00001

    and-int/2addr v9, v12

    goto :goto_143

    :cond_108
    :goto_108
    and-int/lit16 v12, v15, 0x80

    if-eqz v12, :cond_143

    const v12, 0x73fc3c1e

    const-string v11, "CC(remember):ReviewScreen.kt#9igjgp"

    invoke-static {v8, v12, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v11, 0x0

    .local v11, "invalid\\1":Z
    move-object v12, v8

    .local v12, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 93
    .local v18, "$i$f$cache\\1\\21":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\1":Ljava/lang/Object;
    const/16 v20, 0x0

    .line 94
    .local v20, "$i$a$-let-ComposerKt$cache$1\\2\\93\\1":I
    sget-object v21, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v6, v13, :cond_135

    .line 95
    const/4 v13, 0x0

    .line 21
    .local v13, "$i$a$-cache-ReviewScreenKt$ReviewScreen$1\\3\\95\\0":I
    new-instance v2, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$ReviewScreen$1$1;

    const/4 v3, 0x0

    invoke-direct {v2, v3}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$ReviewScreen$1$1;-><init>(Lkotlin/coroutines/Continuation;)V

    check-cast v2, Lkotlin/jvm/functions/Function2;

    .line 95
    .end local v13    # "$i$a$-cache-ReviewScreenKt$ReviewScreen$1\\3\\95\\0":I
    nop

    .line 96
    .local v2, "value\\2":Ljava/lang/Object;
    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 97
    move-object v6, v2

    .end local v2    # "value\\2":Ljava/lang/Object;
    goto :goto_136

    .line 98
    :cond_135
    nop

    .line 93
    .end local v6    # "it\\1":Ljava/lang/Object;
    .end local v20    # "$i$a$-let-ComposerKt$cache$1\\2\\93\\1":I
    :goto_136
    nop

    .line 21
    .end local v11    # "invalid\\1":Z
    .end local v12    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$f$cache\\1\\21":I
    move-object v2, v6

    check-cast v2, Lkotlin/jvm/functions/Function2;

    .end local p7    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v2, "openMedia":Lkotlin/jvm/functions/Function2;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const v3, -0x1c00001

    and-int/2addr v9, v3

    move v3, v9

    goto :goto_145

    .end local v2    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local p7    # "openMedia":Lkotlin/jvm/functions/Function2;
    :cond_143
    :goto_143
    move v3, v9

    move-object v2, v10

    .end local v9    # "$dirty":I
    .end local p7    # "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v2    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v3, "$dirty":I
    :goto_145
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endDefaults()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_157

    const/4 v6, -0x1

    const-string v9, "com.xunji.flashcards.ui.screens.ReviewScreen (ReviewScreen.kt:20)"

    const v10, -0x6cd51d88

    invoke-static {v10, v3, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_157
    instance-of v6, v1, Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;

    .line 23
    .local v6, "submitting":Z
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v9, v10, v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v18

    .local v18, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v9, 0x6

    .local v9, "$changed\\4":I
    move-object v11, v8

    .local v11, "$composer\\4":Landroidx/compose/runtime/Composer;
    move/from16 v20, v9

    .end local v9    # "$changed\\4":I
    .local v20, "$changed\\4":I
    const/16 v21, 0x0

    .line 99
    .local v21, "$i$f$Column\\4\\23":I
    const v9, 0x4ff7456f

    const-string v12, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v11, v9, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 100
    sget-object v13, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v13}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v13

    .line 101
    .local v13, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v16, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v10

    .line 104
    .local v10, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v20, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v23, v20, 0x3

    and-int/lit8 v23, v23, 0x70

    or-int v9, v16, v23

    invoke-static {v13, v10, v11, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 108
    .local v9, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v20, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 105
    move/from16 v23, v16

    .local v23, "$changed\\5":I
    move-object/from16 v25, v18

    .local v25, "modifier\\5":Landroidx/compose/ui/Modifier;
    const/16 v26, 0x0

    .line 109
    .local v26, "$i$f$Layout\\5\\105":I
    move-object/from16 v16, v13

    .end local v13    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v16, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const v13, -0x451e1427

    move-object/from16 v27, v2

    .end local v2    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v27, "openMedia":Lkotlin/jvm/functions/Function2;
    const-string v2, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v11, v13, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 110
    const/4 v13, 0x0

    invoke-static {v11, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v29

    invoke-static/range {v29 .. v30}, Ljava/lang/Long;->hashCode(J)I

    move-result v29

    .line 111
    .local v29, "compositeKeyHash\\5":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 112
    .local v13, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v0, v25

    move/from16 v25, v3

    .end local v3    # "$dirty":I
    .local v0, "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v25, "$dirty":I
    invoke-static {v11, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 114
    .local v3, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v30, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v30 .. v30}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v30

    move-object/from16 v31, v0

    .end local v0    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v31, "modifier\\5":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v23, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v32, v0

    const/4 v0, 0x6

    or-int/lit8 v32, v32, 0x6

    .line 113
    move-object/from16 v33, v30

    .local v32, "$changed\\6":I
    .local v33, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v30, 0x0

    .line 115
    .local v30, "$i$f$ReusableComposeNode\\6\\113":I
    move/from16 v34, v0

    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v11, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 116
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1e1

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 117
    :cond_1e1
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 118
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1f0

    .line 119
    move-object/from16 v0, v33

    .end local v33    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1f5

    .line 121
    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_1f0
    move-object/from16 v0, v33

    .end local v33    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 123
    :goto_1f5
    move-object/from16 v33, v0

    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v33    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static {v11}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 124
    .local v36, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\123\\5":I
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v9, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 125
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v13, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 126
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v37, 0x0

    .line 127
    .local v37, "$i$f$set-impl\\8\\126":I
    move-object/from16 v38, v0

    .local v38, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v39, 0x0

    .line 128
    .local v39, "$i$a$-with-Updater$set$1\\9\\127\\8":I
    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v40

    if-nez v40, :cond_235

    invoke-interface/range {v38 .. v38}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move/from16 v40, v6

    .end local v6    # "submitting":Z
    .local v40, "submitting":Z
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_232

    goto :goto_237

    :cond_232
    move-object/from16 v6, v38

    goto :goto_247

    .end local v40    # "submitting":Z
    .restart local v6    # "submitting":Z
    :cond_235
    move/from16 v40, v6

    .line 129
    .end local v6    # "submitting":Z
    .restart local v40    # "submitting":Z
    :goto_237
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v38

    .end local v38    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 130
    invoke-static/range {v29 .. v29}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v0, v5, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 132
    :goto_247
    nop

    .line 127
    .end local v6    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v39    # "$i$a$-with-Updater$set$1\\9\\127\\8":I
    nop

    .line 132
    nop

    .line 133
    .end local v4    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v37    # "$i$f$set-impl\\8\\126":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 134
    nop

    .line 123
    .end local v0    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\123\\5":I
    nop

    .line 135
    shr-int/lit8 v0, v32, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\10":I
    move-object v4, v11

    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 106
    .local v36, "$i$a$-Layout-ColumnKt$Column$1\\10\\135\\4":I
    const v5, 0x7cc0ae6e

    const-string v6, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v4, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v37, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v38, v20, 0x6

    and-int/lit8 v38, v38, 0x70

    or-int/lit8 v38, v38, 0x6

    .local v38, "$changed\\11":I
    check-cast v37, Landroidx/compose/foundation/layout/ColumnScope;

    .local v37, "$this$ReviewScreen_u24lambda_u241\\11":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v39, v4

    .local v39, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 24
    .local v41, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2\\11\\106\\0":I
    const v5, 0x3bcee221

    move/from16 v43, v0

    .end local v0    # "$changed\\10":I
    .local v43, "$changed\\10":I
    const-string v0, "C23@994L358:ReviewScreen.kt#i35lj1"

    move-object/from16 v44, v13

    move-object/from16 v13, v39

    .end local v39    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v13, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v44, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v13, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    move-object/from16 p7, v3

    move-object/from16 v19, v4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    .end local v3    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local p7, "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v0, v5, v4, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0xa

    .local v3, "$this$dp\\12":I
    const/16 v39, 0x0

    .line 136
    .local v39, "$i$f$getDp\\12\\24":I
    int-to-float v4, v3

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 24
    .end local v3    # "$this$dp\\12":I
    .end local v39    # "$i$f$getDp\\12\\24":I
    const/4 v4, 0x6

    .local v4, "$this$dp\\13":I
    const/16 v39, 0x0

    .line 136
    .local v39, "$i$f$getDp\\13\\24":I
    int-to-float v5, v4

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 24
    .end local v4    # "$this$dp\\13":I
    .end local v39    # "$i$f$getDp\\13\\24":I
    invoke-static {v0, v3, v4}, Landroidx/compose/foundation/layout/PaddingKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\14":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v3

    .local v3, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v39, 0x186

    .local v39, "$changed\\14":I
    move-object v4, v13

    .local v4, "$composer\\14":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 137
    .local v47, "$i$f$Row\\14\\24":I
    const v5, 0x3255a44b

    move-object/from16 v48, v0

    .end local v0    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .local v48, "modifier\\14":Landroidx/compose/ui/Modifier;
    const-string v0, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v4, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 138
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v0}, Landroidx/compose/foundation/layout/Arrangement;->getStart()Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    move-result-object v0

    .line 142
    .local v0, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shr-int/lit8 v5, v39, 0x3

    and-int/lit8 v5, v5, 0xe

    shr-int/lit8 v49, v39, 0x3

    and-int/lit8 v49, v49, 0x70

    or-int v5, v5, v49

    invoke-static {v0, v3, v4, v5}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .line 146
    .local v5, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v49, v39, 0x3

    and-int/lit8 v49, v49, 0x70

    .line 143
    move-object/from16 v50, v48

    .local v49, "$changed\\15":I
    .local v50, "modifier\\15":Landroidx/compose/ui/Modifier;
    const/16 v51, 0x0

    .line 147
    .local v51, "$i$f$Layout\\15\\143":I
    move-object/from16 v52, v0

    const v0, -0x451e1427

    .end local v0    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v52, "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v4, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 148
    const/4 v0, 0x0

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v53

    invoke-static/range {v53 .. v54}, Ljava/lang/Long;->hashCode(J)I

    move-result v53

    .line 149
    .local v53, "compositeKeyHash\\15":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v0

    .line 150
    .local v0, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v54, v13

    move-object/from16 v13, v50

    move-object/from16 v50, v3

    .end local v3    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .local v13, "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v50, "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .local v54, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 152
    .local v3, "materialized\\15":Landroidx/compose/ui/Modifier;
    sget-object v55, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v55 .. v55}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v55

    move-object/from16 v56, v6

    shl-int/lit8 v6, v49, 0x6

    and-int/lit16 v6, v6, 0x380

    or-int/lit8 v6, v6, 0x6

    .line 151
    move/from16 v57, v6

    .local v57, "$changed\\16":I
    move-object/from16 v6, v55

    .local v6, "factory\\16":Lkotlin/jvm/functions/Function0;
    const/16 v55, 0x0

    .line 153
    .local v55, "$i$f$ReusableComposeNode\\16\\151":I
    const v7, -0x20f7d59c

    invoke-static {v4, v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 154
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_319

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 155
    :cond_319
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 156
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_326

    .line 157
    invoke-interface {v4, v6}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_329

    .line 159
    :cond_326
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 161
    :goto_329
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 162
    .local v58, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\161\\15":I
    sget-object v59, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v60, v4

    .end local v4    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .local v60, "$composer\\14":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v59 .. v59}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v7, v5, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 163
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v7, v0, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 164
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\18":Lkotlin/jvm/functions/Function2;
    const/16 v59, 0x0

    .line 165
    .local v59, "$i$f$set-impl\\18\\164":I
    move-object/from16 v61, v7

    .local v61, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    const/16 v62, 0x0

    .line 166
    .local v62, "$i$a$-with-Updater$set$1\\19\\165\\18":I
    invoke-interface/range {v61 .. v61}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v63

    if-nez v63, :cond_36b

    move-object/from16 v63, v0

    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .local v63, "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v61 .. v61}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    move-object/from16 v64, v5

    .end local v5    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v64, "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_368

    goto :goto_36f

    :cond_368
    move-object/from16 v5, v61

    goto :goto_37f

    .end local v63    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v64    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_36b
    move-object/from16 v63, v0

    move-object/from16 v64, v5

    .line 167
    .end local v0    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v63    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v64    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_36f
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v5, v61

    .end local v61    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 168
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v7, v0, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 170
    :goto_37f
    nop

    .line 165
    .end local v5    # "$this$set_impl_u24lambda_u240\\18":Landroidx/compose/runtime/Composer;
    .end local v62    # "$i$a$-with-Updater$set$1\\19\\165\\18":I
    nop

    .line 170
    nop

    .line 171
    .end local v4    # "block\\18":Lkotlin/jvm/functions/Function2;
    .end local v59    # "$i$f$set-impl\\18\\164":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 172
    nop

    .line 161
    .end local v7    # "$this$Layout_u24lambda_u240\\17":Landroidx/compose/runtime/Composer;
    .end local v58    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\17\\161\\15":I
    nop

    .line 173
    shr-int/lit8 v0, v57, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\20":I
    move-object/from16 v4, v60

    .local v4, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 144
    .local v58, "$i$a$-Layout-RowKt$Row$1\\20\\173\\14":I
    const v5, 0x56ccd6f5

    const-string v7, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v4, v5, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v7, v39, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v59, v7, 0x6

    .local v59, "$changed\\21":I
    check-cast v5, Landroidx/compose/foundation/layout/RowScope;

    .local v5, "$this$ReviewScreen_u24lambda_u241_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v65, v5

    move-object v5, v11

    .end local v11    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\4":Landroidx/compose/runtime/Composer;
    .local v65, "$this$ReviewScreen_u24lambda_u241_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    move-object v11, v4

    .local v11, "$composer\\21":Landroidx/compose/runtime/Composer;
    const/16 v61, 0x0

    .line 25
    .local v61, "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$1\\21\\144\\11":I
    const v7, 0x6f9ef432

    move/from16 v62, v0

    .end local v0    # "$changed\\20":I
    .local v62, "$changed\\20":I
    const-string v0, "C24@1093L58,25@1188L10,25@1155L84:ReviewScreen.kt#i35lj1"

    invoke-static {v11, v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object v0, v10

    .end local v10    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .local v0, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    xor-int/lit8 v10, v40, 0x1

    shr-int/lit8 v7, v25, 0xc

    and-int/lit16 v7, v7, 0x380

    or-int/lit16 v7, v7, 0xc36

    move-object/from16 v66, v13

    .end local v13    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v66, "modifier\\15":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    move-object/from16 v67, v6

    .end local v6    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v67, "factory\\16":Lkotlin/jvm/functions/Function0;
    const-string v6, "back"

    move-object/from16 v68, v12

    move v12, v7

    const-string v7, "\u7ed3\u675f\u590d\u4e60"

    move-object/from16 v69, v9

    .end local v9    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v69, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    const-string v9, "review-exit"

    move-object/from16 v28, v0

    move-object/from16 v17, v5

    move-object v5, v8

    move-object/from16 v24, v16

    move-object/from16 v45, v44

    move-object/from16 v0, v54

    move-object/from16 v92, v56

    move-object/from16 v46, v66

    move-object/from16 v54, v67

    move-object/from16 v93, v68

    move-object/from16 v44, v69

    const/16 v22, 0x0

    move-object/from16 v8, p6

    move-object/from16 v56, v3

    const v3, -0x451e1427

    .end local v3    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v16    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v66    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v67    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v69    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v0, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer\\4":Landroidx/compose/runtime/Composer;
    .local v24, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v28, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .local v44, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v45, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v46, "modifier\\15":Landroidx/compose/ui/Modifier;
    .local v54, "factory\\16":Lkotlin/jvm/functions/Function0;
    .local v56, "materialized\\15":Landroidx/compose/ui/Modifier;
    invoke-static/range {v6 .. v13}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 26
    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v11, v7}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v87

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v66, v6

    check-cast v66, Landroidx/compose/ui/Modifier;

    const/16 v69, 0x2

    const/16 v70, 0x0

    const/high16 v67, 0x3f800000    # 1.0f

    const/16 v68, 0x0

    invoke-static/range {v65 .. v70}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v67

    const/16 v90, 0x0

    const v91, 0x1fffc

    const-string v66, "\u4e13\u6ce8\u8fd9\u4e00\u5f20"

    const-wide/16 v68, 0x0

    const-wide/16 v71, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const-wide/16 v80, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    const/16 v85, 0x0

    const/16 v86, 0x0

    const/16 v89, 0x6

    move-object/from16 v88, v11

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v88, "$composer\\21":Landroidx/compose/runtime/Composer;
    invoke-static/range {v66 .. v91}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 27
    .end local v88    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    if-eqz p1, :cond_47e

    const v6, 0x6fa15092

    invoke-interface {v11, v6}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v6, "26@1254L94"

    invoke-static {v11, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    xor-int/lit8 v6, v40, 0x1

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const-string v8, "undo-rating"

    invoke-static {v7, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    sget-object v8, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;

    invoke-virtual {v8}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;->getLambda$1943808554$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v13

    shr-int/lit8 v8, v25, 0xc

    and-int/lit8 v8, v8, 0xe

    const v9, 0x30000030

    or-int/2addr v8, v9

    const/16 v16, 0x1f8

    move-object v9, v5

    move-object v5, v7

    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    move v15, v8

    const/4 v8, 0x0

    move-object v10, v9

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    move-object v12, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    move-object/from16 v88, v11

    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v88    # "$composer\\21":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    move-object/from16 v66, v12

    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .local v66, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    move-object/from16 v94, v66

    move-object/from16 v14, v88

    move-object/from16 v88, v4

    move-object/from16 v4, p4

    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v66    # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$composer\\21":Landroidx/compose/runtime/Composer;
    .local v88, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v94, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v4 .. v16}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    move-object v11, v14

    .end local v14    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .restart local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    goto :goto_488

    .end local v88    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v94    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_47e
    move-object/from16 v88, v4

    move-object/from16 v94, v5

    .end local v4    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v88    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v94    # "$composer":Landroidx/compose/runtime/Composer;
    const v4, 0x6f8e4610

    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_488
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 25
    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 28
    nop

    .line 144
    .end local v11    # "$composer\\21":Landroidx/compose/runtime/Composer;
    .end local v59    # "$changed\\21":I
    .end local v61    # "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$1\\21\\144\\11":I
    .end local v65    # "$this$ReviewScreen_u24lambda_u241_u240\\21":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v88 .. v88}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 173
    .end local v58    # "$i$a$-Layout-RowKt$Row$1\\20\\173\\14":I
    .end local v62    # "$changed\\20":I
    .end local v88    # "$composer\\20":Landroidx/compose/runtime/Composer;
    nop

    .line 174
    invoke-interface/range {v60 .. v60}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 153
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 175
    nop

    .line 147
    .end local v54    # "factory\\16":Lkotlin/jvm/functions/Function0;
    .end local v55    # "$i$f$ReusableComposeNode\\16\\151":I
    .end local v57    # "$changed\\16":I
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 176
    nop

    .line 137
    .end local v46    # "modifier\\15":Landroidx/compose/ui/Modifier;
    .end local v49    # "$changed\\15":I
    .end local v51    # "$i$f$Layout\\15\\143":I
    .end local v53    # "compositeKeyHash\\15":I
    .end local v56    # "materialized\\15":Landroidx/compose/ui/Modifier;
    .end local v63    # "localMap\\15":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v60 .. v60}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 177
    nop

    .line 29
    .end local v39    # "$changed\\14":I
    .end local v47    # "$i$f$Row\\14\\24":I
    .end local v48    # "modifier\\14":Landroidx/compose/ui/Modifier;
    .end local v50    # "verticalAlignment\\14":Landroidx/compose/ui/Alignment$Vertical;
    .end local v52    # "horizontalArrangement\\14":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v60    # "$composer\\14":Landroidx/compose/runtime/Composer;
    .end local v64    # "measurePolicy\\14":Landroidx/compose/ui/layout/MeasurePolicy;
    nop

    .line 30
    sget-object v4, Lcom/xunji/flashcards/ui/ReviewUiState$Loading;->INSTANCE:Lcom/xunji/flashcards/ui/ReviewUiState$Loading;

    move-object/from16 v12, p0

    invoke-static {v12, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_4cd

    const v1, -0x40227b6c

    invoke-interface {v0, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "29@1395L6"

    invoke-static {v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v13, 0x0

    invoke-static {v0, v13}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v1, p3

    move-object/from16 v54, v0

    move/from16 v66, v25

    move-object/from16 v13, v27

    move/from16 v12, v40

    move-object/from16 v3, v94

    goto/16 :goto_d74

    .line 31
    :cond_4cd
    instance-of v4, v12, Lcom/xunji/flashcards/ui/ReviewUiState$Failure;

    if-eqz v4, :cond_629

    const v4, -0x4022769c

    invoke-interface {v0, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "30@1431L86"

    invoke-static {v0, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/16 v5, 0x16

    .local v5, "$this$dp\\22":I
    const/4 v6, 0x0

    .line 178
    .local v6, "$i$f$getDp\\22\\31":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 31
    .end local v5    # "$this$dp\\22":I
    .end local v6    # "$i$f$getDp\\22\\31":I
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .local v11, "modifier\\23":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x6

    .local v13, "$changed\\23":I
    move-object v14, v0

    .local v14, "$composer\\23":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 179
    .local v15, "$i$f$Box\\23\\31":I
    const v4, 0x3e277f0a

    const-string v5, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v14, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 180
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getTopStart()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .line 181
    .local v4, "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    const/4 v5, 0x0

    .line 184
    .local v5, "propagateMinConstraints\\23":Z
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 188
    .local v6, "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v7, v13, 0x3

    and-int/lit8 v7, v7, 0x70

    .line 185
    move-object v8, v11

    .local v8, "modifier\\24":Landroidx/compose/ui/Modifier;
    move/from16 v16, v7

    .local v16, "$changed\\24":I
    const/16 v22, 0x0

    .line 189
    .local v22, "$i$f$Layout\\24\\185":I
    invoke-static {v14, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 190
    const/4 v2, 0x0

    invoke-static {v14, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v2

    invoke-static {v2, v3}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 191
    .local v2, "compositeKeyHash\\24":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 192
    .local v3, "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v14, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 194
    .local v7, "materialized\\24":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v9

    shl-int/lit8 v10, v16, 0x6

    and-int/lit16 v10, v10, 0x380

    or-int/lit8 v10, v10, 0x6

    .line 193
    move/from16 v39, v10

    .local v9, "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v39, "$changed\\25":I
    const/16 v42, 0x0

    .line 195
    .local v42, "$i$f$ReusableComposeNode\\25\\193":I
    const v10, -0x20f7d59c

    invoke-static {v14, v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 196
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_540

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 197
    :cond_540
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 198
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_54d

    .line 199
    invoke-interface {v14, v9}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_550

    .line 201
    :cond_54d
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 203
    :goto_550
    invoke-static {v14}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 204
    .local v10, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\203\\24":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 p8, v2

    .end local v2    # "compositeKeyHash\\24":I
    .local p8, "compositeKeyHash\\24":I
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v6, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 205
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v3, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 206
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\27":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 207
    .local v35, "$i$f$set-impl\\27\\206":I
    move-object/from16 v46, v1

    .local v46, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    const/16 v47, 0x0

    .line 208
    .local v47, "$i$a$-with-Updater$set$1\\28\\207\\27":I
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v48

    if-nez v48, :cond_591

    move-object/from16 v48, v3

    .end local v3    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .local v48, "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v49, v4

    .end local v4    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    .local v49, "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_58e

    goto :goto_595

    :cond_58e
    move-object/from16 v4, v46

    goto :goto_5a5

    .end local v48    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v49    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    .restart local v3    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v4    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    :cond_591
    move-object/from16 v48, v3

    move-object/from16 v49, v4

    .line 209
    .end local v3    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v4    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    .restart local v48    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v49    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    :goto_595
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v46

    .end local v46    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 210
    invoke-static/range {p8 .. p8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 212
    :goto_5a5
    nop

    .line 207
    .end local v4    # "$this$set_impl_u24lambda_u240\\27":Landroidx/compose/runtime/Composer;
    .end local v47    # "$i$a$-with-Updater$set$1\\28\\207\\27":I
    nop

    .line 212
    nop

    .line 213
    .end local v2    # "block\\27":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\27\\206":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v7, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 214
    nop

    .line 203
    .end local v1    # "$this$Layout_u24lambda_u240\\26":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\26\\203\\24":I
    nop

    .line 215
    shr-int/lit8 v1, v39, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\29":I
    move-object v2, v14

    .local v2, "$composer\\29":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 186
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\29\\215\\23":I
    const v4, 0x6d423196

    const-string v10, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v2, v4, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v10, v13, 0x6

    and-int/lit8 v10, v10, 0x70

    or-int/lit8 v34, v10, 0x6

    .local v34, "$changed\\30":I
    move-object/from16 v35, v4

    check-cast v35, Landroidx/compose/foundation/layout/BoxScope;

    move-object v4, v8

    .end local v8    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v4, "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v35, "$this$ReviewScreen_u24lambda_u241_u241\\30":Landroidx/compose/foundation/layout/BoxScope;
    move-object v8, v2

    .local v8, "$composer\\30":Landroidx/compose/runtime/Composer;
    const/16 v46, 0x0

    .line 31
    .local v46, "$i$a$-Box-ReviewScreenKt$ReviewScreen$2$2\\30\\186\\11":I
    const v10, -0x55af4607

    move/from16 v47, v1

    .end local v1    # "$changed\\29":I
    .local v47, "$changed\\29":I
    const-string v1, "C30@1462L53:ReviewScreen.kt#i35lj1"

    invoke-static {v8, v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object v1, v12

    check-cast v1, Lcom/xunji/flashcards/ui/ReviewUiState$Failure;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/ReviewUiState$Failure;->getMessage()Ljava/lang/String;

    move-result-object v1

    shr-int/lit8 v10, v25, 0x6

    and-int/lit16 v10, v10, 0x1c00

    or-int/lit16 v10, v10, 0x186

    move-object/from16 v50, v9

    move v9, v10

    .end local v9    # "factory\\25":Lkotlin/jvm/functions/Function0;
    .local v50, "factory\\25":Lkotlin/jvm/functions/Function0;
    const/4 v10, 0x0

    move-object/from16 v51, v4

    .end local v4    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .local v51, "modifier\\24":Landroidx/compose/ui/Modifier;
    const-string v4, "\u6682\u65f6\u9047\u5230\u4e00\u70b9\u95ee\u9898"

    move-object/from16 v52, v6

    .end local v6    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v52, "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    const-string v6, "\u91cd\u65b0\u8bfb\u53d6"

    move/from16 v53, v5

    move-object v5, v1

    move/from16 v1, v53

    move-object/from16 v53, v50

    move-object/from16 v50, v7

    move-object/from16 v7, p5

    .end local v5    # "propagateMinConstraints\\23":Z
    .end local v7    # "materialized\\24":Landroidx/compose/ui/Modifier;
    .local v1, "propagateMinConstraints\\23":Z
    .local v50, "materialized\\24":Landroidx/compose/ui/Modifier;
    .local v53, "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v4 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 186
    .end local v8    # "$composer\\30":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\30":I
    .end local v35    # "$this$ReviewScreen_u24lambda_u241_u241\\30":Landroidx/compose/foundation/layout/BoxScope;
    .end local v46    # "$i$a$-Box-ReviewScreenKt$ReviewScreen$2$2\\30\\186\\11":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 215
    .end local v2    # "$composer\\29":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$a$-Layout-BoxKt$Box$1\\29\\215\\23":I
    .end local v47    # "$changed\\29":I
    nop

    .line 216
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 195
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 217
    nop

    .line 189
    .end local v39    # "$changed\\25":I
    .end local v42    # "$i$f$ReusableComposeNode\\25\\193":I
    .end local v53    # "factory\\25":Lkotlin/jvm/functions/Function0;
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 218
    nop

    .line 179
    .end local v16    # "$changed\\24":I
    .end local v22    # "$i$f$Layout\\24\\185":I
    .end local v48    # "localMap\\24":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v50    # "materialized\\24":Landroidx/compose/ui/Modifier;
    .end local v51    # "modifier\\24":Landroidx/compose/ui/Modifier;
    .end local p8    # "compositeKeyHash\\24":I
    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 219
    nop

    .line 31
    .end local v1    # "propagateMinConstraints\\23":Z
    .end local v11    # "modifier\\23":Landroidx/compose/ui/Modifier;
    .end local v13    # "$changed\\23":I
    .end local v14    # "$composer\\23":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$f$Box\\23\\31":I
    .end local v49    # "contentAlignment\\23":Landroidx/compose/ui/Alignment;
    .end local v52    # "measurePolicy\\23":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v1, p3

    move-object/from16 v54, v0

    move/from16 v66, v25

    move-object/from16 v13, v27

    move/from16 v12, v40

    move-object/from16 v3, v94

    goto/16 :goto_d74

    .line 32
    :cond_629
    instance-of v4, v12, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    if-eqz v4, :cond_9d0

    const v4, -0x402264aa

    invoke-interface {v0, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "31@1593L21,31@1548L936"

    invoke-static {v0, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v13, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x1

    invoke-static {v4, v13, v15, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v46

    const/4 v4, 0x0

    invoke-static {v4, v0, v4, v15}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v47

    const/16 v51, 0xe

    const/16 v52, 0x0

    const/16 v48, 0x0

    const/16 v49, 0x0

    const/16 v50, 0x0

    invoke-static/range {v46 .. v52}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v6, 0x16

    .local v6, "$this$dp\\31":I
    const/4 v7, 0x0

    .line 220
    .local v7, "$i$f$getDp\\31\\32":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 32
    .end local v6    # "$this$dp\\31":I
    .end local v7    # "$i$f$getDp\\31\\32":I
    invoke-static {v4, v6}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x18

    .local v7, "$this$dp\\32":I
    const/4 v8, 0x0

    .line 220
    .local v8, "$i$f$getDp\\32\\32":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 32
    .end local v7    # "$this$dp\\32":I
    .end local v8    # "$i$f$getDp\\32\\32":I
    invoke-virtual {v6, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    check-cast v6, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v6, "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v22, 0x30

    .local v22, "$changed\\33":I
    move-object v7, v0

    .local v7, "$composer\\33":Landroidx/compose/runtime/Composer;
    move-object/from16 v39, v4

    .local v39, "modifier\\33":Landroidx/compose/ui/Modifier;
    const/16 v42, 0x0

    .line 221
    .local v42, "$i$f$Column\\33\\32":I
    move-object/from16 v4, v93

    const v8, 0x4ff7456f

    invoke-static {v7, v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 222
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 225
    .local v4, "horizontalAlignment\\33":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v8, v22, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v9, v22, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v8, v9

    invoke-static {v6, v4, v7, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .line 229
    .local v8, "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v22, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 226
    move-object/from16 v10, v39

    .local v10, "modifier\\34":Landroidx/compose/ui/Modifier;
    move/from16 v46, v9

    .local v46, "$changed\\34":I
    const/16 v47, 0x0

    .line 230
    .local v47, "$i$f$Layout\\34\\226":I
    invoke-static {v7, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 231
    const/4 v9, 0x0

    invoke-static {v7, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v48

    invoke-static/range {v48 .. v49}, Ljava/lang/Long;->hashCode(J)I

    move-result v48

    .line 232
    .local v48, "compositeKeyHash\\34":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 233
    .local v9, "localMap\\34":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 235
    .local v11, "materialized\\34":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v5, v46, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 234
    move/from16 v50, v5

    .local v50, "$changed\\35":I
    move-object/from16 v5, v16

    .local v5, "factory\\35":Lkotlin/jvm/functions/Function0;
    const/16 v51, 0x0

    .line 236
    .local v51, "$i$f$ReusableComposeNode\\35\\234":I
    const v3, -0x20f7d59c

    invoke-static {v7, v3, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 237
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_6d5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 238
    :cond_6d5
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 239
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_6e2

    .line 240
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_6e5

    .line 242
    :cond_6e2
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 244
    :goto_6e5
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .local v3, "$this$Layout_u24lambda_u240\\36":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 245
    .local v52, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\36\\244\\34":I
    sget-object v53, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v53 .. v53}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v3, v8, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 246
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v3, v9, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 247
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    .local v13, "block\\37":Lkotlin/jvm/functions/Function2;
    const/16 v53, 0x0

    .line 248
    .local v53, "$i$f$set-impl\\37\\247":I
    move-object/from16 v54, v3

    .local v54, "$this$set_impl_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 249
    .local v55, "$i$a$-with-Updater$set$1\\38\\248\\37":I
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v56

    if-nez v56, :cond_721

    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v15

    invoke-static {v14, v15}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v14

    if-nez v14, :cond_71e

    goto :goto_721

    :cond_71e
    move-object/from16 v15, v54

    goto :goto_731

    .line 250
    :cond_721
    :goto_721
    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    move-object/from16 v15, v54

    .end local v54    # "$this$set_impl_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    .local v15, "$this$set_impl_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    invoke-interface {v15, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    invoke-static/range {v48 .. v48}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v14

    invoke-interface {v3, v14, v13}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 253
    :goto_731
    nop

    .line 248
    .end local v15    # "$this$set_impl_u24lambda_u240\\37":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-with-Updater$set$1\\38\\248\\37":I
    nop

    .line 253
    nop

    .line 254
    .end local v13    # "block\\37":Lkotlin/jvm/functions/Function2;
    .end local v53    # "$i$f$set-impl\\37\\247":I
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v13

    invoke-static {v3, v11, v13}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 255
    nop

    .line 244
    .end local v3    # "$this$Layout_u24lambda_u240\\36":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\36\\244\\34":I
    nop

    .line 256
    shr-int/lit8 v3, v50, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\39":I
    move-object v13, v7

    .local v13, "$composer\\39":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 227
    .local v52, "$i$a$-Layout-ColumnKt$Column$1\\39\\256\\33":I
    move-object/from16 v14, v92

    const v15, 0x7cc0ae6e

    invoke-static {v13, v15, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v14, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v15, v22, 0x6

    and-int/lit8 v15, v15, 0x70

    or-int/lit8 v53, v15, 0x6

    .local v53, "$changed\\40":I
    move-object/from16 v54, v14

    check-cast v54, Landroidx/compose/foundation/layout/ColumnScope;

    .local v54, "$this$ReviewScreen_u24lambda_u241_u242\\40":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v14, v13

    .local v14, "$composer\\40":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 33
    .local v55, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$3\\40\\227\\11":I
    const v15, -0x569a63da

    move/from16 v56, v3

    .end local v3    # "$changed\\39":I
    .local v56, "$changed\\39":I
    const-string v3, "C32@1686L30,32@1717L93,33@1815L149,34@2027L257,34@1969L315,35@2289L36,36@2330L28,36@2359L120:ReviewScreen.kt#i35lj1"

    invoke-static {v14, v15, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/16 v15, 0x10

    .local v15, "$this$dp\\41":I
    const/16 v57, 0x0

    .line 257
    .local v57, "$i$f$getDp\\41\\33":I
    move-object/from16 v58, v4

    .end local v4    # "horizontalAlignment\\33":Landroidx/compose/ui/Alignment$Horizontal;
    .local v58, "horizontalAlignment\\33":Landroidx/compose/ui/Alignment$Horizontal;
    int-to-float v4, v15

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 33
    .end local v15    # "$this$dp\\41":I
    .end local v57    # "$i$f$getDp\\41\\33":I
    invoke-static {v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v4, v34

    invoke-static {v3, v14, v4}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    move-object/from16 v57, v5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v15, 0x0

    .end local v5    # "factory\\35":Lkotlin/jvm/functions/Function0;
    .local v57, "factory\\35":Lkotlin/jvm/functions/Function0;
    invoke-static {v3, v4, v5, v15}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .local v3, "modifier\\42":Landroidx/compose/ui/Modifier;
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .local v4, "contentAlignment\\42":Landroidx/compose/ui/Alignment;
    const/16 v5, 0x36

    .local v5, "$changed\\42":I
    move-object v15, v14

    .local v15, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 258
    .local v59, "$i$f$Box\\42\\33":I
    move-object/from16 v60, v3

    .end local v3    # "modifier\\42":Landroidx/compose/ui/Modifier;
    .local v60, "modifier\\42":Landroidx/compose/ui/Modifier;
    const v3, 0x3e277f0a

    move/from16 v61, v5

    .end local v5    # "$changed\\42":I
    .local v61, "$changed\\42":I
    const-string v5, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v15, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 259
    const/4 v3, 0x0

    .line 262
    .local v3, "propagateMinConstraints\\42":Z
    invoke-static {v4, v3}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v5

    .line 266
    .local v5, "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v62, v61, 0x3

    and-int/lit8 v62, v62, 0x70

    .line 263
    move-object/from16 v63, v60

    .local v62, "$changed\\43":I
    .local v63, "modifier\\43":Landroidx/compose/ui/Modifier;
    const/16 v64, 0x0

    .line 267
    .local v64, "$i$f$Layout\\43\\263":I
    move/from16 v65, v3

    const v3, -0x451e1427

    .end local v3    # "propagateMinConstraints\\42":Z
    .local v65, "propagateMinConstraints\\42":Z
    invoke-static {v15, v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 268
    const/4 v2, 0x0

    invoke-static {v15, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v66

    invoke-static/range {v66 .. v67}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 269
    .local v2, "compositeKeyHash\\43":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 270
    .local v3, "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v16, v2

    move-object/from16 v2, v63

    move-object/from16 v63, v4

    .end local v4    # "contentAlignment\\42":Landroidx/compose/ui/Alignment;
    .local v2, "modifier\\43":Landroidx/compose/ui/Modifier;
    .local v16, "compositeKeyHash\\43":I
    .local v63, "contentAlignment\\42":Landroidx/compose/ui/Alignment;
    invoke-static {v15, v2}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 272
    .local v4, "materialized\\43":Landroidx/compose/ui/Modifier;
    sget-object v66, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v66 .. v66}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v66

    move-object/from16 v67, v2

    .end local v2    # "modifier\\43":Landroidx/compose/ui/Modifier;
    .local v67, "modifier\\43":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v2, v62, 0x6

    and-int/lit16 v2, v2, 0x380

    const/16 v34, 0x6

    or-int/lit8 v2, v2, 0x6

    .line 271
    move-object/from16 v68, v66

    .local v2, "$changed\\44":I
    .local v68, "factory\\44":Lkotlin/jvm/functions/Function0;
    const/16 v66, 0x0

    .line 273
    .local v66, "$i$f$ReusableComposeNode\\44\\271":I
    move/from16 v69, v2

    const v2, -0x20f7d59c

    .end local v2    # "$changed\\44":I
    .local v69, "$changed\\44":I
    invoke-static {v15, v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 274
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_7f6

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 275
    :cond_7f6
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 276
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_805

    .line 277
    move-object/from16 v1, v68

    .end local v68    # "factory\\44":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\44":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_80a

    .line 279
    .end local v1    # "factory\\44":Lkotlin/jvm/functions/Function0;
    .restart local v68    # "factory\\44":Lkotlin/jvm/functions/Function0;
    :cond_805
    move-object/from16 v1, v68

    .end local v68    # "factory\\44":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\44":Lkotlin/jvm/functions/Function0;
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 281
    :goto_80a
    invoke-static {v15}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\45":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 282
    .local v35, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\45\\281\\43":I
    sget-object v68, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v70, v1

    .end local v1    # "factory\\44":Lkotlin/jvm/functions/Function0;
    .local v70, "factory\\44":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v68 .. v68}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 283
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v3, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 284
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\46":Lkotlin/jvm/functions/Function2;
    const/16 v68, 0x0

    .line 285
    .local v68, "$i$f$set-impl\\46\\284":I
    move-object/from16 v71, v2

    .local v71, "$this$set_impl_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    const/16 v72, 0x0

    .line 286
    .local v72, "$i$a$-with-Updater$set$1\\47\\285\\46":I
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v73

    if-nez v73, :cond_84c

    move-object/from16 v73, v3

    .end local v3    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .local v73, "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v74, v5

    .end local v5    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v74, "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_849

    goto :goto_850

    :cond_849
    move-object/from16 v5, v71

    goto :goto_860

    .end local v73    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v74    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v3    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_84c
    move-object/from16 v73, v3

    move-object/from16 v74, v5

    .line 287
    .end local v3    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v73    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v74    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_850
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v5, v71

    .end local v71    # "$this$set_impl_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 288
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 290
    :goto_860
    nop

    .line 285
    .end local v5    # "$this$set_impl_u24lambda_u240\\46":Landroidx/compose/runtime/Composer;
    .end local v72    # "$i$a$-with-Updater$set$1\\47\\285\\46":I
    nop

    .line 290
    nop

    .line 291
    .end local v1    # "block\\46":Lkotlin/jvm/functions/Function2;
    .end local v68    # "$i$f$set-impl\\46\\284":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 292
    nop

    .line 281
    .end local v2    # "$this$Layout_u24lambda_u240\\45":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\45\\281\\43":I
    nop

    .line 293
    shr-int/lit8 v1, v69, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\48":I
    move-object v2, v15

    .local v2, "$composer\\48":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 264
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\48\\293\\42":I
    const v5, 0x6d423196

    move/from16 v35, v1

    .end local v1    # "$changed\\48":I
    .local v35, "$changed\\48":I
    const-string v1, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v5, v61, 0x6

    and-int/lit8 v5, v5, 0x70

    const/16 v34, 0x6

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\49":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    .local v1, "$this$ReviewScreen_u24lambda_u241_u242_u240\\49":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v68, v2

    .local v68, "$composer\\49":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 33
    .local v71, "$i$a$-Box-ReviewScreenKt$ReviewScreen$2$3$1\\49\\264\\40":I
    move-object/from16 v72, v1

    .end local v1    # "$this$ReviewScreen_u24lambda_u241_u242_u240\\49":Landroidx/compose/foundation/layout/BoxScope;
    .local v72, "$this$ReviewScreen_u24lambda_u241_u242_u240\\49":Landroidx/compose/foundation/layout/BoxScope;
    const v1, -0x2f655001

    move-object/from16 v75, v2

    .end local v2    # "$composer\\48":Landroidx/compose/runtime/Composer;
    .local v75, "$composer\\48":Landroidx/compose/runtime/Composer;
    const-string v2, "C32@1782L26:ReviewScreen.kt#i35lj1"

    move/from16 v76, v3

    move-object/from16 v3, v68

    .end local v68    # "$composer\\49":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\49":Landroidx/compose/runtime/Composer;
    .local v76, "$i$a$-Layout-BoxKt$Box$1\\48\\293\\42":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x40

    .local v2, "$this$dp\\50":I
    const/16 v68, 0x0

    .line 257
    .local v68, "$i$f$getDp\\50\\33":I
    move-object/from16 v77, v4

    .end local v4    # "materialized\\43":Landroidx/compose/ui/Modifier;
    .local v77, "materialized\\43":Landroidx/compose/ui/Modifier;
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 33
    .end local v2    # "$this$dp\\50":I
    .end local v68    # "$i$f$getDp\\50\\33":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/4 v2, 0x0

    const/4 v4, 0x6

    invoke-static {v1, v3, v4, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Mark(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    .end local v3    # "$composer\\49":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\49":I
    .end local v71    # "$i$a$-Box-ReviewScreenKt$ReviewScreen$2$3$1\\49\\264\\40":I
    .end local v72    # "$this$ReviewScreen_u24lambda_u241_u242_u240\\49":Landroidx/compose/foundation/layout/BoxScope;
    invoke-static/range {v75 .. v75}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 293
    .end local v35    # "$changed\\48":I
    .end local v75    # "$composer\\48":Landroidx/compose/runtime/Composer;
    .end local v76    # "$i$a$-Layout-BoxKt$Box$1\\48\\293\\42":I
    nop

    .line 294
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 273
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 295
    nop

    .line 267
    .end local v66    # "$i$f$ReusableComposeNode\\44\\271":I
    .end local v69    # "$changed\\44":I
    .end local v70    # "factory\\44":Lkotlin/jvm/functions/Function0;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 296
    nop

    .line 258
    .end local v16    # "compositeKeyHash\\43":I
    .end local v62    # "$changed\\43":I
    .end local v64    # "$i$f$Layout\\43\\263":I
    .end local v67    # "modifier\\43":Landroidx/compose/ui/Modifier;
    .end local v73    # "localMap\\43":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v77    # "materialized\\43":Landroidx/compose/ui/Modifier;
    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 297
    nop

    .line 34
    .end local v15    # "$composer\\42":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$f$Box\\42\\33":I
    .end local v60    # "modifier\\42":Landroidx/compose/ui/Modifier;
    .end local v61    # "$changed\\42":I
    .end local v63    # "contentAlignment\\42":Landroidx/compose/ui/Alignment;
    .end local v65    # "propagateMinConstraints\\42":Z
    .end local v74    # "measurePolicy\\42":Landroidx/compose/ui/layout/MeasurePolicy;
    move-object v1, v12

    check-cast v1, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getScoreCount()I

    move-result v1

    if-lez v1, :cond_8d8

    const-string v1, "\u8fd9\u4e00\u8f6e\uff0c\u8f9b\u82e6\u4e86\u3002"

    goto :goto_8da

    :cond_8d8
    const-string v1, "\u73b0\u5728\u53ef\u4ee5\u6b47\u4e00\u6b47\u3002"

    :goto_8da
    move-object v2, v12

    check-cast v2, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getNextDueAt()Ljava/lang/Long;

    move-result-object v2

    if-eqz v2, :cond_90c

    move-object v2, v12

    check-cast v2, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getNextDueAt()Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    invoke-static {v2, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->localTime(J)Ljava/lang/String;

    move-result-object v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u4e0b\u4e00\u5f20\u5c06\u5728 "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5230\u671f\u3002"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_90e

    :cond_90c
    const-string v2, "\u5f53\u524d\u6ca1\u6709\u53ef\u4ee5\u5b66\u4e60\u7684\u5361\u7247\u3002"

    :goto_90e
    const/4 v4, 0x0

    invoke-static {v1, v2, v14, v4, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->SectionTitle(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 35
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v15, 0x1

    invoke-static {v1, v5, v15, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const-string v2, "review-complete"

    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    new-instance v2, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v2, v12}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda6;-><init>(Lcom/xunji/flashcards/ui/ReviewUiState;)V

    const v3, 0x544977d4

    const/16 v4, 0x36

    invoke-static {v3, v15, v2, v14, v4}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    check-cast v2, Lkotlin/jvm/functions/Function3;

    const/4 v3, 0x0

    invoke-static {v1, v2, v14, v4, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 36
    const-string v1, "\u5b66\u4e60\u6b65\u9aa4\u4f1a\u5728\u5230\u671f\u540e\u518d\u6b21\u51fa\u73b0\u3002\u7559\u4e00\u70b9\u7a7a\u95f4\uff0c\u8ba9\u8bb0\u5fc6\u6c89\u6dc0\u3002"

    const/4 v2, 0x2

    const/4 v4, 0x6

    invoke-static {v1, v3, v14, v4, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 37
    shr-int/lit8 v1, v25, 0xf

    and-int/lit8 v1, v1, 0x70

    or-int/2addr v1, v4

    move-object v3, v11

    .end local v11    # "materialized\\34":Landroidx/compose/ui/Modifier;
    .local v3, "materialized\\34":Landroidx/compose/ui/Modifier;
    const/16 v11, 0x1c

    const-string v4, "\u5b8c\u6210\u590d\u4e60"

    move-object v5, v6

    .end local v6    # "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v5, "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v6, 0x0

    move-object v15, v7

    .end local v7    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v15, "$composer\\33":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    move-object/from16 v16, v8

    .end local v8    # "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v16, "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v8, 0x0

    move-object/from16 v49, v9

    move-object/from16 v35, v10

    move-object v9, v14

    move-object/from16 v34, v16

    move-object/from16 v59, v57

    move v10, v1

    move-object/from16 v57, v3

    move-object v1, v5

    move-object v3, v15

    move-object/from16 v5, p6

    .end local v5    # "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v10    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .end local v14    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .end local v15    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .end local v16    # "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v1, "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v3, "$composer\\33":Landroidx/compose/runtime/Composer;
    .local v9, "$composer\\40":Landroidx/compose/runtime/Composer;
    .local v34, "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v35, "modifier\\34":Landroidx/compose/ui/Modifier;
    .local v49, "localMap\\34":Landroidx/compose/runtime/CompositionLocalMap;
    .local v57, "materialized\\34":Landroidx/compose/ui/Modifier;
    .local v59, "factory\\35":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v4 .. v11}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v11, 0x0

    const/4 v15, 0x1

    invoke-static {v4, v5, v15, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v6, 0x34

    .local v6, "$this$dp\\51":I
    const/4 v7, 0x0

    .line 298
    .local v7, "$i$f$getDp\\51\\37":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 37
    .end local v6    # "$this$dp\\51":I
    .end local v7    # "$i$f$getDp\\51\\37":I
    invoke-static {v4, v6, v5, v2, v11}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    const/16 v2, 0x12

    .local v2, "$this$dp\\52":I
    const/4 v4, 0x0

    .line 298
    .local v4, "$i$f$getDp\\52\\37":I
    int-to-float v6, v2

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 37
    .end local v2    # "$this$dp\\52":I
    .end local v4    # "$i$f$getDp\\52\\37":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    move-object v7, v2

    check-cast v7, Landroidx/compose/ui/graphics/Shape;

    sget-object v2, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;

    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$ReviewScreenKt;->getLambda$-964842$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v2

    shr-int/lit8 v4, v25, 0xf

    and-int/lit8 v4, v4, 0xe

    const v6, 0x30000030

    or-int v15, v4, v6

    const/16 v16, 0x1f4

    const/4 v6, 0x0

    const/4 v8, 0x0

    .end local v9    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .restart local v14    # "$composer\\40":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    move-object v4, v13

    move-object v13, v2

    move-object v2, v4

    move-object/from16 v4, p5

    .end local v13    # "$composer\\39":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\39":Landroidx/compose/runtime/Composer;
    invoke-static/range {v4 .. v16}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 33
    move-object v9, v14

    .end local v14    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer\\40":Landroidx/compose/runtime/Composer;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 38
    nop

    .line 227
    .end local v9    # "$composer\\40":Landroidx/compose/runtime/Composer;
    .end local v53    # "$changed\\40":I
    .end local v54    # "$this$ReviewScreen_u24lambda_u241_u242\\40":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v55    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$3\\40\\227\\11":I
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 256
    .end local v2    # "$composer\\39":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Layout-ColumnKt$Column$1\\39\\256\\33":I
    .end local v56    # "$changed\\39":I
    nop

    .line 299
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 236
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 300
    nop

    .line 230
    .end local v50    # "$changed\\35":I
    .end local v51    # "$i$f$ReusableComposeNode\\35\\234":I
    .end local v59    # "factory\\35":Lkotlin/jvm/functions/Function0;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 301
    nop

    .line 221
    .end local v35    # "modifier\\34":Landroidx/compose/ui/Modifier;
    .end local v46    # "$changed\\34":I
    .end local v47    # "$i$f$Layout\\34\\226":I
    .end local v48    # "compositeKeyHash\\34":I
    .end local v49    # "localMap\\34":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57    # "materialized\\34":Landroidx/compose/ui/Modifier;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 302
    nop

    .line 32
    .end local v1    # "verticalArrangement\\33":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v3    # "$composer\\33":Landroidx/compose/runtime/Composer;
    .end local v22    # "$changed\\33":I
    .end local v34    # "measurePolicy\\33":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v39    # "modifier\\33":Landroidx/compose/ui/Modifier;
    .end local v42    # "$i$f$Column\\33\\32":I
    .end local v58    # "horizontalAlignment\\33":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-object/from16 v1, p3

    move-object/from16 v54, v0

    move/from16 v66, v25

    move-object/from16 v13, v27

    move/from16 v12, v40

    move-object/from16 v3, v94

    goto/16 :goto_d74

    .line 39
    :cond_9d0
    move-object v3, v12

    move-object/from16 v14, v92

    move-object/from16 v4, v93

    const v8, 0x4ff7456f

    const v15, 0x7cc0ae6e

    const v5, 0x3be4e080

    invoke-interface {v0, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v5, "41@2698L2307"

    invoke-static {v0, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 40
    instance-of v5, v3, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    if-eqz v5, :cond_9ee

    move-object v13, v3

    check-cast v13, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    goto :goto_9fb

    :cond_9ee
    instance-of v5, v3, Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;

    if-eqz v5, :cond_9fa

    move-object v5, v3

    check-cast v5, Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;

    invoke-virtual {v5}, Lcom/xunji/flashcards/ui/ReviewUiState$Submitting;->getAnswer()Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    move-result-object v13

    goto :goto_9fb

    :cond_9fa
    const/4 v13, 0x0

    .line 41
    .local v13, "answer\\11":Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    :goto_9fb
    if-eqz v13, :cond_a03

    invoke-virtual {v13}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getCandidate()Lcom/xunji/core/model/CardCandidate;

    move-result-object v5

    if-nez v5, :cond_a0a

    :cond_a03
    move-object v5, v3

    check-cast v5, Lcom/xunji/flashcards/ui/ReviewUiState$Question;

    invoke-virtual {v5}, Lcom/xunji/flashcards/ui/ReviewUiState$Question;->getCandidate()Lcom/xunji/core/model/CardCandidate;

    move-result-object v5

    .line 42
    .local v5, "candidate\\11":Lcom/xunji/core/model/CardCandidate;
    :cond_a0a
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    const/4 v7, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v6, v7, v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v7, 0x16

    .local v7, "$this$dp\\53":I
    const/4 v9, 0x0

    .line 303
    .local v9, "$i$f$getDp\\53\\42":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 42
    .end local v7    # "$this$dp\\53":I
    .end local v9    # "$i$f$getDp\\53\\42":I
    const/16 v9, 0xc

    .local v9, "$this$dp\\54":I
    const/4 v10, 0x0

    .line 303
    .local v10, "$i$f$getDp\\54\\42":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 42
    .end local v9    # "$this$dp\\54":I
    .end local v10    # "$i$f$getDp\\54\\42":I
    const/16 v10, 0x16

    .local v10, "$this$dp\\55":I
    const/4 v11, 0x0

    .line 303
    .local v11, "$i$f$getDp\\55\\42":I
    int-to-float v12, v10

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 42
    .end local v10    # "$this$dp\\55":I
    .end local v11    # "$i$f$getDp\\55\\42":I
    const/16 v11, 0x12

    .local v11, "$this$dp\\56":I
    const/4 v12, 0x0

    .line 303
    .local v12, "$i$f$getDp\\56\\42":I
    int-to-float v15, v11

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v11

    .line 42
    .end local v11    # "$this$dp\\56":I
    .end local v12    # "$i$f$getDp\\56\\42":I
    invoke-static {v6, v7, v9, v10, v11}, Landroidx/compose/foundation/layout/PaddingKt;->padding-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    move-result-object v6

    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v9, 0x10

    .local v9, "$this$dp\\57":I
    const/4 v10, 0x0

    .line 303
    .local v10, "$i$f$getDp\\57\\42":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 42
    .end local v9    # "$this$dp\\57":I
    .end local v10    # "$i$f$getDp\\57\\42":I
    invoke-virtual {v7, v9}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v7

    check-cast v7, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v7, "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v22, 0x36

    .local v22, "$changed\\58":I
    move-object v9, v0

    .local v9, "$composer\\58":Landroidx/compose/runtime/Composer;
    move-object/from16 v39, v6

    .local v39, "modifier\\58":Landroidx/compose/ui/Modifier;
    const/16 v46, 0x0

    .line 304
    .local v46, "$i$f$Column\\58\\42":I
    invoke-static {v9, v8, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 305
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v4

    .line 308
    .local v4, "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v6, v22, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v8, v22, 0x3

    and-int/lit8 v8, v8, 0x70

    or-int/2addr v6, v8

    invoke-static {v7, v4, v9, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 312
    .local v6, "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v8, v22, 0x3

    and-int/lit8 v8, v8, 0x70

    .line 309
    move/from16 v47, v8

    .local v47, "$changed\\59":I
    move-object/from16 v8, v39

    .local v8, "modifier\\59":Landroidx/compose/ui/Modifier;
    const/16 v48, 0x0

    .line 313
    .local v48, "$i$f$Layout\\59\\309":I
    const v10, -0x451e1427

    invoke-static {v9, v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 314
    const/4 v2, 0x0

    invoke-static {v9, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 315
    .local v2, "compositeKeyHash\\59":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v10

    .line 316
    .local v10, "localMap\\59":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9, v8}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v11

    .line 318
    .local v11, "materialized\\59":Landroidx/compose/ui/Modifier;
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v12

    shl-int/lit8 v15, v47, 0x6

    and-int/lit16 v15, v15, 0x380

    const/16 v34, 0x6

    or-int/lit8 v15, v15, 0x6

    .line 317
    nop

    .local v12, "factory\\60":Lkotlin/jvm/functions/Function0;
    move/from16 v16, v15

    .local v16, "$changed\\60":I
    const/16 v50, 0x0

    .line 319
    .local v50, "$i$f$ReusableComposeNode\\60\\317":I
    const v15, -0x20f7d59c

    invoke-static {v9, v15, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 320
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_aab

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 321
    :cond_aab
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 322
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_ab8

    .line 323
    invoke-interface {v9, v12}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_abb

    .line 325
    :cond_ab8
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 327
    :goto_abb
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\61":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 328
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\61\\327\\59":I
    sget-object v35, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v54, v0

    .end local v0    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v35 .. v35}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 329
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 330
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\62":Lkotlin/jvm/functions/Function2;
    const/16 v35, 0x0

    .line 331
    .local v35, "$i$f$set-impl\\62\\330":I
    move-object/from16 v51, v1

    .local v51, "$this$set_impl_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 332
    .local v52, "$i$a$-with-Updater$set$1\\63\\331\\62":I
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v53

    if-nez v53, :cond_afc

    move/from16 v53, v2

    .end local v2    # "compositeKeyHash\\59":I
    .local v53, "compositeKeyHash\\59":I
    invoke-interface/range {v51 .. v51}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v55, v4

    .end local v4    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    .local v55, "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_af9

    goto :goto_b00

    :cond_af9
    move-object/from16 v4, v51

    goto :goto_b10

    .end local v53    # "compositeKeyHash\\59":I
    .end local v55    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v2    # "compositeKeyHash\\59":I
    .restart local v4    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    :cond_afc
    move/from16 v53, v2

    move-object/from16 v55, v4

    .line 333
    .end local v2    # "compositeKeyHash\\59":I
    .end local v4    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v53    # "compositeKeyHash\\59":I
    .restart local v55    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    :goto_b00
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v51

    .end local v51    # "$this$set_impl_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 334
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 336
    :goto_b10
    nop

    .line 331
    .end local v4    # "$this$set_impl_u24lambda_u240\\62":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-with-Updater$set$1\\63\\331\\62":I
    nop

    .line 336
    nop

    .line 337
    .end local v0    # "block\\62":Lkotlin/jvm/functions/Function2;
    .end local v35    # "$i$f$set-impl\\62\\330":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v11, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 338
    nop

    .line 327
    .end local v1    # "$this$Layout_u24lambda_u240\\61":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\61\\327\\59":I
    nop

    .line 339
    shr-int/lit8 v0, v16, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\64":I
    move-object v1, v9

    .local v1, "$composer\\64":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 310
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\64\\339\\58":I
    const v15, 0x7cc0ae6e

    invoke-static {v1, v15, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v14, v22, 0x6

    and-int/lit8 v14, v14, 0x70

    const/16 v34, 0x6

    or-int/lit8 v34, v14, 0x6

    .local v34, "$changed\\65":I
    check-cast v4, Landroidx/compose/foundation/layout/ColumnScope;

    .local v4, "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v14, v1

    .local v14, "$composer\\65":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 43
    .local v35, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4\\65\\310\\11":I
    const v15, -0x124dad68

    move/from16 v42, v0

    .end local v0    # "$changed\\64":I
    .local v42, "$changed\\64":I
    const-string v0, "C42@2947L81,42@2817L211:ReviewScreen.kt#i35lj1"

    invoke-static {v14, v15, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    move-object/from16 v51, v1

    move/from16 v52, v2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v15, 0x0

    .end local v1    # "$composer\\64":Landroidx/compose/runtime/Composer;
    .end local v2    # "$i$a$-Layout-ColumnKt$Column$1\\64\\339\\58":I
    .local v51, "$composer\\64":Landroidx/compose/runtime/Composer;
    .local v52, "$i$a$-Layout-ColumnKt$Column$1\\64\\339\\58":I
    invoke-static {v0, v15, v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v56

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v1, 0x12

    .local v1, "$this$dp\\66":I
    const/4 v2, 0x0

    .line 340
    .local v2, "$i$f$getDp\\66\\43":I
    int-to-float v15, v1

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 43
    .end local v1    # "$this$dp\\66":I
    .end local v2    # "$i$f$getDp\\66\\43":I
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    move-object/from16 v57, v0

    check-cast v57, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v1, 0x6

    .local v1, "$this$dp\\67":I
    const/4 v2, 0x0

    .line 340
    .local v2, "$i$f$getDp\\67\\43":I
    int-to-float v15, v1

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 43
    .end local v1    # "$this$dp\\67":I
    .end local v2    # "$i$f$getDp\\67\\43":I
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    move-object/from16 v58, v0

    check-cast v58, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    new-instance v0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v0, v5, v13}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda7;-><init>(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V

    const v1, -0x1fb52376

    const/16 v2, 0x36

    const/4 v15, 0x1

    invoke-static {v1, v15, v0, v14, v2}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v62, v0

    check-cast v62, Lkotlin/jvm/functions/Function3;

    const v64, 0x1801b6

    const/16 v65, 0x38

    const/16 v59, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    move-object/from16 v63, v14

    .end local v14    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v63, "$composer\\65":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v65}, Landroidx/compose/foundation/layout/FlowLayoutKt;->FlowRow(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Vertical;IILkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 44
    move-object/from16 v1, v63

    .end local v63    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v1, "$composer\\65":Landroidx/compose/runtime/Composer;
    if-eqz v13, :cond_ba2

    invoke-virtual {v13}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getRendered()Lcom/xunji/flashcards/anki/RenderedCard;

    move-result-object v0

    if-nez v0, :cond_bb3

    :cond_ba2
    instance-of v0, v3, Lcom/xunji/flashcards/ui/ReviewUiState$Question;

    if-eqz v0, :cond_baa

    move-object v0, v3

    check-cast v0, Lcom/xunji/flashcards/ui/ReviewUiState$Question;

    goto :goto_bab

    :cond_baa
    const/4 v0, 0x0

    :goto_bab
    if-eqz v0, :cond_bb2

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/ReviewUiState$Question;->getRendered()Lcom/xunji/flashcards/anki/RenderedCard;

    move-result-object v0

    goto :goto_bb3

    :cond_bb2
    const/4 v0, 0x0

    .line 46
    .local v0, "rendered\\65":Lcom/xunji/flashcards/anki/RenderedCard;
    :cond_bb3
    :goto_bb3
    invoke-virtual {v5}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v2

    invoke-virtual {v2}, Lcom/xunji/core/model/Flashcard;->getId()Ljava/lang/String;

    move-result-object v2

    const v14, -0x29e14a7c

    invoke-interface {v1, v14, v2}, Landroidx/compose/runtime/Composer;->startMovableGroup(ILjava/lang/Object;)V

    const-string v2, "46@3339L11,46@3398L11,46@3427L1219,46@3244L1402"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 47
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v57, v2

    check-cast v57, Landroidx/compose/ui/Modifier;

    const/16 v60, 0x2

    const/16 v61, 0x0

    const/high16 v58, 0x3f800000    # 1.0f

    const/16 v59, 0x0

    move-object/from16 v56, v4

    .end local v4    # "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    .local v56, "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v56 .. v61}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    move-object/from16 v69, v56

    const/4 v4, 0x1

    const/4 v14, 0x0

    const/4 v15, 0x0

    .end local v56    # "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    .local v69, "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v2, v15, v4, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v56

    const/16 v2, 0x1c

    .local v2, "$this$dp\\68":I
    const/4 v14, 0x0

    .line 341
    .local v14, "$i$f$getDp\\68\\47":I
    int-to-float v15, v2

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 47
    .end local v2    # "$this$dp\\68":I
    .end local v14    # "$i$f$getDp\\68\\47":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    move-object/from16 v57, v2

    check-cast v57, Landroidx/compose/ui/graphics/Shape;

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v1, v14}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v58

    const/4 v2, 0x1

    .local v2, "$this$dp\\69":I
    const/4 v14, 0x0

    .line 341
    .local v14, "$i$f$getDp\\69\\47":I
    int-to-float v15, v2

    invoke-static {v15}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 47
    .end local v2    # "$this$dp\\69":I
    .end local v14    # "$i$f$getDp\\69\\47":I
    sget-object v14, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v15, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v14, v1, v15}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v14

    invoke-virtual {v14}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v14

    invoke-static {v2, v14, v15}, Landroidx/compose/foundation/BorderStrokeKt;->BorderStroke-cXLIe8U(FJ)Landroidx/compose/foundation/BorderStroke;

    move-result-object v64

    move-object v2, v10

    .end local v10    # "localMap\\59":Landroidx/compose/runtime/CompositionLocalMap;
    .local v2, "localMap\\59":Landroidx/compose/runtime/CompositionLocalMap;
    new-instance v10, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;

    move-object v14, v11

    move-object v11, v0

    move-object v0, v14

    move-object v14, v5

    move-object v15, v13

    move-object/from16 v13, v27

    move-object/from16 v27, v12

    move/from16 v12, v40

    .end local v5    # "candidate\\11":Lcom/xunji/core/model/CardCandidate;
    .end local v40    # "submitting":Z
    .local v0, "materialized\\59":Landroidx/compose/ui/Modifier;
    .local v11, "rendered\\65":Lcom/xunji/flashcards/anki/RenderedCard;
    .local v12, "submitting":Z
    .local v13, "openMedia":Lkotlin/jvm/functions/Function2;
    .local v14, "candidate\\11":Lcom/xunji/core/model/CardCandidate;
    .local v15, "answer\\11":Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .local v27, "factory\\60":Lkotlin/jvm/functions/Function0;
    invoke-direct/range {v10 .. v15}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V

    const v5, -0x8926ce3

    move-object/from16 v40, v0

    const/16 v0, 0x36

    .end local v0    # "materialized\\59":Landroidx/compose/ui/Modifier;
    .local v40, "materialized\\59":Landroidx/compose/ui/Modifier;
    invoke-static {v5, v4, v10, v1, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v65, v0

    check-cast v65, Lkotlin/jvm/functions/Function2;

    const/high16 v67, 0xc00000

    const/16 v68, 0x38

    const-wide/16 v60, 0x0

    const/16 v62, 0x0

    const/16 v63, 0x0

    move-object/from16 v66, v1

    .end local v1    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v66, "$composer\\65":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v68}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .end local v66    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .restart local v1    # "$composer\\65":Landroidx/compose/runtime/Composer;
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endMovableGroup()V

    .line 61
    if-nez v15, :cond_c82

    const v0, -0x29e09949

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "60@4675L50"

    invoke-static {v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    shr-int/lit8 v0, v25, 0x3

    and-int/lit8 v0, v0, 0x70

    or-int/lit16 v0, v0, 0x6006

    const/16 v10, 0xc

    const-string v3, "\u663e\u793a\u7b54\u6848"

    const/4 v5, 0x0

    move-object v4, v6

    .end local v6    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v4, "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v6, 0x0

    move-object/from16 v49, v7

    .end local v7    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v49, "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-string v7, "reveal-answer"

    move-object/from16 v64, v4

    move-object/from16 v65, v8

    move-object/from16 v4, p2

    move-object v8, v1

    move/from16 v1, v25

    move-object/from16 v25, v9

    move v9, v0

    move-object/from16 v0, p7

    .end local v4    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v9    # "$composer\\58":Landroidx/compose/runtime/Composer;
    .end local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v0, "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v1, "$dirty":I
    .local v8, "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\58":Landroidx/compose/runtime/Composer;
    .local v64, "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v65, "modifier\\59":Landroidx/compose/ui/Modifier;
    invoke-static/range {v3 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move/from16 v66, v1

    move-object/from16 v3, v94

    move-object/from16 v1, p3

    goto/16 :goto_d5a

    .line 62
    .end local v0    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v49    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v64    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v65    # "modifier\\59":Landroidx/compose/ui/Modifier;
    .local v1, "$composer\\65":Landroidx/compose/runtime/Composer;
    .restart local v6    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v7    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v8, "modifier\\59":Landroidx/compose/ui/Modifier;
    .restart local v9    # "$composer\\58":Landroidx/compose/runtime/Composer;
    .local v25, "$dirty":I
    .restart local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    :cond_c82
    move-object/from16 v0, p7

    move-object/from16 v64, v6

    move-object/from16 v49, v7

    move-object/from16 v65, v8

    move-object v8, v1

    move/from16 v1, v25

    move-object/from16 v25, v9

    .end local v6    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v7    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9    # "$composer\\58":Landroidx/compose/runtime/Composer;
    .end local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .restart local v0    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v1, "$dirty":I
    .local v8, "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\58":Landroidx/compose/runtime/Composer;
    .restart local v49    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v64    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v65    # "modifier\\59":Landroidx/compose/ui/Modifier;
    const v3, -0x123189aa

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, ""

    invoke-static {v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 63
    invoke-virtual {v15}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getError()Ljava/lang/String;

    move-result-object v3

    if-eqz v3, :cond_cb6

    const v3, -0x29e08e02

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "62@4766L25"

    invoke-static {v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual {v15}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getError()Ljava/lang/String;

    move-result-object v3

    const/16 v5, 0x30

    const/4 v9, 0x0

    invoke-static {v3, v4, v8, v5, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_cbd

    :cond_cb6
    const/4 v9, 0x0

    const v3, -0x12795d63

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_cbd
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 64
    invoke-virtual {v15}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getRetryRating()Lcom/xunji/core/model/Rating;

    move-result-object v3

    if-eqz v3, :cond_d37

    const v3, -0x29e08626

    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v3, "63@4874L29,63@4826L117"

    invoke-static {v8, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    if-eqz v12, :cond_cd6

    const-string v3, "\u6b63\u5728\u8bb0\u5f55\u2026"

    goto :goto_cd8

    :cond_cd6
    const-string v3, "\u91cd\u8bd5\u8bb0\u5f55"

    :goto_cd8
    move-object/from16 v56, v3

    const v3, -0x29e0807e

    const-string v5, "CC(remember):ReviewScreen.kt#9igjgp"

    invoke-static {v8, v3, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v3, v1, 0x1c00

    const/16 v5, 0x800

    if-ne v3, v5, :cond_cea

    move v6, v4

    goto :goto_ceb

    :cond_cea
    move v6, v9

    :goto_ceb
    move-object/from16 v3, v94

    .end local v94    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v15}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v4, v6

    .local v4, "invalid\\70":Z
    move-object v5, v8

    .local v5, "$this$cache\\70":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 342
    .local v6, "$i$f$cache\\70\\64":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v7

    .local v7, "it\\70":Ljava/lang/Object;
    const/4 v9, 0x0

    .line 343
    .local v9, "$i$a$-let-ComposerKt$cache$1\\71\\342\\70":I
    if-nez v4, :cond_d0b

    sget-object v10, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v10}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v7, v10, :cond_d04

    goto :goto_d0b

    .line 347
    :cond_d04
    move-object/from16 p7, v0

    move/from16 v66, v1

    move-object/from16 v1, p3

    goto :goto_d1c

    .line 344
    :cond_d0b
    :goto_d0b
    const/4 v10, 0x0

    .line 64
    .local v10, "$i$a$-cache-ReviewScreenKt$ReviewScreen$2$4$3\\72\\344\\65":I
    move-object/from16 p7, v0

    .end local v0    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .restart local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda9;

    move/from16 v66, v1

    move-object/from16 v1, p3

    .end local v1    # "$dirty":I
    .local v66, "$dirty":I
    invoke-direct {v0, v1, v15}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda9;-><init>(Lkotlin/jvm/functions/Function1;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)V

    .line 344
    .end local v10    # "$i$a$-cache-ReviewScreenKt$ReviewScreen$2$4$3\\72\\344\\65":I
    nop

    .line 345
    .local v0, "value\\71":Ljava/lang/Object;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 346
    move-object v7, v0

    .line 342
    .end local v0    # "value\\71":Ljava/lang/Object;
    .end local v7    # "it\\70":Ljava/lang/Object;
    .end local v9    # "$i$a$-let-ComposerKt$cache$1\\71\\342\\70":I
    :goto_d1c
    nop

    .line 64
    .end local v4    # "invalid\\70":Z
    .end local v5    # "$this$cache\\70":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$cache\\70\\64":I
    move-object/from16 v57, v7

    check-cast v57, Lkotlin/jvm/functions/Function0;

    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    xor-int/lit8 v59, v12, 0x1

    const/16 v62, 0x6000

    const/16 v63, 0x4

    const/16 v58, 0x0

    const-string v60, "retry-rating"

    move-object/from16 v61, v8

    .end local v8    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .local v61, "$composer\\65":Landroidx/compose/runtime/Composer;
    invoke-static/range {v56 .. v63}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .end local v61    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .restart local v8    # "$composer\\65":Landroidx/compose/runtime/Composer;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_d57

    .line 65
    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v66    # "$dirty":I
    .end local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v0, "materialized\\5":Landroidx/compose/ui/Modifier;
    .restart local v1    # "$dirty":I
    .restart local v94    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_d37
    move-object/from16 p7, v0

    move/from16 v66, v1

    move-object/from16 v3, v94

    move-object/from16 v1, p3

    .end local v0    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v1    # "$dirty":I
    .end local v94    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v66    # "$dirty":I
    .restart local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    const v0, -0x29e07656

    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "64@4955L37"

    invoke-static {v8, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget v0, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->$stable:I

    shr-int/lit8 v4, v66, 0x3

    and-int/lit16 v4, v4, 0x380

    or-int/2addr v0, v4

    invoke-static {v15, v12, v1, v8, v0}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->RatingGrid(Lcom/xunji/flashcards/ui/ReviewUiState$Answer;ZLkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 62
    :goto_d57
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 43
    :goto_d5a
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 67
    .end local v11    # "rendered\\65":Lcom/xunji/flashcards/anki/RenderedCard;
    nop

    .line 310
    .end local v8    # "$composer\\65":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\65":I
    .end local v35    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4\\65\\310\\11":I
    .end local v69    # "$this$ReviewScreen_u24lambda_u241_u243\\65":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v51 .. v51}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 339
    .end local v42    # "$changed\\64":I
    .end local v51    # "$composer\\64":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Layout-ColumnKt$Column$1\\64\\339\\58":I
    nop

    .line 348
    invoke-interface/range {v25 .. v25}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 319
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 349
    nop

    .line 313
    .end local v16    # "$changed\\60":I
    .end local v27    # "factory\\60":Lkotlin/jvm/functions/Function0;
    .end local v50    # "$i$f$ReusableComposeNode\\60\\317":I
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 350
    nop

    .line 304
    .end local v2    # "localMap\\59":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v40    # "materialized\\59":Landroidx/compose/ui/Modifier;
    .end local v47    # "$changed\\59":I
    .end local v48    # "$i$f$Layout\\59\\309":I
    .end local v53    # "compositeKeyHash\\59":I
    .end local v65    # "modifier\\59":Landroidx/compose/ui/Modifier;
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 351
    nop

    .line 39
    .end local v14    # "candidate\\11":Lcom/xunji/core/model/CardCandidate;
    .end local v15    # "answer\\11":Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .end local v22    # "$changed\\58":I
    .end local v25    # "$composer\\58":Landroidx/compose/runtime/Composer;
    .end local v39    # "modifier\\58":Landroidx/compose/ui/Modifier;
    .end local v46    # "$i$f$Column\\58\\42":I
    .end local v49    # "verticalArrangement\\58":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v55    # "horizontalAlignment\\58":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v64    # "measurePolicy\\58":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 24
    :goto_d74
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 70
    nop

    .line 106
    .end local v37    # "$this$ReviewScreen_u24lambda_u241\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v38    # "$changed\\11":I
    .end local v41    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2\\11\\106\\0":I
    .end local v54    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v19 .. v19}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 135
    .end local v19    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-Layout-ColumnKt$Column$1\\10\\135\\4":I
    .end local v43    # "$changed\\10":I
    nop

    .line 352
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 115
    invoke-static/range {v17 .. v17}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 353
    nop

    .line 109
    .end local v30    # "$i$f$ReusableComposeNode\\6\\113":I
    .end local v32    # "$changed\\6":I
    .end local v33    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v17 .. v17}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 354
    nop

    .line 99
    .end local v23    # "$changed\\5":I
    .end local v26    # "$i$f$Layout\\5\\105":I
    .end local v29    # "compositeKeyHash\\5":I
    .end local v31    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v45    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local p7    # "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static/range {v17 .. v17}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 355
    nop

    .end local v17    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .end local v18    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v20    # "$changed\\4":I
    .end local v21    # "$i$f$Column\\4\\23":I
    .end local v24    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v28    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v44    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_d94

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 71
    .end local v12    # "submitting":Z
    :cond_d94
    move-object v8, v13

    goto :goto_d9e

    .line 21
    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v13    # "openMedia":Lkotlin/jvm/functions/Function2;
    .end local v66    # "$dirty":I
    .local v8, "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$dirty":I
    .local p7, "openMedia":Lkotlin/jvm/functions/Function2;
    :cond_d96
    move-object v1, v0

    move-object v3, v8

    .end local v8    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move/from16 v66, v9

    move-object v8, v10

    .line 71
    .end local v9    # "$dirty":I
    .end local p7    # "openMedia":Lkotlin/jvm/functions/Function2;
    .local v8, "openMedia":Lkotlin/jvm/functions/Function2;
    .restart local v66    # "$dirty":I
    :goto_d9e
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v11

    if-eqz v11, :cond_dbf

    new-instance v0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda10;

    move/from16 v2, p1

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move/from16 v9, p9

    move/from16 v10, p10

    move-object v4, v1

    move-object v12, v3

    move-object/from16 v1, p0

    move-object/from16 v3, p2

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    invoke-direct/range {v0 .. v10}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda10;-><init>(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;II)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_dc0

    .end local v12    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_dbf
    move-object v12, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v12    # "$composer":Landroidx/compose/runtime/Composer;
    :goto_dc0
    return-void
.end method

.method private static final ReviewScreen$lambda$1$2$1(Lcom/xunji/flashcards/ui/ReviewUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 41
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/ReviewUiState;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C34@2029L15,34@2045L187,34@2233L49:ReviewScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1e4

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:34)"

    const v6, 0x544977d4

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_31
    const-string v2, "\u672c\u6b21\u590d\u4e60"

    const/4 v4, 0x6

    invoke-static {v2, v0, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v6, 0x14

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 357
    .local v7, "$i$f$getDp\\1\\35":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 35
    .end local v6    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\35":I
    invoke-virtual {v2, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v6, 0x30

    .local v6, "$changed\\2":I
    move-object/from16 v7, p2

    .local v7, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 358
    .local v8, "$i$f$Row\\2\\35":I
    const v9, 0x3255a44b

    const-string v10, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 359
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    .line 361
    .local v9, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    .line 364
    .local v10, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v6, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v2, v10, v7, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 368
    .local v11, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v6, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 365
    nop

    .local v12, "$changed\\3":I
    move-object v13, v9

    .local v13, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v14, 0x0

    .line 369
    .local v14, "$i$f$Layout\\3\\365":I
    const v15, -0x451e1427

    move/from16 v16, v4

    const-string v4, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 370
    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 371
    .local v4, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 372
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 374
    .local v5, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v1, v12, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 373
    move-object/from16 v19, v18

    .local v1, "$changed\\4":I
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 375
    .local v18, "$i$f$ReusableComposeNode\\4\\373":I
    move/from16 v20, v1

    .end local v1    # "$changed\\4":I
    .local v20, "$changed\\4":I
    const v1, -0x20f7d59c

    move-object/from16 v21, v2

    .end local v2    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v21, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const-string v2, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 376
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_b3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 377
    :cond_b3
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 378
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_c2

    .line 379
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c7

    .line 381
    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c2
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 383
    :goto_c7
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 384
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\383\\3":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v1

    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 385
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 386
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 387
    .local v22, "$i$f$set-impl\\6\\386":I
    move-object/from16 v24, v2

    .local v24, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 388
    .local v25, "$i$a$-with-Updater$set$1\\7\\387\\6":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_107

    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v26, v4

    .end local v4    # "compositeKeyHash\\3":I
    .local v26, "compositeKeyHash\\3":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_104

    goto :goto_109

    :cond_104
    move-object/from16 v4, v24

    goto :goto_119

    .end local v26    # "compositeKeyHash\\3":I
    .restart local v4    # "compositeKeyHash\\3":I
    :cond_107
    move/from16 v26, v4

    .line 389
    .end local v4    # "compositeKeyHash\\3":I
    .restart local v26    # "compositeKeyHash\\3":I
    :goto_109
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 390
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 392
    :goto_119
    nop

    .line 387
    .end local v4    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\7\\387\\6":I
    nop

    .line 392
    nop

    .line 393
    .end local v1    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\6\\386":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 394
    nop

    .line 383
    .end local v2    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\383\\3":I
    nop

    .line 395
    shr-int/lit8 v1, v20, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object v2, v7

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 366
    .local v3, "$i$a$-Layout-RowKt$Row$1\\8\\395\\2":I
    const v4, 0x56ccd6f5

    move/from16 v19, v1

    .end local v1    # "$changed\\8":I
    .local v19, "$changed\\8":I
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v6, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v30, v2

    .local v30, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v31, v1

    .end local v1    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v31, "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/4 v1, 0x0

    .line 35
    .local v1, "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$3$2$1\\9\\366\\0":I
    move/from16 v16, v1

    .end local v1    # "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$3$2$1\\9\\366\\0":I
    .local v16, "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$3$2$1\\9\\366\\0":I
    const v1, -0x1b93bdad

    move-object/from16 v22, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v2, "C34@2102L62,34@2165L65:ReviewScreen.kt#i35lj1"

    move/from16 v24, v3

    move-object/from16 v3, v30

    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v24, "$i$a$-Layout-RowKt$Row$1\\8\\395\\2":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v1, p0

    check-cast v1, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getScoreCount()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v27

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v1

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/16 v35, 0x2

    const/16 v36, 0x0

    const/high16 v33, 0x3f800000    # 1.0f

    const/16 v34, 0x0

    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    move-object/from16 v1, v31

    .end local v31    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v1, "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x30

    const/16 v32, 0x0

    const-string v28, "\u8bc4\u5206\u6b21\u6570"

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    move-object/from16 v2, p0

    check-cast v2, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v2}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getDistinctCards()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v27

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v2

    check-cast v32, Landroidx/compose/ui/Modifier;

    move-object/from16 v31, v1

    .end local v1    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v31    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    .end local v31    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v1    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x30

    const/16 v32, 0x0

    const-string v28, "\u5b66\u4e60\u5361\u7247"

    invoke-static/range {v27 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 366
    .end local v1    # "$this$ReviewScreen_u24lambda_u241_u242_u241_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v4    # "$changed\\9":I
    .end local v16    # "$i$a$-Row-ReviewScreenKt$ReviewScreen$2$3$2$1\\9\\366\\0":I
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 395
    .end local v19    # "$changed\\8":I
    .end local v22    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Layout-RowKt$Row$1\\8\\395\\2":I
    nop

    .line 396
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 375
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 397
    nop

    .line 369
    .end local v18    # "$i$f$ReusableComposeNode\\4\\373":I
    .end local v20    # "$changed\\4":I
    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 398
    nop

    .line 358
    .end local v5    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\3":I
    .end local v13    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v14    # "$i$f$Layout\\3\\365":I
    .end local v15    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v26    # "compositeKeyHash\\3":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 399
    nop

    .line 35
    .end local v6    # "$changed\\2":I
    .end local v7    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Row\\2\\35":I
    .end local v9    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v10    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v11    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    move-object/from16 v1, p0

    check-cast v1, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/ReviewUiState$Complete;->getDurationMs()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->durationLabel(J)Ljava/lang/String;

    move-result-object v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u6709\u6548\u7528\u65f6 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v1, v3, v0, v3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1e7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1e7

    :cond_1e4
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1e7
    :goto_1e7
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final ReviewScreen$lambda$1$3$0(Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9
    .param p0, "$candidate"    # Lcom/xunji/core/model/CardCandidate;
    .param p1, "$answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .param p2, "$this$FlowRow"    # Landroidx/compose/foundation/layout/FlowRowScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$FlowRow"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C42@2949L27,42@2977L49:ReviewScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eq v0, v1, :cond_13

    const/4 v0, 0x1

    goto :goto_14

    :cond_13
    move v0, v2

    :goto_14
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_46

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2b

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:42)"

    const v3, -0x1fb52376

    invoke-static {v3, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 43
    :cond_2b
    invoke-virtual {p0}, Lcom/xunji/core/model/CardCandidate;->getDeckName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0, p3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    if-nez p1, :cond_37

    const-string v0, "\u5148\u56de\u5fc6\uff0c\u518d\u63ed\u6653"

    goto :goto_39

    :cond_37
    const-string v0, "\u6309\u771f\u5b9e\u611f\u53d7\u8bc4\u5206"

    :goto_39
    invoke-static {v0, p3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_49

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_49

    :cond_46
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_49
    :goto_49
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ReviewScreen$lambda$1$3$1(Lcom/xunji/flashcards/anki/RenderedCard;ZLkotlin/jvm/functions/Function2;Lcom/xunji/core/model/CardCandidate;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 94
    .param p0, "$rendered"    # Lcom/xunji/flashcards/anki/RenderedCard;
    .param p1, "$submitting"    # Z
    .param p2, "$openMedia"    # Lkotlin/jvm/functions/Function2;
    .param p3, "$candidate"    # Lcom/xunji/core/model/CardCandidate;
    .param p4, "$answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v3, p5

    move/from16 v6, p6

    const-string v0, "C:ReviewScreen.kt#i35lj1"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v6, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x2

    if-eq v0, v4, :cond_12

    move v0, v1

    goto :goto_13

    :cond_12
    move v0, v2

    :goto_13
    and-int/lit8 v5, v6, 0x1

    invoke-interface {v3, v0, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_2c7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    const/4 v0, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:47)"

    const v7, -0x8926ce3

    invoke-static {v7, v6, v0, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 48
    :cond_2a
    if-eqz p0, :cond_3d

    if-eqz p1, :cond_3d

    const v0, -0x2daabb1d

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "47@3467L6"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {v3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    goto :goto_6a

    :cond_3d
    const/4 v0, 0x0

    const/4 v5, 0x0

    if-eqz p0, :cond_6f

    const v2, -0x2daab71a

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "47@3497L73"

    invoke-static {v3, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    invoke-static {v2, v0, v1, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0xc

    .local v1, "$this$dp\\1":I
    const/4 v2, 0x0

    .line 400
    .local v2, "$i$f$getDp\\1\\48":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 48
    .end local v1    # "$this$dp\\1":I
    .end local v2    # "$i$f$getDp\\1\\48":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v4, 0x180

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move-object/from16 v1, p2

    invoke-static/range {v0 .. v5}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    :goto_6a
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto/16 :goto_2bd

    :cond_6f
    const v7, -0x2daaa95c

    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v7, "47@3621L21,47@3576L1063"

    invoke-static {v3, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    invoke-static {v7, v0, v1, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    invoke-static {v2, v3, v2, v1}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v9

    const/16 v13, 0xe

    const/4 v14, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static/range {v8 .. v14}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const/16 v8, 0x1a

    .local v8, "$this$dp\\2":I
    const/4 v9, 0x0

    .line 400
    .local v9, "$i$f$getDp\\2\\48":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 48
    .end local v8    # "$this$dp\\2":I
    .end local v9    # "$i$f$getDp\\2\\48":I
    invoke-static {v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v7

    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v9, 0x14

    .local v9, "$this$dp\\3":I
    const/4 v10, 0x0

    .line 400
    .local v10, "$i$f$getDp\\3\\48":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 48
    .end local v9    # "$this$dp\\3":I
    .end local v10    # "$i$f$getDp\\3\\48":I
    invoke-virtual {v8, v9}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v8

    check-cast v8, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v8, "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v9, 0x30

    .local v9, "$changed\\4":I
    move-object/from16 v10, p5

    .local v7, "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v10, "$composer\\4":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 401
    .local v11, "$i$f$Column\\4\\48":I
    const v12, 0x4ff7456f

    const-string v13, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 402
    sget-object v12, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v12}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v12

    .line 405
    .local v12, "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v13, v9, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v9, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v8, v12, v10, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .line 409
    .local v13, "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v9, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 406
    nop

    .local v14, "$changed\\5":I
    move-object v15, v7

    .local v15, "modifier\\5":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    .line 410
    .local v16, "$i$f$Layout\\5\\406":I
    const v1, -0x451e1427

    const-string v0, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v10, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 411
    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 412
    .local v0, "compositeKeyHash\\5":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v1

    .line 413
    .local v1, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 415
    .local v4, "materialized\\5":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v2, v14, 0x6

    and-int/lit16 v2, v2, 0x380

    const/4 v5, 0x6

    or-int/2addr v2, v5

    .line 414
    nop

    .local v2, "$changed\\6":I
    move-object/from16 v19, v17

    .local v19, "factory\\6":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 416
    .local v17, "$i$f$ReusableComposeNode\\6\\414":I
    move/from16 v20, v5

    const v5, -0x20f7d59c

    move/from16 v21, v0

    .end local v0    # "compositeKeyHash\\5":I
    .local v21, "compositeKeyHash\\5":I
    const-string v0, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v10, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 417
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_114

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 418
    :cond_114
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 419
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_123

    .line 420
    move-object/from16 v0, v19

    .end local v19    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_128

    .line 422
    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\6":Lkotlin/jvm/functions/Function0;
    :cond_123
    move-object/from16 v0, v19

    .end local v19    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 424
    :goto_128
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 425
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\424\\5":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v0

    .end local v0    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\6":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 426
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v1, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 427
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\8":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 428
    .local v22, "$i$f$set-impl\\8\\427":I
    move-object/from16 v24, v5

    .local v24, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 429
    .local v25, "$i$a$-with-Updater$set$1\\9\\428\\8":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_16a

    move-object/from16 v26, v1

    .end local v1    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .local v26, "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move/from16 v27, v2

    .end local v2    # "$changed\\6":I
    .local v27, "$changed\\6":I
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_167

    goto :goto_16e

    :cond_167
    move-object/from16 v2, v24

    goto :goto_17e

    .end local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v27    # "$changed\\6":I
    .restart local v1    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "$changed\\6":I
    :cond_16a
    move-object/from16 v26, v1

    move/from16 v27, v2

    .line 430
    .end local v1    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v2    # "$changed\\6":I
    .restart local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v27    # "$changed\\6":I
    :goto_16e
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 431
    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v5, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 433
    :goto_17e
    nop

    .line 428
    .end local v2    # "$this$set_impl_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\9\\428\\8":I
    nop

    .line 433
    nop

    .line 434
    .end local v0    # "block\\8":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\8\\427":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v5, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 435
    nop

    .line 424
    .end local v5    # "$this$Layout_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\7\\424\\5":I
    nop

    .line 436
    shr-int/lit8 v0, v27, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\10":I
    move-object v1, v10

    .local v1, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 407
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\10\\436\\4":I
    const v5, 0x7cc0ae6e

    move/from16 v19, v0

    .end local v0    # "$changed\\10":I
    .local v19, "$changed\\10":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v5, v9, 0x6

    and-int/lit8 v5, v5, 0x70

    or-int/lit8 v5, v5, 0x6

    .local v5, "$changed\\11":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v50, v1

    .local v50, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 49
    .local v22, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1\\11\\407\\0":I
    move-object/from16 v24, v0

    .end local v0    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .local v24, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x304bfe7a

    move-object/from16 v25, v1

    .end local v1    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v25, "$composer\\10":Landroidx/compose/runtime/Composer;
    const-string v1, "C48@3717L24,49@3795L10,49@3749L177,50@4017L614,50@3934L697:ReviewScreen.kt#i35lj1"

    move/from16 v54, v2

    move-object/from16 v2, v50

    .end local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v54, "$i$a$-Layout-ColumnKt$Column$1\\10\\436\\4":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v0, "QUESTION \u00b7 \u6b63\u9762"

    move/from16 v1, v20

    invoke-static {v0, v2, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 50
    invoke-virtual/range {p3 .. p3}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getFront()Ljava/lang/String;

    move-result-object v28

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getHeadlineLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v55

    sget-object v0, Landroidx/compose/ui/text/font/FontFamily;->Companion:Landroidx/compose/ui/text/font/FontFamily$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/font/FontFamily$Companion;->getSerif()Landroidx/compose/ui/text/font/GenericFontFamily;

    move-result-object v0

    const/16 v1, 0x20

    invoke-static {v1}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v58

    const/16 v1, 0x2c

    invoke-static {v1}, Landroidx/compose/ui/unit/TextUnitKt;->getSp(I)J

    move-result-wide v77

    move-object/from16 v63, v0

    check-cast v63, Landroidx/compose/ui/text/font/FontFamily;

    const v85, 0xfdffdd

    const/16 v86, 0x0

    const-wide/16 v56, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const/16 v62, 0x0

    const/16 v64, 0x0

    const-wide/16 v65, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const-wide/16 v70, 0x0

    const/16 v72, 0x0

    const/16 v73, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const/16 v84, 0x0

    invoke-static/range {v55 .. v86}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;Landroidx/compose/ui/graphics/drawscope/DrawStyle;IIJLandroidx/compose/ui/text/style/TextIndent;Landroidx/compose/ui/text/PlatformTextStyle;Landroidx/compose/ui/text/style/LineHeightStyle;IILandroidx/compose/ui/text/style/TextMotion;ILjava/lang/Object;)Landroidx/compose/ui/text/TextStyle;

    move-result-object v49

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v1, "card-front"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    const/16 v52, 0x0

    const v53, 0x1fffc

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const-wide/16 v33, 0x0

    const/16 v35, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const-wide/16 v42, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v47, 0x0

    const/16 v48, 0x0

    const/16 v51, 0x30

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v53}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 51
    .end local v50    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    if-eqz p4, :cond_255

    const/16 v29, 0x1

    goto :goto_257

    :cond_255
    const/16 v29, 0x0

    :goto_257
    const/16 v0, 0xc8

    move-object/from16 v18, v4

    const/4 v1, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    .end local v4    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v0, v4, v3, v1, v3}, Landroidx/compose/animation/core/AnimationSpecKt;->tween$default(IILandroidx/compose/animation/core/Easing;ILjava/lang/Object;)Landroidx/compose/animation/core/TweenSpec;

    move-result-object v0

    check-cast v0, Landroidx/compose/animation/core/FiniteAnimationSpec;

    const/4 v1, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v1, v4, v3}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeIn$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/EnterTransition;

    move-result-object v31

    const/16 v0, 0xb4

    const/4 v1, 0x6

    const/4 v4, 0x0

    invoke-static {v0, v4, v3, v1, v3}, Landroidx/compose/animation/core/AnimationSpecKt;->tween$default(IILandroidx/compose/animation/core/Easing;ILjava/lang/Object;)Landroidx/compose/animation/core/TweenSpec;

    move-result-object v0

    check-cast v0, Landroidx/compose/animation/core/FiniteAnimationSpec;

    const/4 v1, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v1, v4, v3}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeOut$default(Landroidx/compose/animation/core/FiniteAnimationSpec;FILjava/lang/Object;)Landroidx/compose/animation/ExitTransition;

    move-result-object v32

    new-instance v0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda0;

    move-object/from16 v1, p3

    invoke-direct {v0, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/core/model/CardCandidate;)V

    const/16 v3, 0x36

    const v4, 0x6bc3d28f

    const/4 v1, 0x1

    invoke-static {v4, v1, v0, v2, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v34, v0

    check-cast v34, Lkotlin/jvm/functions/Function3;

    and-int/lit8 v0, v5, 0xe

    const v1, 0x186c00

    or-int v36, v0, v1

    const/16 v37, 0x12

    const/16 v30, 0x0

    const/16 v33, 0x0

    move-object/from16 v35, v2

    move-object/from16 v28, v24

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v24    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .local v28, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .local v35, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v37}, Landroidx/compose/animation/AnimatedVisibilityKt;->AnimatedVisibility(Landroidx/compose/foundation/layout/ColumnScope;ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransition;Landroidx/compose/animation/ExitTransition;Ljava/lang/String;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 49
    .end local v28    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v35    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v24    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 58
    nop

    .line 407
    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v5    # "$changed\\11":I
    .end local v22    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1\\11\\407\\0":I
    .end local v24    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240\\11":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v25 .. v25}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 436
    .end local v19    # "$changed\\10":I
    .end local v25    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v54    # "$i$a$-Layout-ColumnKt$Column$1\\10\\436\\4":I
    nop

    .line 437
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 416
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 438
    nop

    .line 410
    .end local v17    # "$i$f$ReusableComposeNode\\6\\414":I
    .end local v23    # "factory\\6":Lkotlin/jvm/functions/Function0;
    .end local v27    # "$changed\\6":I
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 439
    nop

    .line 401
    .end local v14    # "$changed\\5":I
    .end local v15    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v16    # "$i$f$Layout\\5\\406":I
    .end local v18    # "materialized\\5":Landroidx/compose/ui/Modifier;
    .end local v21    # "compositeKeyHash\\5":I
    .end local v26    # "localMap\\5":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 440
    nop

    .line 48
    .end local v7    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v8    # "verticalArrangement\\4":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v9    # "$changed\\4":I
    .end local v10    # "$composer\\4":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$Column\\4\\48":I
    .end local v12    # "horizontalAlignment\\4":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v13    # "measurePolicy\\4":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    :goto_2bd
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2ca

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_2ca

    .line 47
    :cond_2c7
    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 59
    :cond_2ca
    :goto_2ca
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ReviewScreen$lambda$1$3$1$0$0(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/animation/AnimatedVisibilityScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 57
    .param p0, "$candidate"    # Lcom/xunji/core/model/CardCandidate;
    .param p1, "$this$AnimatedVisibility"    # Landroidx/compose/animation/AnimatedVisibilityScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$AnimatedVisibility"

    move-object/from16 v1, p1

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C51@4027L595:ReviewScreen.kt#i35lj1"

    move-object/from16 v2, p2

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_20

    const/4 v0, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:51)"

    const v4, 0x6bc3d28f

    move/from16 v5, p3

    invoke-static {v4, v5, v0, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    goto :goto_22

    :cond_20
    move/from16 v5, p3

    .line 52
    :goto_22
    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v3, 0x14

    .local v3, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 441
    .local v4, "$i$f$getDp\\1\\52":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 52
    .end local v3    # "$this$dp\\1":I
    .end local v4    # "$i$f$getDp\\1\\52":I
    invoke-virtual {v0, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    check-cast v0, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v0, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v3, 0x30

    .local v3, "$changed\\2":I
    move-object/from16 v4, p2

    .local v4, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 442
    .local v6, "$i$f$Column\\2\\52":I
    const v7, 0x4ff7456f

    const-string v8, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v4, v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 443
    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    .line 445
    .local v7, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 448
    .local v8, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v3, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v0, v8, v4, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 452
    .local v9, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 449
    nop

    .local v10, "$changed\\3":I
    move-object v11, v7

    .local v11, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    .line 453
    .local v12, "$i$f$Layout\\3\\449":I
    const v13, -0x451e1427

    const-string v14, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v4, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 454
    const/4 v13, 0x0

    invoke-static {v4, v13}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v13

    .line 455
    .local v13, "compositeKeyHash\\3":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 456
    .local v14, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v4, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 458
    .local v15, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v17, v0

    .end local v0    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v17, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shl-int/lit8 v0, v10, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v18, v0

    const/4 v0, 0x6

    or-int/lit8 v18, v18, 0x6

    .line 457
    move-object/from16 v19, v16

    .local v18, "$changed\\4":I
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 459
    .local v16, "$i$f$ReusableComposeNode\\4\\457":I
    move/from16 v20, v0

    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 460
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_a0

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 461
    :cond_a0
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 462
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_af

    .line 463
    move-object/from16 v0, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b4

    .line 465
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_af
    move-object/from16 v0, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 467
    :goto_b4
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 468
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\467\\3":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v9, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 469
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 470
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 471
    .local v21, "$i$f$set-impl\\6\\470":I
    move-object/from16 v23, v1

    .local v23, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 472
    .local v24, "$i$a$-with-Updater$set$1\\7\\471\\6":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_f4

    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v25, v3

    .end local v3    # "$changed\\2":I
    .local v25, "$changed\\2":I
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f1

    goto :goto_f6

    :cond_f1
    move-object/from16 v3, v23

    goto :goto_106

    .end local v25    # "$changed\\2":I
    .restart local v3    # "$changed\\2":I
    :cond_f4
    move/from16 v25, v3

    .line 473
    .end local v3    # "$changed\\2":I
    .restart local v25    # "$changed\\2":I
    :goto_f6
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 474
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 476
    :goto_106
    nop

    .line 471
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\7\\471\\6":I
    nop

    .line 476
    nop

    .line 477
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\6\\470":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 478
    nop

    .line 467
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\467\\3":I
    nop

    .line 479
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v1, v4

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 450
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\479\\2":I
    const v3, 0x7cc0ae6e

    move/from16 v19, v0

    .end local v0    # "$changed\\8":I
    .local v19, "$changed\\8":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v25, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v30, v1

    .local v30, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 53
    .local v21, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1$1$1\\9\\450\\0":I
    move-object/from16 v23, v0

    .end local v0    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v23, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x6bb35fb8

    move-object/from16 v24, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C52@4132L11,52@4094L65,52@4160L22,53@4237L10,53@4192L105:ReviewScreen.kt#i35lj1"

    move/from16 v52, v2

    move-object/from16 v2, v30

    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v52, "$i$a$-Layout-ColumnKt$Column$1\\8\\479\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v28

    const/16 v31, 0x0

    const/16 v32, 0x3

    const/16 v26, 0x0

    const/16 v27, 0x0

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v32}, Landroidx/compose/material3/DividerKt;->HorizontalDivider-9IZ8Weo(Landroidx/compose/ui/Modifier;FJLandroidx/compose/runtime/Composer;II)V

    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v0, "ANSWER \u00b7 \u80cc\u9762"

    move/from16 v1, v20

    invoke-static {v0, v2, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    .line 54
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getBack()Ljava/lang/String;

    move-result-object v26

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v47

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v1, "card-back"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v27

    const/16 v50, 0x0

    const v51, 0x1fffc

    const-wide/16 v28, 0x0

    const/16 v30, 0x0

    const-wide/16 v31, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const/16 v35, 0x0

    const-wide/16 v36, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const-wide/16 v40, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v46, 0x0

    const/16 v49, 0x30

    move-object/from16 v48, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v48, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v51}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 55
    .end local v48    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getExample()Ljava/lang/String;

    move-result-object v0

    check-cast v0, Ljava/lang/CharSequence;

    invoke-static {v0}, Lkotlin/text/StringsKt;->isBlank(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_20e

    const v0, 0x6bb71574

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "54@4409L11,54@4437L173,54@4349L261"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/16 v0, 0x10

    .local v0, "$this$dp\\10":I
    const/4 v1, 0x0

    .line 480
    .local v1, "$i$f$getDp\\10\\55":I
    move/from16 v20, v1

    .end local v1    # "$i$f$getDp\\10\\55":I
    .local v20, "$i$f$getDp\\10\\55":I
    int-to-float v1, v0

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 55
    .end local v0    # "$this$dp\\10":I
    .end local v20    # "$i$f$getDp\\10\\55":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    move-object/from16 v27, v0

    check-cast v27, Landroidx/compose/ui/graphics/Shape;

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getSurfaceVariant-0d7_KjU()J

    move-result-wide v28

    new-instance v0, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda3;

    move-object/from16 v1, p0

    invoke-direct {v0, v1}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt$$ExternalSyntheticLambda3;-><init>(Lcom/xunji/core/model/CardCandidate;)V

    const/16 v1, 0x36

    move/from16 v20, v3

    .end local v3    # "$changed\\9":I
    .local v20, "$changed\\9":I
    const v3, -0x1091f1c5

    move-object/from16 v39, v4

    .end local v4    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v39, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x1

    invoke-static {v3, v4, v0, v2, v1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object/from16 v35, v0

    check-cast v35, Lkotlin/jvm/functions/Function2;

    const/high16 v37, 0xc00000

    const/16 v38, 0x79

    const/16 v26, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    move-object/from16 v36, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v36, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v38}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    .end local v36    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    goto :goto_218

    .end local v20    # "$changed\\9":I
    .end local v39    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$changed\\9":I
    .restart local v4    # "$composer\\2":Landroidx/compose/runtime/Composer;
    :cond_20e
    move/from16 v20, v3

    move-object/from16 v39, v4

    .end local v3    # "$changed\\9":I
    .end local v4    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v20    # "$changed\\9":I
    .restart local v39    # "$composer\\2":Landroidx/compose/runtime/Composer;
    const v0, 0x6b7524dd

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_218
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 53
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 56
    nop

    .line 450
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v20    # "$changed\\9":I
    .end local v21    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1$1$1\\9\\450\\0":I
    .end local v23    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 479
    .end local v19    # "$changed\\8":I
    .end local v24    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-Layout-ColumnKt$Column$1\\8\\479\\2":I
    nop

    .line 481
    invoke-interface/range {v39 .. v39}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 459
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 482
    nop

    .line 453
    .end local v16    # "$i$f$ReusableComposeNode\\4\\457":I
    .end local v18    # "$changed\\4":I
    .end local v22    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 483
    nop

    .line 442
    .end local v10    # "$changed\\3":I
    .end local v11    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v12    # "$i$f$Layout\\3\\449":I
    .end local v13    # "compositeKeyHash\\3":I
    .end local v14    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v39 .. v39}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 484
    nop

    .end local v6    # "$i$f$Column\\2\\52":I
    .end local v7    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v8    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v9    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v17    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v25    # "$changed\\2":I
    .end local v39    # "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_23b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 57
    :cond_23b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ReviewScreen$lambda$1$3$1$0$0$0$0(Lcom/xunji/core/model/CardCandidate;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 55
    .param p0, "$candidate"    # Lcom/xunji/core/model/CardCandidate;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C54@4439L169:ReviewScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq v2, v3, :cond_11

    const/4 v2, 0x1

    goto :goto_12

    :cond_11
    move v2, v4

    :goto_12
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1b5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.ReviewScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (ReviewScreen.kt:54)"

    const v5, -0x1091f1c5

    invoke-static {v5, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 55
    :cond_29
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x10

    .local v3, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 480
    .local v5, "$i$f$getDp\\1\\55":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 55
    .end local v3    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\55":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v5, 0x8

    .local v5, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 480
    .local v6, "$i$f$getDp\\2\\55":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 55
    .end local v5    # "$this$dp\\2":I
    .end local v6    # "$i$f$getDp\\2\\55":I
    invoke-virtual {v3, v5}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v3, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v5, 0x36

    .local v5, "$changed\\3":I
    move-object/from16 v6, p1

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v6, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 485
    .local v7, "$i$f$Column\\3\\55":I
    const v8, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 486
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 489
    .local v8, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v3, v8, v6, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 493
    .local v9, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 490
    nop

    .local v10, "$changed\\4":I
    move-object v11, v2

    .local v11, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    .line 494
    .local v12, "$i$f$Layout\\4\\490":I
    const v13, -0x451e1427

    const-string v14, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 495
    invoke-static {v6, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 496
    .local v4, "compositeKeyHash\\4":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 497
    .local v13, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 499
    .local v14, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v10, 0x6

    and-int/lit16 v0, v0, 0x380

    move/from16 v16, v0

    const/4 v0, 0x6

    or-int/lit8 v16, v16, 0x6

    .line 498
    nop

    .local v15, "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v16, "$changed\\5":I
    const/16 v17, 0x0

    .line 500
    .local v17, "$i$f$ReusableComposeNode\\5\\498":I
    move/from16 v18, v0

    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 501
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_af

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 502
    :cond_af
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 503
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_bc

    .line 504
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bf

    .line 506
    :cond_bc
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 508
    :goto_bf
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 509
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\508\\4":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v20, v1

    .end local v1    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\508\\4":I
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\508\\4":I
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 510
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 511
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 512
    .local v19, "$i$f$set-impl\\7\\511":I
    move-object/from16 v21, v0

    .local v21, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 513
    .local v22, "$i$a$-with-Updater$set$1\\8\\512\\7":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_100

    move-object/from16 v23, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v23, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v24, v3

    .end local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v24, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_fd

    goto :goto_104

    :cond_fd
    move-object/from16 v3, v21

    goto :goto_114

    .end local v23    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v24    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_100
    move-object/from16 v23, v2

    move-object/from16 v24, v3

    .line 514
    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v23    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v24    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_104
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 515
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 517
    :goto_114
    nop

    .line 512
    .end local v3    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\8\\512\\7":I
    nop

    .line 517
    nop

    .line 518
    .end local v1    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\7\\511":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 519
    nop

    .line 508
    .end local v0    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\508\\4":I
    nop

    .line 520
    shr-int/lit8 v0, v16, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v1, v6

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 491
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\9\\520\\3":I
    const v3, 0x7cc0ae6e

    move/from16 v19, v0

    .end local v0    # "$changed\\9":I
    .local v19, "$changed\\9":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v5, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v47, v1

    .local v47, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 55
    .local v20, "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1$1$1$1$1\\10\\491\\0":I
    move-object/from16 v21, v0

    .end local v0    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .local v21, "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x5afde078

    move-object/from16 v22, v1

    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v1, "C54@4520L16,54@4585L10,54@4537L69:ReviewScreen.kt#i35lj1"

    move/from16 v51, v2

    move-object/from16 v2, v47

    .end local v47    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v51, "$i$a$-Layout-ColumnKt$Column$1\\9\\520\\3":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const-string v0, "\u653e\u8fdb\u53e5\u5b50\u91cc"

    move/from16 v1, v18

    invoke-static {v0, v2, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/CardCandidate;->getCard()Lcom/xunji/core/model/Flashcard;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Flashcard;->getExample()Ljava/lang/String;

    move-result-object v25

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v46

    const/16 v49, 0x0

    const v50, 0x1fffe

    const/16 v26, 0x0

    const-wide/16 v27, 0x0

    const/16 v29, 0x0

    const-wide/16 v30, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const/16 v34, 0x0

    const-wide/16 v35, 0x0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const-wide/16 v39, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v48, 0x0

    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v47    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v25 .. v50}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 491
    .end local v3    # "$changed\\10":I
    .end local v20    # "$i$a$-Column-ReviewScreenKt$ReviewScreen$2$4$2$1$1$1$1$1\\10\\491\\0":I
    .end local v21    # "$this$ReviewScreen_u24lambda_u241_u243_u241_u240_u240_u240_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v47    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 520
    .end local v19    # "$changed\\9":I
    .end local v22    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-Layout-ColumnKt$Column$1\\9\\520\\3":I
    nop

    .line 521
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 500
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 522
    nop

    .line 494
    .end local v15    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v16    # "$changed\\5":I
    .end local v17    # "$i$f$ReusableComposeNode\\5\\498":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 523
    nop

    .line 485
    .end local v4    # "compositeKeyHash\\4":I
    .end local v10    # "$changed\\4":I
    .end local v11    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v12    # "$i$f$Layout\\4\\490":I
    .end local v13    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 524
    nop

    .end local v5    # "$changed\\3":I
    .end local v6    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$Column\\3\\55":I
    .end local v8    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v9    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v24    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1b8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1b8

    .line 55
    :cond_1b5
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1b8
    :goto_1b8
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ReviewScreen$lambda$1$3$2$0(Lkotlin/jvm/functions/Function1;Lcom/xunji/flashcards/ui/ReviewUiState$Answer;)Lkotlin/Unit;
    .registers 3
    .param p0, "$onGrade"    # Lkotlin/jvm/functions/Function1;
    .param p1, "$answer"    # Lcom/xunji/flashcards/ui/ReviewUiState$Answer;

    .line 64
    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/ReviewUiState$Answer;->getRetryRating()Lcom/xunji/core/model/Rating;

    move-result-object v0

    invoke-interface {p0, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final ReviewScreen$lambda$2(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 24

    or-int/lit8 v0, p8, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v10

    move-object v1, p0

    move v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object/from16 v5, p4

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move/from16 v11, p9

    move-object/from16 v9, p10

    invoke-static/range {v1 .. v11}, Lcom/xunji/flashcards/ui/screens/ReviewScreenKt;->ReviewScreen(Lcom/xunji/flashcards/ui/ReviewUiState;ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

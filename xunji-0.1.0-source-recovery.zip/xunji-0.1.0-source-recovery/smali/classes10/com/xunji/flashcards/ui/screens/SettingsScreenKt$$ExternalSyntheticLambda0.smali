.class public final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/SettingsViewModel;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/SettingsUiState;

.field public final synthetic f$2:Lcom/xunji/core/model/ThemeMode;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$1:Lcom/xunji/flashcards/ui/SettingsUiState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$2:Lcom/xunji/core/model/ThemeMode;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$1:Lcom/xunji/flashcards/ui/SettingsUiState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;->f$2:Lcom/xunji/core/model/ThemeMode;

    invoke-static {v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->$r8$lambda$D5TiVVHTnbS9Cx_yiAsC5pq8uW0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

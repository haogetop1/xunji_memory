.class public final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/SettingsUiState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/SettingsUiState;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda18;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda18;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    invoke-static {v0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->$r8$lambda$g4tYkeOZowLgjBDM6Q2uIy33PYw(Lcom/xunji/flashcards/ui/SettingsUiState;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

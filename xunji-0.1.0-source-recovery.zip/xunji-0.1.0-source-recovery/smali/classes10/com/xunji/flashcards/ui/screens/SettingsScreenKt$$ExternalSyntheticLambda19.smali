.class public final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$4:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .registers 8

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$3:Landroidx/compose/runtime/MutableState;

    iput-object p5, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$4:Lkotlin/jvm/functions/Function0;

    iput-object p6, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$5:Lkotlin/jvm/functions/Function0;

    iput-object p7, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$6:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$3:Landroidx/compose/runtime/MutableState;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$4:Lkotlin/jvm/functions/Function0;

    iget-object v5, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$5:Lkotlin/jvm/functions/Function0;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;->f$6:Lkotlin/jvm/functions/Function0;

    move-object v7, p1

    check-cast v7, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->$r8$lambda$KTJctTBufZ0pENPNh-tSii9EC1c(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

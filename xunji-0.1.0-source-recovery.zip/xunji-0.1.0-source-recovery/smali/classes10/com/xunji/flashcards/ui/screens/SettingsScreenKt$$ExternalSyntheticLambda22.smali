.class public final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/backup/PreparedBackup;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/SettingsUiState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;->f$0:Lcom/xunji/flashcards/backup/PreparedBackup;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;->f$1:Lcom/xunji/flashcards/ui/SettingsUiState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;->f$0:Lcom/xunji/flashcards/backup/PreparedBackup;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;->f$1:Lcom/xunji/flashcards/ui/SettingsUiState;

    check-cast p1, Landroidx/compose/runtime/Composer;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    invoke-static {v0, v1, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->$r8$lambda$iSs9U6jtGAkPLUX1uRZXqW1xlA8(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

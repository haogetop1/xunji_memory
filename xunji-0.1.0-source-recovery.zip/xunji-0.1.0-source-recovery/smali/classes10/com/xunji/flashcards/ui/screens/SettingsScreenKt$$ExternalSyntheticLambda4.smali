.class public final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/SettingsUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$2:Lcom/xunji/flashcards/ui/SettingsViewModel;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;->f$3:Landroidx/compose/runtime/MutableState;

    move-object v4, p1

    check-cast v4, Landroidx/compose/foundation/lazy/LazyItemScope;

    move-object v5, p2

    check-cast v5, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result v6

    invoke-static/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->$r8$lambda$ItqZp0KZP7L3kbCdy5XFmTV2Q4M(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class final synthetic Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$4$1$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "SettingsScreen.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1018
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/jvm/internal/FunctionReferenceImpl;",
        "Lkotlin/jvm/functions/Function0<",
        "Lkotlin/Unit;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method constructor <init>(Ljava/lang/Object;)V
    .registers 9

    const-class v3, Lcom/xunji/flashcards/ui/SettingsViewModel;

    const-string v5, "confirmRestore()V"

    const/4 v6, 0x0

    const/4 v1, 0x0

    const-string v4, "confirmRestore"

    move-object v0, p0

    move-object v2, p1

    invoke-direct/range {v0 .. v6}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public bridge synthetic invoke()Ljava/lang/Object;
    .registers 2

    .line 50
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$4$1$1;->invoke()V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public final invoke()V
    .registers 2

    .line 50
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$4$1$1;->receiver:Ljava/lang/Object;

    check-cast v0, Lcom/xunji/flashcards/ui/SettingsViewModel;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/SettingsViewModel;->confirmRestore()V

    return-void
.end method

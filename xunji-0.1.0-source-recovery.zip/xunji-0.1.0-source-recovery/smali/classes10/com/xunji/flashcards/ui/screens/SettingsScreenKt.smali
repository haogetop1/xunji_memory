.class public final Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;
.super Ljava/lang/Object;
.source "SettingsScreen.kt"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$WhenMappings;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nSettingsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SettingsScreen.kt\ncom/xunji/flashcards/ui/screens/SettingsScreenKt\n+ 2 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 3 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 4 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 5 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 6 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 7 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 8 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 9 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,52:1\n1282#2,6:53\n1282#2,6:59\n1282#2,6:65\n1282#2,6:72\n1282#2,6:78\n1282#2,6:91\n1282#2,6:97\n1282#2,6:105\n1282#2,6:114\n113#3:71\n113#3:90\n113#3:103\n113#3:112\n113#3:113\n113#3:120\n85#4:84\n117#4,2:85\n85#4:87\n117#4,2:88\n1869#5:104\n1870#5:111\n87#6:121\n83#6,10:122\n94#6:162\n80#7,6:132\n87#7,3:147\n90#7,2:156\n94#7:161\n391#8,9:138\n400#8,3:158\n4360#9,6:150\n*S KotlinDebug\n*F\n+ 1 SettingsScreen.kt\ncom/xunji/flashcards/ui/screens/SettingsScreenKt\n*L\n20#1:53,6\n21#1:59,6\n22#1:65,6\n23#1:72,6\n50#1:78,6\n29#1:91,6\n30#1:97,6\n34#1:105,6\n50#1:114,6\n23#1:71\n29#1:90\n34#1:103\n39#1:112\n45#1:113\n50#1:120\n20#1:84\n20#1:85,2\n21#1:87\n21#1:88,2\n34#1:104\n34#1:111\n50#1:121\n50#1:122,10\n50#1:162\n50#1:132,6\n50#1:147,3\n50#1:156,2\n50#1:161\n50#1:138,9\n50#1:158,3\n50#1:150,6\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000&\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\u001aG\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u0004\u001a\u00020\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\u0008\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00072\u000c\u0010\t\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0007H\u0007\u00a2\u0006\u0002\u0010\n\u00a8\u0006\u000b\u00b2\u0006\n\u0010\u000c\u001a\u00020\rX\u008a\u008e\u0002\u00b2\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002"
    }
    d2 = {
        "SettingsScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/SettingsUiState;",
        "viewModel",
        "Lcom/xunji/flashcards/ui/SettingsViewModel;",
        "onExport",
        "Lkotlin/Function0;",
        "onImport",
        "onAnkiImport",
        "(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "app_debug",
        "limit",
        "",
        "limitError",
        ""
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$5mL3TGT8a55zPFQUUxlKl4CUJ2E(Lcom/xunji/core/model/ThemeMode;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$3$0$0$0$1(Lcom/xunji/core/model/ThemeMode;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8RyFQ7sTs7spUAFvfuIoxfCWSFo(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$5(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$8UBuv2H1NYpkO1WOdJLC3XrM1e4(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$5$0(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9fSne8AA32mN7UAhd9tiBzwX2Pg(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$4$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$D5TiVVHTnbS9Cx_yiAsC5pq8uW0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$3$0$0$0$0$0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$G7R3pja0R_U-4bXCKuTbXpW7Wv0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$1(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ItqZp0KZP7L3kbCdy5XFmTV2Q4M(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$2(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KTJctTBufZ0pENPNh-tSii9EC1c(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TemDcXXw5HD5yZbm1bqSOUOQTzU(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$3(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TjlfDwzzcU2P0rs3ttQQGGHBiKw(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$4(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$XSl8M7W1RGsbCxpVtFDDdufqs2I(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$10(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Y844gpFxhzvj-e8Yp4WvNSlCmVU(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$12(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ayNV-g5IyLuENcZcCXx42DWdSqs(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$9(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dkS6EfIYWmfAVBVi725DXsBADzo(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$3$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g4tYkeOZowLgjBDM6Q2uIy33PYw(Lcom/xunji/flashcards/ui/SettingsUiState;)Landroidx/compose/runtime/MutableState;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;)Landroidx/compose/runtime/MutableState;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$iSs9U6jtGAkPLUX1uRZXqW1xlA8(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$11(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jWJzE73aRb0U1LtGbaLX8XZHkUA(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$2$0$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$m5hBXOBNQXx8opj70R21Tl5aKHY(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$vLjCgPXCNCxp8KMdnUWj5r3NGSk(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$2$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wzPueknDDu6RiRm0YREGldIrUDo(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$3$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$yFh6F-o0JjFFnlvk_5pecvjRpL4(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$2$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ybczbzBfONmarOUtSWhq97CbjBk(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$9$1(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$zhN_rhBCNrG0JGEo6IHrBWdKPzs(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$7$0$2$0$2$0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final SettingsScreen(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 40
    .param p0, "state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p2, "onExport"    # Lkotlin/jvm/functions/Function0;
    .param p3, "onImport"    # Lkotlin/jvm/functions/Function0;
    .param p4, "onAnkiImport"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/SettingsUiState;",
            "Lcom/xunji/flashcards/ui/SettingsViewModel;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move/from16 v8, p6

    const-string v0, "state"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "viewModel"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onExport"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onImport"

    invoke-static {v4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "onAnkiImport"

    invoke-static {v5, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    const v0, -0x550494ec

    move-object/from16 v6, p5

    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v9

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    const-string v6, "C(SettingsScreen)N(state,viewModel,onExport,onImport,onAnkiImport)19@857L60,19@840L77,20@937L34,21@1019L50,21@973L96,22@1221L2425,22@1071L2575:SettingsScreen.kt#i35lj1"

    invoke-static {v9, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v6, p6

    .local v6, "$dirty":I
    and-int/lit8 v7, v8, 0x6

    const/4 v11, 0x4

    if-nez v7, :cond_4d

    and-int/lit8 v7, v8, 0x8

    if-nez v7, :cond_43

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    goto :goto_47

    :cond_43
    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    :goto_47
    if-eqz v7, :cond_4b

    move v7, v11

    goto :goto_4c

    :cond_4b
    const/4 v7, 0x2

    :goto_4c
    or-int/2addr v6, v7

    :cond_4d
    and-int/lit8 v7, v8, 0x30

    if-nez v7, :cond_66

    and-int/lit8 v7, v8, 0x40

    if-nez v7, :cond_5a

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    goto :goto_5e

    :cond_5a
    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    :goto_5e
    if-eqz v7, :cond_63

    const/16 v7, 0x20

    goto :goto_65

    :cond_63
    const/16 v7, 0x10

    :goto_65
    or-int/2addr v6, v7

    :cond_66
    and-int/lit16 v7, v8, 0x180

    if-nez v7, :cond_76

    invoke-interface {v9, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_73

    const/16 v7, 0x100

    goto :goto_75

    :cond_73
    const/16 v7, 0x80

    :goto_75
    or-int/2addr v6, v7

    :cond_76
    and-int/lit16 v7, v8, 0xc00

    if-nez v7, :cond_86

    invoke-interface {v9, v4}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_83

    const/16 v7, 0x800

    goto :goto_85

    :cond_83
    const/16 v7, 0x400

    :goto_85
    or-int/2addr v6, v7

    :cond_86
    and-int/lit16 v7, v8, 0x6000

    if-nez v7, :cond_96

    invoke-interface {v9, v5}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_93

    const/16 v7, 0x4000

    goto :goto_95

    :cond_93
    const/16 v7, 0x2000

    :goto_95
    or-int/2addr v6, v7

    :cond_96
    and-int/lit16 v7, v6, 0x2493

    const/16 v15, 0x2492

    const/4 v14, 0x0

    if-eq v7, v15, :cond_9f

    const/4 v7, 0x1

    goto :goto_a0

    :cond_9f
    move v7, v14

    :goto_a0
    and-int/lit8 v15, v6, 0x1

    invoke-interface {v9, v7, v15}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_34c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_b4

    const/4 v7, -0x1

    const-string v15, "com.xunji.flashcards.ui.screens.SettingsScreen (SettingsScreen.kt:18)"

    invoke-static {v0, v6, v7, v15}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_b4
    new-array v0, v14, [Ljava/lang/Object;

    .line 20
    const v7, -0x2632f590

    const-string v15, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v9, v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v7, v6, 0xe

    if-eq v7, v11, :cond_cf

    and-int/lit8 v7, v6, 0x8

    if-eqz v7, :cond_cd

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_cd

    goto :goto_cf

    :cond_cd
    move v7, v14

    goto :goto_d0

    :cond_cf
    :goto_cf
    const/4 v7, 0x1

    .local v7, "invalid\\1":Z
    :goto_d0
    move-object/from16 v18, v9

    .local v18, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 53
    .local v19, "$i$f$cache\\1\\20":I
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v12

    .local v12, "it\\1":Ljava/lang/Object;
    const/16 v21, 0x0

    .line 54
    .local v21, "$i$a$-let-ComposerKt$cache$1\\2\\53\\1":I
    if-nez v7, :cond_e8

    sget-object v22, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v12, v13, :cond_e5

    goto :goto_e8

    .line 58
    :cond_e5
    move-object/from16 v13, v18

    goto :goto_f5

    .line 55
    :cond_e8
    :goto_e8
    const/4 v13, 0x0

    .line 20
    .local v13, "$i$a$-cache-SettingsScreenKt$SettingsScreen$limit$2\\3\\55\\0":I
    new-instance v11, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda18;

    invoke-direct {v11, v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda18;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;)V

    .line 55
    .end local v13    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$limit$2\\3\\55\\0":I
    nop

    .line 56
    .local v11, "value\\2":Ljava/lang/Object;
    move-object/from16 v13, v18

    .end local v18    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .local v13, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    invoke-interface {v13, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 57
    move-object v12, v11

    .line 53
    .end local v11    # "value\\2":Ljava/lang/Object;
    .end local v12    # "it\\1":Ljava/lang/Object;
    .end local v21    # "$i$a$-let-ComposerKt$cache$1\\2\\53\\1":I
    :goto_f5
    nop

    .line 20
    .end local v7    # "invalid\\1":Z
    .end local v13    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$f$cache\\1\\20":I
    check-cast v12, Lkotlin/jvm/functions/Function0;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v12, v9, v14}, Landroidx/compose/runtime/saveable/RememberSaveableKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/compose/runtime/MutableState;

    .line 21
    .local v0, "limit$delegate":Landroidx/compose/runtime/MutableState;
    const v7, -0x2632ebaa

    invoke-static {v9, v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v7, 0x0

    .local v7, "invalid\\4":Z
    move-object v11, v9

    .local v11, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 59
    .local v12, "$i$f$cache\\4\\21":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\4":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 60
    .local v18, "$i$a$-let-ComposerKt$cache$1\\5\\59\\4":I
    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v14

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    const/4 v10, 0x0

    if-ne v13, v14, :cond_12b

    .line 61
    const/4 v14, 0x0

    .line 21
    .local v14, "$i$a$-cache-SettingsScreenKt$SettingsScreen$limitError$2\\6\\61\\0":I
    invoke-static/range {v21 .. v21}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v4, 0x2

    invoke-static {v3, v10, v4, v10}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v3

    .line 61
    .end local v14    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$limitError$2\\6\\61\\0":I
    nop

    .line 62
    .local v3, "value\\5":Ljava/lang/Object;
    invoke-interface {v11, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 63
    move-object v13, v3

    .end local v3    # "value\\5":Ljava/lang/Object;
    goto :goto_12c

    .line 64
    :cond_12b
    nop

    .line 59
    .end local v13    # "it\\4":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\5\\59\\4":I
    :goto_12c
    nop

    .line 21
    .end local v7    # "invalid\\4":Z
    .end local v11    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\4\\21":I
    move-object v4, v13

    check-cast v4, Landroidx/compose/runtime/MutableState;

    .local v4, "limitError$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 22
    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v3

    invoke-virtual {v3}, Lcom/xunji/core/model/AppSettings;->getNewCardsPerDay()I

    move-result v3

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const v7, -0x2632e15a

    invoke-static {v9, v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    and-int/lit8 v11, v6, 0xe

    const/4 v12, 0x4

    if-eq v11, v12, :cond_15c

    and-int/lit8 v11, v6, 0x8

    if-eqz v11, :cond_159

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v11

    if-eqz v11, :cond_159

    goto :goto_15c

    :cond_159
    move/from16 v11, v21

    goto :goto_15d

    :cond_15c
    :goto_15c
    const/4 v11, 0x1

    :goto_15d
    or-int/2addr v7, v11

    .local v7, "invalid\\7":Z
    move-object v11, v9

    .local v11, "$this$cache\\7":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    .line 65
    .local v12, "$i$f$cache\\7\\22":I
    invoke-interface {v11}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v13

    .local v13, "it\\7":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 66
    .local v14, "$i$a$-let-ComposerKt$cache$1\\8\\65\\7":I
    if-nez v7, :cond_173

    sget-object v18, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v10

    if-ne v13, v10, :cond_170

    goto :goto_173

    .line 70
    :cond_170
    move-object/from16 v18, v4

    goto :goto_183

    .line 67
    :cond_173
    :goto_173
    const/4 v10, 0x0

    .line 22
    .local v10, "$i$a$-cache-SettingsScreenKt$SettingsScreen$1\\9\\67\\0":I
    move-object/from16 v18, v4

    .end local v4    # "limitError$delegate":Landroidx/compose/runtime/MutableState;
    .local v18, "limitError$delegate":Landroidx/compose/runtime/MutableState;
    new-instance v4, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$1$1;

    const/4 v5, 0x0

    invoke-direct {v4, v1, v0, v5}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$1$1;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;)V

    check-cast v4, Lkotlin/jvm/functions/Function2;

    .line 67
    .end local v10    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$1\\9\\67\\0":I
    nop

    .line 68
    .local v4, "value\\8":Ljava/lang/Object;
    invoke-interface {v11, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 69
    move-object v13, v4

    .line 65
    .end local v4    # "value\\8":Ljava/lang/Object;
    .end local v13    # "it\\7":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\8\\65\\7":I
    :goto_183
    nop

    .line 22
    .end local v7    # "invalid\\7":Z
    .end local v11    # "$this$cache\\7":Landroidx/compose/runtime/Composer;
    .end local v12    # "$i$f$cache\\7\\22":I
    check-cast v13, Lkotlin/jvm/functions/Function2;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move/from16 v10, v21

    invoke-static {v3, v13, v9, v10}, Landroidx/compose/runtime/EffectsKt;->LaunchedEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;I)V

    .line 23
    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v11, 0x1

    invoke-static {v3, v4, v11, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-static {v3}, Landroidx/compose/foundation/layout/WindowInsetsPadding_androidKt;->imePadding(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    const/16 v3, 0x16

    .local v3, "$this$dp\\10":I
    const/4 v4, 0x0

    .line 71
    .local v4, "$i$f$getDp\\10\\23":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 23
    .end local v3    # "$this$dp\\10":I
    .end local v4    # "$i$f$getDp\\10\\23":I
    const/16 v4, 0x12

    .local v4, "$this$dp\\11":I
    const/4 v5, 0x0

    .line 71
    .local v5, "$i$f$getDp\\11\\23":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 23
    .end local v4    # "$this$dp\\11":I
    .end local v5    # "$i$f$getDp\\11\\23":I
    const/16 v5, 0x16

    .local v5, "$this$dp\\12":I
    const/4 v7, 0x0

    .line 71
    .local v7, "$i$f$getDp\\12\\23":I
    int-to-float v13, v5

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 23
    .end local v5    # "$this$dp\\12":I
    .end local v7    # "$i$f$getDp\\12\\23":I
    const/16 v7, 0x1c

    .local v7, "$this$dp\\13":I
    const/4 v13, 0x0

    .line 71
    .local v13, "$i$f$getDp\\13\\23":I
    int-to-float v14, v7

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 23
    .end local v7    # "$this$dp\\13":I
    .end local v13    # "$i$f$getDp\\13\\23":I
    invoke-static {v3, v4, v5, v7}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v13

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v4, 0x16

    .local v4, "$this$dp\\14":I
    const/4 v5, 0x0

    .line 71
    .local v5, "$i$f$getDp\\14\\23":I
    int-to-float v7, v4

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 23
    .end local v4    # "$this$dp\\14":I
    .end local v5    # "$i$f$getDp\\14\\23":I
    invoke-virtual {v3, v4}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    move-object v14, v3

    check-cast v14, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    const v3, -0x2632bed3

    invoke-static {v9, v3, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v3, v6, 0xe

    const/4 v4, 0x4

    if-eq v3, v4, :cond_1ea

    and-int/lit8 v3, v6, 0x8

    if-eqz v3, :cond_1e8

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_1e8

    goto :goto_1ea

    :cond_1e8
    move v3, v10

    goto :goto_1eb

    :cond_1ea
    :goto_1ea
    move v3, v11

    :goto_1eb
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v3, v4

    and-int/lit8 v4, v6, 0x70

    const/16 v5, 0x20

    if-eq v4, v5, :cond_203

    and-int/lit8 v4, v6, 0x40

    if-eqz v4, :cond_201

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_201

    goto :goto_203

    :cond_201
    move v4, v10

    goto :goto_204

    :cond_203
    :goto_203
    move v4, v11

    :goto_204
    or-int/2addr v3, v4

    and-int/lit16 v4, v6, 0x380

    const/16 v7, 0x100

    if-ne v4, v7, :cond_20d

    move v4, v11

    goto :goto_20e

    :cond_20d
    move v4, v10

    :goto_20e
    or-int/2addr v3, v4

    and-int/lit16 v4, v6, 0x1c00

    const/16 v7, 0x800

    if-ne v4, v7, :cond_217

    move v4, v11

    goto :goto_218

    :cond_217
    move v4, v10

    :goto_218
    or-int/2addr v3, v4

    const v4, 0xe000

    and-int/2addr v4, v6

    const/16 v7, 0x4000

    if-ne v4, v7, :cond_223

    move v4, v11

    goto :goto_224

    :cond_223
    move v4, v10

    :goto_224
    or-int v16, v3, v4

    .local v16, "invalid\\15":Z
    move-object v3, v9

    .local v3, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 72
    .local v17, "$i$f$cache\\15\\23":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\15":Ljava/lang/Object;
    const/16 v19, 0x0

    .line 73
    .local v19, "$i$a$-let-ComposerKt$cache$1\\16\\72\\15":I
    if-nez v16, :cond_243

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_23a

    goto :goto_243

    .line 77
    :cond_23a
    move-object v10, v3

    move-object v3, v4

    move/from16 v22, v5

    move/from16 v31, v6

    move-object/from16 v4, v18

    goto :goto_267

    .line 74
    :cond_243
    :goto_243
    const/16 v20, 0x0

    .line 23
    .local v20, "$i$a$-cache-SettingsScreenKt$SettingsScreen$2\\17\\74\\0":I
    move-object v2, v0

    .end local v0    # "limit$delegate":Landroidx/compose/runtime/MutableState;
    .local v2, "limit$delegate":Landroidx/compose/runtime/MutableState;
    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;

    move-object/from16 v7, v18

    move-object/from16 v18, v4

    move-object v4, v7

    move-object/from16 v7, p4

    move-object v10, v3

    move/from16 v22, v5

    move/from16 v31, v6

    move-object/from16 v3, p1

    move-object/from16 v5, p2

    move-object/from16 v6, p3

    .end local v3    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v6    # "$dirty":I
    .local v4, "limitError$delegate":Landroidx/compose/runtime/MutableState;
    .local v10, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .local v18, "it\\15":Ljava/lang/Object;
    .local v31, "$dirty":I
    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda19;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 74
    move-object/from16 v32, v3

    move-object v3, v0

    move-object v0, v2

    move-object/from16 v2, v32

    .line 75
    .end local v2    # "limit$delegate":Landroidx/compose/runtime/MutableState;
    .end local v20    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$2\\17\\74\\0":I
    .restart local v0    # "limit$delegate":Landroidx/compose/runtime/MutableState;
    .local v3, "value\\16":Ljava/lang/Object;
    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 76
    nop

    .line 72
    .end local v3    # "value\\16":Ljava/lang/Object;
    .end local v18    # "it\\15":Ljava/lang/Object;
    .end local v19    # "$i$a$-let-ComposerKt$cache$1\\16\\72\\15":I
    :goto_267
    nop

    .line 23
    .end local v10    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\15":Z
    .end local v17    # "$i$f$cache\\15\\23":I
    move-object/from16 v18, v3

    check-cast v18, Lkotlin/jvm/functions/Function1;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v20, 0x6180

    const/4 v10, 0x0

    const/16 v21, 0x1ea

    move v3, v10

    const/4 v10, 0x0

    move-object/from16 v27, v9

    move-object v9, v12

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .local v27, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v12, 0x0

    move/from16 v23, v11

    move-object v11, v13

    move-object v13, v14

    const/4 v14, 0x0

    move-object v5, v15

    const/4 v15, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    move-object v6, v5

    move/from16 v5, v22

    move/from16 v7, v23

    move-object/from16 v19, v27

    .end local v27    # "$composer":Landroidx/compose/runtime/Composer;
    .local v19, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v21}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 49
    move-object/from16 v10, v19

    .end local v19    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getPrepared()Lcom/xunji/flashcards/backup/PreparedBackup;

    move-result-object v9

    .line 50
    .local v9, "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    if-eqz v9, :cond_338

    const v11, 0x5fff80c0

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v11, "49@3724L24,49@4034L183,49@4232L116,49@3780L239,49@3695L654"

    invoke-static {v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const v11, -0x26318f54

    invoke-static {v10, v11, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v6, v31, 0x70

    if-eq v6, v5, :cond_2b9

    and-int/lit8 v5, v31, 0x40

    if-eqz v5, :cond_2b7

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2b7

    goto :goto_2b9

    :cond_2b7
    move v14, v3

    goto :goto_2ba

    :cond_2b9
    :goto_2b9
    move v14, v7

    .local v14, "invalid\\18":Z
    :goto_2ba
    move-object v3, v10

    .local v3, "$this$cache\\18":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 78
    .local v5, "$i$f$cache\\18\\50":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\18":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 79
    .local v11, "$i$a$-let-ComposerKt$cache$1\\19\\78\\18":I
    if-nez v14, :cond_2cd

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v6, v12, :cond_2cc

    goto :goto_2cd

    .line 83
    :cond_2cc
    goto :goto_2da

    .line 80
    :cond_2cd
    :goto_2cd
    const/4 v12, 0x0

    .line 50
    .local v12, "$i$a$-cache-SettingsScreenKt$SettingsScreen$3\\20\\80\\0":I
    new-instance v13, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$3$1;

    invoke-direct {v13, v2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$3$1;-><init>(Ljava/lang/Object;)V

    check-cast v13, Lkotlin/reflect/KFunction;

    .line 80
    .end local v12    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$3\\20\\80\\0":I
    nop

    .line 81
    .local v13, "value\\19":Ljava/lang/Object;
    invoke-interface {v3, v13}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 82
    move-object v6, v13

    .line 78
    .end local v6    # "it\\18":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\19\\78\\18":I
    .end local v13    # "value\\19":Ljava/lang/Object;
    :goto_2da
    nop

    .line 50
    .end local v3    # "$this$cache\\18":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\18\\50":I
    .end local v14    # "invalid\\18":Z
    check-cast v6, Lkotlin/reflect/KFunction;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    check-cast v6, Lkotlin/jvm/functions/Function0;

    new-instance v3, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda20;

    invoke-direct {v3, v2, v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda20;-><init>(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v5, -0x76a1431f

    const/16 v11, 0x36

    invoke-static {v5, v7, v3, v10, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    check-cast v3, Lkotlin/jvm/functions/Function2;

    new-instance v5, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda21;

    invoke-direct {v5, v2, v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda21;-><init>(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v12, -0x7577169d

    invoke-static {v12, v7, v5, v10, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object v12, v5

    check-cast v12, Lkotlin/jvm/functions/Function2;

    sget-object v5, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v5}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-1951197723$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v14

    new-instance v5, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;

    invoke-direct {v5, v9, v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda22;-><init>(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v13, -0x73b7d3da

    invoke-static {v13, v7, v5, v10, v11}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v5

    move-object v15, v5

    check-cast v15, Lkotlin/jvm/functions/Function2;

    const/16 v29, 0x0

    const/16 v30, 0x3f94

    const/4 v11, 0x0

    const/4 v13, 0x0

    const/16 v16, 0x0

    const-wide/16 v17, 0x0

    const-wide/16 v19, 0x0

    const-wide/16 v21, 0x0

    const-wide/16 v23, 0x0

    const/16 v25, 0x0

    const/16 v26, 0x0

    const v28, 0x1b0c30

    move-object/from16 v27, v10

    move-object v10, v3

    move-object v3, v9

    move-object v9, v6

    .end local v9    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    .restart local v27    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v9 .. v30}, Landroidx/compose/material3/AndroidAlertDialog_androidKt;->AlertDialog-Oix01E0(Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;JJJJFLandroidx/compose/ui/window/DialogProperties;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v10, v27

    .end local v27    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_33f

    .end local v3    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    .restart local v9    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    :cond_338
    move-object v3, v9

    .end local v9    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    .restart local v3    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    const v5, 0x5fc73f8e

    invoke-interface {v10, v5}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_33f
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_352

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v0    # "limit$delegate":Landroidx/compose/runtime/MutableState;
    .end local v3    # "prepared":Lcom/xunji/flashcards/backup/PreparedBackup;
    .end local v4    # "limitError$delegate":Landroidx/compose/runtime/MutableState;
    goto :goto_352

    .line 19
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v31    # "$dirty":I
    .local v6, "$dirty":I
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    :cond_34c
    move/from16 v31, v6

    move-object v10, v9

    .end local v6    # "$dirty":I
    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v31    # "$dirty":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 51
    :cond_352
    :goto_352
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v7

    if-eqz v7, :cond_367

    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda1;

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move v6, v8

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda1;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v7, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_367
    return-void
.end method

.method private static final SettingsScreen$lambda$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;)Landroidx/compose/runtime/MutableState;
    .registers 4
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;

    .line 20
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/AppSettings;->getNewCardsPerDay()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {v0, v1, v2, v1}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    return-object v0
.end method

.method private static final SettingsScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 20
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 84
    .local v3, "$i$f$getValue\\1\\20":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\20":I
    check-cast v0, Ljava/lang/String;

    .line 20
    return-object v0
.end method

.method private static final SettingsScreen$lambda$10(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v10, p2

    move/from16 v13, p3

    const-string v0, "C49@4244L24,49@4233L113:SettingsScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eq v0, v1, :cond_11

    move v0, v2

    goto :goto_12

    :cond_11
    const/4 v0, 0x0

    :goto_12
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_8c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_29

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)"

    const v3, -0x7577169d

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_29
    const v0, 0xbf41e3b

    const-string v1, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v10, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, p0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v0

    .local v0, "invalid\\1":Z
    move-object/from16 v1, p2

    .local v1, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 114
    .local v3, "$i$f$cache\\1\\50":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\1":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 115
    .local v5, "$i$a$-let-ComposerKt$cache$1\\2\\114\\1":I
    if-nez v0, :cond_49

    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_48

    goto :goto_49

    .line 119
    :cond_48
    goto :goto_56

    .line 116
    :cond_49
    :goto_49
    const/4 v6, 0x0

    .line 50
    .local v6, "$i$a$-cache-SettingsScreenKt$SettingsScreen$5$1\\3\\116\\0":I
    new-instance v7, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$5$1$1;

    invoke-direct {v7, p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$5$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v7, Lkotlin/reflect/KFunction;

    .line 116
    .end local v6    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$5$1\\3\\116\\0":I
    nop

    .line 117
    .local v7, "value\\2":Ljava/lang/Object;
    invoke-interface {v1, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    move-object v4, v7

    .line 114
    .end local v4    # "it\\1":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\2\\114\\1":I
    .end local v7    # "value\\2":Ljava/lang/Object;
    :goto_56
    nop

    .line 50
    .end local v0    # "invalid\\1":Z
    .end local v1    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$cache\\1\\50":I
    check-cast v4, Lkotlin/reflect/KFunction;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    xor-int/2addr v2, v0

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const-string v1, "restore-cancel"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    move-object v0, v4

    check-cast v0, Lkotlin/jvm/functions/Function0;

    sget-object v3, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v3}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-607905248$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const v11, 0x30000030

    const/16 v12, 0x1f8

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_8f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_8f

    :cond_8c
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_8f
    :goto_8f
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$11(Lcom/xunji/flashcards/backup/PreparedBackup;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 60
    .param p0, "$prepared"    # Lcom/xunji/flashcards/backup/PreparedBackup;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "C49@3781L237:SettingsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v5, 0x0

    if-eq v2, v3, :cond_11

    const/4 v2, 0x1

    goto :goto_12

    :cond_11
    move v2, v5

    :goto_12
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_203

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)"

    const v6, -0x73b7d3da

    invoke-static {v6, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_29
    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v3, 0xc

    .local v3, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 120
    .local v6, "$i$f$getDp\\1\\50":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 50
    .end local v3    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\50":I
    invoke-virtual {v2, v3}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v2, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v3, 0x30

    .local v3, "$changed\\2":I
    move-object/from16 v6, p2

    .local v6, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 121
    .local v7, "$i$f$Column\\2\\50":I
    const v8, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 122
    sget-object v8, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v8, Landroidx/compose/ui/Modifier;

    .line 124
    .local v8, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v9, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v9}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v9

    .line 127
    .local v9, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v10, v3, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v2, v9, v6, v10}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 131
    .local v10, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v3, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 128
    nop

    .local v11, "$changed\\3":I
    move-object v12, v8

    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 132
    .local v13, "$i$f$Layout\\3\\128":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 133
    invoke-static {v6, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 134
    .local v14, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 135
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 137
    .local v4, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v5, v11, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 136
    move-object/from16 v17, v16

    .local v5, "$changed\\4":I
    .local v17, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 138
    .local v16, "$i$f$ReusableComposeNode\\4\\136":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 139
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_9f

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 140
    :cond_9f
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 141
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_ae

    .line 142
    move-object/from16 v0, v17

    .end local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_b3

    .line 144
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_ae
    move-object/from16 v0, v17

    .end local v17    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 146
    :goto_b3
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 147
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\146\\3":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v19, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 148
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 149
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 150
    .local v18, "$i$f$set-impl\\6\\149":I
    move-object/from16 v20, v1

    .local v20, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 151
    .local v21, "$i$a$-with-Updater$set$1\\7\\150\\6":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_f5

    move-object/from16 v22, v2

    .end local v2    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v22, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v23, v3

    .end local v3    # "$changed\\2":I
    .local v23, "$changed\\2":I
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f2

    goto :goto_f9

    :cond_f2
    move-object/from16 v3, v20

    goto :goto_109

    .end local v22    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v23    # "$changed\\2":I
    .restart local v2    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v3    # "$changed\\2":I
    :cond_f5
    move-object/from16 v22, v2

    move/from16 v23, v3

    .line 152
    .end local v2    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v3    # "$changed\\2":I
    .restart local v22    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v23    # "$changed\\2":I
    :goto_f9
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 153
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 155
    :goto_109
    nop

    .line 150
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\7\\150\\6":I
    nop

    .line 155
    nop

    .line 156
    .end local v0    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\6\\149":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 157
    nop

    .line 146
    .end local v1    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\146\\3":I
    nop

    .line 158
    shr-int/lit8 v0, v5, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v1, v6

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 129
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\8\\158\\2":I
    const v3, 0x7cc0ae6e

    move/from16 v17, v0

    .end local v0    # "$changed\\8":I
    .local v17, "$changed\\8":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v23, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$SettingsScreen_u24lambda_u2411_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v46, v1

    .local v46, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 50
    .local v18, "$i$a$-Column-SettingsScreenKt$SettingsScreen$6$1\\9\\129\\0":I
    move-object/from16 v20, v0

    .end local v0    # "$this$SettingsScreen_u24lambda_u2411_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v20, "$this$SettingsScreen_u24lambda_u2411_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x2aaa99ea

    move-object/from16 v21, v1

    .end local v1    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v21, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v1, "C49@3839L92,49@3932L38:SettingsScreen.kt#i35lj1"

    move/from16 v50, v2

    move-object/from16 v2, v46

    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v50, "$i$a$-Layout-ColumnKt$Column$1\\8\\158\\2":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/backup/PreparedBackup;->getDeckCount()J

    move-result-wide v0

    move/from16 v51, v3

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v3    # "$changed\\9":I
    .restart local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v51, "$changed\\9":I
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/backup/PreparedBackup;->getCardCount()J

    move-result-wide v2

    move-object/from16 v52, v4

    move/from16 v53, v5

    .end local v4    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v5    # "$changed\\4":I
    .local v52, "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v53, "$changed\\4":I
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/backup/PreparedBackup;->getLogCount()J

    move-result-wide v4

    move-object/from16 v54, v6

    .end local v6    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\2":Landroidx/compose/runtime/Composer;
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    move/from16 v55, v7

    .end local v7    # "$i$f$Column\\2\\50":I
    .local v55, "$i$f$Column\\2\\50":I
    const-string v7, "\u5907\u4efd\u5305\u542b "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v6

    invoke-virtual {v6, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u4e2a\u724c\u7ec4\u3001"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5361\u7247\u3001"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u6761\u8bc4\u5206\u8bb0\u5f55\u3002"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v24

    const/16 v48, 0x0

    const v49, 0x3fffe

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v45, 0x0

    const/16 v47, 0x0

    invoke-static/range {v24 .. v49}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    const-string v24, "\u5f53\u524d\u724c\u7ec4\u3001\u5361\u7247\u548c\u8bb0\u5f55\u5c06\u88ab\u66ff\u6362\uff0c\u65e0\u6cd5\u64a4\u56de\u3002\u5efa\u8bae\u5148\u5bfc\u51fa\u5f53\u524d\u6570\u636e\u3002"

    const/16 v47, 0x6

    invoke-static/range {v24 .. v49}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v2, v46

    .end local v46    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getError()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_1da

    const v0, 0x302c1e14

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "49@3992L24"

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getError()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x30

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0, v3, v2, v1, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_1e0

    :cond_1da
    const v0, -0x2ae4cf5a

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_1e0
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 129
    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-Column-SettingsScreenKt$SettingsScreen$6$1\\9\\129\\0":I
    .end local v20    # "$this$SettingsScreen_u24lambda_u2411_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v51    # "$changed\\9":I
    invoke-static/range {v21 .. v21}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 158
    .end local v17    # "$changed\\8":I
    .end local v21    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-ColumnKt$Column$1\\8\\158\\2":I
    nop

    .line 159
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 138
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 160
    nop

    .line 132
    .end local v16    # "$i$f$ReusableComposeNode\\4\\136":I
    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v53    # "$changed\\4":I
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 161
    nop

    .line 121
    .end local v11    # "$changed\\3":I
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\3\\128":I
    .end local v14    # "compositeKeyHash\\3":I
    .end local v15    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v52    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 162
    nop

    .end local v8    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v9    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v23    # "$changed\\2":I
    .end local v54    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$f$Column\\2\\50":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_206

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_206

    .line 50
    :cond_203
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_206
    :goto_206
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$12(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move-object v5, p4

    move-object v6, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final SettingsScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 20
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 85
    .local v4, "$i$f$setValue\\1\\20":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 86
    nop

    .line 20
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\20":I
    return-void
.end method

.method private static final SettingsScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 21
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 87
    .local v3, "$i$f$getValue\\1\\21":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\21":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 21
    return v0
.end method

.method private static final SettingsScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 21
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 88
    .local v4, "$i$f$setValue\\1\\21":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 89
    nop

    .line 21
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\21":I
    return-void
.end method

.method private static final SettingsScreen$lambda$7$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 20
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p3, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$onExport"    # Lkotlin/jvm/functions/Function0;
    .param p5, "$onImport"    # Lkotlin/jvm/functions/Function0;
    .param p6, "$onAnkiImport"    # Lkotlin/jvm/functions/Function0;
    .param p7, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    move-object/from16 v1, p7

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-1037137569$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 25
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getError()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    if-eqz v0, :cond_33

    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v0, p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda2;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v1, 0x2c8f97e4

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 26
    :cond_33
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getMessage()Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_51

    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v0, p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda3;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v1, 0x7a4e48cd

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 27
    :cond_51
    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;

    move-object v8, p3

    invoke-direct {v0, p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;)V

    const v1, 0x23f6c788

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 32
    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v0, p0, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda5;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;)V

    const v1, 0xa7f2927

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 36
    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda6;

    move-object/from16 v9, p4

    move-object/from16 v10, p5

    invoke-direct {v0, p0, v9, v10}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda6;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const v1, -0xef8753a

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 42
    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda7;

    move-object/from16 v11, p6

    invoke-direct {v0, v11, p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda7;-><init>(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v1, -0x2870139b

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    move-object/from16 v1, p7

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 47
    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-1105703420$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 48
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C24@1303L24:SettingsScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_3f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:24)"

    const v4, 0x2c8f97e4

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 25
    :cond_2c
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getError()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x30

    invoke-static {v0, v3, p2, v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_42

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_42

    :cond_3f
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_42
    :goto_42
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$1(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C25@1362L21:SettingsScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    if-eq v0, v1, :cond_13

    const/4 v0, 0x1

    goto :goto_14

    :cond_13
    move v0, v2

    :goto_14
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_3d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2b

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:25)"

    const v3, 0x7a4e48cd

    invoke-static {v3, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 26
    :cond_2b
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    invoke-static {v0, v2, p2, v2, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_40

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_40

    :cond_3d
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_40
    :goto_40
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$2(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 13
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p3, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C26@1426L697,26@1395L728:SettingsScreen.kt#i35lj1"

    invoke-static {p5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p6, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p6, 0x1

    invoke-interface {p5, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:26)"

    const v4, 0x23f6c788

    invoke-static {v4, p6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 27
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda14;

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda14;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;)V

    const v4, -0x27fd09a8

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p5, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p5, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 31
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$2$0(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/runtime/MutableState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 40
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p3, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v9, p5

    move/from16 v4, p6

    const-string v5, "$this$Paper"

    move-object/from16 v6, p4

    invoke-static {v6, v5}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v5, "C27@1464L10,27@1431L55,27@1487L37,28@1552L27,28@1817L62,28@1528L384,29@1939L139,29@1916L203:SettingsScreen.kt#i35lj1"

    invoke-static {v9, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v5, v4, 0x11

    const/16 v7, 0x10

    const/4 v8, 0x0

    const/4 v10, 0x1

    if-eq v5, v7, :cond_20

    move v5, v10

    goto :goto_21

    :cond_20
    move v5, v8

    :goto_21
    and-int/lit8 v7, v4, 0x1

    invoke-interface {v9, v5, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_1c3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_38

    const/4 v5, -0x1

    const-string v7, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:27)"

    const v11, -0x27fd09a8

    invoke-static {v11, v4, v5, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 28
    :cond_38
    sget-object v5, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v5, v9, v7}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v5

    invoke-virtual {v5}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v25

    const/16 v28, 0x0

    const v29, 0x1fffe

    const-string v4, "\u6bcf\u5929\u7684\u65b0\u5361"

    const/4 v5, 0x0

    const-wide/16 v6, 0x0

    move v11, v8

    const/4 v8, 0x0

    move v12, v10

    const-wide/16 v9, 0x0

    move v13, v11

    const/4 v11, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v17, v14

    move/from16 v16, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    move/from16 v21, v19

    const-wide/16 v18, 0x0

    move/from16 v22, v20

    const/16 v20, 0x0

    move/from16 v23, v21

    const/16 v21, 0x0

    move/from16 v24, v22

    const/16 v22, 0x0

    move/from16 v26, v23

    const/16 v23, 0x0

    move/from16 v27, v24

    const/16 v24, 0x0

    move/from16 v30, v27

    const/16 v27, 0x6

    move-object/from16 v26, p5

    move/from16 v0, v30

    invoke-static/range {v4 .. v29}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v9, v26

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v6, "\u6240\u6709\u724c\u7ec4\u5408\u8ba1\u3002\u8bbe\u4e3a 0 \u53ef\u6682\u505c\u65b0\u5361\uff0c\u5230\u671f\u590d\u4e60\u4ecd\u7136\u4fdd\u7559\u3002"

    invoke-static {v6, v0, v9, v4, v5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 29
    invoke-static {v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v4

    new-instance v10, Landroidx/compose/foundation/text/KeyboardOptions;

    sget-object v0, Landroidx/compose/ui/text/input/KeyboardType;->Companion:Landroidx/compose/ui/text/input/KeyboardType$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/text/input/KeyboardType$Companion;->getNumber-PjHm6EE()I

    move-result v13

    const/16 v18, 0x7b

    const/16 v19, 0x0

    const/4 v11, 0x0

    const/4 v14, 0x0

    const/4 v15, 0x0

    invoke-direct/range {v10 .. v19}, Landroidx/compose/foundation/text/KeyboardOptions;-><init>(ILjava/lang/Boolean;IILandroidx/compose/ui/text/input/PlatformImeOptions;Ljava/lang/Boolean;Landroidx/compose/ui/text/intl/LocaleList;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    invoke-static {v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v17

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    const/4 v5, 0x1

    xor-int/lit8 v7, v0, 0x1

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v8, 0x0

    invoke-static {v0, v6, v5, v8}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v6, "new-card-limit"

    invoke-static {v0, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    const/16 v0, 0x10

    .local v0, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 90
    .local v8, "$i$f$getDp\\1\\29":I
    int-to-float v11, v0

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 29
    .end local v0    # "$this$dp\\1":I
    .end local v8    # "$i$f$getDp\\1\\29":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    const v8, -0x1ce12fcd

    const-string v11, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v9, v8, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    .local v8, "invalid\\2":Z
    move-object/from16 v12, p5

    .local v12, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v13, 0x0

    .line 91
    .local v13, "$i$f$cache\\2\\29":I
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\2":Ljava/lang/Object;
    const/4 v15, 0x0

    .line 92
    .local v15, "$i$a$-let-ComposerKt$cache$1\\3\\91\\2":I
    if-nez v8, :cond_f4

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v5

    if-ne v14, v5, :cond_f1

    goto :goto_f4

    .line 96
    :cond_f1
    move-object/from16 v16, v0

    goto :goto_101

    .line 93
    :cond_f4
    :goto_f4
    const/4 v5, 0x0

    .line 29
    .local v5, "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$3$1$1\\4\\93\\0":I
    move-object/from16 v16, v0

    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v0, v1, v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda8;-><init>(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 93
    .end local v5    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$3$1$1\\4\\93\\0":I
    nop

    .line 94
    .local v0, "value\\3":Ljava/lang/Object;
    invoke-interface {v12, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 95
    move-object v14, v0

    .line 91
    .end local v0    # "value\\3":Ljava/lang/Object;
    .end local v14    # "it\\2":Ljava/lang/Object;
    .end local v15    # "$i$a$-let-ComposerKt$cache$1\\3\\91\\2":I
    :goto_101
    nop

    .line 29
    .end local v8    # "invalid\\2":Z
    .end local v12    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v13    # "$i$f$cache\\2\\29":I
    move-object v5, v14

    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-1235225230$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    sget-object v8, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v8}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$164190816$app_debug()Lkotlin/jvm/functions/Function2;

    move-result-object v15

    new-instance v8, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda9;

    invoke-direct {v8, v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda9;-><init>(Landroidx/compose/runtime/MutableState;)V

    const/16 v12, 0x36

    const v13, 0x3cd8cbff

    const/4 v14, 0x1

    invoke-static {v13, v14, v8, v9, v12}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function2;

    move-object/from16 v25, v16

    check-cast v25, Landroidx/compose/ui/graphics/Shape;

    const/16 v30, 0x0

    const v31, 0x5d47b0

    move-object/from16 v16, v8

    const/4 v8, 0x0

    const/4 v9, 0x0

    move-object v12, v11

    const/4 v11, 0x0

    move-object v13, v12

    const/4 v12, 0x0

    move-object/from16 v18, v13

    const/4 v13, 0x0

    move/from16 v19, v14

    const/4 v14, 0x0

    move-object/from16 v20, v18

    const/16 v18, 0x0

    move-object/from16 v21, v20

    const/16 v20, 0x0

    move-object/from16 v22, v21

    const/16 v21, 0x1

    move-object/from16 v23, v22

    const/16 v22, 0x0

    move-object/from16 v24, v23

    const/16 v23, 0x0

    move-object/from16 v26, v24

    const/16 v24, 0x0

    move-object/from16 v27, v26

    const/16 v26, 0x0

    const v28, 0x180180

    const v29, 0xc301b0

    move/from16 v32, v19

    move-object/from16 v19, v10

    move-object v10, v0

    move-object/from16 v0, v27

    move-object/from16 v27, p5

    invoke-static/range {v4 .. v31}, Landroidx/compose/material3/OutlinedTextFieldKt;->OutlinedTextField(Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;ZZLandroidx/compose/ui/text/TextStyle;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;ZLandroidx/compose/ui/text/input/VisualTransformation;Landroidx/compose/foundation/text/KeyboardOptions;Landroidx/compose/foundation/text/KeyboardActions;ZIILandroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/TextFieldColors;Landroidx/compose/runtime/Composer;IIII)V

    .line 30
    move-object/from16 v9, v27

    const v4, -0x1ce0fefd

    invoke-static {v9, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v0

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v0, v4

    move-object/from16 v12, p0

    invoke-interface {v9, v12}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    or-int/2addr v0, v4

    .local v0, "invalid\\5":Z
    move-object/from16 v4, p5

    .local v4, "$this$cache\\5":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 97
    .local v5, "$i$f$cache\\5\\30":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\5":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 98
    .local v7, "$i$a$-let-ComposerKt$cache$1\\6\\97\\5":I
    if-nez v0, :cond_196

    sget-object v8, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v8}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v8

    if-ne v6, v8, :cond_195

    goto :goto_196

    .line 102
    :cond_195
    goto :goto_1a1

    .line 99
    :cond_196
    :goto_196
    const/4 v8, 0x0

    .line 30
    .local v8, "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$3$1$3\\7\\99\\0":I
    new-instance v10, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda10;

    invoke-direct {v10, v2, v12, v1, v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda10;-><init>(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 99
    .end local v8    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$3$1$3\\7\\99\\0":I
    nop

    .line 100
    .local v10, "value\\6":Ljava/lang/Object;
    invoke-interface {v4, v10}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 101
    move-object v6, v10

    .line 97
    .end local v6    # "it\\5":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\6\\97\\5":I
    .end local v10    # "value\\6":Ljava/lang/Object;
    :goto_1a1
    nop

    .line 30
    .end local v0    # "invalid\\5":Z
    .end local v4    # "$this$cache\\5":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$cache\\5\\30":I
    move-object v5, v6

    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual {v12}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    xor-int/lit8 v7, v0, 0x1

    const/16 v10, 0x6006

    const/4 v11, 0x4

    const-string v4, "\u4fdd\u5b58\u5b66\u4e60\u8bbe\u7f6e"

    const/4 v6, 0x0

    const-string v8, "save-settings"

    invoke-static/range {v4 .. v11}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1c8

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1c8

    .line 27
    :cond_1c3
    move-object/from16 v12, p0

    invoke-interface/range {p5 .. p5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 31
    :cond_1c8
    :goto_1c8
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$2$0$0$0(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 4
    .param p0, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 29
    invoke-static {p0, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    const/4 v0, 0x0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$2$0$1(Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 29
    .param p0, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C28@1818L60:SettingsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_10

    const/4 v2, 0x1

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_65

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:28)"

    const v4, 0x3cd8cbff

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 29
    :cond_28
    invoke-static/range {p0 .. p0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v2

    if-eqz v2, :cond_31

    const-string v2, "\u8bf7\u8f93\u5165 0\uff5e100 \u7684\u6574\u6570"

    goto :goto_33

    :cond_31
    const-string v2, "0\uff5e100 \u5f20 \u00b7 \u9ed8\u8ba4 20 \u5f20"

    :goto_33
    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p1

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_68

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_68

    :cond_65
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_68
    :goto_68
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$2$0$2$0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)Lkotlin/Unit;
    .registers 14
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$limitError$delegate"    # Landroidx/compose/runtime/MutableState;

    .line 30
    invoke-static {p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lkotlin/text/StringsKt;->toIntOrNull(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    .local v0, "n":Ljava/lang/Integer;
    const/4 v1, 0x1

    if-eqz v0, :cond_2e

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v3, 0x0

    if-ltz v2, :cond_17

    const/16 v4, 0x65

    if-ge v2, v4, :cond_17

    move v3, v1

    :cond_17
    if-nez v3, :cond_1a

    goto :goto_2e

    :cond_1a
    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static/range {v4 .. v9}, Lcom/xunji/core/model/AppSettings;->copy$default(Lcom/xunji/core/model/AppSettings;ILcom/xunji/core/model/ThemeMode;IILjava/lang/Object;)Lcom/xunji/core/model/AppSettings;

    move-result-object v1

    invoke-virtual {p0, v1}, Lcom/xunji/flashcards/ui/SettingsViewModel;->saveSettings(Lcom/xunji/core/model/AppSettings;)V

    goto :goto_31

    :cond_2e
    :goto_2e
    invoke-static {p3, v1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    :goto_31
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final SettingsScreen$lambda$7$0$3(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 11
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C31@2166L528,31@2135L559:SettingsScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:31)"

    const v4, 0xa7f2927

    invoke-static {v4, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 32
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda15;

    invoke-direct {v1, p0, p1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda15;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;)V

    const v4, -0x4174a809

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p3, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 35
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$3$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 31
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p2, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v7, p3

    move/from16 v0, p4

    const-string v1, "$this$Paper"

    move-object/from16 v2, p2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C32@2203L10,32@2171L54,33@2335L355,33@2229L461:SettingsScreen.kt#i35lj1"

    invoke-static {v7, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    const/4 v4, 0x1

    if-eq v1, v3, :cond_19

    move v1, v4

    goto :goto_1a

    :cond_19
    const/4 v1, 0x0

    :goto_1a
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v7, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_c6

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:32)"

    const v5, -0x4174a809

    invoke-static {v5, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_31
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v7, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u754c\u9762\u4e3b\u9898"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    move v5, v4

    const/4 v4, 0x0

    move v8, v5

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    move v9, v8

    const/4 v8, 0x0

    move v10, v9

    const/4 v9, 0x0

    move v12, v10

    const-wide/16 v10, 0x0

    move v13, v12

    const/4 v12, 0x0

    move v14, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const-wide/16 v14, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v19, v18

    const/16 v18, 0x0

    move/from16 v20, v19

    const/16 v19, 0x0

    move/from16 v22, v20

    const/16 v20, 0x0

    const/16 v23, 0x6

    move-object/from16 v22, p3

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 34
    move-object/from16 v7, v22

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v1, 0xa

    .local v1, "$this$dp\\1":I
    const/4 v2, 0x0

    .line 103
    .local v2, "$i$f$getDp\\1\\34":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 34
    .end local v1    # "$this$dp\\1":I
    .end local v2    # "$i$f$getDp\\1\\34":I
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v2, 0x6

    .local v2, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 103
    .local v3, "$i$f$getDp\\2\\34":I
    int-to-float v4, v2

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 34
    .end local v2    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\34":I
    invoke-virtual {v0, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    move-object v2, v0

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    new-instance v0, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda17;

    move-object/from16 v10, p0

    move-object/from16 v11, p1

    invoke-direct {v0, v10, v11}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda17;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;)V

    const/16 v3, 0x36

    const v4, 0x1a7d885c

    const/4 v5, 0x1

    invoke-static {v4, v5, v0, v7, v3}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v6, v0

    check-cast v6, Lkotlin/jvm/functions/Function3;

    const v8, 0x1801b0

    const/16 v9, 0x39

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static/range {v0 .. v9}, Landroidx/compose/foundation/layout/FlowLayoutKt;->FlowRow(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Vertical;IILkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_cd

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_cd

    .line 32
    :cond_c6
    move-object/from16 v10, p0

    move-object/from16 v11, p1

    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 35
    :cond_cd
    :goto_cd
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$3$0$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/flashcards/ui/SettingsViewModel;Landroidx/compose/foundation/layout/FlowRowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 31
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p2, "$this$FlowRow"    # Landroidx/compose/foundation/layout/FlowRowScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v14, p3

    move/from16 v2, p4

    const-string v3, "$this$FlowRow"

    move-object/from16 v4, p2

    invoke-static {v4, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "C*33@2430L61,33@2518L87,33@2371L315:SettingsScreen.kt#i35lj1"

    invoke-static {v14, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v3, v2, 0x11

    const/16 v5, 0x10

    const/16 v18, 0x0

    const/4 v6, 0x1

    if-eq v3, v5, :cond_1f

    move v3, v6

    goto :goto_21

    :cond_1f
    move/from16 v3, v18

    :goto_21
    and-int/lit8 v5, v2, 0x1

    invoke-interface {v14, v3, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_126

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_38

    const/4 v3, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:33)"

    const v7, 0x1a7d885c

    invoke-static {v7, v2, v3, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 34
    :cond_38
    invoke-static {}, Lcom/xunji/core/model/ThemeMode;->getEntries()Lkotlin/enums/EnumEntries;

    move-result-object v3

    move-object/from16 v19, v3

    check-cast v19, Ljava/lang/Iterable;

    .local v19, "$this$forEach\\1":Ljava/lang/Iterable;
    const/16 v20, 0x0

    .line 104
    .local v20, "$i$f$forEach\\1\\34":I
    invoke-interface/range {v19 .. v19}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v21

    :goto_46
    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    if-eqz v3, :cond_11b

    invoke-interface/range {v21 .. v21}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v22

    .local v22, "element\\1":Ljava/lang/Object;
    move-object/from16 v3, v22

    check-cast v3, Lcom/xunji/core/model/ThemeMode;

    .local v3, "mode\\2":Lcom/xunji/core/model/ThemeMode;
    const/16 v23, 0x0

    .line 34
    .local v23, "$i$a$-forEach-SettingsScreenKt$SettingsScreen$2$1$4$1$1$1\\2\\104\\0":I
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v5

    invoke-virtual {v5}, Lcom/xunji/core/model/AppSettings;->getThemeMode()Lcom/xunji/core/model/ThemeMode;

    move-result-object v5

    if-ne v5, v3, :cond_62

    move v2, v6

    goto :goto_64

    :cond_62
    move/from16 v2, v18

    :goto_64
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v5

    xor-int/2addr v5, v6

    sget-object v7, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v7, Landroidx/compose/ui/Modifier;

    const/16 v8, 0x30

    .local v8, "$this$dp\\3":I
    const/4 v9, 0x0

    .line 103
    .local v9, "$i$f$getDp\\3\\34":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 34
    .end local v8    # "$this$dp\\3":I
    .end local v9    # "$i$f$getDp\\3\\34":I
    const/4 v9, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v7, v8, v11, v9, v10}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    invoke-virtual {v3}, Lcom/xunji/core/model/ThemeMode;->name()Ljava/lang/String;

    move-result-object v8

    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    invoke-virtual {v8, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    move-result-object v8

    const-string v9, "toLowerCase(...)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "theme-"

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v9

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v7, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    const v8, -0x4eab5552

    const-string v9, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v14, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v14, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v8

    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v9

    or-int/2addr v8, v9

    move-object v9, v3

    check-cast v9, Ljava/lang/Enum;

    invoke-virtual {v9}, Ljava/lang/Enum;->ordinal()I

    move-result v9

    invoke-interface {v14, v9}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v9

    or-int/2addr v8, v9

    .local v8, "invalid\\4":Z
    move-object/from16 v9, p3

    .local v9, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 105
    .local v10, "$i$f$cache\\4\\34":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\4":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 106
    .local v12, "$i$a$-let-ComposerKt$cache$1\\5\\105\\4":I
    if-nez v8, :cond_d3

    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_d2

    goto :goto_d3

    .line 110
    :cond_d2
    goto :goto_de

    .line 107
    :cond_d3
    :goto_d3
    const/4 v13, 0x0

    .line 34
    .local v13, "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$4$1$1$1$1\\6\\107\\2":I
    new-instance v15, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v15, v1, v0, v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)V

    .line 107
    .end local v13    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$2$1$4$1$1$1$1\\6\\107\\2":I
    nop

    .line 108
    .local v15, "value\\5":Ljava/lang/Object;
    invoke-interface {v9, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 109
    move-object v11, v15

    .line 105
    .end local v11    # "it\\4":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\5\\105\\4":I
    .end local v15    # "value\\5":Ljava/lang/Object;
    :goto_de
    nop

    .line 34
    .end local v8    # "invalid\\4":Z
    .end local v9    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\4\\34":I
    check-cast v11, Lkotlin/jvm/functions/Function0;

    invoke-static {v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v8, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v8, v3}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda11;-><init>(Lcom/xunji/core/model/ThemeMode;)V

    const/16 v9, 0x36

    const v10, -0x4e4f907c

    invoke-static {v10, v6, v8, v14, v9}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    check-cast v8, Lkotlin/jvm/functions/Function2;

    const/16 v16, 0x0

    const/16 v17, 0xfe0

    move v9, v6

    move v6, v5

    move-object v5, v7

    const/4 v7, 0x0

    move-object v4, v8

    const/4 v8, 0x0

    move v10, v9

    const/4 v9, 0x0

    move v12, v10

    const/4 v10, 0x0

    move-object v13, v3

    move-object v3, v11

    .end local v3    # "mode\\2":Lcom/xunji/core/model/ThemeMode;
    .local v13, "mode\\2":Lcom/xunji/core/model/ThemeMode;
    const/4 v11, 0x0

    move v15, v12

    const/4 v12, 0x0

    move-object/from16 v24, v13

    .end local v13    # "mode\\2":Lcom/xunji/core/model/ThemeMode;
    .local v24, "mode\\2":Lcom/xunji/core/model/ThemeMode;
    const/4 v13, 0x0

    move/from16 v25, v15

    const/16 v15, 0x180

    invoke-static/range {v2 .. v17}, Landroidx/compose/material3/ChipKt;->FilterChip(ZLkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/SelectableChipColors;Landroidx/compose/material3/SelectableChipElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/runtime/Composer;III)V

    .line 104
    .end local v23    # "$i$a$-forEach-SettingsScreenKt$SettingsScreen$2$1$4$1$1$1\\2\\104\\0":I
    .end local v24    # "mode\\2":Lcom/xunji/core/model/ThemeMode;
    move-object/from16 v4, p2

    move-object/from16 v14, p3

    move/from16 v2, p4

    move/from16 v6, v25

    .end local v22    # "element\\1":Ljava/lang/Object;
    goto/16 :goto_46

    .line 111
    :cond_11b
    nop

    .end local v19    # "$this$forEach\\1":Ljava/lang/Iterable;
    .end local v20    # "$i$f$forEach\\1\\34":I
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_129

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_129

    .line 34
    :cond_126
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_129
    :goto_129
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v2
.end method

.method private static final SettingsScreen$lambda$7$0$3$0$0$0$0$0(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Lcom/xunji/core/model/ThemeMode;)Lkotlin/Unit;
    .registers 9
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$mode"    # Lcom/xunji/core/model/ThemeMode;

    .line 34
    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    move-object v2, p2

    .end local p2    # "$mode":Lcom/xunji/core/model/ThemeMode;
    .local v2, "$mode":Lcom/xunji/core/model/ThemeMode;
    invoke-static/range {v0 .. v5}, Lcom/xunji/core/model/AppSettings;->copy$default(Lcom/xunji/core/model/AppSettings;ILcom/xunji/core/model/ThemeMode;IILjava/lang/Object;)Lcom/xunji/core/model/AppSettings;

    move-result-object p2

    invoke-virtual {p0, p2}, Lcom/xunji/flashcards/ui/SettingsViewModel;->saveSettings(Lcom/xunji/core/model/AppSettings;)V

    sget-object p2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p2
.end method

.method private static final SettingsScreen$lambda$7$0$3$0$0$0$1(Lcom/xunji/core/model/ThemeMode;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 29
    .param p0, "$mode"    # Lcom/xunji/core/model/ThemeMode;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C33@2519L85:SettingsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    if-eq v2, v3, :cond_10

    const/4 v2, 0x1

    goto :goto_11

    :cond_10
    const/4 v2, 0x0

    :goto_11
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_73

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_28

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:33)"

    const v4, -0x4e4f907c

    invoke-static {v4, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 34
    :cond_28
    sget-object v2, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$WhenMappings;->$EnumSwitchMapping$0:[I

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/ThemeMode;->ordinal()I

    move-result v3

    aget v2, v2, v3

    packed-switch v2, :pswitch_data_7a

    new-instance v0, Lkotlin/NoWhenBranchMatchedException;

    invoke-direct {v0}, Lkotlin/NoWhenBranchMatchedException;-><init>()V

    throw v0

    :pswitch_39
    const-string v2, "\u6df1\u8272"

    goto :goto_41

    :pswitch_3c
    const-string v2, "\u6d45\u8272"

    goto :goto_41

    :pswitch_3f
    const-string v2, "\u8ddf\u968f\u7cfb\u7edf"

    :goto_41
    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p1

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_76

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_76

    :cond_73
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_76
    :goto_76
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    nop

    :pswitch_data_7a
    .packed-switch 0x1
        :pswitch_3f
        :pswitch_3c
        :pswitch_39
    .end packed-switch
.end method

.method private static final SettingsScreen$lambda$7$0$4(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 12
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$onExport"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$onImport"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C35@2737L456,35@2706L487:SettingsScreen.kt#i35lj1"

    invoke-static {p4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p5, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p5, 0x1

    invoke-interface {p4, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:35)"

    const v4, -0xef8753a

    invoke-static {v4, p5, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 36
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda16;

    invoke-direct {v1, p0, p1, p2}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda16;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    const v4, -0x5aec466a

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p4, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p4, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p4}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 41
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$4$0(Lcom/xunji/flashcards/ui/SettingsUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 33
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$onExport"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$onImport"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move-object/from16 v10, p4

    move/from16 v0, p5

    const-string v1, "$this$Paper"

    move-object/from16 v2, p3

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C36@2777L10,36@2742L57,36@2800L73,37@2877L97,38@2978L163,39@3145L44:SettingsScreen.kt#i35lj1"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v3, :cond_1a

    move v1, v5

    goto :goto_1b

    :cond_1a
    move v1, v4

    :goto_1b
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v10, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_fc

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_32

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:36)"

    const v6, -0x5aec466a

    invoke-static {v6, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 37
    :cond_32
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v10, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u628a\u8bb0\u5fc6\u597d\u597d\u4fdd\u5b58"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    move v6, v4

    const/4 v4, 0x0

    move v8, v5

    move v7, v6

    const-wide/16 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v11, v8

    const/4 v8, 0x0

    move v12, v9

    const/4 v9, 0x0

    move v13, v11

    const-wide/16 v10, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    move/from16 v17, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x6

    move-object/from16 v22, p4

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v10, v22

    const-string v0, "\u5bfc\u51fa\u5faa\u8bb0 V2 \u5907\u4efd\uff08.xunji.zip\uff09\uff0c\u5305\u542b\u5361\u7247\u3001\u590d\u4e60\u8fdb\u5ea6\u3001\u8bbe\u7f6e\u53ca Anki \u6a21\u677f\u548c\u5a92\u4f53\u3002\u8bf7\u5c06\u91cd\u8981\u5907\u4efd\u4fdd\u5b58\u5728\u53ef\u9760\u7684\u4f4d\u7f6e\u3002"

    const/4 v13, 0x6

    const/4 v14, 0x2

    const/4 v15, 0x0

    invoke-static {v0, v15, v10, v13, v14}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 38
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    if-eqz v0, :cond_91

    const-string v0, "\u6b63\u5728\u5904\u7406\u2026"

    goto :goto_93

    :cond_91
    const-string v0, "\u5bfc\u51fa\u5907\u4efd"

    :goto_93
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v1

    const/4 v11, 0x1

    xor-int/lit8 v3, v1, 0x1

    const/16 v6, 0x6000

    const/4 v7, 0x4

    const/4 v2, 0x0

    const-string v4, "export-backup"

    move-object/from16 v1, p1

    move-object v5, v10

    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    .line 39
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    invoke-static {v0, v1, v11, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x38

    .local v3, "$this$dp\\1":I
    const/4 v4, 0x0

    .line 112
    .local v4, "$i$f$getDp\\1\\39":I
    int-to-float v5, v3

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 39
    .end local v3    # "$this$dp\\1":I
    .end local v4    # "$i$f$getDp\\1\\39":I
    invoke-static {v0, v3, v1, v14, v2}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "import-backup"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    xor-int/lit8 v2, v0, 0x1

    const/16 v0, 0x12

    .local v0, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 112
    .local v3, "$i$f$getDp\\2\\39":I
    int-to-float v4, v0

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 39
    .end local v0    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\39":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-492772856$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const v11, 0x30000030

    const/16 v12, 0x1f0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v0, p2

    move-object/from16 v10, p4

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 40
    const-string v0, "\u6062\u590d\u4f1a\u66ff\u6362\u5f53\u524d\u5168\u90e8\u6570\u636e\u3002\u652f\u6301\u5faa\u8bb0 V2 \u5907\u4efd\u53ca\u65e7\u7248 V1 JSON\u3002"

    invoke-static {v0, v15, v10, v13, v14}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_ff

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_ff

    .line 36
    :cond_fc
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 41
    :cond_ff
    :goto_ff
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$5(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 11
    .param p0, "$onAnkiImport"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C41@3236L303,41@3205L334:SettingsScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p4, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p4, 0x1

    invoke-interface {p3, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:41)"

    const v4, -0x2870139b

    invoke-static {v4, p4, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 42
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda13;

    invoke-direct {v1, p0, p1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda13;-><init>(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const v4, -0x7463e4cb

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p3, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 46
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$7$0$5$0(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 32
    .param p0, "$onAnkiImport"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v10, p3

    move/from16 v0, p4

    const-string v1, "$this$Paper"

    move-object/from16 v2, p2

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C42@3279L10,42@3241L60,43@3305L56,44@3365L170:SettingsScreen.kt#i35lj1"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eq v1, v3, :cond_1a

    move v1, v5

    goto :goto_1b

    :cond_1a
    move v1, v4

    :goto_1b
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v10, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_d9

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_32

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (SettingsScreen.kt:42)"

    const v6, -0x7463e4cb

    invoke-static {v6, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 43
    :cond_32
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v10, v3}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u5bfc\u5165 Anki \u724c\u7ec4"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    move v6, v4

    const/4 v4, 0x0

    move v8, v5

    move v7, v6

    const-wide/16 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v11, v8

    const/4 v8, 0x0

    move v12, v9

    const/4 v9, 0x0

    move v13, v11

    const-wide/16 v10, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    move/from16 v17, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x6

    move-object/from16 v22, p3

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 44
    move-object/from16 v10, v22

    const-string v0, "\u9009\u62e9 .apkg \u6587\u4ef6\uff0c\u5148\u67e5\u770b\u517c\u5bb9\u6027\u548c\u53d7\u5f71\u54cd\u5361\u7247\uff0c\u518d\u786e\u8ba4\u5bfc\u5165\u3002\u5df2\u6709\u5361\u7247\u4e0e\u590d\u4e60\u8fdb\u5ea6\u4e0d\u4f1a\u88ab\u8986\u76d6\u3002"

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v12, 0x0

    invoke-static {v0, v12, v10, v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 45
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v11, 0x1

    invoke-static {v0, v1, v11, v3}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v4, 0x38

    .local v4, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 113
    .local v5, "$i$f$getDp\\1\\45":I
    int-to-float v6, v4

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 45
    .end local v4    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\45":I
    invoke-static {v0, v4, v1, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const-string v1, "import-anki"

    invoke-static {v0, v1}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v0

    xor-int/lit8 v2, v0, 0x1

    const/16 v0, 0x12

    .local v0, "$this$dp\\2":I
    const/4 v3, 0x0

    .line 113
    .local v3, "$i$f$getDp\\2\\45":I
    int-to-float v4, v0

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 45
    .end local v0    # "$this$dp\\2":I
    .end local v3    # "$i$f$getDp\\2\\45":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    move-object v3, v0

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$SettingsScreenKt;->getLambda$-920042585$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v9

    const v11, 0x30000030

    const/16 v12, 0x1f0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_dc

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_dc

    .line 42
    :cond_d9
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 46
    :cond_dc
    :goto_dc
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final SettingsScreen$lambda$9(Lcom/xunji/flashcards/ui/SettingsViewModel;Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 20
    .param p0, "$viewModel"    # Lcom/xunji/flashcards/ui/SettingsViewModel;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v11, p2

    move/from16 v14, p3

    const-string v1, "C49@4046L25,49@4138L78,49@4035L181:SettingsScreen.kt#i35lj1"

    invoke-static {v11, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v14, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eq v1, v2, :cond_13

    move v1, v3

    goto :goto_14

    :cond_13
    const/4 v1, 0x0

    :goto_14
    and-int/lit8 v2, v14, 0x1

    invoke-interface {v11, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_9c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_2b

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous> (SettingsScreen.kt:49)"

    const v4, -0x76a1431f

    invoke-static {v4, v14, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_2b
    const v1, -0x535cf5c6

    const-string v2, "CC(remember):SettingsScreen.kt#9igjgp"

    invoke-static {v11, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v11, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    .local v1, "invalid\\1":Z
    move-object/from16 v2, p2

    .local v2, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 114
    .local v4, "$i$f$cache\\1\\50":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\1":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 115
    .local v6, "$i$a$-let-ComposerKt$cache$1\\2\\114\\1":I
    if-nez v1, :cond_4b

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_4a

    goto :goto_4b

    .line 119
    :cond_4a
    goto :goto_58

    .line 116
    :cond_4b
    :goto_4b
    const/4 v7, 0x0

    .line 50
    .local v7, "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1\\3\\116\\0":I
    new-instance v8, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$4$1$1;

    invoke-direct {v8, v0}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$SettingsScreen$4$1$1;-><init>(Ljava/lang/Object;)V

    check-cast v8, Lkotlin/reflect/KFunction;

    .line 116
    .end local v7    # "$i$a$-cache-SettingsScreenKt$SettingsScreen$4$1\\3\\116\\0":I
    nop

    .line 117
    .local v8, "value\\2":Ljava/lang/Object;
    invoke-interface {v2, v8}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 118
    move-object v5, v8

    .line 114
    .end local v5    # "it\\1":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\2\\114\\1":I
    .end local v8    # "value\\2":Ljava/lang/Object;
    :goto_58
    nop

    .line 50
    .end local v1    # "invalid\\1":Z
    .end local v2    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\1\\50":I
    check-cast v5, Lkotlin/reflect/KFunction;

    invoke-static {v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v1

    xor-int/2addr v1, v3

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const-string v4, "restore-confirm"

    invoke-static {v2, v4}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    check-cast v5, Lkotlin/jvm/functions/Function0;

    new-instance v4, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda12;

    move-object/from16 v15, p1

    invoke-direct {v4, v15}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt$$ExternalSyntheticLambda12;-><init>(Lcom/xunji/flashcards/ui/SettingsUiState;)V

    const/16 v6, 0x36

    const v7, -0x25661262

    invoke-static {v7, v3, v4, v11, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v3

    move-object v10, v3

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const v12, 0x30000030

    const/16 v13, 0x1f8

    const/4 v4, 0x0

    move v3, v1

    move-object v1, v5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v1 .. v13}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_a1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_a1

    :cond_9c
    move-object/from16 v15, p1

    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_a1
    :goto_a1
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final SettingsScreen$lambda$9$1(Lcom/xunji/flashcards/ui/SettingsUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/SettingsUiState;
    .param p1, "$this$TextButton"    # Landroidx/compose/foundation/layout/RowScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$TextButton"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C49@4197L11,49@4139L76:SettingsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    if-eq v2, v4, :cond_18

    const/4 v2, 0x1

    goto :goto_19

    :cond_18
    const/4 v2, 0x0

    :goto_19
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_78

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.SettingsScreen.<anonymous>.<anonymous> (SettingsScreen.kt:49)"

    const v5, -0x25661262

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_30
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/SettingsUiState;->getBusy()Z

    move-result v2

    if-eqz v2, :cond_39

    const-string v2, "\u6062\u590d\u4e2d\u2026"

    goto :goto_3b

    :cond_39
    const-string v2, "\u786e\u8ba4\u66ff\u6362"

    :goto_3b
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v5, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v0, v5}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v4

    const/16 v24, 0x0

    const v25, 0x3fffa

    const/4 v1, 0x0

    move-object v0, v2

    move-wide v2, v4

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_7b

    :cond_78
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_7b
    :goto_7b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final synthetic access$SettingsScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 2
    .param p0, "$limit$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;

    .line 1
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/SettingsScreenKt;->SettingsScreen$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    return-void
.end method

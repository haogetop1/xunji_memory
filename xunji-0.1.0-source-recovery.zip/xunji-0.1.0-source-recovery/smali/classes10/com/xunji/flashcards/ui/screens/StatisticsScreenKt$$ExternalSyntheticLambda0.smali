.class public final synthetic Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/core/stats/DaySummary;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/core/stats/DaySummary;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/core/stats/DaySummary;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/core/stats/DaySummary;

    check-cast p1, Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    invoke-static {v0, p1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->$r8$lambda$9c7bP3QPQ4yOnfhpFvFbzETOFLk(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# instance fields
.field public final synthetic f$0:Lcom/xunji/core/stats/StatisticsSummary;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/core/stats/StatisticsSummary;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda3;->f$0:Lcom/xunji/core/stats/StatisticsSummary;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda3;->f$0:Lcom/xunji/core/stats/StatisticsSummary;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyItemScope;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p2

    check-cast p3, Landroidx/compose/runtime/Composer;

    check-cast p4, Ljava/lang/Integer;

    invoke-virtual {p4}, Ljava/lang/Integer;->intValue()I

    move-result p4

    invoke-static {v0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->$r8$lambda$rZ2JNvyFAdpDpJL-h1qEZcXU16g(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

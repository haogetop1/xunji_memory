.class public final synthetic Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda7;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/core/stats/StatisticsSummary;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/core/stats/StatisticsSummary;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/core/stats/StatisticsSummary;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda7;->f$0:Lcom/xunji/core/stats/StatisticsSummary;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static {v0, p1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->$r8$lambda$u580wVRBQ6nNEb_xxA5IHbsEHlM(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

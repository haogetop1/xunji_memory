.class public final Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;
.super Ljava/lang/Object;
.source "StatisticsScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nStatisticsScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 StatisticsScreen.kt\ncom/xunji/flashcards/ui/screens/StatisticsScreenKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 Row.kt\nandroidx/compose/foundation/layout/RowKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n+ 9 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 10 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n*L\n1#1,38:1\n113#2:39\n113#2:47\n113#2:109\n113#2:150\n123#2:184\n113#2:185\n1282#3,6:40\n1282#3,6:144\n1#4:46\n99#5:48\n95#5,10:49\n106#5:89\n95#5,10:90\n106#5:108\n99#5,6:110\n106#5:194\n80#6,6:59\n87#6,3:74\n90#6,2:83\n94#6:88\n87#6,8:100\n80#6,6:116\n87#6,3:131\n90#6,2:140\n80#6,6:157\n87#6,3:172\n90#6,2:181\n94#6:188\n94#6:193\n391#7,9:65\n400#7,3:85\n391#7,9:122\n400#7:142\n391#7,9:163\n400#7:183\n401#7,2:186\n401#7,2:191\n4360#8,6:77\n4360#8,6:134\n4360#8,6:175\n1869#9:143\n1870#9:190\n87#10,6:151\n94#10:189\n*S KotlinDebug\n*F\n+ 1 StatisticsScreen.kt\ncom/xunji/flashcards/ui/screens/StatisticsScreenKt\n*L\n18#1:39\n22#1:47\n25#1:109\n26#1:150\n28#1:184\n28#1:185\n18#1:40,6\n26#1:144,6\n22#1:48\n22#1:49,10\n22#1:89\n22#1:90,10\n22#1:108\n25#1:110,6\n25#1:194\n22#1:59,6\n22#1:74,3\n22#1:83,2\n22#1:88\n22#1:100,8\n25#1:116,6\n25#1:131,3\n25#1:140,2\n26#1:157,6\n26#1:172,3\n26#1:181,2\n26#1:188\n25#1:193\n22#1:65,9\n22#1:85,3\n25#1:122,9\n25#1:142\n26#1:163,9\n26#1:183\n26#1:186,2\n25#1:191,2\n22#1:77,6\n25#1:134,6\n26#1:175,6\n26#1:143\n26#1:190\n26#1:151,6\n26#1:189\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0002\u001a\u0015\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u0003H\u0007\u00a2\u0006\u0002\u0010\u0004\u00a8\u0006\u0005"
    }
    d2 = {
        "StatisticsScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/MainUiState;",
        "(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$7Dgz6yMEdd4eCIKIJPAnrJzX1xM(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$1(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$9c7bP3QPQ4yOnfhpFvFbzETOFLk(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$2$0$1$0$0$0(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TNZAj0zQfvcsTNetUVn-LBIoezQ(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$2(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$dXiIhqUfLzsDNIzrMUWqI8Sa6QY(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$1$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qVX4gPxMA-9wJD2b44fG560AnOE(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$2$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rZ2JNvyFAdpDpJL-h1qEZcXU16g(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$3(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$u580wVRBQ6nNEb_xxA5IHbsEHlM(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$x17MoX6mbZrWObi4sPMKNZKfFWU(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$0$0$3$0(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$ySMDvSphAJoxIcEK2SLBEZgqgcY(Lcom/xunji/flashcards/ui/MainUiState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen$lambda$1(Lcom/xunji/flashcards/ui/MainUiState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final StatisticsScreen(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)V
    .registers 20
    .param p0, "state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    move/from16 v1, p2

    const-string v2, "state"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 16
    const v2, -0x596e4f3b

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v13, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(StatisticsScreen)N(state)17@759L2230,17@622L2367:StatisticsScreen.kt#i35lj1"

    invoke-static {v13, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, v1, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_28

    invoke-interface {v13, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_26

    const/4 v4, 0x4

    goto :goto_27

    :cond_26
    move v4, v5

    :goto_27
    or-int/2addr v3, v4

    :cond_28
    and-int/lit8 v4, v3, 0x3

    const/4 v6, 0x1

    if-eq v4, v5, :cond_2f

    move v4, v6

    goto :goto_30

    :cond_2f
    const/4 v4, 0x0

    :goto_30
    and-int/lit8 v5, v3, 0x1

    invoke-interface {v13, v4, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_d7

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_44

    const/4 v4, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.StatisticsScreen (StatisticsScreen.kt:15)"

    invoke-static {v2, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 17
    :cond_44
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/MainUiState;->getStatistics()Lcom/xunji/core/stats/StatisticsSummary;

    move-result-object v2

    .line 18
    .local v2, "stats":Lcom/xunji/core/stats/StatisticsSummary;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v7, 0x0

    invoke-static {v4, v5, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v5, 0x16

    .local v5, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 39
    .local v6, "$i$f$getDp\\1\\18":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 18
    .end local v5    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\18":I
    const/16 v6, 0x12

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 39
    .local v7, "$i$f$getDp\\2\\18":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 18
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\18":I
    const/16 v7, 0x16

    .local v7, "$this$dp\\3":I
    const/4 v8, 0x0

    .line 39
    .local v8, "$i$f$getDp\\3\\18":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 18
    .end local v7    # "$this$dp\\3":I
    .end local v8    # "$i$f$getDp\\3\\18":I
    const/16 v8, 0x1c

    .local v8, "$this$dp\\4":I
    const/4 v9, 0x0

    .line 39
    .local v9, "$i$f$getDp\\4\\18":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 18
    .end local v8    # "$this$dp\\4":I
    .end local v9    # "$i$f$getDp\\4\\18":I
    invoke-static {v5, v6, v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v5

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x16

    .local v7, "$this$dp\\5":I
    const/4 v8, 0x0

    .line 39
    .local v8, "$i$f$getDp\\5\\18":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 18
    .end local v7    # "$this$dp\\5":I
    .end local v8    # "$i$f$getDp\\5\\18":I
    invoke-virtual {v6, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    move-object v7, v6

    check-cast v7, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    const v6, 0x48e8b63b

    const-string v8, "CC(remember):StatisticsScreen.kt#9igjgp"

    invoke-static {v13, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v13, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .local v6, "invalid\\6":Z
    move-object v8, v13

    .local v8, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 40
    .local v9, "$i$f$cache\\6\\18":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v10

    .local v10, "it\\6":Ljava/lang/Object;
    const/4 v11, 0x0

    .line 41
    .local v11, "$i$a$-let-ComposerKt$cache$1\\7\\40\\6":I
    if-nez v6, :cond_a6

    sget-object v12, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v12}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v12

    if-ne v10, v12, :cond_a5

    goto :goto_a6

    .line 45
    :cond_a5
    goto :goto_b1

    .line 42
    :cond_a6
    :goto_a6
    const/4 v12, 0x0

    .line 18
    .local v12, "$i$a$-cache-StatisticsScreenKt$StatisticsScreen$1\\8\\42\\0":I
    new-instance v14, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v14, v2}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda7;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    .line 42
    .end local v12    # "$i$a$-cache-StatisticsScreenKt$StatisticsScreen$1\\8\\42\\0":I
    nop

    .line 43
    .local v14, "value\\7":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 44
    move-object v10, v14

    .line 40
    .end local v10    # "it\\6":Ljava/lang/Object;
    .end local v11    # "$i$a$-let-ComposerKt$cache$1\\7\\40\\6":I
    .end local v14    # "value\\7":Ljava/lang/Object;
    :goto_b1
    nop

    .line 18
    .end local v6    # "invalid\\6":Z
    .end local v8    # "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$cache\\6\\18":I
    move-object v12, v10

    check-cast v12, Lkotlin/jvm/functions/Function1;

    invoke-static {v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v14, 0x6186

    const/16 v15, 0x1ea

    move v6, v3

    move-object v3, v4

    .end local v3    # "$dirty":I
    .local v6, "$dirty":I
    const/4 v4, 0x0

    move v8, v6

    .end local v6    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v6, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v10, v9

    .end local v9    # "$dirty":I
    .local v10, "$dirty":I
    const/4 v9, 0x0

    move v11, v10

    .end local v10    # "$dirty":I
    .local v11, "$dirty":I
    const/4 v10, 0x0

    move/from16 v16, v11

    .end local v11    # "$dirty":I
    .local v16, "$dirty":I
    const/4 v11, 0x0

    invoke-static/range {v3 .. v15}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_dc

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v2    # "stats":Lcom/xunji/core/stats/StatisticsSummary;
    goto :goto_dc

    .line 16
    .end local v16    # "$dirty":I
    .restart local v3    # "$dirty":I
    :cond_d7
    move/from16 v16, v3

    .end local v3    # "$dirty":I
    .restart local v16    # "$dirty":I
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 37
    :cond_dc
    :goto_dc
    invoke-interface {v13}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_ea

    new-instance v3, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v3, v0, v1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/ui/MainUiState;I)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_ea
    return-void
.end method

.method private static final StatisticsScreen$lambda$0$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 16
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 19
    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->getLambda$1383379216$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p1

    .end local p1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .local v1, "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 20
    move-object v7, v1

    .end local v1    # "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    .local v7, "$this$LazyColumn":Landroidx/compose/foundation/lazy/LazyListScope;
    if-eqz p0, :cond_37

    invoke-virtual {p0}, Lcom/xunji/core/stats/StatisticsSummary;->getLastSevenDays()Ljava/util/List;

    move-result-object p1

    check-cast p1, Ljava/lang/Iterable;

    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object p1

    const/4 v0, 0x0

    :goto_21
    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    if-eqz v1, :cond_35

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/xunji/core/stats/DaySummary;

    .line 46
    nop

    .local v1, "it\\1":Lcom/xunji/core/stats/DaySummary;
    const/4 v2, 0x0

    .line 20
    .local v2, "$i$a$-sumOfInt-StatisticsScreenKt$StatisticsScreen$1$1$1\\1\\20\\0":I
    invoke-virtual {v1}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v1

    .end local v1    # "it\\1":Lcom/xunji/core/stats/DaySummary;
    .end local v2    # "$i$a$-sumOfInt-StatisticsScreenKt$StatisticsScreen$1$1$1\\1\\20\\0":I
    add-int/2addr v0, v1

    goto :goto_21

    :cond_35
    if-nez v0, :cond_44

    :cond_37
    sget-object p1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;

    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->getLambda$253803925$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 21
    :cond_44
    if-eqz p0, :cond_8c

    .line 22
    new-instance p1, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {p1, p0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda1;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    const v0, 0x6447e

    const/4 v1, 0x1

    invoke-static {v0, v1, p1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p1

    move-object v10, p1

    check-cast v10, Lkotlin/jvm/functions/Function3;

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 23
    new-instance p1, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {p1, p0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda2;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    const v0, 0x7d7ae327

    invoke-static {v0, v1, p1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p1

    move-object v10, p1

    check-cast v10, Lkotlin/jvm/functions/Function3;

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 33
    invoke-virtual {p0}, Lcom/xunji/core/stats/StatisticsSummary;->getLastSevenDays()Ljava/util/List;

    move-result-object p1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v8

    new-instance p1, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {p1, p0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda3;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    const v0, -0x655d49ab

    invoke-static {v0, v1, p1}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object p1

    move-object v11, p1

    check-cast v11, Lkotlin/jvm/functions/Function4;

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v10, 0x0

    invoke-static/range {v7 .. v13}, Landroidx/compose/foundation/lazy/LazyListScope;->items$default(Landroidx/compose/foundation/lazy/LazyListScope;ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;ILjava/lang/Object;)V

    .line 35
    :cond_8c
    sget-object p1, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;

    invoke-virtual {p1}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$StatisticsScreenKt;->getLambda$-1104460487$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v10

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 36
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p1
.end method

.method private static final StatisticsScreen$lambda$0$0$1(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C21@990L512,21@959L543:StatisticsScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:21)"

    const v4, 0x6447e

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v1, p0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    const v4, -0x504ef0b2

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p2, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StatisticsScreen$lambda$0$0$1$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 51
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v4, p2

    move/from16 v7, p3

    const-string v0, "$this$Paper"

    move-object/from16 v8, p1

    invoke-static {v8, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C21@992L13,21@1006L199,21@1244L11,21@1206L65,21@1272L228:StatisticsScreen.kt#i35lj1"

    invoke-static {v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v7, 0x11

    const/16 v1, 0x10

    const/4 v9, 0x0

    if-eq v0, v1, :cond_19

    const/4 v0, 0x1

    goto :goto_1a

    :cond_19
    move v0, v9

    :goto_1a
    and-int/lit8 v1, v7, 0x1

    invoke-interface {v4, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_387

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:21)"

    const v2, -0x504ef0b2

    invoke-static {v2, v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_31
    const-string v0, "\u4eca\u5929"

    const/4 v10, 0x6

    invoke-static {v0, v4, v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v1, 0x18

    .local v1, "$this$dp\\1":I
    const/4 v2, 0x0

    .line 47
    .local v2, "$i$f$getDp\\1\\22":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 22
    .end local v1    # "$this$dp\\1":I
    .end local v2    # "$i$f$getDp\\1\\22":I
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    check-cast v0, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v0, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v1, 0x30

    .local v1, "$changed\\2":I
    move-object/from16 v2, p2

    .local v2, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 48
    .local v3, "$i$f$Row\\2\\22":I
    const v11, 0x3255a44b

    const-string v12, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v2, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 49
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .line 51
    .local v5, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .line 54
    .local v6, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v13, v1, 0x3

    and-int/lit8 v13, v13, 0xe

    shr-int/lit8 v14, v1, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v13, v14

    invoke-static {v0, v6, v2, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v13

    .line 58
    .local v13, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v1, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 55
    nop

    .local v14, "$changed\\3":I
    move-object v15, v5

    .local v15, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    .line 59
    .local v16, "$i$f$Layout\\3\\55":I
    move/from16 v17, v10

    const v10, -0x451e1427

    const-string v11, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v2, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 60
    invoke-static {v2, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v19

    invoke-static/range {v19 .. v20}, Ljava/lang/Long;->hashCode(J)I

    move-result v19

    .line 61
    .local v19, "compositeKeyHash\\3":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 62
    .local v9, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    .line 64
    .local v10, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v22

    move-object/from16 v23, v0

    .end local v0    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v23, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shl-int/lit8 v0, v14, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 63
    move-object/from16 v24, v22

    .local v0, "$changed\\4":I
    .local v24, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v22, 0x0

    .line 65
    .local v22, "$i$f$ReusableComposeNode\\4\\63":I
    move/from16 v25, v0

    .end local v0    # "$changed\\4":I
    .local v25, "$changed\\4":I
    const v0, -0x20f7d59c

    move/from16 v26, v1

    .end local v1    # "$changed\\2":I
    .local v26, "$changed\\2":I
    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 66
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_b6

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 67
    :cond_b6
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 68
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_c5

    .line 69
    move-object/from16 v0, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_ca

    .line 71
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c5
    move-object/from16 v0, v24

    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 73
    :goto_ca
    move-object/from16 v24, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v28, 0x0

    .line 74
    .local v28, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\73\\3":I
    sget-object v29, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v30, v1

    invoke-virtual/range {v29 .. v29}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 75
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 76
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v29, 0x0

    .line 77
    .local v29, "$i$f$set-impl\\6\\76":I
    move-object/from16 v31, v0

    .local v31, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v32, 0x0

    .line 78
    .local v32, "$i$a$-with-Updater$set$1\\7\\77\\6":I
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v33

    if-nez v33, :cond_10e

    move-object/from16 v33, v2

    .end local v2    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v33, "$composer\\2":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v31 .. v31}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v34, v3

    .end local v3    # "$i$f$Row\\2\\22":I
    .local v34, "$i$f$Row\\2\\22":I
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_10b

    goto :goto_112

    :cond_10b
    move-object/from16 v3, v31

    goto :goto_122

    .end local v33    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$f$Row\\2\\22":I
    .restart local v2    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$i$f$Row\\2\\22":I
    :cond_10e
    move-object/from16 v33, v2

    move/from16 v34, v3

    .line 79
    .end local v2    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$Row\\2\\22":I
    .restart local v33    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .restart local v34    # "$i$f$Row\\2\\22":I
    :goto_112
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v31

    .end local v31    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 80
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 82
    :goto_122
    nop

    .line 77
    .end local v3    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v32    # "$i$a$-with-Updater$set$1\\7\\77\\6":I
    nop

    .line 82
    nop

    .line 83
    .end local v1    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v29    # "$i$f$set-impl\\6\\76":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v10, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 84
    nop

    .line 73
    .end local v0    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v28    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\73\\3":I
    nop

    .line 85
    shr-int/lit8 v0, v25, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object/from16 v1, v33

    .local v1, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 56
    .local v2, "$i$a$-Layout-RowKt$Row$1\\8\\85\\2":I
    const v3, 0x56ccd6f5

    move/from16 v28, v0

    .end local v0    # "$changed\\8":I
    .local v28, "$changed\\8":I
    const-string v0, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v29, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v31, v26, 0x6

    and-int/lit8 v31, v31, 0x70

    or-int/lit8 v31, v31, 0x6

    .local v31, "$changed\\9":I
    check-cast v29, Landroidx/compose/foundation/layout/RowScope;

    .local v29, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v38, v1

    .local v38, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v39, v29

    .end local v29    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v39, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v29, 0x0

    .line 22
    .local v29, "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$2$1$1\\9\\56\\0":I
    const v3, -0x723da13b

    move-object/from16 v45, v0

    const-string v0, "C21@1063L68,21@1132L71:StatisticsScreen.kt#i35lj1"

    move-object/from16 v46, v1

    .end local v38    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v35

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v40, v0

    check-cast v40, Landroidx/compose/ui/Modifier;

    const/16 v43, 0x2

    const/16 v44, 0x0

    const/high16 v41, 0x3f800000    # 1.0f

    const/16 v42, 0x0

    invoke-static/range {v39 .. v44}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    move-object/from16 v0, v39

    .end local v39    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v0, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v39, 0x30

    const/16 v40, 0x0

    const-string v36, "\u8bc4\u5206\u6b21\u6570"

    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v38    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v35 .. v40}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/stats/DaySummary;->getDistinctCards()I

    move-result v1

    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v35

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v40, v1

    check-cast v40, Landroidx/compose/ui/Modifier;

    move-object/from16 v39, v0

    .end local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v39    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v39 .. v44}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v37

    .end local v39    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v39, 0x30

    const/16 v40, 0x0

    const-string v36, "\u5b66\u4e60\u5361\u7247"

    invoke-static/range {v35 .. v40}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v38 .. v38}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 56
    .end local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v29    # "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$2$1$1\\9\\56\\0":I
    .end local v31    # "$changed\\9":I
    .end local v38    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 85
    .end local v2    # "$i$a$-Layout-RowKt$Row$1\\8\\85\\2":I
    .end local v28    # "$changed\\8":I
    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 86
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 65
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 87
    nop

    .line 59
    .end local v22    # "$i$f$ReusableComposeNode\\4\\63":I
    .end local v24    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v25    # "$changed\\4":I
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 88
    nop

    .line 48
    .end local v9    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v10    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v14    # "$changed\\3":I
    .end local v15    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v16    # "$i$f$Layout\\3\\55":I
    .end local v19    # "compositeKeyHash\\3":I
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 89
    nop

    .line 22
    .end local v5    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v6    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v13    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v26    # "$changed\\2":I
    .end local v33    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$f$Row\\2\\22":I
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    move-object/from16 v13, v30

    move-object/from16 v9, v45

    const v10, 0x56ccd6f5

    const v14, -0x20f7d59c

    invoke-static/range {v0 .. v6}, Landroidx/compose/material3/DividerKt;->HorizontalDivider-9IZ8Weo(Landroidx/compose/ui/Modifier;FJLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v1, 0x18

    .local v1, "$this$dp\\10":I
    const/4 v2, 0x0

    .line 47
    .local v2, "$i$f$getDp\\10\\22":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 22
    .end local v1    # "$this$dp\\10":I
    .end local v2    # "$i$f$getDp\\10\\22":I
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v0

    check-cast v0, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v0, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v1, 0x30

    .local v1, "$changed\\11":I
    move-object/from16 v2, p2

    .local v2, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 48
    .local v3, "$i$f$Row\\11\\22":I
    const v4, 0x3255a44b

    invoke-static {v2, v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 90
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .line 92
    .local v4, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 95
    .local v5, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v6, v1, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v12, v1, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v6, v12

    invoke-static {v0, v5, v2, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 99
    .local v6, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v1, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 96
    nop

    .local v12, "$changed\\12":I
    move-object v15, v4

    .local v15, "modifier\\12":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    .line 59
    .local v16, "$i$f$Layout\\12\\96":I
    const v10, -0x451e1427

    invoke-static {v2, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 60
    const/4 v10, 0x0

    invoke-static {v2, v10}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v10

    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    move-result v10

    .line 61
    .local v10, "compositeKeyHash\\12":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 62
    .local v11, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 64
    .local v14, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    move-object/from16 v19, v0

    .end local v0    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v19, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    shl-int/lit8 v0, v12, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 63
    move-object/from16 v20, v18

    .local v0, "$changed\\13":I
    .local v20, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 65
    .local v18, "$i$f$ReusableComposeNode\\13\\63":I
    move/from16 v21, v0

    const v0, -0x20f7d59c

    .end local v0    # "$changed\\13":I
    .local v21, "$changed\\13":I
    invoke-static {v2, v0, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 66
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_250

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 67
    :cond_250
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 68
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_25f

    .line 69
    move-object/from16 v0, v20

    .end local v20    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_264

    .line 71
    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_25f
    move-object/from16 v0, v20

    .end local v20    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 73
    :goto_264
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v13

    .local v13, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 100
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\73\\12":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v0

    .end local v0    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v6, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 101
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v11, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 102
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 77
    .local v22, "$i$f$set-impl\\15\\102":I
    move-object/from16 v24, v13

    .local v24, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 78
    .local v25, "$i$a$-with-Updater$set$1\\16\\77\\15":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_2a6

    move/from16 v26, v1

    .end local v1    # "$changed\\11":I
    .local v26, "$changed\\11":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v27, v2

    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2a3

    goto :goto_2aa

    :cond_2a3
    move-object/from16 v2, v24

    goto :goto_2ba

    .end local v26    # "$changed\\11":I
    .end local v27    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v1    # "$changed\\11":I
    .restart local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    :cond_2a6
    move/from16 v26, v1

    move-object/from16 v27, v2

    .line 79
    .end local v1    # "$changed\\11":I
    .end local v2    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .restart local v26    # "$changed\\11":I
    .restart local v27    # "$composer\\11":Landroidx/compose/runtime/Composer;
    :goto_2aa
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 80
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v13, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 82
    :goto_2ba
    nop

    .line 77
    .end local v2    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\16\\77\\15":I
    nop

    .line 82
    nop

    .line 103
    .end local v0    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\15\\102":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v13, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 104
    nop

    .line 73
    .end local v13    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\73\\12":I
    nop

    .line 85
    shr-int/lit8 v0, v21, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\17":I
    move-object/from16 v1, v27

    .local v1, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 97
    .local v2, "$i$a$-Layout-RowKt$Row$1\\17\\85\\11":I
    const v13, 0x56ccd6f5

    invoke-static {v1, v13, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v9, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v13, v26, 0x6

    and-int/lit8 v13, v13, 0x70

    or-int/lit8 v13, v13, 0x6

    .local v13, "$changed\\18":I
    check-cast v9, Landroidx/compose/foundation/layout/RowScope;

    .local v9, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v31, v1

    .local v31, "$composer\\18":Landroidx/compose/runtime/Composer;
    move-object/from16 v32, v9

    .end local v9    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v32, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    const/4 v9, 0x0

    .line 22
    .local v9, "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$2$1$2\\18\\97\\0":I
    move/from16 v17, v0

    .end local v0    # "$changed\\17":I
    .local v17, "$changed\\17":I
    const v0, -0x40afcd8f

    move-object/from16 v20, v1

    .end local v1    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v20, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v1, "C21@1329L96,21@1426L72:StatisticsScreen.kt#i35lj1"

    move/from16 v22, v2

    move-object/from16 v2, v31

    .end local v31    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v22, "$i$a$-Layout-RowKt$Row$1\\17\\85\\11":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/stats/DaySummary;->getAgainRatio()Ljava/lang/Double;

    move-result-object v0

    if-eqz v0, :cond_323

    check-cast v0, Ljava/lang/Number;

    invoke-virtual {v0}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v0

    .line 46
    .local v0, "it\\19":D
    const/16 v24, 0x0

    .line 22
    .local v24, "$i$a$-let-StatisticsScreenKt$StatisticsScreen$1$1$2$1$2$1\\19\\22\\18":I
    move-wide/from16 v28, v0

    .end local v0    # "it\\19":D
    .local v28, "it\\19":D
    const/16 v0, 0x64

    int-to-double v0, v0

    mul-double v0, v0, v28

    double-to-int v0, v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, "%"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    .end local v24    # "$i$a$-let-StatisticsScreenKt$StatisticsScreen$1$1$2$1$2$1\\19\\22\\18":I
    .end local v28    # "it\\19":D
    if-nez v0, :cond_325

    :cond_323
    const-string v0, "\u2014"

    :cond_325
    move-object/from16 v28, v0

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v33, v0

    check-cast v33, Landroidx/compose/ui/Modifier;

    const/16 v36, 0x2

    const/16 v37, 0x0

    const/high16 v34, 0x3f800000    # 1.0f

    const/16 v35, 0x0

    invoke-static/range {v32 .. v37}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v30

    move-object/from16 v0, v32

    .end local v32    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    .local v0, "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    const/16 v32, 0x30

    const/16 v33, 0x0

    const-string v29, "\u5fd8\u8bb0\u6bd4\u4f8b"

    move-object/from16 v31, v2

    .end local v2    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v31    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v28 .. v33}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/stats/DaySummary;->getDurationMs()J

    move-result-wide v1

    invoke-static {v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->durationLabel(J)Ljava/lang/String;

    move-result-object v28

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v33, v1

    check-cast v33, Landroidx/compose/ui/Modifier;

    move-object/from16 v32, v0

    .end local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    .restart local v32    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v32 .. v37}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v30

    .end local v32    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    .restart local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    const/16 v32, 0x30

    const/16 v33, 0x0

    const-string v29, "\u6709\u6548\u7528\u65f6"

    invoke-static/range {v28 .. v33}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 97
    .end local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u241_u240_u241\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v9    # "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$2$1$2\\18\\97\\0":I
    .end local v13    # "$changed\\18":I
    .end local v31    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v20 .. v20}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 85
    .end local v17    # "$changed\\17":I
    .end local v20    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-Layout-RowKt$Row$1\\17\\85\\11":I
    nop

    .line 86
    invoke-interface/range {v27 .. v27}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 65
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 87
    nop

    .line 59
    .end local v18    # "$i$f$ReusableComposeNode\\13\\63":I
    .end local v21    # "$changed\\13":I
    .end local v23    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 107
    nop

    .line 48
    .end local v10    # "compositeKeyHash\\12":I
    .end local v11    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v12    # "$changed\\12":I
    .end local v14    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v15    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v16    # "$i$f$Layout\\12\\96":I
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 108
    nop

    .end local v3    # "$i$f$Row\\11\\22":I
    .end local v4    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v5    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v6    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v19    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v26    # "$changed\\11":I
    .end local v27    # "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_38a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_38a

    .line 22
    :cond_387
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_38a
    :goto_38a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StatisticsScreen$lambda$0$0$2(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C22@1546L985,22@1515L1016:StatisticsScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:22)"

    const v4, 0x7d7ae327

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 23
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v1, p0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda5;-><init>(Lcom/xunji/core/stats/StatisticsSummary;)V

    const v4, -0x1261c609

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p2, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 32
    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StatisticsScreen$lambda$0$0$2$0(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 93
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C22@1582L10,22@1548L56,22@1605L21,24@1704L822:StatisticsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v2, v4, :cond_1a

    move v2, v6

    goto :goto_1b

    :cond_1a
    move v2, v5

    :goto_1b
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_50a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:22)"

    const v7, -0x1261c609

    invoke-static {v7, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 23
    :cond_32
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v0, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const-string v0, "\u6700\u8fd1 7 \u5929"

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move v7, v5

    move v8, v6

    const-wide/16 v5, 0x0

    move v9, v7

    const/4 v7, 0x0

    move v10, v8

    const/4 v8, 0x0

    move v11, v9

    const/4 v9, 0x0

    move v13, v10

    move v12, v11

    const-wide/16 v10, 0x0

    move v14, v12

    const/4 v12, 0x0

    move v15, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    move/from16 v17, v15

    const-wide/16 v14, 0x0

    move/from16 v18, v16

    const/16 v16, 0x0

    move/from16 v19, v17

    const/16 v17, 0x0

    move/from16 v20, v18

    const/16 v18, 0x0

    move/from16 v22, v19

    const/16 v19, 0x0

    move/from16 v23, v20

    const/16 v20, 0x0

    move/from16 v26, v23

    const/16 v23, 0x6

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v0, v22

    const-string v1, "\u8bc4\u5206\u6b21\u6570 \u00b7 \u5305\u542b\u4eca\u5929"

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v12, 0x0

    invoke-static {v1, v12, v0, v3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 24
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getLastSevenDays()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    if-eqz v2, :cond_504

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Lcom/xunji/core/stats/DaySummary;

    .line 46
    .local v2, "it\\1":Lcom/xunji/core/stats/DaySummary;
    const/4 v4, 0x0

    .line 24
    .local v4, "$i$a$-maxOf-StatisticsScreenKt$StatisticsScreen$1$1$3$1$max$1\\1\\24\\0":I
    invoke-virtual {v2}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v2

    .end local v2    # "it\\1":Lcom/xunji/core/stats/DaySummary;
    .end local v4    # "$i$a$-maxOf-StatisticsScreenKt$StatisticsScreen$1$1$3$1$max$1\\1\\24\\0":I
    :cond_a3
    :goto_a3
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_b8

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/xunji/core/stats/DaySummary;

    .line 46
    .local v4, "it\\2":Lcom/xunji/core/stats/DaySummary;
    const/4 v5, 0x0

    .line 24
    .local v5, "$i$a$-maxOf-StatisticsScreenKt$StatisticsScreen$1$1$3$1$max$1\\2\\24\\0":I
    invoke-virtual {v4}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v4

    .end local v4    # "it\\2":Lcom/xunji/core/stats/DaySummary;
    .end local v5    # "$i$a$-maxOf-StatisticsScreenKt$StatisticsScreen$1$1$3$1$max$1\\2\\24\\0":I
    if-ge v2, v4, :cond_a3

    move v2, v4

    goto :goto_a3

    :cond_b8
    const/4 v13, 0x1

    invoke-static {v2, v13}, Lkotlin/ranges/RangesKt;->coerceAtLeast(II)I

    move-result v1

    .line 25
    .local v1, "max":I
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2, v4, v13, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v6, 0x98

    .local v6, "$this$dp\\3":I
    const/4 v7, 0x0

    .line 109
    .local v7, "$i$f$getDp\\3\\25":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 25
    .end local v6    # "$this$dp\\3":I
    .end local v7    # "$i$f$getDp\\3\\25":I
    invoke-static {v2, v6}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x8

    .local v7, "$this$dp\\4":I
    const/4 v8, 0x0

    .line 109
    .local v8, "$i$f$getDp\\4\\25":I
    int-to-float v9, v7

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 25
    .end local v7    # "$this$dp\\4":I
    .end local v8    # "$i$f$getDp\\4\\25":I
    invoke-virtual {v6, v7}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v6

    check-cast v6, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v6, "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getBottom()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v7

    .local v7, "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v8, 0x1b6

    .local v8, "$changed\\5":I
    move-object/from16 v9, p2

    .local v2, "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v9, "$composer\\5":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 110
    .local v10, "$i$f$Row\\5\\25":I
    const v11, 0x3255a44b

    const-string v14, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v9, v11, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 111
    shr-int/lit8 v11, v8, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v14, v8, 0x3

    and-int/lit8 v14, v14, 0x70

    or-int/2addr v11, v14

    invoke-static {v6, v7, v9, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 115
    .local v11, "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v14, v8, 0x3

    and-int/lit8 v14, v14, 0x70

    .line 112
    move-object v15, v2

    .local v14, "$changed\\6":I
    .local v15, "modifier\\6":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    .line 116
    .local v16, "$i$f$Layout\\6\\112":I
    move/from16 v17, v3

    const v3, -0x451e1427

    const-string v4, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v9, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 117
    invoke-static {v9, v12}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v19

    invoke-static/range {v19 .. v20}, Ljava/lang/Long;->hashCode(J)I

    move-result v19

    .line 118
    .local v19, "compositeKeyHash\\6":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 119
    .local v5, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9, v15}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 121
    .local v12, "materialized\\6":Landroidx/compose/ui/Modifier;
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v21

    shl-int/lit8 v3, v14, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 120
    nop

    .local v3, "$changed\\7":I
    move-object/from16 v24, v21

    .local v24, "factory\\7":Lkotlin/jvm/functions/Function0;
    const/16 v21, 0x0

    .line 122
    .local v21, "$i$f$ReusableComposeNode\\7\\120":I
    const v13, -0x20f7d59c

    const-string v0, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v9, v13, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 123
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v13

    instance-of v13, v13, Landroidx/compose/runtime/Applier;

    if-nez v13, :cond_148

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 124
    :cond_148
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 125
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v13

    if-eqz v13, :cond_157

    .line 126
    move-object/from16 v13, v24

    .end local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .local v13, "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_15c

    .line 128
    .end local v13    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    :cond_157
    move-object/from16 v13, v24

    .end local v24    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .restart local v13    # "factory\\7":Lkotlin/jvm/functions/Function0;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 130
    :goto_15c
    move-object/from16 v24, v2

    .end local v2    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .local v24, "modifier\\5":Landroidx/compose/ui/Modifier;
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    const/16 v26, 0x0

    .line 131
    .local v26, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\130\\6":I
    sget-object v27, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v28, v3

    .end local v3    # "$changed\\7":I
    .local v28, "$changed\\7":I
    invoke-virtual/range {v27 .. v27}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v11, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 132
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 133
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\9":Lkotlin/jvm/functions/Function2;
    const/16 v27, 0x0

    .line 134
    .local v27, "$i$f$set-impl\\9\\133":I
    move-object/from16 v29, v2

    .local v29, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 135
    .local v30, "$i$a$-with-Updater$set$1\\10\\134\\9":I
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v31

    if-nez v31, :cond_1a0

    move-object/from16 v31, v5

    .end local v5    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .local v31, "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v29 .. v29}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v32, v6

    .end local v6    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v32, "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_19d

    goto :goto_1a4

    :cond_19d
    move-object/from16 v6, v29

    goto :goto_1b4

    .end local v31    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v32    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v5    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_1a0
    move-object/from16 v31, v5

    move-object/from16 v32, v6

    .line 136
    .end local v5    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v31    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v32    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_1a4
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v29

    .end local v29    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 137
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v2, v5, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 139
    :goto_1b4
    nop

    .line 134
    .end local v6    # "$this$set_impl_u24lambda_u240\\9":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-with-Updater$set$1\\10\\134\\9":I
    nop

    .line 139
    nop

    .line 140
    .end local v3    # "block\\9":Lkotlin/jvm/functions/Function2;
    .end local v27    # "$i$f$set-impl\\9\\133":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v2, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 141
    nop

    .line 130
    .end local v2    # "$this$Layout_u24lambda_u240\\8":Landroidx/compose/runtime/Composer;
    .end local v26    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\8\\130\\6":I
    nop

    .line 142
    shr-int/lit8 v2, v28, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\11":I
    move-object v3, v9

    .local v3, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 113
    .local v5, "$i$a$-Layout-RowKt$Row$1\\11\\142\\5":I
    const v6, 0x56ccd6f5

    move/from16 v26, v2

    .end local v2    # "$changed\\11":I
    .local v26, "$changed\\11":I
    const-string v2, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v3, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v6, v8, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\12":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241\\12":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v27, v3

    .local v27, "$composer\\12":Landroidx/compose/runtime/Composer;
    move-object/from16 v33, v2

    .end local v2    # "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241\\12":Landroidx/compose/foundation/layout/RowScope;
    .local v33, "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241\\12":Landroidx/compose/foundation/layout/RowScope;
    const/4 v2, 0x0

    .line 26
    .local v2, "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1\\12\\113\\0":I
    move/from16 v29, v2

    .end local v2    # "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1\\12\\113\\0":I
    .local v29, "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1\\12\\113\\0":I
    const v2, 0x718a855f

    move-object/from16 v30, v3

    .end local v3    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v30, "$composer\\11":Landroidx/compose/runtime/Composer;
    const-string v3, "C:StatisticsScreen.kt#i35lj1"

    move/from16 v39, v5

    move-object/from16 v5, v27

    .end local v27    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v39, "$i$a$-Layout-RowKt$Row$1\\11\\142\\5":I
    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v2, -0x1d5e9e70

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "*25@1934L83,25@1874L644"

    invoke-static {v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getLastSevenDays()Ljava/util/List;

    move-result-object v2

    check-cast v2, Ljava/lang/Iterable;

    .local v2, "$this$forEach\\13":Ljava/lang/Iterable;
    const/4 v3, 0x0

    .line 143
    .local v3, "$i$f$forEach\\13\\26":I
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v27

    :goto_207
    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->hasNext()Z

    move-result v34

    if-eqz v34, :cond_4d6

    invoke-interface/range {v27 .. v27}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v40

    move-object/from16 v41, v2

    .end local v2    # "$this$forEach\\13":Ljava/lang/Iterable;
    .local v40, "element\\13":Ljava/lang/Object;
    .local v41, "$this$forEach\\13":Ljava/lang/Iterable;
    move-object/from16 v2, v40

    check-cast v2, Lcom/xunji/core/stats/DaySummary;

    .local v2, "day\\14":Lcom/xunji/core/stats/DaySummary;
    const/16 v42, 0x0

    .line 26
    .local v42, "$i$a$-forEach-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1\\14\\143\\12":I
    sget-object v34, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v34, Landroidx/compose/ui/Modifier;

    const/16 v37, 0x2

    const/16 v38, 0x0

    const/high16 v35, 0x3f800000    # 1.0f

    const/16 v36, 0x0

    move/from16 v43, v3

    .end local v3    # "$i$f$forEach\\13\\26":I
    .local v43, "$i$f$forEach\\13\\26":I
    invoke-static/range {v33 .. v38}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    move/from16 v34, v6

    .end local v6    # "$changed\\12":I
    .local v34, "$changed\\12":I
    const v6, 0x733b3e37

    move-object/from16 v35, v7

    .end local v7    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .local v35, "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    const-string v7, "CC(remember):StatisticsScreen.kt#9igjgp"

    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v5, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    .local v6, "invalid\\15":Z
    move-object v7, v5

    .local v7, "$this$cache\\15":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 144
    .local v36, "$i$f$cache\\15\\26":I
    move-object/from16 v37, v5

    .end local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v37, "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\15":Ljava/lang/Object;
    const/16 v38, 0x0

    .line 145
    .local v38, "$i$a$-let-ComposerKt$cache$1\\16\\144\\15":I
    if-nez v6, :cond_254

    sget-object v44, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v45, v6

    .end local v6    # "invalid\\15":Z
    .local v45, "invalid\\15":Z
    invoke-virtual/range {v44 .. v44}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v5, v6, :cond_253

    goto :goto_256

    .line 149
    :cond_253
    goto :goto_263

    .line 145
    .end local v45    # "invalid\\15":Z
    .restart local v6    # "invalid\\15":Z
    :cond_254
    move/from16 v45, v6

    .line 146
    .end local v6    # "invalid\\15":Z
    .restart local v45    # "invalid\\15":Z
    :goto_256
    const/4 v6, 0x0

    .line 26
    .local v6, "$i$a$-cache-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1$1\\17\\146\\14":I
    move-object/from16 v44, v5

    .end local v5    # "it\\15":Ljava/lang/Object;
    .local v44, "it\\15":Ljava/lang/Object;
    new-instance v5, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v5, v2}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/core/stats/DaySummary;)V

    .line 146
    .end local v6    # "$i$a$-cache-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1$1\\17\\146\\14":I
    nop

    .line 147
    .local v5, "value\\16":Ljava/lang/Object;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 148
    nop

    .line 144
    .end local v5    # "value\\16":Ljava/lang/Object;
    .end local v38    # "$i$a$-let-ComposerKt$cache$1\\16\\144\\15":I
    .end local v44    # "it\\15":Ljava/lang/Object;
    :goto_263
    nop

    .line 26
    .end local v7    # "$this$cache\\15":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$f$cache\\15\\26":I
    .end local v45    # "invalid\\15":Z
    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-static/range {v37 .. v37}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v6, 0x1

    invoke-static {v3, v6, v5}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterHorizontally()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v5

    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x8

    .local v7, "$this$dp\\18":I
    const/16 v36, 0x0

    .line 150
    .local v36, "$i$f$getDp\\18\\26":I
    move-object/from16 v38, v2

    .end local v2    # "day\\14":Lcom/xunji/core/stats/DaySummary;
    .local v38, "day\\14":Lcom/xunji/core/stats/DaySummary;
    int-to-float v2, v7

    invoke-static {v2}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 26
    .end local v7    # "$this$dp\\18":I
    .end local v36    # "$i$f$getDp\\18\\26":I
    invoke-virtual {v6, v2}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v2, "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x1b0

    .local v3, "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v6, "$changed\\19":I
    move-object/from16 v7, v37

    .local v5, "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    .local v7, "$composer\\19":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 151
    .local v36, "$i$f$Column\\19\\26":I
    move-object/from16 v44, v3

    .end local v3    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .local v44, "modifier\\19":Landroidx/compose/ui/Modifier;
    const v3, 0x4ff7456f

    move/from16 v45, v6

    .end local v6    # "$changed\\19":I
    .local v45, "$changed\\19":I
    const-string v6, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v7, v3, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 152
    shr-int/lit8 v3, v45, 0x3

    and-int/lit8 v3, v3, 0xe

    shr-int/lit8 v6, v45, 0x3

    and-int/lit8 v6, v6, 0x70

    or-int/2addr v3, v6

    invoke-static {v2, v5, v7, v3}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .line 156
    .local v3, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v6, v45, 0x3

    and-int/lit8 v6, v6, 0x70

    .line 153
    nop

    .local v6, "$changed\\20":I
    move-object/from16 v46, v44

    .local v46, "modifier\\20":Landroidx/compose/ui/Modifier;
    const/16 v47, 0x0

    .line 157
    .local v47, "$i$f$Layout\\20\\153":I
    move-object/from16 v48, v2

    const v2, -0x451e1427

    .end local v2    # "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v48, "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v7, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 158
    const/4 v2, 0x0

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v49

    invoke-static/range {v49 .. v50}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 159
    .local v2, "compositeKeyHash\\20":I
    move/from16 v49, v2

    .end local v2    # "compositeKeyHash\\20":I
    .local v49, "compositeKeyHash\\20":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 160
    .local v2, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v50, v4

    move-object/from16 v4, v46

    move-object/from16 v46, v5

    .end local v5    # "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    .local v4, "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v46, "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v7, v4}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 162
    .local v5, "materialized\\20":Landroidx/compose/ui/Modifier;
    sget-object v51, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v51 .. v51}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v51

    move-object/from16 v52, v4

    .end local v4    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .local v52, "modifier\\20":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v4, v6, 0x6

    and-int/lit16 v4, v4, 0x380

    or-int/lit8 v4, v4, 0x6

    .line 161
    move-object/from16 v53, v51

    .local v4, "$changed\\21":I
    .local v53, "factory\\21":Lkotlin/jvm/functions/Function0;
    const/16 v51, 0x0

    .line 163
    .local v51, "$i$f$ReusableComposeNode\\21\\161":I
    move/from16 v54, v4

    const v4, -0x20f7d59c

    .end local v4    # "$changed\\21":I
    .local v54, "$changed\\21":I
    invoke-static {v7, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 164
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_2f5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 165
    :cond_2f5
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 166
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_304

    .line 167
    move-object/from16 v4, v53

    .end local v53    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v4, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v4}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_309

    .line 169
    .end local v4    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v53    # "factory\\21":Lkotlin/jvm/functions/Function0;
    :cond_304
    move-object/from16 v4, v53

    .end local v53    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .restart local v4    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 171
    :goto_309
    move-object/from16 v53, v0

    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 172
    .local v55, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\171\\20":I
    sget-object v56, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v57, v4

    .end local v4    # "factory\\21":Lkotlin/jvm/functions/Function0;
    .local v57, "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v56 .. v56}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 173
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v0, v2, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 174
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    .local v4, "block\\23":Lkotlin/jvm/functions/Function2;
    const/16 v56, 0x0

    .line 175
    .local v56, "$i$f$set-impl\\23\\174":I
    move-object/from16 v58, v0

    .local v58, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 176
    .local v59, "$i$a$-with-Updater$set$1\\24\\175\\23":I
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v60

    if-nez v60, :cond_34d

    move-object/from16 v60, v2

    .end local v2    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .local v60, "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v58 .. v58}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v61, v3

    .end local v3    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v61, "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_34a

    goto :goto_351

    :cond_34a
    move-object/from16 v3, v58

    goto :goto_361

    .end local v60    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v61    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v3    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_34d
    move-object/from16 v60, v2

    move-object/from16 v61, v3

    .line 177
    .end local v2    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v3    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v60    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v61    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_351
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v58

    .end local v58    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 178
    invoke-static/range {v49 .. v49}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 180
    :goto_361
    nop

    .line 175
    .end local v3    # "$this$set_impl_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v59    # "$i$a$-with-Updater$set$1\\24\\175\\23":I
    nop

    .line 180
    nop

    .line 181
    .end local v4    # "block\\23":Lkotlin/jvm/functions/Function2;
    .end local v56    # "$i$f$set-impl\\23\\174":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 182
    nop

    .line 171
    .end local v0    # "$this$Layout_u24lambda_u240\\22":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\22\\171\\20":I
    nop

    .line 183
    shr-int/lit8 v0, v54, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\25":I
    move-object v2, v7

    .local v2, "$composer\\25":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 154
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\25\\183\\19":I
    const v4, 0x7cc0ae6e

    move/from16 v55, v0

    .end local v0    # "$changed\\25":I
    .local v55, "$changed\\25":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v4, v45, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\26":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241_u240_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v84, v2

    .local v84, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 27
    .local v56, "$i$a$-Column-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1$2\\26\\154\\14":I
    move-object/from16 v58, v0

    .end local v0    # "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241_u240_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    .local v58, "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241_u240_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x27c59a8f

    move-object/from16 v59, v2

    .end local v2    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .local v59, "$composer\\25":Landroidx/compose/runtime/Composer;
    const-string v2, "C26@2174L10,26@2123L74,27@2204L221,28@2488L10,28@2432L79:StatisticsScreen.kt#i35lj1"

    move/from16 v88, v3

    move-object/from16 v3, v84

    .end local v84    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v88, "$i$a$-Layout-ColumnKt$Column$1\\25\\183\\19":I
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {v38 .. v38}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v62

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v83

    const/16 v86, 0x0

    const v87, 0x1fffe

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const-wide/16 v72, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v85, 0x0

    .end local v3    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v84    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v62 .. v87}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 28
    .end local v84    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\26":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    move/from16 v18, v4

    move-object/from16 v20, v5

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    .end local v4    # "$changed\\26":I
    .end local v5    # "materialized\\20":Landroidx/compose/ui/Modifier;
    .local v18, "$changed\\26":I
    .local v20, "materialized\\20":Landroidx/compose/ui/Modifier;
    invoke-static {v0, v4, v5, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    move/from16 v2, v17

    int-to-float v4, v2

    invoke-virtual/range {v38 .. v38}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v2

    int-to-float v2, v2

    const/high16 v62, 0x42a00000    # 80.0f

    mul-float v2, v2, v62

    int-to-float v5, v1

    div-float/2addr v2, v5

    add-float/2addr v4, v2

    .local v4, "$this$dp\\27":F
    const/4 v2, 0x0

    .line 184
    .local v2, "$i$f$getDp\\27\\28":I
    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 28
    .end local v2    # "$i$f$getDp\\27\\28":I
    .end local v4    # "$this$dp\\27":F
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v2, 0x8

    .local v2, "$this$dp\\28":I
    const/4 v4, 0x0

    .line 185
    .local v4, "$i$f$getDp\\28\\28":I
    int-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 28
    .end local v2    # "$this$dp\\28":I
    .end local v4    # "$i$f$getDp\\28\\28":I
    invoke-static {v2}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v2

    check-cast v2, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v0, v2}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v62

    invoke-virtual/range {v38 .. v38}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v0

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v2

    invoke-virtual {v2}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v2

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_43e

    const v0, 0x514c51f5

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "27@2356L11"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v4

    goto :goto_455

    :cond_43e
    const v0, 0x514c56de

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "27@2395L11"

    invoke-static {v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v4

    :goto_455
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide/from16 v63, v4

    const/16 v66, 0x2

    const/16 v67, 0x0

    const/16 v65, 0x0

    invoke-static/range {v62 .. v67}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v2, 0x0

    invoke-static {v0, v3, v2}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    .line 29
    invoke-virtual/range {v38 .. v38}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v0

    invoke-virtual {v0}, Ljava/time/LocalDate;->getDayOfMonth()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v62

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v83

    const/16 v86, 0x0

    const v87, 0x1fffe

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const-wide/16 v67, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    const/16 v71, 0x0

    const-wide/16 v72, 0x0

    const/16 v74, 0x0

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v80, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v85, 0x0

    move-object/from16 v84, v3

    .end local v3    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v84    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v62 .. v87}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .line 27
    .end local v84    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 30
    nop

    .line 154
    .end local v3    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v18    # "$changed\\26":I
    .end local v56    # "$i$a$-Column-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1$2\\26\\154\\14":I
    .end local v58    # "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241_u240_u241\\26":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 183
    .end local v55    # "$changed\\25":I
    .end local v59    # "$composer\\25":Landroidx/compose/runtime/Composer;
    .end local v88    # "$i$a$-Layout-ColumnKt$Column$1\\25\\183\\19":I
    nop

    .line 186
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 163
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 187
    nop

    .line 157
    .end local v51    # "$i$f$ReusableComposeNode\\21\\161":I
    .end local v54    # "$changed\\21":I
    .end local v57    # "factory\\21":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 188
    nop

    .line 151
    .end local v6    # "$changed\\20":I
    .end local v20    # "materialized\\20":Landroidx/compose/ui/Modifier;
    .end local v47    # "$i$f$Layout\\20\\153":I
    .end local v49    # "compositeKeyHash\\20":I
    .end local v52    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v60    # "localMap\\20":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 189
    nop

    .line 30
    .end local v7    # "$composer\\19":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$f$Column\\19\\26":I
    .end local v44    # "modifier\\19":Landroidx/compose/ui/Modifier;
    .end local v45    # "$changed\\19":I
    .end local v46    # "horizontalAlignment\\19":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v48    # "verticalArrangement\\19":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v61    # "measurePolicy\\19":Landroidx/compose/ui/layout/MeasurePolicy;
    nop

    .line 143
    .end local v38    # "day\\14":Lcom/xunji/core/stats/DaySummary;
    .end local v42    # "$i$a$-forEach-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1$1\\14\\143\\12":I
    move/from16 v6, v34

    move-object/from16 v7, v35

    move-object/from16 v5, v37

    move-object/from16 v2, v41

    move/from16 v3, v43

    move-object/from16 v4, v50

    move-object/from16 v0, v53

    const/16 v17, 0x6

    .end local v40    # "element\\13":Ljava/lang/Object;
    goto/16 :goto_207

    .line 190
    .end local v34    # "$changed\\12":I
    .end local v35    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .end local v37    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v41    # "$this$forEach\\13":Ljava/lang/Iterable;
    .end local v43    # "$i$f$forEach\\13\\26":I
    .local v2, "$this$forEach\\13":Ljava/lang/Iterable;
    .local v3, "$i$f$forEach\\13\\26":I
    .local v5, "$composer\\12":Landroidx/compose/runtime/Composer;
    .local v6, "$changed\\12":I
    .local v7, "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    :cond_4d6
    move-object/from16 v41, v2

    move/from16 v43, v3

    move-object/from16 v37, v5

    move/from16 v34, v6

    move-object/from16 v35, v7

    .end local v2    # "$this$forEach\\13":Ljava/lang/Iterable;
    .end local v3    # "$i$f$forEach\\13\\26":I
    .end local v5    # "$composer\\12":Landroidx/compose/runtime/Composer;
    .end local v6    # "$changed\\12":I
    .end local v7    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v34    # "$changed\\12":I
    .restart local v35    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    .restart local v37    # "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v37 .. v37}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 26
    invoke-static/range {v37 .. v37}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 31
    nop

    .line 113
    .end local v29    # "$i$a$-Row-StatisticsScreenKt$StatisticsScreen$1$1$3$1$1\\12\\113\\0":I
    .end local v33    # "$this$StatisticsScreen_u24lambda_u240_u240_u242_u240_u241\\12":Landroidx/compose/foundation/layout/RowScope;
    .end local v34    # "$changed\\12":I
    .end local v37    # "$composer\\12":Landroidx/compose/runtime/Composer;
    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 142
    .end local v26    # "$changed\\11":I
    .end local v30    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v39    # "$i$a$-Layout-RowKt$Row$1\\11\\142\\5":I
    nop

    .line 191
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 122
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 192
    nop

    .line 116
    .end local v13    # "factory\\7":Lkotlin/jvm/functions/Function0;
    .end local v21    # "$i$f$ReusableComposeNode\\7\\120":I
    .end local v28    # "$changed\\7":I
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 193
    nop

    .line 110
    .end local v12    # "materialized\\6":Landroidx/compose/ui/Modifier;
    .end local v14    # "$changed\\6":I
    .end local v15    # "modifier\\6":Landroidx/compose/ui/Modifier;
    .end local v16    # "$i$f$Layout\\6\\112":I
    .end local v19    # "compositeKeyHash\\6":I
    .end local v31    # "localMap\\6":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 194
    nop

    .end local v8    # "$changed\\5":I
    .end local v9    # "$composer\\5":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$Row\\5\\25":I
    .end local v11    # "measurePolicy\\5":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "modifier\\5":Landroidx/compose/ui/Modifier;
    .end local v32    # "horizontalArrangement\\5":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v35    # "verticalAlignment\\5":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_50d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "max":I
    goto :goto_50d

    .line 24
    :cond_504
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0

    .line 23
    :cond_50a
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 32
    :cond_50d
    :goto_50d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StatisticsScreen$lambda$0$0$2$0$1$0$0$0(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 6
    .param p0, "$day"    # Lcom/xunji/core/stats/DaySummary;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 26
    invoke-virtual {p0}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v0

    invoke-virtual {p0}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v1

    invoke-virtual {p0}, Lcom/xunji/core/stats/DaySummary;->getDistinctCards()I

    move-result v2

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, "\uff1a"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u6b21\u8bc4\u5206\uff0c"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5361\u7247"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {p1, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final StatisticsScreen$lambda$0$0$3(Lcom/xunji/core/stats/StatisticsSummary;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 13
    .param p0, "$stats"    # Lcom/xunji/core/stats/StatisticsSummary;
    .param p1, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "i"    # I
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    const-string v0, "$this$items"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "CN(i)32@2647L267,32@2616L298:StatisticsScreen.kt#i35lj1"

    invoke-static {p3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move v0, p4

    .local v0, "$dirty":I
    and-int/lit8 v1, p4, 0x30

    if-nez v1, :cond_1b

    invoke-interface {p3, p2}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v1

    if-eqz v1, :cond_18

    const/16 v1, 0x20

    goto :goto_1a

    :cond_18
    const/16 v1, 0x10

    :goto_1a
    or-int/2addr v0, v1

    :cond_1b
    and-int/lit16 v1, v0, 0x91

    const/16 v2, 0x90

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eq v1, v2, :cond_25

    move v1, v4

    goto :goto_26

    :cond_25
    move v1, v3

    :goto_26
    and-int/lit8 v2, v0, 0x1

    invoke-interface {p3, v1, v2}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_74

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_3d

    const/4 v1, -0x1

    const-string v2, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:32)"

    const v5, -0x655d49ab

    invoke-static {v5, v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_3d
    invoke-virtual {p0}, Lcom/xunji/core/stats/StatisticsSummary;->getLastSevenDays()Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->reversed(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    invoke-interface {v1, p2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Lcom/xunji/core/stats/DaySummary;

    .local v1, "day":Lcom/xunji/core/stats/DaySummary;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v2, v5, v4, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    new-instance v5, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v5, v1}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt$$ExternalSyntheticLambda6;-><init>(Lcom/xunji/core/stats/DaySummary;)V

    const v6, -0x70b466db

    const/16 v7, 0x36

    invoke-static {v6, v4, v5, p3, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function3;

    invoke-static {v2, v4, p3, v7, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_77

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v1    # "day":Lcom/xunji/core/stats/DaySummary;
    goto :goto_77

    :cond_74
    invoke-interface {p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_77
    :goto_77
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final StatisticsScreen$lambda$0$0$3$0(Lcom/xunji/core/stats/DaySummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$day"    # Lcom/xunji/core/stats/DaySummary;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C32@2723L10,32@2649L97,32@2747L93,32@2841L71:StatisticsScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_124

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.StatisticsScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (StatisticsScreen.kt:32)"

    const v6, -0x70b466db

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 33
    :cond_31
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v2

    invoke-virtual {v2}, Ljava/time/LocalDate;->getMonthValue()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getDate()Ljava/time/LocalDate;

    move-result-object v4

    invoke-virtual {v4}, Ljava/time/LocalDate;->getDayOfMonth()I

    move-result v4

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v6, "\u6708"

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v4, "\u65e5"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v0, v6}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    move v7, v5

    const-wide/16 v5, 0x0

    move v8, v7

    const/4 v7, 0x0

    move v9, v8

    const/4 v8, 0x0

    move v10, v9

    const/4 v9, 0x0

    move v12, v10

    const-wide/16 v10, 0x0

    move v13, v12

    const/4 v12, 0x0

    move v14, v13

    const/4 v13, 0x0

    move/from16 v16, v14

    const-wide/16 v14, 0x0

    move/from16 v17, v16

    const/16 v16, 0x0

    move/from16 v18, v17

    const/16 v17, 0x0

    move/from16 v19, v18

    const/16 v18, 0x0

    move/from16 v20, v19

    const/16 v19, 0x0

    move/from16 v22, v20

    const/16 v20, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v0, v22

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getDistinctCards()I

    move-result v2

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getDurationMs()J

    move-result-wide v3

    invoke-static {v3, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->durationLabel(J)Ljava/lang/String;

    move-result-object v3

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v4, " \u6b21\u8bc4\u5206 \u00b7 "

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20\u5361\u7247 \u00b7 "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    const/4 v7, 0x0

    invoke-static {v1, v7, v0, v7, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/stats/DaySummary;->getAgainRatio()Ljava/lang/Double;

    move-result-object v1

    if-eqz v1, :cond_102

    check-cast v1, Ljava/lang/Number;

    invoke-virtual {v1}, Ljava/lang/Number;->doubleValue()D

    move-result-wide v3

    .line 46
    .local v3, "it\\1":D
    const/4 v1, 0x0

    .line 33
    .local v1, "$i$a$-let-StatisticsScreenKt$StatisticsScreen$1$1$4$1$1\\1\\33\\0":I
    const/16 v5, 0x64

    int-to-double v5, v5

    mul-double/2addr v5, v3

    double-to-int v5, v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    const-string v6, "%"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    .end local v1    # "$i$a$-let-StatisticsScreenKt$StatisticsScreen$1$1$4$1$1\\1\\33\\0":I
    .end local v3    # "it\\1":D
    if-nez v1, :cond_104

    :cond_102
    const-string v1, "\u2014"

    :cond_104
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "\u5fd8\u8bb0\u6bd4\u4f8b "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1, v7, v0, v7, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_127

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_127

    :cond_124
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_127
    :goto_127
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final StatisticsScreen$lambda$1(Lcom/xunji/flashcards/ui/MainUiState;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lcom/xunji/flashcards/ui/screens/StatisticsScreenKt;->StatisticsScreen(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

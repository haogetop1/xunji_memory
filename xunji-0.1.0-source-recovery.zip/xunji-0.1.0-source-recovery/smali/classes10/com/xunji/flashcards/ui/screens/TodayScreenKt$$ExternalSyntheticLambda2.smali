.class public final synthetic Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/MainUiState;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$1:Lkotlin/jvm/functions/Function0;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$2:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$1:Lkotlin/jvm/functions/Function0;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;->f$2:Lkotlin/jvm/functions/Function0;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyListScope;

    invoke-static {v0, v1, v2, p1}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->$r8$lambda$1th_yAV_uaO93vZT3gwg4yc28a4(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

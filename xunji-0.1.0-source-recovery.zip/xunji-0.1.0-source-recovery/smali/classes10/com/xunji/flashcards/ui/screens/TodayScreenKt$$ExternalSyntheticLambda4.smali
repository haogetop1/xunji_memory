.class public final synthetic Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/MainUiState;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;->f$0:Lkotlin/jvm/functions/Function0;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;->f$1:Lcom/xunji/flashcards/ui/MainUiState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;->f$0:Lkotlin/jvm/functions/Function0;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;->f$1:Lcom/xunji/flashcards/ui/MainUiState;

    check-cast p1, Landroidx/compose/foundation/lazy/LazyItemScope;

    check-cast p2, Landroidx/compose/runtime/Composer;

    check-cast p3, Ljava/lang/Integer;

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p3

    invoke-static {v0, v1, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->$r8$lambda$UmUVagj3-8QCARisdgMEqUivgf8(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/MainUiState;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;->f$1:Lkotlin/jvm/functions/Function0;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 11

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;->f$0:Lcom/xunji/flashcards/ui/MainUiState;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;->f$1:Lkotlin/jvm/functions/Function0;

    move-object v2, p1

    check-cast v2, Landroidx/compose/foundation/lazy/LazyItemScope;

    check-cast p2, Ljava/lang/Integer;

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result v3

    move-object v4, p3

    check-cast v4, Landroidx/compose/runtime/Composer;

    check-cast p4, Ljava/lang/Integer;

    invoke-virtual {p4}, Ljava/lang/Integer;->intValue()I

    move-result v5

    invoke-static/range {v0 .. v5}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->$r8$lambda$g0kT9culmjEsC0urKpzHlv0U0c0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p1

    return-object p1
.end method

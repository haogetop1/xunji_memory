.class public final Lcom/xunji/flashcards/ui/screens/TodayScreenKt;
.super Ljava/lang/Object;
.source "TodayScreen.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nTodayScreen.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TodayScreen.kt\ncom/xunji/flashcards/ui/screens/TodayScreenKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Row.kt\nandroidx/compose/foundation/layout/RowKt\n*L\n1#1,44:1\n113#2:45\n113#2:52\n113#2:53\n113#2:127\n113#2:250\n113#2:255\n113#2:335\n1282#3,6:46\n87#4:54\n85#4,8:55\n87#4:164\n84#4,9:165\n94#4:204\n87#4:205\n84#4,9:206\n94#4:245\n94#4:254\n87#4:374\n83#4,10:375\n94#4:393\n80#5,6:63\n87#5,3:78\n90#5,2:87\n80#5,6:96\n87#5,3:111\n90#5,2:120\n94#5:125\n80#5,6:137\n87#5,3:152\n90#5,2:161\n80#5,6:174\n87#5,3:189\n90#5,2:198\n94#5:203\n80#5,6:215\n87#5,3:230\n90#5,2:239\n94#5:244\n94#5:248\n94#5:253\n80#5,6:267\n87#5,3:282\n90#5,2:291\n94#5:296\n80#5,6:304\n87#5,3:319\n90#5,2:328\n94#5:333\n80#5,6:347\n87#5,3:362\n90#5,2:371\n87#5,5:385\n94#5:392\n391#6,9:69\n400#6:89\n391#6,9:102\n400#6,3:122\n391#6,9:143\n400#6:163\n391#6,9:180\n400#6,3:200\n391#6,9:221\n400#6,3:241\n401#6,2:246\n401#6,2:251\n391#6,9:273\n400#6,3:293\n391#6,9:310\n400#6,3:330\n391#6,9:353\n400#6:373\n401#6,2:390\n4360#7,6:81\n4360#7,6:114\n4360#7,6:155\n4360#7,6:192\n4360#7,6:233\n4360#7,6:285\n4360#7,6:322\n4360#7,6:365\n99#8,6:90\n106#8:126\n99#8:128\n97#8,8:129\n106#8:249\n99#8:256\n95#8,10:257\n106#8:297\n99#8,6:298\n106#8:334\n99#8:336\n95#8,10:337\n106#8:394\n*S KotlinDebug\n*F\n+ 1 TodayScreen.kt\ncom/xunji/flashcards/ui/screens/TodayScreenKt\n*L\n20#1:45\n24#1:52\n25#1:53\n27#1:127\n31#1:250\n37#1:255\n39#1:335\n20#1:46,6\n25#1:54\n25#1:55,8\n28#1:164\n28#1:165,9\n28#1:204\n29#1:205\n29#1:206,9\n29#1:245\n25#1:254\n39#1:374\n39#1:375,10\n39#1:393\n25#1:63,6\n25#1:78,3\n25#1:87,2\n26#1:96,6\n26#1:111,3\n26#1:120,2\n26#1:125\n27#1:137,6\n27#1:152,3\n27#1:161,2\n28#1:174,6\n28#1:189,3\n28#1:198,2\n28#1:203\n29#1:215,6\n29#1:230,3\n29#1:239,2\n29#1:244\n27#1:248\n25#1:253\n37#1:267,6\n37#1:282,3\n37#1:291,2\n37#1:296\n38#1:304,6\n38#1:319,3\n38#1:328,2\n38#1:333\n39#1:347,6\n39#1:362,3\n39#1:371,2\n39#1:385,5\n39#1:392\n25#1:69,9\n25#1:89\n26#1:102,9\n26#1:122,3\n27#1:143,9\n27#1:163\n28#1:180,9\n28#1:200,3\n29#1:221,9\n29#1:241,3\n27#1:246,2\n25#1:251,2\n37#1:273,9\n37#1:293,3\n38#1:310,9\n38#1:330,3\n39#1:353,9\n39#1:373\n39#1:390,2\n25#1:81,6\n26#1:114,6\n27#1:155,6\n28#1:192,6\n29#1:233,6\n37#1:285,6\n38#1:322,6\n39#1:365,6\n26#1:90,6\n26#1:126\n27#1:128\n27#1:129,8\n27#1:249\n37#1:256\n37#1:257,10\n37#1:297\n38#1:298,6\n38#1:334\n39#1:336\n39#1:337,10\n39#1:394\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0016\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\u001a1\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u000c\u0010\u0004\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u00052\u000c\u0010\u0006\u001a\u0008\u0012\u0004\u0012\u00020\u00010\u0005H\u0007\u00a2\u0006\u0002\u0010\u0007\u00a8\u0006\u0008"
    }
    d2 = {
        "TodayScreen",
        "",
        "state",
        "Lcom/xunji/flashcards/ui/MainUiState;",
        "onReview",
        "Lkotlin/Function0;",
        "onDecks",
        "(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$1th_yAV_uaO93vZT3gwg4yc28a4(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Gf_qssF9dPobiAPKgwnFLmZeOJ0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$2(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LhEjAz2swQs_1GzGLv6OPr00IAQ(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$PCJ6jDysLKBNVHD7jVgAB0VF1wY(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$PSGVL-4-qyrRziE8GmtqUOzyHIw(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$3(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Qsel8oDS7JX0dKVnq8rH1_iXXcU(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$4(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TvNczJDOlIC-WfrPPrDLM7DUfpk(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$1$0(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$UmUVagj3-8QCARisdgMEqUivgf8(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$1(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$g0kT9culmjEsC0urKpzHlv0U0c0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$5(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$gtcRRo3voNAyAgxfEeU6hjMo3E4(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$5$0(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$p3knnEQEKzNQgIAWqwOZNkxmirs(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$2(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$uhCj7U6EVsOiIiX3kdKKxcKUVDQ(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$1$0$0$2(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$y1H4TZqkyBPf8fZCesa5B2Yajh0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen$lambda$1$0$3$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final TodayScreen(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V
    .registers 24
    .param p0, "state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "onReview"    # Lkotlin/jvm/functions/Function0;
    .param p2, "onDecks"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/MainUiState;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "I)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v2, p2

    move/from16 v3, p4

    const-string v4, "state"

    invoke-static {v0, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onReview"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onDecks"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 18
    const v4, 0x79144673

    move-object/from16 v5, p3

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v15

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(TodayScreen)N(state,onReview,onDecks)19@867L2825,19@730L2962:TodayScreen.kt#i35lj1"

    invoke-static {v15, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p4

    .local v5, "$dirty":I
    and-int/lit8 v6, v3, 0x6

    if-nez v6, :cond_35

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_33

    const/4 v6, 0x4

    goto :goto_34

    :cond_33
    const/4 v6, 0x2

    :goto_34
    or-int/2addr v5, v6

    :cond_35
    and-int/lit8 v6, v3, 0x30

    const/16 v7, 0x20

    if-nez v6, :cond_46

    invoke-interface {v15, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_43

    move v6, v7

    goto :goto_45

    :cond_43
    const/16 v6, 0x10

    :goto_45
    or-int/2addr v5, v6

    :cond_46
    and-int/lit16 v6, v3, 0x180

    const/16 v8, 0x100

    if-nez v6, :cond_57

    invoke-interface {v15, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_54

    move v6, v8

    goto :goto_56

    :cond_54
    const/16 v6, 0x80

    :goto_56
    or-int/2addr v5, v6

    :cond_57
    and-int/lit16 v6, v5, 0x93

    const/16 v9, 0x92

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-eq v6, v9, :cond_61

    move v6, v11

    goto :goto_62

    :cond_61
    move v6, v10

    :goto_62
    and-int/lit8 v9, v5, 0x1

    invoke-interface {v15, v6, v9}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_14a

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_76

    const/4 v6, -0x1

    const-string v9, "com.xunji.flashcards.ui.screens.TodayScreen (TodayScreen.kt:17)"

    invoke-static {v4, v5, v6, v9}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 19
    :cond_76
    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/MainUiState;->getLoading()Z

    move-result v4

    if-eqz v4, :cond_a5

    const v4, 0x1e73a35e

    invoke-interface {v15, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v4, "18@713L6"

    invoke-static {v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {v15, v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_96

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 43
    :cond_96
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v4

    if-eqz v4, :cond_a4

    new-instance v6, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda1;

    invoke-direct {v6, v0, v1, v2, v3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda1;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v4, v6}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    .line 19
    :cond_a4
    return-void

    :cond_a5
    const v4, 0x1e68da4f

    invoke-interface {v15, v4}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 20
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v9, 0x0

    invoke-static {v4, v6, v11, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const/16 v6, 0x16

    .local v6, "$this$dp\\1":I
    const/4 v9, 0x0

    .line 45
    .local v9, "$i$f$getDp\\1\\20":I
    int-to-float v12, v6

    invoke-static {v12}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 20
    .end local v6    # "$this$dp\\1":I
    .end local v9    # "$i$f$getDp\\1\\20":I
    const/16 v9, 0x12

    .local v9, "$this$dp\\2":I
    const/4 v12, 0x0

    .line 45
    .local v12, "$i$f$getDp\\2\\20":I
    int-to-float v13, v9

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 20
    .end local v9    # "$this$dp\\2":I
    .end local v12    # "$i$f$getDp\\2\\20":I
    const/16 v12, 0x16

    .local v12, "$this$dp\\3":I
    const/4 v13, 0x0

    .line 45
    .local v13, "$i$f$getDp\\3\\20":I
    int-to-float v14, v12

    invoke-static {v14}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v12

    .line 20
    .end local v12    # "$this$dp\\3":I
    .end local v13    # "$i$f$getDp\\3\\20":I
    const/16 v13, 0x1c

    .local v13, "$this$dp\\4":I
    const/4 v14, 0x0

    .line 45
    .local v14, "$i$f$getDp\\4\\20":I
    int-to-float v10, v13

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 20
    .end local v13    # "$this$dp\\4":I
    .end local v14    # "$i$f$getDp\\4\\20":I
    invoke-static {v6, v9, v12, v10}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-a9UjIt4(FFFF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v6

    sget-object v9, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v10, 0x16

    .local v10, "$this$dp\\5":I
    const/4 v12, 0x0

    .line 45
    .local v12, "$i$f$getDp\\5\\20":I
    int-to-float v13, v10

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 20
    .end local v10    # "$this$dp\\5":I
    .end local v12    # "$i$f$getDp\\5\\20":I
    invoke-virtual {v9, v10}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v9

    check-cast v9, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    const v10, -0x7ae36064

    const-string v12, "CC(remember):TodayScreen.kt#9igjgp"

    invoke-static {v15, v10, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    and-int/lit8 v12, v5, 0x70

    if-ne v12, v7, :cond_fe

    move v7, v11

    goto :goto_ff

    :cond_fe
    const/4 v7, 0x0

    :goto_ff
    or-int/2addr v7, v10

    and-int/lit16 v10, v5, 0x380

    if-ne v10, v8, :cond_106

    move v10, v11

    goto :goto_107

    :cond_106
    const/4 v10, 0x0

    :goto_107
    or-int/2addr v7, v10

    .local v7, "invalid\\6":Z
    move-object v8, v15

    .local v8, "$this$cache\\6":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 46
    .local v10, "$i$f$cache\\6\\20":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\6":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 47
    .local v12, "$i$a$-let-ComposerKt$cache$1\\7\\46\\6":I
    if-nez v7, :cond_11b

    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_11a

    goto :goto_11b

    .line 51
    :cond_11a
    goto :goto_126

    .line 48
    :cond_11b
    :goto_11b
    const/4 v13, 0x0

    .line 20
    .local v13, "$i$a$-cache-TodayScreenKt$TodayScreen$2\\8\\48\\0":I
    new-instance v14, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;

    invoke-direct {v14, v0, v1, v2}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda2;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;)V

    .line 48
    .end local v13    # "$i$a$-cache-TodayScreenKt$TodayScreen$2\\8\\48\\0":I
    nop

    .line 49
    .local v14, "value\\7":Ljava/lang/Object;
    invoke-interface {v8, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 50
    move-object v11, v14

    .line 46
    .end local v11    # "it\\6":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\7\\46\\6":I
    .end local v14    # "value\\7":Ljava/lang/Object;
    :goto_126
    nop

    .line 20
    .end local v7    # "invalid\\6":Z
    .end local v8    # "$this$cache\\6":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\6\\20":I
    move-object v14, v11

    check-cast v14, Lkotlin/jvm/functions/Function1;

    invoke-static {v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/16 v16, 0x6186

    const/16 v17, 0x1ea

    move-object v7, v6

    const/4 v6, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    move/from16 v18, v5

    move-object v5, v4

    move/from16 v4, v18

    .end local v5    # "$dirty":I
    .local v4, "$dirty":I
    invoke-static/range {v5 .. v17}, Landroidx/compose/foundation/lazy/LazyDslKt;->LazyColumn(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValues;ZLandroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/foundation/gestures/FlingBehavior;ZLandroidx/compose/foundation/OverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_14e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_14e

    .line 18
    .end local v4    # "$dirty":I
    .restart local v5    # "$dirty":I
    :cond_14a
    move v4, v5

    .end local v5    # "$dirty":I
    .restart local v4    # "$dirty":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 43
    :cond_14e
    :goto_14e
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v5

    if-eqz v5, :cond_15c

    new-instance v6, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda3;

    invoke-direct {v6, v0, v1, v2, v3}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda3;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;I)V

    invoke-interface {v5, v6}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_15c
    return-void
.end method

.method private static final TodayScreen$lambda$0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyListScope;)Lkotlin/Unit;
    .registers 12
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$onReview"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$onDecks"    # Lkotlin/jvm/functions/Function0;
    .param p3, "$this$LazyColumn"    # Landroidx/compose/foundation/lazy/LazyListScope;

    const-string v0, "$this$LazyColumn"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 21
    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->getLambda$-2076728066$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 22
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/MainUiState;->getError()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    if-eqz v0, :cond_31

    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda0;

    invoke-direct {v0, p0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/flashcards/ui/MainUiState;)V

    const v1, 0x6d158f43

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 23
    :cond_31
    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;

    invoke-direct {v0, p1, p0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda4;-><init>(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;)V

    const v1, 0x5465d9e7

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 35
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/MainUiState;->getCards()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_6a

    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda5;

    invoke-direct {v0, p2}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda5;-><init>(Lkotlin/jvm/functions/Function0;)V

    const v1, 0x7d7246ec

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    goto :goto_b7

    .line 37
    :cond_6a
    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda6;

    invoke-direct {v0, p0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda6;-><init>(Lcom/xunji/flashcards/ui/MainUiState;)V

    const v1, -0x2b8ea43d

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 38
    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda7;

    invoke-direct {v0, p2}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda7;-><init>(Lkotlin/jvm/functions/Function0;)V

    const v1, -0x446abe94

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v4, v0

    check-cast v4, Lkotlin/jvm/functions/Function3;

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 39
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v0

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v1, 0x2

    invoke-static {v1, v0}, Ljava/lang/Math;->min(II)I

    move-result v2

    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;

    invoke-direct {v0, p0, p2}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;)V

    const v1, -0x3279f966

    invoke-static {v1, v7, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->composableLambdaInstance(IZLjava/lang/Object;)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v5, v0

    check-cast v5, Lkotlin/jvm/functions/Function4;

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v7}, Landroidx/compose/foundation/lazy/LazyListScope;->items$default(Landroidx/compose/foundation/lazy/LazyListScope;ILkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function4;ILjava/lang/Object;)V

    .line 41
    :goto_b7
    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->getLambda$1071045318$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v1, p3

    invoke-static/range {v1 .. v6}, Landroidx/compose/foundation/lazy/LazyListScope;->item$default(Landroidx/compose/foundation/lazy/LazyListScope;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function3;ILjava/lang/Object;)V

    .line 42
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C21@1085L24:TodayScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_3f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:21)"

    const v4, 0x6d158f43

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 22
    :cond_2c
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/MainUiState;->getError()Ljava/lang/String;

    move-result-object v0

    const/16 v1, 0x30

    invoke-static {v0, v3, p2, v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_42

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_42

    :cond_3f
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_42
    :goto_42
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$1(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 21
    .param p0, "$onReview"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p2, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v10, p3

    move/from16 v13, p4

    const-string v0, "$this$item"

    move-object/from16 v14, p2

    invoke-static {v14, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C23@1184L11,23@1205L1342,23@1124L1423:TodayScreen.kt#i35lj1"

    invoke-static {v10, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, v13, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x1

    if-eq v0, v1, :cond_19

    move v0, v2

    goto :goto_1a

    :cond_19
    const/4 v0, 0x0

    :goto_1a
    and-int/lit8 v1, v13, 0x1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_79

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_31

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:23)"

    const v3, 0x5465d9e7

    invoke-static {v3, v13, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 24
    :cond_31
    const/16 v0, 0x1c

    .local v0, "$this$dp\\1":I
    const/4 v1, 0x0

    .line 52
    .local v1, "$i$f$getDp\\1\\24":I
    int-to-float v3, v0

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 24
    .end local v0    # "$this$dp\\1":I
    .end local v1    # "$i$f$getDp\\1\\24":I
    invoke-static {v0}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v0

    move-object v1, v0

    check-cast v1, Landroidx/compose/ui/graphics/Shape;

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v10, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v3

    new-instance v0, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda12;

    move-object/from16 v15, p0

    move-object/from16 v5, p1

    invoke-direct {v0, v15, v5}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda12;-><init>(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;)V

    const/16 v6, 0x36

    const v7, -0x5ebb9914

    invoke-static {v7, v2, v0, v10, v6}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    move-object v9, v0

    check-cast v9, Lkotlin/jvm/functions/Function2;

    const/high16 v11, 0xc00000

    const/16 v12, 0x79

    const/4 v0, 0x0

    move-wide v2, v3

    const-wide/16 v4, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static/range {v0 .. v12}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_7e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_7e

    .line 23
    :cond_79
    move-object/from16 v15, p0

    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 34
    :cond_7e
    :goto_7e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$1$0(Lkotlin/jvm/functions/Function0;Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 111
    .param p0, "$onReview"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "C24@1211L1331:TodayScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eq v2, v5, :cond_12

    move v2, v4

    goto :goto_13

    :cond_12
    move v2, v3

    :goto_13
    and-int/lit8 v6, v1, 0x1

    invoke-interface {v0, v2, v6}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_839

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_2a

    const/4 v2, -0x1

    const-string v6, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:24)"

    const v7, -0x5ebb9914

    invoke-static {v7, v1, v2, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 25
    :cond_2a
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v2, v6, v4, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v8, 0x18

    .local v8, "$this$dp\\1":I
    const/4 v9, 0x0

    .line 53
    .local v9, "$i$f$getDp\\1\\25":I
    int-to-float v10, v8

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 25
    .end local v8    # "$this$dp\\1":I
    .end local v9    # "$i$f$getDp\\1\\25":I
    invoke-static {v2, v8}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v8, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v9, 0x18

    .local v9, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 53
    .local v10, "$i$f$getDp\\2\\25":I
    int-to-float v11, v9

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v9

    .line 25
    .end local v9    # "$this$dp\\2":I
    .end local v10    # "$i$f$getDp\\2\\25":I
    invoke-virtual {v8, v9}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v8

    check-cast v8, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v8, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v9, 0x36

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v9, "$changed\\3":I
    move-object/from16 v10, p2

    .local v10, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v11, 0x0

    .line 54
    .local v11, "$i$f$Column\\3\\25":I
    const v12, 0x4ff7456f

    const-string v13, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v10, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 55
    sget-object v14, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v14

    .line 58
    .local v14, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v15, v9, 0x3

    and-int/lit8 v15, v15, 0xe

    shr-int/lit8 v16, v9, 0x3

    and-int/lit8 v16, v16, 0x70

    or-int v15, v15, v16

    invoke-static {v8, v14, v10, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v15

    .line 62
    .local v15, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v9, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 59
    nop

    .local v16, "$changed\\4":I
    move-object/from16 v17, v2

    .local v17, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    .line 63
    .local v18, "$i$f$Layout\\4\\59":I
    const v5, -0x451e1427

    const-string v12, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v10, v5, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 64
    invoke-static {v10, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v20

    invoke-static/range {v20 .. v21}, Ljava/lang/Long;->hashCode(J)I

    move-result v20

    .line 65
    .local v20, "compositeKeyHash\\4":I
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v3

    .line 66
    .local v3, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v5, v17

    .end local v17    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v5, "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v10, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 68
    .local v4, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v23, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v23 .. v23}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v23

    shl-int/lit8 v6, v16, 0x6

    and-int/lit16 v6, v6, 0x380

    or-int/lit8 v6, v6, 0x6

    .line 67
    move-object/from16 v24, v23

    .local v6, "$changed\\5":I
    .local v24, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v23, 0x0

    .line 69
    .local v23, "$i$f$ReusableComposeNode\\5\\67":I
    const v7, -0x20f7d59c

    const-string v0, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v10, v7, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 70
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_b7

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 71
    :cond_b7
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 72
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_c6

    .line 73
    move-object/from16 v7, v24

    .end local v24    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v7, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10, v7}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_cb

    .line 75
    .end local v7    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v24    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_c6
    move-object/from16 v7, v24

    .end local v24    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 77
    :goto_cb
    invoke-static {v10}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 78
    .local v24, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\77\\4":I
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v27, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v27, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v15, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 79
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v3, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 80
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v26, 0x0

    .line 81
    .local v26, "$i$f$set-impl\\7\\80":I
    move-object/from16 v28, v1

    .local v28, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 82
    .local v29, "$i$a$-with-Updater$set$1\\8\\81\\7":I
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v30

    if-nez v30, :cond_10d

    move-object/from16 v30, v3

    .end local v3    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .local v30, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v28 .. v28}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v31, v5

    .end local v5    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .local v31, "modifier\\4":Landroidx/compose/ui/Modifier;
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_10a

    goto :goto_111

    :cond_10a
    move-object/from16 v5, v28

    goto :goto_121

    .end local v30    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v31    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .restart local v3    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v5    # "modifier\\4":Landroidx/compose/ui/Modifier;
    :cond_10d
    move-object/from16 v30, v3

    move-object/from16 v31, v5

    .line 83
    .end local v3    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v5    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .restart local v30    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v31    # "modifier\\4":Landroidx/compose/ui/Modifier;
    :goto_111
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v5, v28

    .end local v28    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v5, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v5, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 84
    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 86
    :goto_121
    nop

    .line 81
    .end local v5    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-with-Updater$set$1\\8\\81\\7":I
    nop

    .line 86
    nop

    .line 87
    .end local v2    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v26    # "$i$f$set-impl\\7\\80":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v4, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 88
    nop

    .line 77
    .end local v1    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\77\\4":I
    nop

    .line 89
    shr-int/lit8 v1, v6, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\9":I
    move-object v2, v10

    .local v2, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 60
    .local v3, "$i$a$-Layout-ColumnKt$Column$1\\9\\89\\3":I
    const v5, 0x7cc0ae6e

    move/from16 v24, v1

    .end local v1    # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v1, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v26, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v28, v9, 0x6

    and-int/lit8 v28, v28, 0x70

    or-int/lit8 v28, v28, 0x6

    .local v28, "$changed\\10":I
    check-cast v26, Landroidx/compose/foundation/layout/ColumnScope;

    .local v26, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v41, v2

    .local v41, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v29, 0x0

    .line 26
    .local v29, "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1\\10\\60\\0":I
    const v5, 0x22f9249a

    move-object/from16 v45, v2

    .end local v2    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v2, "C25@1313L237,26@1556L424,30@2181L11,30@2231L11,30@2288L11,30@2363L11,30@2139L244,30@2385L151,30@1986L550:TodayScreen.kt#i35lj1"

    move/from16 v46, v3

    move-object/from16 v3, v41

    .end local v41    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v46, "$i$a$-Layout-ColumnKt$Column$1\\9\\89\\3":I
    invoke-static {v3, v5, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v47, v4

    move/from16 v48, v6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    .end local v4    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v6    # "$changed\\5":I
    .local v47, "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v48, "$changed\\5":I
    invoke-static {v2, v4, v6, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\11":Landroidx/compose/ui/Modifier;
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v4, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .local v5, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v6, 0x1b6

    .local v6, "$changed\\11":I
    move-object/from16 v33, v3

    .local v33, "$composer\\11":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 90
    .local v34, "$i$f$Row\\11\\26":I
    move-object/from16 v35, v2

    .end local v2    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v35, "modifier\\11":Landroidx/compose/ui/Modifier;
    const v2, 0x3255a44b

    move/from16 v36, v6

    .end local v6    # "$changed\\11":I
    .local v36, "$changed\\11":I
    const-string v6, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    move-object/from16 v49, v7

    move-object/from16 v7, v33

    .end local v33    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v7, "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v49, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v7, v2, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 91
    shr-int/lit8 v33, v36, 0x3

    and-int/lit8 v33, v33, 0xe

    shr-int/lit8 v37, v36, 0x3

    and-int/lit8 v37, v37, 0x70

    or-int v2, v33, v37

    invoke-static {v4, v5, v7, v2}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .line 95
    .local v2, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v33, v36, 0x3

    and-int/lit8 v33, v33, 0x70

    .line 92
    move-object/from16 v37, v35

    .local v33, "$changed\\12":I
    .local v37, "modifier\\12":Landroidx/compose/ui/Modifier;
    const/16 v39, 0x0

    .line 96
    .local v39, "$i$f$Layout\\12\\92":I
    move-object/from16 v40, v4

    const v4, -0x451e1427

    .end local v4    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v40, "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 97
    const/4 v4, 0x0

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v41

    invoke-static/range {v41 .. v42}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 98
    .local v4, "compositeKeyHash\\12":I
    move/from16 v41, v4

    .end local v4    # "compositeKeyHash\\12":I
    .local v41, "compositeKeyHash\\12":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 99
    .local v4, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v42, v5

    move-object/from16 v50, v8

    move-object/from16 v5, v37

    .end local v8    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v37    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v5, "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v42, "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .local v50, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v7, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 101
    .local v8, "materialized\\12":Landroidx/compose/ui/Modifier;
    sget-object v37, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v37 .. v37}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v37

    move-object/from16 v43, v5

    .end local v5    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .local v43, "modifier\\12":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v33, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 100
    nop

    .local v5, "$changed\\13":I
    move-object/from16 v44, v37

    .local v44, "factory\\13":Lkotlin/jvm/functions/Function0;
    const/16 v37, 0x0

    .line 102
    .local v37, "$i$f$ReusableComposeNode\\13\\100":I
    move/from16 v51, v5

    const v5, -0x20f7d59c

    .end local v5    # "$changed\\13":I
    .local v51, "$changed\\13":I
    invoke-static {v7, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 103
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_1eb

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 104
    :cond_1eb
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 105
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_1fa

    .line 106
    move-object/from16 v5, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1ff

    .line 108
    .end local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    :cond_1fa
    move-object/from16 v5, v44

    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 110
    :goto_1ff
    move-object/from16 v44, v5

    .end local v5    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .restart local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v52, 0x0

    .line 111
    .local v52, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\110\\12":I
    sget-object v53, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v54, v7

    .end local v7    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\11":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v53 .. v53}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v2, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 112
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 113
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\15":Lkotlin/jvm/functions/Function2;
    const/16 v53, 0x0

    .line 114
    .local v53, "$i$f$set-impl\\15\\113":I
    move-object/from16 v55, v5

    .local v55, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 115
    .local v56, "$i$a$-with-Updater$set$1\\16\\114\\15":I
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v57

    if-nez v57, :cond_243

    move-object/from16 v57, v2

    .end local v2    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v57, "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v55 .. v55}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v58, v4

    .end local v4    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .local v58, "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_240

    goto :goto_247

    :cond_240
    move-object/from16 v4, v55

    goto :goto_257

    .end local v57    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v58    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_243
    move-object/from16 v57, v2

    move-object/from16 v58, v4

    .line 116
    .end local v2    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v57    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v58    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_247
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v55

    .end local v55    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 117
    invoke-static/range {v41 .. v41}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v5, v2, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 119
    :goto_257
    nop

    .line 114
    .end local v4    # "$this$set_impl_u24lambda_u240\\15":Landroidx/compose/runtime/Composer;
    .end local v56    # "$i$a$-with-Updater$set$1\\16\\114\\15":I
    nop

    .line 119
    nop

    .line 120
    .end local v7    # "block\\15":Lkotlin/jvm/functions/Function2;
    .end local v53    # "$i$f$set-impl\\15\\113":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v5, v8, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 121
    nop

    .line 110
    .end local v5    # "$this$Layout_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v52    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\14\\110\\12":I
    nop

    .line 122
    shr-int/lit8 v2, v51, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\17":I
    move-object/from16 v4, v54

    .local v4, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 93
    .local v5, "$i$a$-Layout-RowKt$Row$1\\17\\122\\11":I
    const v7, 0x56ccd6f5

    move/from16 v52, v2

    .end local v2    # "$changed\\17":I
    .local v52, "$changed\\17":I
    const-string v2, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v4, v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v53, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v55, v36, 0x6

    and-int/lit8 v55, v55, 0x70

    or-int/lit8 v55, v55, 0x6

    .local v55, "$changed\\18":I
    check-cast v53, Landroidx/compose/foundation/layout/RowScope;

    .local v53, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v81, v4

    .local v81, "$composer\\18":Landroidx/compose/runtime/Composer;
    const/16 v56, 0x0

    .line 26
    .local v56, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$1\\18\\93\\10":I
    const v7, -0x53911833

    move-object/from16 v86, v4

    .end local v4    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v86, "$composer\\17":Landroidx/compose/runtime/Composer;
    const-string v4, "C25@1469L10,25@1436L56,25@1526L11,25@1493L55:TodayScreen.kt#i35lj1"

    move/from16 v87, v5

    move-object/from16 v5, v81

    .end local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v87, "$i$a$-Layout-RowKt$Row$1\\17\\122\\11":I
    invoke-static {v5, v7, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v5, v7}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v80

    const/16 v83, 0x0

    const v84, 0x1fffe

    const-string v59, "\u4eca\u5929\u7684\u5b66\u4e60"

    const/16 v60, 0x0

    const-wide/16 v61, 0x0

    const/16 v63, 0x0

    const-wide/16 v64, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const-wide/16 v69, 0x0

    const/16 v71, 0x0

    const/16 v72, 0x0

    const-wide/16 v73, 0x0

    const/16 v75, 0x0

    const/16 v76, 0x0

    const/16 v77, 0x0

    const/16 v78, 0x0

    const/16 v79, 0x0

    const/16 v82, 0x6

    .end local v5    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v59 .. v84}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v81    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\18":Landroidx/compose/runtime/Composer;
    sget-object v4, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v4, v5, v7}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v4

    invoke-virtual {v4}, Landroidx/compose/material3/ColorScheme;->getOnPrimary-0d7_KjU()J

    move-result-wide v61

    const/16 v64, 0x6

    const/16 v65, 0x2

    const-string v59, "leaf"

    move-object/from16 v63, v5

    .end local v5    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .local v63, "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static/range {v59 .. v65}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    .end local v63    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\18":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 93
    .end local v5    # "$composer\\18":Landroidx/compose/runtime/Composer;
    .end local v53    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u240\\18":Landroidx/compose/foundation/layout/RowScope;
    .end local v55    # "$changed\\18":I
    .end local v56    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$1\\18\\93\\10":I
    invoke-static/range {v86 .. v86}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 122
    .end local v52    # "$changed\\17":I
    .end local v86    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v87    # "$i$a$-Layout-RowKt$Row$1\\17\\122\\11":I
    nop

    .line 123
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 102
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 124
    nop

    .line 96
    .end local v37    # "$i$f$ReusableComposeNode\\13\\100":I
    .end local v44    # "factory\\13":Lkotlin/jvm/functions/Function0;
    .end local v51    # "$changed\\13":I
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 125
    nop

    .line 90
    .end local v8    # "materialized\\12":Landroidx/compose/ui/Modifier;
    .end local v33    # "$changed\\12":I
    .end local v39    # "$i$f$Layout\\12\\92":I
    .end local v41    # "compositeKeyHash\\12":I
    .end local v43    # "modifier\\12":Landroidx/compose/ui/Modifier;
    .end local v58    # "localMap\\12":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v54 .. v54}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 126
    nop

    .line 27
    .end local v34    # "$i$f$Row\\11\\26":I
    .end local v35    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v36    # "$changed\\11":I
    .end local v40    # "horizontalArrangement\\11":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v42    # "verticalAlignment\\11":Landroidx/compose/ui/Alignment$Vertical;
    .end local v54    # "$composer\\11":Landroidx/compose/runtime/Composer;
    .end local v57    # "measurePolicy\\11":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v4, v7, v8, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    sget-object v5, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v7, 0x18

    .local v7, "$this$dp\\19":I
    const/4 v8, 0x0

    .line 127
    .local v8, "$i$f$getDp\\19\\27":I
    move-object/from16 v33, v4

    int-to-float v4, v7

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v4

    .line 27
    .end local v7    # "$this$dp\\19":I
    .end local v8    # "$i$f$getDp\\19\\27":I
    invoke-virtual {v5, v4}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v4, "horizontalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v5, 0x36

    .local v5, "$changed\\20":I
    .local v33, "modifier\\20":Landroidx/compose/ui/Modifier;
    move-object v7, v3

    .local v7, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 128
    .local v8, "$i$f$Row\\20\\27":I
    move/from16 v34, v5

    const v5, 0x3255a44b

    .end local v5    # "$changed\\20":I
    .local v34, "$changed\\20":I
    invoke-static {v7, v5, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 129
    sget-object v5, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v5

    .line 132
    .local v5, "verticalAlignment\\20":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v6, v34, 0x3

    and-int/lit8 v6, v6, 0xe

    shr-int/lit8 v35, v34, 0x3

    and-int/lit8 v35, v35, 0x70

    or-int v6, v6, v35

    invoke-static {v4, v5, v7, v6}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 136
    .local v6, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v35, v34, 0x3

    and-int/lit8 v35, v35, 0x70

    .line 133
    move-object/from16 v36, v33

    .local v35, "$changed\\21":I
    .local v36, "modifier\\21":Landroidx/compose/ui/Modifier;
    const/16 v37, 0x0

    .line 137
    .local v37, "$i$f$Layout\\21\\133":I
    move-object/from16 v38, v4

    const v4, -0x451e1427

    .end local v4    # "horizontalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v38, "horizontalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {v7, v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 138
    const/4 v4, 0x0

    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v39

    invoke-static/range {v39 .. v40}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 139
    .local v4, "compositeKeyHash\\21":I
    move/from16 v39, v4

    .end local v4    # "compositeKeyHash\\21":I
    .local v39, "compositeKeyHash\\21":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 140
    .local v4, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v40, v5

    move-object/from16 v5, v36

    move/from16 v36, v8

    .end local v8    # "$i$f$Row\\20\\27":I
    .local v5, "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v36, "$i$f$Row\\20\\27":I
    .local v40, "verticalAlignment\\20":Landroidx/compose/ui/Alignment$Vertical;
    invoke-static {v7, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    .line 142
    .local v8, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v41

    move-object/from16 v42, v5

    .end local v5    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v42, "modifier\\21":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v35, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 141
    nop

    .local v5, "$changed\\22":I
    move-object/from16 v43, v41

    .local v43, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v41, 0x0

    .line 143
    .local v41, "$i$f$ReusableComposeNode\\22\\141":I
    move/from16 v44, v5

    const v5, -0x20f7d59c

    .end local v5    # "$changed\\22":I
    .local v44, "$changed\\22":I
    invoke-static {v7, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 144
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_383

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 145
    :cond_383
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 146
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_392

    .line 147
    move-object/from16 v5, v43

    .end local v43    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_397

    .line 149
    .end local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v43    # "factory\\22":Lkotlin/jvm/functions/Function0;
    :cond_392
    move-object/from16 v5, v43

    .end local v43    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 151
    :goto_397
    move-object/from16 v43, v5

    .end local v5    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v43    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v5

    .local v5, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v51, 0x0

    .line 152
    .local v51, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\151\\21":I
    sget-object v52, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v53, v7

    .end local v7    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v53, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v52 .. v52}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v6, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 153
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    invoke-static {v5, v4, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 154
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v7

    .local v7, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v52, 0x0

    .line 155
    .local v52, "$i$f$set-impl\\24\\154":I
    move-object/from16 v54, v5

    .local v54, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v55, 0x0

    .line 156
    .local v55, "$i$a$-with-Updater$set$1\\25\\155\\24":I
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v56

    if-nez v56, :cond_3db

    move-object/from16 v56, v4

    .end local v4    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v56, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v54 .. v54}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v57, v6

    .end local v6    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v57, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_3d8

    goto :goto_3df

    :cond_3d8
    move-object/from16 v6, v54

    goto :goto_3ef

    .end local v56    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v57    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_3db
    move-object/from16 v56, v4

    move-object/from16 v57, v6

    .line 157
    .end local v4    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v56    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v57    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_3df
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v6, v54

    .end local v54    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 158
    invoke-static/range {v39 .. v39}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v5, v4, v7}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 160
    :goto_3ef
    nop

    .line 155
    .end local v6    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v55    # "$i$a$-with-Updater$set$1\\25\\155\\24":I
    nop

    .line 160
    nop

    .line 161
    .end local v7    # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v52    # "$i$f$set-impl\\24\\154":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v5, v8, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 162
    nop

    .line 151
    .end local v5    # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v51    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\151\\21":I
    nop

    .line 163
    shr-int/lit8 v4, v44, 0x6

    and-int/lit8 v4, v4, 0xe

    .local v4, "$changed\\26":I
    move-object/from16 v5, v53

    .local v5, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 134
    .local v6, "$i$a$-Layout-RowKt$Row$1\\26\\163\\20":I
    const v7, 0x56ccd6f5

    invoke-static {v5, v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v7, v34, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v7, v7, 0x6

    .local v7, "$changed\\27":I
    check-cast v2, Landroidx/compose/foundation/layout/RowScope;

    .local v2, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241\\27":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v51, v5

    .local v51, "$composer\\27":Landroidx/compose/runtime/Composer;
    move-object/from16 v58, v2

    .end local v2    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241\\27":Landroidx/compose/foundation/layout/RowScope;
    .local v58, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241\\27":Landroidx/compose/foundation/layout/RowScope;
    const/4 v2, 0x0

    .line 28
    .local v2, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$2\\27\\134\\10":I
    move/from16 v52, v2

    .end local v2    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$2\\27\\134\\10":I
    .local v52, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$2\\27\\134\\10":I
    const v2, 0x7f33a65c

    move/from16 v54, v4

    .end local v4    # "$changed\\26":I
    .local v54, "$changed\\26":I
    const-string v4, "C27@1643L157,28@1807L166:TodayScreen.kt#i35lj1"

    move-object/from16 v55, v5

    .end local v51    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v59, v2

    check-cast v59, Landroidx/compose/ui/Modifier;

    const/16 v62, 0x2

    const/16 v63, 0x0

    const/high16 v60, 0x3f800000    # 1.0f

    const/16 v61, 0x0

    invoke-static/range {v58 .. v63}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\28":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\28":I
    .local v51, "$composer\\28":Landroidx/compose/runtime/Composer;
    const/16 v59, 0x0

    .line 164
    .local v59, "$i$f$Column\\28\\28":I
    move-object/from16 v60, v2

    move-object/from16 v2, v51

    move/from16 v51, v4

    const v4, 0x4ff7456f

    .end local v4    # "$changed\\28":I
    .local v2, "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v51, "$changed\\28":I
    .local v60, "modifier\\28":Landroidx/compose/ui/Modifier;
    invoke-static {v2, v4, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 165
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 166
    .local v4, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v61, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v64, v5

    .end local v5    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .local v64, "$composer\\27":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v61 .. v61}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v5

    .line 169
    .local v5, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v61, v51, 0x3

    and-int/lit8 v61, v61, 0xe

    shr-int/lit8 v62, v51, 0x3

    and-int/lit8 v62, v62, 0x70

    move/from16 v65, v6

    .end local v6    # "$i$a$-Layout-RowKt$Row$1\\26\\163\\20":I
    .local v65, "$i$a$-Layout-RowKt$Row$1\\26\\163\\20":I
    or-int v6, v61, v62

    invoke-static {v4, v5, v2, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v6

    .line 173
    .local v6, "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v61, v51, 0x3

    and-int/lit8 v61, v61, 0x70

    .line 170
    nop

    .local v61, "$changed\\29":I
    move-object/from16 v62, v60

    .local v62, "modifier\\29":Landroidx/compose/ui/Modifier;
    const/16 v63, 0x0

    .line 174
    .local v63, "$i$f$Layout\\29\\170":I
    move-object/from16 v66, v4

    const v4, -0x451e1427

    .end local v4    # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v66, "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v2, v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 175
    const/4 v4, 0x0

    invoke-static {v2, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v67

    invoke-static/range {v67 .. v68}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 176
    .local v4, "compositeKeyHash\\29":I
    move/from16 v67, v4

    .end local v4    # "compositeKeyHash\\29":I
    .local v67, "compositeKeyHash\\29":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 177
    .local v4, "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v68, v5

    move/from16 v69, v7

    move-object/from16 v5, v62

    .end local v7    # "$changed\\27":I
    .end local v62    # "modifier\\29":Landroidx/compose/ui/Modifier;
    .local v5, "modifier\\29":Landroidx/compose/ui/Modifier;
    .local v68, "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .local v69, "$changed\\27":I
    invoke-static {v2, v5}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 179
    .local v7, "materialized\\29":Landroidx/compose/ui/Modifier;
    sget-object v62, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v62 .. v62}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v62

    move-object/from16 v70, v5

    .end local v5    # "modifier\\29":Landroidx/compose/ui/Modifier;
    .local v70, "modifier\\29":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v5, v61, 0x6

    and-int/lit16 v5, v5, 0x380

    or-int/lit8 v5, v5, 0x6

    .line 178
    move-object/from16 v71, v62

    .local v5, "$changed\\30":I
    .local v71, "factory\\30":Lkotlin/jvm/functions/Function0;
    const/16 v62, 0x0

    .line 180
    .local v62, "$i$f$ReusableComposeNode\\30\\178":I
    move/from16 v72, v5

    const v5, -0x20f7d59c

    .end local v5    # "$changed\\30":I
    .local v72, "$changed\\30":I
    invoke-static {v2, v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 181
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v5

    instance-of v5, v5, Landroidx/compose/runtime/Applier;

    if-nez v5, :cond_4b5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 182
    :cond_4b5
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 183
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v5

    if-eqz v5, :cond_4c4

    .line 184
    move-object/from16 v5, v71

    .end local v71    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .local v5, "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_4c9

    .line 186
    .end local v5    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v71    # "factory\\30":Lkotlin/jvm/functions/Function0;
    :cond_4c4
    move-object/from16 v5, v71

    .end local v71    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .restart local v5    # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 188
    :goto_4c9
    move-object/from16 v71, v2

    .end local v2    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .local v71, "$composer\\28":Landroidx/compose/runtime/Composer;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    const/16 v73, 0x0

    .line 189
    .local v73, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\188\\29":I
    sget-object v74, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v75, v5

    .end local v5    # "factory\\30":Lkotlin/jvm/functions/Function0;
    .local v75, "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v74 .. v74}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v6, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 190
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v2, v4, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 191
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\32":Lkotlin/jvm/functions/Function2;
    const/16 v74, 0x0

    .line 192
    .local v74, "$i$f$set-impl\\32\\191":I
    move-object/from16 v76, v2

    .local v76, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    const/16 v77, 0x0

    .line 193
    .local v77, "$i$a$-with-Updater$set$1\\33\\192\\32":I
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v78

    if-nez v78, :cond_50d

    move-object/from16 v78, v4

    .end local v4    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .local v78, "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-interface/range {v76 .. v76}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    move-object/from16 v79, v6

    .end local v6    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v79, "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v67 .. v67}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v4, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_50a

    goto :goto_511

    :cond_50a
    move-object/from16 v6, v76

    goto :goto_521

    .end local v78    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v79    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v6    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_50d
    move-object/from16 v78, v4

    move-object/from16 v79, v6

    .line 194
    .end local v4    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v6    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v78    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v79    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_511
    invoke-static/range {v67 .. v67}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    move-object/from16 v6, v76

    .end local v76    # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 195
    invoke-static/range {v67 .. v67}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-interface {v2, v4, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 197
    :goto_521
    nop

    .line 192
    .end local v6    # "$this$set_impl_u24lambda_u240\\32":Landroidx/compose/runtime/Composer;
    .end local v77    # "$i$a$-with-Updater$set$1\\33\\192\\32":I
    nop

    .line 197
    nop

    .line 198
    .end local v5    # "block\\32":Lkotlin/jvm/functions/Function2;
    .end local v74    # "$i$f$set-impl\\32\\191":I
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v4

    invoke-static {v2, v7, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 199
    nop

    .line 188
    .end local v2    # "$this$Layout_u24lambda_u240\\31":Landroidx/compose/runtime/Composer;
    .end local v73    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\31\\188\\29":I
    nop

    .line 200
    shr-int/lit8 v2, v72, 0x6

    and-int/lit8 v2, v2, 0xe

    .local v2, "$changed\\34":I
    move-object/from16 v4, v71

    .local v4, "$composer\\34":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 171
    .local v5, "$i$a$-Layout-ColumnKt$Column$1\\34\\200\\28":I
    const v6, 0x7cc0ae6e

    invoke-static {v4, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v6, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v73, v51, 0x6

    and-int/lit8 v73, v73, 0x70

    or-int/lit8 v73, v73, 0x6

    .local v73, "$changed\\35":I
    check-cast v6, Landroidx/compose/foundation/layout/ColumnScope;

    .local v6, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u240\\35":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v102, v4

    .local v102, "$composer\\35":Landroidx/compose/runtime/Composer;
    const/16 v74, 0x0

    .line 28
    .local v74, "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1$2$1\\35\\171\\27":I
    move/from16 v76, v2

    .end local v2    # "$changed\\34":I
    .local v76, "$changed\\34":I
    const v2, -0x1df522ed

    move-object/from16 v77, v4

    .end local v4    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .local v77, "$composer\\34":Landroidx/compose/runtime/Composer;
    const-string v4, "C27@1719L10,27@1673L70,27@1776L10,27@1744L54:TodayScreen.kt#i35lj1"

    move/from16 v106, v5

    move-object/from16 v5, v102

    .end local v102    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v5, "$composer\\35":Landroidx/compose/runtime/Composer;
    .local v106, "$i$a$-Layout-ColumnKt$Column$1\\34\\200\\28":I
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/MainUiState;->getDue()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v80

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getDisplaySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    const/16 v104, 0x0

    const v105, 0x1fffe

    const/16 v81, 0x0

    const-wide/16 v82, 0x0

    const/16 v84, 0x0

    const-wide/16 v85, 0x0

    const/16 v87, 0x0

    const/16 v88, 0x0

    const/16 v89, 0x0

    const-wide/16 v90, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const-wide/16 v94, 0x0

    const/16 v96, 0x0

    const/16 v97, 0x0

    const/16 v98, 0x0

    const/16 v99, 0x0

    const/16 v100, 0x0

    const/16 v103, 0x0

    .end local v5    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v80 .. v105}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v102    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\35":Landroidx/compose/runtime/Composer;
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v5, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v101

    const-string v80, "\u5230\u671f\u590d\u4e60"

    const/16 v103, 0x6

    .end local v5    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v102    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static/range {v80 .. v105}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v102    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer\\35":Landroidx/compose/runtime/Composer;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 171
    .end local v5    # "$composer\\35":Landroidx/compose/runtime/Composer;
    .end local v6    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u240\\35":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v73    # "$changed\\35":I
    .end local v74    # "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1$2$1\\35\\171\\27":I
    invoke-static/range {v77 .. v77}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 200
    .end local v76    # "$changed\\34":I
    .end local v77    # "$composer\\34":Landroidx/compose/runtime/Composer;
    .end local v106    # "$i$a$-Layout-ColumnKt$Column$1\\34\\200\\28":I
    nop

    .line 201
    invoke-interface/range {v71 .. v71}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 180
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 202
    nop

    .line 174
    .end local v62    # "$i$f$ReusableComposeNode\\30\\178":I
    .end local v72    # "$changed\\30":I
    .end local v75    # "factory\\30":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 203
    nop

    .line 164
    .end local v7    # "materialized\\29":Landroidx/compose/ui/Modifier;
    .end local v61    # "$changed\\29":I
    .end local v63    # "$i$f$Layout\\29\\170":I
    .end local v67    # "compositeKeyHash\\29":I
    .end local v70    # "modifier\\29":Landroidx/compose/ui/Modifier;
    .end local v78    # "localMap\\29":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v71 .. v71}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 204
    nop

    .line 29
    .end local v51    # "$changed\\28":I
    .end local v59    # "$i$f$Column\\28\\28":I
    .end local v60    # "modifier\\28":Landroidx/compose/ui/Modifier;
    .end local v66    # "verticalArrangement\\28":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v68    # "horizontalAlignment\\28":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v71    # "$composer\\28":Landroidx/compose/runtime/Composer;
    .end local v79    # "measurePolicy\\28":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v59, v2

    check-cast v59, Landroidx/compose/ui/Modifier;

    const/16 v62, 0x2

    const/16 v63, 0x0

    const/high16 v60, 0x3f800000    # 1.0f

    const/16 v61, 0x0

    invoke-static/range {v58 .. v63}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\36":Landroidx/compose/ui/Modifier;
    const/4 v4, 0x0

    .local v4, "$changed\\36":I
    move-object/from16 v5, v64

    .local v5, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 205
    .local v6, "$i$f$Column\\36\\29":I
    const v7, 0x4ff7456f

    invoke-static {v5, v7, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 206
    sget-object v7, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v7}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v7

    .line 207
    .local v7, "verticalArrangement\\36":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v13, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v13

    .line 210
    .local v13, "horizontalAlignment\\36":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v19, v4, 0x3

    and-int/lit8 v19, v19, 0xe

    shr-int/lit8 v51, v4, 0x3

    and-int/lit8 v51, v51, 0x70

    move-object/from16 v59, v2

    .end local v2    # "modifier\\36":Landroidx/compose/ui/Modifier;
    .local v59, "modifier\\36":Landroidx/compose/ui/Modifier;
    or-int v2, v19, v51

    invoke-static {v7, v13, v5, v2}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v2

    .line 214
    .local v2, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v19, v4, 0x3

    and-int/lit8 v19, v19, 0x70

    .line 211
    nop

    .local v19, "$changed\\37":I
    move-object/from16 v51, v59

    .local v51, "modifier\\37":Landroidx/compose/ui/Modifier;
    const/16 v60, 0x0

    .line 215
    .local v60, "$i$f$Layout\\37\\211":I
    move/from16 v61, v4

    const v4, -0x451e1427

    .end local v4    # "$changed\\36":I
    .local v61, "$changed\\36":I
    invoke-static {v5, v4, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 216
    const/4 v4, 0x0

    invoke-static {v5, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v21

    invoke-static/range {v21 .. v22}, Ljava/lang/Long;->hashCode(J)I

    move-result v12

    .line 217
    .local v12, "compositeKeyHash\\37":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v4

    .line 218
    .local v4, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v22, v6

    move-object/from16 v6, v51

    move-object/from16 v51, v7

    .end local v7    # "verticalArrangement\\36":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v6, "modifier\\37":Landroidx/compose/ui/Modifier;
    .local v22, "$i$f$Column\\36\\29":I
    .local v51, "verticalArrangement\\36":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v5, v6}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v7

    .line 220
    .local v7, "materialized\\37":Landroidx/compose/ui/Modifier;
    sget-object v62, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v62 .. v62}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v62

    move-object/from16 v63, v6

    .end local v6    # "modifier\\37":Landroidx/compose/ui/Modifier;
    .local v63, "modifier\\37":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v6, v19, 0x6

    and-int/lit16 v6, v6, 0x380

    or-int/lit8 v6, v6, 0x6

    .line 219
    move-object/from16 v66, v62

    .local v6, "$changed\\38":I
    .local v66, "factory\\38":Lkotlin/jvm/functions/Function0;
    const/16 v62, 0x0

    .line 221
    .local v62, "$i$f$ReusableComposeNode\\38\\219":I
    move/from16 v67, v6

    const v6, -0x20f7d59c

    .end local v6    # "$changed\\38":I
    .local v67, "$changed\\38":I
    invoke-static {v5, v6, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 222
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_646

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 223
    :cond_646
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 224
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_655

    .line 225
    move-object/from16 v0, v66

    .end local v66    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_65a

    .line 227
    .end local v0    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v66    # "factory\\38":Lkotlin/jvm/functions/Function0;
    :cond_655
    move-object/from16 v0, v66

    .end local v66    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 229
    :goto_65a
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v6

    .local v6, "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 230
    .local v25, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\229\\37":I
    sget-object v66, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v68, v0

    .end local v0    # "factory\\38":Lkotlin/jvm/functions/Function0;
    .local v68, "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v66 .. v66}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 231
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 232
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\40":Lkotlin/jvm/functions/Function2;
    const/16 v66, 0x0

    .line 233
    .local v66, "$i$f$set-impl\\40\\232":I
    move-object/from16 v70, v6

    .local v70, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    const/16 v71, 0x0

    .line 234
    .local v71, "$i$a$-with-Updater$set$1\\41\\233\\40":I
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v72

    if-nez v72, :cond_69c

    move-object/from16 v72, v2

    .end local v2    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v72, "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface/range {v70 .. v70}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v73, v4

    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .local v73, "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_699

    goto :goto_6a0

    :cond_699
    move-object/from16 v4, v70

    goto :goto_6b0

    .end local v72    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v73    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v2    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_69c
    move-object/from16 v72, v2

    move-object/from16 v73, v4

    .line 235
    .end local v2    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v72    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v73    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_6a0
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v70

    .end local v70    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 236
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v6, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 238
    :goto_6b0
    nop

    .line 233
    .end local v4    # "$this$set_impl_u24lambda_u240\\40":Landroidx/compose/runtime/Composer;
    .end local v71    # "$i$a$-with-Updater$set$1\\41\\233\\40":I
    nop

    .line 238
    nop

    .line 239
    .end local v0    # "block\\40":Lkotlin/jvm/functions/Function2;
    .end local v66    # "$i$f$set-impl\\40\\232":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v6, v7, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 240
    nop

    .line 229
    .end local v6    # "$this$Layout_u24lambda_u240\\39":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\39\\229\\37":I
    nop

    .line 241
    shr-int/lit8 v0, v67, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\42":I
    move-object v2, v5

    .local v2, "$composer\\42":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 212
    .local v4, "$i$a$-Layout-ColumnKt$Column$1\\42\\241\\36":I
    const v6, 0x7cc0ae6e

    invoke-static {v2, v6, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v6, v61, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\43":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u241\\43":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v96, v2

    .local v96, "$composer\\43":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 29
    .local v25, "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1$2$2\\43\\212\\27":I
    move/from16 v32, v0

    .end local v0    # "$changed\\42":I
    .local v32, "$changed\\42":I
    const v0, -0x5e811e6d

    move-object/from16 v66, v1

    .end local v1    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u241\\43":Landroidx/compose/foundation/layout/ColumnScope;
    .local v66, "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u241\\43":Landroidx/compose/foundation/layout/ColumnScope;
    const-string v1, "C28@1892L10,28@1837L79,28@1949L10,28@1917L54:TodayScreen.kt#i35lj1"

    move-object/from16 v70, v2

    .end local v96    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\43":Landroidx/compose/runtime/Composer;
    .local v70, "$composer\\42":Landroidx/compose/runtime/Composer;
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/MainUiState;->getAvailableNew()I

    move-result v0

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v74

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getDisplaySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v95

    const/16 v98, 0x0

    const v99, 0x1fffe

    const/16 v75, 0x0

    const-wide/16 v76, 0x0

    const/16 v78, 0x0

    const-wide/16 v79, 0x0

    const/16 v81, 0x0

    const/16 v82, 0x0

    const/16 v83, 0x0

    const-wide/16 v84, 0x0

    const/16 v86, 0x0

    const/16 v87, 0x0

    const-wide/16 v88, 0x0

    const/16 v90, 0x0

    const/16 v91, 0x0

    const/16 v92, 0x0

    const/16 v93, 0x0

    const/16 v94, 0x0

    const/16 v97, 0x0

    .end local v2    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v96    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v74 .. v99}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v96    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\43":Landroidx/compose/runtime/Composer;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v95

    const-string v74, "\u53ef\u5b66\u65b0\u5361"

    const/16 v97, 0x6

    .end local v2    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v96    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static/range {v74 .. v99}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v96    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\43":Landroidx/compose/runtime/Composer;
    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 212
    .end local v2    # "$composer\\43":Landroidx/compose/runtime/Composer;
    .end local v6    # "$changed\\43":I
    .end local v25    # "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1$2$2\\43\\212\\27":I
    .end local v66    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241_u241\\43":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v70 .. v70}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 241
    .end local v4    # "$i$a$-Layout-ColumnKt$Column$1\\42\\241\\36":I
    .end local v32    # "$changed\\42":I
    .end local v70    # "$composer\\42":Landroidx/compose/runtime/Composer;
    nop

    .line 242
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 221
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 243
    nop

    .line 215
    .end local v62    # "$i$f$ReusableComposeNode\\38\\219":I
    .end local v67    # "$changed\\38":I
    .end local v68    # "factory\\38":Lkotlin/jvm/functions/Function0;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 244
    nop

    .line 205
    .end local v7    # "materialized\\37":Landroidx/compose/ui/Modifier;
    .end local v12    # "compositeKeyHash\\37":I
    .end local v19    # "$changed\\37":I
    .end local v60    # "$i$f$Layout\\37\\211":I
    .end local v63    # "modifier\\37":Landroidx/compose/ui/Modifier;
    .end local v73    # "localMap\\37":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 245
    nop

    .line 28
    .end local v5    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .end local v13    # "horizontalAlignment\\36":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v22    # "$i$f$Column\\36\\29":I
    .end local v51    # "verticalArrangement\\36":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v59    # "modifier\\36":Landroidx/compose/ui/Modifier;
    .end local v61    # "$changed\\36":I
    .end local v72    # "measurePolicy\\36":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v64 .. v64}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 30
    nop

    .line 134
    .end local v52    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$2$1$1$2\\27\\134\\10":I
    .end local v58    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240_u241\\27":Landroidx/compose/foundation/layout/RowScope;
    .end local v64    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .end local v69    # "$changed\\27":I
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 163
    .end local v54    # "$changed\\26":I
    .end local v55    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v65    # "$i$a$-Layout-RowKt$Row$1\\26\\163\\20":I
    nop

    .line 246
    invoke-interface/range {v53 .. v53}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 143
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 247
    nop

    .line 137
    .end local v41    # "$i$f$ReusableComposeNode\\22\\141":I
    .end local v43    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v44    # "$changed\\22":I
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 248
    nop

    .line 128
    .end local v8    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v35    # "$changed\\21":I
    .end local v37    # "$i$f$Layout\\21\\133":I
    .end local v39    # "compositeKeyHash\\21":I
    .end local v42    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .end local v56    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v53 .. v53}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 249
    nop

    .line 31
    .end local v33    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v34    # "$changed\\20":I
    .end local v36    # "$i$f$Row\\20\\27":I
    .end local v38    # "horizontalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v40    # "verticalAlignment\\20":Landroidx/compose/ui/Alignment$Vertical;
    .end local v53    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v57    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v0, v4, v6, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v1, 0x38

    .local v1, "$this$dp\\44":I
    const/4 v2, 0x0

    .line 250
    .local v2, "$i$f$getDp\\44\\31":I
    int-to-float v6, v1

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 31
    .end local v1    # "$this$dp\\44":I
    .end local v2    # "$i$f$getDp\\44\\31":I
    const/4 v2, 0x2

    invoke-static {v0, v1, v4, v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/MainUiState;->getDue()I

    move-result v1

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/ui/MainUiState;->getAvailableNew()I

    move-result v2

    add-int/2addr v1, v2

    if-lez v1, :cond_78a

    const/16 v21, 0x1

    goto :goto_78c

    :cond_78a
    const/16 v21, 0x0

    :goto_78c
    const/16 v1, 0x10

    .local v1, "$this$dp\\45":I
    const/4 v2, 0x0

    .line 250
    .local v2, "$i$f$getDp\\45\\31":I
    int-to-float v4, v1

    invoke-static {v4}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 31
    .end local v1    # "$this$dp\\45":I
    .end local v2    # "$i$f$getDp\\45\\31":I
    invoke-static {v1}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v1

    check-cast v1, Landroidx/compose/ui/graphics/Shape;

    sget-object v32, Landroidx/compose/material3/ButtonDefaults;->INSTANCE:Landroidx/compose/material3/ButtonDefaults;

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v33

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v35

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getBackground-0d7_KjU()J

    move-result-wide v37

    const/16 v43, 0xe

    const/16 v44, 0x0

    const v39, 0x3f59999a    # 0.85f

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    invoke-static/range {v37 .. v44}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(JFFFFILjava/lang/Object;)J

    move-result-wide v37

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v39

    sget v2, Landroidx/compose/material3/ButtonDefaults;->$stable:I

    shl-int/lit8 v42, v2, 0xc

    const/16 v43, 0x0

    move-object/from16 v41, v3

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v41, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {v32 .. v43}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/Composer;II)Landroidx/compose/material3/ButtonColors;

    move-result-object v36

    .end local v41    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    new-instance v2, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda10;

    move-object/from16 v4, p1

    invoke-direct {v2, v4}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda10;-><init>(Lcom/xunji/flashcards/ui/MainUiState;)V

    const/16 v5, 0x36

    const v6, 0x76eeff52

    const/4 v8, 0x1

    invoke-static {v6, v8, v2, v3, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v2

    move-object/from16 v41, v2

    check-cast v41, Lkotlin/jvm/functions/Function3;

    const v43, 0x30000030

    const/16 v44, 0x1e0

    const/16 v37, 0x0

    const/16 v38, 0x0

    const/16 v39, 0x0

    const/16 v40, 0x0

    move-object/from16 v32, p0

    move-object/from16 v33, v0

    move-object/from16 v35, v1

    move-object/from16 v42, v3

    move/from16 v34, v21

    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v42, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v32 .. v44}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 26
    .end local v42    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 32
    nop

    .line 60
    .end local v3    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v26    # "$this$TodayScreen_u24lambda_u241_u240_u241_u240_u240\\10":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v28    # "$changed\\10":I
    .end local v29    # "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$2$1$1\\10\\60\\0":I
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 89
    .end local v24    # "$changed\\9":I
    .end local v45    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v46    # "$i$a$-Layout-ColumnKt$Column$1\\9\\89\\3":I
    nop

    .line 251
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 69
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 252
    nop

    .line 63
    .end local v23    # "$i$f$ReusableComposeNode\\5\\67":I
    .end local v48    # "$changed\\5":I
    .end local v49    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 253
    nop

    .line 54
    .end local v16    # "$changed\\4":I
    .end local v18    # "$i$f$Layout\\4\\59":I
    .end local v20    # "compositeKeyHash\\4":I
    .end local v30    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v31    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v47    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 254
    nop

    .end local v9    # "$changed\\3":I
    .end local v10    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v11    # "$i$f$Column\\3\\25":I
    .end local v14    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v15    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v27    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v50    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_83e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_83e

    .line 24
    :cond_839
    move-object/from16 v4, p1

    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 33
    :cond_83e
    :goto_83e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$1$0$0$2(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$this$Button"    # Landroidx/compose/foundation/layout/RowScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v4, p2

    move/from16 v0, p3

    const-string v1, "$this$Button"

    move-object/from16 v2, p1

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C30@2387L62,30@2450L29,30@2514L11,30@2480L54:TodayScreen.kt#i35lj1"

    invoke-static {v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    if-eq v1, v3, :cond_18

    const/4 v1, 0x1

    goto :goto_19

    :cond_18
    const/4 v1, 0x0

    :goto_19
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v4, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_9c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_30

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:30)"

    const v5, 0x76eeff52

    invoke-static {v5, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 31
    :cond_30
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getDue()I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getAvailableNew()I

    move-result v3

    add-int/2addr v1, v3

    if-lez v1, :cond_3e

    const-string v1, "\u5f00\u59cb\u590d\u4e60"

    goto :goto_40

    :cond_3e
    const-string v1, "\u6682\u65f6\u6ca1\u6709\u5f85\u5b66\u5361\u7247"

    :goto_40
    const/16 v24, 0x0

    const v25, 0x3fffe

    move-object v0, v1

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p2

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v4, v22

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0xc

    .local v1, "$this$dp\\1":I
    const/4 v2, 0x0

    .line 250
    .local v2, "$i$f$getDp\\1\\31":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 31
    .end local v1    # "$this$dp\\1":I
    .end local v2    # "$i$f$getDp\\1\\31":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x6

    invoke-static {v0, v4, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v4, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v0, "arrow"

    const/4 v1, 0x0

    invoke-static/range {v0 .. v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_9f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_9f

    :cond_9c
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_9f
    :goto_9f
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$2(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14
    .param p0, "$onDecks"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C34@2586L59:TodayScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    if-eq v0, v1, :cond_12

    const/4 v0, 0x1

    goto :goto_13

    :cond_12
    const/4 v0, 0x0

    :goto_13
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_42

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2a

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:34)"

    const v2, 0x7d7246ec

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 35
    :cond_2a
    const/16 v8, 0x1b6

    const/4 v9, 0x0

    const-string v3, "\u4ece\u7b2c\u4e00\u5f20\u5361\u5f00\u59cb"

    const-string v4, "\u6536\u96c6\u4e00\u4e2a\u8bcd\u3001\u4e00\u53e5\u8bdd\uff0c\u6216\u4e00\u4e2a\u60f3\u8bb0\u4f4f\u7684\u7b54\u6848\u3002"

    const-string v5, "\u521b\u5efa\u724c\u7ec4"

    move-object v6, p0

    move-object v7, p2

    .end local p0    # "$onDecks":Lkotlin/jvm/functions/Function0;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v6, "$onDecks":Lkotlin/jvm/functions/Function0;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v3 .. v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_47

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_47

    .end local v6    # "$onDecks":Lkotlin/jvm/functions/Function0;
    .end local v7    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p0    # "$onDecks":Lkotlin/jvm/functions/Function0;
    .restart local p2    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_42
    move-object v6, p0

    move-object v7, p2

    .end local p0    # "$onDecks":Lkotlin/jvm/functions/Function0;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v6    # "$onDecks":Lkotlin/jvm/functions/Function0;
    .restart local v7    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_47
    :goto_47
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final TodayScreen$lambda$1$0$3(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 10
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "$this$item"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "C36@2698L302,36@2667L333:TodayScreen.kt#i35lj1"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x11

    const/16 v1, 0x10

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eq v0, v1, :cond_14

    move v0, v3

    goto :goto_15

    :cond_14
    move v0, v2

    :goto_15
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_53

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_2c

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:36)"

    const v4, -0x2b8ea43d

    invoke-static {v4, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 37
    :cond_2c
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v1, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1, v3, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v1, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda9;

    invoke-direct {v1, p0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda9;-><init>(Lcom/xunji/flashcards/ui/MainUiState;)V

    const v4, -0x4eb3a96d

    const/16 v5, 0x36

    invoke-static {v4, v3, v1, p2, v5}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v1

    check-cast v1, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v1, p2, v5, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_56

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_56

    :cond_53
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_56
    :goto_56
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$3$0(Lcom/xunji/flashcards/ui/MainUiState;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 41
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C36@2700L25,36@2726L210,36@2937L61:TodayScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1ee

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:36)"

    const v6, -0x4eb3a96d

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 37
    :cond_31
    const-string v2, "TODAY \u00b7 \u5df2\u7ecf\u8d70\u8fc7\u7684\u8def"

    const/4 v4, 0x6

    invoke-static {v2, v0, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v2, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v6, 0x18

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 255
    .local v7, "$i$f$getDp\\1\\37":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 37
    .end local v6    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\37":I
    invoke-virtual {v2, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v2

    check-cast v2, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v2, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v6, 0x30

    .local v6, "$changed\\2":I
    move-object/from16 v7, p2

    .local v7, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 256
    .local v8, "$i$f$Row\\2\\37":I
    const v9, 0x3255a44b

    const-string v10, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 257
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    .line 259
    .local v9, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v10, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v10}, Landroidx/compose/ui/Alignment$Companion;->getTop()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v10

    .line 262
    .local v10, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0xe

    shr-int/lit8 v12, v6, 0x3

    and-int/lit8 v12, v12, 0x70

    or-int/2addr v11, v12

    invoke-static {v2, v10, v7, v11}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v11

    .line 266
    .local v11, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v12, v6, 0x3

    and-int/lit8 v12, v12, 0x70

    .line 263
    nop

    .local v12, "$changed\\3":I
    move-object v13, v9

    .local v13, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v14, 0x0

    .line 267
    .local v14, "$i$f$Layout\\3\\263":I
    const v15, -0x451e1427

    move/from16 v16, v4

    const-string v4, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v15, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 268
    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v17

    invoke-static/range {v17 .. v18}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 269
    .local v4, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 270
    .local v15, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v13}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    .line 272
    .local v5, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v18

    shl-int/lit8 v1, v12, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 271
    move-object/from16 v19, v18

    .local v1, "$changed\\4":I
    .local v19, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v18, 0x0

    .line 273
    .local v18, "$i$f$ReusableComposeNode\\4\\271":I
    move/from16 v20, v1

    .end local v1    # "$changed\\4":I
    .local v20, "$changed\\4":I
    const v1, -0x20f7d59c

    move-object/from16 v21, v2

    .end local v2    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v21, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const-string v2, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 274
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_b3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 275
    :cond_b3
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 276
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_c2

    .line 277
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v1, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_c7

    .line 279
    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_c2
    move-object/from16 v1, v19

    .end local v19    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 281
    :goto_c7
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .local v2, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 282
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\281\\3":I
    sget-object v22, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v23, v1

    .end local v1    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v23, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v11, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 283
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v15, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 284
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v22, 0x0

    .line 285
    .local v22, "$i$f$set-impl\\6\\284":I
    move-object/from16 v24, v2

    .local v24, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v25, 0x0

    .line 286
    .local v25, "$i$a$-with-Updater$set$1\\7\\285\\6":I
    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v26

    if-nez v26, :cond_107

    invoke-interface/range {v24 .. v24}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move/from16 v26, v4

    .end local v4    # "compositeKeyHash\\3":I
    .local v26, "compositeKeyHash\\3":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_104

    goto :goto_109

    :cond_104
    move-object/from16 v4, v24

    goto :goto_119

    .end local v26    # "compositeKeyHash\\3":I
    .restart local v4    # "compositeKeyHash\\3":I
    :cond_107
    move/from16 v26, v4

    .line 287
    .end local v4    # "compositeKeyHash\\3":I
    .restart local v26    # "compositeKeyHash\\3":I
    :goto_109
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v24

    .end local v24    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 288
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v2, v3, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 290
    :goto_119
    nop

    .line 285
    .end local v4    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v25    # "$i$a$-with-Updater$set$1\\7\\285\\6":I
    nop

    .line 290
    nop

    .line 291
    .end local v1    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v22    # "$i$f$set-impl\\6\\284":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v2, v5, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 292
    nop

    .line 281
    .end local v2    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\281\\3":I
    nop

    .line 293
    shr-int/lit8 v1, v20, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\8":I
    move-object v2, v7

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 264
    .local v3, "$i$a$-Layout-RowKt$Row$1\\8\\293\\2":I
    const v4, 0x56ccd6f5

    move/from16 v19, v1

    .end local v1    # "$changed\\8":I
    .local v19, "$changed\\8":I
    const-string v1, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v6, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/RowScope;

    .local v1, "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v30, v2

    .local v30, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v31, v1

    .end local v1    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v31, "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/4 v1, 0x0

    .line 37
    .local v1, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$4$1$1\\9\\264\\0":I
    move/from16 v16, v1

    .end local v1    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$4$1$1\\9\\264\\0":I
    .local v16, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$4$1$1\\9\\264\\0":I
    const v1, -0x2816c54b

    move-object/from16 v22, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v2, "C36@2783L88,36@2872L62:TodayScreen.kt#i35lj1"

    move/from16 v24, v3

    move-object/from16 v3, v30

    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v24, "$i$a$-Layout-RowKt$Row$1\\8\\293\\2":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getStatistics()Lcom/xunji/core/stats/StatisticsSummary;

    move-result-object v1

    if-eqz v1, :cond_167

    invoke-virtual {v1}, Lcom/xunji/core/stats/StatisticsSummary;->getToday()Lcom/xunji/core/stats/DaySummary;

    move-result-object v1

    if-eqz v1, :cond_167

    invoke-virtual {v1}, Lcom/xunji/core/stats/DaySummary;->getScoreCount()I

    move-result v1

    goto :goto_168

    :cond_167
    const/4 v1, 0x0

    :goto_168
    invoke-static {v1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v27

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v1

    check-cast v32, Landroidx/compose/ui/Modifier;

    const/16 v35, 0x2

    const/16 v36, 0x0

    const/high16 v33, 0x3f800000    # 1.0f

    const/16 v34, 0x0

    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    move-object/from16 v1, v31

    .end local v31    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v1, "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x30

    const/16 v32, 0x0

    const-string v28, "\u8bc4\u5206\u6b21\u6570"

    move-object/from16 v30, v3

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getLearnedNew()I

    move-result v2

    invoke-static {v2}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v27

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v32, v2

    check-cast v32, Landroidx/compose/ui/Modifier;

    move-object/from16 v31, v1

    .end local v1    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v31    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    invoke-static/range {v31 .. v36}, Landroidx/compose/foundation/layout/RowScope;->weight$default(Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v29

    .end local v31    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .restart local v1    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const/16 v31, 0x30

    const/16 v32, 0x0

    const-string v28, "\u5df2\u5b66\u65b0\u5361"

    invoke-static/range {v27 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    .end local v1    # "$this$TodayScreen_u24lambda_u241_u240_u243_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v4    # "$changed\\9":I
    .end local v16    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$4$1$1\\9\\264\\0":I
    .end local v30    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 293
    .end local v19    # "$changed\\8":I
    .end local v22    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-Layout-RowKt$Row$1\\8\\293\\2":I
    nop

    .line 294
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 273
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 295
    nop

    .line 267
    .end local v18    # "$i$f$ReusableComposeNode\\4\\271":I
    .end local v20    # "$changed\\4":I
    .end local v23    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 296
    nop

    .line 256
    .end local v5    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v12    # "$changed\\3":I
    .end local v13    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v14    # "$i$f$Layout\\3\\263":I
    .end local v15    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v26    # "compositeKeyHash\\3":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 297
    nop

    .line 37
    .end local v6    # "$changed\\2":I
    .end local v7    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Row\\2\\37":I
    .end local v9    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v10    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v11    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v21    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getSettings()Lcom/xunji/core/model/AppSettings;

    move-result-object v1

    invoke-virtual {v1}, Lcom/xunji/core/model/AppSettings;->getNewCardsPerDay()I

    move-result v1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "\u6bcf\u65e5\u65b0\u5361\u4e0a\u9650 "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v1

    const-string v2, " \u5f20 \u00b7 \u5230\u671f\u590d\u4e60\u4e0d\u9650\u91cf"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v1, v3, v0, v3, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_1f1

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1f1

    :cond_1ee
    invoke-interface {v0}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1f1
    :goto_1f1
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1
.end method

.method private static final TodayScreen$lambda$1$0$4(Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 55
    .param p0, "$onDecks"    # Lkotlin/jvm/functions/Function0;
    .param p1, "$this$item"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$item"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C37@3013L218:TodayScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eq v2, v4, :cond_1a

    move v2, v6

    goto :goto_1b

    :cond_1a
    move v2, v5

    :goto_1b
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_1bb

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_32

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:37)"

    const v7, -0x446abe94

    invoke-static {v7, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 38
    :cond_32
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v7, 0x0

    invoke-static {v2, v4, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getSpaceBetween()Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v4, "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v6

    .local v6, "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    const/16 v7, 0x1b6

    .local v7, "$changed\\1":I
    move-object/from16 v8, p2

    .local v8, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v9, 0x0

    .line 298
    .local v9, "$i$f$Row\\1\\38":I
    const v10, 0x3255a44b

    const-string v11, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v8, v10, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 299
    shr-int/lit8 v10, v7, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v7, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v4, v6, v8, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 303
    .local v10, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v7, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 300
    nop

    .local v11, "$changed\\2":I
    move-object v12, v2

    .local v12, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 304
    .local v13, "$i$f$Layout\\2\\300":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v8, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 305
    invoke-static {v8, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v5

    .line 306
    .local v5, "compositeKeyHash\\2":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v14

    .line 307
    .local v14, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v8, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 309
    .local v15, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    shl-int/lit8 v0, v11, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 308
    move-object/from16 v17, v16

    .local v0, "$changed\\3":I
    .local v17, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 310
    .local v16, "$i$f$ReusableComposeNode\\3\\308":I
    move/from16 v18, v0

    .end local v0    # "$changed\\3":I
    .local v18, "$changed\\3":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v8, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 311
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_a8

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 312
    :cond_a8
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 313
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b7

    .line 314
    move-object/from16 v0, v17

    .end local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bc

    .line 316
    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    :cond_b7
    move-object/from16 v0, v17

    .end local v17    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 318
    :goto_bc
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 319
    .local v17, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\318\\2":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v20, v0

    .end local v0    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .local v20, "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 320
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v14, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 321
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 322
    .local v19, "$i$f$set-impl\\5\\321":I
    move-object/from16 v21, v1

    .local v21, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 323
    .local v22, "$i$a$-with-Updater$set$1\\6\\322\\5":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_fc

    move-object/from16 v23, v2

    .end local v2    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local v23, "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_f9

    goto :goto_fe

    :cond_f9
    move-object/from16 v3, v21

    goto :goto_10e

    .end local v23    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v2    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :cond_fc
    move-object/from16 v23, v2

    .line 324
    .end local v2    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .restart local v23    # "modifier\\1":Landroidx/compose/ui/Modifier;
    :goto_fe
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 325
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 327
    :goto_10e
    nop

    .line 322
    .end local v3    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\6\\322\\5":I
    nop

    .line 327
    nop

    .line 328
    .end local v0    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\5\\321":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 329
    nop

    .line 318
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\318\\2":I
    nop

    .line 330
    shr-int/lit8 v0, v18, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\7":I
    move-object v1, v8

    .local v1, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 301
    .local v2, "$i$a$-Layout-RowKt$Row$1\\7\\330\\1":I
    const v3, 0x56ccd6f5

    move/from16 v17, v0

    .end local v0    # "$changed\\7":I
    .local v17, "$changed\\7":I
    const-string v0, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v3, v7, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\8":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$TodayScreen_u24lambda_u241_u240_u244_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v46, v1

    .local v46, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    .line 38
    .local v19, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$5$1\\8\\301\\0":I
    move-object/from16 v21, v0

    .end local v0    # "$this$TodayScreen_u24lambda_u241_u240_u244_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .local v21, "$this$TodayScreen_u24lambda_u241_u240_u244_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x7abd3582

    move-object/from16 v22, v1

    .end local v1    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v1, "C37@3170L10,37@3136L56,37@3193L36:TodayScreen.kt#i35lj1"

    move/from16 v50, v2

    move-object/from16 v2, v46

    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v50, "$i$a$-Layout-RowKt$Row$1\\7\\330\\1":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v45

    const/16 v48, 0x0

    const v49, 0x1fffe

    const-string v24, "\u4f60\u7684\u8bb0\u5fc6\u82b1\u56ed"

    const/16 v25, 0x0

    const-wide/16 v26, 0x0

    const/16 v28, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v33, 0x0

    const-wide/16 v34, 0x0

    const/16 v36, 0x0

    const/16 v37, 0x0

    const-wide/16 v38, 0x0

    const/16 v40, 0x0

    const/16 v41, 0x0

    const/16 v42, 0x0

    const/16 v43, 0x0

    const/16 v44, 0x0

    const/16 v47, 0x6

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v49}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    sget-object v0, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->INSTANCE:Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;

    invoke-virtual {v0}, Lcom/xunji/flashcards/ui/screens/ComposableSingletons$TodayScreenKt;->getLambda$-1573877077$app_debug()Lkotlin/jvm/functions/Function3;

    move-result-object v33

    const/high16 v35, 0x30000000

    const/16 v36, 0x1fe

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    move-object/from16 v24, p0

    move-object/from16 v34, v46

    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v24 .. v36}, Landroidx/compose/material3/ButtonKt;->TextButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .end local v34    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 301
    .end local v3    # "$changed\\8":I
    .end local v19    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$5$1\\8\\301\\0":I
    .end local v21    # "$this$TodayScreen_u24lambda_u241_u240_u244_u240\\8":Landroidx/compose/foundation/layout/RowScope;
    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 330
    .end local v17    # "$changed\\7":I
    .end local v22    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v50    # "$i$a$-Layout-RowKt$Row$1\\7\\330\\1":I
    nop

    .line 331
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 310
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 332
    nop

    .line 304
    .end local v16    # "$i$f$ReusableComposeNode\\3\\308":I
    .end local v18    # "$changed\\3":I
    .end local v20    # "factory\\3":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 333
    nop

    .line 298
    .end local v5    # "compositeKeyHash\\2":I
    .end local v11    # "$changed\\2":I
    .end local v12    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\2\\300":I
    .end local v14    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v15    # "materialized\\2":Landroidx/compose/ui/Modifier;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 334
    nop

    .end local v4    # "horizontalArrangement\\1":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .end local v6    # "verticalAlignment\\1":Landroidx/compose/ui/Alignment$Vertical;
    .end local v7    # "$changed\\1":I
    .end local v8    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v9    # "$i$f$Row\\1\\38":I
    .end local v10    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_1be

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_1be

    .line 38
    :cond_1bb
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_1be
    :goto_1be
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$1$0$5(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/lazy/LazyItemScope;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 24
    .param p0, "$state"    # Lcom/xunji/flashcards/ui/MainUiState;
    .param p1, "$onDecks"    # Lkotlin/jvm/functions/Function0;
    .param p2, "$this$items"    # Landroidx/compose/foundation/lazy/LazyItemScope;
    .param p3, "i"    # I
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move/from16 v0, p3

    move-object/from16 v1, p4

    const-string v2, "$this$items"

    move-object/from16 v3, p2

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "CN(i)38@3357L283,38@3299L341:TodayScreen.kt#i35lj1"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p5

    .local v2, "$dirty":I
    and-int/lit8 v4, p5, 0x30

    if-nez v4, :cond_22

    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v4

    if-eqz v4, :cond_1f

    const/16 v4, 0x20

    goto :goto_21

    :cond_1f
    const/16 v4, 0x10

    :goto_21
    or-int/2addr v2, v4

    :cond_22
    and-int/lit16 v4, v2, 0x91

    const/16 v5, 0x90

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eq v4, v5, :cond_2c

    move v4, v7

    goto :goto_2d

    :cond_2c
    move v4, v6

    :goto_2d
    and-int/lit8 v5, v2, 0x1

    invoke-interface {v1, v4, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_85

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_44

    const/4 v4, -0x1

    const-string v5, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:38)"

    const v8, -0x3279f966

    invoke-static {v8, v2, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 39
    :cond_44
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/ui/MainUiState;->getDecks()Ljava/util/List;

    move-result-object v4

    invoke-interface {v4, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/xunji/core/model/DeckSummary;

    .local v4, "deck":Lcom/xunji/core/model/DeckSummary;
    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v5, v8, v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    const/16 v16, 0xf

    const/16 v17, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x0

    move-object/from16 v15, p1

    invoke-static/range {v10 .. v17}, Landroidx/compose/foundation/ClickableKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/ui/semantics/Role;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function0;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v5

    new-instance v8, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda11;

    invoke-direct {v8, v4}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt$$ExternalSyntheticLambda11;-><init>(Lcom/xunji/core/model/DeckSummary;)V

    const/16 v9, 0x36

    const v10, 0x7bc7196a

    invoke-static {v10, v7, v8, v1, v9}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v7

    check-cast v7, Lkotlin/jvm/functions/Function3;

    const/16 v8, 0x30

    invoke-static {v5, v7, v1, v8, v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_88

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .end local v4    # "deck":Lcom/xunji/core/model/DeckSummary;
    goto :goto_88

    :cond_85
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_88
    :goto_88
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v4
.end method

.method private static final TodayScreen$lambda$1$0$5$0(Lcom/xunji/core/model/DeckSummary;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 79
    .param p0, "$deck"    # Lcom/xunji/core/model/DeckSummary;
    .param p1, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Paper"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C38@3359L279:TodayScreen.kt#i35lj1"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    const/4 v5, 0x0

    if-eq v2, v4, :cond_19

    const/4 v2, 0x1

    goto :goto_1a

    :cond_19
    move v2, v5

    :goto_1a
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_329

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_31

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.screens.TodayScreen.<anonymous>.<anonymous>.<anonymous>.<anonymous> (TodayScreen.kt:38)"

    const v6, 0x7bc7196a

    invoke-static {v6, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 39
    :cond_31
    sget-object v2, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/Alignment$Companion;->getCenterVertically()Landroidx/compose/ui/Alignment$Vertical;

    move-result-object v2

    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v6, 0x10

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 335
    .local v7, "$i$f$getDp\\1\\39":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 39
    .end local v6    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\39":I
    invoke-virtual {v4, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v4

    check-cast v4, Landroidx/compose/foundation/layout/Arrangement$Horizontal;

    .local v4, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    const/16 v6, 0x1b0

    .local v6, "$changed\\2":I
    move-object/from16 v7, p2

    .local v2, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v7, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 336
    .local v8, "$i$f$Row\\2\\39":I
    const v9, 0x3255a44b

    const-string v10, "CC(Row)N(modifier,horizontalArrangement,verticalAlignment,content)99@5125L58,100@5188L131:Row.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 337
    sget-object v9, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v9, Landroidx/compose/ui/Modifier;

    .line 342
    .local v9, "modifier\\2":Landroidx/compose/ui/Modifier;
    shr-int/lit8 v10, v6, 0x3

    and-int/lit8 v10, v10, 0xe

    shr-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    or-int/2addr v10, v11

    invoke-static {v4, v2, v7, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/Alignment$Vertical;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 346
    .local v10, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 343
    move-object v12, v9

    .local v11, "$changed\\3":I
    .local v12, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 347
    .local v13, "$i$f$Layout\\3\\343":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 348
    invoke-static {v7, v5}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->hashCode(J)I

    move-result v16

    .line 349
    .local v16, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v5

    .line 350
    .local v5, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 352
    .local v14, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v19

    shl-int/lit8 v0, v11, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 351
    nop

    .local v0, "$changed\\4":I
    move-object/from16 v20, v19

    .local v20, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/16 v19, 0x0

    .line 353
    .local v19, "$i$f$ReusableComposeNode\\4\\351":I
    move/from16 v21, v0

    .end local v0    # "$changed\\4":I
    .local v21, "$changed\\4":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 354
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_a9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 355
    :cond_a9
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 356
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b8

    .line 357
    move-object/from16 v0, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bd

    .line 359
    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    :cond_b8
    move-object/from16 v0, v20

    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 361
    :goto_bd
    move-object/from16 v20, v0

    .end local v0    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .restart local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v23, 0x0

    .line 362
    .local v23, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\361\\3":I
    sget-object v24, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v25, v2

    .end local v2    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .local v25, "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    invoke-virtual/range {v24 .. v24}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v10, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 363
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v5, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 364
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v24, 0x0

    .line 365
    .local v24, "$i$f$set-impl\\6\\364":I
    move-object/from16 v26, v0

    .local v26, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 366
    .local v27, "$i$a$-with-Updater$set$1\\7\\365\\6":I
    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v28

    if-nez v28, :cond_ff

    invoke-interface/range {v26 .. v26}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v28, v4

    .end local v4    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .local v28, "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_fc

    goto :goto_101

    :cond_fc
    move-object/from16 v4, v26

    goto :goto_111

    .end local v28    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v4    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :cond_ff
    move-object/from16 v28, v4

    .line 367
    .end local v4    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    .restart local v28    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    :goto_101
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v26

    .end local v26    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 368
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v0, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 370
    :goto_111
    nop

    .line 365
    .end local v4    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v27    # "$i$a$-with-Updater$set$1\\7\\365\\6":I
    nop

    .line 370
    nop

    .line 371
    .end local v2    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v24    # "$i$f$set-impl\\6\\364":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v0, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 372
    nop

    .line 361
    .end local v0    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v23    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\361\\3":I
    nop

    .line 373
    shr-int/lit8 v0, v21, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\8":I
    move-object v2, v7

    .local v2, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 344
    .local v3, "$i$a$-Layout-RowKt$Row$1\\8\\373\\2":I
    const v4, 0x56ccd6f5

    move/from16 v23, v0

    .end local v0    # "$changed\\8":I
    .local v23, "$changed\\8":I
    const-string v0, "C101@5233L9:Row.kt#2w3rfo"

    invoke-static {v2, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/RowScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/RowScopeInstance;

    shr-int/lit8 v4, v6, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\9":I
    check-cast v0, Landroidx/compose/foundation/layout/RowScope;

    .local v0, "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    move-object/from16 v33, v2

    .local v33, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 39
    .local v24, "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$6$1$1\\9\\344\\0":I
    move-object/from16 v26, v0

    .end local v0    # "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .local v26, "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    const v0, -0x1e86769a

    move-object/from16 v27, v2

    .end local v2    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v27, "$composer\\8":Landroidx/compose/runtime/Composer;
    const-string v2, "C38@3495L11,38@3461L54,38@3516L120:TodayScreen.kt#i35lj1"

    move/from16 v36, v3

    move-object/from16 v3, v33

    .end local v33    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v36, "$i$a$-Layout-RowKt$Row$1\\8\\373\\2":I
    invoke-static {v3, v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v3, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v31

    const/16 v34, 0x6

    const/16 v35, 0x2

    const-string v29, "decks"

    const/16 v30, 0x0

    .end local v3    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v33    # "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static/range {v29 .. v35}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    const/4 v0, 0x0

    .local v0, "$changed\\10":I
    move-object/from16 v2, v33

    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 374
    .local v3, "$i$f$Column\\10\\39":I
    move/from16 v29, v0

    .end local v0    # "$changed\\10":I
    .local v29, "$changed\\10":I
    const v0, 0x4ff7456f

    move/from16 v30, v3

    .end local v3    # "$i$f$Column\\10\\39":I
    .local v30, "$i$f$Column\\10\\39":I
    const-string v3, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v2, v0, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 375
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    .line 376
    .local v0, "modifier\\10":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v3}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v3

    .line 377
    .local v3, "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v31, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    move-object/from16 v32, v0

    .end local v0    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .local v32, "modifier\\10":Landroidx/compose/ui/Modifier;
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v0

    .line 380
    .local v0, "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v31, v29, 0x3

    and-int/lit8 v31, v31, 0xe

    shr-int/lit8 v34, v29, 0x3

    and-int/lit8 v34, v34, 0x70

    move/from16 v35, v4

    .end local v4    # "$changed\\9":I
    .local v35, "$changed\\9":I
    or-int v4, v31, v34

    invoke-static {v3, v0, v2, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v4

    .line 384
    .local v4, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v31, v29, 0x3

    and-int/lit8 v31, v31, 0x70

    .line 381
    move-object/from16 v34, v32

    .local v31, "$changed\\11":I
    .local v34, "modifier\\11":Landroidx/compose/ui/Modifier;
    const/16 v37, 0x0

    .line 347
    .local v37, "$i$f$Layout\\11\\381":I
    move-object/from16 v38, v0

    const v0, -0x451e1427

    .end local v0    # "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    .local v38, "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    invoke-static {v2, v0, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 348
    const/4 v0, 0x0

    invoke-static {v2, v0}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v39

    invoke-static/range {v39 .. v40}, Ljava/lang/Long;->hashCode(J)I

    move-result v0

    .line 349
    .local v0, "compositeKeyHash\\11":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 350
    .local v15, "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 v18, v0

    move-object/from16 v0, v34

    move-object/from16 v34, v3

    .end local v3    # "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v0, "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v18, "compositeKeyHash\\11":I
    .local v34, "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v2, v0}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    .line 352
    .local v3, "materialized\\11":Landroidx/compose/ui/Modifier;
    sget-object v39, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v39 .. v39}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v39

    move-object/from16 v40, v0

    .end local v0    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .local v40, "modifier\\11":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v0, v31, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 351
    move-object/from16 v41, v39

    .local v0, "$changed\\12":I
    .local v41, "factory\\12":Lkotlin/jvm/functions/Function0;
    const/16 v39, 0x0

    .line 353
    .local v39, "$i$f$ReusableComposeNode\\12\\351":I
    move/from16 v42, v0

    const v0, -0x20f7d59c

    .end local v0    # "$changed\\12":I
    .local v42, "$changed\\12":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 354
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_1e2

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 355
    :cond_1e2
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 356
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_1f1

    .line 357
    move-object/from16 v0, v41

    .end local v41    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_1f6

    .line 359
    .end local v0    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v41    # "factory\\12":Lkotlin/jvm/functions/Function0;
    :cond_1f1
    move-object/from16 v0, v41

    .end local v41    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 361
    :goto_1f6
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 385
    .local v22, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\361\\11":I
    sget-object v41, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v43, v0

    .end local v0    # "factory\\12":Lkotlin/jvm/functions/Function0;
    .local v43, "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v41 .. v41}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 386
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 387
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\14":Lkotlin/jvm/functions/Function2;
    const/16 v41, 0x0

    .line 365
    .local v41, "$i$f$set-impl\\14\\387":I
    move-object/from16 v44, v1

    .local v44, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    const/16 v45, 0x0

    .line 366
    .local v45, "$i$a$-with-Updater$set$1\\15\\365\\14":I
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v46

    if-nez v46, :cond_238

    move-object/from16 v46, v2

    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v47, v4

    .end local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v47, "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_235

    goto :goto_23c

    :cond_235
    move-object/from16 v4, v44

    goto :goto_24c

    .end local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v47    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :cond_238
    move-object/from16 v46, v2

    move-object/from16 v47, v4

    .line 367
    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v4    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v47    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    :goto_23c
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v4, v44

    .end local v44    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 368
    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 370
    :goto_24c
    nop

    .line 365
    .end local v4    # "$this$set_impl_u24lambda_u240\\14":Landroidx/compose/runtime/Composer;
    .end local v45    # "$i$a$-with-Updater$set$1\\15\\365\\14":I
    nop

    .line 370
    nop

    .line 388
    .end local v0    # "block\\14":Lkotlin/jvm/functions/Function2;
    .end local v41    # "$i$f$set-impl\\14\\387":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 389
    nop

    .line 361
    .end local v1    # "$this$Layout_u24lambda_u240\\13":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\13\\361\\11":I
    nop

    .line 373
    shr-int/lit8 v0, v42, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\16":I
    move-object/from16 v1, v46

    .local v1, "$composer\\16":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 382
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\16\\373\\10":I
    const v4, 0x7cc0ae6e

    move/from16 v22, v0

    .end local v0    # "$changed\\16":I
    .local v22, "$changed\\16":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v4, v29, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\17":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v70, v1

    .local v70, "$composer\\17":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 39
    .local v41, "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$6$1$1$1\\17\\382\\9":I
    move-object/from16 v44, v0

    .end local v0    # "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    .local v44, "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, -0x40316fce

    move-object/from16 v45, v1

    .end local v1    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .local v45, "$composer\\16":Landroidx/compose/runtime/Composer;
    const-string v1, "C38@3565L10,38@3525L63,38@3589L45:TodayScreen.kt#i35lj1"

    move/from16 v74, v2

    move-object/from16 v2, v70

    .end local v70    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\17":Landroidx/compose/runtime/Composer;
    .local v74, "$i$a$-Layout-ColumnKt$Column$1\\16\\373\\10":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/DeckSummary;->getDeck()Lcom/xunji/core/model/Deck;

    move-result-object v0

    invoke-virtual {v0}, Lcom/xunji/core/model/Deck;->getName()Ljava/lang/String;

    move-result-object v48

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getTitleMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v69

    const/16 v72, 0x0

    const v73, 0x1fffe

    const/16 v49, 0x0

    const-wide/16 v50, 0x0

    const/16 v52, 0x0

    const-wide/16 v53, 0x0

    const/16 v55, 0x0

    const/16 v56, 0x0

    const/16 v57, 0x0

    const-wide/16 v58, 0x0

    const/16 v60, 0x0

    const/16 v61, 0x0

    const-wide/16 v62, 0x0

    const/16 v64, 0x0

    const/16 v65, 0x0

    const/16 v66, 0x0

    const/16 v67, 0x0

    const/16 v68, 0x0

    const/16 v71, 0x0

    .end local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v70    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-static/range {v48 .. v73}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    .end local v70    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/DeckSummary;->getTotal()I

    move-result v0

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/core/model/DeckSummary;->getDue()I

    move-result v1

    move-object/from16 v48, v3

    .end local v3    # "materialized\\11":Landroidx/compose/ui/Modifier;
    .local v48, "materialized\\11":Landroidx/compose/ui/Modifier;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v3, " \u5f20\u5361\u7247 \u00b7 "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5f20\u5230\u671f"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v1, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v3, v2, v3, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 382
    .end local v2    # "$composer\\17":Landroidx/compose/runtime/Composer;
    .end local v4    # "$changed\\17":I
    .end local v41    # "$i$a$-Column-TodayScreenKt$TodayScreen$2$1$6$1$1$1\\17\\382\\9":I
    .end local v44    # "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240_u240\\17":Landroidx/compose/foundation/layout/ColumnScope;
    invoke-static/range {v45 .. v45}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 373
    .end local v22    # "$changed\\16":I
    .end local v45    # "$composer\\16":Landroidx/compose/runtime/Composer;
    .end local v74    # "$i$a$-Layout-ColumnKt$Column$1\\16\\373\\10":I
    nop

    .line 390
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 353
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 391
    nop

    .line 347
    .end local v39    # "$i$f$ReusableComposeNode\\12\\351":I
    .end local v42    # "$changed\\12":I
    .end local v43    # "factory\\12":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 392
    nop

    .line 374
    .end local v15    # "localMap\\11":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v18    # "compositeKeyHash\\11":I
    .end local v31    # "$changed\\11":I
    .end local v37    # "$i$f$Layout\\11\\381":I
    .end local v40    # "modifier\\11":Landroidx/compose/ui/Modifier;
    .end local v48    # "materialized\\11":Landroidx/compose/ui/Modifier;
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 393
    nop

    .line 39
    .end local v29    # "$changed\\10":I
    .end local v30    # "$i$f$Column\\10\\39":I
    .end local v32    # "modifier\\10":Landroidx/compose/ui/Modifier;
    .end local v34    # "verticalArrangement\\10":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v38    # "horizontalAlignment\\10":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v46    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v47    # "measurePolicy\\10":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 344
    .end local v24    # "$i$a$-Row-TodayScreenKt$TodayScreen$2$1$6$1$1\\9\\344\\0":I
    .end local v26    # "$this$TodayScreen_u24lambda_u241_u240_u245_u240_u240\\9":Landroidx/compose/foundation/layout/RowScope;
    .end local v33    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v35    # "$changed\\9":I
    invoke-static/range {v27 .. v27}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 373
    .end local v23    # "$changed\\8":I
    .end local v27    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-Layout-RowKt$Row$1\\8\\373\\2":I
    nop

    .line 390
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 353
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 391
    nop

    .line 347
    .end local v19    # "$i$f$ReusableComposeNode\\4\\351":I
    .end local v20    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v21    # "$changed\\4":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 392
    nop

    .line 336
    .end local v5    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v11    # "$changed\\3":I
    .end local v12    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\3\\343":I
    .end local v14    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .end local v16    # "compositeKeyHash\\3":I
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 394
    nop

    .end local v6    # "$changed\\2":I
    .end local v7    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Row\\2\\39":I
    .end local v9    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v10    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v25    # "verticalAlignment\\2":Landroidx/compose/ui/Alignment$Vertical;
    .end local v28    # "horizontalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Horizontal;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_32c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_32c

    .line 39
    :cond_329
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_32c
    :goto_32c
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final TodayScreen$lambda$2(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p2, p4, v0}, Lcom/xunji/flashcards/ui/screens/TodayScreenKt;->TodayScreen(Lcom/xunji/flashcards/ui/MainUiState;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

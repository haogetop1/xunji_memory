.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnCompletionListener;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;


# direct methods
.method public synthetic constructor <init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;->f$0:J

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    return-void
.end method


# virtual methods
.method public final onCompletion(Landroid/media/MediaPlayer;)V
    .registers 5

    .line 0
    iget-wide v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;->f$0:J

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    invoke-static {v0, v1, v2, p1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$r8$lambda$ovSEwpLAB9sEyqSq5aAtyAkqKaU(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V

    return-void
.end method

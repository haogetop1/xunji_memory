.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/media/MediaPlayer$OnErrorListener;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;


# direct methods
.method public synthetic constructor <init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-wide p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;->f$0:J

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    return-void
.end method


# virtual methods
.method public final onError(Landroid/media/MediaPlayer;II)Z
    .registers 10

    .line 0
    iget-wide v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;->f$0:J

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    move-object v3, p1

    move v4, p2

    move v5, p3

    invoke-static/range {v0 .. v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$r8$lambda$KJUmVWoQYb2P-8PwpKASVM0i6EI(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;II)Z

    move-result p1

    return p1
.end method

.class final Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "AnkiCardContent.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiCardContent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,117:1\n1#2:118\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1$1"
    f = "AnkiCardContent.kt"
    i = {}
    l = {
        0x3b
    }
    m = "invokeSuspend"
    n = {}
    s = {}
    v = 0x1
.end annotation


# instance fields
.field final synthetic $media:Lcom/xunji/flashcards/anki/CardMedia;

.field final synthetic $opened:Lkotlin/jvm/internal/Ref$ObjectRef;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/io/InputStream;",
            ">;"
        }
    .end annotation
.end field

.field L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;


# direct methods
.method constructor <init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlin/jvm/internal/Ref$ObjectRef<",
            "Ljava/io/InputStream;",
            ">;",
            "Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$opened:Lkotlin/jvm/internal/Ref$ObjectRef;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$opened:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    invoke-direct {v0, v1, v2, v3, p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;-><init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 59
    iget v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->label:I

    packed-switch v1, :pswitch_data_4a

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_11
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v2, p1

    goto :goto_34

    :pswitch_1a
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$opened:Lkotlin/jvm/internal/Ref$ObjectRef;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->open:Lkotlin/jvm/functions/Function2;
    invoke-static {v2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getOpen$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function2;

    move-result-object v2

    iget-object v3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    iput-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->L$0:Ljava/lang/Object;

    const/4 v4, 0x1

    iput v4, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;->label:I

    invoke-interface {v2, v3, p0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    if-ne v2, v0, :cond_33

    return-object v0

    :cond_33
    move-object v0, v1

    :goto_34
    if-eqz v2, :cond_3b

    iput-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 118
    :cond_3b
    const/4 v0, 0x0

    .line 59
    .local v0, "$i$a$-requireNotNull-AnkiAudioPlayer$play$1$1$1\\1\\59\\0":I
    nop

    .end local v0    # "$i$a$-requireNotNull-AnkiAudioPlayer$play$1$1$1\\1\\59\\0":I
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "\u97f3\u9891\u6587\u4ef6\u7f3a\u5931"

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    nop

    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_1a
        :pswitch_11
    .end packed-switch
.end method

.class final Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "AnkiCardContent.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->play(Lcom/xunji/flashcards/anki/CardMedia;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Lkotlin/Unit;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.components.AnkiAudioPlayer$play$1"
    f = "AnkiCardContent.kt"
    i = {
        0x0
    }
    l = {
        0x3b
    }
    m = "invokeSuspend"
    n = {
        "opened"
    }
    s = {
        "L$0"
    }
    v = 0x1
.end annotation


# instance fields
.field final synthetic $media:Lcom/xunji/flashcards/anki/CardMedia;

.field final synthetic $token:J

.field L$0:Ljava/lang/Object;

.field label:I

.field final synthetic this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;


# direct methods
.method public static synthetic $r8$lambda$Fjn8ltfocTpVGDNS2z3XlJGDzsU(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invokeSuspend$lambda$0$0(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V

    return-void
.end method

.method public static synthetic $r8$lambda$KJUmVWoQYb2P-8PwpKASVM0i6EI(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;II)Z
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invokeSuspend$lambda$0$2(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;II)Z

    move-result p0

    return p0
.end method

.method public static synthetic $r8$lambda$ovSEwpLAB9sEyqSq5aAtyAkqKaU(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invokeSuspend$lambda$0$1(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V

    return-void
.end method

.method constructor <init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V
    .registers 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J",
            "Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;",
            ">;)V"
        }
    .end annotation

    iput-wide p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$token:J

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method private static final invokeSuspend$lambda$0$0(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V
    .registers 7
    .param p0, "$token"    # J
    .param p2, "this$0"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p3, "ready"    # Landroid/media/MediaPlayer;

    .line 66
    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J

    move-result-wide v0

    cmp-long v0, p0, v0

    if-nez v0, :cond_28

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getPlayer$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Landroid/media/MediaPlayer;

    move-result-object v0

    if-ne v0, p3, :cond_28

    :try_start_e
    invoke-virtual {p3}, Landroid/media/MediaPlayer;->start()V

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;

    move-result-object v0

    const-string v1, "\u6b63\u5728\u64ad\u653e"

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1a
    .catch Ljava/lang/Exception; {:try_start_e .. :try_end_1a} :catch_1b

    goto :goto_28

    :catch_1b
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    invoke-virtual {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;

    move-result-object v1

    const-string v2, "\u6b64\u8bbe\u5907\u65e0\u6cd5\u89e3\u7801\u6216\u64ad\u653e\u8be5\u97f3\u9891"

    invoke-interface {v1, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 67
    .end local v0    # "<unused var>":Ljava/lang/Exception;
    :cond_28
    :goto_28
    return-void
.end method

.method private static final invokeSuspend$lambda$0$1(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V
    .registers 6
    .param p0, "$token"    # J
    .param p2, "this$0"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p3, "it"    # Landroid/media/MediaPlayer;

    .line 68
    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J

    move-result-wide v0

    cmp-long v0, p0, v0

    if-nez v0, :cond_14

    invoke-virtual {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;

    move-result-object v0

    const-string v1, "\u64ad\u653e\u5b8c\u6210"

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_14
    return-void
.end method

.method private static final invokeSuspend$lambda$0$2(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;II)Z
    .registers 6
    .param p0, "$token"    # J
    .param p2, "this$0"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 69
    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J

    move-result-wide p3

    cmp-long p3, p0, p3

    if-nez p3, :cond_14

    invoke-virtual {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;
    invoke-static {p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;

    move-result-object p3

    const-string p4, "\u6b64\u8bbe\u5907\u65e0\u6cd5\u89e3\u7801\u6216\u64ad\u653e\u8be5\u97f3\u9891"

    invoke-interface {p3, p4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_14
    const/4 p3, 0x1

    return p3
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;

    iget-wide v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$token:J

    iget-object v3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v4, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    move-object v5, p2

    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;-><init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lkotlin/Unit;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 55
    iget v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->label:I

    const/4 v2, 0x0

    packed-switch v1, :pswitch_data_fe

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_12
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->L$0:Ljava/lang/Object;

    check-cast v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    .local v0, "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    :try_start_16
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_19
    .catchall {:try_start_16 .. :try_end_19} :catchall_1a

    goto :goto_48

    .line 72
    :catchall_1a
    move-exception v1

    goto/16 :goto_d1

    .line 55
    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    :pswitch_1d
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 56
    nop

    .line 57
    :try_start_21
    new-instance v1, Lkotlin/jvm/internal/Ref$ObjectRef;

    invoke-direct {v1}, Lkotlin/jvm/internal/Ref$ObjectRef;-><init>()V
    :try_end_26
    .catch Ljava/util/concurrent/CancellationException; {:try_start_21 .. :try_end_26} :catch_fb
    .catch Ljava/lang/Exception; {:try_start_21 .. :try_end_26} :catch_db

    .line 58
    .local v1, "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    nop

    .line 59
    :try_start_27
    invoke-static {}, Lkotlinx/coroutines/Dispatchers;->getIO()Lkotlinx/coroutines/CoroutineDispatcher;

    move-result-object v3

    check-cast v3, Lkotlin/coroutines/CoroutineContext;

    new-instance v4, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;

    iget-object v5, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v6, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    invoke-direct {v4, v1, v5, v6, v2}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$1;-><init>(Lkotlin/jvm/internal/Ref$ObjectRef;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    check-cast v4, Lkotlin/jvm/functions/Function2;

    move-object v5, p0

    check-cast v5, Lkotlin/coroutines/Continuation;

    iput-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->L$0:Ljava/lang/Object;

    const/4 v6, 0x1

    iput v6, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->label:I

    invoke-static {v3, v4, v5}, Lkotlinx/coroutines/BuildersKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v3
    :try_end_44
    .catchall {:try_start_27 .. :try_end_44} :catchall_cd

    if-ne v3, v0, :cond_47

    .line 55
    return-object v0

    .line 59
    :cond_47
    move-object v0, v1

    .line 60
    .end local v1    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_48
    :try_start_48
    iget-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    if-eqz v1, :cond_c1

    check-cast v1, Ljava/io/Closeable;

    iget-wide v3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$token:J

    iget-object v5, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    :try_end_52
    .catchall {:try_start_48 .. :try_end_52} :catchall_1a

    :try_start_52
    move-object v6, v1

    check-cast v6, Ljava/io/InputStream;

    .local v6, "it\\2":Ljava/io/InputStream;
    const/4 v7, 0x0

    .line 61
    .local v7, "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J
    invoke-static {v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J

    move-result-wide v8

    cmp-long v8, v3, v8

    if-eqz v8, :cond_6d

    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_60
    .catchall {:try_start_52 .. :try_end_60} :catchall_ba

    .line 60
    .end local v6    # "it\\2":Ljava/io/InputStream;
    .end local v7    # "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    :try_start_60
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_63
    .catchall {:try_start_60 .. :try_end_63} :catchall_1a

    .line 72
    :try_start_63
    iget-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/io/InputStream;

    if-eqz v1, :cond_6c

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_6c
    .catch Ljava/util/concurrent/CancellationException; {:try_start_63 .. :try_end_6c} :catch_fb
    .catch Ljava/lang/Exception; {:try_start_63 .. :try_end_6c} :catch_db

    :cond_6c
    return-object v3

    .line 62
    .restart local v6    # "it\\2":Ljava/io/InputStream;
    .restart local v7    # "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    :cond_6d
    :try_start_6d
    instance-of v8, v6, Ljava/io/FileInputStream;

    if-eqz v8, :cond_75

    move-object v8, v6

    check-cast v8, Ljava/io/FileInputStream;

    goto :goto_76

    :cond_75
    move-object v8, v2

    :goto_76
    if-eqz v8, :cond_b2

    .line 63
    .local v8, "file\\2":Ljava/io/FileInputStream;
    new-instance v9, Landroid/media/MediaPlayer;

    invoke-direct {v9}, Landroid/media/MediaPlayer;-><init>()V

    .local v9, "active\\2":Landroid/media/MediaPlayer;
    invoke-static {v5, v9}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$setPlayer$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V

    .line 64
    invoke-virtual {v8}, Ljava/io/FileInputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object v10

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setDataSource(Ljava/io/FileDescriptor;)V

    .line 65
    new-instance v10, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda0;

    invoke-direct {v10, v3, v4, v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda0;-><init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    .line 68
    new-instance v10, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;

    invoke-direct {v10, v3, v4, v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda1;-><init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    .line 69
    new-instance v10, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;

    invoke-direct {v10, v3, v4, v5}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1$$ExternalSyntheticLambda2;-><init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V

    invoke-virtual {v9, v10}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    .line 70
    invoke-virtual {v9}, Landroid/media/MediaPlayer;->prepareAsync()V

    .line 71
    nop

    .end local v6    # "it\\2":Ljava/io/InputStream;
    .end local v7    # "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    .end local v8    # "file\\2":Ljava/io/FileInputStream;
    .end local v9    # "active\\2":Landroid/media/MediaPlayer;
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a5
    .catchall {:try_start_6d .. :try_end_a5} :catchall_ba

    .line 60
    :try_start_a5
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V
    :try_end_a8
    .catchall {:try_start_a5 .. :try_end_a8} :catchall_1a

    .line 72
    :try_start_a8
    iget-object v1, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v1, Ljava/io/InputStream;

    if-eqz v1, :cond_f8

    invoke-virtual {v1}, Ljava/io/InputStream;->close()V
    :try_end_b1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_a8 .. :try_end_b1} :catch_fb
    .catch Ljava/lang/Exception; {:try_start_a8 .. :try_end_b1} :catch_db

    goto :goto_f8

    .line 62
    .restart local v6    # "it\\2":Ljava/io/InputStream;
    .restart local v7    # "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    :cond_b2
    :try_start_b2
    new-instance v2, Ljava/io/IOException;

    const-string v3, "\u65e0\u6cd5\u8bfb\u53d6\u672c\u5730\u97f3\u9891"

    invoke-direct {v2, v3}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p1    # "$result":Ljava/lang/Object;
    throw v2
    :try_end_ba
    .catchall {:try_start_b2 .. :try_end_ba} :catchall_ba

    .line 60
    .end local v6    # "it\\2":Ljava/io/InputStream;
    .end local v7    # "$i$a$-use-AnkiAudioPlayer$play$1$2\\2\\60\\0":I
    .restart local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catchall_ba
    move-exception v2

    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p1    # "$result":Ljava/lang/Object;
    :try_start_bb
    throw v2
    :try_end_bc
    .catchall {:try_start_bb .. :try_end_bc} :catchall_bc

    .restart local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catchall_bc
    move-exception v3

    :try_start_bd
    invoke-static {v1, v2}, Lkotlin/io/CloseableKt;->closeFinally(Ljava/io/Closeable;Ljava/lang/Throwable;)V

    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p1    # "$result":Ljava/lang/Object;
    throw v3

    .restart local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p1    # "$result":Ljava/lang/Object;
    :cond_c1
    const-string v1, "Required value was null."

    new-instance v2, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v2, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .end local p1    # "$result":Ljava/lang/Object;
    throw v2
    :try_end_cd
    .catchall {:try_start_bd .. :try_end_cd} :catchall_1a

    .line 72
    .restart local v1    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catchall_cd
    move-exception v0

    move-object v11, v1

    move-object v1, v0

    move-object v0, v11

    .end local v1    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    :goto_d1
    :try_start_d1
    iget-object v2, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    check-cast v2, Ljava/io/InputStream;

    if-eqz v2, :cond_da

    invoke-virtual {v2}, Ljava/io/InputStream;->close()V

    .end local p1    # "$result":Ljava/lang/Object;
    :cond_da
    throw v1
    :try_end_db
    .catch Ljava/util/concurrent/CancellationException; {:try_start_d1 .. :try_end_db} :catch_fb
    .catch Ljava/lang/Exception; {:try_start_d1 .. :try_end_db} :catch_db

    .line 73
    .end local v0    # "opened":Lkotlin/jvm/internal/Ref$ObjectRef;
    .restart local p1    # "$result":Ljava/lang/Object;
    :catch_db
    move-exception v0

    .local v0, "<unused var>":Ljava/lang/Exception;
    iget-wide v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->$token:J

    iget-object v3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J
    invoke-static {v3}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J

    move-result-wide v3

    cmp-long v1, v1, v3

    if-nez v1, :cond_f8

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;
    invoke-static {v1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;

    move-result-object v1

    const-string v2, "\u6b64\u8bbe\u5907\u65e0\u6cd5\u8bfb\u53d6\u6216\u64ad\u653e\u8be5\u97f3\u9891"

    invoke-interface {v1, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    .end local v0    # "<unused var>":Ljava/lang/Exception;
    :cond_f8
    :goto_f8
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0

    .line 73
    :catch_fb
    move-exception v0

    .local v0, "e":Ljava/util/concurrent/CancellationException;
    throw v0

    nop

    :pswitch_data_fe
    .packed-switch 0x0
        :pswitch_1d
        :pswitch_12
    .end packed-switch
.end method

.class public final Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
.super Ljava/lang/Object;
.source "AnkiCardContent.kt"

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiCardContent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiAudioPlayer\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,117:1\n1#2:118\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0002\n\u0002\u0008\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\u0008\u0006\u0008\u0001\u0018\u00002\u00020\u0001BI\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012$\u0010\u0004\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0006\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00080\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005\u0012\u0012\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\r0\u000b\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u000e\u0010\u001b\u001a\u00020\r2\u0006\u0010\u001c\u001a\u00020\u0006J\u0008\u0010\u001d\u001a\u00020\rH\u0016R\u000e\u0010\u0002\u001a\u00020\u0003X\u0082\u0004\u00a2\u0006\u0002\n\u0000R.\u0010\u0004\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0006\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00080\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0005X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\u0010R\u001a\u0010\n\u001a\u000e\u0012\u0004\u0012\u00020\u000c\u0012\u0004\u0012\u00020\r0\u000bX\u0082\u0004\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u0004\u0018\u00010\u0012X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0010\u0010\u0013\u001a\u0004\u0018\u00010\u0014X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u000e\u0010\u0015\u001a\u00020\u0016X\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0017\u001a\u00020\u00188@X\u0080\u0004\u00a2\u0006\u0006\u001a\u0004\u0008\u0019\u0010\u001a\u00a8\u0006\u001e"
    }
    d2 = {
        "Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;",
        "Ljava/io/Closeable;",
        "scope",
        "Lkotlinx/coroutines/CoroutineScope;",
        "open",
        "Lkotlin/Function2;",
        "Lcom/xunji/flashcards/anki/CardMedia;",
        "Lkotlin/coroutines/Continuation;",
        "Ljava/io/InputStream;",
        "",
        "status",
        "Lkotlin/Function1;",
        "",
        "",
        "<init>",
        "(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V",
        "Lkotlin/jvm/functions/Function2;",
        "player",
        "Landroid/media/MediaPlayer;",
        "job",
        "Lkotlinx/coroutines/Job;",
        "generation",
        "",
        "hasPlayer",
        "",
        "getHasPlayer$app_debug",
        "()Z",
        "play",
        "media",
        "close",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I


# instance fields
.field private generation:J

.field private job:Lkotlinx/coroutines/Job;

.field private final open:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private player:Landroid/media/MediaPlayer;

.field private final scope:Lkotlinx/coroutines/CoroutineScope;

.field private final status:Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function1<",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const/16 v0, 0x8

    sput v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->$stable:I

    return-void
.end method

.method public constructor <init>(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V
    .registers 5
    .param p1, "scope"    # Lkotlinx/coroutines/CoroutineScope;
    .param p2, "open"    # Lkotlin/jvm/functions/Function2;
    .param p3, "status"    # Lkotlin/jvm/functions/Function1;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Lkotlin/jvm/functions/Function1<",
            "-",
            "Ljava/lang/String;",
            "Lkotlin/Unit;",
            ">;)V"
        }
    .end annotation

    const-string v0, "scope"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "open"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "status"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 48
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->scope:Lkotlinx/coroutines/CoroutineScope;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->open:Lkotlin/jvm/functions/Function2;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;

    return-void
.end method

.method public static final synthetic access$getGeneration$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)J
    .registers 3
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 48
    iget-wide v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J

    return-wide v0
.end method

.method public static final synthetic access$getOpen$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function2;
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 48
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->open:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public static final synthetic access$getPlayer$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Landroid/media/MediaPlayer;
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 48
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;

    return-object v0
.end method

.method public static final synthetic access$getStatus$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)Lkotlin/jvm/functions/Function1;
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 48
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;

    return-object v0
.end method

.method public static final synthetic access$setPlayer$p(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroid/media/MediaPlayer;)V
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p1, "<set-?>"    # Landroid/media/MediaPlayer;

    .line 48
    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;

    return-void
.end method


# virtual methods
.method public close()V
    .registers 6

    .line 76
    iget-wide v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J

    const-wide/16 v2, 0x1

    add-long/2addr v0, v2

    iput-wide v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J

    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->job:Lkotlinx/coroutines/Job;

    const/4 v1, 0x0

    if-eqz v0, :cond_10

    const/4 v2, 0x1

    invoke-static {v0, v1, v2, v1}, Lkotlinx/coroutines/Job$DefaultImpls;->cancel$default(Lkotlinx/coroutines/Job;Ljava/util/concurrent/CancellationException;ILjava/lang/Object;)V

    :cond_10
    iput-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->job:Lkotlinx/coroutines/Job;

    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_3c

    .line 118
    .local v0, "it\\1":Landroid/media/MediaPlayer;
    const/4 v2, 0x0

    .line 76
    .local v2, "$i$a$-let-AnkiAudioPlayer$close$1\\1\\76\\0":I
    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnPreparedListener(Landroid/media/MediaPlayer$OnPreparedListener;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnCompletionListener(Landroid/media/MediaPlayer$OnCompletionListener;)V

    invoke-virtual {v0, v1}, Landroid/media/MediaPlayer;->setOnErrorListener(Landroid/media/MediaPlayer$OnErrorListener;)V

    :try_start_20
    sget-object v3, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v3, p0

    check-cast v3, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .line 118
    .local v3, "$this$close_u24lambda_u240_u240\\2":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    const/4 v4, 0x0

    .line 76
    .local v4, "$i$a$-runCatching-AnkiAudioPlayer$close$1$1\\2\\76\\1":I
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->stop()V

    .end local v3    # "$this$close_u24lambda_u240_u240\\2":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .end local v4    # "$i$a$-runCatching-AnkiAudioPlayer$close$1$1\\2\\76\\1":I
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2e
    .catchall {:try_start_20 .. :try_end_2e} :catchall_2f

    goto :goto_39

    :catchall_2f
    move-exception v3

    sget-object v4, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v3}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v3

    invoke-static {v3}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_39
    invoke-virtual {v0}, Landroid/media/MediaPlayer;->release()V

    .end local v0    # "it\\1":Landroid/media/MediaPlayer;
    .end local v2    # "$i$a$-let-AnkiAudioPlayer$close$1\\1\\76\\0":I
    :cond_3c
    iput-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;

    return-void
.end method

.method public final getHasPlayer$app_debug()Z
    .registers 2

    .line 52
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->player:Landroid/media/MediaPlayer;

    if-eqz v0, :cond_6

    const/4 v0, 0x1

    goto :goto_7

    :cond_6
    const/4 v0, 0x0

    :goto_7
    return v0
.end method

.method public final play(Lcom/xunji/flashcards/anki/CardMedia;)V
    .registers 12
    .param p1, "media"    # Lcom/xunji/flashcards/anki/CardMedia;

    const-string v0, "media"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 54
    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    iget-wide v2, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->generation:J

    .local v2, "token":J
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->status:Lkotlin/jvm/functions/Function1;

    const-string v1, "\u6b63\u5728\u51c6\u5907\u97f3\u9891\u2026"

    invoke-interface {v0, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 55
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->scope:Lkotlinx/coroutines/CoroutineScope;

    new-instance v1, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;

    const/4 v6, 0x0

    move-object v4, p0

    move-object v5, p1

    .end local p1    # "media":Lcom/xunji/flashcards/anki/CardMedia;
    .local v5, "media":Lcom/xunji/flashcards/anki/CardMedia;
    invoke-direct/range {v1 .. v6}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer$play$1;-><init>(JLcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    move-object p1, v4

    move-object v4, v1

    move-object v1, v5

    .end local v5    # "media":Lcom/xunji/flashcards/anki/CardMedia;
    .local v1, "media":Lcom/xunji/flashcards/anki/CardMedia;
    move-object v7, v4

    check-cast v7, Lkotlin/jvm/functions/Function2;

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v5, 0x0

    move-object v4, v0

    invoke-static/range {v4 .. v9}, Lkotlinx/coroutines/BuildersKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlinx/coroutines/CoroutineStart;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Lkotlinx/coroutines/Job;

    move-result-object v0

    iput-object v0, p1, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->job:Lkotlinx/coroutines/Job;

    .line 75
    return-void
.end method

.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroidx/lifecycle/LifecycleEventObserver;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

.field public final synthetic f$1:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 4

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/runtime/MutableState;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$2:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final onStateChanged(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$1:Landroidx/compose/runtime/MutableState;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;->f$2:Landroidx/compose/runtime/MutableState;

    invoke-static {v0, v1, v2, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->$r8$lambda$5UmIpQScaLZtxMhqcNNGNMhqMFw(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V

    return-void
.end method

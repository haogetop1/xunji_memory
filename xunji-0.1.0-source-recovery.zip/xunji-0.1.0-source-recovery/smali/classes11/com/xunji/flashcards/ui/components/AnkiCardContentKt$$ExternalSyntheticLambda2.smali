.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/lifecycle/LifecycleOwner;

.field public final synthetic f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$3:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 5

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$0:Landroidx/lifecycle/LifecycleOwner;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iput-object p3, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$2:Landroidx/compose/runtime/MutableState;

    iput-object p4, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$3:Landroidx/compose/runtime/MutableState;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$0:Landroidx/lifecycle/LifecycleOwner;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$1:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$2:Landroidx/compose/runtime/MutableState;

    iget-object v3, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;->f$3:Landroidx/compose/runtime/MutableState;

    check-cast p1, Landroidx/compose/runtime/DisposableEffectScope;

    invoke-static {v0, v1, v2, v3, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->$r8$lambda$3Bkzc50tdq-CiREjAPbGMmkTeSo(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p1

    return-object p1
.end method

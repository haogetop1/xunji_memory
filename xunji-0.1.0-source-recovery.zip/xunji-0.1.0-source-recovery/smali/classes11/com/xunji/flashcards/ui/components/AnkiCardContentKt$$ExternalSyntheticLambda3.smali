.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Landroid/webkit/WebView;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(Landroid/webkit/WebView;I)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;->f$0:Landroid/webkit/WebView;

    iput p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;->f$1:I

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;->f$0:Landroid/webkit/WebView;

    iget v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;->f$1:I

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->$r8$lambda$-Z8-6mS4fyTiL1nTpWxWgrVVCpc(Landroid/webkit/WebView;I)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

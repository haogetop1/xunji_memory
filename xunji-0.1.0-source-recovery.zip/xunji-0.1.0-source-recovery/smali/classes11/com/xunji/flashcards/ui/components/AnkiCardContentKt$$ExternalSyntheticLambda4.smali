.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

.field public final synthetic f$1:Landroid/webkit/WebView;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;->f$1:Landroid/webkit/WebView;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;->f$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;->f$1:Landroid/webkit/WebView;

    check-cast p1, Landroidx/compose/runtime/DisposableEffectScope;

    invoke-static {v0, v1, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->$r8$lambda$DjjbH0kPWzjgQXmtX3MQZ3T9acs(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p1

    return-object p1
.end method

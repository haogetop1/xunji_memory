.class public final synthetic Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

.field public final synthetic f$1:Lcom/xunji/flashcards/anki/CardMedia;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)V
    .registers 3

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;->f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;->f$1:Lcom/xunji/flashcards/anki/CardMedia;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 3

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;->f$0:Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;->f$1:Lcom/xunji/flashcards/anki/CardMedia;

    invoke-static {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->$r8$lambda$OCtcAyuPjC6eJod4LVLzV6cUDK8(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

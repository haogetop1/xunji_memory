.class public final Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "Effects.kt"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nEffects.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope$onDispose$1\n+ 2 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiCardContentKt\n*L\n1#1,69:1\n109#2:70\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004\u00b8\u0006\u0000"
    }
    d2 = {
        "androidx/compose/runtime/DisposableEffectScope$onDispose$1",
        "Landroidx/compose/runtime/DisposableEffectResult;",
        "dispose",
        "",
        "runtime"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic $session$inlined:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

.field final synthetic $web$inlined:Landroid/webkit/WebView;


# direct methods
.method public constructor <init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;)V
    .registers 3

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$session$inlined:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$web$inlined:Landroid/webkit/WebView;

    .line 66
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public dispose()V
    .registers 3

    .line 68
    const/4 v0, 0x0

    .line 70
    .local v0, "$i$a$-onDispose-AnkiCardContentKt$AnkiCardContent$2$2$1$1\\1\\68\\0":I
    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$session$inlined:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    invoke-virtual {v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->close()V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$web$inlined:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->stopLoading()V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$web$inlined:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->onPause()V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$web$inlined:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->removeAllViews()V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;->$web$inlined:Landroid/webkit/WebView;

    invoke-virtual {v1}, Landroid/webkit/WebView;->destroy()V

    .line 68
    .end local v0    # "$i$a$-onDispose-AnkiCardContentKt$AnkiCardContent$2$2$1$1\\1\\68\\0":I
    nop

    .line 69
    return-void
.end method

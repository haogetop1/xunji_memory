.class public final Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;
.super Ljava/lang/Object;
.source "AnkiCardContent.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiCardContent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiCardContentKt\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 Effects.kt\nandroidx/compose/runtime/EffectsKt\n+ 4 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 5 Effects.kt\nandroidx/compose/runtime/EffectsKt$rememberCoroutineScope$1\n+ 6 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 7 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 8 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 9 Composer.kt\nandroidx/compose/runtime/Updater\n+ 10 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 11 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 12 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 13 SnapshotState.kt\nandroidx/compose/runtime/SnapshotStateKt__SnapshotStateKt\n+ 14 Effects.kt\nandroidx/compose/runtime/DisposableEffectScope\n*L\n1#1,117:1\n75#2:118\n75#2:119\n75#2:208\n607#3:120\n604#3,6:121\n1282#4,3:127\n1285#4,3:131\n1282#4,6:134\n1282#4,6:140\n1282#4,6:146\n1282#4,6:152\n1282#4,6:195\n1282#4,3:201\n1285#4,3:205\n1282#4,6:209\n1282#4,6:215\n1282#4,6:221\n1282#4,6:267\n605#5:130\n87#6:158\n84#6,9:159\n87#6:228\n84#6,9:229\n94#6:277\n94#6:281\n80#7,6:168\n87#7,3:183\n90#7,2:192\n80#7,6:238\n87#7,3:253\n90#7,2:262\n94#7:276\n94#7:280\n391#8,9:174\n400#8:194\n391#8,9:244\n400#8:264\n401#8,2:274\n401#8,2:278\n4360#9,6:186\n4360#9,6:256\n1#10:204\n113#11:227\n1878#12,2:265\n1880#12:273\n85#13:282\n117#13,2:283\n85#13:285\n117#13,2:286\n66#14,5:288\n66#14,5:293\n*S KotlinDebug\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiCardContentKt\n*L\n83#1:118\n84#1:119\n107#1:208\n85#1:120\n85#1:121,6\n85#1:127,3\n85#1:131,3\n86#1:134,6\n87#1:140,6\n88#1:146,6\n89#1:152,6\n96#1:195,6\n100#1:201,3\n100#1:205,3\n108#1:209,6\n109#1:215,6\n110#1:221,6\n112#1:267,6\n85#1:130\n94#1:158\n94#1:159,9\n112#1:228\n112#1:229,9\n112#1:277\n94#1:281\n94#1:168,6\n94#1:183,3\n94#1:192,2\n112#1:238,6\n112#1:253,3\n112#1:262,2\n112#1:276\n94#1:280\n94#1:174,9\n94#1:194\n112#1:244,9\n112#1:264\n112#1:274,2\n94#1:278,2\n94#1:186,6\n112#1:256,6\n112#1:227\n112#1:265,2\n112#1:273\n86#1:282\n86#1:283,2\n87#1:285\n87#1:286,2\n92#1:288,5\n109#1:293,5\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u00006\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\u001aE\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032$\u0010\u0004\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0006\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00080\u0007\u0012\u0006\u0012\u0004\u0018\u00010\t0\u00052\u0008\u0008\u0002\u0010\n\u001a\u00020\u000bH\u0007\u00a2\u0006\u0002\u0010\u000c\u00a8\u0006\r\u00b2\u0006\n\u0010\u000e\u001a\u00020\u000fX\u008a\u008e\u0002\u00b2\u0006\n\u0010\u0010\u001a\u00020\u0011X\u008a\u008e\u0002"
    }
    d2 = {
        "AnkiCardContent",
        "",
        "card",
        "Lcom/xunji/flashcards/anki/RenderedCard;",
        "openMedia",
        "Lkotlin/Function2;",
        "Lcom/xunji/flashcards/anki/CardMedia;",
        "Lkotlin/coroutines/Continuation;",
        "Ljava/io/InputStream;",
        "",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V",
        "app_debug",
        "audioStatus",
        "",
        "foreground",
        ""
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$-Z8-6mS4fyTiL1nTpWxWgrVVCpc(Landroid/webkit/WebView;I)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$8$2$0(Landroid/webkit/WebView;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$3Bkzc50tdq-CiREjAPbGMmkTeSo(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$7$0(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$4yYMmfhfOLtlcoQNl_r9CI28RQQ(ILcom/xunji/flashcards/anki/CardMedia;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$8$5$0$1(ILcom/xunji/flashcards/anki/CardMedia;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$5UmIpQScaLZtxMhqcNNGNMhqMFw(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$7$0$0(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V

    return-void
.end method

.method public static synthetic $r8$lambda$DjjbH0kPWzjgQXmtX3MQZ3T9acs(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$8$3$0(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$KwWYBNRdmtU65QhkaccSIJpRPw4(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$6$0(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$OCtcAyuPjC6eJod4LVLzV6cUDK8(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$8$5$0$0$0(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Qp42WP80M8Lx1xR7knoPjNWkSts(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$9(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$sfHxOGLsKX3R-m-NdQsYKDssKno(Landroid/webkit/WebView;Landroid/content/Context;)Landroid/webkit/WebView;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$8$4$0(Landroid/webkit/WebView;Landroid/content/Context;)Landroid/webkit/WebView;

    move-result-object p0

    return-object p0
.end method

.method public static final AnkiCardContent(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
    .registers 89
    .param p0, "card"    # Lcom/xunji/flashcards/anki/RenderedCard;
    .param p1, "openMedia"    # Lkotlin/jvm/functions/Function2;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/anki/RenderedCard;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;+",
            "Ljava/lang/Object;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v0, p0

    move-object/from16 v8, p1

    move/from16 v9, p4

    const-string v1, "card"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "openMedia"

    invoke-static {v8, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 79
    const v1, 0x55947475

    move-object/from16 v2, p3

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(AnkiCardContent)N(card,openMedia,modifier)79@4917L11,80@4981L11:AnkiCardContent.kt#8ao140"

    invoke-static {v10, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p4

    .local v2, "$dirty":I
    and-int/lit8 v3, v9, 0x6

    if-nez v3, :cond_37

    and-int/lit8 v3, v9, 0x8

    if-nez v3, :cond_2d

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    goto :goto_31

    :cond_2d
    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    :goto_31
    if-eqz v3, :cond_35

    const/4 v3, 0x4

    goto :goto_36

    :cond_35
    const/4 v3, 0x2

    :goto_36
    or-int/2addr v2, v3

    :cond_37
    and-int/lit8 v3, v9, 0x30

    if-nez v3, :cond_47

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_44

    const/16 v3, 0x20

    goto :goto_46

    :cond_44
    const/16 v3, 0x10

    :goto_46
    or-int/2addr v2, v3

    :cond_47
    and-int/lit8 v3, p5, 0x4

    if-eqz v3, :cond_50

    or-int/lit16 v2, v2, 0x180

    move-object/from16 v4, p2

    goto :goto_65

    :cond_50
    and-int/lit16 v4, v9, 0x180

    if-nez v4, :cond_63

    move-object/from16 v4, p2

    invoke-interface {v10, v4}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_5f

    const/16 v5, 0x100

    goto :goto_61

    :cond_5f
    const/16 v5, 0x80

    :goto_61
    or-int/2addr v2, v5

    goto :goto_65

    :cond_63
    move-object/from16 v4, p2

    :goto_65
    move v12, v2

    .end local v2    # "$dirty":I
    .local v12, "$dirty":I
    and-int/lit16 v2, v12, 0x93

    const/16 v5, 0x92

    const/4 v14, 0x0

    if-eq v2, v5, :cond_6f

    const/4 v2, 0x1

    goto :goto_70

    :cond_6f
    move v2, v14

    :goto_70
    and-int/lit8 v5, v12, 0x1

    invoke-interface {v10, v2, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_904

    if-eqz v3, :cond_81

    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    move-object/from16 v36, v2

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v2, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_83

    .end local v2    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_81
    move-object/from16 v36, v4

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v36, "modifier":Landroidx/compose/ui/Modifier;
    :goto_83
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_8f

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.components.AnkiCardContent (AnkiCardContent.kt:78)"

    invoke-static {v1, v12, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 80
    :cond_8f
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v10, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->toArgb-8_81llA(J)I

    move-result v37

    .line 81
    .local v37, "textColor":I
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v2, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v10, v2}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v1

    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->toArgb-8_81llA(J)I

    move-result v38

    .line 82
    .local v38, "background":I
    invoke-static/range {v37 .. v37}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v10, v0, v1}, Landroidx/compose/runtime/Composer;->joinKey(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    invoke-static/range {v38 .. v38}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v10, v1, v2}, Landroidx/compose/runtime/Composer;->joinKey(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const v2, 0x424955ad

    invoke-interface {v10, v2, v1}, Landroidx/compose/runtime/Composer;->startMovableGroup(ILjava/lang/Object;)V

    const-string v1, "82@5080L7,83@5126L7,84@5152L24,85@5204L31,86@5262L92,87@5373L64,88@5470L381,88@5446L405,93@5860L2020"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 83
    invoke-static {}, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->getLocalContext()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v1

    check-cast v1, Landroidx/compose/runtime/CompositionLocal;

    .local v1, "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    const/4 v2, 0x0

    .local v2, "$changed\\1":I
    move-object v3, v10

    .local v3, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 118
    .local v4, "$i$f$getCurrent\\1\\83":I
    const v15, 0x789c5f52

    const-string v5, "CC(<get-current>):CompositionLocal.kt#9igjgp"

    invoke-static {v3, v15, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 83
    .end local v1    # "this_\\1":Landroidx/compose/runtime/CompositionLocal;
    .end local v2    # "$changed\\1":I
    .end local v3    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$getCurrent\\1\\83":I
    move-object v1, v6

    check-cast v1, Landroid/content/Context;

    .line 84
    .local v1, "context":Landroid/content/Context;
    invoke-static {}, Landroidx/lifecycle/compose/LocalLifecycleOwnerKt;->getLocalLifecycleOwner()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    .local v2, "this_\\2":Landroidx/compose/runtime/CompositionLocal;
    const/4 v3, 0x0

    .local v3, "$changed\\2":I
    move-object v4, v10

    .local v4, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 119
    .local v6, "$i$f$getCurrent\\2\\84":I
    invoke-static {v4, v15, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 84
    .end local v2    # "this_\\2":Landroidx/compose/runtime/CompositionLocal;
    .end local v3    # "$changed\\2":I
    .end local v4    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$getCurrent\\2\\84":I
    move-object v2, v7

    check-cast v2, Landroidx/lifecycle/LifecycleOwner;

    .line 85
    .local v2, "owner":Landroidx/lifecycle/LifecycleOwner;
    move v3, v14

    .local v3, "$changed\\3":I
    .local v4, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v6, 0x0

    .line 120
    .local v6, "$i$f$rememberCoroutineScope\\3\\85":I
    const v7, 0x2e20b340

    const-string v15, "CC(rememberCoroutineScope)N(getContext)608@27648L68:Effects.kt#9igjgp"

    invoke-static {v4, v7, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 121
    nop

    .line 125
    move-object v7, v4

    .line 126
    .local v7, "composer\\3":Landroidx/compose/runtime/Composer;
    const v15, 0x28c10104

    const-string v13, "CC(remember):Effects.kt#9igjgp"

    invoke-static {v4, v15, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v13, 0x0

    .local v13, "invalid\\4":Z
    move-object v15, v4

    .local v15, "$this$cache\\4":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    .line 127
    .local v16, "$i$f$cache\\4\\126":I
    invoke-interface {v15}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v14

    .local v14, "it\\4":Ljava/lang/Object;
    const/16 v18, 0x0

    .line 128
    .local v18, "$i$a$-let-ComposerKt$cache$1\\5\\127\\4":I
    sget-object v19, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v19 .. v19}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v11

    if-ne v14, v11, :cond_134

    .line 129
    const/4 v11, 0x0

    .line 126
    .local v11, "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\6\\129\\3":I
    const/16 v19, 0x0

    .line 130
    .local v19, "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\7\\126\\0":I
    sget-object v19, Lkotlin/coroutines/EmptyCoroutineContext;->INSTANCE:Lkotlin/coroutines/EmptyCoroutineContext;

    .line 126
    .end local v19    # "$i$a$-rememberCoroutineScope-EffectsKt$rememberCoroutineScope$1\\7\\126\\0":I
    move-object/from16 v0, v19

    check-cast v0, Lkotlin/coroutines/CoroutineContext;

    invoke-static {v0, v7}, Landroidx/compose/runtime/EffectsKt;->createCompositionCoroutineScope(Lkotlin/coroutines/CoroutineContext;Landroidx/compose/runtime/Composer;)Lkotlinx/coroutines/CoroutineScope;

    move-result-object v0

    .line 129
    .end local v11    # "$i$a$-cache-EffectsKt$rememberCoroutineScope$2\\6\\129\\3":I
    nop

    .line 131
    .local v0, "value\\5":Ljava/lang/Object;
    invoke-interface {v15, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 132
    move-object v14, v0

    .end local v0    # "value\\5":Ljava/lang/Object;
    goto :goto_135

    .line 133
    :cond_134
    nop

    .line 127
    .end local v14    # "it\\4":Ljava/lang/Object;
    .end local v18    # "$i$a$-let-ComposerKt$cache$1\\5\\127\\4":I
    :goto_135
    nop

    .line 126
    .end local v13    # "invalid\\4":Z
    .end local v15    # "$this$cache\\4":Landroidx/compose/runtime/Composer;
    .end local v16    # "$i$f$cache\\4\\126":I
    check-cast v14, Lkotlinx/coroutines/CoroutineScope;

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 120
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 126
    nop

    .line 85
    .end local v3    # "$changed\\3":I
    .end local v4    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v6    # "$i$f$rememberCoroutineScope\\3\\85":I
    .end local v7    # "composer\\3":Landroidx/compose/runtime/Composer;
    move-object v11, v14

    .line 86
    .local v11, "scope":Lkotlinx/coroutines/CoroutineScope;
    const v0, 0x42496254

    const-string v13, "CC(remember):AnkiCardContent.kt#9igjgp"

    invoke-static {v10, v0, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\8":Z
    move-object v3, v10

    .local v3, "$this$cache\\8":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 134
    .local v4, "$i$f$cache\\8\\86":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\8":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 135
    .local v7, "$i$a$-let-ComposerKt$cache$1\\9\\134\\8":I
    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    const/4 v15, 0x0

    if-ne v6, v14, :cond_16b

    .line 136
    const/4 v14, 0x0

    .line 86
    .local v14, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$audioStatus$2\\10\\136\\0":I
    move/from16 v16, v0

    .end local v0    # "invalid\\8":Z
    .local v16, "invalid\\8":Z
    const-string v0, ""

    move-object/from16 v18, v1

    const/4 v1, 0x2

    .end local v1    # "context":Landroid/content/Context;
    .local v18, "context":Landroid/content/Context;
    invoke-static {v0, v15, v1, v15}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 136
    .end local v14    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$audioStatus$2\\10\\136\\0":I
    nop

    .line 137
    .local v0, "value\\9":Ljava/lang/Object;
    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 138
    move-object v6, v0

    .end local v0    # "value\\9":Ljava/lang/Object;
    goto :goto_16f

    .line 139
    .end local v16    # "invalid\\8":Z
    .end local v18    # "context":Landroid/content/Context;
    .local v0, "invalid\\8":Z
    .restart local v1    # "context":Landroid/content/Context;
    :cond_16b
    move/from16 v16, v0

    move-object/from16 v18, v1

    .line 134
    .end local v0    # "invalid\\8":Z
    .end local v1    # "context":Landroid/content/Context;
    .end local v6    # "it\\8":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\9\\134\\8":I
    .restart local v16    # "invalid\\8":Z
    .restart local v18    # "context":Landroid/content/Context;
    :goto_16f
    nop

    .line 86
    .end local v3    # "$this$cache\\8":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\8\\86":I
    .end local v16    # "invalid\\8":Z
    move-object v14, v6

    check-cast v14, Landroidx/compose/runtime/MutableState;

    .local v14, "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 87
    const v0, 0x424969d1

    invoke-static {v10, v0, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\11":Z
    move-object v1, v10

    .local v1, "$this$cache\\11":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 140
    .local v3, "$i$f$cache\\11\\87":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\11":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 141
    .local v6, "$i$a$-let-ComposerKt$cache$1\\12\\140\\11":I
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_1af

    .line 142
    const/4 v7, 0x0

    .line 87
    .local v7, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$foreground$2\\13\\142\\0":I
    invoke-interface {v2}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Landroidx/lifecycle/Lifecycle;->getCurrentState()Landroidx/lifecycle/Lifecycle$State;

    move-result-object v15

    move/from16 v16, v0

    .end local v0    # "invalid\\11":Z
    .local v16, "invalid\\11":Z
    sget-object v0, Landroidx/lifecycle/Lifecycle$State;->RESUMED:Landroidx/lifecycle/Lifecycle$State;

    invoke-virtual {v15, v0}, Landroidx/lifecycle/Lifecycle$State;->isAtLeast(Landroidx/lifecycle/Lifecycle$State;)Z

    move-result v0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    move/from16 v21, v3

    const/4 v3, 0x0

    const/4 v15, 0x2

    .end local v3    # "$i$f$cache\\11\\87":I
    .local v21, "$i$f$cache\\11\\87":I
    invoke-static {v0, v3, v15, v3}, Landroidx/compose/runtime/SnapshotStateKt;->mutableStateOf$default(Ljava/lang/Object;Landroidx/compose/runtime/SnapshotMutationPolicy;ILjava/lang/Object;)Landroidx/compose/runtime/MutableState;

    move-result-object v0

    .line 142
    .end local v7    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$foreground$2\\13\\142\\0":I
    nop

    .line 143
    .local v0, "value\\12":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 144
    move-object v4, v0

    .end local v0    # "value\\12":Ljava/lang/Object;
    goto :goto_1b3

    .line 145
    .end local v16    # "invalid\\11":Z
    .end local v21    # "$i$f$cache\\11\\87":I
    .local v0, "invalid\\11":Z
    .restart local v3    # "$i$f$cache\\11\\87":I
    :cond_1af
    move/from16 v16, v0

    move/from16 v21, v3

    .line 140
    .end local v0    # "invalid\\11":Z
    .end local v3    # "$i$f$cache\\11\\87":I
    .end local v4    # "it\\11":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\12\\140\\11":I
    .restart local v16    # "invalid\\11":Z
    .restart local v21    # "$i$f$cache\\11\\87":I
    :goto_1b3
    nop

    .line 87
    .end local v1    # "$this$cache\\11":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\11":Z
    .end local v21    # "$i$f$cache\\11\\87":I
    move-object v15, v4

    check-cast v15, Landroidx/compose/runtime/MutableState;

    .local v15, "foreground$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 88
    const v0, 0x42497795

    invoke-static {v10, v0, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v0, 0x0

    .local v0, "invalid\\14":Z
    move-object v1, v10

    .local v1, "$this$cache\\14":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 146
    .local v3, "$i$f$cache\\14\\88":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\14":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 147
    .local v6, "$i$a$-let-ComposerKt$cache$1\\15\\146\\14":I
    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v4, v7, :cond_1e5

    .line 148
    const/4 v7, 0x0

    .line 88
    .local v7, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$audio$1\\16\\148\\0":I
    move/from16 v16, v0

    .end local v0    # "invalid\\14":Z
    .local v16, "invalid\\14":Z
    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    move/from16 v21, v3

    .end local v3    # "$i$f$cache\\14\\88":I
    .local v21, "$i$f$cache\\14\\88":I
    new-instance v3, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda1;

    invoke-direct {v3, v14}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/runtime/MutableState;)V

    invoke-direct {v0, v11, v8, v3}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;-><init>(Lkotlinx/coroutines/CoroutineScope;Lkotlin/jvm/functions/Function2;Lkotlin/jvm/functions/Function1;)V

    .line 148
    .end local v7    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$audio$1\\16\\148\\0":I
    nop

    .line 149
    .local v0, "value\\15":Ljava/lang/Object;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 150
    move-object v4, v0

    .end local v0    # "value\\15":Ljava/lang/Object;
    goto :goto_1e9

    .line 151
    .end local v16    # "invalid\\14":Z
    .end local v21    # "$i$f$cache\\14\\88":I
    .local v0, "invalid\\14":Z
    .restart local v3    # "$i$f$cache\\14\\88":I
    :cond_1e5
    move/from16 v16, v0

    move/from16 v21, v3

    .line 146
    .end local v0    # "invalid\\14":Z
    .end local v3    # "$i$f$cache\\14\\88":I
    .end local v4    # "it\\14":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\15\\146\\14":I
    .restart local v16    # "invalid\\14":Z
    .restart local v21    # "$i$f$cache\\14\\88":I
    :goto_1e9
    nop

    .line 88
    .end local v1    # "$this$cache\\14":Landroidx/compose/runtime/Composer;
    .end local v16    # "invalid\\14":Z
    .end local v21    # "$i$f$cache\\14\\88":I
    move-object v0, v4

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;

    .local v0, "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 89
    const v1, 0x424984f2

    invoke-static {v10, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v1

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v1, v3

    .local v1, "invalid\\17":Z
    move-object v3, v10

    .local v3, "$this$cache\\17":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 152
    .local v4, "$i$f$cache\\17\\89":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v6

    .local v6, "it\\17":Ljava/lang/Object;
    const/4 v7, 0x0

    .line 153
    .local v7, "$i$a$-let-ComposerKt$cache$1\\18\\152\\17":I
    if-nez v1, :cond_214

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    move/from16 v21, v1

    .end local v1    # "invalid\\17":Z
    .local v21, "invalid\\17":Z
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v1

    if-ne v6, v1, :cond_213

    goto :goto_216

    .line 157
    :cond_213
    goto :goto_223

    .line 153
    .end local v21    # "invalid\\17":Z
    .restart local v1    # "invalid\\17":Z
    :cond_214
    move/from16 v21, v1

    .line 154
    .end local v1    # "invalid\\17":Z
    .restart local v21    # "invalid\\17":Z
    :goto_216
    const/4 v1, 0x0

    .line 89
    .local v1, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$1\\19\\154\\0":I
    move/from16 v16, v1

    .end local v1    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$1\\19\\154\\0":I
    .local v16, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$1\\19\\154\\0":I
    new-instance v1, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;

    invoke-direct {v1, v2, v0, v15, v14}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda2;-><init>(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 154
    .end local v16    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$1\\19\\154\\0":I
    nop

    .line 155
    .local v1, "value\\18":Ljava/lang/Object;
    invoke-interface {v3, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 156
    move-object v6, v1

    .line 152
    .end local v1    # "value\\18":Ljava/lang/Object;
    .end local v6    # "it\\17":Ljava/lang/Object;
    .end local v7    # "$i$a$-let-ComposerKt$cache$1\\18\\152\\17":I
    :goto_223
    nop

    .line 89
    .end local v3    # "$this$cache\\17":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\17\\89":I
    .end local v21    # "invalid\\17":Z
    check-cast v6, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v1, 0x0

    invoke-static {v2, v6, v10, v1}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    .line 94
    shr-int/lit8 v1, v12, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\20":I
    move-object/from16 v39, v36

    .local v39, "modifier\\20":Landroidx/compose/ui/Modifier;
    move/from16 v40, v1

    .end local v1    # "$changed\\20":I
    .local v40, "$changed\\20":I
    move-object v1, v10

    .local v1, "$composer\\20":Landroidx/compose/runtime/Composer;
    const/16 v41, 0x0

    .line 158
    .local v41, "$i$f$Column\\20\\94":I
    const v3, 0x4ff7456f

    const-string v4, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v1, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 159
    sget-object v6, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v6}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v6

    .line 160
    .local v6, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v7, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v7}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v7

    .line 163
    .local v7, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v16, v40, 0x3

    and-int/lit8 v16, v16, 0xe

    shr-int/lit8 v21, v40, 0x3

    and-int/lit8 v21, v21, 0x70

    or-int v3, v16, v21

    invoke-static {v6, v7, v1, v3}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v3

    .line 167
    .local v3, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v16, v40, 0x3

    and-int/lit8 v16, v16, 0x70

    .line 164
    move/from16 v42, v16

    .local v42, "$changed\\21":I
    move-object/from16 v43, v39

    .local v43, "modifier\\21":Landroidx/compose/ui/Modifier;
    const/16 v44, 0x0

    .line 168
    .local v44, "$i$f$Layout\\21\\164":I
    move-object/from16 v16, v2

    .end local v2    # "owner":Landroidx/lifecycle/LifecycleOwner;
    .local v16, "owner":Landroidx/lifecycle/LifecycleOwner;
    const v2, -0x451e1427

    move-object/from16 v21, v4

    const-string v4, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 169
    const/4 v2, 0x0

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v24

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->hashCode(J)I

    move-result v45

    .line 170
    .local v45, "compositeKeyHash\\21":I
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v2

    .line 171
    .local v2, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    move-object/from16 v24, v14

    move-object/from16 v25, v15

    move-object/from16 v14, v43

    .end local v15    # "foreground$delegate":Landroidx/compose/runtime/MutableState;
    .end local v43    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v14, "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v24, "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    .local v25, "foreground$delegate":Landroidx/compose/runtime/MutableState;
    invoke-static {v1, v14}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 173
    .local v15, "materialized\\21":Landroidx/compose/ui/Modifier;
    sget-object v26, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v26 .. v26}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v26

    move-object/from16 v27, v0

    .end local v0    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .local v27, "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    shl-int/lit8 v0, v42, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 172
    move/from16 v43, v0

    .local v43, "$changed\\22":I
    move-object/from16 v0, v26

    .local v0, "factory\\22":Lkotlin/jvm/functions/Function0;
    const/16 v46, 0x0

    .line 174
    .local v46, "$i$f$ReusableComposeNode\\22\\172":I
    move-object/from16 v26, v4

    const v4, -0x20f7d59c

    move-object/from16 v28, v5

    const-string v5, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v1, v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 175
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v4

    instance-of v4, v4, Landroidx/compose/runtime/Applier;

    if-nez v4, :cond_2b2

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 176
    :cond_2b2
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 177
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v4

    if-eqz v4, :cond_2bf

    .line 178
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_2c2

    .line 180
    :cond_2bf
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 182
    :goto_2c2
    invoke-static {v1}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    const/16 v30, 0x0

    .line 183
    .local v30, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\182\\21":I
    sget-object v31, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v32, v0

    .end local v0    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v32, "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v31 .. v31}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v3, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 184
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v2, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 185
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\24":Lkotlin/jvm/functions/Function2;
    const/16 v31, 0x0

    .line 186
    .local v31, "$i$f$set-impl\\24\\185":I
    move-object/from16 v33, v4

    .local v33, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    const/16 v34, 0x0

    .line 187
    .local v34, "$i$a$-with-Updater$set$1\\25\\186\\24":I
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v35

    if-nez v35, :cond_304

    move-object/from16 v35, v1

    .end local v1    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v35, "$composer\\20":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v33 .. v33}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    move-object/from16 v47, v2

    .end local v2    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v47, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_301

    goto :goto_308

    :cond_301
    move-object/from16 v2, v33

    goto :goto_318

    .end local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v47    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v1    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v2    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_304
    move-object/from16 v35, v1

    move-object/from16 v47, v2

    .line 188
    .end local v1    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v2    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v47    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    :goto_308
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    move-object/from16 v2, v33

    .end local v33    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .local v2, "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 189
    invoke-static/range {v45 .. v45}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-interface {v4, v1, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 191
    :goto_318
    nop

    .line 186
    .end local v2    # "$this$set_impl_u24lambda_u240\\24":Landroidx/compose/runtime/Composer;
    .end local v34    # "$i$a$-with-Updater$set$1\\25\\186\\24":I
    nop

    .line 191
    nop

    .line 192
    .end local v0    # "block\\24":Lkotlin/jvm/functions/Function2;
    .end local v31    # "$i$f$set-impl\\24\\185":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v4, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 193
    nop

    .line 182
    .end local v4    # "$this$Layout_u24lambda_u240\\23":Landroidx/compose/runtime/Composer;
    .end local v30    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\23\\182\\21":I
    nop

    .line 194
    shr-int/lit8 v0, v43, 0x6

    and-int/lit8 v48, v0, 0xe

    .local v48, "$changed\\26":I
    move-object/from16 v0, v35

    .local v0, "$composer\\26":Landroidx/compose/runtime/Composer;
    const/16 v49, 0x0

    .line 165
    .local v49, "$i$a$-Layout-ColumnKt$Column$1\\26\\194\\20":I
    const v1, 0x7cc0ae6e

    const-string v2, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v2, v40, 0x6

    and-int/lit8 v2, v2, 0x70

    or-int/lit8 v50, v2, 0x6

    .local v50, "$changed\\27":I
    move-object/from16 v51, v1

    check-cast v51, Landroidx/compose/foundation/layout/ColumnScope;

    .local v51, "$this$AnkiCardContent_u24lambda_u248\\27":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v57, v0

    .local v57, "$composer\\27":Landroidx/compose/runtime/Composer;
    const/16 v58, 0x0

    .line 95
    .local v58, "$i$a$-Column-AnkiCardContentKt$AnkiCardContent$2\\27\\165\\0":I
    const v1, -0x4c1ff2b0

    const-string v2, "C111@7543L21,111@7491L280:AnkiCardContent.kt#8ao140"

    invoke-static {v10, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-static/range {v25 .. v25}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v1

    if-eqz v1, :cond_5a2

    const v1, -0x4c1fedd9

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "95@5936L272,99@6233L850,106@7123L7,107@7181L28,107@7170L39,108@7248L96,108@7226L118,109@7381L5,109@7361L70"

    invoke-static {v10, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    .line 96
    const v1, -0x658d6bf8

    invoke-static {v10, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\28":Z
    move-object v4, v10

    .local v4, "$this$cache\\28":Landroidx/compose/runtime/Composer;
    move/from16 v30, v1

    .end local v1    # "invalid\\28":Z
    .local v30, "invalid\\28":Z
    const/16 v31, 0x0

    .line 195
    .local v31, "$i$f$cache\\28\\96":I
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v1

    .local v1, "it\\28":Ljava/lang/Object;
    const/16 v33, 0x0

    .line 196
    .local v33, "$i$a$-let-ComposerKt$cache$1\\29\\195\\28":I
    sget-object v34, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v34 .. v34}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v2

    if-ne v1, v2, :cond_417

    .line 197
    const/16 v34, 0x0

    .line 97
    .local v34, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$session$1\\30\\197\\27":I
    const v2, 0xffffff

    and-int v2, v37, v2

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const v53, 0xffffff

    and-int v53, v38, v53

    move-object/from16 v54, v0

    .end local v0    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v54, "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v53 .. v53}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    filled-new-array {v2, v0}, [Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    invoke-static {v0, v2}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    move-result-object v0

    const-string v2, "<style>body{color:#%06x;background:#%06x}</style>"

    invoke-static {v2, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const-string v2, "format(...)"

    invoke-static {v0, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    .line 98
    .local v0, "theme\\30":Ljava/lang/String;
    new-instance v2, Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/RenderedCard;->getHtml()Ljava/lang/String;

    move-result-object v59

    move-object/from16 v53, v1

    .end local v1    # "it\\28":Ljava/lang/Object;
    .local v53, "it\\28":Ljava/lang/Object;
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    move-object/from16 v55, v0

    .end local v0    # "theme\\30":Ljava/lang/String;
    .local v55, "theme\\30":Ljava/lang/String;
    const-string v0, "</head>"

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v61

    const/16 v63, 0x4

    const/16 v64, 0x0

    const-string v60, "</head>"

    const/16 v62, 0x0

    invoke-static/range {v59 .. v64}, Lkotlin/text/StringsKt;->replace$default(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZILjava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    move-object v1, v6

    .end local v6    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v1, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x1b

    move-object/from16 v56, v7

    .end local v7    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .local v56, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v7, 0x0

    move-object/from16 v59, v1

    .end local v1    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v59, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v1, 0x0

    move-object/from16 v60, v2

    const/4 v2, 0x0

    move-object/from16 v61, v4

    .end local v4    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .local v61, "$this$cache\\28":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    move-object/from16 v62, v5

    const/4 v5, 0x0

    move-object/from16 v9, v21

    move-object/from16 v21, v11

    move-object/from16 v11, v60

    move-object/from16 v60, v59

    move-object/from16 v59, v35

    move-object/from16 v35, v9

    move/from16 v22, v12

    move-object/from16 v64, v32

    move-object/from16 v63, v47

    move-object/from16 v65, v54

    move-object/from16 v9, v61

    move-object/from16 v23, v62

    const/4 v12, 0x0

    move-object/from16 v62, v3

    move-object/from16 v47, v16

    move-object/from16 v61, v56

    move-object v3, v0

    move-object/from16 v16, v14

    move-object/from16 v14, v18

    move-object/from16 v0, p0

    move-object/from16 v18, v15

    move-object/from16 v15, v28

    move-object/from16 v28, v26

    .end local v3    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v11    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v12    # "$dirty":I
    .end local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v32    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v54    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v56    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .local v9, "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .local v14, "context":Landroid/content/Context;
    .local v16, "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v21, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v22, "$dirty":I
    .local v47, "owner":Landroidx/lifecycle/LifecycleOwner;
    .local v59, "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v60, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v61, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .local v62, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v63, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .local v64, "factory\\22":Lkotlin/jvm/functions/Function0;
    .local v65, "$composer\\26":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/anki/RenderedCard;->copy$default(Lcom/xunji/flashcards/anki/RenderedCard;Ljava/lang/String;Lcom/xunji/core/anki/CardSide;Ljava/lang/String;Ljava/util/Map;Ljava/util/List;ILjava/lang/Object;)Lcom/xunji/flashcards/anki/RenderedCard;

    move-result-object v1

    invoke-direct {v11, v1, v8}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;-><init>(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;)V

    .line 197
    .end local v34    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$session$1\\30\\197\\27":I
    .end local v55    # "theme\\30":Ljava/lang/String;
    move-object v1, v11

    .line 198
    .local v1, "value\\29":Ljava/lang/Object;
    invoke-interface {v9, v1}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 199
    nop

    .end local v1    # "value\\29":Ljava/lang/Object;
    goto :goto_43d

    .line 200
    .end local v9    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .end local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v22    # "$dirty":I
    .end local v53    # "it\\28":Ljava/lang/Object;
    .end local v59    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v60    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v61    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v63    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v64    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v65    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v1, "it\\28":Ljava/lang/Object;
    .restart local v3    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v4    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .restart local v6    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v7    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v11    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v12    # "$dirty":I
    .local v14, "modifier\\21":Landroidx/compose/ui/Modifier;
    .restart local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v16, "owner":Landroidx/lifecycle/LifecycleOwner;
    .local v18, "context":Landroid/content/Context;
    .restart local v32    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v47, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_417
    move-object/from16 v65, v0

    move-object/from16 v53, v1

    move-object/from16 v62, v3

    move-object v9, v4

    move-object/from16 v23, v5

    move-object/from16 v60, v6

    move-object/from16 v61, v7

    move/from16 v22, v12

    move-object/from16 v64, v32

    move-object/from16 v59, v35

    move-object/from16 v63, v47

    const/4 v12, 0x0

    move-object/from16 v47, v16

    move-object/from16 v35, v21

    move-object/from16 v21, v11

    move-object/from16 v16, v14

    move-object/from16 v14, v18

    move-object/from16 v18, v15

    move-object/from16 v15, v28

    move-object/from16 v28, v26

    .line 195
    .end local v0    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v1    # "it\\28":Ljava/lang/Object;
    .end local v3    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v4    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .end local v6    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v7    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v11    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v12    # "$dirty":I
    .end local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v32    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v33    # "$i$a$-let-ComposerKt$cache$1\\29\\195\\28":I
    .end local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .local v14, "context":Landroid/content/Context;
    .local v16, "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\21":Landroidx/compose/ui/Modifier;
    .restart local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v22    # "$dirty":I
    .local v47, "owner":Landroidx/lifecycle/LifecycleOwner;
    .restart local v59    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v60    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v61    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v62    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v63    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v64    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v65    # "$composer\\26":Landroidx/compose/runtime/Composer;
    :goto_43d
    nop

    .line 96
    .end local v9    # "$this$cache\\28":Landroidx/compose/runtime/Composer;
    .end local v30    # "invalid\\28":Z
    .end local v31    # "$i$f$cache\\28\\96":I
    move-object v0, v1

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .local v0, "session\\27":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 100
    const v1, -0x658d4496

    invoke-static {v10, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v1, 0x0

    .local v1, "invalid\\31":Z
    move-object v2, v10

    .local v2, "$this$cache\\31":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 201
    .local v3, "$i$f$cache\\31\\100":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v4

    .local v4, "it\\31":Ljava/lang/Object;
    const/4 v5, 0x0

    .line 202
    .local v5, "$i$a$-let-ComposerKt$cache$1\\32\\201\\31":I
    sget-object v6, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v6}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v6

    if-ne v4, v6, :cond_4b7

    .line 203
    const/4 v6, 0x0

    .line 100
    .local v6, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$web$1\\33\\203\\27":I
    new-instance v7, Landroid/webkit/WebView;

    invoke-direct {v7, v14}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    move-object v9, v7

    .local v9, "$this$AnkiCardContent_u24lambda_u248_u241_u240\\34":Landroid/webkit/WebView;
    const/4 v11, 0x0

    .line 101
    .local v11, "$i$a$-apply-AnkiCardContentKt$AnkiCardContent$2$web$1$1\\34\\100\\33":I
    invoke-virtual {v9}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v12

    .line 204
    .local v12, "$this$AnkiCardContent_u24lambda_u248_u241_u240_u240\\35":Landroid/webkit/WebSettings;
    const/16 v31, 0x0

    .line 101
    .local v31, "$i$a$-apply-AnkiCardContentKt$AnkiCardContent$2$web$1$1$1\\35\\101\\34":I
    move/from16 v33, v1

    const/4 v1, 0x0

    .end local v1    # "invalid\\31":Z
    .local v33, "invalid\\31":Z
    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setAllowFileAccessFromFileURLs(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    move/from16 v34, v3

    const/4 v3, 0x1

    .end local v3    # "$i$f$cache\\31\\100":I
    .local v34, "$i$f$cache\\31\\100":I
    invoke-virtual {v12, v3}, Landroid/webkit/WebSettings;->setBlockNetworkLoads(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setSupportMultipleWindows(Z)V

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setJavaScriptCanOpenWindowsAutomatically(Z)V

    invoke-virtual {v12, v3}, Landroid/webkit/WebSettings;->setMixedContentMode(I)V

    const/4 v1, 0x2

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setCacheMode(I)V

    invoke-virtual {v12, v3}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    invoke-virtual {v12, v3}, Landroid/webkit/WebSettings;->setSupportZoom(Z)V

    invoke-virtual {v12, v3}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    const/4 v1, 0x0

    invoke-virtual {v12, v1}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V

    .line 102
    .end local v12    # "$this$AnkiCardContent_u24lambda_u248_u241_u240_u240\\35":Landroid/webkit/WebSettings;
    .end local v31    # "$i$a$-apply-AnkiCardContentKt$AnkiCardContent$2$web$1$1$1\\35\\101\\34":I
    move-object v3, v0

    check-cast v3, Landroid/webkit/WebViewClient;

    invoke-virtual {v9, v3}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    .line 103
    invoke-virtual {v9, v1}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    .line 105
    const-string v1, "https://anki.xunji.invalid/card.html"

    invoke-virtual {v9, v1}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    .line 106
    nop

    .line 100
    .end local v9    # "$this$AnkiCardContent_u24lambda_u248_u241_u240\\34":Landroid/webkit/WebView;
    .end local v11    # "$i$a$-apply-AnkiCardContentKt$AnkiCardContent$2$web$1$1\\34\\100\\33":I
    nop

    .line 106
    nop

    .line 203
    .end local v6    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$web$1\\33\\203\\27":I
    nop

    .line 205
    .local v7, "value\\32":Ljava/lang/Object;
    invoke-interface {v2, v7}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 206
    move-object v4, v7

    .end local v7    # "value\\32":Ljava/lang/Object;
    goto :goto_4bb

    .line 207
    .end local v33    # "invalid\\31":Z
    .end local v34    # "$i$f$cache\\31\\100":I
    .restart local v1    # "invalid\\31":Z
    .restart local v3    # "$i$f$cache\\31\\100":I
    :cond_4b7
    move/from16 v33, v1

    move/from16 v34, v3

    .line 201
    .end local v1    # "invalid\\31":Z
    .end local v3    # "$i$f$cache\\31\\100":I
    .end local v4    # "it\\31":Ljava/lang/Object;
    .end local v5    # "$i$a$-let-ComposerKt$cache$1\\32\\201\\31":I
    .restart local v33    # "invalid\\31":Z
    .restart local v34    # "$i$f$cache\\31\\100":I
    :goto_4bb
    nop

    .line 100
    .end local v2    # "$this$cache\\31":Landroidx/compose/runtime/Composer;
    .end local v33    # "invalid\\31":Z
    .end local v34    # "$i$f$cache\\31\\100":I
    move-object v1, v4

    check-cast v1, Landroid/webkit/WebView;

    .local v1, "web\\27":Landroid/webkit/WebView;
    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 107
    invoke-static {}, Landroidx/compose/ui/platform/CompositionLocalsKt;->getLocalDensity()Landroidx/compose/runtime/ProvidableCompositionLocal;

    move-result-object v2

    check-cast v2, Landroidx/compose/runtime/CompositionLocal;

    .local v2, "this_\\36":Landroidx/compose/runtime/CompositionLocal;
    const/4 v3, 0x0

    .local v3, "$changed\\36":I
    move-object v4, v10

    .local v4, "$composer\\36":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 208
    .local v5, "$i$f$getCurrent\\36\\107":I
    const v6, 0x789c5f52

    invoke-static {v4, v6, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->consume(Landroidx/compose/runtime/CompositionLocal;)Ljava/lang/Object;

    move-result-object v6

    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .end local v2    # "this_\\36":Landroidx/compose/runtime/CompositionLocal;
    .end local v3    # "$changed\\36":I
    .end local v4    # "$composer\\36":Landroidx/compose/runtime/Composer;
    .end local v5    # "$i$f$getCurrent\\36\\107":I
    check-cast v6, Landroidx/compose/ui/unit/Density;

    .line 107
    invoke-interface {v6}, Landroidx/compose/ui/unit/Density;->getFontScale()F

    move-result v2

    const/16 v3, 0x64

    int-to-float v3, v3

    mul-float/2addr v2, v3

    float-to-int v9, v2

    .line 108
    .local v9, "zoom\\27":I
    const v2, -0x658cd14c

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v10, v9}, Landroidx/compose/runtime/Composer;->changed(I)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\37":Z
    move-object v3, v10

    .local v3, "$this$cache\\37":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 209
    .local v4, "$i$f$cache\\37\\108":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\37":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 210
    .local v6, "$i$a$-let-ComposerKt$cache$1\\38\\209\\37":I
    if-nez v2, :cond_505

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_504

    goto :goto_505

    .line 214
    :cond_504
    goto :goto_510

    .line 211
    :cond_505
    :goto_505
    const/4 v7, 0x0

    .line 108
    .local v7, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$1\\39\\211\\27":I
    new-instance v11, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;

    invoke-direct {v11, v1, v9}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda3;-><init>(Landroid/webkit/WebView;I)V

    .line 211
    .end local v7    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$1\\39\\211\\27":I
    nop

    .line 212
    .local v11, "value\\38":Ljava/lang/Object;
    invoke-interface {v3, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 213
    move-object v5, v11

    .line 209
    .end local v5    # "it\\37":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\38\\209\\37":I
    .end local v11    # "value\\38":Ljava/lang/Object;
    :goto_510
    nop

    .line 108
    .end local v2    # "invalid\\37":Z
    .end local v3    # "$this$cache\\37":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\37\\108":I
    check-cast v5, Lkotlin/jvm/functions/Function0;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v2, 0x0

    invoke-static {v5, v10, v2}, Landroidx/compose/runtime/EffectsKt;->SideEffect(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;I)V

    .line 109
    const v2, -0x658cc8a8

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v3

    or-int/2addr v2, v3

    .local v2, "invalid\\40":Z
    move-object v3, v10

    .local v3, "$this$cache\\40":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 215
    .local v4, "$i$f$cache\\40\\109":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\40":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 216
    .local v6, "$i$a$-let-ComposerKt$cache$1\\41\\215\\40":I
    if-nez v2, :cond_53c

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_53b

    goto :goto_53c

    .line 220
    :cond_53b
    goto :goto_547

    .line 217
    :cond_53c
    :goto_53c
    const/4 v7, 0x0

    .line 109
    .local v7, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$2\\42\\217\\27":I
    new-instance v11, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;

    invoke-direct {v11, v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda4;-><init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;)V

    .line 217
    .end local v7    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$2\\42\\217\\27":I
    nop

    .line 218
    .local v11, "value\\41":Ljava/lang/Object;
    invoke-interface {v3, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 219
    move-object v5, v11

    .line 215
    .end local v5    # "it\\40":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\41\\215\\40":I
    .end local v11    # "value\\41":Ljava/lang/Object;
    :goto_547
    nop

    .line 109
    .end local v2    # "invalid\\40":Z
    .end local v3    # "$this$cache\\40":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\40\\109":I
    check-cast v5, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v2, 0x0

    invoke-static {v1, v5, v10, v2}, Landroidx/compose/runtime/EffectsKt;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    .line 110
    const v2, -0x658cb863

    invoke-static {v10, v2, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v2

    .local v2, "invalid\\43":Z
    move-object v3, v10

    .local v3, "$this$cache\\43":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    .line 221
    .local v4, "$i$f$cache\\43\\110":I
    invoke-interface {v3}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    .local v5, "it\\43":Ljava/lang/Object;
    const/4 v6, 0x0

    .line 222
    .local v6, "$i$a$-let-ComposerKt$cache$1\\44\\221\\43":I
    if-nez v2, :cond_56e

    sget-object v7, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v7}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v7

    if-ne v5, v7, :cond_56d

    goto :goto_56e

    .line 226
    :cond_56d
    goto :goto_579

    .line 223
    :cond_56e
    :goto_56e
    const/4 v7, 0x0

    .line 110
    .local v7, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$3\\45\\223\\27":I
    new-instance v11, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda5;

    invoke-direct {v11, v1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda5;-><init>(Landroid/webkit/WebView;)V

    .line 223
    .end local v7    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$3\\45\\223\\27":I
    nop

    .line 224
    .local v11, "value\\44":Ljava/lang/Object;
    invoke-interface {v3, v11}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 225
    move-object v5, v11

    .line 221
    .end local v5    # "it\\43":Ljava/lang/Object;
    .end local v6    # "$i$a$-let-ComposerKt$cache$1\\44\\221\\43":I
    .end local v11    # "value\\44":Ljava/lang/Object;
    :goto_579
    nop

    .line 110
    .end local v2    # "invalid\\43":Z
    .end local v3    # "$this$cache\\43":Landroidx/compose/runtime/Composer;
    .end local v4    # "$i$f$cache\\43\\110":I
    move-object v2, v5

    check-cast v2, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 v12, 0x0

    invoke-static {v3, v12, v5, v4}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v52

    const/16 v55, 0x2

    const/16 v56, 0x0

    const/high16 v53, 0x3f800000    # 1.0f

    const/16 v54, 0x0

    invoke-static/range {v51 .. v56}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v4, 0x0

    move-object v5, v10

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v2 .. v7}, Landroidx/compose/ui/viewinterop/AndroidView_androidKt;->AndroidView(Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;II)V

    .line 95
    .end local v0    # "session\\27":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    .end local v1    # "web\\27":Landroid/webkit/WebView;
    .end local v9    # "zoom\\27":I
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    goto :goto_5e7

    .end local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v22    # "$dirty":I
    .end local v59    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v60    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v61    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v63    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v64    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v65    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\26":Landroidx/compose/runtime/Composer;
    .local v3, "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v6, "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v7, "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .local v11, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v12, "$dirty":I
    .local v14, "modifier\\21":Landroidx/compose/ui/Modifier;
    .restart local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v16, "owner":Landroidx/lifecycle/LifecycleOwner;
    .local v18, "context":Landroid/content/Context;
    .restart local v32    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .local v47, "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    :cond_5a2
    move-object/from16 v65, v0

    move-object/from16 v62, v3

    move-object/from16 v23, v5

    move-object/from16 v60, v6

    move-object/from16 v61, v7

    move-object v5, v10

    move/from16 v22, v12

    move-object/from16 v28, v26

    move-object/from16 v64, v32

    move-object/from16 v59, v35

    move-object/from16 v63, v47

    move-object/from16 v47, v16

    move-object/from16 v35, v21

    move-object/from16 v21, v11

    move-object/from16 v16, v14

    move-object/from16 v14, v18

    move-object/from16 v18, v15

    .line 111
    .end local v0    # "$composer\\26":Landroidx/compose/runtime/Composer;
    .end local v3    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v6    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v7    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v11    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v12    # "$dirty":I
    .end local v15    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v32    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .end local v35    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "context":Landroid/content/Context;
    .local v16, "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\21":Landroidx/compose/ui/Modifier;
    .restart local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v22    # "$dirty":I
    .local v47, "owner":Landroidx/lifecycle/LifecycleOwner;
    .restart local v59    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .restart local v60    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v61    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .restart local v62    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    .restart local v63    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v64    # "factory\\22":Lkotlin/jvm/functions/Function0;
    .restart local v65    # "$composer\\26":Landroidx/compose/runtime/Composer;
    const v0, -0x658caf8d

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "110@7451L27"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v52, v0

    check-cast v52, Landroidx/compose/ui/Modifier;

    const/16 v55, 0x2

    const/16 v56, 0x0

    const/high16 v53, 0x3f800000    # 1.0f

    const/16 v54, 0x0

    invoke-static/range {v51 .. v56}, Landroidx/compose/foundation/layout/ColumnScope;->weight$default(Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/ui/Modifier;FZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/4 v1, 0x0

    invoke-static {v0, v5, v1}, Landroidx/compose/foundation/layout/SpacerKt;->Spacer(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;I)V

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 112
    :goto_5e7
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0xa0

    .local v1, "$this$dp\\46":I
    const/4 v2, 0x0

    .line 227
    .local v2, "$i$f$getDp\\46\\112":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 112
    .end local v1    # "$this$dp\\46":I
    .end local v2    # "$i$f$getDp\\46\\112":I
    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v12, 0x0

    invoke-static {v0, v12, v1, v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v66

    const/4 v1, 0x0

    invoke-static {v1, v5, v1, v2}, Landroidx/compose/foundation/ScrollKt;->rememberScrollState(ILandroidx/compose/runtime/Composer;II)Landroidx/compose/foundation/ScrollState;

    move-result-object v67

    const/16 v71, 0xe

    const/16 v72, 0x0

    const/16 v68, 0x0

    const/16 v69, 0x0

    const/16 v70, 0x0

    invoke-static/range {v66 .. v72}, Landroidx/compose/foundation/ScrollKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;ZLandroidx/compose/foundation/gestures/FlingBehavior;ZILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    .local v0, "modifier\\47":Landroidx/compose/ui/Modifier;
    const/4 v1, 0x0

    .local v1, "$changed\\47":I
    move-object v2, v5

    .local v2, "$composer\\47":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 228
    .local v3, "$i$f$Column\\47\\112":I
    move-object/from16 v4, v35

    const v6, 0x4ff7456f

    invoke-static {v2, v6, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 229
    sget-object v4, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    invoke-virtual {v4}, Landroidx/compose/foundation/layout/Arrangement;->getTop()Landroidx/compose/foundation/layout/Arrangement$Vertical;

    move-result-object v4

    .line 230
    .local v4, "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 233
    .local v6, "horizontalAlignment\\47":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v7, v1, 0x3

    and-int/lit8 v7, v7, 0xe

    shr-int/lit8 v9, v1, 0x3

    and-int/lit8 v9, v9, 0x70

    or-int/2addr v7, v9

    invoke-static {v4, v6, v2, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v7

    .line 237
    .local v7, "measurePolicy\\47":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v9, v1, 0x3

    and-int/lit8 v9, v9, 0x70

    .line 234
    move-object v10, v0

    .local v9, "$changed\\48":I
    .local v10, "modifier\\48":Landroidx/compose/ui/Modifier;
    const/16 v31, 0x0

    .line 238
    .local v31, "$i$f$Layout\\48\\234":I
    move-object/from16 v11, v28

    const v12, -0x451e1427

    invoke-static {v2, v12, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 239
    const/4 v11, 0x0

    invoke-static {v2, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v32

    invoke-static/range {v32 .. v33}, Ljava/lang/Long;->hashCode(J)I

    move-result v26

    .line 240
    .local v26, "compositeKeyHash\\48":I
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 241
    .local v12, "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v2, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v15

    .line 243
    .local v15, "materialized\\48":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v11, v9, 0x6

    and-int/lit16 v11, v11, 0x380

    or-int/lit8 v11, v11, 0x6

    .line 242
    move/from16 v32, v11

    .local v32, "$changed\\49":I
    move-object/from16 v11, v17

    .local v11, "factory\\49":Lkotlin/jvm/functions/Function0;
    const/16 v33, 0x0

    .line 244
    .local v33, "$i$f$ReusableComposeNode\\49\\242":I
    move-object/from16 p2, v0

    move-object/from16 v0, v23

    move/from16 v23, v1

    const v1, -0x20f7d59c

    .end local v0    # "modifier\\47":Landroidx/compose/ui/Modifier;
    .end local v1    # "$changed\\47":I
    .local v23, "$changed\\47":I
    .local p2, "modifier\\47":Landroidx/compose/ui/Modifier;
    invoke-static {v2, v1, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 245
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_67a

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 246
    :cond_67a
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 247
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_687

    .line 248
    invoke-interface {v2, v11}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_68a

    .line 250
    :cond_687
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 252
    :goto_68a
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 253
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\50\\252\\48":I
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v29, v1

    .end local v1    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\50\\252\\48":I
    .local v29, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\50\\252\\48":I
    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v7, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 254
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v12, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 255
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\51":Lkotlin/jvm/functions/Function2;
    const/16 v17, 0x0

    .line 256
    .local v17, "$i$f$set-impl\\51\\255":I
    move-object/from16 v34, v0

    .local v34, "$this$set_impl_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 257
    .local v35, "$i$a$-with-Updater$set$1\\52\\256\\51":I
    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v52

    if-nez v52, :cond_6cb

    move-object/from16 v52, v2

    .end local v2    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .local v52, "$composer\\47":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v34 .. v34}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move/from16 v53, v3

    .end local v3    # "$i$f$Column\\47\\112":I
    .local v53, "$i$f$Column\\47\\112":I
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_6c8

    goto :goto_6cf

    :cond_6c8
    move-object/from16 v3, v34

    goto :goto_6df

    .end local v52    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$f$Column\\47\\112":I
    .restart local v2    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$i$f$Column\\47\\112":I
    :cond_6cb
    move-object/from16 v52, v2

    move/from16 v53, v3

    .line 258
    .end local v2    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .end local v3    # "$i$f$Column\\47\\112":I
    .restart local v52    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .restart local v53    # "$i$f$Column\\47\\112":I
    :goto_6cf
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v34

    .end local v34    # "$this$set_impl_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 259
    invoke-static/range {v26 .. v26}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 261
    :goto_6df
    nop

    .line 256
    .end local v3    # "$this$set_impl_u24lambda_u240\\51":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-with-Updater$set$1\\52\\256\\51":I
    nop

    .line 261
    nop

    .line 262
    .end local v1    # "block\\51":Lkotlin/jvm/functions/Function2;
    .end local v17    # "$i$f$set-impl\\51\\255":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v15, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 263
    nop

    .line 252
    .end local v0    # "$this$Layout_u24lambda_u240\\50":Landroidx/compose/runtime/Composer;
    .end local v29    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\50\\252\\48":I
    nop

    .line 264
    shr-int/lit8 v0, v32, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\53":I
    move-object/from16 v1, v52

    .local v1, "$composer\\53":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 235
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    const v3, 0x7cc0ae6e

    move/from16 v29, v0

    .end local v0    # "$changed\\53":I
    .local v29, "$changed\\53":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v23, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\54":I
    check-cast v0, Landroidx/compose/foundation/layout/ColumnScope;

    .local v0, "$this$AnkiCardContent_u24lambda_u248_u245\\54":Landroidx/compose/foundation/layout/ColumnScope;
    move-object/from16 v34, v1

    .local v34, "$composer\\54":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 112
    .local v35, "$i$a$-Column-AnkiCardContentKt$AnkiCardContent$2$4\\54\\235\\27":I
    move-object/from16 v54, v0

    .end local v0    # "$this$AnkiCardContent_u24lambda_u248_u245\\54":Landroidx/compose/foundation/layout/ColumnScope;
    .local v54, "$this$AnkiCardContent_u24lambda_u248_u245\\54":Landroidx/compose/foundation/layout/ColumnScope;
    const v0, 0x84090b

    move-object/from16 v55, v1

    .end local v1    # "$composer\\53":Landroidx/compose/runtime/Composer;
    .local v55, "$composer\\53":Landroidx/compose/runtime/Composer;
    const-string v1, "C:AnkiCardContent.kt#8ao140"

    invoke-static {v5, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const v0, 0x39d2b74d

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "*111@7634L19,111@7727L41,111@7611L157"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Lcom/xunji/flashcards/anki/RenderedCard;->getAudio()Ljava/util/List;

    move-result-object v0

    check-cast v0, Ljava/lang/Iterable;

    .local v0, "$this$forEachIndexed\\55":Ljava/lang/Iterable;
    const/4 v1, 0x0

    .line 265
    .local v1, "$i$f$forEachIndexed\\55\\112":I
    const/16 v17, 0x0

    .line 266
    .local v17, "index\\55":I
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v56

    :goto_730
    invoke-interface/range {v56 .. v56}, Ljava/util/Iterator;->hasNext()Z

    move-result v66

    if-eqz v66, :cond_83c

    invoke-interface/range {v56 .. v56}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v66

    .local v66, "item\\55":Ljava/lang/Object;
    add-int/lit8 v67, v17, 0x1

    .end local v17    # "index\\55":I
    .local v67, "index\\55":I
    if-gez v17, :cond_741

    invoke-static {}, Lkotlin/collections/CollectionsKt;->throwIndexOverflow()V

    :cond_741
    move-object/from16 v68, v14

    .end local v14    # "context":Landroid/content/Context;
    .local v68, "context":Landroid/content/Context;
    move-object/from16 v14, v66

    check-cast v14, Lcom/xunji/flashcards/anki/CardMedia;

    .local v14, "media\\56":Lcom/xunji/flashcards/anki/CardMedia;
    .local v17, "index\\56":I
    move/from16 v69, v17

    .end local v17    # "index\\56":I
    .local v69, "index\\56":I
    const/16 v70, 0x0

    .line 112
    .local v70, "$i$a$-forEachIndexed-AnkiCardContentKt$AnkiCardContent$2$4$1\\56\\266\\54":I
    move-object/from16 v17, v12

    .end local v12    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .local v17, "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v25 .. v25}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$4(Landroidx/compose/runtime/MutableState;)Z

    move-result v12

    sget-object v71, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v72, v0

    .end local v0    # "$this$forEachIndexed\\55":Ljava/lang/Iterable;
    .local v72, "$this$forEachIndexed\\55":Ljava/lang/Iterable;
    move-object/from16 v0, v71

    check-cast v0, Landroidx/compose/ui/Modifier;

    move/from16 v71, v1

    move/from16 v30, v2

    move/from16 v73, v3

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    .end local v1    # "$i$f$forEachIndexed\\55\\112":I
    .end local v2    # "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .end local v3    # "$changed\\54":I
    .local v30, "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .local v71, "$i$f$forEachIndexed\\55\\112":I
    .local v73, "$changed\\54":I
    invoke-static {v0, v1, v3, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const/16 v3, 0x30

    .local v3, "$this$dp\\57":I
    const/16 v19, 0x0

    .line 227
    .local v19, "$i$f$getDp\\57\\112":I
    int-to-float v1, v3

    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 112
    .end local v3    # "$this$dp\\57":I
    .end local v19    # "$i$f$getDp\\57\\112":I
    move-object/from16 v74, v4

    const/4 v3, 0x0

    const/4 v4, 0x2

    .end local v4    # "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v74, "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v0, v1, v3, v4, v2}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v1, 0x38db86b4

    invoke-static {v5, v1, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    move-object/from16 v1, v27

    .end local v27    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .local v1, "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    invoke-interface {v5, v1}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v19

    invoke-interface {v5, v14}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v20

    or-int v19, v19, v20

    .local v19, "invalid\\58":Z
    move-object/from16 v20, v5

    .local v20, "$this$cache\\58":Landroidx/compose/runtime/Composer;
    const/16 v27, 0x0

    .line 267
    .local v27, "$i$f$cache\\58\\112":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    .local v2, "it\\58":Ljava/lang/Object;
    const/16 v76, 0x0

    .line 268
    .local v76, "$i$a$-let-ComposerKt$cache$1\\59\\267\\58":I
    if-nez v19, :cond_7a1

    sget-object v77, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v77 .. v77}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v3

    if-ne v2, v3, :cond_79e

    goto :goto_7a1

    .line 272
    :cond_79e
    move-object/from16 v3, v20

    goto :goto_7ae

    .line 269
    :cond_7a1
    :goto_7a1
    const/4 v3, 0x0

    .line 112
    .local v3, "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$4$1$1\\60\\269\\56":I
    new-instance v4, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;

    invoke-direct {v4, v1, v14}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda6;-><init>(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)V

    .line 269
    .end local v3    # "$i$a$-cache-AnkiCardContentKt$AnkiCardContent$2$4$1$1\\60\\269\\56":I
    nop

    .line 270
    .local v4, "value\\59":Ljava/lang/Object;
    move-object/from16 v3, v20

    .end local v20    # "$this$cache\\58":Landroidx/compose/runtime/Composer;
    .local v3, "$this$cache\\58":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v4}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 271
    move-object v2, v4

    .line 267
    .end local v2    # "it\\58":Ljava/lang/Object;
    .end local v4    # "value\\59":Ljava/lang/Object;
    .end local v76    # "$i$a$-let-ComposerKt$cache$1\\59\\267\\58":I
    :goto_7ae
    nop

    .line 112
    .end local v3    # "$this$cache\\58":Landroidx/compose/runtime/Composer;
    .end local v19    # "invalid\\58":Z
    .end local v27    # "$i$f$cache\\58\\112":I
    check-cast v2, Lkotlin/jvm/functions/Function0;

    invoke-static {v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    new-instance v3, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda7;

    move/from16 v4, v69

    .end local v69    # "index\\56":I
    .local v4, "index\\56":I
    invoke-direct {v3, v4, v14}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda7;-><init>(ILcom/xunji/flashcards/anki/CardMedia;)V

    move-object/from16 v19, v0

    const/16 v0, 0x36

    move-object/from16 v27, v1

    .end local v1    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .local v27, "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    const v1, -0x4fbb3bd1

    move-object/from16 v20, v2

    const/4 v2, 0x1

    invoke-static {v1, v2, v3, v5, v0}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v0

    check-cast v0, Lkotlin/jvm/functions/Function3;

    move-object/from16 v1, v21

    .end local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v1, "scope":Lkotlinx/coroutines/CoroutineScope;
    const v21, 0x30000030

    move/from16 v3, v22

    .end local v22    # "$dirty":I
    .local v3, "$dirty":I
    const/16 v22, 0x1f8

    move-object/from16 v69, v13

    const/4 v13, 0x0

    move-object/from16 v76, v14

    .end local v14    # "media\\56":Lcom/xunji/flashcards/anki/CardMedia;
    .local v76, "media\\56":Lcom/xunji/flashcards/anki/CardMedia;
    const/4 v14, 0x0

    move-object/from16 v79, v15

    .end local v15    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .local v79, "materialized\\48":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    move-object/from16 v80, v16

    .end local v16    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v80, "modifier\\21":Landroidx/compose/ui/Modifier;
    const/16 v16, 0x0

    move-object/from16 v81, v17

    .end local v17    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .local v81, "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    const/16 v17, 0x0

    move-object/from16 v82, v18

    .end local v18    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v82, "materialized\\21":Landroidx/compose/ui/Modifier;
    const/16 v18, 0x0

    move-object/from16 v28, v19

    move-object/from16 v19, v0

    move-object/from16 v0, v68

    move/from16 v68, v3

    move-object/from16 v3, v24

    move-object/from16 v24, v10

    move-object/from16 v10, v20

    move-object/from16 v20, v5

    move-object/from16 v5, v25

    move-object/from16 v25, v11

    move-object/from16 v11, v28

    move-object/from16 v28, v69

    move-object/from16 v69, v27

    move-object/from16 v27, v28

    const/16 v28, 0x0

    const/16 v75, 0x0

    const/16 v77, 0x2

    const/16 v78, 0x0

    .end local v10    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .end local v11    # "factory\\49":Lkotlin/jvm/functions/Function0;
    .end local v27    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .local v0, "context":Landroid/content/Context;
    .local v3, "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    .local v5, "foreground$delegate":Landroidx/compose/runtime/MutableState;
    .local v20, "$composer":Landroidx/compose/runtime/Composer;
    .local v24, "modifier\\48":Landroidx/compose/ui/Modifier;
    .local v25, "factory\\49":Lkotlin/jvm/functions/Function0;
    .local v68, "$dirty":I
    .local v69, "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    invoke-static/range {v10 .. v22}, Landroidx/compose/material3/ButtonKt;->OutlinedButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    .line 266
    move-object/from16 v4, v20

    .end local v20    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v70    # "$i$a$-forEachIndexed-AnkiCardContentKt$AnkiCardContent$2$4$1\\56\\266\\54":I
    .end local v76    # "media\\56":Lcom/xunji/flashcards/anki/CardMedia;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    move-object v14, v0

    move-object/from16 v21, v1

    move-object/from16 v10, v24

    move-object/from16 v11, v25

    move-object/from16 v13, v27

    move/from16 v2, v30

    move/from16 v17, v67

    move/from16 v22, v68

    move-object/from16 v27, v69

    move/from16 v1, v71

    move-object/from16 v0, v72

    move-object/from16 v15, v79

    move-object/from16 v16, v80

    move-object/from16 v12, v81

    move-object/from16 v18, v82

    move-object/from16 v24, v3

    move-object/from16 v25, v5

    move/from16 v3, v73

    move-object v5, v4

    move-object/from16 v4, v74

    .end local v66    # "item\\55":Ljava/lang/Object;
    goto/16 :goto_730

    .line 273
    .end local v30    # "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .end local v67    # "index\\55":I
    .end local v68    # "$dirty":I
    .end local v69    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .end local v71    # "$i$f$forEachIndexed\\55\\112":I
    .end local v72    # "$this$forEachIndexed\\55":Ljava/lang/Iterable;
    .end local v73    # "$changed\\54":I
    .end local v74    # "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v79    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .end local v80    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .end local v81    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v82    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .local v0, "$this$forEachIndexed\\55":Ljava/lang/Iterable;
    .local v1, "$i$f$forEachIndexed\\55\\112":I
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .local v3, "$changed\\54":I
    .local v4, "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v5, "$composer":Landroidx/compose/runtime/Composer;
    .restart local v10    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .restart local v11    # "factory\\49":Lkotlin/jvm/functions/Function0;
    .restart local v12    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .local v14, "context":Landroid/content/Context;
    .restart local v15    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .restart local v16    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .local v17, "index\\55":I
    .restart local v18    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .restart local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .restart local v22    # "$dirty":I
    .local v24, "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    .local v25, "foreground$delegate":Landroidx/compose/runtime/MutableState;
    .restart local v27    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    :cond_83c
    move-object/from16 v72, v0

    move/from16 v71, v1

    move/from16 v30, v2

    move/from16 v73, v3

    move-object/from16 v74, v4

    move-object v4, v5

    move-object/from16 v81, v12

    move-object v0, v14

    move-object/from16 v79, v15

    move-object/from16 v80, v16

    move-object/from16 v82, v18

    move-object/from16 v1, v21

    move/from16 v68, v22

    move-object/from16 v3, v24

    move-object/from16 v5, v25

    move-object/from16 v69, v27

    const/4 v2, 0x1

    const/16 v28, 0x0

    move-object/from16 v24, v10

    move-object/from16 v25, v11

    .end local v2    # "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .end local v10    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .end local v11    # "factory\\49":Lkotlin/jvm/functions/Function0;
    .end local v12    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "context":Landroid/content/Context;
    .end local v15    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .end local v16    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .end local v17    # "index\\55":I
    .end local v18    # "materialized\\21":Landroidx/compose/ui/Modifier;
    .end local v21    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v22    # "$dirty":I
    .end local v27    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .local v0, "context":Landroid/content/Context;
    .local v1, "scope":Lkotlinx/coroutines/CoroutineScope;
    .local v3, "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    .local v5, "foreground$delegate":Landroidx/compose/runtime/MutableState;
    .local v24, "modifier\\48":Landroidx/compose/ui/Modifier;
    .local v25, "factory\\49":Lkotlin/jvm/functions/Function0;
    .restart local v30    # "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .restart local v68    # "$dirty":I
    .restart local v69    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .restart local v73    # "$changed\\54":I
    .restart local v74    # "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v79    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .restart local v80    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .restart local v81    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    .restart local v82    # "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-interface {v4}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 112
    invoke-static {v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 235
    .end local v34    # "$composer\\54":Landroidx/compose/runtime/Composer;
    .end local v35    # "$i$a$-Column-AnkiCardContentKt$AnkiCardContent$2$4\\54\\235\\27":I
    .end local v54    # "$this$AnkiCardContent_u24lambda_u248_u245\\54":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v73    # "$changed\\54":I
    invoke-static/range {v55 .. v55}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    .end local v29    # "$changed\\53":I
    .end local v30    # "$i$a$-Layout-ColumnKt$Column$1\\53\\264\\47":I
    .end local v55    # "$composer\\53":Landroidx/compose/runtime/Composer;
    nop

    .line 274
    invoke-interface/range {v52 .. v52}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 244
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 275
    nop

    .line 238
    .end local v25    # "factory\\49":Lkotlin/jvm/functions/Function0;
    .end local v32    # "$changed\\49":I
    .end local v33    # "$i$f$ReusableComposeNode\\49\\242":I
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 276
    nop

    .line 228
    .end local v9    # "$changed\\48":I
    .end local v24    # "modifier\\48":Landroidx/compose/ui/Modifier;
    .end local v26    # "compositeKeyHash\\48":I
    .end local v31    # "$i$f$Layout\\48\\234":I
    .end local v79    # "materialized\\48":Landroidx/compose/ui/Modifier;
    .end local v81    # "localMap\\48":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static/range {v52 .. v52}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 277
    nop

    .line 113
    .end local v6    # "horizontalAlignment\\47":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v7    # "measurePolicy\\47":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v23    # "$changed\\47":I
    .end local v52    # "$composer\\47":Landroidx/compose/runtime/Composer;
    .end local v53    # "$i$f$Column\\47\\112":I
    .end local v74    # "verticalArrangement\\47":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local p2    # "modifier\\47":Landroidx/compose/ui/Modifier;
    invoke-static {v3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v6

    check-cast v6, Ljava/lang/CharSequence;

    invoke-interface {v6}, Ljava/lang/CharSequence;->length()I

    move-result v6

    if-lez v6, :cond_888

    move v13, v2

    goto :goto_88a

    :cond_888
    move/from16 v13, v28

    :goto_88a
    if-eqz v13, :cond_8d4

    const v2, -0x658c824e

    invoke-interface {v4, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "112@7849L10,112@7812L58"

    invoke-static {v4, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;

    move-result-object v10

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v6}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getBodySmall()Landroidx/compose/ui/text/TextStyle;

    move-result-object v31

    const/16 v34, 0x0

    const v35, 0x1fffe

    const/4 v11, 0x0

    const-wide/16 v12, 0x0

    const/4 v14, 0x0

    const-wide/16 v15, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const-wide/16 v20, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const-wide/16 v24, 0x0

    const/16 v26, 0x0

    const/16 v27, 0x0

    const/16 v28, 0x0

    const/16 v29, 0x0

    const/16 v30, 0x0

    const/16 v33, 0x0

    move-object/from16 v32, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v32, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v10 .. v35}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v9, v32

    .end local v32    # "$composer":Landroidx/compose/runtime/Composer;
    .local v9, "$composer":Landroidx/compose/runtime/Composer;
    goto :goto_8db

    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_8d4
    move-object v9, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v9    # "$composer":Landroidx/compose/runtime/Composer;
    const v2, -0x4c7a11d6

    invoke-interface {v9, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_8db
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    .line 95
    invoke-static {v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 114
    nop

    .line 165
    .end local v50    # "$changed\\27":I
    .end local v51    # "$this$AnkiCardContent_u24lambda_u248\\27":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v57    # "$composer\\27":Landroidx/compose/runtime/Composer;
    .end local v58    # "$i$a$-Column-AnkiCardContentKt$AnkiCardContent$2\\27\\165\\0":I
    invoke-static/range {v65 .. v65}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 194
    .end local v48    # "$changed\\26":I
    .end local v49    # "$i$a$-Layout-ColumnKt$Column$1\\26\\194\\20":I
    .end local v65    # "$composer\\26":Landroidx/compose/runtime/Composer;
    nop

    .line 278
    invoke-interface/range {v59 .. v59}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 174
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 279
    nop

    .line 168
    .end local v43    # "$changed\\22":I
    .end local v46    # "$i$f$ReusableComposeNode\\22\\172":I
    .end local v64    # "factory\\22":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 280
    nop

    .line 158
    .end local v42    # "$changed\\21":I
    .end local v44    # "$i$f$Layout\\21\\164":I
    .end local v45    # "compositeKeyHash\\21":I
    .end local v63    # "localMap\\21":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v80    # "modifier\\21":Landroidx/compose/ui/Modifier;
    .end local v82    # "materialized\\21":Landroidx/compose/ui/Modifier;
    invoke-static/range {v59 .. v59}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 281
    nop

    .end local v39    # "modifier\\20":Landroidx/compose/ui/Modifier;
    .end local v40    # "$changed\\20":I
    .end local v41    # "$i$f$Column\\20\\94":I
    .end local v59    # "$composer\\20":Landroidx/compose/runtime/Composer;
    .end local v60    # "verticalArrangement\\20":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v61    # "horizontalAlignment\\20":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v62    # "measurePolicy\\20":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endMovableGroup()V

    .end local v0    # "context":Landroid/content/Context;
    .end local v1    # "scope":Lkotlinx/coroutines/CoroutineScope;
    .end local v3    # "audioStatus$delegate":Landroidx/compose/runtime/MutableState;
    .end local v5    # "foreground$delegate":Landroidx/compose/runtime/MutableState;
    .end local v47    # "owner":Landroidx/lifecycle/LifecycleOwner;
    .end local v69    # "audio":Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_901

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 116
    .end local v37    # "textColor":I
    .end local v38    # "background":I
    :cond_901
    move-object/from16 v3, v36

    goto :goto_90b

    .line 79
    .end local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v36    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v68    # "$dirty":I
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$dirty":I
    .local p2, "modifier":Landroidx/compose/ui/Modifier;
    :cond_904
    move-object v9, v10

    move/from16 v68, v12

    .end local v10    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v12    # "$dirty":I
    .restart local v9    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v68    # "$dirty":I
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v3, v4

    .line 116
    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "modifier":Landroidx/compose/ui/Modifier;
    :goto_90b
    invoke-interface {v9}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_920

    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda8;

    move-object/from16 v1, p0

    move/from16 v4, p4

    move/from16 v5, p5

    move-object v2, v8

    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda8;-><init>(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;II)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_920
    return-void
.end method

.method private static final AnkiCardContent$lambda$1(Landroidx/compose/runtime/MutableState;)Ljava/lang/String;
    .registers 5
    .param p0, "$audioStatus$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    .line 86
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 282
    .local v3, "$i$f$getValue\\1\\86":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\86":I
    check-cast v0, Ljava/lang/String;

    .line 86
    return-object v0
.end method

.method private static final AnkiCardContent$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V
    .registers 7
    .param p0, "$audioStatus$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Ljava/lang/String;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    .line 86
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    move-object v2, p1

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 283
    .local v4, "$i$f$setValue\\1\\86":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 284
    nop

    .line 86
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\86":I
    return-void
.end method

.method private static final AnkiCardContent$lambda$4(Landroidx/compose/runtime/MutableState;)Z
    .registers 5
    .param p0, "$foreground$delegate"    # Landroidx/compose/runtime/MutableState;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;)Z"
        }
    .end annotation

    .line 87
    move-object v0, p0

    check-cast v0, Landroidx/compose/runtime/State;

    .local v0, "$this$getValue\\1":Landroidx/compose/runtime/State;
    const/4 v1, 0x0

    .local v1, "this_\\1":Ljava/lang/Object;
    const/4 v2, 0x0

    .local v2, "property\\1":Lkotlin/reflect/KProperty;
    const/4 v3, 0x0

    .line 285
    .local v3, "$i$f$getValue\\1\\87":I
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    move-result-object v0

    .end local v0    # "$this$getValue\\1":Landroidx/compose/runtime/State;
    .end local v1    # "this_\\1":Ljava/lang/Object;
    .end local v2    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v3    # "$i$f$getValue\\1\\87":I
    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    .line 87
    return v0
.end method

.method private static final AnkiCardContent$lambda$5(Landroidx/compose/runtime/MutableState;Z)V
    .registers 7
    .param p0, "$foreground$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "<set-?>"    # Z
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/runtime/MutableState<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    .line 87
    const/4 v0, 0x0

    .local v0, "this_\\1":Ljava/lang/Object;
    const/4 v1, 0x0

    .local v1, "property\\1":Lkotlin/reflect/KProperty;
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    .local v2, "value\\1":Ljava/lang/Object;
    move-object v3, p0

    .local v3, "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    const/4 v4, 0x0

    .line 286
    .local v4, "$i$f$setValue\\1\\87":I
    invoke-interface {v3, v2}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 287
    nop

    .line 87
    .end local v0    # "this_\\1":Ljava/lang/Object;
    .end local v1    # "property\\1":Lkotlin/reflect/KProperty;
    .end local v2    # "value\\1":Ljava/lang/Object;
    .end local v3    # "$this$setValue\\1":Landroidx/compose/runtime/MutableState;
    .end local v4    # "$i$f$setValue\\1\\87":I
    return-void
.end method

.method private static final AnkiCardContent$lambda$6$0(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)Lkotlin/Unit;
    .registers 3
    .param p0, "$audioStatus$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p1, "it"    # Ljava/lang/String;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 88
    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiCardContent$lambda$7$0(Landroidx/lifecycle/LifecycleOwner;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .registers 9
    .param p0, "$owner"    # Landroidx/lifecycle/LifecycleOwner;
    .param p1, "$audio"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p2, "$foreground$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p3, "$audioStatus$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "$this$DisposableEffect"    # Landroidx/compose/runtime/DisposableEffectScope;

    const-string v0, "$this$DisposableEffect"

    invoke-static {p4, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;

    invoke-direct {v0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$$ExternalSyntheticLambda0;-><init>(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 91
    .local v0, "observer":Landroidx/lifecycle/LifecycleEventObserver;
    invoke-interface {p0}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/Lifecycle;

    move-result-object v1

    move-object v2, v0

    check-cast v2, Landroidx/lifecycle/LifecycleObserver;

    invoke-virtual {v1, v2}, Landroidx/lifecycle/Lifecycle;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 92
    move-object v1, p4

    .local v1, "this_\\1":Landroidx/compose/runtime/DisposableEffectScope;
    const/4 v2, 0x0

    .line 288
    .local v2, "$i$f$onDispose\\1\\92":I
    new-instance v3, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$7$0$$inlined$onDispose$1;

    invoke-direct {v3, p0, v0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$7$0$$inlined$onDispose$1;-><init>(Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/LifecycleEventObserver;Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;)V

    check-cast v3, Landroidx/compose/runtime/DisposableEffectResult;

    .line 292
    nop

    .line 92
    .end local v1    # "this_\\1":Landroidx/compose/runtime/DisposableEffectScope;
    .end local v2    # "$i$f$onDispose\\1\\92":I
    return-object v3
.end method

.method private static final AnkiCardContent$lambda$7$0$0(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroidx/lifecycle/LifecycleOwner;Landroidx/lifecycle/Lifecycle$Event;)V
    .registers 6
    .param p0, "$audio"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p1, "$foreground$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p2, "$audioStatus$delegate"    # Landroidx/compose/runtime/MutableState;
    .param p4, "event"    # Landroidx/lifecycle/Lifecycle$Event;

    const-string v0, "<unused var>"

    invoke-static {p3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string p3, "event"

    invoke-static {p4, p3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 90
    sget-object p3, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;

    if-ne p4, p3, :cond_13

    const/4 p3, 0x1

    invoke-static {p1, p3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    goto :goto_27

    :cond_13
    sget-object p3, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;

    if-eq p4, p3, :cond_1b

    sget-object p3, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;

    if-ne p4, p3, :cond_27

    :cond_1b
    const/4 p3, 0x0

    invoke-static {p1, p3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$5(Landroidx/compose/runtime/MutableState;Z)V

    invoke-virtual {p0}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->close()V

    const-string p3, ""

    invoke-static {p2, p3}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent$lambda$2(Landroidx/compose/runtime/MutableState;Ljava/lang/String;)V

    :cond_27
    :goto_27
    return-void
.end method

.method private static final AnkiCardContent$lambda$8$2$0(Landroid/webkit/WebView;I)Lkotlin/Unit;
    .registers 3
    .param p0, "$web"    # Landroid/webkit/WebView;
    .param p1, "$zoom"    # I

    .line 108
    invoke-virtual {p0}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v0

    invoke-virtual {v0, p1}, Landroid/webkit/WebSettings;->setTextZoom(I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiCardContent$lambda$8$3$0(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;Landroidx/compose/runtime/DisposableEffectScope;)Landroidx/compose/runtime/DisposableEffectResult;
    .registers 6
    .param p0, "$session"    # Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    .param p1, "$web"    # Landroid/webkit/WebView;
    .param p2, "$this$DisposableEffect"    # Landroidx/compose/runtime/DisposableEffectScope;

    const-string v0, "$this$DisposableEffect"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 109
    move-object v0, p2

    .local v0, "this_\\1":Landroidx/compose/runtime/DisposableEffectScope;
    const/4 v1, 0x0

    .line 293
    .local v1, "$i$f$onDispose\\1\\109":I
    new-instance v2, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;

    invoke-direct {v2, p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt$AnkiCardContent$lambda$8$3$0$$inlined$onDispose$1;-><init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Landroid/webkit/WebView;)V

    check-cast v2, Landroidx/compose/runtime/DisposableEffectResult;

    .line 297
    nop

    .line 109
    .end local v0    # "this_\\1":Landroidx/compose/runtime/DisposableEffectScope;
    .end local v1    # "$i$f$onDispose\\1\\109":I
    return-object v2
.end method

.method private static final AnkiCardContent$lambda$8$4$0(Landroid/webkit/WebView;Landroid/content/Context;)Landroid/webkit/WebView;
    .registers 3
    .param p0, "$web"    # Landroid/webkit/WebView;
    .param p1, "it"    # Landroid/content/Context;

    const-string v0, "it"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 110
    return-object p0
.end method

.method private static final AnkiCardContent$lambda$8$5$0$0$0(Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;Lcom/xunji/flashcards/anki/CardMedia;)Lkotlin/Unit;
    .registers 3
    .param p0, "$audio"    # Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;
    .param p1, "$media"    # Lcom/xunji/flashcards/anki/CardMedia;

    .line 112
    invoke-virtual {p0, p1}, Lcom/xunji/flashcards/ui/components/AnkiAudioPlayer;->play(Lcom/xunji/flashcards/anki/CardMedia;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiCardContent$lambda$8$5$0$1(ILcom/xunji/flashcards/anki/CardMedia;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 31
    .param p0, "$index"    # I
    .param p1, "$media"    # Lcom/xunji/flashcards/anki/CardMedia;
    .param p2, "$this$OutlinedButton"    # Landroidx/compose/foundation/layout/RowScope;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p3

    move/from16 v1, p4

    const-string v2, "$this$OutlinedButton"

    move-object/from16 v3, p2

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C111@7728L39:AnkiCardContent.kt#8ao140"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    if-eq v2, v4, :cond_18

    const/4 v2, 0x1

    goto :goto_19

    :cond_18
    const/4 v2, 0x0

    :goto_19
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_85

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.components.AnkiCardContent.<anonymous>.<anonymous>.<anonymous>.<anonymous>.<anonymous> (AnkiCardContent.kt:111)"

    const v5, -0x4fbb3bd1

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 112
    :cond_30
    add-int/lit8 v2, p0, 0x1

    invoke-virtual/range {p1 .. p1}, Lcom/xunji/flashcards/anki/CardMedia;->getName()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "\u64ad\u653e\u97f3\u9891 "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v5, " \u00b7 "

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/16 v24, 0x0

    const v25, 0x3fffe

    const/4 v1, 0x0

    move-object v0, v2

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v21, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, p3

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_88

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_88

    :cond_85
    invoke-interface/range {p3 .. p3}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_88
    :goto_88
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final AnkiCardContent$lambda$9(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lcom/xunji/flashcards/ui/components/AnkiCardContentKt;->AnkiCardContent(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

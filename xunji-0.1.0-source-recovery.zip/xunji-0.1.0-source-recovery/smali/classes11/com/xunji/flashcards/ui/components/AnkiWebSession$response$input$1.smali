.class final Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "AnkiCardContent.kt"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$app_debug(Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x18
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lkotlin/coroutines/jvm/internal/SuspendLambda;",
        "Lkotlin/jvm/functions/Function2<",
        "Lkotlinx/coroutines/CoroutineScope;",
        "Lkotlin/coroutines/Continuation<",
        "-",
        "Ljava/io/InputStream;",
        ">;",
        "Ljava/lang/Object;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\n\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u0004\u0018\u00010\u0001*\u00020\u0002H\n"
    }
    d2 = {
        "<anonymous>",
        "Ljava/io/InputStream;",
        "Lkotlinx/coroutines/CoroutineScope;"
    }
    k = 0x3
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/coroutines/jvm/internal/DebugMetadata;
    c = "com.xunji.flashcards.ui.components.AnkiWebSession$response$input$1"
    f = "AnkiCardContent.kt"
    i = {}
    l = {
        0x26
    }
    m = "invokeSuspend"
    n = {}
    s = {}
    v = 0x1
.end annotation


# instance fields
.field final synthetic $media:Lcom/xunji/flashcards/anki/CardMedia;

.field label:I

.field final synthetic this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;


# direct methods
.method constructor <init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/ui/components/AnkiWebSession;",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;",
            ">;)V"
        }
    .end annotation

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    const/4 v0, 0x2

    invoke-direct {p0, v0, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/Object;",
            "Lkotlin/coroutines/Continuation<",
            "*>;)",
            "Lkotlin/coroutines/Continuation<",
            "Lkotlin/Unit;",
            ">;"
        }
    .end annotation

    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    invoke-direct {v0, v1, v2, p2}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;-><init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/coroutines/Continuation;

    return-object v0
.end method

.method public bridge synthetic invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    check-cast p2, Lkotlin/coroutines/Continuation;

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invoke(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lkotlinx/coroutines/CoroutineScope;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    move-result-object v0

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;

    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-virtual {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6
    .param p1, "$result"    # Ljava/lang/Object;

    invoke-static {}, Lkotlin/coroutines/intrinsics/IntrinsicsKt;->getCOROUTINE_SUSPENDED()Ljava/lang/Object;

    move-result-object v0

    .line 38
    iget v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->label:I

    packed-switch v1, :pswitch_data_3a

    new-instance v0, Ljava/lang/IllegalStateException;

    const-string v1, "call to \'resume\' before \'invoke\' with coroutine"

    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_11
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    move-object v1, p1

    goto :goto_2d

    :pswitch_16
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    # getter for: Lcom/xunji/flashcards/ui/components/AnkiWebSession;->open:Lkotlin/jvm/functions/Function2;
    invoke-static {v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->access$getOpen$p(Lcom/xunji/flashcards/ui/components/AnkiWebSession;)Lkotlin/jvm/functions/Function2;

    move-result-object v1

    iget-object v2, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->$media:Lcom/xunji/flashcards/anki/CardMedia;

    if-eqz v2, :cond_2e

    const/4 v3, 0x1

    iput v3, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;->label:I

    invoke-interface {v1, v2, p0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    if-ne v1, v0, :cond_2d

    return-object v0

    :cond_2d
    :goto_2d
    return-object v1

    :cond_2e
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "Required value was null."

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_16
        :pswitch_11
    .end packed-switch
.end method

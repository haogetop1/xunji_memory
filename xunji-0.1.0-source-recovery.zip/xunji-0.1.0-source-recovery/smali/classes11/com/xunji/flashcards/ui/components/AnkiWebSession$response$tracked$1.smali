.class public final Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;
.super Ljava/io/FilterInputStream;
.source "AnkiCardContent.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$app_debug(Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiCardContent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,117:1\n1#2:118\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0011\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0008\u0010\u0002\u001a\u00020\u0003H\u0016\u00a8\u0006\u0004"
    }
    d2 = {
        "com/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1",
        "Ljava/io/FilterInputStream;",
        "close",
        "",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;


# direct methods
.method constructor <init>(Ljava/io/InputStream;Lcom/xunji/flashcards/ui/components/AnkiWebSession;)V
    .registers 3
    .param p1, "$input"    # Ljava/io/InputStream;
    .param p2, "$receiver"    # Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .line 39
    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    return-void
.end method


# virtual methods
.method public close()V
    .registers 4

    .line 40
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;->this$0:Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    monitor-enter v0

    .line 118
    const/4 v2, 0x0

    .line 40
    .local v2, "$i$a$-synchronized-AnkiWebSession$response$tracked$1$close$1\\1\\40\\0":I
    :try_start_6
    # getter for: Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;
    invoke-static {v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->access$getStreams$p(Lcom/xunji/flashcards/ui/components/AnkiWebSession;)Ljava/util/Set;

    move-result-object v1

    invoke-interface {v1, p0}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z
    :try_end_d
    .catchall {:try_start_6 .. :try_end_d} :catchall_12

    .end local v2    # "$i$a$-synchronized-AnkiWebSession$response$tracked$1$close$1\\1\\40\\0":I
    monitor-exit v0

    invoke-super {p0}, Ljava/io/FilterInputStream;->close()V

    return-void

    :catchall_12
    move-exception v1

    monitor-exit v0

    throw v1
.end method

.class public final Lcom/xunji/flashcards/ui/components/AnkiWebSession;
.super Landroid/webkit/WebViewClient;
.source "AnkiCardContent.kt"

# interfaces
.implements Ljava/io/Closeable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/xunji/flashcards/ui/components/AnkiWebSession$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nAnkiCardContent.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiWebSession\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,117:1\n1#2:118\n1869#3,2:119\n*S KotlinDebug\n*F\n+ 1 AnkiCardContent.kt\ncom/xunji/flashcards/ui/components/AnkiWebSession\n*L\n45#1:119,2\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\\\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010#\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004\n\u0002\u0010\u0002\n\u0002\u0008\u0002\u0008\u0001\u0018\u0000  2\u00020\u00012\u00020\u0002:\u0001 B5\u0012\u0006\u0010\u0003\u001a\u00020\u0004\u0012$\u0010\u0005\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0007\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0008\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0006\u00a2\u0006\u0004\u0008\u000b\u0010\u000cJ\u001c\u0010\u0012\u001a\u00020\u000f2\u0008\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0008\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u001c\u0010\u0012\u001a\u00020\u000f2\u0008\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0008\u0010\u0017\u001a\u0004\u0018\u00010\u0018H\u0017J\u001c\u0010\u0019\u001a\u00020\u001a2\u0008\u0010\u0013\u001a\u0004\u0018\u00010\u00142\u0008\u0010\u0015\u001a\u0004\u0018\u00010\u0016H\u0016J\u001f\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0017\u001a\u00020\u00182\u0008\u0008\u0002\u0010\u001c\u001a\u00020\u0018H\u0000\u00a2\u0006\u0002\u0008\u001dJ\u0008\u0010\u001e\u001a\u00020\u001fH\u0016R\u000e\u0010\u0003\u001a\u00020\u0004X\u0082\u0004\u00a2\u0006\u0002\n\u0000R.\u0010\u0005\u001a \u0008\u0001\u0012\u0004\u0012\u00020\u0007\u0012\u000c\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\t0\u0008\u0012\u0006\u0012\u0004\u0018\u00010\n0\u0006X\u0082\u0004\u00a2\u0006\u0004\n\u0002\u0010\rR\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u000e\u00a2\u0006\u0002\n\u0000R\u0014\u0010\u0010\u001a\u0008\u0012\u0004\u0012\u00020\t0\u0011X\u0082\u0004\u00a2\u0006\u0002\n\u0000\u00a8\u0006!"
    }
    d2 = {
        "Lcom/xunji/flashcards/ui/components/AnkiWebSession;",
        "Landroid/webkit/WebViewClient;",
        "Ljava/io/Closeable;",
        "card",
        "Lcom/xunji/flashcards/anki/RenderedCard;",
        "open",
        "Lkotlin/Function2;",
        "Lcom/xunji/flashcards/anki/CardMedia;",
        "Lkotlin/coroutines/Continuation;",
        "Ljava/io/InputStream;",
        "",
        "<init>",
        "(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;)V",
        "Lkotlin/jvm/functions/Function2;",
        "closed",
        "",
        "streams",
        "",
        "shouldOverrideUrlLoading",
        "view",
        "Landroid/webkit/WebView;",
        "request",
        "Landroid/webkit/WebResourceRequest;",
        "url",
        "",
        "shouldInterceptRequest",
        "Landroid/webkit/WebResourceResponse;",
        "response",
        "method",
        "response$app_debug",
        "close",
        "",
        "Companion",
        "app_debug"
    }
    k = 0x1
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# static fields
.field public static final $stable:I

.field public static final Companion:Lcom/xunji/flashcards/ui/components/AnkiWebSession$Companion;

.field public static final DOCUMENT_URL:Ljava/lang/String; = "https://anki.xunji.invalid/card.html"


# instance fields
.field private final card:Lcom/xunji/flashcards/anki/RenderedCard;

.field private closed:Z

.field private final open:Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Lkotlin/jvm/functions/Function2<",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field

.field private final streams:Ljava/util/Set;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Set<",
            "Ljava/io/InputStream;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->Companion:Lcom/xunji/flashcards/ui/components/AnkiWebSession$Companion;

    const/16 v0, 0x8

    sput v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->$stable:I

    return-void
.end method

.method public constructor <init>(Lcom/xunji/flashcards/anki/RenderedCard;Lkotlin/jvm/functions/Function2;)V
    .registers 4
    .param p1, "card"    # Lcom/xunji/flashcards/anki/RenderedCard;
    .param p2, "open"    # Lkotlin/jvm/functions/Function2;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/xunji/flashcards/anki/RenderedCard;",
            "Lkotlin/jvm/functions/Function2<",
            "-",
            "Lcom/xunji/flashcards/anki/CardMedia;",
            "-",
            "Lkotlin/coroutines/Continuation<",
            "-",
            "Ljava/io/InputStream;",
            ">;+",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const-string v0, "card"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "open"

    invoke-static {p2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 24
    invoke-direct {p0}, Landroid/webkit/WebViewClient;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->card:Lcom/xunji/flashcards/anki/RenderedCard;

    iput-object p2, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->open:Lkotlin/jvm/functions/Function2;

    .line 27
    new-instance v0, Ljava/util/LinkedHashSet;

    invoke-direct {v0}, Ljava/util/LinkedHashSet;-><init>()V

    check-cast v0, Ljava/util/Set;

    iput-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;

    .line 24
    return-void
.end method

.method public static final synthetic access$getOpen$p(Lcom/xunji/flashcards/ui/components/AnkiWebSession;)Lkotlin/jvm/functions/Function2;
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .line 24
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->open:Lkotlin/jvm/functions/Function2;

    return-object v0
.end method

.method public static final synthetic access$getStreams$p(Lcom/xunji/flashcards/ui/components/AnkiWebSession;)Ljava/util/Set;
    .registers 2
    .param p0, "$this"    # Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .line 24
    iget-object v0, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;

    return-object v0
.end method

.method public static synthetic response$app_debug$default(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Object;)Landroid/webkit/WebResourceResponse;
    .registers 5

    .line 32
    and-int/lit8 p3, p3, 0x2

    if-eqz p3, :cond_6

    const-string p2, "GET"

    :cond_6
    invoke-virtual {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$app_debug(Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;

    move-result-object p0

    return-object p0
.end method

.method private static final response$denied()Landroid/webkit/WebResourceResponse;
    .registers 7

    .line 33
    new-instance v0, Landroid/webkit/WebResourceResponse;

    invoke-static {}, Lkotlin/collections/MapsKt;->emptyMap()Ljava/util/Map;

    move-result-object v5

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v2, 0x0

    new-array v2, v2, [B

    invoke-direct {v1, v2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    move-object v6, v1

    check-cast v6, Ljava/io/InputStream;

    const-string v1, "text/plain"

    const-string v2, "UTF-8"

    const/16 v3, 0x193

    const-string v4, "Forbidden"

    invoke-direct/range {v0 .. v6}, Landroid/webkit/WebResourceResponse;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/Map;Ljava/io/InputStream;)V

    return-object v0
.end method


# virtual methods
.method public close()V
    .registers 10

    .line 45
    monitor-enter p0

    .line 118
    const/4 v0, 0x0

    .line 45
    .local v0, "$i$a$-synchronized-AnkiWebSession$close$1\\1\\45\\0":I
    const/4 v1, 0x1

    :try_start_3
    iput-boolean v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->closed:Z

    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;

    check-cast v1, Ljava/lang/Iterable;

    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->toList(Ljava/lang/Iterable;)Ljava/util/List;

    move-result-object v1

    check-cast v1, Ljava/lang/Iterable;

    .local v1, "$this$forEach\\2":Ljava/lang/Iterable;
    const/4 v2, 0x0

    .line 119
    .local v2, "$i$f$forEach\\2\\45":I
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    move-result-object v3

    :goto_14
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    if-eqz v4, :cond_3d

    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    .local v4, "element\\2":Ljava/lang/Object;
    move-object v5, v4

    check-cast v5, Ljava/io/InputStream;
    :try_end_21
    .catchall {:try_start_3 .. :try_end_21} :catchall_47

    .local v5, "it\\3":Ljava/io/InputStream;
    const/4 v6, 0x0

    .line 45
    .local v6, "$i$a$-forEach-AnkiWebSession$close$1$1\\3\\119\\1":I
    :try_start_22
    sget-object v7, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v7, p0

    check-cast v7, Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .line 118
    .local v7, "$this$close_u24lambda_u240_u240_u240\\4":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    const/4 v8, 0x0

    .line 45
    .local v8, "$i$a$-runCatching-AnkiWebSession$close$1$1$1\\4\\45\\3":I
    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    .end local v7    # "$this$close_u24lambda_u240_u240_u240\\4":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    .end local v8    # "$i$a$-runCatching-AnkiWebSession$close$1$1$1\\4\\45\\3":I
    sget-object v7, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v7}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_30
    .catchall {:try_start_22 .. :try_end_30} :catchall_31

    goto :goto_3b

    :catchall_31
    move-exception v7

    :try_start_32
    sget-object v8, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v7}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v7

    invoke-static {v7}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    .end local v5    # "it\\3":Ljava/io/InputStream;
    .end local v6    # "$i$a$-forEach-AnkiWebSession$close$1$1\\3\\119\\1":I
    :goto_3b
    nop

    .end local v4    # "element\\2":Ljava/lang/Object;
    goto :goto_14

    .line 120
    :cond_3d
    nop

    .line 45
    .end local v1    # "$this$forEach\\2":Ljava/lang/Iterable;
    .end local v2    # "$i$f$forEach\\2\\45":I
    iget-object v1, p0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;

    invoke-interface {v1}, Ljava/util/Set;->clear()V

    .end local v0    # "$i$a$-synchronized-AnkiWebSession$close$1\\1\\45\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_45
    .catchall {:try_start_32 .. :try_end_45} :catchall_47

    monitor-exit p0

    return-void

    :catchall_47
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public final response$app_debug(Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;
    .registers 20
    .param p1, "url"    # Ljava/lang/String;
    .param p2, "method"    # Ljava/lang/String;

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    const-string v0, "url"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "method"

    invoke-static {v3, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 34
    monitor-enter p0

    .line 118
    const/4 v0, 0x0

    .line 34
    .local v0, "$i$a$-synchronized-AnkiWebSession$response$media$1\\1\\34\\0":I
    :try_start_12
    iget-boolean v4, v1, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->closed:Z

    if-nez v4, :cond_f1

    const-string v4, "GET"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v4

    if-nez v4, :cond_20

    goto/16 :goto_f1

    :cond_20
    iget-object v4, v1, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->card:Lcom/xunji/flashcards/anki/RenderedCard;

    invoke-virtual {v4}, Lcom/xunji/flashcards/anki/RenderedCard;->getMedia()Ljava/util/Map;

    move-result-object v4

    invoke-interface {v4, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Lcom/xunji/flashcards/anki/CardMedia;
    :try_end_2c
    .catchall {:try_start_12 .. :try_end_2c} :catchall_f7

    .end local v0    # "$i$a$-synchronized-AnkiWebSession$response$media$1\\1\\34\\0":I
    monitor-exit p0

    .line 35
    .local v4, "media":Lcom/xunji/flashcards/anki/CardMedia;
    const-string v0, "https://anki.xunji.invalid/card.html"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    .line 36
    .local v5, "document":Z
    if-nez v5, :cond_3c

    if-nez v4, :cond_3c

    invoke-static {}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$denied()Landroid/webkit/WebResourceResponse;

    move-result-object v0

    return-object v0

    .line 37
    :cond_3c
    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eqz v5, :cond_59

    new-instance v0, Ljava/io/ByteArrayInputStream;

    iget-object v8, v1, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->card:Lcom/xunji/flashcards/anki/RenderedCard;

    invoke-virtual {v8}, Lcom/xunji/flashcards/anki/RenderedCard;->getHtml()Ljava/lang/String;

    move-result-object v8

    sget-object v9, Lkotlin/text/Charsets;->UTF_8:Ljava/nio/charset/Charset;

    invoke-virtual {v8, v9}, Ljava/lang/String;->getBytes(Ljava/nio/charset/Charset;)[B

    move-result-object v8

    const-string v9, "getBytes(...)"

    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    invoke-direct {v0, v8}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    check-cast v0, Ljava/io/InputStream;

    goto :goto_70

    .line 38
    :cond_59
    :try_start_59
    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;

    invoke-direct {v0, v1, v4, v7}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$input$1;-><init>(Lcom/xunji/flashcards/ui/components/AnkiWebSession;Lcom/xunji/flashcards/anki/CardMedia;Lkotlin/coroutines/Continuation;)V

    check-cast v0, Lkotlin/jvm/functions/Function2;

    invoke-static {v7, v0, v6, v7}, Lkotlinx/coroutines/BuildersKt;->runBlocking$default(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Ljava/io/InputStream;
    :try_end_66
    .catch Ljava/lang/Exception; {:try_start_59 .. :try_end_66} :catch_67

    goto :goto_69

    :catch_67
    move-exception v0

    move-object v0, v7

    :goto_69
    if-nez v0, :cond_70

    invoke-static {}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$denied()Landroid/webkit/WebResourceResponse;

    move-result-object v0

    return-object v0

    .line 37
    :cond_70
    :goto_70
    move-object v8, v0

    .line 39
    .local v8, "input":Ljava/io/InputStream;
    new-instance v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;

    invoke-direct {v0, v8, v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;-><init>(Ljava/io/InputStream;Lcom/xunji/flashcards/ui/components/AnkiWebSession;)V

    move-object v9, v0

    .line 42
    .local v9, "tracked":Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;
    monitor-enter p0

    .line 118
    const/4 v10, 0x0

    .line 42
    .local v10, "$i$a$-synchronized-AnkiWebSession$response$1\\2\\42\\0":I
    :try_start_79
    iget-boolean v0, v1, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->closed:Z
    :try_end_7b
    .catchall {:try_start_79 .. :try_end_7b} :catchall_ee

    if-eqz v0, :cond_9c

    :try_start_7d
    sget-object v0, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    move-object v0, v1

    check-cast v0, Lcom/xunji/flashcards/ui/components/AnkiWebSession;

    .line 118
    .local v0, "$this$response_u24lambda_u241_u240\\3":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    const/4 v6, 0x0

    .line 42
    .local v6, "$i$a$-runCatching-AnkiWebSession$response$1$1\\3\\42\\2":I
    invoke-virtual {v8}, Ljava/io/InputStream;->close()V

    .end local v0    # "$this$response_u24lambda_u241_u240\\3":Lcom/xunji/flashcards/ui/components/AnkiWebSession;
    .end local v6    # "$i$a$-runCatching-AnkiWebSession$response$1$1\\3\\42\\2":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_8b
    .catchall {:try_start_7d .. :try_end_8b} :catchall_8c

    goto :goto_96

    :catchall_8c
    move-exception v0

    :try_start_8d
    sget-object v6, Lkotlin/Result;->Companion:Lkotlin/Result$Companion;

    invoke-static {v0}, Lkotlin/ResultKt;->createFailure(Ljava/lang/Throwable;)Ljava/lang/Object;

    move-result-object v0

    invoke-static {v0}, Lkotlin/Result;->constructor-impl(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_96
    invoke-static {}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$denied()Landroid/webkit/WebResourceResponse;

    move-result-object v0
    :try_end_9a
    .catchall {:try_start_8d .. :try_end_9a} :catchall_ee

    .end local v10    # "$i$a$-synchronized-AnkiWebSession$response$1\\2\\42\\0":I
    monitor-exit p0

    return-object v0

    .restart local v10    # "$i$a$-synchronized-AnkiWebSession$response$1\\2\\42\\0":I
    :cond_9c
    :try_start_9c
    iget-object v0, v1, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->streams:Ljava/util/Set;

    check-cast v0, Ljava/util/Collection;

    invoke-interface {v0, v9}, Ljava/util/Collection;->add(Ljava/lang/Object;)Z

    .end local v10    # "$i$a$-synchronized-AnkiWebSession$response$1\\2\\42\\0":I
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;
    :try_end_a5
    .catchall {:try_start_9c .. :try_end_a5} :catchall_ee

    monitor-exit p0

    .line 43
    new-instance v10, Landroid/webkit/WebResourceResponse;

    if-eqz v5, :cond_ae

    const-string v0, "text/html"

    :goto_ac
    move-object v11, v0

    goto :goto_b5

    :cond_ae
    if-eqz v4, :cond_e2

    invoke-virtual {v4}, Lcom/xunji/flashcards/anki/CardMedia;->getMime()Ljava/lang/String;

    move-result-object v0

    goto :goto_ac

    :goto_b5
    if-eqz v5, :cond_b9

    const-string v7, "UTF-8"

    :cond_b9
    move-object v12, v7

    const-string v14, "OK"

    const/4 v0, 0x2

    new-array v0, v0, [Lkotlin/Pair;

    const-string v7, "Cache-Control"

    const-string v13, "no-store"

    invoke-static {v7, v13}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v7

    const/4 v13, 0x0

    aput-object v7, v0, v13

    const-string v7, "X-Content-Type-Options"

    const-string v13, "nosniff"

    invoke-static {v7, v13}, Lkotlin/TuplesKt;->to(Ljava/lang/Object;Ljava/lang/Object;)Lkotlin/Pair;

    move-result-object v7

    aput-object v7, v0, v6

    invoke-static {v0}, Lkotlin/collections/MapsKt;->mapOf([Lkotlin/Pair;)Ljava/util/Map;

    move-result-object v15

    move-object/from16 v16, v9

    check-cast v16, Ljava/io/InputStream;

    const/16 v13, 0xc8

    invoke-direct/range {v10 .. v16}, Landroid/webkit/WebResourceResponse;-><init>(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/util/Map;Ljava/io/InputStream;)V

    return-object v10

    :cond_e2
    const-string v0, "Required value was null."

    new-instance v6, Ljava/lang/IllegalArgumentException;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v6, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v6

    .line 42
    :catchall_ee
    move-exception v0

    monitor-exit p0

    throw v0

    .line 34
    .end local v4    # "media":Lcom/xunji/flashcards/anki/CardMedia;
    .end local v5    # "document":Z
    .end local v8    # "input":Ljava/io/InputStream;
    .end local v9    # "tracked":Lcom/xunji/flashcards/ui/components/AnkiWebSession$response$tracked$1;
    .local v0, "$i$a$-synchronized-AnkiWebSession$response$media$1\\1\\34\\0":I
    :cond_f1
    :goto_f1
    :try_start_f1
    invoke-static {}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$denied()Landroid/webkit/WebResourceResponse;

    move-result-object v4
    :try_end_f5
    .catchall {:try_start_f1 .. :try_end_f5} :catchall_f7

    .end local v0    # "$i$a$-synchronized-AnkiWebSession$response$media$1\\1\\34\\0":I
    monitor-exit p0

    return-object v4

    :catchall_f7
    move-exception v0

    monitor-exit p0

    throw v0
.end method

.method public shouldInterceptRequest(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Landroid/webkit/WebResourceResponse;
    .registers 5
    .param p1, "view"    # Landroid/webkit/WebView;
    .param p2, "request"    # Landroid/webkit/WebResourceRequest;

    .line 31
    if-eqz p2, :cond_7

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getUrl()Landroid/net/Uri;

    move-result-object v0

    goto :goto_8

    :cond_7
    const/4 v0, 0x0

    :goto_8
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    if-eqz p2, :cond_14

    invoke-interface {p2}, Landroid/webkit/WebResourceRequest;->getMethod()Ljava/lang/String;

    move-result-object v1

    if-nez v1, :cond_16

    :cond_14
    const-string v1, ""

    :cond_16
    invoke-virtual {p0, v0, v1}, Lcom/xunji/flashcards/ui/components/AnkiWebSession;->response$app_debug(Ljava/lang/String;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;

    move-result-object v0

    return-object v0
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Landroid/webkit/WebResourceRequest;)Z
    .registers 4
    .param p1, "view"    # Landroid/webkit/WebView;
    .param p2, "request"    # Landroid/webkit/WebResourceRequest;

    .line 28
    const/4 v0, 0x1

    return v0
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .registers 4
    .param p1, "view"    # Landroid/webkit/WebView;
    .param p2, "url"    # Ljava/lang/String;
    .annotation runtime Lkotlin/Deprecated;
        message = "Required for older WebView implementations"
    .end annotation

    .line 30
    const/4 v0, 0x1

    return v0
.end method

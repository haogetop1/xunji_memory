.class public final synthetic Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda18;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>()V
    .registers 1

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    invoke-static {}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->$r8$lambda$Ybl1n4zcFZc9KuP9PLokn-_Uh3s()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

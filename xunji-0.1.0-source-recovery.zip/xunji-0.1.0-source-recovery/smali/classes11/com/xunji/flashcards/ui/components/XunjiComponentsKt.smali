.class public final Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;
.super Ljava/lang/Object;
.source "XunjiComponents.kt"


# annotations
.annotation system Ldalvik/annotation/SourceDebugExtension;
    value = "SMAP\nXunjiComponents.kt\nKotlin\n*S Kotlin\n*F\n+ 1 XunjiComponents.kt\ncom/xunji/flashcards/ui/components/XunjiComponentsKt\n+ 2 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 3 Composer.kt\nandroidx/compose/runtime/ComposerKt\n+ 4 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 5 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 6 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 7 Composer.kt\nandroidx/compose/runtime/Updater\n+ 8 Column.kt\nandroidx/compose/foundation/layout/ColumnKt\n+ 9 Size.kt\nandroidx/compose/ui/geometry/Size\n+ 10 InlineClassHelper.kt\nandroidx/compose/ui/util/InlineClassHelperKt\n+ 11 InlineClassHelper.jvm.kt\nandroidx/compose/ui/util/InlineClassHelper_jvmKt\n+ 12 Offset.kt\nandroidx/compose/ui/geometry/OffsetKt\n+ 13 Size.kt\nandroidx/compose/ui/geometry/SizeKt\n+ 14 CornerRadius.kt\nandroidx/compose/ui/geometry/CornerRadiusKt\n+ 15 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,71:1\n113#2:72\n113#2:79\n113#2:86\n113#2:127\n113#2:128\n113#2:177\n113#2:182\n113#2:225\n118#2:271\n113#2:283\n113#2:324\n1282#3,6:73\n1282#3,6:80\n1282#3,6:129\n1282#3,6:135\n70#4:87\n68#4,8:88\n77#4:126\n70#4:141\n68#4,8:142\n77#4:181\n70#4:325\n68#4,8:326\n77#4:364\n80#5,6:96\n87#5,3:111\n90#5,2:120\n94#5:125\n80#5,6:150\n87#5,3:165\n90#5,2:174\n94#5:180\n80#5,6:194\n87#5,3:209\n90#5,2:218\n94#5:223\n80#5,6:235\n87#5,3:250\n90#5,2:259\n94#5:264\n80#5,6:293\n87#5,3:308\n90#5,2:317\n94#5:322\n80#5,6:334\n87#5,3:349\n90#5,2:358\n94#5:363\n391#6,9:102\n400#6,3:122\n391#6,9:156\n400#6:176\n401#6,2:178\n391#6,9:200\n400#6,3:220\n391#6,9:241\n400#6,3:261\n391#6,9:299\n400#6,3:319\n391#6,9:340\n400#6,3:360\n4360#7,6:114\n4360#7,6:168\n4360#7,6:212\n4360#7,6:253\n4360#7,6:311\n4360#7,6:352\n87#8:183\n83#8,10:184\n94#8:224\n87#8:226\n85#8,8:227\n94#8:265\n87#8:284\n85#8,8:285\n94#8:323\n57#9:266\n61#9:269\n60#10:267\n70#10:270\n53#10,3:273\n53#10,3:280\n22#11:268\n30#12:272\n30#12:279\n33#13:276\n33#14:277\n1#15:278\n*S KotlinDebug\n*F\n+ 1 XunjiComponents.kt\ncom/xunji/flashcards/ui/components/XunjiComponentsKt\n*L\n21#1:72\n40#1:79\n43#1:86\n47#1:127\n50#1:128\n62#1:177\n63#1:182\n64#1:225\n22#1:271\n47#1:283\n57#1:324\n21#1:73,6\n40#1:80,6\n53#1:129,6\n55#1:135,6\n43#1:87\n43#1:88,8\n43#1:126\n62#1:141\n62#1:142,8\n62#1:181\n57#1:325\n57#1:326,8\n57#1:364\n43#1:96,6\n43#1:111,3\n43#1:120,2\n43#1:125\n62#1:150,6\n62#1:165,3\n62#1:174,2\n62#1:180\n63#1:194,6\n63#1:209,3\n63#1:218,2\n63#1:223\n64#1:235,6\n64#1:250,3\n64#1:259,2\n64#1:264\n47#1:293,6\n47#1:308,3\n47#1:317,2\n47#1:322\n57#1:334,6\n57#1:349,3\n57#1:358,2\n57#1:363\n43#1:102,9\n43#1:122,3\n62#1:156,9\n62#1:176\n62#1:178,2\n63#1:200,9\n63#1:220,3\n64#1:241,9\n64#1:261,3\n47#1:299,9\n47#1:319,3\n57#1:340,9\n57#1:360,3\n43#1:114,6\n62#1:168,6\n63#1:212,6\n64#1:253,6\n47#1:311,6\n57#1:352,6\n63#1:183\n63#1:184,10\n63#1:224\n64#1:226\n64#1:227,8\n64#1:265\n47#1:284\n47#1:285,8\n47#1:323\n22#1:266\n22#1:269\n22#1:267\n22#1:270\n28#1:273,3\n23#1:280,3\n22#1:268\n28#1:272\n23#1:279\n28#1:276\n28#1:277\n*E\n"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000H\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0005\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0010\u000b\n\u0002\u0008\u0008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0016\n\u0002\u0010\t\n\u0002\u0008\u0006\u001a+\u0010\u0000\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u0006\u001a\u00020\u0007H\u0007\u00a2\u0006\u0004\u0008\u0008\u0010\t\u001a?\u0010\n\u001a\u00020\u00012\u0006\u0010\u0002\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\u00032\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00010\r2\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u000f\u001a\u00020\u0010H\u0007\u00a2\u0006\u0002\u0010\u0011\u001a\u0017\u0010\u0012\u001a\u00020\u00012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u0007\u00a2\u0006\u0002\u0010\u0013\u001a\u0015\u0010\u0014\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u0003H\u0007\u00a2\u0006\u0002\u0010\u0016\u001a5\u0010\u0017\u001a\u00020\u00012\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u001c\u0010\u0018\u001a\u0018\u0012\u0004\u0012\u00020\u001a\u0012\u0004\u0012\u00020\u00010\u0019\u00a2\u0006\u0002\u0008\u001b\u00a2\u0006\u0002\u0008\u001cH\u0007\u00a2\u0006\u0002\u0010\u001d\u001aA\u0010\u001e\u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00032\u000c\u0010\u000c\u001a\u0008\u0012\u0004\u0012\u00020\u00010\r2\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u00052\u0008\u0008\u0002\u0010\u000f\u001a\u00020\u00102\u0008\u0008\u0002\u0010\u000e\u001a\u00020\u0003H\u0007\u00a2\u0006\u0002\u0010\u001f\u001a\u001f\u0010 \u001a\u00020\u00012\u0006\u0010\u0015\u001a\u00020\u00032\u0008\u0008\u0002\u0010!\u001a\u00020\u0010H\u0007\u00a2\u0006\u0002\u0010\"\u001a9\u0010#\u001a\u00020\u00012\u0006\u0010$\u001a\u00020\u00032\u0006\u0010%\u001a\u00020\u00032\n\u0008\u0002\u0010&\u001a\u0004\u0018\u00010\u00032\u000e\u0008\u0002\u0010\'\u001a\u0008\u0012\u0004\u0012\u00020\u00010\rH\u0007\u00a2\u0006\u0002\u0010(\u001a\r\u0010)\u001a\u00020\u0001H\u0007\u00a2\u0006\u0002\u0010*\u001a!\u0010+\u001a\u00020\u00012\u0006\u0010$\u001a\u00020\u00032\n\u0008\u0002\u0010,\u001a\u0004\u0018\u00010\u0003H\u0007\u00a2\u0006\u0002\u0010-\u001a\'\u0010.\u001a\u00020\u00012\u0006\u0010/\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\u00032\u0008\u0008\u0002\u0010\u0004\u001a\u00020\u0005H\u0007\u00a2\u0006\u0002\u00100\u001a\u0016\u00101\u001a\u00020\u00032\u0006\u00102\u001a\u0002032\u0006\u00104\u001a\u000203\u001a\u000e\u00105\u001a\u00020\u00032\u0006\u00106\u001a\u000203\u001a\u000e\u00107\u001a\u00020\u00032\u0006\u00108\u001a\u000203\u00a8\u00069"
    }
    d2 = {
        "Glyph",
        "",
        "kind",
        "",
        "modifier",
        "Landroidx/compose/ui/Modifier;",
        "color",
        "Landroidx/compose/ui/graphics/Color;",
        "Glyph-FNF3uiM",
        "(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V",
        "IconAction",
        "label",
        "onClick",
        "Lkotlin/Function0;",
        "tag",
        "enabled",
        "",
        "(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "Mark",
        "(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V",
        "Eyebrow",
        "text",
        "(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V",
        "Paper",
        "content",
        "Lkotlin/Function1;",
        "Landroidx/compose/foundation/layout/ColumnScope;",
        "Landroidx/compose/runtime/Composable;",
        "Lkotlin/ExtensionFunctionType;",
        "(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V",
        "PrimaryButton",
        "(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "Notice",
        "error",
        "(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V",
        "EmptyState",
        "title",
        "description",
        "action",
        "onAction",
        "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V",
        "Busy",
        "(Landroidx/compose/runtime/Composer;I)V",
        "SectionTitle",
        "subtitle",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V",
        "Metric",
        "value",
        "(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V",
        "intervalLabel",
        "dueAt",
        "",
        "now",
        "localTime",
        "timestamp",
        "durationLabel",
        "ms",
        "app_debug"
    }
    k = 0x2
    mv = {
        0x2,
        0x2,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method public static synthetic $r8$lambda$3fBQIAomEF4VrT_0Xj-tdbpydRQ(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState$lambda$1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$3oTBevsA_d3yNarw9aT-bhf0Jcs(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy$lambda$1(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$64ioF3EvFFO2Oxg4627nihWXsXc(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 1

    invoke-static {p0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice$lambda$0$0(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$7suQya1s0gSNGqS6o7k4J0Zw1Es(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    invoke-static/range {p0 .. p6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric$lambda$1(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$I89rDH8U6n9rAHZ5yrCTl7DE7vU(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton$lambda$1(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$LhsS-GbQkRnhMjxFPorZaggQRFA(Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice$lambda$1(Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$NBqziWLkgT_j-UkIX88pqSTjWK0(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 9

    invoke-static/range {p0 .. p8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction$lambda$2(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$R9e0W-HopkDnoAsmM63SCo-69HY(Ljava/lang/String;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->SectionTitle$lambda$1(Ljava/lang/String;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$TMsqgTgQkxrfF901bHsFSHqEBw4(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction$lambda$1(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$Ybl1n4zcFZc9KuP9PLokn-_Uh3s()Lkotlin/Unit;
    .registers 1

    invoke-static {}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState$lambda$0$0()Lkotlin/Unit;

    move-result-object v0

    return-object v0
.end method

.method public static synthetic $r8$lambda$YdIbrqOXNw4kiDHRinhxj_xoxrI(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    invoke-static/range {p0 .. p5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper$lambda$1(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$axOFVDV3_23DyY2Cf7haWCCicLg(Ljava/lang/String;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton$lambda$0(Ljava/lang/String;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$jWjgEGTPkTz3kfIxF_uhIq8BnpY(Ljava/lang/String;Landroidx/compose/ui/Modifier;JIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$1(Ljava/lang/String;Landroidx/compose/ui/Modifier;JIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qCDTbY0AmZN7mn0sNHwGpAslHvY(Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 3

    invoke-static {p0, p1, p2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper$lambda$0(Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$qq5Qs-cHjSz3iRcbYn_od_nG02g(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow$lambda$0(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$rhf2XF9zeHqKW5_acjMgmqVbC8Q(Ljava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .registers 4

    invoke-static {p0, p1, p2, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0(Ljava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$wBwKgkLTbX9SVZ6_1cqggYVhKwg(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 8

    invoke-static/range {p0 .. p7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState$lambda$2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$xM7IH8PsKRjuWM_dq9EhB-tSC4Y(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    invoke-static {p0, p1, p2, p3, p4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Mark$lambda$1(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static synthetic $r8$lambda$z9Cmme2XfOp-SZUYqtNRbYluzKY(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 2

    invoke-static {p0, p1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction$lambda$0$0(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;

    move-result-object p0

    return-object p0
.end method

.method public static final Busy(Landroidx/compose/runtime/Composer;I)V
    .registers 39
    .param p0, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p1, "$changed"    # I

    .line 62
    move/from16 v0, p1

    const v1, 0x3445b037

    move-object/from16 v2, p0

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p0    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(Busy)61@4727L130:XunjiComponents.kt#8ao140"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_16

    move v5, v4

    goto :goto_17

    :cond_16
    move v5, v3

    :goto_17
    and-int/lit8 v6, v0, 0x1

    invoke-interface {v2, v5, v6}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_17b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_2b

    const/4 v5, -0x1

    const-string v6, "com.xunji.flashcards.ui.components.Busy (XunjiComponents.kt:61)"

    invoke-static {v1, v0, v5, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_2b
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, v5, v4, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\1":Landroidx/compose/ui/Modifier;
    sget-object v4, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v4}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v4

    .local v4, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    const/16 v5, 0x36

    .local v5, "$changed\\1":I
    move-object v6, v2

    .local v6, "$composer\\1":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 141
    .local v7, "$i$f$Box\\1\\62":I
    const v8, 0x3e277f0a

    const-string v9, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 142
    const/4 v8, 0x0

    .line 145
    .local v8, "propagateMinConstraints\\1":Z
    invoke-static {v4, v8}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 149
    .local v9, "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 146
    move-object v11, v1

    .local v10, "$changed\\2":I
    .local v11, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    .line 150
    .local v12, "$i$f$Layout\\2\\146":I
    const v13, -0x451e1427

    const-string v14, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 151
    invoke-static {v6, v3}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v3

    .line 152
    .local v3, "compositeKeyHash\\2":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 153
    .local v13, "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 155
    .local v14, "materialized\\2":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    move-object/from16 p0, v1

    .end local v1    # "modifier\\1":Landroidx/compose/ui/Modifier;
    .local p0, "modifier\\1":Landroidx/compose/ui/Modifier;
    shl-int/lit8 v1, v10, 0x6

    and-int/lit16 v1, v1, 0x380

    or-int/lit8 v1, v1, 0x6

    .line 154
    nop

    .local v1, "$changed\\3":I
    .local v15, "factory\\3":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 156
    .local v16, "$i$f$ReusableComposeNode\\3\\154":I
    move/from16 v17, v1

    .end local v1    # "$changed\\3":I
    .local v17, "$changed\\3":I
    const v1, -0x20f7d59c

    move-object/from16 v18, v2

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v18, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 157
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v1

    instance-of v1, v1, Landroidx/compose/runtime/Applier;

    if-nez v1, :cond_92

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 158
    :cond_92
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 159
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v1

    if-eqz v1, :cond_9f

    .line 160
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_a2

    .line 162
    :cond_9f
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 164
    :goto_a2
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 165
    .local v2, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\164\\2":I
    sget-object v19, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v20, v2

    .end local v2    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\164\\2":I
    .local v20, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\164\\2":I
    invoke-virtual/range {v19 .. v19}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v9, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 166
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v13, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 167
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    .local v2, "block\\5":Lkotlin/jvm/functions/Function2;
    const/16 v19, 0x0

    .line 168
    .local v19, "$i$f$set-impl\\5\\167":I
    move-object/from16 v21, v1

    .local v21, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/16 v22, 0x0

    .line 169
    .local v22, "$i$a$-with-Updater$set$1\\6\\168\\5":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v23

    if-nez v23, :cond_e3

    move/from16 v23, v3

    .end local v3    # "compositeKeyHash\\2":I
    .local v23, "compositeKeyHash\\2":I
    invoke-interface/range {v21 .. v21}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v3

    move-object/from16 v24, v4

    .end local v4    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .local v24, "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v3

    if-nez v3, :cond_e0

    goto :goto_e7

    :cond_e0
    move-object/from16 v4, v21

    goto :goto_f7

    .end local v23    # "compositeKeyHash\\2":I
    .end local v24    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .restart local v3    # "compositeKeyHash\\2":I
    .restart local v4    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    :cond_e3
    move/from16 v23, v3

    move-object/from16 v24, v4

    .line 170
    .end local v3    # "compositeKeyHash\\2":I
    .end local v4    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .restart local v23    # "compositeKeyHash\\2":I
    .restart local v24    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    :goto_e7
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move-object/from16 v4, v21

    .end local v21    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .local v4, "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 171
    invoke-static/range {v23 .. v23}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-interface {v1, v3, v2}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 173
    :goto_f7
    nop

    .line 168
    .end local v4    # "$this$set_impl_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v22    # "$i$a$-with-Updater$set$1\\6\\168\\5":I
    nop

    .line 173
    nop

    .line 174
    .end local v2    # "block\\5":Lkotlin/jvm/functions/Function2;
    .end local v19    # "$i$f$set-impl\\5\\167":I
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v2

    invoke-static {v1, v14, v2}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 175
    nop

    .line 164
    .end local v1    # "$this$Layout_u24lambda_u240\\4":Landroidx/compose/runtime/Composer;
    .end local v20    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\4\\164\\2":I
    nop

    .line 176
    shr-int/lit8 v1, v17, 0x6

    and-int/lit8 v1, v1, 0xe

    .local v1, "$changed\\7":I
    move-object v2, v6

    .local v2, "$composer\\7":Landroidx/compose/runtime/Composer;
    const/4 v3, 0x0

    .line 147
    .local v3, "$i$a$-Layout-BoxKt$Box$1\\7\\176\\1":I
    const v4, 0x6d423196

    move/from16 v19, v1

    .end local v1    # "$changed\\7":I
    .local v19, "$changed\\7":I
    const-string v1, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v2, v4, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v4, v5, 0x6

    and-int/lit8 v4, v4, 0x70

    or-int/lit8 v4, v4, 0x6

    .local v4, "$changed\\8":I
    check-cast v1, Landroidx/compose/foundation/layout/BoxScope;

    .local v1, "$this$Busy_u24lambda_u240\\8":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v33, v2

    .local v33, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v20, 0x0

    .line 62
    .local v20, "$i$a$-Box-XunjiComponentsKt$Busy$1\\8\\147\\0":I
    move-object/from16 v21, v1

    .end local v1    # "$this$Busy_u24lambda_u240\\8":Landroidx/compose/foundation/layout/BoxScope;
    .local v21, "$this$Busy_u24lambda_u240\\8":Landroidx/compose/foundation/layout/BoxScope;
    const v1, 0x5130426

    move-object/from16 v22, v2

    .end local v2    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\7":Landroidx/compose/runtime/Composer;
    const-string v2, "C61@4791L64:XunjiComponents.kt#8ao140"

    move/from16 v36, v3

    move-object/from16 v3, v33

    .end local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v3, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v36, "$i$a$-Layout-BoxKt$Box$1\\7\\176\\1":I
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v2, 0x20

    .local v2, "$this$dp\\9":I
    const/16 v25, 0x0

    .line 177
    .local v25, "$i$f$getDp\\9\\62":I
    nop

    .end local v3    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .restart local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    int-to-float v3, v2

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 62
    .end local v2    # "$this$dp\\9":I
    .end local v25    # "$i$f$getDp\\9\\62":I
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v25

    const/4 v1, 0x3

    .local v1, "$this$dp\\10":I
    const/4 v2, 0x0

    .line 177
    .local v2, "$i$f$getDp\\10\\62":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v28

    .line 62
    .end local v1    # "$this$dp\\10":I
    .end local v2    # "$i$f$getDp\\10\\62":I
    const-wide/16 v26, 0x0

    const-wide/16 v29, 0x0

    const/16 v31, 0x0

    const/16 v32, 0x0

    const/16 v34, 0x186

    const/16 v35, 0x3a

    invoke-static/range {v25 .. v35}, Landroidx/compose/material3/ProgressIndicatorKt;->CircularProgressIndicator-4lLiAd8(Landroidx/compose/ui/Modifier;JFJIFLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 147
    .end local v4    # "$changed\\8":I
    .end local v20    # "$i$a$-Box-XunjiComponentsKt$Busy$1\\8\\147\\0":I
    .end local v21    # "$this$Busy_u24lambda_u240\\8":Landroidx/compose/foundation/layout/BoxScope;
    .end local v33    # "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v22 .. v22}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 176
    .end local v19    # "$changed\\7":I
    .end local v22    # "$composer\\7":Landroidx/compose/runtime/Composer;
    .end local v36    # "$i$a$-Layout-BoxKt$Box$1\\7\\176\\1":I
    nop

    .line 178
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 156
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 179
    nop

    .line 150
    .end local v15    # "factory\\3":Lkotlin/jvm/functions/Function0;
    .end local v16    # "$i$f$ReusableComposeNode\\3\\154":I
    .end local v17    # "$changed\\3":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 180
    nop

    .line 141
    .end local v10    # "$changed\\2":I
    .end local v11    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v12    # "$i$f$Layout\\2\\146":I
    .end local v13    # "localMap\\2":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\2":Landroidx/compose/ui/Modifier;
    .end local v23    # "compositeKeyHash\\2":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 181
    nop

    .end local v5    # "$changed\\1":I
    .end local v6    # "$composer\\1":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$Box\\1\\62":I
    .end local v8    # "propagateMinConstraints\\1":Z
    .end local v9    # "measurePolicy\\1":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v24    # "contentAlignment\\1":Landroidx/compose/ui/Alignment;
    .end local p0    # "modifier\\1":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_180

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_180

    .line 62
    .end local v18    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    :cond_17b
    move-object/from16 v18, v2

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v18    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_180
    :goto_180
    invoke-interface/range {v18 .. v18}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_18e

    new-instance v2, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda5;

    invoke-direct {v2, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda5;-><init>(I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_18e
    return-void
.end method

.method private static final Busy$lambda$1(ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 4

    or-int/lit8 v0, p0, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p1, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Busy(Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V
    .registers 24
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "description"    # Ljava/lang/String;
    .param p2, "action"    # Ljava/lang/String;
    .param p3, "onAction"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v5, p5

    const-string v0, "title"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v0, "description"

    invoke-static {v2, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 55
    const v0, -0x593eb597

    move-object/from16 v3, p4

    invoke-interface {v3, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(EmptyState)N(title,description,action,onAction)54@4306L2,55@4344L355,55@4313L386:XunjiComponents.kt#8ao140"

    invoke-static {v7, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p5

    .local v3, "$dirty":I
    and-int/lit8 v4, v5, 0x6

    if-nez v4, :cond_2e

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_2c

    const/4 v4, 0x4

    goto :goto_2d

    :cond_2c
    const/4 v4, 0x2

    :goto_2d
    or-int/2addr v3, v4

    :cond_2e
    and-int/lit8 v4, v5, 0x30

    if-nez v4, :cond_3e

    invoke-interface {v7, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_3b

    const/16 v4, 0x20

    goto :goto_3d

    :cond_3b
    const/16 v4, 0x10

    :goto_3d
    or-int/2addr v3, v4

    :cond_3e
    and-int/lit8 v4, p6, 0x4

    if-eqz v4, :cond_47

    or-int/lit16 v3, v3, 0x180

    move-object/from16 v6, p2

    goto :goto_5c

    :cond_47
    and-int/lit16 v6, v5, 0x180

    if-nez v6, :cond_5a

    move-object/from16 v6, p2

    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_56

    const/16 v8, 0x100

    goto :goto_58

    :cond_56
    const/16 v8, 0x80

    :goto_58
    or-int/2addr v3, v8

    goto :goto_5c

    :cond_5a
    move-object/from16 v6, p2

    :goto_5c
    and-int/lit8 v8, p6, 0x8

    if-eqz v8, :cond_65

    or-int/lit16 v3, v3, 0xc00

    move-object/from16 v9, p3

    goto :goto_7a

    :cond_65
    and-int/lit16 v9, v5, 0xc00

    if-nez v9, :cond_78

    move-object/from16 v9, p3

    invoke-interface {v7, v9}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v10

    if-eqz v10, :cond_74

    const/16 v10, 0x800

    goto :goto_76

    :cond_74
    const/16 v10, 0x400

    :goto_76
    or-int/2addr v3, v10

    goto :goto_7a

    :cond_78
    move-object/from16 v9, p3

    :goto_7a
    move v10, v3

    .end local v3    # "$dirty":I
    .local v10, "$dirty":I
    and-int/lit16 v3, v10, 0x493

    const/16 v11, 0x492

    const/4 v12, 0x0

    const/4 v13, 0x1

    if-eq v3, v11, :cond_85

    move v3, v13

    goto :goto_86

    :cond_85
    move v3, v12

    :goto_86
    and-int/lit8 v11, v10, 0x1

    invoke-interface {v7, v3, v11}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v3

    if-eqz v3, :cond_f7

    if-eqz v4, :cond_92

    const/4 v3, 0x0

    .end local p2    # "action":Ljava/lang/String;
    .local v3, "action":Ljava/lang/String;
    goto :goto_93

    .end local v3    # "action":Ljava/lang/String;
    .restart local p2    # "action":Ljava/lang/String;
    :cond_92
    move-object v3, v6

    .end local p2    # "action":Ljava/lang/String;
    .restart local v3    # "action":Ljava/lang/String;
    :goto_93
    if-eqz v8, :cond_c3

    const v4, -0x467a135

    const-string v6, "CC(remember):XunjiComponents.kt#9igjgp"

    invoke-static {v7, v4, v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v4, 0x0

    .local v4, "invalid\\1":Z
    move-object v6, v7

    .local v6, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 135
    .local v8, "$i$f$cache\\1\\55":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v14, 0x0

    .line 136
    .local v14, "$i$a$-let-ComposerKt$cache$1\\2\\135\\1":I
    sget-object v15, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v15}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v15

    if-ne v11, v15, :cond_ba

    .line 137
    const/4 v15, 0x0

    .local v15, "$i$a$-cache-XunjiComponentsKt$EmptyState$1\\3\\137\\0":I
    new-instance v16, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda18;

    invoke-direct/range {v16 .. v16}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda18;-><init>()V

    .end local v15    # "$i$a$-cache-XunjiComponentsKt$EmptyState$1\\3\\137\\0":I
    move-object/from16 v15, v16

    .line 138
    .local v15, "value\\2":Ljava/lang/Object;
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 139
    move-object v11, v15

    .end local v15    # "value\\2":Ljava/lang/Object;
    goto :goto_bb

    .line 140
    :cond_ba
    nop

    .line 135
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v14    # "$i$a$-let-ComposerKt$cache$1\\2\\135\\1":I
    :goto_bb
    nop

    .line 55
    .end local v4    # "invalid\\1":Z
    .end local v6    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\1\\55":I
    move-object v4, v11

    check-cast v4, Lkotlin/jvm/functions/Function0;

    .end local p3    # "onAction":Lkotlin/jvm/functions/Function0;
    .local v4, "onAction":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    move-object v9, v4

    .end local v4    # "onAction":Lkotlin/jvm/functions/Function0;
    .local v9, "onAction":Lkotlin/jvm/functions/Function0;
    :cond_c3
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_cf

    const/4 v4, -0x1

    const-string v6, "com.xunji.flashcards.ui.components.EmptyState (XunjiComponents.kt:54)"

    invoke-static {v0, v10, v4, v6}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 56
    :cond_cf
    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/4 v4, 0x0

    const/4 v6, 0x0

    invoke-static {v0, v4, v13, v6}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v0

    new-instance v4, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda1;

    invoke-direct {v4, v1, v2, v3, v9}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda1;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;)V

    const v6, 0x5be36199

    const/16 v8, 0x36

    invoke-static {v6, v13, v4, v7, v8}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v4

    check-cast v4, Lkotlin/jvm/functions/Function3;

    invoke-static {v0, v4, v7, v8, v12}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_f5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 61
    :cond_f5
    move-object v4, v9

    goto :goto_fc

    .line 55
    .end local v3    # "action":Ljava/lang/String;
    .end local v9    # "onAction":Lkotlin/jvm/functions/Function0;
    .restart local p2    # "action":Ljava/lang/String;
    .restart local p3    # "onAction":Lkotlin/jvm/functions/Function0;
    :cond_f7
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v3, v6

    move-object v4, v9

    .line 61
    .end local p2    # "action":Ljava/lang/String;
    .end local p3    # "onAction":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "action":Ljava/lang/String;
    .restart local v4    # "onAction":Lkotlin/jvm/functions/Function0;
    :goto_fc
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_10c

    new-instance v0, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda2;

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_10c
    return-void
.end method

.method private static final EmptyState$lambda$0$0()Lkotlin/Unit;
    .registers 1

    .line 55
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final EmptyState$lambda$1(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/foundation/layout/ColumnScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 42
    .param p0, "$title"    # Ljava/lang/String;
    .param p1, "$description"    # Ljava/lang/String;
    .param p2, "$action"    # Ljava/lang/String;
    .param p3, "$onAction"    # Lkotlin/jvm/functions/Function0;
    .param p4, "$this$Paper"    # Landroidx/compose/foundation/layout/ColumnScope;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I

    move-object/from16 v5, p5

    move/from16 v0, p6

    const-string v1, "$this$Paper"

    move-object/from16 v2, p4

    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v1, "C56@4430L11,56@4348L219,57@4601L10,57@4570L57,57@4628L19:XunjiComponents.kt#8ao140"

    invoke-static {v5, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v1, v0, 0x11

    const/16 v3, 0x10

    const/4 v4, 0x0

    if-eq v1, v3, :cond_19

    const/4 v1, 0x1

    goto :goto_1a

    :cond_19
    move v1, v4

    :goto_1a
    and-int/lit8 v3, v0, 0x1

    invoke-interface {v5, v1, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v1

    if-eqz v1, :cond_210

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_31

    const/4 v1, -0x1

    const-string v3, "com.xunji.flashcards.ui.components.EmptyState.<anonymous> (XunjiComponents.kt:56)"

    const v6, 0x5be36199

    invoke-static {v6, v0, v1, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 57
    :cond_31
    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x40

    .local v3, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 324
    .local v6, "$i$f$getDp\\1\\57":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 57
    .end local v3    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\57":I
    invoke-static {v1, v3}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v1

    const/16 v3, 0x16

    .local v3, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 324
    .local v6, "$i$f$getDp\\2\\57":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 57
    .end local v3    # "$this$dp\\2":I
    .end local v6    # "$i$f$getDp\\2\\57":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v1, v3}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v6

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v5, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getPrimaryContainer-0d7_KjU()J

    move-result-wide v7

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v9, 0x0

    invoke-static/range {v6 .. v11}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    .local v1, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v3, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v3

    .local v3, "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    const/16 v6, 0x30

    .local v6, "$changed\\3":I
    move-object/from16 v7, p5

    .local v7, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 325
    .local v8, "$i$f$Box\\3\\57":I
    const v9, 0x3e277f0a

    const-string v10, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v7, v9, v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 326
    const/4 v9, 0x0

    .line 329
    .local v9, "propagateMinConstraints\\3":Z
    invoke-static {v3, v9}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v10

    .line 333
    .local v10, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v11, v6, 0x3

    and-int/lit8 v11, v11, 0x70

    .line 330
    nop

    .local v11, "$changed\\4":I
    move-object v12, v1

    .local v12, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    .line 334
    .local v13, "$i$f$Layout\\4\\330":I
    const v14, -0x451e1427

    const-string v15, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 335
    invoke-static {v7, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v14

    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    move-result v14

    .line 336
    .local v14, "compositeKeyHash\\4":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v15

    .line 337
    .local v15, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v12}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    .line 339
    .local v4, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v17, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v17 .. v17}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v17

    shl-int/lit8 v0, v11, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 338
    nop

    .local v0, "$changed\\5":I
    move-object/from16 v18, v17

    .local v18, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v17, 0x0

    .line 340
    .local v17, "$i$f$ReusableComposeNode\\5\\338":I
    move/from16 v19, v0

    .end local v0    # "$changed\\5":I
    .local v19, "$changed\\5":I
    const v0, -0x20f7d59c

    move-object/from16 v20, v1

    .end local v1    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v20, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 341
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_c5

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 342
    :cond_c5
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 343
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_d4

    .line 344
    move-object/from16 v0, v18

    .end local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v0, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7, v0}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_d9

    .line 346
    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_d4
    move-object/from16 v0, v18

    .end local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 348
    :goto_d9
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v1

    .local v1, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 349
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\348\\4":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v0

    .end local v0    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v10, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 350
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v15, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 351
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    .local v0, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 352
    .local v21, "$i$f$set-impl\\7\\351":I
    move-object/from16 v23, v1

    .local v23, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 353
    .local v24, "$i$a$-with-Updater$set$1\\8\\352\\7":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_119

    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v25, v3

    .end local v3    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .local v25, "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_116

    goto :goto_11b

    :cond_116
    move-object/from16 v3, v23

    goto :goto_12b

    .end local v25    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .restart local v3    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    :cond_119
    move-object/from16 v25, v3

    .line 354
    .end local v3    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .restart local v25    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    :goto_11b
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 355
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v1, v2, v0}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 357
    :goto_12b
    nop

    .line 352
    .end local v3    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\8\\352\\7":I
    nop

    .line 357
    nop

    .line 358
    .end local v0    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\7\\351":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v1, v4, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 359
    nop

    .line 348
    .end local v1    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\348\\4":I
    nop

    .line 360
    shr-int/lit8 v0, v19, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v1, v7

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 331
    .local v2, "$i$a$-Layout-BoxKt$Box$1\\9\\360\\3":I
    const v3, 0x6d423196

    move/from16 v18, v0

    .end local v0    # "$changed\\9":I
    .local v18, "$changed\\9":I
    const-string v0, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v3, v6, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    .local v3, "$changed\\10":I
    check-cast v0, Landroidx/compose/foundation/layout/BoxScope;

    .local v0, "$this$EmptyState_u24lambda_u241_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v30, v1

    .local v30, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 57
    .local v21, "$i$a$-Box-XunjiComponentsKt$EmptyState$2$1\\10\\331\\0":I
    move-object/from16 v23, v0

    .end local v0    # "$this$EmptyState_u24lambda_u241_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    .local v23, "$this$EmptyState_u24lambda_u241_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    const v0, -0x571859b4

    move-object/from16 v24, v1

    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v24, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-string v1, "C56@4545L11,56@4497L68:XunjiComponents.kt#8ao140"

    move/from16 v33, v2

    move-object/from16 v2, v30

    .end local v30    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v2, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v33, "$i$a$-Layout-BoxKt$Box$1\\9\\360\\3":I
    invoke-static {v2, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v0, Landroidx/compose/ui/Modifier;

    const/16 v1, 0x20

    .local v1, "$this$dp\\11":I
    const/16 v26, 0x0

    .line 324
    .local v26, "$i$f$getDp\\11\\57":I
    move/from16 v34, v3

    .end local v3    # "$changed\\10":I
    .local v34, "$changed\\10":I
    int-to-float v3, v1

    invoke-static {v3}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v1

    .line 57
    .end local v1    # "$this$dp\\11":I
    .end local v26    # "$i$f$getDp\\11\\57":I
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v27

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v28

    const/16 v31, 0x36

    const/16 v32, 0x0

    const-string v26, "leaf"

    .end local v2    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v30    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v26 .. v32}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v30 .. v30}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 331
    .end local v21    # "$i$a$-Box-XunjiComponentsKt$EmptyState$2$1\\10\\331\\0":I
    .end local v23    # "$this$EmptyState_u24lambda_u241_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    .end local v30    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .end local v34    # "$changed\\10":I
    invoke-static/range {v24 .. v24}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 360
    .end local v18    # "$changed\\9":I
    .end local v24    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v33    # "$i$a$-Layout-BoxKt$Box$1\\9\\360\\3":I
    nop

    .line 361
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 340
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 362
    nop

    .line 334
    .end local v17    # "$i$f$ReusableComposeNode\\5\\338":I
    .end local v19    # "$changed\\5":I
    .end local v22    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 363
    nop

    .line 325
    .end local v4    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local v11    # "$changed\\4":I
    .end local v12    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v13    # "$i$f$Layout\\4\\330":I
    .end local v14    # "compositeKeyHash\\4":I
    .end local v15    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 364
    nop

    .line 58
    .end local v6    # "$changed\\3":I
    .end local v7    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$Box\\3\\57":I
    .end local v9    # "propagateMinConstraints\\3":Z
    .end local v10    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v20    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v25    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, v5, v1}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/Typography;->getHeadlineMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/4 v0, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x0

    move-object/from16 v0, p0

    move-object/from16 v22, p5

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v5, v22

    const/4 v0, 0x2

    move-object/from16 v8, p1

    const/4 v1, 0x0

    invoke-static {v8, v1, v5, v1, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    .line 59
    if-eqz p2, :cond_1fd

    const v0, -0xf6e7849

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "58@4666L30"

    invoke-static {v5, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/16 v7, 0x1c

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    invoke-static/range {v0 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    goto :goto_203

    :cond_1fd
    const v0, 0x2158c6e9

    invoke-interface {v5, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_203
    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_215

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_215

    .line 56
    :cond_210
    move-object/from16 v8, p1

    invoke-interface {v5}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 60
    :cond_215
    :goto_215
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final EmptyState$lambda$2(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->EmptyState(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V
    .registers 32
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p0

    const-string v1, "text"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 45
    const v1, 0x4445c2d4

    move-object/from16 v2, p1

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(Eyebrow)N(text)44@3160L10,44@3203L11,44@3130L102:XunjiComponents.kt#8ao140"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p2

    .local v3, "$dirty":I
    and-int/lit8 v4, p2, 0x6

    const/4 v5, 0x2

    if-nez v4, :cond_26

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_24

    const/4 v4, 0x4

    goto :goto_25

    :cond_24
    move v4, v5

    :goto_25
    or-int/2addr v3, v4

    :cond_26
    and-int/lit8 v4, v3, 0x3

    if-eq v4, v5, :cond_2c

    const/4 v4, 0x1

    goto :goto_2d

    :cond_2c
    const/4 v4, 0x0

    :goto_2d
    and-int/lit8 v5, v3, 0x1

    invoke-interface {v2, v4, v5}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_9e

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_41

    const/4 v4, -0x1

    const-string v5, "com.xunji.flashcards.ui.components.Eyebrow (XunjiComponents.kt:44)"

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_41
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getLabelMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v4

    and-int/lit8 v23, v3, 0xe

    const/16 v24, 0x0

    const v25, 0x1fffa

    const/4 v1, 0x0

    move-object/from16 v22, v2

    move-wide/from16 v27, v4

    move v5, v3

    move-wide/from16 v2, v27

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v5, "$dirty":I
    .local v22, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    move v7, v5

    .end local v5    # "$dirty":I
    .local v7, "$dirty":I
    const-wide/16 v5, 0x0

    move v8, v7

    .end local v7    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v7, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v10, v9

    .end local v9    # "$dirty":I
    .local v10, "$dirty":I
    const/4 v9, 0x0

    move v12, v10

    .end local v10    # "$dirty":I
    .local v12, "$dirty":I
    const-wide/16 v10, 0x0

    move v13, v12

    .end local v12    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v12, 0x0

    move v14, v13

    .end local v13    # "$dirty":I
    .local v14, "$dirty":I
    const/4 v13, 0x0

    move/from16 v16, v14

    .end local v14    # "$dirty":I
    .local v16, "$dirty":I
    const-wide/16 v14, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v20, v19

    .end local v19    # "$dirty":I
    .local v20, "$dirty":I
    const/16 v19, 0x0

    move/from16 v26, v20

    .end local v20    # "$dirty":I
    .local v26, "$dirty":I
    const/16 v20, 0x0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_a5

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_a5

    .end local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v26    # "$dirty":I
    .restart local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$dirty":I
    :cond_9e
    move-object/from16 v22, v2

    move/from16 v26, v3

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .restart local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v26    # "$dirty":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_a5
    :goto_a5
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_b6

    new-instance v2, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda6;

    move/from16 v3, p2

    invoke-direct {v2, v0, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda6;-><init>(Ljava/lang/String;I)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_b8

    :cond_b6
    move/from16 v3, p2

    :goto_b8
    return-void
.end method

.method private static final Eyebrow$lambda$0(Ljava/lang/String;ILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 5

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p2, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Eyebrow(Ljava/lang/String;Landroidx/compose/runtime/Composer;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V
    .registers 23
    .param p0, "kind"    # Ljava/lang/String;
    .param p1, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p2, "$v$c$androidx-compose-ui-graphics-Color$-color$0"    # J
    .param p4, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p5, "$changed"    # I

    move-object/from16 v1, p0

    move/from16 v5, p5

    const-string v0, "kind"

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 20
    const v0, -0x5d2296b

    move-object/from16 v2, p4

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .end local p4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v7, "$composer":Landroidx/compose/runtime/Composer;
    const-string v2, "C(Glyph)N(kind,modifier,color:c#ui.graphics.Color)20@811L1654,20@782L1683:XunjiComponents.kt#8ao140"

    invoke-static {v7, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v2, p5

    .local v2, "$dirty":I
    and-int/lit8 v3, v5, 0x6

    const/4 v4, 0x4

    if-nez v3, :cond_28

    invoke-interface {v7, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v3

    if-eqz v3, :cond_26

    move v3, v4

    goto :goto_27

    :cond_26
    const/4 v3, 0x2

    :goto_27
    or-int/2addr v2, v3

    :cond_28
    and-int/lit8 v3, p6, 0x2

    if-eqz v3, :cond_31

    or-int/lit8 v2, v2, 0x30

    move-object/from16 v6, p1

    goto :goto_46

    :cond_31
    and-int/lit8 v6, v5, 0x30

    if-nez v6, :cond_44

    move-object/from16 v6, p1

    invoke-interface {v7, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_40

    const/16 v8, 0x20

    goto :goto_42

    :cond_40
    const/16 v8, 0x10

    :goto_42
    or-int/2addr v2, v8

    goto :goto_46

    :cond_44
    move-object/from16 v6, p1

    :goto_46
    and-int/lit16 v8, v5, 0x180

    const/16 v9, 0x100

    if-nez v8, :cond_60

    and-int/lit8 v8, p6, 0x4

    if-nez v8, :cond_5a

    move-wide/from16 v10, p2

    invoke-interface {v7, v10, v11}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v8

    if-eqz v8, :cond_5c

    move v8, v9

    goto :goto_5e

    :cond_5a
    move-wide/from16 v10, p2

    :cond_5c
    const/16 v8, 0x80

    :goto_5e
    or-int/2addr v2, v8

    goto :goto_62

    :cond_60
    move-wide/from16 v10, p2

    :goto_62
    and-int/lit16 v8, v2, 0x93

    const/16 v12, 0x92

    const/4 v13, 0x0

    const/4 v14, 0x1

    if-eq v8, v12, :cond_6c

    move v8, v14

    goto :goto_6d

    :cond_6c
    move v8, v13

    :goto_6d
    and-int/lit8 v12, v2, 0x1

    invoke-interface {v7, v8, v12}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v8

    if-eqz v8, :cond_11f

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startDefaults()V

    const-string v8, "19@756L11"

    invoke-static {v7, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v8, v5, 0x1

    if-eqz v8, :cond_93

    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getDefaultsInvalid()Z

    move-result v8

    if-eqz v8, :cond_88

    goto :goto_93

    :cond_88
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    and-int/lit8 v3, p6, 0x4

    if-eqz v3, :cond_91

    and-int/lit16 v2, v2, -0x381

    :cond_91
    move-object v3, v6

    goto :goto_ad

    :cond_93
    :goto_93
    if-eqz v3, :cond_9a

    sget-object v3, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v3, Landroidx/compose/ui/Modifier;

    .end local p1    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_9b

    .end local v3    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p1    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_9a
    move-object v3, v6

    .end local p1    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v3    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_9b
    and-int/lit8 v6, p6, 0x4

    if-eqz v6, :cond_ad

    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v8, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v7, v8}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v10

    .end local p2    # "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    .local v10, "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    and-int/lit16 v2, v2, -0x381

    :cond_ad
    :goto_ad
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endDefaults()V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_bc

    const/4 v6, -0x1

    const-string v8, "com.xunji.flashcards.ui.components.Glyph (XunjiComponents.kt:19)"

    invoke-static {v0, v2, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 21
    :cond_bc
    const/16 v0, 0x18

    .local v0, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 72
    .local v6, "$i$f$getDp\\1\\21":I
    int-to-float v8, v0

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v0

    .line 21
    .end local v0    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\21":I
    invoke-static {v3, v0}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v0

    const v6, 0x26129c0b

    const-string v8, "CC(remember):XunjiComponents.kt#9igjgp"

    invoke-static {v7, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit16 v6, v2, 0x380

    xor-int/lit16 v6, v6, 0x180

    if-le v6, v9, :cond_dc

    invoke-interface {v7, v10, v11}, Landroidx/compose/runtime/Composer;->changed(J)Z

    move-result v6

    if-nez v6, :cond_e0

    :cond_dc
    and-int/lit16 v6, v2, 0x180

    if-ne v6, v9, :cond_e2

    :cond_e0
    move v6, v14

    goto :goto_e3

    :cond_e2
    move v6, v13

    :goto_e3
    and-int/lit8 v8, v2, 0xe

    if-ne v8, v4, :cond_e8

    goto :goto_e9

    :cond_e8
    move v14, v13

    :goto_e9
    or-int v4, v6, v14

    .local v4, "invalid\\2":Z
    move-object v6, v7

    .local v6, "$this$cache\\2":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 73
    .local v8, "$i$f$cache\\2\\21":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\2":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 74
    .local v12, "$i$a$-let-ComposerKt$cache$1\\3\\73\\2":I
    if-nez v4, :cond_fe

    sget-object v14, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v14}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v9, v14, :cond_fd

    goto :goto_fe

    .line 78
    :cond_fd
    goto :goto_109

    .line 75
    :cond_fe
    :goto_fe
    const/4 v14, 0x0

    .line 21
    .local v14, "$i$a$-cache-XunjiComponentsKt$Glyph$1\\4\\75\\0":I
    new-instance v15, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda0;

    invoke-direct {v15, v1, v10, v11}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda0;-><init>(Ljava/lang/String;J)V

    .line 75
    .end local v14    # "$i$a$-cache-XunjiComponentsKt$Glyph$1\\4\\75\\0":I
    nop

    .line 76
    .local v15, "value\\3":Ljava/lang/Object;
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 77
    move-object v9, v15

    .line 73
    .end local v9    # "it\\2":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\3\\73\\2":I
    .end local v15    # "value\\3":Ljava/lang/Object;
    :goto_109
    nop

    .line 21
    .end local v4    # "invalid\\2":Z
    .end local v6    # "$this$cache\\2":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\2\\21":I
    check-cast v9, Lkotlin/jvm/functions/Function1;

    invoke-static {v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    invoke-static {v0, v9, v7, v13}, Landroidx/compose/foundation/CanvasKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/Composer;I)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_11b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 38
    :cond_11b
    move v8, v2

    move-object v2, v3

    move-wide v3, v10

    goto :goto_125

    .line 20
    .end local v3    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v10    # "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    .restart local p1    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    :cond_11f
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move v8, v2

    move-object v2, v6

    move-wide v3, v10

    .line 38
    .end local p1    # "modifier":Landroidx/compose/ui/Modifier;
    .end local p2    # "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    .local v2, "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "$v$c$androidx-compose-ui-graphics-Color$-color$0":J
    .local v8, "$dirty":I
    :goto_125
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v9

    if-eqz v9, :cond_135

    new-instance v0, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda10;

    move/from16 v6, p6

    invoke-direct/range {v0 .. v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda10;-><init>(Ljava/lang/String;Landroidx/compose/ui/Modifier;JII)V

    invoke-interface {v9, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_135
    return-void
.end method

.method private static final Glyph_FNF3uiM$lambda$0$0(Ljava/lang/String;JLandroidx/compose/ui/graphics/drawscope/DrawScope;)Lkotlin/Unit;
    .registers 28
    .param p0, "$kind"    # Ljava/lang/String;
    .param p1, "$$v$c$androidx-compose-ui-graphics-Color$-color$0"    # J
    .param p3, "$this$Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    const-string v2, "$this$Canvas"

    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 22
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    .local v2, "arg0\\1":J
    const/4 v4, 0x0

    .line 266
    .local v4, "$i$f$getWidth-impl\\1\\22":I
    move-wide v5, v2

    .local v5, "value\\2":J
    const/4 v7, 0x0

    .line 267
    .local v7, "$i$f$unpackFloat1\\2\\266":I
    const/16 v8, 0x20

    shr-long v9, v5, v8

    long-to-int v9, v9

    .local v9, "bits\\3":I
    const/4 v10, 0x0

    .line 268
    .local v10, "$i$f$floatFromBits\\3\\267":I
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v9

    .line 267
    .end local v9    # "bits\\3":I
    .end local v10    # "$i$f$floatFromBits\\3\\267":I
    nop

    .line 266
    .end local v5    # "value\\2":J
    .end local v7    # "$i$f$unpackFloat1\\2\\266":I
    nop

    .line 22
    .end local v2    # "arg0\\1":J
    .end local v4    # "$i$f$getWidth-impl\\1\\22":I
    move v13, v9

    .local v13, "w":F
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    move-result-wide v2

    .local v2, "arg0\\4":J
    const/4 v4, 0x0

    .line 269
    .local v4, "$i$f$getHeight-impl\\4\\22":I
    move-wide v5, v2

    .local v5, "value\\5":J
    const/4 v7, 0x0

    .line 270
    .local v7, "$i$f$unpackFloat2\\5\\269":I
    const-wide v9, 0xffffffffL

    and-long v11, v5, v9

    long-to-int v11, v11

    .local v11, "bits\\6":I
    const/4 v12, 0x0

    .line 268
    .local v12, "$i$f$floatFromBits\\6\\270":I
    invoke-static {v11}, Ljava/lang/Float;->intBitsToFloat(I)F

    move-result v11

    .line 270
    .end local v11    # "bits\\6":I
    .end local v12    # "$i$f$floatFromBits\\6\\270":I
    nop

    .line 269
    .end local v5    # "value\\5":J
    .end local v7    # "$i$f$unpackFloat2\\5\\269":I
    nop

    .line 22
    .end local v2    # "arg0\\4":J
    .end local v4    # "$i$f$getHeight-impl\\4\\22":I
    move v14, v11

    .local v14, "h":F
    new-instance v6, Landroidx/compose/ui/graphics/drawscope/Stroke;

    const-wide v2, 0x3ffccccccccccccdL    # 1.8

    .local v2, "$this$dp\\7":D
    const/4 v4, 0x0

    .line 271
    .local v4, "$i$f$getDp\\7\\22":I
    double-to-float v5, v2

    invoke-static {v5}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 22
    .end local v2    # "$this$dp\\7":D
    .end local v4    # "$i$f$getDp\\7\\22":I
    invoke-interface {v1, v2}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->toPx-0680j_4(F)F

    move-result v16

    sget-object v2, Landroidx/compose/ui/graphics/StrokeCap;->Companion:Landroidx/compose/ui/graphics/StrokeCap$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/StrokeCap$Companion;->getRound-KaPHkGw()I

    move-result v18

    sget-object v2, Landroidx/compose/ui/graphics/StrokeJoin;->Companion:Landroidx/compose/ui/graphics/StrokeJoin$Companion;

    invoke-virtual {v2}, Landroidx/compose/ui/graphics/StrokeJoin$Companion;->getRound-LxFBmk8()I

    move-result v19

    const/16 v21, 0x12

    const/16 v22, 0x0

    const/16 v17, 0x0

    const/16 v20, 0x0

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIILandroidx/compose/ui/graphics/PathEffect;ILkotlin/jvm/internal/DefaultConstructorMarker;)V

    .line 24
    .local v15, "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const v16, 0x3ea3d70a    # 0.32f

    const v17, 0x3dcccccd    # 0.1f

    const v3, 0x3e6b851f    # 0.23f

    sparse-switch v2, :sswitch_data_3da

    :goto_6d
    goto/16 :goto_375

    :sswitch_6f
    const-string v2, "settings"

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_78

    goto :goto_6d

    .line 30
    :cond_78
    const v2, 0x3e9eb852    # 0.31f

    mul-float v4, v13, v2

    move-object v8, v15

    check-cast v8, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    const/16 v11, 0x6c

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-wide/from16 v2, p1

    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    mul-float v4, v13, v17

    move-object v8, v15

    check-cast v8, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    const/4 v1, 0x0

    move v11, v1

    .local v11, "i":I
    :goto_99
    const/16 v1, 0x8

    if-ge v11, v1, :cond_d5

    int-to-double v1, v11

    const-wide v3, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v1, v3

    const/4 v3, 0x4

    int-to-double v3, v3

    div-double v17, v1, v3

    .local v17, "a":D
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->cos(D)D

    move-result-wide v1

    double-to-float v12, v1

    .local v12, "c":F
    invoke-static/range {v17 .. v18}, Ljava/lang/Math;->sin(D)D

    move-result-wide v1

    double-to-float v1, v1

    .local v1, "s":F
    mul-float v2, v12, v16

    const/high16 v3, 0x3f000000    # 0.5f

    add-float v7, v2, v3

    mul-float v2, v1, v16

    add-float v8, v2, v3

    const v2, 0x3edc28f6    # 0.43f

    mul-float v4, v12, v2

    add-float v9, v4, v3

    mul-float/2addr v2, v1

    add-float v10, v2, v3

    move-wide/from16 v2, p1

    move v4, v13

    move v5, v14

    move-object v6, v15

    move v13, v1

    move-object/from16 v1, p3

    .end local v1    # "s":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .local v4, "w":F
    .local v5, "h":F
    .local v6, "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .local v13, "s":F
    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    move v13, v4

    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .end local v12    # "c":F
    .end local v17    # "a":D
    .local v13, "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    add-int/lit8 v11, v11, 0x1

    goto :goto_99

    :cond_d5
    move v4, v13

    move v5, v14

    move-object v6, v15

    goto/16 :goto_3d7

    .line 24
    .end local v11    # "i":I
    :sswitch_da
    const-string v1, "today"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_e3

    goto :goto_6d

    .line 27
    :cond_e3
    mul-float v4, v13, v16

    move-object v8, v15

    check-cast v8, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    const/16 v11, 0x6c

    const/4 v12, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    const/high16 v9, 0x3f000000    # 0.5f

    const/high16 v10, 0x3f000000    # 0.5f

    const/high16 v7, 0x3f000000    # 0.5f

    const v8, 0x3e99999a    # 0.3f

    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f28f5c3    # 0.66f

    const v10, 0x3f147ae1    # 0.58f

    const/high16 v8, 0x3f000000    # 0.5f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_113
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "stats"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_120

    goto/16 :goto_30f

    .line 29
    :cond_120
    const v9, 0x3e4ccccd    # 0.2f

    const v10, 0x3f051eb8    # 0.52f

    const v7, 0x3e4ccccd    # 0.2f

    const v8, 0x3f51eb85    # 0.82f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const/high16 v9, 0x3f000000    # 0.5f

    const v10, 0x3e4ccccd    # 0.2f

    const/high16 v7, 0x3f000000    # 0.5f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3ecccccd    # 0.4f

    const v7, 0x3f4ccccd    # 0.8f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .local v16, "w":F
    .local v18, "h":F
    .local v19, "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    goto/16 :goto_3d7

    .line 24
    .end local v16    # "w":F
    .end local v18    # "h":F
    .end local v19    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_14b
    move/from16 v16, v13

    move/from16 v18, v14

    move-object/from16 v19, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v16    # "w":F
    .restart local v18    # "h":F
    .restart local v19    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "decks"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_161

    move/from16 v13, v16

    move/from16 v14, v18

    move-object/from16 v15, v19

    goto/16 :goto_375

    .line 28
    :cond_161
    const v1, 0x3df5c28f    # 0.12f

    mul-float v13, v16, v1

    .local v13, "x\\8":F
    mul-float v14, v18, v3

    .local v14, "y\\8":F
    const/4 v1, 0x0

    .line 272
    .local v1, "$i$f$Offset\\8\\28":I
    const/4 v2, 0x0

    .line 273
    .local v2, "$i$f$packFloats\\9\\272":I
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v3, v3

    .line 274
    .local v3, "v1\\9":J
    invoke-static {v14}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v5

    int-to-long v5, v5

    .line 275
    .local v5, "v2\\9":J
    shl-long v11, v3, v8

    and-long v20, v5, v9

    or-long v2, v11, v20

    .line 272
    .end local v2    # "$i$f$packFloats\\9\\272":I
    .end local v3    # "v1\\9":J
    .end local v5    # "v2\\9":J
    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v4

    .line 28
    .end local v1    # "$i$f$Offset\\8\\28":I
    .end local v13    # "x\\8":F
    .end local v14    # "y\\8":F
    const v1, 0x3f266666    # 0.65f

    mul-float v13, v16, v1

    .local v13, "width\\10":F
    mul-float v14, v18, v1

    .local v14, "height\\10":F
    const/4 v1, 0x0

    .line 276
    .local v1, "$i$f$Size\\10\\28":I
    const/4 v2, 0x0

    .line 273
    .local v2, "$i$f$packFloats\\11\\276":I
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v6, v3

    .line 274
    .local v6, "v1\\11":J
    invoke-static {v14}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v3

    int-to-long v11, v3

    .line 275
    .local v11, "v2\\11":J
    shl-long v20, v6, v8

    and-long v22, v11, v9

    or-long v2, v20, v22

    .line 276
    .end local v2    # "$i$f$packFloats\\11\\276":I
    .end local v6    # "v1\\11":J
    .end local v11    # "v2\\11":J
    invoke-static {v2, v3}, Landroidx/compose/ui/geometry/Size;->constructor-impl(J)J

    move-result-wide v6

    .line 28
    .end local v1    # "$i$f$Size\\10\\28":I
    .end local v13    # "width\\10":F
    .end local v14    # "height\\10":F
    mul-float v13, v16, v17

    .line 277
    .local v13, "x\\12":F
    move v1, v13

    .local v1, "y\\12":F
    const/4 v2, 0x0

    .local v2, "$i$f$CornerRadius\\12\\28":I
    const/4 v3, 0x0

    .line 273
    .local v3, "$i$f$packFloats\\13\\277":I
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v11

    int-to-long v11, v11

    .line 274
    .local v11, "v1\\13":J
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v14

    int-to-long v14, v14

    .line 275
    .local v14, "v2\\13":J
    shl-long v20, v11, v8

    and-long v8, v14, v9

    or-long v8, v20, v8

    .line 277
    .end local v3    # "$i$f$packFloats\\13\\277":I
    .end local v11    # "v1\\13":J
    .end local v14    # "v2\\13":J
    invoke-static {v8, v9}, Landroidx/compose/ui/geometry/CornerRadius;->constructor-impl(J)J

    move-result-wide v8

    .line 28
    .end local v1    # "y\\12":F
    .end local v2    # "$i$f$CornerRadius\\12\\28":I
    .end local v13    # "x\\12":F
    move-object/from16 v10, v19

    check-cast v10, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    const/16 v14, 0xe0

    const/4 v15, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v15}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/DrawStyle;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    const v9, 0x3f59999a    # 0.85f

    const v10, 0x3df5c28f    # 0.12f

    const v7, 0x3e99999a    # 0.3f

    const v8, 0x3df5c28f    # 0.12f

    move/from16 v4, v16

    move/from16 v5, v18

    move-object/from16 v6, v19

    .end local v16    # "w":F
    .end local v18    # "h":F
    .end local v19    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .local v5, "h":F
    .local v6, "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f6147ae    # 0.88f

    const v10, 0x3f266666    # 0.65f

    const v7, 0x3f6147ae    # 0.88f

    const v8, 0x3e19999a    # 0.15f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .local v13, "w":F
    .local v14, "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_1eb
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "check"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_1f8

    goto/16 :goto_30f

    .line 33
    :cond_1f8
    const v9, 0x3ed70a3d    # 0.42f

    const v10, 0x3f3851ec    # 0.72f

    const v7, 0x3e4ccccd    # 0.2f

    const/high16 v8, 0x3f000000    # 0.5f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3e8f5c29    # 0.28f

    const v7, 0x3ed70a3d    # 0.42f

    const v8, 0x3f3851ec    # 0.72f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_21b
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "arrow"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_228

    goto/16 :goto_30f

    .line 34
    :cond_228
    const v9, 0x3f59999a    # 0.85f

    const/high16 v10, 0x3f000000    # 0.5f

    const v7, 0x3e19999a    # 0.15f

    const/high16 v8, 0x3f000000    # 0.5f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v7, 0x3f19999a    # 0.6f

    const/high16 v8, 0x3e800000    # 0.25f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f19999a    # 0.6f

    const/high16 v10, 0x3f400000    # 0.75f

    const v7, 0x3f59999a    # 0.85f

    const/high16 v8, 0x3f000000    # 0.5f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_250
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "edit"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_25d

    goto/16 :goto_30f

    .line 31
    :cond_25d
    const v9, 0x3f333333    # 0.7f

    const/high16 v10, 0x3e800000    # 0.25f

    const/high16 v7, 0x3e800000    # 0.25f

    const v8, 0x3f333333    # 0.7f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3eb33333    # 0.35f

    const v7, 0x3f333333    # 0.7f

    const/high16 v8, 0x3e800000    # 0.25f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3eb33333    # 0.35f

    const v10, 0x3f4ccccd    # 0.8f

    const v7, 0x3f4ccccd    # 0.8f

    const v8, 0x3eb33333    # 0.35f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3e4ccccd    # 0.2f

    const v10, 0x3f547ae1    # 0.83f

    const v7, 0x3eb33333    # 0.35f

    const v8, 0x3f4ccccd    # 0.8f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const/high16 v9, 0x3e800000    # 0.25f

    const v10, 0x3f333333    # 0.7f

    const v7, 0x3e4ccccd    # 0.2f

    const v8, 0x3f547ae1    # 0.83f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_2aa
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "back"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2b6

    goto :goto_30f

    .line 25
    :cond_2b6
    const v9, 0x3eb33333    # 0.35f

    const/high16 v10, 0x3f000000    # 0.5f

    const v7, 0x3f333333    # 0.7f

    const v8, 0x3e4ccccd    # 0.2f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f333333    # 0.7f

    const v10, 0x3f4ccccd    # 0.8f

    const v7, 0x3eb33333    # 0.35f

    const/high16 v8, 0x3f000000    # 0.5f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_2d8
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "add"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_2e4

    goto :goto_30f

    .line 26
    :cond_2e4
    const/high16 v9, 0x3f000000    # 0.5f

    const v10, 0x3f51eb85    # 0.82f

    const/high16 v7, 0x3f000000    # 0.5f

    const v8, 0x3e3851ec    # 0.18f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f51eb85    # 0.82f

    const/high16 v10, 0x3f000000    # 0.5f

    const v7, 0x3e3851ec    # 0.18f

    const/high16 v8, 0x3f000000    # 0.5f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    goto/16 :goto_3d7

    .line 24
    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    :sswitch_304
    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v4    # "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    const-string v1, "delete"

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_313

    :goto_30f
    move v13, v4

    move v14, v5

    move-object v15, v6

    goto :goto_375

    .line 32
    :cond_313
    const v9, 0x3f4ccccd    # 0.8f

    const v10, 0x3e99999a    # 0.3f

    const v7, 0x3e4ccccd    # 0.2f

    const v8, 0x3e99999a    # 0.3f

    move-wide/from16 v2, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f266666    # 0.65f

    const v10, 0x3e19999a    # 0.15f

    const v7, 0x3eb33333    # 0.35f

    const v8, 0x3e19999a    # 0.15f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3ea8f5c3    # 0.33f

    const v10, 0x3f59999a    # 0.85f

    const v7, 0x3e8f5c29    # 0.28f

    const v8, 0x3e99999a    # 0.3f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f2b851f    # 0.67f

    const v7, 0x3ea8f5c3    # 0.33f

    const v8, 0x3f59999a    # 0.85f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f3851ec    # 0.72f

    const v10, 0x3e99999a    # 0.3f

    const v7, 0x3f2b851f    # 0.67f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3edc28f6    # 0.43f

    const v10, 0x3f333333    # 0.7f

    const v7, 0x3edc28f6    # 0.43f

    const v8, 0x3ee66666    # 0.45f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    const v9, 0x3f11eb85    # 0.57f

    const v7, 0x3f11eb85    # 0.57f

    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    .end local v4    # "w":F
    .end local v5    # "h":F
    .end local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .restart local v13    # "w":F
    .restart local v14    # "h":F
    .restart local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    goto :goto_3d7

    .line 35
    :goto_375
    invoke-static {}, Landroidx/compose/ui/graphics/AndroidPath_androidKt;->Path()Landroidx/compose/ui/graphics/Path;

    move-result-object v2

    move-object v4, v2

    .line 278
    .local v4, "$this$Glyph_FNF3uiM_u24lambda_u240_u240_u240\\14":Landroidx/compose/ui/graphics/Path;
    const/4 v1, 0x0

    .line 35
    .local v1, "$i$a$-apply-XunjiComponentsKt$Glyph$1$1$p$1\\14\\35\\0":I
    mul-float v5, v13, v3

    const v11, 0x3f4ccccd    # 0.8f

    mul-float v6, v14, v11

    invoke-interface {v4, v5, v6}, Landroidx/compose/ui/graphics/Path;->moveTo(FF)V

    mul-float v5, v13, v17

    const/high16 v6, 0x3e800000    # 0.25f

    mul-float/2addr v6, v14

    mul-float v7, v13, v11

    const v8, 0x3e3851ec    # 0.18f

    mul-float/2addr v8, v14

    const v9, 0x3f51eb85    # 0.82f

    mul-float/2addr v9, v13

    const v10, 0x3e23d70a    # 0.16f

    mul-float/2addr v10, v14

    invoke-interface/range {v4 .. v10}, Landroidx/compose/ui/graphics/Path;->cubicTo(FFFFFF)V

    const v5, 0x3f5c28f6    # 0.86f

    mul-float/2addr v5, v13

    const v6, 0x3f333333    # 0.7f

    mul-float/2addr v6, v14

    const v7, 0x3ee147ae    # 0.44f

    mul-float/2addr v7, v13

    const v8, 0x3f59999a    # 0.85f

    mul-float/2addr v8, v14

    mul-float v9, v13, v3

    mul-float v10, v14, v11

    invoke-interface/range {v4 .. v10}, Landroidx/compose/ui/graphics/Path;->cubicTo(FFFFFF)V

    .end local v1    # "$i$a$-apply-XunjiComponentsKt$Glyph$1$1$p$1\\14\\35\\0":I
    .end local v4    # "$this$Glyph_FNF3uiM_u24lambda_u240_u240_u240\\14":Landroidx/compose/ui/graphics/Path;
    .local v2, "p":Landroidx/compose/ui/graphics/Path;
    move-object v6, v15

    check-cast v6, Landroidx/compose/ui/graphics/drawscope/DrawStyle;

    const/16 v9, 0x34

    const/4 v10, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    move-wide/from16 v3, p1

    move-object/from16 v1, p3

    invoke-static/range {v1 .. v10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawPath-LG529CI$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Path;JFLandroidx/compose/ui/graphics/drawscope/DrawStyle;Landroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    move-object v11, v2

    .end local v2    # "p":Landroidx/compose/ui/graphics/Path;
    .local v11, "p":Landroidx/compose/ui/graphics/Path;
    const v9, 0x3f2b851f    # 0.67f

    const v10, 0x3ec28f5c    # 0.38f

    const v7, 0x3e75c28f    # 0.24f

    const v8, 0x3f4ccccd    # 0.8f

    move-wide/from16 v2, p1

    move v4, v13

    move v5, v14

    move-object v6, v15

    .end local v13    # "w":F
    .end local v14    # "h":F
    .end local v15    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    .local v4, "w":F
    .restart local v5    # "h":F
    .restart local v6    # "stroke":Landroidx/compose/ui/graphics/drawscope/Stroke;
    invoke-static/range {v1 .. v10}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V

    .line 37
    .end local v11    # "p":Landroidx/compose/ui/graphics/Path;
    :goto_3d7
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v1

    :sswitch_data_3da
    .sparse-switch
        -0x4f997a55 -> :sswitch_304
        0x178a1 -> :sswitch_2d8
        0x2e04e7 -> :sswitch_2aa
        0x2f6e0a -> :sswitch_250
        0x58c7409 -> :sswitch_21b
        0x5a3e508 -> :sswitch_1eb
        0x5b098ea -> :sswitch_14b
        0x68ac49f -> :sswitch_113
        0x6969f41 -> :sswitch_da
        0x5582bc23 -> :sswitch_6f
    .end sparse-switch
.end method

.method private static final Glyph_FNF3uiM$lambda$0$0$line(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFFLandroidx/compose/ui/graphics/drawscope/Stroke;FFFF)V
    .registers 38
    .param p0, "$this_Canvas"    # Landroidx/compose/ui/graphics/drawscope/DrawScope;
    .param p1, "$$v$c$androidx-compose-ui-graphics-Color$-color$0"    # J
    .param p3, "w"    # F
    .param p4, "h"    # F
    .param p5, "stroke"    # Landroidx/compose/ui/graphics/drawscope/Stroke;
    .param p6, "x1"    # F
    .param p7, "y1"    # F
    .param p8, "x2"    # F
    .param p9, "y2"    # F

    .line 23
    mul-float v0, p6, p3

    .local v0, "x\\1":F
    mul-float v1, p7, p4

    .local v1, "y\\1":F
    const/4 v2, 0x0

    .line 279
    .local v2, "$i$f$Offset\\1\\23":I
    const/4 v3, 0x0

    .line 280
    .local v3, "$i$f$packFloats\\2\\279":I
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v4

    int-to-long v4, v4

    .line 281
    .local v4, "v1\\2":J
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v6

    int-to-long v6, v6

    .line 282
    .local v6, "v2\\2":J
    const/16 v8, 0x20

    shl-long v9, v4, v8

    const-wide v11, 0xffffffffL

    and-long v13, v6, v11

    or-long v3, v9, v13

    .line 279
    .end local v3    # "$i$f$packFloats\\2\\279":I
    .end local v4    # "v1\\2":J
    .end local v6    # "v2\\2":J
    invoke-static {v3, v4}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v16

    .line 23
    .end local v0    # "x\\1":F
    .end local v1    # "y\\1":F
    .end local v2    # "$i$f$Offset\\1\\23":I
    mul-float v0, p8, p3

    .local v0, "x\\3":F
    mul-float v1, p9, p4

    .local v1, "y\\3":F
    const/4 v2, 0x0

    .line 279
    .local v2, "$i$f$Offset\\3\\23":I
    const/4 v3, 0x0

    .line 280
    .local v3, "$i$f$packFloats\\4\\279":I
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v4

    int-to-long v4, v4

    .line 281
    .local v4, "v1\\4":J
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    move-result v6

    int-to-long v6, v6

    .line 282
    .local v6, "v2\\4":J
    shl-long v8, v4, v8

    and-long v10, v6, v11

    or-long v3, v8, v10

    .line 279
    .end local v3    # "$i$f$packFloats\\4\\279":I
    .end local v4    # "v1\\4":J
    .end local v6    # "v2\\4":J
    invoke-static {v3, v4}, Landroidx/compose/ui/geometry/Offset;->constructor-impl(J)J

    move-result-wide v18

    .line 23
    .end local v0    # "x\\3":F
    .end local v1    # "y\\3":F
    .end local v2    # "$i$f$Offset\\3\\23":I
    invoke-virtual/range {p5 .. p5}, Landroidx/compose/ui/graphics/drawscope/Stroke;->getWidth()F

    move-result v20

    sget-object v0, Landroidx/compose/ui/graphics/StrokeCap;->Companion:Landroidx/compose/ui/graphics/StrokeCap$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/graphics/StrokeCap$Companion;->getRound-KaPHkGw()I

    move-result v21

    const/16 v26, 0x1e0

    const/16 v27, 0x0

    const/16 v22, 0x0

    const/16 v23, 0x0

    const/16 v24, 0x0

    const/16 v25, 0x0

    move-object/from16 v13, p0

    move-wide/from16 v14, p1

    invoke-static/range {v13 .. v27}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawLine-NGM6Ib0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFILandroidx/compose/ui/graphics/PathEffect;FLandroidx/compose/ui/graphics/ColorFilter;IILjava/lang/Object;)V

    return-void
.end method

.method private static final Glyph_FNF3uiM$lambda$1(Ljava/lang/String;Landroidx/compose/ui/Modifier;JIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 16

    or-int/lit8 v0, p4, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v6

    move-object v1, p0

    move-object v2, p1

    move-wide v3, p2

    move v7, p5

    move-object v5, p6

    invoke-static/range {v1 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .registers 31
    .param p0, "kind"    # Ljava/lang/String;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p3, "tag"    # Ljava/lang/String;
    .param p4, "enabled"    # Z
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Ljava/lang/String;",
            "Z",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move/from16 v0, p6

    const-string v4, "kind"

    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "label"

    invoke-static {v2, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v4, "onClick"

    invoke-static {v3, v4}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 39
    const v4, -0x1a9b283e

    move-object/from16 v5, p5

    invoke-interface {v5, v4}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v10

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v10, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(IconAction)N(kind,label,onClick,tag,enabled)39@2699L28,39@2729L107,39@2576L260:XunjiComponents.kt#8ao140"

    invoke-static {v10, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p6

    .local v5, "$dirty":I
    and-int/lit8 v6, v0, 0x6

    if-nez v6, :cond_35

    invoke-interface {v10, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_33

    const/4 v6, 0x4

    goto :goto_34

    :cond_33
    const/4 v6, 0x2

    :goto_34
    or-int/2addr v5, v6

    :cond_35
    and-int/lit8 v6, v0, 0x30

    const/16 v7, 0x20

    if-nez v6, :cond_46

    invoke-interface {v10, v2}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_43

    move v6, v7

    goto :goto_45

    :cond_43
    const/16 v6, 0x10

    :goto_45
    or-int/2addr v5, v6

    :cond_46
    and-int/lit16 v6, v0, 0x180

    if-nez v6, :cond_56

    invoke-interface {v10, v3}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_53

    const/16 v6, 0x100

    goto :goto_55

    :cond_53
    const/16 v6, 0x80

    :goto_55
    or-int/2addr v5, v6

    :cond_56
    and-int/lit8 v6, p7, 0x8

    if-eqz v6, :cond_5f

    or-int/lit16 v5, v5, 0xc00

    move-object/from16 v8, p3

    goto :goto_74

    :cond_5f
    and-int/lit16 v8, v0, 0xc00

    if-nez v8, :cond_72

    move-object/from16 v8, p3

    invoke-interface {v10, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_6e

    const/16 v9, 0x800

    goto :goto_70

    :cond_6e
    const/16 v9, 0x400

    :goto_70
    or-int/2addr v5, v9

    goto :goto_74

    :cond_72
    move-object/from16 v8, p3

    :goto_74
    and-int/lit8 v9, p7, 0x10

    if-eqz v9, :cond_7d

    or-int/lit16 v5, v5, 0x6000

    move/from16 v11, p4

    goto :goto_92

    :cond_7d
    and-int/lit16 v11, v0, 0x6000

    if-nez v11, :cond_90

    move/from16 v11, p4

    invoke-interface {v10, v11}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v12

    if-eqz v12, :cond_8c

    const/16 v12, 0x4000

    goto :goto_8e

    :cond_8c
    const/16 v12, 0x2000

    :goto_8e
    or-int/2addr v5, v12

    goto :goto_92

    :cond_90
    move/from16 v11, p4

    :goto_92
    move v13, v5

    .end local v5    # "$dirty":I
    .local v13, "$dirty":I
    and-int/lit16 v5, v13, 0x2493

    const/16 v12, 0x2492

    if-eq v5, v12, :cond_9b

    const/4 v5, 0x1

    goto :goto_9c

    :cond_9b
    const/4 v5, 0x0

    :goto_9c
    and-int/lit8 v12, v13, 0x1

    invoke-interface {v10, v5, v12}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v5

    if-eqz v5, :cond_14e

    if-eqz v6, :cond_a9

    const-string v5, ""

    .end local p3    # "tag":Ljava/lang/String;
    .local v5, "tag":Ljava/lang/String;
    goto :goto_aa

    .end local v5    # "tag":Ljava/lang/String;
    .restart local p3    # "tag":Ljava/lang/String;
    :cond_a9
    move-object v5, v8

    .end local p3    # "tag":Ljava/lang/String;
    .restart local v5    # "tag":Ljava/lang/String;
    :goto_aa
    if-eqz v9, :cond_ae

    const/4 v6, 0x1

    move v11, v6

    .end local p4    # "enabled":Z
    .local v11, "enabled":Z
    :cond_ae
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_ba

    const/4 v6, -0x1

    const-string v8, "com.xunji.flashcards.ui.components.IconAction (XunjiComponents.kt:38)"

    invoke-static {v4, v13, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_ba
    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v16, v4

    check-cast v16, Landroidx/compose/ui/Modifier;

    const/16 v4, 0x30

    .local v4, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 79
    .local v6, "$i$f$getDp\\1\\40":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v17

    .line 40
    .end local v4    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\40":I
    const/16 v4, 0x30

    .local v4, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 79
    .local v6, "$i$f$getDp\\2\\40":I
    int-to-float v8, v4

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v18

    .line 40
    .end local v4    # "$this$dp\\2":I
    .end local v6    # "$i$f$getDp\\2\\40":I
    const/16 v21, 0xc

    const/16 v22, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    invoke-static/range {v16 .. v22}, Landroidx/compose/foundation/layout/SizeKt;->sizeIn-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    const v6, 0x1f8e0abe

    const-string v8, "CC(remember):XunjiComponents.kt#9igjgp"

    invoke-static {v10, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    and-int/lit8 v6, v13, 0x70

    if-ne v6, v7, :cond_ee

    const/4 v6, 0x1

    goto :goto_ef

    :cond_ee
    const/4 v6, 0x0

    .local v6, "invalid\\3":Z
    :goto_ef
    move-object v7, v10

    .local v7, "$this$cache\\3":Landroidx/compose/runtime/Composer;
    const/4 v8, 0x0

    .line 80
    .local v8, "$i$f$cache\\3\\40":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    .local v9, "it\\3":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 81
    .local v12, "$i$a$-let-ComposerKt$cache$1\\4\\80\\3":I
    if-nez v6, :cond_102

    sget-object v16, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v14

    if-ne v9, v14, :cond_101

    goto :goto_102

    .line 85
    :cond_101
    goto :goto_10d

    .line 82
    :cond_102
    :goto_102
    const/4 v14, 0x0

    .line 40
    .local v14, "$i$a$-cache-XunjiComponentsKt$IconAction$1\\5\\82\\0":I
    new-instance v15, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda11;

    invoke-direct {v15, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda11;-><init>(Ljava/lang/String;)V

    .line 82
    .end local v14    # "$i$a$-cache-XunjiComponentsKt$IconAction$1\\5\\82\\0":I
    nop

    .line 83
    .local v15, "value\\4":Ljava/lang/Object;
    invoke-interface {v7, v15}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 84
    move-object v9, v15

    .line 80
    .end local v9    # "it\\3":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\4\\80\\3":I
    .end local v15    # "value\\4":Ljava/lang/Object;
    :goto_10d
    nop

    .line 40
    .end local v6    # "invalid\\3":Z
    .end local v7    # "$this$cache\\3":Landroidx/compose/runtime/Composer;
    .end local v8    # "$i$f$cache\\3\\40":I
    check-cast v9, Lkotlin/jvm/functions/Function1;

    invoke-static {v10}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v4, v7, v9, v8, v6}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v4

    new-instance v6, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda12;

    invoke-direct {v6, v1, v11}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda12;-><init>(Ljava/lang/String;Z)V

    const/16 v7, 0x36

    const v9, 0x7a2d8fe0

    invoke-static {v9, v8, v6, v10, v7}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v6

    move-object v9, v6

    check-cast v9, Lkotlin/jvm/functions/Function2;

    shr-int/lit8 v6, v13, 0x6

    and-int/lit8 v6, v6, 0xe

    const/high16 v7, 0x180000

    or-int/2addr v6, v7

    shr-int/lit8 v7, v13, 0x6

    and-int/lit16 v7, v7, 0x380

    or-int/2addr v6, v7

    const/16 v12, 0x38

    move-object v8, v5

    move v5, v11

    move v11, v6

    .end local v11    # "enabled":Z
    .local v5, "enabled":Z
    .local v8, "tag":Ljava/lang/String;
    const/4 v6, 0x0

    const/4 v7, 0x0

    move-object v14, v8

    .end local v8    # "tag":Ljava/lang/String;
    .local v14, "tag":Ljava/lang/String;
    const/4 v8, 0x0

    invoke-static/range {v3 .. v12}, Landroidx/compose/material3/IconButtonKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/foundation/interaction/MutableInteractionSource;Landroidx/compose/ui/graphics/Shape;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v3

    if-eqz v3, :cond_14c

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 41
    :cond_14c
    move-object v4, v14

    goto :goto_153

    .line 39
    .end local v5    # "enabled":Z
    .end local v14    # "tag":Ljava/lang/String;
    .restart local p3    # "tag":Ljava/lang/String;
    .restart local p4    # "enabled":Z
    :cond_14e
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v4, v8

    move v5, v11

    .line 41
    .end local p3    # "tag":Ljava/lang/String;
    .end local p4    # "enabled":Z
    .local v4, "tag":Ljava/lang/String;
    .restart local v5    # "enabled":Z
    :goto_153
    invoke-interface {v10}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_167

    new-instance v0, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda13;

    move-object/from16 v3, p2

    move/from16 v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda13;-><init>(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZII)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_167
    return-void
.end method

.method private static final IconAction$lambda$0$0(Ljava/lang/String;Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 3
    .param p0, "$label"    # Ljava/lang/String;
    .param p1, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p1, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 40
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final IconAction$lambda$1(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 13
    .param p0, "$kind"    # Ljava/lang/String;
    .param p1, "$enabled"    # Z
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    const-string v0, "C39@2731L103:XunjiComponents.kt#8ao140"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v0, p3, 0x3

    const/4 v1, 0x2

    if-eq v0, v1, :cond_c

    const/4 v0, 0x1

    goto :goto_d

    :cond_c
    const/4 v0, 0x0

    :goto_d
    and-int/lit8 v1, p3, 0x1

    invoke-interface {p2, v0, v1}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v0

    if-eqz v0, :cond_6b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_24

    const/4 v0, -0x1

    const-string v1, "com.xunji.flashcards.ui.components.IconAction.<anonymous> (XunjiComponents.kt:39)"

    const v2, 0x7a2d8fe0

    invoke-static {v2, p3, v0, v1}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 40
    :cond_24
    if-eqz p1, :cond_3e

    const v0, -0x5af6e117

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "39@2773L11"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, p2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOnSurface-0d7_KjU()J

    move-result-wide v0

    goto :goto_55

    :cond_3e
    const v0, -0x5af6dbf9

    invoke-interface {p2, v0}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v0, "39@2814L11"

    invoke-static {p2, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v0, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v1, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v0, p2, v1}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/compose/material3/ColorScheme;->getOutline-0d7_KjU()J

    move-result-wide v0

    :goto_55
    invoke-interface {p2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    move-wide v4, v0

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v3, 0x0

    move-object v2, p0

    move-object v6, p2

    .end local p0    # "$kind":Ljava/lang/String;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$kind":Ljava/lang/String;
    .local v6, "$composer":Landroidx/compose/runtime/Composer;
    invoke-static/range {v2 .. v8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result p0

    if-eqz p0, :cond_70

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_70

    .end local v2    # "$kind":Ljava/lang/String;
    .end local v6    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local p0    # "$kind":Ljava/lang/String;
    .restart local p2    # "$composer":Landroidx/compose/runtime/Composer;
    :cond_6b
    move-object v2, p0

    move-object v6, p2

    .end local p0    # "$kind":Ljava/lang/String;
    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v2    # "$kind":Ljava/lang/String;
    .restart local v6    # "$composer":Landroidx/compose/runtime/Composer;
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_70
    :goto_70
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method private static final IconAction$lambda$2(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move-object v4, p3

    move v5, p4

    move v8, p6

    move-object/from16 v6, p7

    invoke-static/range {v1 .. v8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->IconAction(Ljava/lang/String;Ljava/lang/String;Lkotlin/jvm/functions/Function0;Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final Mark(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
    .registers 39
    .param p0, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    .line 42
    move/from16 v0, p2

    move/from16 v1, p3

    const v2, 0x4f297e5a    # 2.84363E9f

    move-object/from16 v3, p1

    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v3

    .end local p1    # "$composer":Landroidx/compose/runtime/Composer;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Mark)N(modifier)42@2973L11,42@2891L197:XunjiComponents.kt#8ao140"

    invoke-static {v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p2

    .local v4, "$dirty":I
    and-int/lit8 v5, v1, 0x1

    const/4 v6, 0x2

    if-eqz v5, :cond_1e

    or-int/lit8 v4, v4, 0x6

    move-object/from16 v7, p0

    goto :goto_31

    :cond_1e
    and-int/lit8 v7, v0, 0x6

    if-nez v7, :cond_2f

    move-object/from16 v7, p0

    invoke-interface {v3, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_2c

    const/4 v8, 0x4

    goto :goto_2d

    :cond_2c
    move v8, v6

    :goto_2d
    or-int/2addr v4, v8

    goto :goto_31

    :cond_2f
    move-object/from16 v7, p0

    :goto_31
    and-int/lit8 v8, v4, 0x3

    if-eq v8, v6, :cond_37

    const/4 v6, 0x1

    goto :goto_38

    :cond_37
    const/4 v6, 0x0

    :goto_38
    and-int/lit8 v8, v4, 0x1

    invoke-interface {v3, v6, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_1c6

    if-eqz v5, :cond_47

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v5, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_48

    .end local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p0    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_47
    move-object v5, v7

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v5    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_48
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_54

    const/4 v6, -0x1

    const-string v7, "com.xunji.flashcards.ui.components.Mark (XunjiComponents.kt:41)"

    invoke-static {v2, v4, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 43
    :cond_54
    const/16 v2, 0x28

    .local v2, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 86
    .local v6, "$i$f$getDp\\1\\43":I
    int-to-float v7, v2

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v2

    .line 43
    .end local v2    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\43":I
    invoke-static {v5, v2}, Landroidx/compose/foundation/layout/SizeKt;->size-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    const/16 v6, 0xe

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 86
    .local v7, "$i$f$getDp\\2\\43":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 43
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\43":I
    invoke-static {v6}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v6

    check-cast v6, Landroidx/compose/ui/graphics/Shape;

    invoke-static {v2, v6}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    move-result-object v10

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v6, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v3, v6}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getPrimary-0d7_KjU()J

    move-result-wide v11

    const/4 v14, 0x2

    const/4 v15, 0x0

    const/4 v13, 0x0

    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/BackgroundKt;->background-bw27NRU$default(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getCenter()Landroidx/compose/ui/Alignment;

    move-result-object v6

    .local v6, "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    const/16 v7, 0x30

    .local v7, "$changed\\3":I
    move-object v8, v3

    .local v8, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 87
    .local v10, "$i$f$Box\\3\\43":I
    const v11, 0x3e277f0a

    const-string v12, "CC(Box)N(modifier,contentAlignment,propagateMinConstraints,content)71@3424L131:Box.kt#2w3rfo"

    invoke-static {v8, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 88
    const/4 v11, 0x0

    .line 91
    .local v11, "propagateMinConstraints\\3":Z
    invoke-static {v6, v11}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/Alignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v12

    .line 95
    .local v12, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v13, v7, 0x3

    and-int/lit8 v13, v13, 0x70

    .line 92
    move-object v14, v2

    .local v13, "$changed\\4":I
    .local v14, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v15, 0x0

    .line 96
    .local v15, "$i$f$Layout\\4\\92":I
    const v9, -0x451e1427

    move-object/from16 p0, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local p0, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-string v2, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v8, v9, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 97
    const/4 v2, 0x0

    invoke-static {v8, v2}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v16

    invoke-static/range {v16 .. v17}, Ljava/lang/Long;->hashCode(J)I

    move-result v2

    .line 98
    .local v2, "compositeKeyHash\\4":I
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v9

    .line 99
    .local v9, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    move/from16 p1, v2

    .end local v2    # "compositeKeyHash\\4":I
    .local p1, "compositeKeyHash\\4":I
    invoke-static {v8, v14}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v2

    .line 101
    .local v2, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v16

    move-object/from16 v17, v3

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v17, "$composer":Landroidx/compose/runtime/Composer;
    shl-int/lit8 v3, v13, 0x6

    and-int/lit16 v3, v3, 0x380

    or-int/lit8 v3, v3, 0x6

    .line 100
    nop

    .local v3, "$changed\\5":I
    move-object/from16 v18, v16

    .local v18, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 102
    .local v16, "$i$f$ReusableComposeNode\\5\\100":I
    move/from16 v19, v3

    .end local v3    # "$changed\\5":I
    .local v19, "$changed\\5":I
    const v3, -0x20f7d59c

    move/from16 v20, v4

    .end local v4    # "$dirty":I
    .local v20, "$dirty":I
    const-string v4, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v8, v3, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 103
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v3

    instance-of v3, v3, Landroidx/compose/runtime/Applier;

    if-nez v3, :cond_e9

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 104
    :cond_e9
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 105
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v3

    if-eqz v3, :cond_f8

    .line 106
    move-object/from16 v3, v18

    .end local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v3, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8, v3}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_fd

    .line 108
    .end local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    :cond_f8
    move-object/from16 v3, v18

    .end local v18    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .restart local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 110
    :goto_fd
    invoke-static {v8}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .local v4, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 111
    .local v18, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\110\\4":I
    sget-object v21, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move-object/from16 v22, v3

    .end local v3    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .local v22, "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v12, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 112
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v9, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 113
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    .local v3, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v21, 0x0

    .line 114
    .local v21, "$i$f$set-impl\\7\\113":I
    move-object/from16 v23, v4

    .local v23, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v24, 0x0

    .line 115
    .local v24, "$i$a$-with-Updater$set$1\\8\\114\\7":I
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v25

    if-nez v25, :cond_13f

    move-object/from16 v25, v5

    .end local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .local v25, "modifier":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v23 .. v23}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v5

    move-object/from16 v26, v6

    .end local v6    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .local v26, "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_13c

    goto :goto_143

    :cond_13c
    move-object/from16 v6, v23

    goto :goto_153

    .end local v25    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v26    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .restart local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v6    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    :cond_13f
    move-object/from16 v25, v5

    move-object/from16 v26, v6

    .line 116
    .end local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v6    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .restart local v25    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v26    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    :goto_143
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    move-object/from16 v6, v23

    .end local v23    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v6, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v6, v5}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 117
    invoke-static/range {p1 .. p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-interface {v4, v5, v3}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 119
    :goto_153
    nop

    .line 114
    .end local v6    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v24    # "$i$a$-with-Updater$set$1\\8\\114\\7":I
    nop

    .line 119
    nop

    .line 120
    .end local v3    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v21    # "$i$f$set-impl\\7\\113":I
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v3}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v3

    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 121
    nop

    .line 110
    .end local v4    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\110\\4":I
    nop

    .line 122
    shr-int/lit8 v3, v19, 0x6

    and-int/lit8 v3, v3, 0xe

    .local v3, "$changed\\9":I
    move-object v4, v8

    .local v4, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v5, 0x0

    .line 93
    .local v5, "$i$a$-Layout-BoxKt$Box$1\\9\\122\\3":I
    const v6, 0x6d423196

    move-object/from16 v18, v2

    .end local v2    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .local v18, "materialized\\4":Landroidx/compose/ui/Modifier;
    const-string v2, "C72@3469L9:Box.kt#2w3rfo"

    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    shr-int/lit8 v6, v7, 0x6

    and-int/lit8 v6, v6, 0x70

    or-int/lit8 v6, v6, 0x6

    .local v6, "$changed\\10":I
    check-cast v2, Landroidx/compose/foundation/layout/BoxScope;

    .local v2, "$this$Mark_u24lambda_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    move-object/from16 v31, v4

    .local v31, "$composer\\10":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 43
    .local v21, "$i$a$-Box-XunjiComponentsKt$Mark$1\\10\\93\\0":I
    move-object/from16 v23, v2

    .end local v2    # "$this$Mark_u24lambda_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    .local v23, "$this$Mark_u24lambda_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    const v2, -0x55e7bf4

    move/from16 v24, v3

    .end local v3    # "$changed\\9":I
    .local v24, "$changed\\9":I
    const-string v3, "C42@3064L11,42@3031L55:XunjiComponents.kt#8ao140"

    move-object/from16 v34, v4

    .end local v31    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v4, "$composer\\10":Landroidx/compose/runtime/Composer;
    .local v34, "$composer\\9":Landroidx/compose/runtime/Composer;
    invoke-static {v4, v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v3, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v4, v3}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/ColorScheme;->getOnPrimary-0d7_KjU()J

    move-result-wide v29

    const/16 v32, 0x6

    const/16 v33, 0x2

    const-string v27, "leaf"

    const/16 v28, 0x0

    .end local v4    # "$composer\\10":Landroidx/compose/runtime/Composer;
    .restart local v31    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v27 .. v33}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Glyph-FNF3uiM(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/runtime/Composer;II)V

    invoke-static/range {v31 .. v31}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 93
    .end local v6    # "$changed\\10":I
    .end local v21    # "$i$a$-Box-XunjiComponentsKt$Mark$1\\10\\93\\0":I
    .end local v23    # "$this$Mark_u24lambda_u240\\10":Landroidx/compose/foundation/layout/BoxScope;
    .end local v31    # "$composer\\10":Landroidx/compose/runtime/Composer;
    invoke-static/range {v34 .. v34}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 122
    .end local v5    # "$i$a$-Layout-BoxKt$Box$1\\9\\122\\3":I
    .end local v24    # "$changed\\9":I
    .end local v34    # "$composer\\9":Landroidx/compose/runtime/Composer;
    nop

    .line 123
    invoke-interface {v8}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 102
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 124
    nop

    .line 96
    .end local v16    # "$i$f$ReusableComposeNode\\5\\100":I
    .end local v19    # "$changed\\5":I
    .end local v22    # "factory\\5":Lkotlin/jvm/functions/Function0;
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 125
    nop

    .line 87
    .end local v9    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v13    # "$changed\\4":I
    .end local v14    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v15    # "$i$f$Layout\\4\\92":I
    .end local v18    # "materialized\\4":Landroidx/compose/ui/Modifier;
    .end local p1    # "compositeKeyHash\\4":I
    invoke-static {v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 126
    nop

    .end local v7    # "$changed\\3":I
    .end local v8    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$Box\\3\\43":I
    .end local v11    # "propagateMinConstraints\\3":Z
    .end local v12    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v26    # "contentAlignment\\3":Landroidx/compose/ui/Alignment;
    .end local p0    # "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_1c3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 44
    :cond_1c3
    move-object/from16 v7, v25

    goto :goto_1cd

    .line 42
    .end local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v20    # "$dirty":I
    .end local v25    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$dirty":I
    .local p0, "modifier":Landroidx/compose/ui/Modifier;
    :cond_1c6
    move-object/from16 v17, v3

    move/from16 v20, v4

    .end local v3    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v4    # "$dirty":I
    .restart local v17    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v20    # "$dirty":I
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 44
    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v7, "modifier":Landroidx/compose/ui/Modifier;
    :goto_1cd
    invoke-interface/range {v17 .. v17}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v2

    if-eqz v2, :cond_1db

    new-instance v3, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda8;

    invoke-direct {v3, v7, v0, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda8;-><init>(Landroidx/compose/ui/Modifier;II)V

    invoke-interface {v2, v3}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_1db
    return-void
.end method

.method private static final Mark$lambda$1(Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 6

    or-int/lit8 v0, p1, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p3, v0, p2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Mark(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V
    .registers 57
    .param p0, "value"    # Ljava/lang/String;
    .param p1, "label"    # Ljava/lang/String;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p4, "$changed"    # I

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move/from16 v2, p4

    const-string v3, "value"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "label"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 64
    const v3, 0x4b625f7

    move-object/from16 v4, p3

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v4

    .end local p3    # "$composer":Landroidx/compose/runtime/Composer;
    .local v4, "$composer":Landroidx/compose/runtime/Composer;
    const-string v5, "C(Metric)N(value,label,modifier)63@5159L165:XunjiComponents.kt#8ao140"

    invoke-static {v4, v5}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v5, p4

    .local v5, "$dirty":I
    and-int/lit8 v6, v2, 0x6

    if-nez v6, :cond_2e

    invoke-interface {v4, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_2c

    const/4 v6, 0x4

    goto :goto_2d

    :cond_2c
    const/4 v6, 0x2

    :goto_2d
    or-int/2addr v5, v6

    :cond_2e
    and-int/lit8 v6, v2, 0x30

    if-nez v6, :cond_3e

    invoke-interface {v4, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v6

    if-eqz v6, :cond_3b

    const/16 v6, 0x20

    goto :goto_3d

    :cond_3b
    const/16 v6, 0x10

    :goto_3d
    or-int/2addr v5, v6

    :cond_3e
    and-int/lit8 v6, p5, 0x4

    if-eqz v6, :cond_47

    or-int/lit16 v5, v5, 0x180

    move-object/from16 v8, p2

    goto :goto_5c

    :cond_47
    and-int/lit16 v8, v2, 0x180

    if-nez v8, :cond_5a

    move-object/from16 v8, p2

    invoke-interface {v4, v8}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_56

    const/16 v9, 0x100

    goto :goto_58

    :cond_56
    const/16 v9, 0x80

    :goto_58
    or-int/2addr v5, v9

    goto :goto_5c

    :cond_5a
    move-object/from16 v8, p2

    :goto_5c
    and-int/lit16 v9, v5, 0x93

    const/16 v10, 0x92

    const/4 v11, 0x0

    if-eq v9, v10, :cond_65

    const/4 v9, 0x1

    goto :goto_66

    :cond_65
    move v9, v11

    :goto_66
    and-int/lit8 v10, v5, 0x1

    invoke-interface {v4, v9, v10}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v9

    if-eqz v9, :cond_21e

    if-eqz v6, :cond_77

    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v6, Landroidx/compose/ui/Modifier;

    move-object/from16 v26, v6

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v6, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_79

    .end local v6    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_77
    move-object/from16 v26, v8

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v26, "modifier":Landroidx/compose/ui/Modifier;
    :goto_79
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_85

    const/4 v6, -0x1

    const-string v8, "com.xunji.flashcards.ui.components.Metric (XunjiComponents.kt:63)"

    invoke-static {v3, v5, v6, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_85
    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v6, 0x5

    .local v6, "$this$dp\\1":I
    const/4 v8, 0x0

    .line 225
    .local v8, "$i$f$getDp\\1\\64":I
    int-to-float v9, v6

    invoke-static {v9}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 64
    .end local v6    # "$this$dp\\1":I
    .end local v8    # "$i$f$getDp\\1\\64":I
    invoke-virtual {v3, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v3, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    shr-int/lit8 v6, v5, 0x6

    and-int/lit8 v6, v6, 0xe

    or-int/lit8 v6, v6, 0x30

    .local v6, "$changed\\2":I
    move/from16 v27, v6

    .end local v6    # "$changed\\2":I
    .local v27, "$changed\\2":I
    move-object v6, v4

    .local v6, "$composer\\2":Landroidx/compose/runtime/Composer;
    move-object/from16 v28, v26

    .local v28, "modifier\\2":Landroidx/compose/ui/Modifier;
    const/16 v29, 0x0

    .line 226
    .local v29, "$i$f$Column\\2\\64":I
    const v8, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 227
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 230
    .local v8, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v27, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v27, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v3, v8, v6, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 234
    .local v9, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v27, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 231
    move/from16 v30, v10

    .local v30, "$changed\\3":I
    move-object/from16 v10, v28

    .local v10, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v31, 0x0

    .line 235
    .local v31, "$i$f$Layout\\3\\231":I
    const v12, -0x451e1427

    const-string v13, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v12, v13}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 236
    invoke-static {v6, v11}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v12

    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    move-result v32

    .line 237
    .local v32, "compositeKeyHash\\3":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v12

    .line 238
    .local v12, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v13

    .line 240
    .local v13, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v14}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v14

    shl-int/lit8 v15, v30, 0x6

    and-int/lit16 v15, v15, 0x380

    or-int/lit8 v15, v15, 0x6

    .line 239
    move/from16 v33, v15

    .local v14, "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v33, "$changed\\4":I
    const/16 v34, 0x0

    .line 241
    .local v34, "$i$f$ReusableComposeNode\\4\\239":I
    const v15, -0x20f7d59c

    const-string v7, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v15, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 242
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v7

    instance-of v7, v7, Landroidx/compose/runtime/Applier;

    if-nez v7, :cond_101

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 243
    :cond_101
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 244
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v7

    if-eqz v7, :cond_10e

    .line 245
    invoke-interface {v6, v14}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_111

    .line 247
    :cond_10e
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 249
    :goto_111
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v7

    .local v7, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 250
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\249\\3":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v7, v9, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 251
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    invoke-static {v7, v12, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 252
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v11}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v11

    .local v11, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 253
    .local v16, "$i$f$set-impl\\6\\252":I
    move-object/from16 p2, v7

    .local p2, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v18, 0x0

    .line 254
    .local v18, "$i$a$-with-Updater$set$1\\7\\253\\6":I
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v19

    if-nez v19, :cond_14c

    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v0

    invoke-static/range {v32 .. v32}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_149

    goto :goto_14c

    :cond_149
    move-object/from16 v1, p2

    goto :goto_15c

    .line 255
    :cond_14c
    :goto_14c
    invoke-static/range {v32 .. v32}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v1, p2

    .end local p2    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v1, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v1, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 256
    invoke-static/range {v32 .. v32}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v7, v0, v11}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 258
    :goto_15c
    nop

    .line 253
    .end local v1    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v18    # "$i$a$-with-Updater$set$1\\7\\253\\6":I
    nop

    .line 258
    nop

    .line 259
    .end local v11    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\6\\252":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v7, v13, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 260
    nop

    .line 249
    .end local v7    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\249\\3":I
    nop

    .line 261
    shr-int/lit8 v0, v33, 0x6

    and-int/lit8 v35, v0, 0xe

    .local v35, "$changed\\8":I
    move-object v0, v6

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v36, 0x0

    .line 232
    .local v36, "$i$a$-Layout-ColumnKt$Column$1\\8\\261\\2":I
    const v1, 0x7cc0ae6e

    const-string v7, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v0, v1, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v7, v27, 0x6

    and-int/lit8 v7, v7, 0x70

    or-int/lit8 v37, v7, 0x6

    .local v37, "$changed\\9":I
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScope;

    .local v1, "$this$Metric_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v7, v0

    .local v7, "$composer\\9":Landroidx/compose/runtime/Composer;
    move-object/from16 v38, v1

    .end local v1    # "$this$Metric_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .local v38, "$this$Metric_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    const/16 v39, 0x0

    .line 64
    .local v39, "$i$a$-Column-XunjiComponentsKt$Metric$1\\9\\232\\0":I
    const v1, -0x4cc84e0b

    const-string v11, "C63@5256L10,63@5225L83,63@5309L13:XunjiComponents.kt#8ao140"

    invoke-static {v7, v1, v11}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v7, v11}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getHeadlineLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    sget-object v1, Landroidx/compose/ui/text/font/FontWeight;->Companion:Landroidx/compose/ui/text/font/FontWeight$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/text/font/FontWeight$Companion;->getBold()Landroidx/compose/ui/text/font/FontWeight;

    move-result-object v1

    and-int/lit8 v11, v5, 0xe

    const/high16 v15, 0x180000

    or-int v23, v11, v15

    const/16 v24, 0x0

    const v25, 0x1ffbe

    move-object v11, v8

    move-object v8, v1

    .end local v8    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v11, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/4 v1, 0x0

    move-object v15, v3

    .end local v3    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v15, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const-wide/16 v2, 0x0

    move-object/from16 v16, v4

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .local v16, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    move/from16 v18, v5

    move-object/from16 v19, v6

    .end local v5    # "$dirty":I
    .end local v6    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v18, "$dirty":I
    .local v19, "$composer\\2":Landroidx/compose/runtime/Composer;
    const-wide/16 v5, 0x0

    move-object/from16 v22, v7

    .end local v7    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v22, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    move-object/from16 v20, v9

    .end local v9    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v20, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v9, 0x0

    move-object/from16 v41, v10

    move-object/from16 v40, v11

    .end local v10    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v11    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v40, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v41, "modifier\\3":Landroidx/compose/ui/Modifier;
    const-wide/16 v10, 0x0

    move-object/from16 v42, v12

    .end local v12    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v42, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const/4 v12, 0x0

    move-object/from16 v43, v13

    .end local v13    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v43, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v13, 0x0

    move-object/from16 v45, v14

    move-object/from16 v44, v15

    .end local v14    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .end local v15    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v44, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v45, "factory\\4":Lkotlin/jvm/functions/Function0;
    const-wide/16 v14, 0x0

    move-object/from16 v46, v16

    .end local v16    # "$composer":Landroidx/compose/runtime/Composer;
    .local v46, "$composer":Landroidx/compose/runtime/Composer;
    const/16 v16, 0x0

    const/16 v47, 0x0

    const/16 v17, 0x0

    move/from16 v48, v18

    .end local v18    # "$dirty":I
    .local v48, "$dirty":I
    const/16 v18, 0x0

    move-object/from16 v49, v19

    .end local v19    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    move-object/from16 v50, v20

    .end local v20    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v50, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v20, 0x0

    move-object/from16 v47, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v47, "$composer\\8":Landroidx/compose/runtime/Composer;
    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v0, v22

    .end local v22    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .local v0, "$composer\\9":Landroidx/compose/runtime/Composer;
    shr-int/lit8 v1, v48, 0x3

    and-int/lit8 v1, v1, 0xe

    move-object/from16 v2, p1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v2, v4, v0, v1, v3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    invoke-static {v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 232
    .end local v0    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v37    # "$changed\\9":I
    .end local v38    # "$this$Metric_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v39    # "$i$a$-Column-XunjiComponentsKt$Metric$1\\9\\232\\0":I
    invoke-static/range {v47 .. v47}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 261
    .end local v35    # "$changed\\8":I
    .end local v36    # "$i$a$-Layout-ColumnKt$Column$1\\8\\261\\2":I
    .end local v47    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 262
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 241
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 263
    nop

    .line 235
    .end local v33    # "$changed\\4":I
    .end local v34    # "$i$f$ReusableComposeNode\\4\\239":I
    .end local v45    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 264
    nop

    .line 226
    .end local v30    # "$changed\\3":I
    .end local v31    # "$i$f$Layout\\3\\231":I
    .end local v32    # "compositeKeyHash\\3":I
    .end local v41    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v42    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v43    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 265
    nop

    .end local v27    # "$changed\\2":I
    .end local v28    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v29    # "$i$f$Column\\2\\64":I
    .end local v40    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v44    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v49    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v50    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_21b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 64
    :cond_21b
    move-object/from16 v3, v26

    goto :goto_227

    .end local v26    # "modifier":Landroidx/compose/ui/Modifier;
    .end local v46    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v48    # "$dirty":I
    .restart local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v5    # "$dirty":I
    .local p2, "modifier":Landroidx/compose/ui/Modifier;
    :cond_21e
    move-object v2, v1

    move-object/from16 v46, v4

    move/from16 v48, v5

    .end local v4    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v5    # "$dirty":I
    .restart local v46    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v48    # "$dirty":I
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v3, v8

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "modifier":Landroidx/compose/ui/Modifier;
    :goto_227
    invoke-interface/range {v46 .. v46}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v6

    if-eqz v6, :cond_23b

    new-instance v0, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda7;

    move-object/from16 v1, p0

    move/from16 v4, p4

    move/from16 v5, p5

    invoke-direct/range {v0 .. v5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda7;-><init>(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;II)V

    invoke-interface {v6, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_23b
    return-void
.end method

.method private static final Metric$lambda$1(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 14

    or-int/lit8 v0, p3, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v5

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v6, p4

    move-object v4, p5

    invoke-static/range {v1 .. v6}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Metric(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/Composer;II)V

    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object p0
.end method

.method public static final Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V
    .registers 35
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "error"    # Z
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    const-string v1, "text"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 52
    const v1, 0x667bb5c5

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(Notice)N(text,error)52@4024L10,52@4169L36,52@3994L212:XunjiComponents.kt#8ao140"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, p3, 0x6

    if-nez v4, :cond_25

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_23

    const/4 v4, 0x4

    goto :goto_24

    :cond_23
    const/4 v4, 0x2

    :goto_24
    or-int/2addr v3, v4

    :cond_25
    and-int/lit8 v4, p4, 0x2

    if-eqz v4, :cond_2e

    or-int/lit8 v3, v3, 0x30

    move/from16 v5, p1

    goto :goto_43

    :cond_2e
    and-int/lit8 v5, p3, 0x30

    if-nez v5, :cond_41

    move/from16 v5, p1

    invoke-interface {v2, v5}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v6

    if-eqz v6, :cond_3d

    const/16 v6, 0x20

    goto :goto_3f

    :cond_3d
    const/16 v6, 0x10

    :goto_3f
    or-int/2addr v3, v6

    goto :goto_43

    :cond_41
    move/from16 v5, p1

    :goto_43
    and-int/lit8 v6, v3, 0x13

    const/16 v7, 0x12

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eq v6, v7, :cond_4d

    move v6, v9

    goto :goto_4e

    :cond_4d
    move v6, v8

    :goto_4e
    and-int/lit8 v7, v3, 0x1

    invoke-interface {v2, v6, v7}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v6

    if-eqz v6, :cond_123

    if-eqz v4, :cond_5c

    const/4 v4, 0x0

    move/from16 v26, v4

    .end local p1    # "error":Z
    .local v4, "error":Z
    goto :goto_5e

    .end local v4    # "error":Z
    .restart local p1    # "error":Z
    :cond_5c
    move/from16 v26, v5

    .end local p1    # "error":Z
    .local v26, "error":Z
    :goto_5e
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v4

    if-eqz v4, :cond_6a

    const/4 v4, -0x1

    const-string v5, "com.xunji.flashcards.ui.components.Notice (XunjiComponents.kt:51)"

    invoke-static {v1, v3, v4, v5}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 53
    :cond_6a
    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/Typography;->getBodyMedium()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    if-eqz v26, :cond_90

    const v1, -0x499a95f6

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "52@4075L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getError-0d7_KjU()J

    move-result-wide v4

    goto :goto_a7

    :cond_90
    const v1, -0x499a914b

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v1, "52@4112L11"

    invoke-static {v2, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    sget-object v1, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v1, v2, v4}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v1

    invoke-virtual {v1}, Landroidx/compose/material3/ColorScheme;->getOnSurfaceVariant-0d7_KjU()J

    move-result-wide v4

    :goto_a7
    invoke-interface {v2}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    sget-object v1, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v1, Landroidx/compose/ui/Modifier;

    const v6, -0x499a8b97

    const-string v7, "CC(remember):XunjiComponents.kt#9igjgp"

    invoke-static {v2, v6, v7}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    const/4 v6, 0x0

    .local v6, "invalid\\1":Z
    move-object v7, v2

    .local v7, "$this$cache\\1":Landroidx/compose/runtime/Composer;
    const/4 v10, 0x0

    .line 129
    .local v10, "$i$f$cache\\1\\53":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v11

    .local v11, "it\\1":Ljava/lang/Object;
    const/4 v12, 0x0

    .line 130
    .local v12, "$i$a$-let-ComposerKt$cache$1\\2\\129\\1":I
    sget-object v13, Landroidx/compose/runtime/Composer;->Companion:Landroidx/compose/runtime/Composer$Companion;

    invoke-virtual {v13}, Landroidx/compose/runtime/Composer$Companion;->getEmpty()Ljava/lang/Object;

    move-result-object v13

    if-ne v11, v13, :cond_d1

    .line 131
    const/4 v13, 0x0

    .local v13, "$i$a$-cache-XunjiComponentsKt$Notice$1\\3\\131\\0":I
    new-instance v14, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda3;

    invoke-direct {v14}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda3;-><init>()V

    .line 132
    .end local v13    # "$i$a$-cache-XunjiComponentsKt$Notice$1\\3\\131\\0":I
    .local v14, "value\\2":Ljava/lang/Object;
    invoke-interface {v7, v14}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 133
    move-object v11, v14

    .end local v14    # "value\\2":Ljava/lang/Object;
    goto :goto_d2

    .line 134
    :cond_d1
    nop

    .line 129
    .end local v11    # "it\\1":Ljava/lang/Object;
    .end local v12    # "$i$a$-let-ComposerKt$cache$1\\2\\129\\1":I
    :goto_d2
    nop

    .line 53
    .end local v6    # "invalid\\1":Z
    .end local v7    # "$this$cache\\1":Landroidx/compose/runtime/Composer;
    .end local v10    # "$i$f$cache\\1\\53":I
    check-cast v11, Lkotlin/jvm/functions/Function1;

    invoke-static {v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    const/4 v6, 0x0

    invoke-static {v1, v8, v11, v9, v6}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics$default(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;ILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v1

    and-int/lit8 v23, v3, 0xe

    const/16 v24, 0x0

    const v25, 0x1fff8

    move-object/from16 v22, v2

    move-wide/from16 v28, v4

    move v5, v3

    move-wide/from16 v2, v28

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v5, "$dirty":I
    .local v22, "$composer":Landroidx/compose/runtime/Composer;
    const/4 v4, 0x0

    move v7, v5

    .end local v5    # "$dirty":I
    .local v7, "$dirty":I
    const-wide/16 v5, 0x0

    move v8, v7

    .end local v7    # "$dirty":I
    .local v8, "$dirty":I
    const/4 v7, 0x0

    move v9, v8

    .end local v8    # "$dirty":I
    .local v9, "$dirty":I
    const/4 v8, 0x0

    move v10, v9

    .end local v9    # "$dirty":I
    .local v10, "$dirty":I
    const/4 v9, 0x0

    move v12, v10

    .end local v10    # "$dirty":I
    .local v12, "$dirty":I
    const-wide/16 v10, 0x0

    move v13, v12

    .end local v12    # "$dirty":I
    .local v13, "$dirty":I
    const/4 v12, 0x0

    move v14, v13

    .end local v13    # "$dirty":I
    .local v14, "$dirty":I
    const/4 v13, 0x0

    move/from16 v16, v14

    .end local v14    # "$dirty":I
    .local v16, "$dirty":I
    const-wide/16 v14, 0x0

    move/from16 v17, v16

    .end local v16    # "$dirty":I
    .local v17, "$dirty":I
    const/16 v16, 0x0

    move/from16 v18, v17

    .end local v17    # "$dirty":I
    .local v18, "$dirty":I
    const/16 v17, 0x0

    move/from16 v19, v18

    .end local v18    # "$dirty":I
    .local v19, "$dirty":I
    const/16 v18, 0x0

    move/from16 v20, v19

    .end local v19    # "$dirty":I
    .local v20, "$dirty":I
    const/16 v19, 0x0

    move/from16 v27, v20

    .end local v20    # "$dirty":I
    .local v27, "$dirty":I
    const/16 v20, 0x0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_120

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 54
    :cond_120
    move/from16 v5, v26

    goto :goto_12a

    .line 52
    .end local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v26    # "error":Z
    .end local v27    # "$dirty":I
    .restart local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$dirty":I
    .restart local p1    # "error":Z
    :cond_123
    move-object/from16 v22, v2

    move/from16 v27, v3

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .restart local v22    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v27    # "$dirty":I
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    .line 54
    .end local p1    # "error":Z
    .local v5, "error":Z
    :goto_12a
    invoke-interface/range {v22 .. v22}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_13d

    new-instance v2, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda4;

    move/from16 v3, p3

    move/from16 v4, p4

    invoke-direct {v2, v0, v5, v3, v4}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda4;-><init>(Ljava/lang/String;ZII)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_13f

    :cond_13d
    move/from16 v3, p3

    :goto_13f
    return-void
.end method

.method private static final Notice$lambda$0$0(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;)Lkotlin/Unit;
    .registers 2
    .param p0, "$this$semantics"    # Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    const-string v0, "$this$semantics"

    invoke-static {p0, v0}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 53
    sget-object v0, Landroidx/compose/ui/semantics/LiveRegionMode;->Companion:Landroidx/compose/ui/semantics/LiveRegionMode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/semantics/LiveRegionMode$Companion;->getPolite-0phEisY()I

    move-result v0

    invoke-static {p0, v0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setLiveRegion-hR3wRGc(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;I)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Notice$lambda$1(Ljava/lang/String;ZIILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p4, v0, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V
    .registers 23
    .param p0, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p1, "content"    # Lkotlin/jvm/functions/Function3;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroidx/compose/ui/Modifier;",
            "Lkotlin/jvm/functions/Function3<",
            "-",
            "Landroidx/compose/foundation/layout/ColumnScope;",
            "-",
            "Landroidx/compose/runtime/Composer;",
            "-",
            "Ljava/lang/Integer;",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v0, p1

    move/from16 v1, p3

    move/from16 v2, p4

    const-string v3, "content"

    invoke-static {v0, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 46
    const v3, -0x60563769

    move-object/from16 v4, p2

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v14, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(Paper)N(modifier,content)46@3398L11,46@3457L11,46@3486L99,46@3329L256:XunjiComponents.kt#8ao140"

    invoke-static {v14, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p3

    .local v4, "$dirty":I
    and-int/lit8 v5, v2, 0x1

    if-eqz v5, :cond_24

    or-int/lit8 v4, v4, 0x6

    move-object/from16 v6, p0

    goto :goto_37

    :cond_24
    and-int/lit8 v6, v1, 0x6

    if-nez v6, :cond_35

    move-object/from16 v6, p0

    invoke-interface {v14, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_32

    const/4 v7, 0x4

    goto :goto_33

    :cond_32
    const/4 v7, 0x2

    :goto_33
    or-int/2addr v4, v7

    goto :goto_37

    :cond_35
    move-object/from16 v6, p0

    :goto_37
    and-int/lit8 v7, v1, 0x30

    if-nez v7, :cond_47

    invoke-interface {v14, v0}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_44

    const/16 v7, 0x20

    goto :goto_46

    :cond_44
    const/16 v7, 0x10

    :goto_46
    or-int/2addr v4, v7

    :cond_47
    and-int/lit8 v7, v4, 0x13

    const/16 v8, 0x12

    const/4 v9, 0x1

    if-eq v7, v8, :cond_50

    move v7, v9

    goto :goto_51

    :cond_50
    const/4 v7, 0x0

    :goto_51
    and-int/lit8 v8, v4, 0x1

    invoke-interface {v14, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_ce

    if-eqz v5, :cond_60

    sget-object v5, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v5, Landroidx/compose/ui/Modifier;

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v5, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_61

    .end local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p0    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_60
    move-object v5, v6

    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v5    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_61
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_6d

    const/4 v6, -0x1

    const-string v7, "com.xunji.flashcards.ui.components.Paper (XunjiComponents.kt:45)"

    invoke-static {v3, v4, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 47
    :cond_6d
    const/16 v3, 0x18

    .local v3, "$this$dp\\1":I
    const/4 v6, 0x0

    .line 127
    .local v6, "$i$f$getDp\\1\\47":I
    int-to-float v7, v3

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 47
    .end local v3    # "$this$dp\\1":I
    .end local v6    # "$i$f$getDp\\1\\47":I
    invoke-static {v3}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v3

    check-cast v3, Landroidx/compose/ui/graphics/Shape;

    sget-object v6, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v7, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v6, v14, v7}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/compose/material3/ColorScheme;->getSurface-0d7_KjU()J

    move-result-wide v6

    const/4 v8, 0x1

    .local v8, "$this$dp\\2":I
    const/4 v10, 0x0

    .line 127
    .local v10, "$i$f$getDp\\2\\47":I
    int-to-float v11, v8

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 47
    .end local v8    # "$this$dp\\2":I
    .end local v10    # "$i$f$getDp\\2\\47":I
    sget-object v10, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v11, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v10, v14, v11}, Landroidx/compose/material3/MaterialTheme;->getColorScheme(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/ColorScheme;

    move-result-object v10

    invoke-virtual {v10}, Landroidx/compose/material3/ColorScheme;->getOutlineVariant-0d7_KjU()J

    move-result-wide v10

    invoke-static {v8, v10, v11}, Landroidx/compose/foundation/BorderStrokeKt;->BorderStroke-cXLIe8U(FJ)Landroidx/compose/foundation/BorderStroke;

    move-result-object v12

    new-instance v8, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda16;

    invoke-direct {v8, v0}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda16;-><init>(Lkotlin/jvm/functions/Function3;)V

    const/16 v10, 0x36

    const v11, -0x24a00724

    invoke-static {v11, v9, v8, v14, v10}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    move-object v13, v8

    check-cast v13, Lkotlin/jvm/functions/Function2;

    and-int/lit8 v8, v4, 0xe

    const/high16 v9, 0xc00000

    or-int v15, v8, v9

    const/16 v16, 0x38

    const-wide/16 v8, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    move-object/from16 v17, v5

    move-object v5, v3

    move v3, v4

    move-object/from16 v4, v17

    .end local v5    # "modifier":Landroidx/compose/ui/Modifier;
    .local v3, "$dirty":I
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    invoke-static/range {v4 .. v16}, Landroidx/compose/material3/SurfaceKt;->Surface-T9BRK9s(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;JJFFLandroidx/compose/foundation/BorderStroke;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v5

    if-eqz v5, :cond_d3

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_d3

    .line 46
    .end local v3    # "$dirty":I
    .local v4, "$dirty":I
    .restart local p0    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_ce
    move v3, v4

    .end local v4    # "$dirty":I
    .restart local v3    # "$dirty":I
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v4, v6

    .line 48
    .end local p0    # "modifier":Landroidx/compose/ui/Modifier;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    :cond_d3
    :goto_d3
    invoke-interface {v14}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v5

    if-eqz v5, :cond_e1

    new-instance v6, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda17;

    invoke-direct {v6, v4, v0, v1, v2}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda17;-><init>(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;II)V

    invoke-interface {v5, v6}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_e1
    return-void
.end method

.method private static final Paper$lambda$0(Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 27
    .param p0, "$content"    # Lkotlin/jvm/functions/Function3;
    .param p1, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p2, "$changed"    # I

    move-object/from16 v0, p1

    move/from16 v1, p2

    const-string v2, "C46@3488L95:XunjiComponents.kt#8ao140"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eq v2, v3, :cond_11

    const/4 v2, 0x1

    goto :goto_12

    :cond_11
    move v2, v4

    :goto_12
    and-int/lit8 v3, v1, 0x1

    invoke-interface {v0, v2, v3}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_15f

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_29

    const/4 v2, -0x1

    const-string v3, "com.xunji.flashcards.ui.components.Paper.<anonymous> (XunjiComponents.kt:46)"

    const v5, -0x24a00724

    invoke-static {v5, v1, v2, v3}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 47
    :cond_29
    sget-object v2, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v2, Landroidx/compose/ui/Modifier;

    const/16 v3, 0x16

    .local v3, "$this$dp\\1":I
    const/4 v5, 0x0

    .line 283
    .local v5, "$i$f$getDp\\1\\47":I
    int-to-float v6, v3

    invoke-static {v6}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v3

    .line 47
    .end local v3    # "$this$dp\\1":I
    .end local v5    # "$i$f$getDp\\1\\47":I
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/PaddingKt;->padding-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    move-result-object v2

    sget-object v3, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/16 v5, 0x10

    .local v5, "$this$dp\\2":I
    const/4 v6, 0x0

    .line 283
    .local v6, "$i$f$getDp\\2\\47":I
    int-to-float v7, v5

    invoke-static {v7}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v5

    .line 47
    .end local v5    # "$this$dp\\2":I
    .end local v6    # "$i$f$getDp\\2\\47":I
    invoke-virtual {v3, v5}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v3

    check-cast v3, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v3, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v5, 0x36

    .local v5, "$changed\\3":I
    move-object/from16 v6, p1

    .local v2, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v6, "$composer\\3":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    .line 284
    .local v7, "$i$f$Column\\3\\47":I
    const v8, 0x4ff7456f

    const-string v9, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v6, v8, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 285
    sget-object v8, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v8}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v8

    .line 288
    .local v8, "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v9, v5, 0x3

    and-int/lit8 v9, v9, 0xe

    shr-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v9, v10

    invoke-static {v3, v8, v6, v9}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v9

    .line 292
    .local v9, "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v5, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 289
    nop

    .local v10, "$changed\\4":I
    move-object v11, v2

    .local v11, "modifier\\4":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    .line 293
    .local v12, "$i$f$Layout\\4\\289":I
    const v13, -0x451e1427

    const-string v14, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v6, v13, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 294
    invoke-static {v6, v4}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v13

    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    move-result v4

    .line 295
    .local v4, "compositeKeyHash\\4":I
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v13

    .line 296
    .local v13, "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v6, v11}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v14

    .line 298
    .local v14, "materialized\\4":Landroidx/compose/ui/Modifier;
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v15}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v15

    shl-int/lit8 v0, v10, 0x6

    and-int/lit16 v0, v0, 0x380

    or-int/lit8 v0, v0, 0x6

    .line 297
    nop

    .local v0, "$changed\\5":I
    .local v15, "factory\\5":Lkotlin/jvm/functions/Function0;
    const/16 v16, 0x0

    .line 299
    .local v16, "$i$f$ReusableComposeNode\\5\\297":I
    move/from16 v17, v0

    .end local v0    # "$changed\\5":I
    .local v17, "$changed\\5":I
    const v0, -0x20f7d59c

    const-string v1, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v6, v0, v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 300
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v0

    instance-of v0, v0, Landroidx/compose/runtime/Applier;

    if-nez v0, :cond_ac

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 301
    :cond_ac
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 302
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v0

    if-eqz v0, :cond_b9

    .line 303
    invoke-interface {v6, v15}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_bc

    .line 305
    :cond_b9
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 307
    :goto_bc
    invoke-static {v6}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v0

    .local v0, "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/4 v1, 0x0

    .line 308
    .local v1, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\307\\4":I
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    move/from16 v19, v1

    .end local v1    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\307\\4":I
    .local v19, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\307\\4":I
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v9, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 309
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v13, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 310
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    .local v1, "block\\7":Lkotlin/jvm/functions/Function2;
    const/16 v18, 0x0

    .line 311
    .local v18, "$i$f$set-impl\\7\\310":I
    move-object/from16 v20, v0

    .local v20, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    const/16 v21, 0x0

    .line 312
    .local v21, "$i$a$-with-Updater$set$1\\8\\311\\7":I
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v22

    if-nez v22, :cond_fd

    move-object/from16 v22, v2

    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v22, "modifier\\3":Landroidx/compose/ui/Modifier;
    invoke-interface/range {v20 .. v20}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v2

    move-object/from16 v23, v3

    .end local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v23, "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_fa

    goto :goto_101

    :cond_fa
    move-object/from16 v3, v20

    goto :goto_111

    .end local v22    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v23    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :cond_fd
    move-object/from16 v22, v2

    move-object/from16 v23, v3

    .line 313
    .end local v2    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v3    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .restart local v22    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .restart local v23    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    :goto_101
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    move-object/from16 v3, v20

    .end local v20    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .local v3, "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    invoke-interface {v3, v2}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 314
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-interface {v0, v2, v1}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 316
    :goto_111
    nop

    .line 311
    .end local v3    # "$this$set_impl_u24lambda_u240\\7":Landroidx/compose/runtime/Composer;
    .end local v21    # "$i$a$-with-Updater$set$1\\8\\311\\7":I
    nop

    .line 316
    nop

    .line 317
    .end local v1    # "block\\7":Lkotlin/jvm/functions/Function2;
    .end local v18    # "$i$f$set-impl\\7\\310":I
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v1}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v1

    invoke-static {v0, v14, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 318
    nop

    .line 307
    .end local v0    # "$this$Layout_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v19    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\6\\307\\4":I
    nop

    .line 319
    shr-int/lit8 v0, v17, 0x6

    and-int/lit8 v0, v0, 0xe

    .local v0, "$changed\\9":I
    move-object v1, v6

    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/4 v2, 0x0

    .line 290
    .local v2, "$i$a$-Layout-ColumnKt$Column$1\\9\\319\\3":I
    const v3, 0x7cc0ae6e

    move/from16 v18, v0

    .end local v0    # "$changed\\9":I
    .local v18, "$changed\\9":I
    const-string v0, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v1, v3, v0}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v0, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v3, v5, 0x6

    and-int/lit8 v3, v3, 0x70

    or-int/lit8 v3, v3, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    move/from16 v19, v2

    move-object/from16 v2, p0

    .end local v2    # "$i$a$-Layout-ColumnKt$Column$1\\9\\319\\3":I
    .local v19, "$i$a$-Layout-ColumnKt$Column$1\\9\\319\\3":I
    invoke-interface {v2, v0, v1, v3}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 319
    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v18    # "$changed\\9":I
    .end local v19    # "$i$a$-Layout-ColumnKt$Column$1\\9\\319\\3":I
    nop

    .line 320
    invoke-interface {v6}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 299
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 321
    nop

    .line 293
    .end local v15    # "factory\\5":Lkotlin/jvm/functions/Function0;
    .end local v16    # "$i$f$ReusableComposeNode\\5\\297":I
    .end local v17    # "$changed\\5":I
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 322
    nop

    .line 284
    .end local v4    # "compositeKeyHash\\4":I
    .end local v10    # "$changed\\4":I
    .end local v11    # "modifier\\4":Landroidx/compose/ui/Modifier;
    .end local v12    # "$i$f$Layout\\4\\289":I
    .end local v13    # "localMap\\4":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v14    # "materialized\\4":Landroidx/compose/ui/Modifier;
    invoke-static {v6}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 323
    nop

    .end local v5    # "$changed\\3":I
    .end local v6    # "$composer\\3":Landroidx/compose/runtime/Composer;
    .end local v7    # "$i$f$Column\\3\\47":I
    .end local v8    # "horizontalAlignment\\3":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v9    # "measurePolicy\\3":Landroidx/compose/ui/layout/MeasurePolicy;
    .end local v22    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v23    # "verticalArrangement\\3":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_164

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_164

    .line 47
    :cond_15f
    move-object/from16 v2, p0

    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_164
    :goto_164
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final Paper$lambda$1(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p4, v0, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Paper(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .registers 26
    .param p0, "text"    # Ljava/lang/String;
    .param p1, "onClick"    # Lkotlin/jvm/functions/Function0;
    .param p2, "modifier"    # Landroidx/compose/ui/Modifier;
    .param p3, "enabled"    # Z
    .param p4, "tag"    # Ljava/lang/String;
    .param p5, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p6, "$changed"    # I
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lkotlin/jvm/functions/Function0<",
            "Lkotlin/Unit;",
            ">;",
            "Landroidx/compose/ui/Modifier;",
            "Z",
            "Ljava/lang/String;",
            "Landroidx/compose/runtime/Composer;",
            "II)V"
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move/from16 v0, p6

    const-string v3, "text"

    invoke-static {v1, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v3, "onClick"

    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 49
    const v3, 0x202a8653

    move-object/from16 v4, p5

    invoke-interface {v4, v3}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v12

    .end local p5    # "$composer":Landroidx/compose/runtime/Composer;
    .local v12, "$composer":Landroidx/compose/runtime/Composer;
    const-string v4, "C(PrimaryButton)N(text,onClick,modifier,enabled,tag)49@3876L56,49@3713L219:XunjiComponents.kt#8ao140"

    invoke-static {v12, v4}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v4, p6

    .local v4, "$dirty":I
    and-int/lit8 v5, v0, 0x6

    const/4 v6, 0x2

    if-nez v5, :cond_2f

    invoke-interface {v12, v1}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_2d

    const/4 v5, 0x4

    goto :goto_2e

    :cond_2d
    move v5, v6

    :goto_2e
    or-int/2addr v4, v5

    :cond_2f
    and-int/lit8 v5, v0, 0x30

    if-nez v5, :cond_3f

    invoke-interface {v12, v2}, Landroidx/compose/runtime/Composer;->changedInstance(Ljava/lang/Object;)Z

    move-result v5

    if-eqz v5, :cond_3c

    const/16 v5, 0x20

    goto :goto_3e

    :cond_3c
    const/16 v5, 0x10

    :goto_3e
    or-int/2addr v4, v5

    :cond_3f
    and-int/lit8 v5, p7, 0x4

    if-eqz v5, :cond_48

    or-int/lit16 v4, v4, 0x180

    move-object/from16 v7, p2

    goto :goto_5d

    :cond_48
    and-int/lit16 v7, v0, 0x180

    if-nez v7, :cond_5b

    move-object/from16 v7, p2

    invoke-interface {v12, v7}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v8

    if-eqz v8, :cond_57

    const/16 v8, 0x100

    goto :goto_59

    :cond_57
    const/16 v8, 0x80

    :goto_59
    or-int/2addr v4, v8

    goto :goto_5d

    :cond_5b
    move-object/from16 v7, p2

    :goto_5d
    and-int/lit8 v8, p7, 0x8

    if-eqz v8, :cond_66

    or-int/lit16 v4, v4, 0xc00

    move/from16 v9, p3

    goto :goto_7b

    :cond_66
    and-int/lit16 v9, v0, 0xc00

    if-nez v9, :cond_79

    move/from16 v9, p3

    invoke-interface {v12, v9}, Landroidx/compose/runtime/Composer;->changed(Z)Z

    move-result v10

    if-eqz v10, :cond_75

    const/16 v10, 0x800

    goto :goto_77

    :cond_75
    const/16 v10, 0x400

    :goto_77
    or-int/2addr v4, v10

    goto :goto_7b

    :cond_79
    move/from16 v9, p3

    :goto_7b
    and-int/lit8 v10, p7, 0x10

    if-eqz v10, :cond_84

    or-int/lit16 v4, v4, 0x6000

    move-object/from16 v11, p4

    goto :goto_99

    :cond_84
    and-int/lit16 v11, v0, 0x6000

    if-nez v11, :cond_97

    move-object/from16 v11, p4

    invoke-interface {v12, v11}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v13

    if-eqz v13, :cond_93

    const/16 v13, 0x4000

    goto :goto_95

    :cond_93
    const/16 v13, 0x2000

    :goto_95
    or-int/2addr v4, v13

    goto :goto_99

    :cond_97
    move-object/from16 v11, p4

    :goto_99
    move v15, v4

    .end local v4    # "$dirty":I
    .local v15, "$dirty":I
    and-int/lit16 v4, v15, 0x2493

    const/16 v13, 0x2492

    const/4 v14, 0x1

    if-eq v4, v13, :cond_a3

    move v4, v14

    goto :goto_a4

    :cond_a3
    const/4 v4, 0x0

    :goto_a4
    and-int/lit8 v13, v15, 0x1

    invoke-interface {v12, v4, v13}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v4

    if-eqz v4, :cond_140

    if-eqz v5, :cond_b3

    sget-object v4, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    check-cast v4, Landroidx/compose/ui/Modifier;

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .local v4, "modifier":Landroidx/compose/ui/Modifier;
    goto :goto_b4

    .end local v4    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "modifier":Landroidx/compose/ui/Modifier;
    :cond_b3
    move-object v4, v7

    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local v4    # "modifier":Landroidx/compose/ui/Modifier;
    :goto_b4
    if-eqz v8, :cond_b8

    const/4 v5, 0x1

    move v9, v5

    .end local p3    # "enabled":Z
    .local v9, "enabled":Z
    :cond_b8
    if-eqz v10, :cond_bd

    const-string v5, ""

    .end local p4    # "tag":Ljava/lang/String;
    .local v5, "tag":Ljava/lang/String;
    goto :goto_be

    .end local v5    # "tag":Ljava/lang/String;
    .restart local p4    # "tag":Ljava/lang/String;
    :cond_bd
    move-object v5, v11

    .end local p4    # "tag":Ljava/lang/String;
    .restart local v5    # "tag":Ljava/lang/String;
    :goto_be
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v7

    if-eqz v7, :cond_ca

    const/4 v7, -0x1

    const-string v8, "com.xunji.flashcards.ui.components.PrimaryButton (XunjiComponents.kt:48)"

    invoke-static {v3, v15, v7, v8}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_ca
    const/4 v3, 0x0

    const/4 v7, 0x0

    invoke-static {v4, v3, v14, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth$default(Landroidx/compose/ui/Modifier;FILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v8

    const/16 v10, 0x38

    .local v10, "$this$dp\\1":I
    const/4 v11, 0x0

    .line 128
    .local v11, "$i$f$getDp\\1\\50":I
    int-to-float v13, v10

    invoke-static {v13}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v10

    .line 50
    .end local v10    # "$this$dp\\1":I
    .end local v11    # "$i$f$getDp\\1\\50":I
    invoke-static {v8, v10, v3, v6, v7}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFILjava/lang/Object;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    invoke-static {v3, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    move-result-object v3

    const/16 v6, 0x12

    .local v6, "$this$dp\\2":I
    const/4 v7, 0x0

    .line 128
    .local v7, "$i$f$getDp\\2\\50":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 50
    .end local v6    # "$this$dp\\2":I
    .end local v7    # "$i$f$getDp\\2\\50":I
    invoke-static {v6}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    move-result-object v6

    check-cast v6, Landroidx/compose/ui/graphics/Shape;

    const/16 v7, 0x12

    .local v7, "$this$dp\\3":I
    const/4 v8, 0x0

    .line 128
    .local v8, "$i$f$getDp\\3\\50":I
    int-to-float v10, v7

    invoke-static {v10}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v7

    .line 50
    .end local v7    # "$this$dp\\3":I
    .end local v8    # "$i$f$getDp\\3\\50":I
    const/16 v8, 0xf

    .local v8, "$this$dp\\4":I
    const/4 v10, 0x0

    .line 128
    .local v10, "$i$f$getDp\\4\\50":I
    int-to-float v11, v8

    invoke-static {v11}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v8

    .line 50
    .end local v8    # "$this$dp\\4":I
    .end local v10    # "$i$f$getDp\\4\\50":I
    invoke-static {v7, v8}, Landroidx/compose/foundation/layout/PaddingKt;->PaddingValues-YgX7TsA(FF)Landroidx/compose/foundation/layout/PaddingValues;

    move-result-object v7

    new-instance v8, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda14;

    invoke-direct {v8, v1}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda14;-><init>(Ljava/lang/String;)V

    const/16 v10, 0x36

    const v11, -0x396cb9d

    invoke-static {v11, v14, v8, v12, v10}, Landroidx/compose/runtime/internal/ComposableLambdaKt;->rememberComposableLambda(IZLjava/lang/Object;Landroidx/compose/runtime/Composer;I)Landroidx/compose/runtime/internal/ComposableLambda;

    move-result-object v8

    move-object v11, v8

    check-cast v11, Lkotlin/jvm/functions/Function3;

    shr-int/lit8 v8, v15, 0x3

    and-int/lit8 v8, v8, 0xe

    const/high16 v10, 0x30c00000

    or-int/2addr v8, v10

    shr-int/lit8 v10, v15, 0x3

    and-int/lit16 v10, v10, 0x380

    or-int v13, v8, v10

    const/16 v14, 0x170

    move-object v8, v5

    move-object v5, v6

    .end local v5    # "tag":Ljava/lang/String;
    .local v8, "tag":Ljava/lang/String;
    const/4 v6, 0x0

    move-object v10, v4

    move v4, v9

    move-object v9, v7

    .end local v9    # "enabled":Z
    .local v4, "enabled":Z
    .local v10, "modifier":Landroidx/compose/ui/Modifier;
    const/4 v7, 0x0

    move-object/from16 v16, v8

    .end local v8    # "tag":Ljava/lang/String;
    .local v16, "tag":Ljava/lang/String;
    const/4 v8, 0x0

    move-object/from16 v17, v10

    .end local v10    # "modifier":Landroidx/compose/ui/Modifier;
    .local v17, "modifier":Landroidx/compose/ui/Modifier;
    const/4 v10, 0x0

    invoke-static/range {v2 .. v14}, Landroidx/compose/material3/ButtonKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValues;Landroidx/compose/foundation/interaction/MutableInteractionSource;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/Composer;II)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_13b

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    .line 51
    :cond_13b
    move-object/from16 v5, v16

    move-object/from16 v3, v17

    goto :goto_146

    .line 49
    .end local v4    # "enabled":Z
    .end local v16    # "tag":Ljava/lang/String;
    .end local v17    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .restart local p3    # "enabled":Z
    .restart local p4    # "tag":Ljava/lang/String;
    :cond_140
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v3, v7

    move v4, v9

    move-object v5, v11

    .line 51
    .end local p2    # "modifier":Landroidx/compose/ui/Modifier;
    .end local p3    # "enabled":Z
    .end local p4    # "tag":Ljava/lang/String;
    .local v3, "modifier":Landroidx/compose/ui/Modifier;
    .restart local v4    # "enabled":Z
    .restart local v5    # "tag":Ljava/lang/String;
    :goto_146
    invoke-interface {v12}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v8

    if-eqz v8, :cond_15a

    new-instance v0, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda15;

    move-object/from16 v2, p1

    move/from16 v6, p6

    move/from16 v7, p7

    invoke-direct/range {v0 .. v7}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda15;-><init>(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;II)V

    invoke-interface {v8, v0}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    :cond_15a
    return-void
.end method

.method private static final PrimaryButton$lambda$0(Ljava/lang/String;Landroidx/compose/foundation/layout/RowScope;Landroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 30
    .param p0, "$text"    # Ljava/lang/String;
    .param p1, "$this$Button"    # Landroidx/compose/foundation/layout/RowScope;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p2

    move/from16 v1, p3

    const-string v2, "$this$Button"

    move-object/from16 v3, p1

    invoke-static {v3, v2}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    const-string v2, "C49@3908L10,49@3878L52:XunjiComponents.kt#8ao140"

    invoke-static {v0, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    and-int/lit8 v2, v1, 0x11

    const/16 v4, 0x10

    if-eq v2, v4, :cond_18

    const/4 v2, 0x1

    goto :goto_19

    :cond_18
    const/4 v2, 0x0

    :goto_19
    and-int/lit8 v4, v1, 0x1

    invoke-interface {v0, v2, v4}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v2

    if-eqz v2, :cond_6d

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v2

    if-eqz v2, :cond_30

    const/4 v2, -0x1

    const-string v4, "com.xunji.flashcards.ui.components.PrimaryButton.<anonymous> (XunjiComponents.kt:49)"

    const v5, -0x396cb9d

    invoke-static {v5, v1, v2, v4}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    .line 50
    :cond_30
    sget-object v2, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v4, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v2, v0, v4}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v2

    invoke-virtual {v2}, Landroidx/compose/material3/Typography;->getLabelLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    const/16 v24, 0x0

    const v25, 0x1fffe

    const/4 v1, 0x0

    const-wide/16 v2, 0x0

    const/4 v4, 0x0

    const-wide/16 v5, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 v10, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-wide/16 v14, 0x0

    const/16 v16, 0x0

    const/16 v17, 0x0

    const/16 v18, 0x0

    const/16 v19, 0x0

    const/16 v20, 0x0

    const/16 v23, 0x0

    move-object/from16 v22, v0

    move-object/from16 v0, p0

    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v0

    if-eqz v0, :cond_70

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_70

    :cond_6d
    invoke-interface/range {p2 .. p2}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    :cond_70
    :goto_70
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method private static final PrimaryButton$lambda$1(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 18

    or-int/lit8 v0, p5, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v7

    move-object v1, p0

    move-object v2, p1

    move-object v3, p2

    move v4, p3

    move-object v5, p4

    move v8, p6

    move-object/from16 v6, p7

    invoke-static/range {v1 .. v8}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->PrimaryButton(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLjava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final SectionTitle(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V
    .registers 57
    .param p0, "title"    # Ljava/lang/String;
    .param p1, "subtitle"    # Ljava/lang/String;
    .param p2, "$composer"    # Landroidx/compose/runtime/Composer;
    .param p3, "$changed"    # I

    move-object/from16 v0, p0

    const-string v1, "title"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullParameter(Ljava/lang/Object;Ljava/lang/String;)V

    .line 63
    const v1, -0x421f7fe5

    move-object/from16 v2, p2

    invoke-interface {v2, v1}, Landroidx/compose/runtime/Composer;->startRestartGroup(I)Landroidx/compose/runtime/Composer;

    move-result-object v2

    .end local p2    # "$composer":Landroidx/compose/runtime/Composer;
    .local v2, "$composer":Landroidx/compose/runtime/Composer;
    const-string v3, "C(SectionTitle)N(title,subtitle)62@4927L150:XunjiComponents.kt#8ao140"

    invoke-static {v2, v3}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    move/from16 v3, p3

    .local v3, "$dirty":I
    and-int/lit8 v4, p3, 0x6

    if-nez v4, :cond_25

    invoke-interface {v2, v0}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_23

    const/4 v4, 0x4

    goto :goto_24

    :cond_23
    const/4 v4, 0x2

    :goto_24
    or-int/2addr v3, v4

    :cond_25
    and-int/lit8 v4, p4, 0x2

    if-eqz v4, :cond_2e

    or-int/lit8 v3, v3, 0x30

    move-object/from16 v6, p1

    goto :goto_43

    :cond_2e
    and-int/lit8 v6, p3, 0x30

    if-nez v6, :cond_41

    move-object/from16 v6, p1

    invoke-interface {v2, v6}, Landroidx/compose/runtime/Composer;->changed(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_3d

    const/16 v7, 0x20

    goto :goto_3f

    :cond_3d
    const/16 v7, 0x10

    :goto_3f
    or-int/2addr v3, v7

    goto :goto_43

    :cond_41
    move-object/from16 v6, p1

    :goto_43
    and-int/lit8 v7, v3, 0x13

    const/16 v8, 0x12

    const/4 v9, 0x0

    if-eq v7, v8, :cond_4c

    const/4 v7, 0x1

    goto :goto_4d

    :cond_4c
    move v7, v9

    :goto_4d
    and-int/lit8 v8, v3, 0x1

    invoke-interface {v2, v7, v8}, Landroidx/compose/runtime/Composer;->shouldExecute(ZI)Z

    move-result v7

    if-eqz v7, :cond_210

    if-eqz v4, :cond_59

    const/4 v4, 0x0

    .end local p1    # "subtitle":Ljava/lang/String;
    .local v4, "subtitle":Ljava/lang/String;
    goto :goto_5a

    .end local v4    # "subtitle":Ljava/lang/String;
    .restart local p1    # "subtitle":Ljava/lang/String;
    :cond_59
    move-object v4, v6

    .end local p1    # "subtitle":Ljava/lang/String;
    .restart local v4    # "subtitle":Ljava/lang/String;
    :goto_5a
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v6

    if-eqz v6, :cond_66

    const/4 v6, -0x1

    const-string v7, "com.xunji.flashcards.ui.components.SectionTitle (XunjiComponents.kt:62)"

    invoke-static {v1, v3, v6, v7}, Landroidx/compose/runtime/ComposerKt;->traceEventStart(IIILjava/lang/String;)V

    :cond_66
    sget-object v1, Landroidx/compose/foundation/layout/Arrangement;->INSTANCE:Landroidx/compose/foundation/layout/Arrangement;

    const/4 v6, 0x5

    .local v6, "$this$dp\\1":I
    const/4 v7, 0x0

    .line 182
    .local v7, "$i$f$getDp\\1\\63":I
    int-to-float v8, v6

    invoke-static {v8}, Landroidx/compose/ui/unit/Dp;->constructor-impl(F)F

    move-result v6

    .line 63
    .end local v6    # "$this$dp\\1":I
    .end local v7    # "$i$f$getDp\\1\\63":I
    invoke-virtual {v1, v6}, Landroidx/compose/foundation/layout/Arrangement;->spacedBy-0680j_4(F)Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;

    move-result-object v1

    check-cast v1, Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .local v1, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/16 v6, 0x30

    .local v6, "$changed\\2":I
    move-object v7, v2

    .local v7, "$composer\\2":Landroidx/compose/runtime/Composer;
    move/from16 v26, v6

    .end local v6    # "$changed\\2":I
    .local v26, "$changed\\2":I
    const/16 v27, 0x0

    .line 183
    .local v27, "$i$f$Column\\2\\63":I
    const v6, 0x4ff7456f

    const-string v8, "CC(Column)N(modifier,verticalArrangement,horizontalAlignment,content)87@4443L61,88@4509L134:Column.kt#2w3rfo"

    invoke-static {v7, v6, v8}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 184
    sget-object v6, Landroidx/compose/ui/Modifier;->Companion:Landroidx/compose/ui/Modifier$Companion;

    move-object/from16 v28, v6

    check-cast v28, Landroidx/compose/ui/Modifier;

    .line 186
    .local v28, "modifier\\2":Landroidx/compose/ui/Modifier;
    sget-object v6, Landroidx/compose/ui/Alignment;->Companion:Landroidx/compose/ui/Alignment$Companion;

    invoke-virtual {v6}, Landroidx/compose/ui/Alignment$Companion;->getStart()Landroidx/compose/ui/Alignment$Horizontal;

    move-result-object v6

    .line 189
    .local v6, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    shr-int/lit8 v8, v26, 0x3

    and-int/lit8 v8, v8, 0xe

    shr-int/lit8 v10, v26, 0x3

    and-int/lit8 v10, v10, 0x70

    or-int/2addr v8, v10

    invoke-static {v1, v6, v7, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/Alignment$Horizontal;Landroidx/compose/runtime/Composer;I)Landroidx/compose/ui/layout/MeasurePolicy;

    move-result-object v8

    .line 193
    .local v8, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    shl-int/lit8 v10, v26, 0x3

    and-int/lit8 v10, v10, 0x70

    .line 190
    move/from16 v29, v10

    .local v29, "$changed\\3":I
    move-object/from16 v10, v28

    .local v10, "modifier\\3":Landroidx/compose/ui/Modifier;
    const/16 v30, 0x0

    .line 194
    .local v30, "$i$f$Layout\\3\\190":I
    const v11, -0x451e1427

    const-string v12, "CC(Layout)P(!1,2)80@3267L27,83@3433L360:Layout.kt#80mrfh"

    invoke-static {v7, v11, v12}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 195
    invoke-static {v7, v9}, Landroidx/compose/runtime/ComposablesKt;->getCurrentCompositeKeyHashCode(Landroidx/compose/runtime/Composer;I)J

    move-result-wide v11

    invoke-static {v11, v12}, Ljava/lang/Long;->hashCode(J)I

    move-result v31

    .line 196
    .local v31, "compositeKeyHash\\3":I
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getCurrentCompositionLocalMap()Landroidx/compose/runtime/CompositionLocalMap;

    move-result-object v11

    .line 197
    .local v11, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    invoke-static {v7, v10}, Landroidx/compose/ui/ComposedModifierKt;->materializeModifier(Landroidx/compose/runtime/Composer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    move-result-object v12

    .line 199
    .local v12, "materialized\\3":Landroidx/compose/ui/Modifier;
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v13}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getConstructor()Lkotlin/jvm/functions/Function0;

    move-result-object v13

    shl-int/lit8 v14, v29, 0x6

    and-int/lit16 v14, v14, 0x380

    or-int/lit8 v14, v14, 0x6

    .line 198
    nop

    .local v13, "factory\\4":Lkotlin/jvm/functions/Function0;
    move/from16 v32, v14

    .local v32, "$changed\\4":I
    const/16 v33, 0x0

    .line 200
    .local v33, "$i$f$ReusableComposeNode\\4\\198":I
    const v14, -0x20f7d59c

    const-string v15, "CC(ReusableComposeNode)N(factory,update,content)399@15590L9:Composables.kt#9igjgp"

    invoke-static {v7, v14, v15}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    .line 201
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getApplier()Landroidx/compose/runtime/Applier;

    move-result-object v14

    instance-of v14, v14, Landroidx/compose/runtime/Applier;

    if-nez v14, :cond_e3

    invoke-static {}, Landroidx/compose/runtime/ComposablesKt;->invalidApplier()V

    .line 202
    :cond_e3
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->startReusableNode()V

    .line 203
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v14

    if-eqz v14, :cond_f0

    .line 204
    invoke-interface {v7, v13}, Landroidx/compose/runtime/Composer;->createNode(Lkotlin/jvm/functions/Function0;)V

    goto :goto_f3

    .line 206
    :cond_f0
    invoke-interface {v7}, Landroidx/compose/runtime/Composer;->useNode()V

    .line 208
    :goto_f3
    invoke-static {v7}, Landroidx/compose/runtime/Updater;->constructor-impl(Landroidx/compose/runtime/Composer;)Landroidx/compose/runtime/Composer;

    move-result-object v14

    .local v14, "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    const/4 v15, 0x0

    .line 209
    .local v15, "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\208\\3":I
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual/range {v16 .. v16}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetMeasurePolicy()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v14, v8, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 210
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetResolvedCompositionLocals()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    invoke-static {v14, v11, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 211
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v5}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetCompositeKeyHash()Lkotlin/jvm/functions/Function2;

    move-result-object v5

    .local v5, "block\\6":Lkotlin/jvm/functions/Function2;
    const/16 v16, 0x0

    .line 212
    .local v16, "$i$f$set-impl\\6\\211":I
    move-object/from16 p1, v14

    .local p1, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    const/16 v17, 0x0

    .line 213
    .local v17, "$i$a$-with-Updater$set$1\\7\\212\\6":I
    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->getInserting()Z

    move-result v18

    if-nez v18, :cond_12e

    invoke-interface/range {p1 .. p1}, Landroidx/compose/runtime/Composer;->rememberedValue()Ljava/lang/Object;

    move-result-object v9

    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-static {v9, v0}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_12b

    goto :goto_12e

    :cond_12b
    move-object/from16 v9, p1

    goto :goto_13e

    .line 214
    :cond_12e
    :goto_12e
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    move-object/from16 v9, p1

    .end local p1    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .local v9, "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    invoke-interface {v9, v0}, Landroidx/compose/runtime/Composer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 215
    invoke-static/range {v31 .. v31}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-interface {v14, v0, v5}, Landroidx/compose/runtime/Composer;->apply(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 217
    :goto_13e
    nop

    .line 212
    .end local v9    # "$this$set_impl_u24lambda_u240\\6":Landroidx/compose/runtime/Composer;
    .end local v17    # "$i$a$-with-Updater$set$1\\7\\212\\6":I
    nop

    .line 217
    nop

    .line 218
    .end local v5    # "block\\6":Lkotlin/jvm/functions/Function2;
    .end local v16    # "$i$f$set-impl\\6\\211":I
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    invoke-virtual {v0}, Landroidx/compose/ui/node/ComposeUiNode$Companion;->getSetModifier()Lkotlin/jvm/functions/Function2;

    move-result-object v0

    invoke-static {v14, v12, v0}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/Composer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 219
    nop

    .line 208
    .end local v14    # "$this$Layout_u24lambda_u240\\5":Landroidx/compose/runtime/Composer;
    .end local v15    # "$i$a$-ReusableComposeNode-LayoutKt$Layout$1\\5\\208\\3":I
    nop

    .line 220
    shr-int/lit8 v0, v32, 0x6

    and-int/lit8 v34, v0, 0xe

    .local v34, "$changed\\8":I
    move-object v0, v7

    .local v0, "$composer\\8":Landroidx/compose/runtime/Composer;
    const/16 v35, 0x0

    .line 191
    .local v35, "$i$a$-Layout-ColumnKt$Column$1\\8\\220\\2":I
    const v5, 0x7cc0ae6e

    const-string v9, "C89@4557L9:Column.kt#2w3rfo"

    invoke-static {v0, v5, v9}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v5, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    shr-int/lit8 v9, v26, 0x6

    and-int/lit8 v9, v9, 0x70

    or-int/lit8 v36, v9, 0x6

    .local v36, "$changed\\9":I
    move-object/from16 v37, v5

    check-cast v37, Landroidx/compose/foundation/layout/ColumnScope;

    .local v37, "$this$SectionTitle_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    move-object v5, v0

    .local v5, "$composer\\9":Landroidx/compose/runtime/Composer;
    const/16 v38, 0x0

    .line 63
    .local v38, "$i$a$-Column-XunjiComponentsKt$SectionTitle$1\\9\\191\\0":I
    const v9, -0x75571ebd

    const-string v14, "C62@5015L10,62@4984L56:XunjiComponents.kt#8ao140"

    invoke-static {v5, v9, v14}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerStart(Landroidx/compose/runtime/Composer;ILjava/lang/String;)V

    sget-object v9, Landroidx/compose/material3/MaterialTheme;->INSTANCE:Landroidx/compose/material3/MaterialTheme;

    sget v14, Landroidx/compose/material3/MaterialTheme;->$stable:I

    invoke-virtual {v9, v5, v14}, Landroidx/compose/material3/MaterialTheme;->getTypography(Landroidx/compose/runtime/Composer;I)Landroidx/compose/material3/Typography;

    move-result-object v9

    invoke-virtual {v9}, Landroidx/compose/material3/Typography;->getHeadlineLarge()Landroidx/compose/ui/text/TextStyle;

    move-result-object v21

    and-int/lit8 v23, v3, 0xe

    const/16 v24, 0x0

    const v25, 0x1fffe

    move-object v9, v1

    .end local v1    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v9, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v1, 0x0

    move-object v14, v2

    move v15, v3

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .local v14, "$composer":Landroidx/compose/runtime/Composer;
    .local v15, "$dirty":I
    const-wide/16 v2, 0x0

    move-object/from16 v16, v4

    .end local v4    # "subtitle":Ljava/lang/String;
    .local v16, "subtitle":Ljava/lang/String;
    const/4 v4, 0x0

    move-object/from16 v22, v5

    move-object/from16 v17, v6

    .end local v5    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v6    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v17, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v22, "$composer\\9":Landroidx/compose/runtime/Composer;
    const-wide/16 v5, 0x0

    move-object/from16 v19, v7

    .end local v7    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v19, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/4 v7, 0x0

    move-object/from16 v20, v8

    .end local v8    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v20, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/4 v8, 0x0

    move-object/from16 v39, v9

    .end local v9    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .local v39, "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    const/4 v9, 0x0

    move-object/from16 v40, v10

    move-object/from16 v41, v11

    .end local v10    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v11    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .local v40, "modifier\\3":Landroidx/compose/ui/Modifier;
    .local v41, "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    const-wide/16 v10, 0x0

    move-object/from16 v42, v12

    .end local v12    # "materialized\\3":Landroidx/compose/ui/Modifier;
    .local v42, "materialized\\3":Landroidx/compose/ui/Modifier;
    const/4 v12, 0x0

    move-object/from16 v43, v13

    .end local v13    # "factory\\4":Lkotlin/jvm/functions/Function0;
    .local v43, "factory\\4":Lkotlin/jvm/functions/Function0;
    const/4 v13, 0x0

    move-object/from16 v44, v14

    move/from16 v45, v15

    .end local v14    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v15    # "$dirty":I
    .local v44, "$composer":Landroidx/compose/runtime/Composer;
    .local v45, "$dirty":I
    const-wide/16 v14, 0x0

    move-object/from16 v46, v16

    .end local v16    # "subtitle":Ljava/lang/String;
    .local v46, "subtitle":Ljava/lang/String;
    const/16 v16, 0x0

    move-object/from16 v47, v17

    .end local v17    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .local v47, "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    const/16 v17, 0x0

    const/16 v48, 0x0

    const/16 v18, 0x0

    move-object/from16 v49, v19

    .end local v19    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .local v49, "$composer\\2":Landroidx/compose/runtime/Composer;
    const/16 v19, 0x0

    move-object/from16 v50, v20

    .end local v20    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    .local v50, "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    const/16 v20, 0x0

    move-object/from16 v51, v46

    move-object/from16 v46, v0

    move-object/from16 v0, p0

    .end local v0    # "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v46, "$composer\\8":Landroidx/compose/runtime/Composer;
    .local v51, "subtitle":Ljava/lang/String;
    invoke-static/range {v0 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JLandroidx/compose/foundation/text/TextAutoSize;JLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/Composer;III)V

    move-object/from16 v1, v22

    move-object/from16 v4, v51

    .end local v22    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v51    # "subtitle":Ljava/lang/String;
    .local v1, "$composer\\9":Landroidx/compose/runtime/Composer;
    .restart local v4    # "subtitle":Ljava/lang/String;
    if-eqz v4, :cond_1e7

    const v2, 0x7815ffd5

    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    const-string v2, "62@5059L16"

    invoke-static {v1, v2}, Landroidx/compose/runtime/ComposerKt;->sourceInformation(Landroidx/compose/runtime/Composer;Ljava/lang/String;)V

    shr-int/lit8 v2, v45, 0x3

    and-int/lit8 v2, v2, 0xe

    const/4 v3, 0x0

    const/4 v5, 0x2

    invoke-static {v4, v3, v1, v2, v5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->Notice(Ljava/lang/String;ZLandroidx/compose/runtime/Composer;II)V

    goto :goto_1ed

    :cond_1e7
    const v2, -0x75a29ea3

    invoke-interface {v1, v2}, Landroidx/compose/runtime/Composer;->startReplaceGroup(I)V

    :goto_1ed
    invoke-interface {v1}, Landroidx/compose/runtime/Composer;->endReplaceGroup()V

    invoke-static {v1}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 191
    .end local v1    # "$composer\\9":Landroidx/compose/runtime/Composer;
    .end local v36    # "$changed\\9":I
    .end local v37    # "$this$SectionTitle_u24lambda_u240\\9":Landroidx/compose/foundation/layout/ColumnScope;
    .end local v38    # "$i$a$-Column-XunjiComponentsKt$SectionTitle$1\\9\\191\\0":I
    invoke-static/range {v46 .. v46}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 220
    .end local v34    # "$changed\\8":I
    .end local v35    # "$i$a$-Layout-ColumnKt$Column$1\\8\\220\\2":I
    .end local v46    # "$composer\\8":Landroidx/compose/runtime/Composer;
    nop

    .line 221
    invoke-interface/range {v49 .. v49}, Landroidx/compose/runtime/Composer;->endNode()V

    .line 200
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 222
    nop

    .line 194
    .end local v32    # "$changed\\4":I
    .end local v33    # "$i$f$ReusableComposeNode\\4\\198":I
    .end local v43    # "factory\\4":Lkotlin/jvm/functions/Function0;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 223
    nop

    .line 183
    .end local v29    # "$changed\\3":I
    .end local v30    # "$i$f$Layout\\3\\190":I
    .end local v31    # "compositeKeyHash\\3":I
    .end local v40    # "modifier\\3":Landroidx/compose/ui/Modifier;
    .end local v41    # "localMap\\3":Landroidx/compose/runtime/CompositionLocalMap;
    .end local v42    # "materialized\\3":Landroidx/compose/ui/Modifier;
    invoke-static/range {v49 .. v49}, Landroidx/compose/runtime/ComposerKt;->sourceInformationMarkerEnd(Landroidx/compose/runtime/Composer;)V

    .line 224
    nop

    .end local v26    # "$changed\\2":I
    .end local v27    # "$i$f$Column\\2\\63":I
    .end local v28    # "modifier\\2":Landroidx/compose/ui/Modifier;
    .end local v39    # "verticalArrangement\\2":Landroidx/compose/foundation/layout/Arrangement$Vertical;
    .end local v47    # "horizontalAlignment\\2":Landroidx/compose/ui/Alignment$Horizontal;
    .end local v49    # "$composer\\2":Landroidx/compose/runtime/Composer;
    .end local v50    # "measurePolicy\\2":Landroidx/compose/ui/layout/MeasurePolicy;
    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->isTraceInProgress()Z

    move-result v1

    if-eqz v1, :cond_218

    invoke-static {}, Landroidx/compose/runtime/ComposerKt;->traceEventEnd()V

    goto :goto_218

    .line 63
    .end local v4    # "subtitle":Ljava/lang/String;
    .end local v44    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v45    # "$dirty":I
    .restart local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v3    # "$dirty":I
    .local p1, "subtitle":Ljava/lang/String;
    :cond_210
    move-object/from16 v44, v2

    move/from16 v45, v3

    .end local v2    # "$composer":Landroidx/compose/runtime/Composer;
    .end local v3    # "$dirty":I
    .restart local v44    # "$composer":Landroidx/compose/runtime/Composer;
    .restart local v45    # "$dirty":I
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->skipToGroupEnd()V

    move-object v4, v6

    .end local p1    # "subtitle":Ljava/lang/String;
    .restart local v4    # "subtitle":Ljava/lang/String;
    :cond_218
    :goto_218
    invoke-interface/range {v44 .. v44}, Landroidx/compose/runtime/Composer;->endRestartGroup()Landroidx/compose/runtime/ScopeUpdateScope;

    move-result-object v1

    if-eqz v1, :cond_22b

    new-instance v2, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda9;

    move/from16 v3, p3

    move/from16 v5, p4

    invoke-direct {v2, v0, v4, v3, v5}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt$$ExternalSyntheticLambda9;-><init>(Ljava/lang/String;Ljava/lang/String;II)V

    invoke-interface {v1, v2}, Landroidx/compose/runtime/ScopeUpdateScope;->updateScope(Lkotlin/jvm/functions/Function2;)V

    goto :goto_22d

    :cond_22b
    move/from16 v3, p3

    :goto_22d
    return-void
.end method

.method private static final SectionTitle$lambda$1(Ljava/lang/String;Ljava/lang/String;IILandroidx/compose/runtime/Composer;I)Lkotlin/Unit;
    .registers 7

    or-int/lit8 v0, p2, 0x1

    invoke-static {v0}, Landroidx/compose/runtime/RecomposeScopeImplKt;->updateChangedFlags(I)I

    move-result v0

    invoke-static {p0, p1, p4, v0, p3}, Lcom/xunji/flashcards/ui/components/XunjiComponentsKt;->SectionTitle(Ljava/lang/String;Ljava/lang/String;Landroidx/compose/runtime/Composer;II)V

    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    return-object v0
.end method

.method public static final durationLabel(J)Ljava/lang/String;
    .registers 5
    .param p0, "ms"    # J

    .line 70
    const-wide/32 v0, 0xea60

    cmp-long v0, p0, v0

    if-gez v0, :cond_18

    const/16 v0, 0x3e8

    int-to-long v0, v0

    div-long v0, p0, v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u79d2"

    goto :goto_29

    :cond_18
    const v0, 0xea60

    int-to-long v0, v0

    div-long v0, p0, v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v0

    const-string v1, " \u5206\u949f"

    :goto_29
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public static final intervalLabel(JJ)Ljava/lang/String;
    .registers 9
    .param p0, "dueAt"    # J
    .param p2, "now"    # J

    .line 66
    sub-long v0, p0, p2

    const-wide/16 v2, 0x0

    invoke-static {v0, v1, v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v0

    const v2, 0xea60

    int-to-long v2, v2

    div-long/2addr v0, v2

    const-wide/16 v2, 0x1

    invoke-static {v0, v1, v2, v3}, Lkotlin/ranges/RangesKt;->coerceAtLeast(JJ)J

    move-result-wide v0

    .line 67
    .local v0, "minutes":J
    const-wide/16 v2, 0x3c

    cmp-long v2, v0, v2

    if-gez v2, :cond_2d

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5206\u949f"

    :goto_24
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    goto :goto_55

    :cond_2d
    const-wide/16 v2, 0x5a0

    cmp-long v2, v0, v2

    if-gez v2, :cond_44

    const/16 v2, 0x3c

    int-to-long v2, v2

    div-long v2, v0, v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5c0f\u65f6"

    goto :goto_24

    :cond_44
    const/16 v2, 0x5a0

    int-to-long v2, v2

    div-long v2, v0, v2

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    move-result-object v2

    const-string v3, " \u5929"

    goto :goto_24

    :goto_55
    return-object v2
.end method

.method public static final localTime(J)Ljava/lang/String;
    .registers 4
    .param p0, "timestamp"    # J

    .line 69
    invoke-static {p0, p1}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    move-result-object v0

    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    move-result-object v0

    const-string v1, "M\u6708d\u65e5 HH:mm"

    invoke-static {v1}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;)Ljava/time/format/DateTimeFormatter;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/time/ZonedDateTime;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    move-result-object v0

    const-string v1, "format(...)"

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->checkNotNullExpressionValue(Ljava/lang/Object;Ljava/lang/String;)V

    return-object v0
.end method

.class public final synthetic Lcom/xunji/flashcards/backup/BackupArchive$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic f$0:Lcom/xunji/flashcards/backup/BackupArchive;


# direct methods
.method public synthetic constructor <init>(Lcom/xunji/flashcards/backup/BackupArchive;)V
    .registers 2

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/xunji/flashcards/backup/BackupArchive$$ExternalSyntheticLambda1;->f$0:Lcom/xunji/flashcards/backup/BackupArchive;

    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 2

    .line 0
    iget-object v0, p0, Lcom/xunji/flashcards/backup/BackupArchive$$ExternalSyntheticLambda1;->f$0:Lcom/xunji/flashcards/backup/BackupArchive;

    invoke-static {v0}, Lcom/xunji/flashcards/backup/BackupArchive;->$r8$lambda$FoxGp2m22TwAudPtZzwk62hjkgo(Lcom/xunji/flashcards/backup/BackupArchive;)Ljava/util/Map;

    move-result-object v0

    return-object v0
.end method
